// =====================================================================
// ELYSIUM | Weapon Wear — fumble + crit-parry weapon damage (v0.22.0-alpha.11)
// =====================================================================
//
// Phase C of the armor/weapon HP rules change. Mirrors armor-wear.mjs.
//
// Per the rules, a weapon takes damage in two situations:
//
//   1. Fumble — depending on the fumble-table result, the wielder's
//      weapon may take damage. Fully GM-adjudicated; this module
//      provides the chat-card "Apply Fumble Weapon Damage" button so
//      the GM can apply -1 HP with one click after rolling the table.
//
//   2. Crit-parry — when an attack rolled a Critical success (resultLevel
//      >= 4) and the defender's parry rolled BELOW Critical (resultLevel
//      < 4, but high enough to actually parry), the defender's parry
//      weapon takes -1 HP. EXCEPTION: if the parry was ALSO a Critical
//      (resultLevel >= 4), the parry "holds" and the weapon takes NO
//      damage. The rule lives in applyCritParryDamage() — callers pass
//      both result levels and the function decides.
//
// State storage: weapon's max HP lives in BRP's standard `system.hp`
// field; current HP lives in `system.hpCurr`. Both are already part of
// the weapon template (unlike armor, no schema migration needed). Broken
// state is derived: `hp > 0 && hpCurr === 0` (the hp > 0 guard means
// untuned/placeholder weapons with hp=0 don't show as broken).
//
// Triggers (where this module is called from):
//   - Damage chat card / fumble flow — GM clicks the "Apply Fumble
//     Weapon Damage" button after resolving a fumble table result.
//   - Combat resolution chat card — GM clicks the "Apply Crit-Parry
//     Damage" button when an attack-crit is parried by a non-crit parry.
//
// Both triggers are GM-facilitated (no auto-fire) because BRP-classic
// combat-card resolution doesn't carry the necessary state through to
// a centralized chokepoint. The pure-function API
// (applyCritParryDamage, applyWeaponDamage, repairWeapon) is in place
// so future automation work can plug straight in.
// =====================================================================

const FLAG_NS = 'elysium'

// ---------------------------------------------------------------------
// Core wear helpers
// ---------------------------------------------------------------------

/**
 * Decrement a weapon's current HP by `amount`. Clamps at 0.
 * Idempotent for items already at 0 (no further decrement).
 *
 * Side effect: posts a chat card noting the damage with reason.
 *
 * @param {Item} item      - the weapon
 * @param {number} amount  - HP to remove (default 1)
 * @param {string} reason  - human-readable trigger label
 *                            ('fumble' | 'crit-parry' | etc.)
 * @returns {Promise<{previous, current, broken, didDecrement}>}
 */
export async function applyWeaponDamage (item, amount = 1, reason = 'weapon-damage') {
  if (!item || item.type !== 'weapon') {
    return { previous: 0, current: 0, broken: false, didDecrement: false }
  }
  const prev = Number(item.system?.hpCurr) || 0
  if (prev <= 0) {
    // Already broken — no further damage to track
    return { previous: 0, current: 0, broken: true, didDecrement: false }
  }
  const next = Math.max(0, prev - Math.max(0, amount))
  await item.update({ 'system.hpCurr': next })
  const broken = next === 0

  await _postWeaponWearCard(item, prev, next, reason)

  return { previous: prev, current: next, broken, didDecrement: prev !== next }
}

/**
 * Restore current HP toward max (`system.hp`). Clamps at max. Used by
 * the Repair button on the weapon sheet (and any future Craft-check
 * integration).
 *
 * @param {Item} item      - the weapon
 * @param {number} amount  - HP to restore (default 1)
 * @returns {Promise<{previous, current, fullyRepaired}>}
 */
export async function repairWeapon (item, amount = 1) {
  if (!item || item.type !== 'weapon') {
    return { previous: 0, current: 0, fullyRepaired: false }
  }
  const prev = Number(item.system?.hpCurr) || 0
  const hpMax = Number(item.system?.hp) || 0
  if (hpMax <= 0) {
    // No max defined — repair is a no-op
    return { previous: prev, current: prev, fullyRepaired: false }
  }
  if (prev >= hpMax) {
    return { previous: prev, current: prev, fullyRepaired: true }
  }
  const next = Math.min(hpMax, prev + Math.max(0, amount))
  await item.update({ 'system.hpCurr': next })
  return { previous: prev, current: next, fullyRepaired: next >= hpMax }
}

/**
 * Check whether a weapon is broken (hpCurr === 0). Includes the
 * hp > 0 guard so placeholder/untuned weapons (hp=0) don't show as
 * broken, mirroring the armor `apMax > 0` guard.
 *
 * @param {Item} item
 * @returns {boolean}
 */
export function isWeaponBroken (item) {
  if (!item || item.type !== 'weapon') return false
  const hpMax = Number(item.system?.hp) || 0
  if (hpMax <= 0) return false   // never had HP, not "broken"
  return (Number(item.system?.hpCurr) || 0) === 0
}

/**
 * Apply the crit-parry rule.
 *
 * Rule: when the attack is a Critical (resultLevel >= 4) AND the parry
 * is BELOW Critical (resultLevel < 4), the defender's parry weapon
 * takes 1 HP damage. If the parry was also Critical, the parry "holds"
 * and no damage applies.
 *
 * BRP resultLevel scale (for reference):
 *   1 = Failure, 2 = Success, 3 = Special, 4 = Critical, 5+ = ...
 *
 * NOTE: This function does NOT check whether the parry actually
 * connected (resultLevel >= 2). A failed parry never reaches this
 * code path in the first place — if the parry missed, the attacker's
 * critical resolves as normal damage rather than as a parry contest,
 * and there's no parry weapon to damage. Callers should only invoke
 * this when a parry was rolled and at least minimally succeeded.
 *
 * @param {Item}   parryWeapon       - the defender's parrying weapon
 * @param {number} attackResultLevel - attacker's resultLevel (1..5+)
 * @param {number} parryResultLevel  - defender's resultLevel (1..5+)
 * @param {string} reason            - label override (default 'crit-parry')
 * @returns {Promise<{applied, reason, previous, current, broken}>}
 */
export async function applyCritParryDamage (parryWeapon, attackResultLevel, parryResultLevel, reason = 'crit-parry') {
  const aRL = Number(attackResultLevel) || 0
  const pRL = Number(parryResultLevel) || 0

  // Rule gate: attack must be crit, parry must be sub-crit.
  if (aRL < 4) {
    return { applied: false, reason: 'attack-not-crit', previous: 0, current: 0, broken: false }
  }
  if (pRL >= 4) {
    // Crit-vs-crit: parry holds, weapon takes no damage.
    return { applied: false, reason: 'parry-was-crit', previous: 0, current: 0, broken: false }
  }
  if (!parryWeapon || parryWeapon.type !== 'weapon') {
    return { applied: false, reason: 'no-parry-weapon', previous: 0, current: 0, broken: false }
  }

  const r = await applyWeaponDamage(parryWeapon, 1, reason)
  return {
    applied: r.didDecrement,
    reason: r.didDecrement ? 'crit-parry' : 'already-broken',
    previous: r.previous,
    current: r.current,
    broken: r.broken,
  }
}

// ---------------------------------------------------------------------
// Chat-card surface
// ---------------------------------------------------------------------

async function _postWeaponWearCard (item, prevHP, newHP, reason) {
  const actor = item.parent
  const hpMax = Number(item.system?.hp) || 0
  const broken = newHP === 0
  const reasonLabel =
    reason === 'fumble'     ? 'fumble' :
    reason === 'crit-parry' ? 'parry against critical attack' :
    reason

  const hpMaxText = hpMax ? ` / ${hpMax}` : ''
  const body =
    `<p>${game.i18n.format('Elysium.Chat.WeaponWearBody', {
      actor: `<b>${actor?.name || 'Weapon'}</b>`,
      item: `<b>${item.name}</b>`,
      reason: reasonLabel,
      prevHP,
      newHP: `<b>${newHP}</b>${hpMaxText}`,
      hpMax: '',
    })}</p>` +
    (broken ? `<p><b>${game.i18n.localize('Elysium.Chat.WeaponBroken')}</b></p>` : '')

  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: broken ? 'danger' : 'bonus-dark', icon: 'wrench', body }
  )
  await ChatMessage.create({
    content: html,
    speaker: actor ? ChatMessage.getSpeaker({ actor }) : undefined,
    flags: { [FLAG_NS]: { weaponWearCard: true } },
  })
}

/**
 * Build an HTML button string for the "Apply Fumble Weapon Damage"
 * surface. The fumble-resolution flow emits this when the fumble-table
 * result indicates weapon damage. Click handler wired in
 * `wireWeaponWearChatHandlers` below.
 *
 * @param {string} actorId  - the wielder's actor ID
 * @param {string} weaponId - the weapon item ID (owned by that actor)
 * @returns {string}
 */
export function buildApplyFumbleDamageButtonHTML (actorId, weaponId) {
  return `
    <button type="button"
            class="elysium-weapon-wear-btn"
            data-elysium-weapon-wear-action="apply-fumble"
            data-actor-id="${actorId}"
            data-weapon-id="${weaponId}"
            style="background:#a07020;color:#fff;border:1px solid #806010;padding:2px 8px;border-radius:3px;cursor:pointer;">
      Apply Fumble Weapon Damage
    </button>
  `
}

/**
 * Build an HTML button string for the "Apply Crit-Parry Damage"
 * surface. The combat-resolution card emits this when an attack rolled
 * a Critical and the defender's parry rolled below Critical. The
 * button's click handler invokes applyCritParryDamage with the carried
 * result levels, so the rule gate is re-checked at click time too.
 *
 * @param {string} defenderId        - the parrying actor's ID
 * @param {string} parryWeaponId     - the parry weapon item ID
 * @param {number} attackResultLevel - attacker's resultLevel
 * @param {number} parryResultLevel  - defender's resultLevel
 * @returns {string}
 */
export function buildApplyCritParryButtonHTML (defenderId, parryWeaponId, attackResultLevel, parryResultLevel) {
  return `
    <button type="button"
            class="elysium-weapon-wear-btn"
            data-elysium-weapon-wear-action="apply-crit-parry"
            data-defender-id="${defenderId}"
            data-weapon-id="${parryWeaponId}"
            data-attack-rl="${Number(attackResultLevel) || 0}"
            data-parry-rl="${Number(parryResultLevel) || 0}"
            style="background:#a07020;color:#fff;border:1px solid #806010;padding:2px 8px;border-radius:3px;cursor:pointer;">
      Apply Crit-Parry Damage
    </button>
  `
}

// ---------------------------------------------------------------------
// Chat-card delegation
// ---------------------------------------------------------------------

/**
 * Resolve a weapon item by ID — first checks world items, then walks
 * actors. Returns null if not found.
 */
function _resolveWeapon (itemId, actorIdHint) {
  if (!itemId) return null
  if (actorIdHint) {
    const a = game.actors?.get(actorIdHint)
    const owned = a?.items?.get(itemId)
    if (owned) return owned
  }
  let item = game.items?.get(itemId)
  if (item) return item
  for (const a of game.actors?.contents || []) {
    const found = a.items?.get(itemId)
    if (found) return found
  }
  return null
}

/**
 * Wire delegated click handlers for weapon-wear UI:
 *   - "Apply Fumble Weapon Damage" button on fumble chat cards
 *   - "Apply Crit-Parry Damage" button on combat resolution cards
 *   - "Repair +1" button on the weapon item sheet
 *
 * Called once during the ready hook (see elysium.mjs).
 */
export function wireWeaponWearChatHandlers () {
  document.body.addEventListener('click', async (ev) => {
    // Chat-card buttons (fumble or crit-parry)
    const damBtn = ev.target.closest('[data-elysium-weapon-wear-action]')
    if (damBtn) {
      ev.preventDefault()
      const action = damBtn.dataset.elysiumWeaponWearAction

      if (action === 'apply-fumble') {
        const actorId  = damBtn.dataset.actorId
        const weaponId = damBtn.dataset.weaponId
        const weapon = _resolveWeapon(weaponId, actorId)
        if (!weapon) {
          ui.notifications?.warn('Weapon not found for fumble damage.')
          return
        }
        const r = await applyWeaponDamage(weapon, 1, 'fumble')
        if (!r.didDecrement) {
          ui.notifications?.info(`${weapon.name} is already broken.`)
        } else {
          damBtn.disabled = true
          damBtn.style.opacity = '0.5'
          damBtn.textContent = 'Applied'
        }
        return
      }

      if (action === 'apply-crit-parry') {
        const defenderId = damBtn.dataset.defenderId
        const weaponId   = damBtn.dataset.weaponId
        const aRL = Number(damBtn.dataset.attackRl) || 0
        const pRL = Number(damBtn.dataset.parryRl) || 0
        const weapon = _resolveWeapon(weaponId, defenderId)
        if (!weapon) {
          ui.notifications?.warn('Parry weapon not found for crit-parry damage.')
          return
        }
        const r = await applyCritParryDamage(weapon, aRL, pRL, 'crit-parry')
        if (!r.applied) {
          const msg =
            r.reason === 'parry-was-crit'   ? `${weapon.name}: parry was a critical — no damage.` :
            r.reason === 'attack-not-crit'  ? `${weapon.name}: attack was not a critical — no damage.` :
            r.reason === 'already-broken'   ? `${weapon.name} is already broken.` :
                                              `${weapon.name}: no damage applied.`
          ui.notifications?.info(msg)
        } else {
          damBtn.disabled = true
          damBtn.style.opacity = '0.5'
          damBtn.textContent = 'Applied'
        }
        return
      }
      return
    }

    // Weapon item-sheet Repair button
    const repBtn = ev.target.closest('[data-elysium-weapon-action]')
    if (repBtn) {
      ev.preventDefault()
      const action = repBtn.dataset.elysiumWeaponAction
      if (action === 'repair') {
        const itemId = repBtn.dataset.itemId
        const item = _resolveWeapon(itemId)
        if (!item) {
          ui.notifications?.warn('Weapon item not found.')
          return
        }
        const r = await repairWeapon(item, 1)
        ui.notifications?.info(
          `${item.name}: ${r.previous} → ${r.current} HP${r.fullyRepaired ? ' (fully repaired)' : ''}.`
        )
      }
    }
  })
}

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

export const ElysiumWeaponWear = {
  applyWeaponDamage,
  repairWeapon,
  isWeaponBroken,
  applyCritParryDamage,
  buildApplyFumbleDamageButtonHTML,
  buildApplyCritParryButtonHTML,
  wireWeaponWearChatHandlers,
}
