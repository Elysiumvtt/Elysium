import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumAllegianceSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['allegiance'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs: { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details: {
      template: 'systems/elysium/templates/item/allegiance.detail.hbs',
      scrollable: ['']
    },
    benefits: { template: 'systems/elysium/templates/item/allegiance.benefits.hbs' },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes: { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' }
  }

  // Tabbed — base's _getTabs includes 'benefits' case (alpha.39 addition)
  static TAB_ORDER = ['header', 'tabs', 'details', 'benefits', 'description']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Header chips per c2-2 lock — Opposed-allegiance + Title + Total when owned.
    const oppAlleg = this.item.system.opposeAlleg;
    const chips = [{
      label: game.i18n.localize('Elysium.opposeAlleg'),
      value: oppAlleg && oppAlleg.length > 0 ? oppAlleg : '—',
    }];
    if (context.hasOwner) {
      const title = this.item.system.allegTitle;
      chips.push(
        { label: game.i18n.localize('Elysium.title'),
          value: title && title.length > 0 ? title : '—' },
        { label: game.i18n.localize('Elysium.total'),
          value: String(this.item.system.total ?? 0) },
      );
    }
    context.itemHeaderChips = chips;

    context.tabs = this._getTabs(options.parts);
    return context
  }

  _onRender(context, _options) {
  }
}
