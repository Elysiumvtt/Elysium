// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { getSetting } from '../../settings/register-settings.mjs'

export function wireEvents (app, html, actor) {
    // Refresh AP button
    html.querySelectorAll('[data-elysium-action="refreshAP"]').forEach(el => {
      el.addEventListener('click', async () => {
        const { ElysiumActorExtension } = await import('../actor/actor-extension.mjs')
        const apData = ElysiumActorExtension.calculateActionPoints(actor)
        await actor.update({
          'system.actionPoints.value':        apData.max,
          'system.actionPoints.max':          apData.max,
          'system.actionPoints.reactValue':   apData.reactMax,
          'system.actionPoints.reactMax':     apData.reactMax,
          'system.actionPoints.attackValue':  apData.attackMax,
          'system.actionPoints.attackMax':    apData.attackMax,
          'system.actionPoints.defenseValue': apData.defenseMax,
          'system.actionPoints.defenseMax':   apData.defenseMax,
        })
      })
    })

    // Spend Luck Point
    html.querySelectorAll('[data-elysium-action="spendLuck"]').forEach(el => {
      el.addEventListener('click', async () => {
        if (!getSetting('enableLuckPoints', true)) return
        const luck = actor.system?.luckPoints?.value || 0
        if (luck <= 0) return ui.notifications.warn(game.i18n.localize('Elysium.Luck.None'))
        await actor.update({ 'system.luckPoints.value': luck - 1 })
      })
    })

    // Increment fatigue (GM only)
    html.querySelectorAll('[data-elysium-action="incrementFatigue"]').forEach(el => {
      el.addEventListener('click', async () => {
        if (!game.user.isGM) return
        const { ElysiumFatigueManager } = await import('../fatigue/fatigue-manager.mjs')
        await ElysiumFatigueManager.increment(actor, 1, 'physical', 'manual')
      })
    })

    // Decrement fatigue
    html.querySelectorAll('[data-elysium-action="decrementFatigue"]').forEach(el => {
      el.addEventListener('click', async () => {
        const { ElysiumFatigueManager } = await import('../fatigue/fatigue-manager.mjs')
        await ElysiumFatigueManager.decrement(actor, 1)
      })
    })
  }
