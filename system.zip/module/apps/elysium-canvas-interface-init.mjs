import ElysiumCanvasInterfaceAmbientLightToggle from "./elysium-canvas-interface-ambient-light-toggle.mjs";
import ElysiumCanvasInterfaceDrawingToggle from "./elysium-canvas-interface-drawing-toggle.mjs";
import ElysiumCanvasInterfaceMapPinToggle from "./elysium-canvas-interface-map-pin-toggle.mjs";
import ElysiumCanvasInterfaceOpenDocument from "./elysium-canvas-interface-open-document.mjs";
import ElysiumCanvasInterfacePlaySound from "./elysium-canvas-interface-play-sound.mjs";
import ElysiumCanvasInterfaceToScene from "./elysium-canvas-interface-to-scene.mjs";
import ElysiumCanvasInterfaceTileToggle from "./elysium-canvas-interface-tile-toggle.mjs";
import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfaceInit extends ElysiumCanvasInterface {
  static initSelf () {
    const known = [
      ElysiumCanvasInterfaceAmbientLightToggle,
      ElysiumCanvasInterfaceDrawingToggle,
      ElysiumCanvasInterfaceMapPinToggle,
      ElysiumCanvasInterfaceOpenDocument,
      ElysiumCanvasInterfacePlaySound,
      ElysiumCanvasInterfaceToScene,
      ElysiumCanvasInterfaceTileToggle
    ]

    super.initSelf()
    const dataModels = {}
    const typeIcons = {}
    const types = []
    for (const cci of known) {
      const name = (new cci).constructor.name
      dataModels[name] = cci
      typeIcons[name] = cci.icon
      types.push(name)
    }

    Object.assign(CONFIG.RegionBehavior.dataModels, dataModels)

    Object.assign(CONFIG.RegionBehavior.typeIcons, typeIcons)

    foundry.applications.apps.DocumentSheetConfig.registerSheet(
      RegionBehavior,
      'elysium',
      foundry.applications.sheets.RegionBehaviorConfig,
      {
        types: types,
        makeDefault: true
      }
    )
  }
}
