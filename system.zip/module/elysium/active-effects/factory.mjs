/**
 * Elysium Active Effect Factory
 *
 * Creates standardised Active Effects for:
 *   - Conditions (Bleeding, Stunned, Frozen, etc.)
 *   - Wound penalties (cumulative)
 *   - Buffs and boons
 *   - Debuffs and afflictions
 *   - Aura effects
 *
 * AE flags structure:
 *   flags.elysium = {
 *     group:         'condition.Stunned' | 'wound' | 'aura' | etc.
 *     condition:     'stunned' (machine name)
 *     ongoing:       boolean (applies per round)
 *     duration:      { rounds, minutes, hours, days }
 *     bleedRate:     number (HP loss per round)
 *     ongoingDamage: { amount, source }
 *     stacking:      'best' | 'cumulative' | 'replace'
 *   }
 */

import { ELYSIUM } from '../config/config.mjs'
export class ElysiumActiveEffectFactory {

  /**
   * Create a condition AE on an actor.
   * Defaults to "best of" stacking — multiple sources of the same
   * condition do not stack except for the Wound group.
   */
  static async applyCondition (actor, conditionName, options = {}) {
    const M = ELYSIUM.MODULE_ID
    const group = `condition.${conditionName}`

    // Check existing same-group effects
    const existing = actor.effects.filter(e =>
      e.flags?.['elysium']?.group === group
    )

    // Wound condition is cumulative; others use best-of (skip if exists)
    if (conditionName !== 'Wound' && existing.length > 0) {
      // Update best-of: keep the more severe one if applicable
      const stacking = options.stacking || 'best'
      if (stacking === 'best') return null    // skip
      if (stacking === 'replace') {
        await actor.deleteEmbeddedDocuments('ActiveEffect',
          existing.map(e => e.id))
      }
    }

    const aeData = this._buildConditionAE(conditionName, options)
    aeData.flags['elysium'].group = group

    return await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }

  static _buildConditionAE (conditionName, options) {
    const def = CONDITION_DEFINITIONS[conditionName] || {}

    return {
      name: conditionName,
      icon: def.icon || 'icons/svg/aura.svg',
      duration: options.duration || def.duration || {},
      changes: this._buildChanges(conditionName, def, options),
      flags: {
        'elysium': {
          condition:     def.machineName || conditionName.toLowerCase(),
          ongoing:       (options.ongoing !== undefined ? options.ongoing : def.ongoing) || false,
          bleedRate:     options.bleedRate || def.bleedRate,
          ongoingDamage: options.ongoingDamage || def.ongoingDamage,
          stacking:      options.stacking || def.stacking || 'best',
          fromSource:    options.source || 'manual',
          ...(options.extraFlags || {}),
        }
      },
      disabled: false,
      transfer: false,
    }
  }

  /**
   * Public accessor for condition definitions. Used by the conditions
   * chip renderer to fall back to default amounts (Burning 2, Bleeding 1)
   * when an AE was created before v0.5.9 and doesn't carry the flag.
   */
  static getDefinition (conditionName) {
    return CONDITION_DEFINITIONS[conditionName] || null
  }

  // =====================================================================
  // PER-LOCATION CONDITIONS (v0.6.0+)
  // =====================================================================
  //
  // Storage: hit-location items carry an array at
  //   item.system.elysium.locationConditions = [
  //     { name: 'Bleeding',  amount: 1, source: 'crit:torn-muscle' },
  //     { name: 'Burning',   amount: 2, source: 'spell:flame-arrow' },
  //   ]
  //
  // Each entry is a { name, amount, source } record. Best-of stacking
  // applies per location: re-applying the same condition keeps the
  // highest amount (also refreshes the source attribution).
  //
  // The actor-level conditions panel chip aggregates by walking every
  // hit-location and grouping by condition name; no actor-level AE is
  // created — single source of truth lives on the location items.
  //
  // Round-tick damage resolution lives in combat-extension.mjs::
  // _applyLocationConditionDamage; this module only handles state
  // mutation.

  /**
   * Add a condition to a specific hit-location item.
   * Best-of stacking by amount; refreshing duration is implicit (the
   * record is overwritten on re-application).
   *
   * @param {Actor}  actor
   * @param {string} locationItemId  the hit-location item id on the actor
   * @param {string} conditionName   key in CONDITION_DEFINITIONS
   * @param {object} [options]       { amount?, source?, override? }
   *                                 - amount overrides the default damage
   *                                 - source is a short attribution string
   *                                 - override forces a value even if lower
   * @returns {Promise<boolean>}     true if the location's list was updated
   */
  static async applyLocationCondition (actor, locationItemId, conditionName, options = {}) {
    const def = CONDITION_DEFINITIONS[conditionName]
    if (!def) {
      console.warn(`Elysium | applyLocationCondition: unknown condition "${conditionName}"`)
      return false
    }
    if (!def.perLocation) {
      console.warn(`Elysium | "${conditionName}" is not a per-location condition; use applyCondition instead`)
      return false
    }

    const location = actor?.items.get(locationItemId)
    if (!location || location.type !== 'hit-location') {
      console.warn(`Elysium | applyLocationCondition: location item ${locationItemId} not found on ${actor?.name}`)
      return false
    }

    // Determine the amount to apply: explicit option, then bleedRate /
    // ongoingDamage.amount / ongoingMaxHPLoss.amount from the definition.
    const incomingAmount = Number(options.amount) ||
                           Number(def.bleedRate) ||
                           Number(def.ongoingDamage?.amount) ||
                           Number(def.ongoingMaxHPLoss?.amount) ||
                           1

    const list = foundry.utils.deepClone(location.system?.elysium?.locationConditions || [])
    const existingIdx = list.findIndex(c => c.name === conditionName)

    const newRecord = {
      name:   conditionName,
      amount: incomingAmount,
      source: options.source || 'manual',
    }

    if (existingIdx >= 0) {
      // Best-of stacking — keep the higher amount, refresh source if higher
      const existing = list[existingIdx]
      if (options.override === true || incomingAmount > existing.amount) {
        list[existingIdx] = newRecord
      } else {
        // Existing is at-least-as-severe; refresh source only if explicit
        if (options.source) list[existingIdx].source = options.source
      }
    } else {
      list.push(newRecord)
    }

    await location.update({ 'system.elysium.locationConditions': list })
    return true
  }

  /**
   * Remove a condition from a specific hit-location item.
   *
   * @param {Actor}  actor
   * @param {string} locationItemId
   * @param {string} conditionName
   * @returns {Promise<boolean>}  true if a condition was removed
   */
  static async removeLocationCondition (actor, locationItemId, conditionName) {
    const location = actor?.items.get(locationItemId)
    if (!location || location.type !== 'hit-location') return false

    const list = location.system?.elysium?.locationConditions || []
    const filtered = list.filter(c => c.name !== conditionName)
    if (filtered.length === list.length) return false

    await location.update({ 'system.elysium.locationConditions': filtered })
    return true
  }

  /**
   * Remove all per-location conditions of a given name across every
   * hit-location on the actor. Useful for "extinguish" effects that
   * clear Burning everywhere.
   */
  static async removeLocationConditionEverywhere (actor, conditionName) {
    let removed = 0
    for (const item of actor?.items || []) {
      if (item.type !== 'hit-location') continue
      const list = item.system?.elysium?.locationConditions || []
      if (!list.some(c => c.name === conditionName)) continue
      const filtered = list.filter(c => c.name !== conditionName)
      await item.update({ 'system.elysium.locationConditions': filtered })
      removed++
    }
    return removed
  }

  /**
   * Aggregate per-location conditions on an actor for display in the
   * conditions panel. Returns a map keyed by condition name with an
   * array of { locationName, amount, source } per occurrence.
   *
   *   {
   *     Bleeding: [{ locationName: 'Right Arm', amount: 1, source: '...' }],
   *     Burning:  [{ locationName: 'Chest',     amount: 2, source: '...' },
   *                { locationName: 'Left Leg',  amount: 2, source: '...' }],
   *   }
   */
  static getLocationConditionsByName (actor) {
    const out = {}
    for (const item of actor?.items || []) {
      if (item.type !== 'hit-location') continue
      const list = item.system?.elysium?.locationConditions || []
      for (const c of list) {
        if (!out[c.name]) out[c.name] = []
        out[c.name].push({
          locationName: item.name,
          locationId:   item.id,
          amount:       c.amount,
          source:       c.source,
        })
      }
    }
    return out
  }

  static _buildChanges (conditionName, def, options) {
    const changes = []

    if (def.skillModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.allSkills',
        mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
        value: String(def.skillModifier),
      })
    }
    if (def.apModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.apPenalty',
        mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
        value: String(Math.abs(def.apModifier)),
      })
    }
    if (def.moveModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.moveModifier',
        mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
        value: String(def.moveModifier),
      })
    }
    if (def.statModifiers) {
      for (const stat in def.statModifiers) {
        changes.push({
          key:   `system.stats.${stat}.effects`,
          mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
          value: String(def.statModifiers[stat]),
        })
      }
    }
    return changes
  }

  /**
   * Remove a condition by name
   */
  static async removeCondition (actor, conditionName) {
    const group = `condition.${conditionName}`
    const ids = actor.effects
      .filter(e => e.flags?.['elysium']?.group === group)
      .map(e => e.id)
    if (ids.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', ids)
    }
  }

  /**
   * Apply a wound penalty (cumulative across all wound sources)
   */
  static async applyWoundPenalty (actor, severity, locationName) {
    let apPenalty = 0
    let skillPenalty = 0

    switch (severity) {
      case 'wounded':           apPenalty = 0; skillPenalty = 0; break
      case 'severelyWounded':   apPenalty = 0; skillPenalty = -20; break
      case 'criticallyWounded': apPenalty = 1; skillPenalty = -40; break
      case 'severed':           apPenalty = 1; skillPenalty = -40; break
    }

    if (apPenalty === 0 && skillPenalty === 0) return null

    const aeData = {
      name: `${locationName} - ${severity}`,
      icon: 'icons/svg/blood.svg',
      changes: [
        { key: 'flags.elysium.modifiers.apPenalty', mode: CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD, value: String(apPenalty) },
        { key: 'flags.elysium.modifiers.allSkills', mode: CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD, value: String(skillPenalty) },
      ],
      flags: {
        'elysium': {
          group:    'wound',
          location: locationName,
          severity: severity,
          stacking: 'cumulative',
        }
      },
      disabled: false,
      transfer: false,
    }

    return await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }
}

// Definitions for all standard conditions
const CONDITION_DEFINITIONS = {
  // Physical
  Staggered: {
    machineName: 'staggered',
    icon: 'icons/svg/daze.svg',
    apModifier: -1,
    duration: { rounds: 1 },
    stacking: 'best',
  },
  Stunned: {
    machineName: 'stunned',
    icon: 'icons/svg/daze.svg',
    skillModifier: -40,
    apModifier: -1,
    duration: { rounds: 1 },
    stacking: 'best',
  },
  Prone: {
    machineName: 'prone',
    icon: 'icons/svg/falling.svg',
    skillModifier: -20,
    moveModifier: -10,
    stacking: 'best',
  },
  Entangled: {
    machineName: 'entangled',
    icon: 'icons/svg/net.svg',
    skillModifier: -20,
    moveModifier: -15,
    stacking: 'best',
  },
  // Rooted — complete movement denial. Distinct from Entangled (partial MOV
  // reduction + combat penalties): Rooted target can still attack, cast,
  // and use AP for non-movement actions, but cannot relocate at all.
  // Distinct from Contained (which is positional containment by a barrier).
  Rooted: {
    machineName: 'rooted',
    icon: 'icons/svg/net.svg',
    moveModifier: -100,
    stacking: 'best',
  },
  Paralysed: {
    machineName: 'paralysed',
    icon: 'icons/svg/paralysis.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },
  Unconscious: {
    machineName: 'unconscious',
    icon: 'icons/svg/sleep.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },
  Dying: {
    machineName: 'dying',
    icon: 'icons/svg/blood.svg',
    apModifier: -99,
    moveModifier: -100,
    ongoing: true,
    stacking: 'best',
  },
  Dead: {
    machineName: 'dead',
    icon: 'icons/svg/skull.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },

  // === PER-LOCATION ONGOING DAMAGE CONDITIONS ===
  // These conditions apply to a specific hit-location item (or a random
  // one for `damageRouting: 'random'`). Their ongoing damage is rolled
  // at end-of-round against the affected location's HP. Multiple
  // locations can carry the same condition independently — Burning
  // on Right Arm and Left Leg are separate, each ticking its own
  // damage to its own location.
  //
  // Stacking on a single location: best-of by amount. Re-applying
  // refreshes duration but keeps the highest amount.
  //
  // The `locationIcon` + `iconColor` are used by the Combat-tab Status
  // column to render an inline glyph next to the wound-tier badge.

  Bleeding: {
    machineName: 'bleeding',
    icon: 'icons/svg/blood.svg',
    locationIcon: 'fas fa-droplet',
    iconColor: '#bb1133',          // deep red
    ongoing: true,
    bleedRate: 1,
    perLocation: true,
    damageRouting: 'self',
    damageType: 'physical',
    stacking: 'best',
  },
  'Arterial Bleeding': {
    machineName: 'arterialBleeding',
    icon: 'icons/svg/blood.svg',
    locationIcon: 'fas fa-droplet',
    iconColor: '#660000',          // darker red — more severe
    ongoing: true,
    bleedRate: 3,
    perLocation: true,
    damageRouting: 'self',
    damageType: 'physical',
    stacking: 'best',
  },

  // Burning — natural fire (torch, campfire, oil flask). Self-extinguishes
  // when removed via combat action or environment change (rolling, water).
  Burning: {
    machineName: 'burning',
    icon: 'icons/svg/fire.svg',
    locationIcon: 'fas fa-fire',
    iconColor: '#cc6600',          // orange — natural flame
    ongoing: true,
    ongoingDamage: { amount: 2, source: 'Burning' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'fire',
    stacking: 'best',
  },

  // Immolation — magical fire / intense heat (red dragon breath, Fireball).
  // Higher per-round damage, harder to extinguish (mechanically same for
  // now; "harder to remove" is a future feature for the Extinguish action).
  Immolation: {
    machineName: 'immolation',
    icon: 'icons/svg/fire.svg',
    locationIcon: 'fas fa-fire',
    iconColor: '#3399ff',          // blue-white — hotter, magical
    ongoing: true,
    ongoingDamage: { amount: 4, source: 'Immolation' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'fire',
    stacking: 'best',
  },

  // Corrosion — acid, ongoing damage. Continues until cleaned/neutralised.
  Corrosion: {
    machineName: 'corrosion',
    icon: 'icons/svg/acid.svg',
    locationIcon: 'fas fa-droplet',
    iconColor: '#88cc44',          // sickly green
    ongoing: true,
    ongoingDamage: { amount: 1, source: 'Corrosion' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'acid',
    stacking: 'best',
  },

  // Decayed — necrotic damage, ongoing.
  Decayed: {
    machineName: 'decayed',
    icon: 'icons/svg/skull.svg',
    locationIcon: 'fas fa-skull',
    iconColor: '#553366',          // dark purple
    ongoing: true,
    ongoingDamage: { amount: 1, source: 'Decayed' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'necrotic',
    stacking: 'best',
  },

  // Shocked — electricity, ongoing damage to the struck location. The
  // older "Shocked" definition (apModifier -99 for stun-style effect)
  // is renamed to Stunned-by-Shock for clarity in v0.6.0.
  Shocked: {
    machineName: 'shocked',
    icon: 'icons/svg/lightning.svg',
    locationIcon: 'fas fa-bolt',
    iconColor: '#ffcc00',          // yellow
    ongoing: true,
    ongoingDamage: { amount: 1, source: 'Shocked' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'electric',
    stacking: 'best',
  },

  // Frostbitten — cold damage, ongoing. (Note: the old definition had
  // skill modifiers; we preserve those by leaving them in changes via
  // _buildChanges — but the per-location ongoing damage is the new
  // primary mechanic.)
  Frostbitten: {
    machineName: 'frostbitten',
    icon: 'icons/svg/frozen.svg',
    locationIcon: 'fas fa-snowflake',
    iconColor: '#66ccff',          // light blue
    ongoing: true,
    ongoingDamage: { amount: 1, source: 'Frostbitten' },
    perLocation: true,
    damageRouting: 'self',
    damageType: 'cold',
    skillModifier: -20,            // legacy — applies if applied actor-level
    stacking: 'best',
  },

  // Poisoned — special damage routing: each round, hits a random hit
  // location rather than the one originally affected. Reflects how
  // many poisons damage the body systemically (toxin in bloodstream).
  // Non-damaging poisons (paralytic, sleep, etc.) should use a
  // different condition; this one is specifically for damage-over-time
  // poisons. perLocation: true means it's stored on a hit-location
  // (so the round-tick walks it), but damageRouting: 'random' means
  // damage hits a different location each round.
  Poisoned: {
    machineName: 'poisoned',
    icon: 'icons/svg/poison.svg',
    locationIcon: 'fas fa-vial',
    iconColor: '#88aa33',          // toxic green-yellow
    ongoing: true,
    ongoingDamage: { amount: 1, source: 'Poisoned' },
    perLocation: true,
    damageRouting: 'random',
    damageType: 'poison',
    stacking: 'best',
  },

  // Withered — v0.19.4: necrotic life-drain that reduces the affected
  // hit-location's maximum HP each round (NOT current HP). This is
  // structural attrition: the muscle/bone/flesh of that location is
  // wasting away. Heals back at 1 HP max/day of rest (or instantly via
  // Vitality cleanse magic). Distinct from Decayed (current-HP damage).
  //
  // Stored alongside other per-location conditions but processed by a
  // separate maxHP-loss pass in combat-extension._applyOngoingDamage.
  //
  // The `ongoingMaxHPLoss` field signals the combat-extension to route
  // ticks as Max HP loss rather than current HP damage. Like other
  // parameterized DOT conditions, the amount can be overridden at
  // application time (Withered 2 = lose 2 max HP per round at that loc).
  Withered: {
    machineName: 'withered',
    icon: 'icons/svg/blood.svg',
    locationIcon: 'fas fa-bone',
    iconColor: '#665544',          // bone/sepia
    ongoing: true,
    ongoingMaxHPLoss: { amount: 1, source: 'Withered' },
    perLocation: true,
    damageRouting: 'self',         // wither happens to the affected location
    damageType: 'necrotic',
    stacking: 'best',
  },

  // === ACTOR-LEVEL CONDITIONS (no per-location semantics) ===

  Frozen: {
    machineName: 'frozen',
    icon: 'icons/svg/frozen.svg',
    moveModifier: -50,
    skillModifier: -20,
    stacking: 'best',
  },
  Suffocating: {
    machineName: 'suffocating',
    icon: 'icons/svg/lungs.svg',
    ongoing: true,
    stacking: 'best',
  },

  // v0.19.4: Chilled — non-DOT cold debuff. Movement halved, -10% rolls.
  // Distinct from Frostbitten (which is per-location DOT) and Frozen
  // (which is heavier movement/skill penalty).
  Chilled: {
    machineName: 'chilled',
    icon: 'icons/svg/frozen.svg',
    skillModifier: -10,
    moveModifier: -50,           // halve via -50%-like proxy
    stacking: 'cumulative',      // Chilled X stacks per application
  },

  // v0.19.4: Contained — positional containment by a barrier or magical
  // boundary. Distinct from Entangled (partial MOV reduction + combat
  // penalties) and Rooted (total movement denial, but free positioning
  // within barrier zone is impossible). Contained target is held in a
  // specific space — cannot voluntarily leave it. Used by Ward's
  // Bind in Place, Void's spatial lock, and similar area-denial abilities.
  Contained: {
    machineName: 'contained',
    icon: 'icons/svg/net.svg',
    moveModifier: -100,
    stacking: 'best',
  },

  // v0.19.4: Stabilized — removes Bleeding and Dying. Functions as a
  // pseudo-condition; the actual removal logic runs on application.
  Stabilized: {
    machineName: 'stabilized',
    icon: 'icons/svg/heal.svg',
    stacking: 'best',
  },

  // v0.19.4: Purged — placeholder for compendium visibility. Application
  // logic is in spell-cast code (removes a chosen harmful condition).
  Purged: {
    machineName: 'purged',
    icon: 'icons/svg/light.svg',
    stacking: 'best',
  },

  // Mental
  Fear: {
    machineName: 'fear',
    icon: 'icons/svg/terror.svg',
    skillModifier: -20,
    stacking: 'best',
  },
  // Terror — compulsion to flee, not just a skill penalty. Target's action
  // economy is biased toward escape: each round the target must spend at
  // least one action attempting to move away from the source of terror,
  // OR pass a Willpower roll to override the compulsion. Cannot voluntarily
  // approach the source. Stronger Fear cousin — distinct mechanically, not
  // just a higher number.
  Terror: {
    machineName: 'terror',
    icon: 'icons/svg/terror.svg',
    skillModifier: -20,            // baseline panic penalty (same as Fear)
    stacking: 'best',
  },
  Charmed: {
    machineName: 'charmed',
    icon: 'icons/svg/heart.svg',
    stacking: 'best',
  },

  // v0.19.4: Awed — similar to Charmed (cannot attack caster) but allows
  // other actions with a Willpower check for any aggressive action toward
  // the caster's allies. Behavioural — no stat modifiers, enforced at
  // action selection time.
  Awed: {
    machineName: 'awed',
    icon: 'icons/svg/aura.svg',
    stacking: 'best',
  },

  // v0.19.4: Confused — chaotic action selection. 1d6 each round determines
  // what the target does. Behavioural — no stat modifiers, enforced at
  // turn-start in the GM's discretion (no automated action override).
  Confused: {
    machineName: 'confused',
    icon: 'icons/svg/daze.svg',
    skillModifier: -10,          // mild penalty to reflect disorientation
    stacking: 'best',
  },

  Dominated: {
    machineName: 'dominated',
    icon: 'icons/svg/eye.svg',
    stacking: 'best',
  },
  Silenced: {
    machineName: 'silenced',
    icon: 'icons/svg/mute.svg',
    stacking: 'best',
  },
  Blinded: {
    machineName: 'blinded',
    icon: 'icons/svg/blind.svg',
    skillModifier: -40,
    stacking: 'best',
  },
  Deafened: {
    machineName: 'deafened',
    icon: 'icons/svg/deaf.svg',
    stacking: 'best',
  },
  Invisible: {
    machineName: 'invisible',
    icon: 'icons/svg/invisible.svg',
    stacking: 'best',
  },

  // === MAGICAL DEBUFFS (v0.19.0+) ===

  // Disrupted — sustained spells end, new sustained casts fail. The
  // sustain-end behaviour is enforced by the casting API at sustain
  // upkeep time; the AE just marks the actor.
  Disrupted: {
    machineName: 'disrupted',
    icon: 'icons/svg/aura.svg',
    skillModifier: -10,          // also impose a generic magic-roll penalty
    stacking: 'best',
  },

  // Doomed — generic skill penalty parameterized by amount.
  // Doomed 1 = -10%, Doomed 2 = -15%, Doomed 3 = -20%, Doomed 4 = -25%.
  // The factory default is -10%; applications can override via the
  // `skillModifier` field at apply time.
  Doomed: {
    machineName: 'doomed',
    icon: 'icons/svg/skull.svg',
    skillModifier: -10,
    stacking: 'cumulative',      // multiple Doom effects stack
  },

  // Cursed — -10% all rolls per stack.
  Cursed: {
    machineName: 'cursed',
    icon: 'icons/svg/circle.svg',
    skillModifier: -10,
    stacking: 'cumulative',
  },

  // Diseased — -10% to Endurance/Brawn/Athletics. We approximate as a
  // generic -10% skill penalty (Mythras doesn't have a clean per-skill
  // AE filter); GMs can apply targeted penalties manually for the three
  // specific skills if desired.
  Diseased: {
    machineName: 'diseased',
    icon: 'icons/svg/sick.svg',
    skillModifier: -10,
    stacking: 'cumulative',
  },

  // Anti-Healed — incoming healing reduced. Enforced by a hook on the
  // heal-application pipeline that reads this AE flag. Code lives at
  // hooks/register-hooks.mjs (healing application path).
  'Anti-Healed': {
    machineName: 'antiHealed',
    icon: 'icons/svg/aura.svg',
    healingReduction: 0.5,       // halves incoming heal (50% reduction)
    stacking: 'best',
  },

  // Marked for Death — next attack against this target by the marker or
  // marker's allies deals +Xd bonus damage. Consumed on hit. Enforced in
  // attack-application pipeline.
  'Marked for Death': {
    machineName: 'markedForDeath',
    icon: 'icons/svg/target.svg',
    stacking: 'best',
  },

  // Warded — cannot voluntarily enter zone/approach target. Behavioural;
  // enforced at GM discretion when target tries to cross threshold.
  Warded: {
    machineName: 'warded',
    icon: 'icons/svg/holy.svg',
    stacking: 'best',
  },

  // Reflected — next attack reflects back on the attacker. Consumed on
  // attack. Enforced in attack-resolution pipeline.
  Reflected: {
    machineName: 'reflected',
    icon: 'icons/svg/mirror.svg',
    stacking: 'best',
  },

  // Resistant — damage reduction; +X% to Resilience saves. The damage
  // reduction is applied in damage-application pipeline.
  Resistant: {
    machineName: 'resistant',
    icon: 'icons/svg/shield.svg',
    damageReduction: 1,           // amount field overrides; default 1 HP/instance
    stacking: 'best',
  },

  // === BENEFICIAL ===

  // Bolstered — Temp HP buffer. Temp HP system exists in v0.5.0+ at
  // actor.system.tempHP — the application code on the cast side
  // increments tempHP.value/max; this AE entry marks the duration.
  Bolstered: {
    machineName: 'bolstered',
    icon: 'icons/svg/aura.svg',
    stacking: 'best',
  },

  // Energized — +1 AP for the cast round. Application is timing-sensitive
  // (only the round the spell is cast); the cast pipeline handles the
  // AP grant. The AE here is for display/duration tracking.
  Energized: {
    machineName: 'energized',
    icon: 'icons/svg/lightning.svg',
    apModifier: 1,
    stacking: 'best',
  },

  Hasted: {
    machineName: 'hasted',
    icon: 'icons/svg/clockwork.svg',
    apModifier: 1,
    moveModifier: 15,
    stacking: 'best',
  },
  Blessed: {
    machineName: 'blessed',
    icon: 'icons/svg/holy.svg',
    skillModifier: 10,
    stacking: 'best',
  },
  Stoneskin: {
    machineName: 'stoneskin',
    icon: 'icons/svg/shield.svg',
    stacking: 'best',
  },
  Regenerating: {
    machineName: 'regenerating',
    icon: 'icons/svg/regen.svg',
    ongoing: true,
    stacking: 'best',
  },
}
