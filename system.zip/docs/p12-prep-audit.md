# P12 prep audit — polish + acceptance

**Status**: PENDING
**Target phase**: P12 (final phase of v1.0.0 rebuild)
**Scope**: Define the complete P12 work scope, sequence it into ship clusters, and decide which items defer to acceptance-testing rather than dedicated ship cycles. P12 is the catch-all phase for everything the v1.0.0 rebuild has accumulated as polish: lang completion, token retokens, legacy CSS retirement, attribute cleanup, inline-HTML callsite migration, and any remaining behavioural fixes surfaced during P7-P11. After P12 ships, v1.0.0-alpha is feature-complete and the next milestone is a v1.0.0 release candidate.
**Inheritance from**: P11 prep audit (decisions c11-13 reserved CSS retirements for P12), cluster-5 audit (deferred `data-handle-change` retirement + lang sweep), cluster-6 audit (1 rgba + 36 px island cleanup + F3-F5 documentation findings), cluster-7 audit (NO-SHIP recommendation routed brace-badge retoken + 27 inline-HTML callsites + combat-tracker visual misalignment as P12 questions), HANDOFF-state.md (`darkred` retoken + orphaning audit + acceptance testing).

The work catalogued here is substantial but mostly mechanical. The hard part is sequencing — many items are small enough that shipping each as its own alpha is wasteful overhead, but batching too aggressively creates large diffs with multiple unrelated failure modes. The recommendation is a small number of themed sub-clusters with explicit boundaries.

---

## 1. Backlog inventory (measured at alpha.50 baseline)

All counts below are LIVE measurements against the alpha.50 work tree, NOT inherited from prior audits. Some numbers diverge from earlier counts; the discrepancies are noted.

### 1.1 Lang parity gap

Measured via flatten + diff of `lang/en.json`, `lang/es.json`, `lang/fr.json`:

| Lang | Total keys | Gap from en |
|---|---|---|
| en | 1260 | — (canonical) |
| es | 1058 | **202** missing |
| fr | 1058 | **202** missing |

(Cluster-5 ship reported gap=206; the gap has shrunk by 4 keys since alpha.49 — likely due to incidental cleanup. Measurement at P12 ship-time will produce the actual final number.)

**Sample missing keys** (es and fr are identical-gap, suggesting one source of drift):
- `Elysium.AP.Label`, `Elysium.AP.ReactionTooltip`, `Elysium.AP.RefreshTooltip`, `Elysium.AP.Tooltip` (Action Point UI strings)
- `Elysium.Ability.Category` (ability sheet)
- (full list ~200 entries spans the Ability, Career, Combat, Magic, NPC, and Status namespaces)

**Work shape**: translation. 202 strings × 2 languages = 404 new entries. Can be done by Claude (machine-translation with the existing translations as style guide) or by the user with human translators — depends on quality bar. The audit doesn't pre-decide this; see Q1.

### 1.2 `data-handle-change` retirement

Measured:
- **14 templates** contain the attribute
- **38 total occurrences**
- **Zero JS consumers** in `module/` (grep across `.mjs` files returns nothing)

Files affected:
- `templates/dialog/difficulty.hbs`
- `templates/dialog/parts/dialog-row.hbs`
- `templates/actor/npcV2.main.hbs`
- 11 item-detail templates (`ability`, `hit-location`, `career.wealth`, `armor`, `gear`, `mysticism`, `skill`, `mutation`, `divine`, `weapon`, `skillcat`)

**Work shape**: pure deletion. Each occurrence is an attribute on a `<select>` or `<input>` element. Remove the attribute, no other change. Risk: zero — V14 ApplicationV2 form-data extraction doesn't read `data-handle-change`.

### 1.3 `darkred` retoken

Three locations:
1. `css/legacy.css:1384` — rule `.elysium .darkred { color: var(--ely-legacy-colour-secondary); }` — currently renders as the legacy secondary color (`rgb(68, 7, 4)` — a deep red), NOT the standard CSS `darkred` (`#8B0000`).
2. `templates/elysiumid/elysiumid-editor.hbs:52` — `<i class="darkred fas fa-exclamation-triangle"></i>` on a warning indicator
3. `templates/elysiumid/elysiumid-editor.hbs:74` — same pattern, second warning location

**Correction to HANDOFF-state.md**: the HANDOFF specified the retoken target as `--ely-text-danger`, but `elysium-tokens.css` does NOT define `--ely-text-danger` — only `--ely-accent-danger` (`#c44040`). The correct retoken target is `--ely-accent-danger` (or `--ely-accent-action` if the existing crimson-on-crimson palette is preferred — the legacy color `rgb(68,7,4)` is deeper than `--ely-accent-danger` and closer to `--ely-accent-action` `#8a2020`).

**Work shape**: 3 retokens. Rule body of `.darkred` becomes `color: var(--ely-accent-danger)` (or option), the class is renamed in templates if we want to deprecate the misleading name, OR the class is kept and only the rule body changes. Decision deferred to Q2.

### 1.4 Island cleanup (cluster-6 deferred findings)

From `docs/p11-cluster6-audit.md`:

| Finding | Count | Location |
|---|---|---|
| Hardcoded rgba | 1 | `styles/elysium.css:~2840` (`.elysium-tier-choice-dialog .tcd-tier-selected .tcd-tier-cost`) |
| Hardcoded px literals (across 4 islands) | 36 | distributed: cast-card 1, csb 9, tcd 5, manipulation 21 |

**Re-verification at alpha.50 baseline**: rgba count confirmed at 1. px count: 36 (matches cluster-6 measurement).

**Work shape**: per-literal review with token mapping. Most px values are spacing (1px-4px borders, 2px-6px gaps), retokens map to `--ely-space-*` scale or `--ely-border-width-*` if a token exists. Some px values are component-layout constants (e.g. `100px` label width in csb) and may stay as literals. Each retoken is mechanical but requires a per-literal judgment.

### 1.5 Brace-badge inline-style retirement (cluster-7 F3)

From `docs/p11-cluster7-audit.md`:

`module/elysium/hooks/render-combat-tracker.mjs:21-23`:
```js
badge.className = 'fas fa-shield elysium-brace-badge'
badge.dataset.tooltip = `${c.name} is bracing — knockback excess halved.`
badge.style.cssText = 'margin-left:6px;color:#0066aa;'
```

- `.elysium-brace-badge` has zero CSS rules anywhere
- Hardcoded `#0066aa` blue not in `elysium-tokens.css`
- Identical anti-pattern to the cluster-3 hitloc-tag retoken

**Work shape**: add 1 CSS rule, remove 1 JS line. Lock `.elysium-brace-badge` against rename (already a JS hook). Optional: live-verify the `--ely-accent-info` (`#5a7aa0`) retoken against the brace-badge visual against the tracker default background.

### 1.6 Inline-HTML ChatMessage.create migration

**Measured precisely at alpha.50**: **44 inline-HTML callsites across 19 files**. Cluster-7 audit reported 27 — that number was a sub-directory filter. The full count was always larger. Distribution:

| Count | File |
|---|---|
| 6 | `module/elysium/mechanics/charge-ui.mjs` |
| 4 | `module/casting/sustain.mjs` |
| 3 | `module/elysium/hooks/item.mjs` |
| 3 | `module/elysium/actor/stat-improvement.mjs` |
| 3 | `module/elysium/mechanics/engagement-ui.mjs` |
| 3 | `module/elysium/mechanics/outmanoeuvre.mjs` |
| 3 | `module/elysium/mechanics/covering-stance.mjs` |
| 3 | `module/casting/sorcery-cast.mjs` |
| 2 | `module/elysium/magic/magic.mjs` |
| 2 | `module/elysium/fatigue/fatigue-manager.mjs` |
| 2 | `module/elysium/creation/creation.mjs` |
| 2 | `module/elysium/critical/critical-roller.mjs` |
| 2 | `module/elysium/sheets/actor/combat-tab.mjs` |
| 1 (×6 files) | `combat-extension`, `chat-card`, `weapon-wear`, `armor-wear`, `spell-learning`, `divine-cast` |
| **Total** | **44 callsites** |

**Work shape per callsite**: each `ChatMessage.create({content: '<div style="...">'})` callsite must be:
1. Replaced with a Handlebars template (likely a new partial per archetype)
2. Inline styles retoken to v1.0.0 tokens via the chat-card-shell or a callsite-specific partial
3. Rendered via `renderTemplate('systems/elysium/templates/chat/parts/X.hbs', ctx)`

This is **the largest single P12 item by absolute work**. Estimated 3-5 new partials covering common archetypes (charge prompt, fatigue notice, critical-result card, sustain-drop notice, learning-roll card), then 44 callsite rewrites averaging ~10-30 LOC each.

**Compare to P11 cluster sizes**: cluster 5 was 10 dialogs onto 1 partial; this is 44 callsites onto ~5 partials. Substantially larger.

### 1.7 Legacy CSS orphaning sweep

Measured at alpha.50 baseline against `css/legacy.css`:

| Metric | Value |
|---|---|
| Total LOC | 1626 |
| Total rule blocks | 220 |
| `.elysium`-prefixed rules | 194 |
| Distinct classes referenced in selectors | 184 |

Preliminary orphan analysis (consumer count = 0 across templates + module JS + non-legacy CSS):

| Category | Count |
|---|---|
| **True orphans** (0 consumers anywhere) | **65** (35% of all classes) |
| Low-use (1-2 consumers) | 40 |
| Active (3+ consumers) | 79 |

**Verification**: a 24-item spot-check of the orphan list confirmed 23/24 are TRULY orphan (one false positive: `itemIcon` had 1 stray template ref). The 35% orphan rate is real.

**Work shape**: each orphan rule is a candidate for deletion. Per-rule confirmation: re-grep the class name across templates + module + other CSS, confirm zero consumers, delete the rule. ~65 rules × 1 LOC each = ~65 LOC of legacy.css shrinkage. Some rules may be multi-selector groups — when the orphan class is one of N selectors in a group, just remove that selector and keep the rest.

**Implication for legacy.css total size**: a full orphan sweep would shrink legacy.css from 1626 → ~1450-1500 LOC (~10-12% reduction). Plus the cluster-4 and cluster-5 retirements already shipped, plus low-use rules that may also retire after closer inspection. Aggressive estimate: legacy.css ends P12 at ~1200-1300 LOC, down from the alpha.45 baseline of ~1720.

### 1.8 Behavioural acceptance testing

Not a code deliverable. The P7-P11 rebuild touched every actor sheet, every item sheet, every chat card, every dialog. Each touched surface has had pre-flight smoke fixture rendering, but live behavioral acceptance — actually using the system in an end-to-end game session — has been deferred.

**Work shape**: spot-test exercises across the test world covering:
- All 8 actor sheet types: create, edit fields, navigate tabs, attach items, take damage, level up
- All 23 item sheet types: create, edit, drag/drop where applicable
- All 15 chat-card types: trigger an action that produces each card type; verify Phase D injection on combat cards
- All 10 dialogs: trigger each dialog from its caller; verify form submission
- Combat flow: start combat, roll initiative, take turns, apply damage, end combat
- Casting flow: cast a spell, sustain, drop, learn
- Special features: outmanoeuvre, engagement, charge, brace

**Per surface**: minutes of testing, not hours. The aggregate is meaningful but each item is small. Bugs surfaced here become hotfixes during or after P12.

### 1.9 Cluster-7 deferred decision: combat-tracker visual misalignment (F1)

The cluster-7 audit reached Option B (brace-badge retoken only, full restyle deferred). The deferred Option C/D work — token-driving the combat tracker for v1.0.0 visual identity — remains an open question for P12. Two paths:

1. **P12 sub-cluster for combat-tracker restyle**: same Option C/D work, just done as part of P12 polish rather than as cluster 7
2. **Acceptance defer**: accept that the combat tracker stays on Foundry V14 default styling for v1.0.0. Note as a v1.1.0 candidate item.

Decision deferred to Q3.

---

## 2. Sub-cluster sequencing options

The 9 backlog items above split into mechanical (1.2, 1.3, 1.4, 1.5, 1.7) and substantive (1.1, 1.6, 1.8, 1.9). Sub-clustering options:

### Option A — Single omnibus P12 ship

All items in one alpha. Cost: large diff, many independent failure modes. Pre-flight sweep covers everything but the smoke matrix is huge.

**Rejected.** Conflicts with audit-then-stop discipline at the cluster level — too many unrelated decisions in one ship for individual decisions to get the attention they need.

### Option B — Three-cluster split

- **P12-c1 (alpha.51)**: Mechanical CSS + attribute cleanup
  - 1.2 `data-handle-change` retirement (14 templates)
  - 1.3 `darkred` retoken (3 sites)
  - 1.4 Island cleanup (1 rgba + 36 px)
  - 1.5 Brace-badge inline-style retirement
  - 1.7 Legacy CSS orphaning sweep (65 orphans)
  - Smoke: re-render every touched template, brace-badge visual check
  - Net diff: substantial but mechanical — all changes are token retokens, attribute removals, or rule deletions

- **P12-c2 (alpha.52)**: Inline-HTML ChatMessage.create migration
  - 1.6 — 44 callsites onto ~5 new partials
  - Most substantive code work
  - Smoke: fire every chat-emission code path
  - Net diff: medium template + JS rewrite, contained scope

- **P12-c3 (alpha.53)**: Lang completion + acceptance
  - 1.1 Lang sweep (202 keys × 2 langs)
  - 1.8 Behavioural acceptance testing
  - 1.9 (deferred) Combat-tracker decision applied if SHIP-track
  - Smoke: full-system end-to-end exercise
  - Net diff: large JSON additions + any bugs surfaced during acceptance

**Pros**: clean themed split; each cluster ships independently; failure of one doesn't block the others.
**Cons**: 3 ship cycles before v1.0.0 is feature-complete.

### Option C — Two-cluster split

Merge P12-c1 + P12-c2 into one larger ship; P12-c3 stays separate.

**Pros**: 2 ships instead of 3.
**Cons**: P12-c1's pre-flight sweep is already substantial; adding 44 ChatMessage rewrites doubles the smoke matrix. The two clusters address different problem domains (CSS/attribute cleanup vs JS callsite rewriting) so combining them obscures what each ship is for.

**Rejected** in favor of Option B.

### Option D — Four-cluster split

Split P12-c1 further into c1a (mechanical CSS retoken / attribute cleanup) and c1b (legacy CSS orphaning sweep) because the orphaning sweep is large enough on its own (~65 rules) to merit a dedicated ship.

**Pros**: even tighter per-ship scope.
**Cons**: legacy CSS retirement is single-rule-low-risk-each; 65 small retirements don't need to ship separately from 36 px retokens.

**Marginal** vs Option B; recommended as a fallback if c1's smoke matrix turns out larger than expected.

---

## 3. Decisions (lockable now)

### D1 — Sub-cluster split: Option B (three clusters)

Recommended. Themed splits (cleanup / migration / completion+acceptance) match the audit-then-stop pattern best.

### D2 — `darkred` retoken target

Retoken to `--ely-accent-danger` (the existing `#c44040` token). Reasoning: the legacy color `rgb(68,7,4)` is a deeper red; `--ely-accent-danger` is the closest v1.0.0 semantic equivalent for "warning/danger color." The legacy `rgb(189,38,30)` variant at `css/legacy.css:77` is closer to `--ely-accent-action` (`#8a2020`), but the rule context (`elysiumid-editor.hbs` warning triangles) is semantically danger, not action.

**Class rename or class-body retoken?**
- Recommended: keep the `.darkred` class name in template + rule, retoken only the rule body. Reasoning: changing the class name in 2 templates is template-surface churn for no functional benefit; the `.darkred` class IS the design intent (a danger-tinted icon), the class name just happens to be a literal-color name from BRP era. Note in comment that the class name is historical.

### D3 — Lang completion approach

Defer to ship-time. Two viable approaches:
1. Machine-translate using existing translations as style guide. Fast (~30 min Claude-time for 404 keys), but quality varies — may need human review for context-sensitive strings.
2. Stub out missing keys with English values, mark for human-translator follow-up. Preserves quality bar at cost of speed.

Decision: deferred to P12-c3 audit. The audit should propose a hybrid: machine-translate the obviously-mechanical keys (button labels, tooltips, short labels) and stub the prose strings (long descriptive sentences) for human review.

### D4 — Brace-badge retoken color

Recommended target: `--ely-accent-info` (`#5a7aa0`). The legacy `#0066aa` is a saturated medium blue used to convey "defensive bracing" status. `--ely-accent-info` is the v1.0.0 semantic match for informational-status color. If live-verify shows insufficient contrast against the tracker background, the fallback is `--ely-text-link` (`#d4a040` — the bonus-gold link color, less semantically aligned but more visible). Final decision goes through Q4-style verification at ship time.

### D5 — Combat-tracker visual misalignment (cluster-7 F1)

Recommended: **acceptance defer** (not a P12 sub-cluster). Reasoning:
- The cluster-7 audit Option C/D estimate was 250-350 LOC of new CSS plus template restructuring — larger than any individual P11 cluster
- v1.0.0 is targeting feature-complete + acceptance, not aesthetic-complete
- The combat-tracker remains functionally correct; visual identity gap is real but not blocking
- Note as a v1.1.0 candidate, optionally as cluster 7's Option D split

If the user prefers it land in P12: add P12-c4 (or fold into c2's larger ship if appetite for one more ship cycle).

### D6 — Legacy CSS sweep scope (65 orphans + 40 low-use)

Recommended: **retire only the 65 true orphans in P12-c1**. The 40 low-use rules deserve per-rule review BEFORE retirement — some are intentional shared utilities (`italics`, `boxed`, `fade`, `indent`) that should be kept as design-system utilities; others are vestigial. Per-rule review is more work than 65 mechanical deletions. Defer the low-use review to a separate cleanup pass or to v1.1.0.

---

## 4. Open questions

### Q1 (blocking c1) — Final decision on `data-handle-change` retirement

Confirmed zero JS consumers across 38 occurrences in 14 templates. Risk of removal: zero. Any reason to keep?

**Recommendation**: retire. No reason to keep an attribute with zero consumers.

### Q2 (blocking c1) — `darkred` class name fate

Per D2 recommendation, retoken the rule body but keep the class name. Confirm.

### Q3 (blocking c1 sequencing) — Cluster-7 F1 (combat-tracker visual misalignment) decision

Per D5 recommendation: acceptance-defer to v1.1.0. Alternative: add as P12-c4 (after c3 acceptance testing surfaces specific pain points), or fold Option D's staged ship into c1+c2 split points.

### Q4 (blocking c2) — ChatMessage.create migration partial design

The 44 callsites span ≥5 different message archetypes:
- Status notices (sustain drop, fatigue tick, weapon/armor wear)
- Action prompts (charge prompt, change-range prompt, outmanoeuvre prompt)
- Action results (charge resolved, fatigue applied, critical roller)
- Roll cards (sustain upkeep roll, spell-learning roll, sorcery cost)
- Multi-button interactive cards (engagement targeting, knockback resolution)

Sub-audit at c2 ship time should propose 4-6 partials (one per archetype) with explicit context contracts. The partials should compose cluster-1 shell + reuse `chat-card-actor-list` + `dialog-row` where possible to avoid net-new partial-vocabulary growth.

### Q5 (blocking c2) — `data-card-type` codes for new archetypes

The chat-card vocabulary uses 2-letter codes (CB/OP/GR/CO/NO/RE/PP/CM/IM/DM/AR/QC/XP/RS/ID). Adding ~5 new archetypes adds ~5 new codes. Section D accent rules need to be populated for each. Proposed:
- ST (status notice) — `--ely-text-muted` accent
- AP (action prompt) — `--ely-accent-action` accent (matches CB family)
- AR is already taken (armor) — RE-resolution result could be RR
- LR (learning roll) — `--ely-accent-bonus` (gold)
- SU (sustain upkeep) — `--ely-accent-mind` (purple, matches casting family)

Final code assignment in c2 sub-audit.

### Q6 (blocking c3) — Lang translation methodology

Per D3: hybrid (machine-translate mechanical + stub prose for human review). Approve or override?

### Q7 (non-blocking) — Acceptance test pass/fail criteria

How structured should the c3 acceptance testing be? Options:
1. **Ad-hoc**: user exercises the system in normal play, files bugs as found, P12-c3 ships when bug count is acceptable
2. **Checklist-driven**: explicit per-surface checklist (open sheet / edit field / submit / verify chat output), ship when checklist clears
3. **Test-script-driven**: write a console-runnable test script that exercises each surface programmatically; ship when script passes

**Recommendation**: option 2 (checklist-driven). Option 1 is too open-ended for a release gate; option 3 is overkill for a single-user system and most surfaces are visual.

### Q8 (non-blocking) — Version after P12

Conventional pre-release versioning would jump alpha.53 → 1.0.0-rc.1 → 1.0.0. Confirm intent.

### Q9 (non-blocking) — What about cluster 7's other findings (F2, F4, F5, F6, F7)?

F2 (`.application.elysium` scope reach) is informational — no work item.
F4 (Foundry API contract immutability) is informational — no work item.
F5 (context menu independence) is informational — no work item.
F6 (zero i18n keys to add) is informational — no work item.
F7 (token-effect icon sizing) is part of the combat-tracker restyle decision (D5) — folds in if F1 ships.

No new P12 items from these.

### Q10 (non-blocking) — `system.json` `styles` array audit

Cluster 1 added `elysium-chat.css` to the styles array. Cluster 7 audit Q2 proposed `elysium-tracker.css` if the tracker restyle ships. P12-c1's island cleanup doesn't add files. P12-c2's ChatMessage.create migration may add a new combined file `elysium-mechanics-chat.css` for the new partials' rules. Decision deferred to c2 sub-audit.

---

## 5. Recommendation

**Sub-cluster sequence: Option B (three clusters)**

| Cluster | Alpha | Scope | LOC estimate |
|---|---|---|---|
| P12-c1 | alpha.51 | mechanical CSS + attribute cleanup (items 1.2, 1.3, 1.4, 1.5, 1.7) | ~250 LOC net (mostly retirements: legacy.css -65, templates -38, plus new CSS +5 brace-badge) |
| P12-c2 | alpha.52 | inline-HTML ChatMessage.create migration (item 1.6) | ~400-600 LOC across new partials + 44 callsite rewrites + new CSS rules |
| P12-c3 | alpha.53 | lang completion + acceptance testing + hotfixes (items 1.1, 1.8 + any bugs from acceptance) | ~400 JSON entries + bugfixes |

After P12-c3 ships and acceptance clears, v1.0.0 is feature-complete. Next milestone is RC versioning.

**Combat-tracker visual misalignment**: deferred to v1.1.0 (D5 recommendation). Brace-badge retoken (small subset of cluster-7 work) still rides along in P12-c1 to close the inline-style anti-pattern.

**Per-cluster audit requirement**: each P12 cluster gets its own prep audit at `docs/p12-c1-audit.md` etc. before its ship per project rule 2. THIS audit (`docs/p12-prep-audit.md`) scopes the phase; per-cluster audits scope the ship.

---

## 6. P12 completion criteria

P12 is complete when ALL of:

- [ ] `data-handle-change` attribute returns 0 occurrences across templates
- [ ] `darkred` rule body uses semantic token (not `--ely-legacy-*`)
- [ ] `styles/elysium.css` rgba count = 0 for island blocks
- [ ] `styles/elysium.css` island px literals retokenned (or explicitly justified as layout constants)
- [ ] `render-combat-tracker.mjs` brace-badge: zero inline-style, uses `.elysium-brace-badge` CSS rule
- [ ] `module/` inline-HTML `ChatMessage.create` count = 0 (or explicit exceptions documented)
- [ ] `css/legacy.css` shrunk by ≥60 lines from orphan retirement
- [ ] `lang/es.json` and `lang/fr.json` reach parity with `lang/en.json` (gap = 0)
- [ ] Behavioural acceptance checklist complete (per Q7)
- [ ] No regression bugs open against P7-P11 surfaces

Per-criterion verification in P12-c3 ship.

---

## 7. P12 lock list additions

Following the audit-5 hook-lock pattern, P12 work introduces:

- `.elysium-brace-badge` — JS-imperative (double-injection guard at `render-combat-tracker.mjs:18`). **LOCK after c1 ship.**
- (P12-c2) new chat-card archetype 2-letter codes (per Q5 — final list at c2 sub-audit). These are template-imperative (`data-card-type` selector hooks for Section D accents). LOCK after c2 ship.

No locks dropped in P12 (cluster-5 audit-5 hooks remain locked; cluster-3 hitloc + cluster-2 mount-point selectors remain locked; cluster-7's combat-tracker Foundry API contract remains immutable).

---

## 8. Cross-references

- `docs/p11-prep-audit.md`: decisions c11-13 reserved CSS retirements for P12
- `docs/p11-cluster5-audit.md`: deferred `data-handle-change`, lang sweep
- `docs/p11-cluster6-audit.md`: island cleanup findings (F1 rgba + F2 px)
- `docs/p11-cluster7-audit.md`: Option B recommendation + F3 brace-badge route to P12 + F1 deferred
- `ROADMAP-v1.0.0.md`: P12 phase row currently reads "not started"; updates on c1 ship
- `HANDOFF-state.md`: P12 backlog enumeration matches this audit modulo measurement updates

---

## 9. Pre-decision checklist

Before responding `proceed with recommended`:

- [ ] Confirm Option B sub-cluster split (3 alphas: c1 cleanup, c2 ChatMessage migration, c3 lang+acceptance)
- [ ] Confirm D5: combat-tracker visual misalignment deferred to v1.1.0 (NOT P12)
- [ ] Confirm D6: 65 orphan retirements in c1, 40 low-use rules deferred to per-rule review
- [ ] Accept that c2 is the largest single P12 item (44 callsites + ~5 new partials) — appropriate to ship on its own
- [ ] Q1 (data-handle-change retire), Q2 (darkred class kept), Q6 (hybrid lang translation) all default-accept under "proceed with recommended"

If any of these need overriding, name the override: e.g. `proceed with C` (Option C two-cluster), `proceed with combat-tracker in P12`, etc.
