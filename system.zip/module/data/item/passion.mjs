/**
 * PassionDataModel — schema for items of type 'passion'.
 *
 * Per P6.2 spec (docs/p6-2-handoff.md). Stored-schema-only.
 * Compendium content: passions.db is empty (0 items). Schema matches
 * template.json exactly.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class PassionDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      base:    new fields.NumberField({ integer: true, initial: 0 }),
      improve: new fields.BooleanField({ initial: false }),
      xp:      new fields.NumberField({ integer: true, initial: 0 }),
      elysium: new fields.SchemaField({
        isSpecialism:    new fields.BooleanField({ initial: false }),
        parentName:      new fields.StringField({ initial: '' }),
        specialismName:  new fields.StringField({ initial: '' }),
        category:        new fields.StringField({ initial: 'general' }),
      }),
    }
  }
}
