// =====================================================================
// ELYSIUM | Engagement UI
// =====================================================================
//
// Adds context-menu items to the Combat Tracker so the GM can establish
// or break engagements between combatants. Wires up small dialogs for:
//
//   - Engage with…           (pick opponent + weapon → mutual engagement)
//   - Disengage from…        (pick existing engagement to break)
//
// Engagement state is multi-opponent: a combatant can have N engagements
// simultaneously. See mechanics/engagement.mjs for the schema and helper
// functions.
// =====================================================================

import { getEngagements, getEngagementWith } from '../mechanics/engagement.mjs'
import { ELYSIUM } from '../config/config.mjs'
/**
 * Patch CombatTracker._getEntryContextOptions to inject our menu items.
 *
 * V14 doesn't fire a public hook for combat-tracker entry context menus
 * (the hook the V11 docs mention — `getCombatTrackerEntryContext` — was
 * dropped in the AppV2 rewrite). Instead we wrap the protected method
 * to append our entries after the core ones.
 *
 * Called once during module init.
 */
export function patchCombatTrackerContextMenu () {
  const TrackerCls = foundry.applications?.sidebar?.tabs?.CombatTracker
  if (!TrackerCls?.prototype?._getEntryContextOptions) {
    console.warn('Elysium | CombatTracker._getEntryContextOptions not found — engagement context menu disabled')
    return
  }

  const original = TrackerCls.prototype._getEntryContextOptions
  TrackerCls.prototype._getEntryContextOptions = function () {
    const options = original.call(this) || []
    registerEngagementContextMenu(this.element, options)
    // Charge / Brace / Knockback entries from the charge module
    const chargeUI = game.system.api?.elysium?.charge
    if (chargeUI?.registerContextMenu) {
      chargeUI.registerContextMenu(this.element, options)
    }
    // Outmanoeuvre entry — eligible when combatant is engaged with ≥2
    // distinct opponents. The mechanics live in mechanics/outmanoeuvre.mjs.
    const outmanoeuvre = game.system.api?.elysium?.outmanoeuvre
    if (outmanoeuvre?.registerContextMenu) {
      outmanoeuvre.registerContextMenu(this.element, options)
    }
    return options
  }
  console.log('Elysium | Patched CombatTracker._getEntryContextOptions for engagement menu')
}

/**
 * Append engagement entries to a combatant context-menu options array.
 * Mutates `options` in place. Called from the patched method above —
 * also used internally for testability.
 *
 * In V14 the callback receives the context target as either an
 * HTMLElement or a jQuery collection (depends on the call path). The
 * helper below normalises to the underlying element so dataset access
 * works either way.
 */
export function registerEngagementContextMenu (html, options) {
  // Normalise jQuery → HTMLElement for dataset access
  const elOf = (li) => (li?.[0] instanceof Element ? li[0] : li)

  options.push(
    {
      name: 'Elysium: Engage with…',
      icon: '<i class="fas fa-crossed-swords"></i>',
      condition: (li) => {
        const combat = game.combat
        if (!combat) return false
        return combat.combatants.size > 1
      },
      callback: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (combatant) openEngageDialog(combatant)
      },
    },
    {
      name: 'Elysium: Change Range…',
      icon: '<i class="fas fa-arrows-left-right"></i>',
      condition: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        return getEngagements(combatant).length > 0
      },
      callback: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (!combatant) return
        // If only one engagement, jump straight to the dialog. Otherwise
        // pick which engagement first.
        const list = getEngagements(combatant)
        if (list.length === 1) {
          openChangeRangeDialog(combatant, list[0].withId)
        } else {
          pickEngagementThenChangeRange(combatant, list)
        }
      },
    },
    {
      name: 'Elysium: Disengage from…',
      icon: '<i class="fas fa-shield-halved"></i>',
      condition: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        return getEngagements(combatant).length > 0
      },
      callback: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (combatant) openDisengageDialog(combatant)
      },
    },
  )
}

/**
 * When a combatant has multiple engagements, prompt the user to pick
 * which opponent to Change Range against, then open the change-range
 * dialog against that opponent.
 */
async function pickEngagementThenChangeRange (combatant, engagements) {
  const reachLabels = ELYSIUM.WEAPON_REACHES || {}
  const opts = engagements.map(eng => {
    const opp = game.combat?.combatants.get(eng.withId)
    return `<option value="${eng.withId}">vs ${opp?.name || '?'} @ ${reachLabels[eng.reach] || eng.reach}</option>`
  }).join('')

  const content = `
    <form>
      <div class="form-group">
        <label>Opponent</label>
        <select name="withId">${opts}</select>
      </div>
    </form>
  `
  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Change Range — ${combatant.name}` },
    content,
    ok: {
      label: 'Continue',
      callback: (event, button) => ({
        withId: button.form.querySelector('[name="withId"]').value,
      }),
    },
  }).catch(() => null)
  if (result?.withId) await openChangeRangeDialog(combatant, result.withId)
}

/**
 * Show the "Engage with…" dialog. Lets the GM pick an opponent combatant
 * and a wielded weapon, then writes mutual engagement records on both
 * combatants. Default reach = the longer of the two weapons' reaches.
 */
async function openEngageDialog (combatant) {
  const combat = game.combat
  if (!combat) return

  // Build opponent list (everyone except self, and not already engaged)
  const existing = getEngagements(combatant).map(e => e.withId)
  const opponents = combat.combatants
    .filter(c => c.id !== combatant.id && !existing.includes(c.id))
    .map(c => ({
      id: c.id,
      name: c.name,
      weapons: c.actor?.items.filter(i =>
        i.type === 'weapon' && i.system?.equipStatus === 'equipped'
      ) || [],
    }))

  if (opponents.length === 0) {
    ui.notifications?.warn('No available opponents to engage.')
    return
  }

  // Build weapon list from this combatant's actor (equipped weapons only)
  const myActor = combatant.actor
  const myWeapons = myActor?.items.filter(i =>
    i.type === 'weapon' && i.system?.equipStatus === 'equipped'
  ) || []

  if (myWeapons.length === 0) {
    ui.notifications?.warn(`${combatant.name} has no equipped weapons.`)
    return
  }

  const oppOpts = opponents.map(o =>
    `<option value="${o.id}">${o.name}</option>`
  ).join('')
  const wpnOpts = myWeapons.map(w => {
    const reach = w.system?.elysium?.reach || 'M'
    const reachLabel = (ELYSIUM.WEAPON_REACHES || {})[reach] || reach
    return `<option value="${w.id}">${w.name} (Reach ${reachLabel})</option>`
  }).join('')
  const reachOpts = Object.entries(ELYSIUM.WEAPON_REACHES || {}).map(([k, label]) =>
    `<option value="${k}">${label}</option>`
  ).join('')

  // Default opponent weapon = first equipped on default opponent. We
  // re-render the opponent-weapon select via a tiny inline script when
  // the opponent dropdown changes.
  const defaultOpponent = opponents[0]
  const defaultOppWeapons = defaultOpponent.weapons
  const defaultOppWpnOpts = defaultOppWeapons.length === 0
    ? '<option value="">— No equipped weapons —</option>'
    : defaultOppWeapons.map(w => {
        const reach = w.system?.elysium?.reach || 'M'
        const reachLabel = (ELYSIUM.WEAPON_REACHES || {})[reach] || reach
        return `<option value="${w.id}">${w.name} (Reach ${reachLabel})</option>`
      }).join('')

  // Embed opponent-weapon mapping as JSON for the inline script
  const oppWeaponMap = {}
  for (const o of opponents) {
    oppWeaponMap[o.id] = o.weapons.map(w => ({
      id: w.id,
      name: w.name,
      reach: w.system?.elysium?.reach || 'M',
    }))
  }
  const reachLabelMap = ELYSIUM.WEAPON_REACHES || {}

  const content = `
    <form>
      <div class="form-group">
        <label>Opponent</label>
        <select name="opponentId" data-elysium-opp-select>${oppOpts}</select>
      </div>
      <div class="form-group">
        <label>Your Weapon</label>
        <select name="weaponId">${wpnOpts}</select>
      </div>
      <div class="form-group">
        <label data-tooltip="Which weapon the opponent is wielding against you. Determines their effective Size if encroachment applies.">
          Opponent's Weapon
        </label>
        <select name="opponentWeaponId" data-elysium-opp-wpn>${defaultOppWpnOpts}</select>
      </div>
      <div class="form-group">
        <label data-tooltip="Default: longer of both weapons' reach. Override here if both combatants agree to engage at a different distance.">
          Engagement Reach
        </label>
        <select name="reach">
          <option value="">— Auto (longer weapon's reach) —</option>
          ${reachOpts}
        </select>
      </div>
      <script type="application/json" data-elysium-opp-map>${JSON.stringify(oppWeaponMap)}</script>
      <script type="application/json" data-elysium-reach-labels>${JSON.stringify(reachLabelMap)}</script>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Engage — ${combatant.name}` },
    content,
    render: (event, dialog) => {
      // When opponent changes, re-render the opponent-weapon select
      const oppSelect = dialog.element.querySelector('[data-elysium-opp-select]')
      const wpnSelect = dialog.element.querySelector('[data-elysium-opp-wpn]')
      const mapEl     = dialog.element.querySelector('[data-elysium-opp-map]')
      const labelsEl  = dialog.element.querySelector('[data-elysium-reach-labels]')
      if (!oppSelect || !wpnSelect || !mapEl) return
      const map    = JSON.parse(mapEl.textContent || '{}')
      const labels = JSON.parse(labelsEl?.textContent || '{}')
      oppSelect.addEventListener('change', () => {
        const oppId = oppSelect.value
        const list  = map[oppId] || []
        wpnSelect.innerHTML = list.length === 0
          ? '<option value="">— No equipped weapons —</option>'
          : list.map(w => {
              const lbl = labels[w.reach] || w.reach
              return `<option value="${w.id}">${w.name} (Reach ${lbl})</option>`
            }).join('')
      })
    },
    ok: {
      label: 'Engage',
      callback: (event, button) => {
        const form = button.form
        return {
          opponentId:       form.querySelector('[name="opponentId"]').value,
          weaponId:         form.querySelector('[name="weaponId"]').value,
          opponentWeaponId: form.querySelector('[name="opponentWeaponId"]').value,
          reach:            form.querySelector('[name="reach"]').value,
        }
      },
    },
  }).catch(() => null)

  if (!result?.opponentId || !result?.weaponId) return

  await establishEngagement(
    combatant,
    result.opponentId,
    result.weaponId,
    result.reach,
    result.opponentWeaponId,
  )
}

/**
 * Disengage dialog — pick one of the existing engagements and break it.
 * Removes the record on both sides.
 */
async function openDisengageDialog (combatant) {
  const combat = game.combat
  if (!combat) return

  const list = getEngagements(combatant)
  if (list.length === 0) return

  const items = list.map(eng => {
    const opp = combat.combatants.get(eng.withId)
    const oppName = opp?.name || '(missing)'
    const reach = (ELYSIUM.WEAPON_REACHES || {})[eng.reach] || eng.reach
    return `<option value="${eng.withId}">vs ${oppName} @ ${reach}</option>`
  }).join('')

  const content = `
    <form>
      <div class="form-group">
        <label>Engagement to break</label>
        <select name="withId">${items}</select>
      </div>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Disengage — ${combatant.name}` },
    content,
    ok: {
      label: 'Disengage',
      callback: (event, button) => {
        const form = button.form
        return { withId: form.querySelector('[name="withId"]').value }
      },
    },
  }).catch(() => null)

  if (!result?.withId) return

  await breakEngagement(combatant, result.withId)
}

/**
 * Write mutual engagement records on both combatants.
 *
 * @param {Combatant} a            initiating combatant
 * @param {string}    opponentId   target combatant id
 * @param {string}    weaponId     A's wielded weapon
 * @param {string}    overrideReach    optional engagement reach (else auto)
 * @param {string}    opponentWeaponId optional opponent weapon (else auto-pick first equipped)
 */
async function establishEngagement (a, opponentId, weaponId, overrideReach, opponentWeaponId) {
  const combat = game.combat
  const b = combat?.combatants.get(opponentId)
  if (!b) return

  // A's wielded weapon's reach
  const aWeapon = a.actor?.items.get(weaponId)
  const aReach  = aWeapon?.system?.elysium?.reach || 'M'

  // B's weapon — explicit if provided, else first equipped
  let bWeapon = opponentWeaponId
    ? b.actor?.items.get(opponentWeaponId)
    : null
  if (!bWeapon) {
    bWeapon = b.actor?.items.find(i =>
      i.type === 'weapon' && i.system?.equipStatus === 'equipped'
    )
  }
  const bReach = bWeapon?.system?.elysium?.reach || 'M'

  // Determine engagement reach: longer of the two by default
  let engagementReach = overrideReach
  if (!engagementReach) {
    const order = ELYSIUM.WEAPON_REACH_ORDER || ['T', 'S', 'M', 'L', 'VL', 'H']
    const aIdx = order.indexOf(aReach)
    const bIdx = order.indexOf(bReach)
    engagementReach = aIdx > bIdx ? aReach : bReach
  }

  // A's engagement record
  const aList = [...getEngagements(a)].filter(e => e.withId !== opponentId)
  aList.push({ withId: opponentId, reach: engagementReach, weaponId })

  // B's engagement record
  const bList = [...getEngagements(b)].filter(e => e.withId !== a.id)
  bList.push({
    withId: a.id,
    reach:  engagementReach,
    weaponId: bWeapon?.id || '',
  })

  await a.update({ 'flags.elysium.engagements': aList })
  await b.update({ 'flags.elysium.engagements': bList })

  ui.notifications?.info(`${a.name} and ${b.name} are engaged at ${engagementReach}.`)

  // Re-render any open weapon sheets so the engagement display updates
  for (const actor of [a.actor, b.actor]) {
    if (!actor) continue
    for (const item of actor.items) {
      if (item.type === 'weapon' && item.sheet?.rendered) {
        item.sheet.render(false)
      }
    }
    if (actor.sheet?.rendered) actor.sheet.render(false)
  }
}

/**
 * Break engagement between two combatants — removes records on both sides.
 */
async function breakEngagement (a, opponentId) {
  const combat = game.combat
  const b = combat?.combatants.get(opponentId)

  const aList = getEngagements(a).filter(e => e.withId !== opponentId)
  await a.update({ 'flags.elysium.engagements': aList })

  if (b) {
    const bList = getEngagements(b).filter(e => e.withId !== a.id)
    await b.update({ 'flags.elysium.engagements': bList })
  }

  ui.notifications?.info(`${a.name} disengaged from ${b?.name || '(unknown)'}.`)

  // Re-render weapon sheets
  for (const actor of [a.actor, b?.actor]) {
    if (!actor) continue
    for (const item of actor.items) {
      if (item.type === 'weapon' && item.sheet?.rendered) {
        item.sheet.render(false)
      }
    }
    if (actor.sheet?.rendered) actor.sheet.render(false)
  }
}

// =====================================================================
// CHANGE RANGE ACTION (Mythras p103)
// =====================================================================
//
// Costs 1 AP. The initiator declares a target reach. The opponent has
// three options:
//   1. Resist     — opposed Evade vs Evade roll
//   2. Attack     — opponent makes an opposed combat skill vs initiator's
//                   Evade. Whether or not they hit, the initiator closes.
//                   Wait — re-read the rule: "Whether or not the blow lands,
//                   the closing character bridges the distance" — so on
//                   "Attack instead" the initiator ALWAYS closes; the
//                   defender just gets a chance to land a blow first.
//   3. Allow      — auto-success, no opposed roll.
//
// We deduct 1 AP from the initiator immediately on Change Range start.
// AP is tracked on the actor (system.actionPoints.value).
// =====================================================================

/**
 * Show the "Change Range" dialog for a specific engagement: lets the
 * initiator pick a target reach (closer or further than current) and
 * posts a chat card to the opponent for response.
 *
 * @param {Combatant} initiator
 * @param {string} opponentCombatantId
 */
export async function openChangeRangeDialog (initiator, opponentCombatantId) {
  const combat = game.combat
  if (!combat) return

  const opp = combat.combatants.get(opponentCombatantId)
  if (!opp) return

  const eng = getEngagementWith(initiator, opponentCombatantId)
  if (!eng) {
    ui.notifications?.warn('No active engagement with that opponent.')
    return
  }

  // Verify AP available
  const apValue = initiator.actor?.system?.actionPoints?.value ?? 0
  if (apValue < 1) {
    ui.notifications?.warn(`${initiator.name} has no Action Points to spend on Change Range.`)
    return
  }

  const reachLabels = ELYSIUM.WEAPON_REACHES || {}
  const order = ELYSIUM.WEAPON_REACH_ORDER || ['T', 'S', 'M', 'L', 'VL', 'H']
  const currentIdx = order.indexOf(eng.reach)
  const currentLabel = reachLabels[eng.reach] || eng.reach

  // Build target-reach options (excluding current)
  const targetOpts = order.map((k, i) => {
    if (i === currentIdx) return ''
    const direction = i < currentIdx ? '↓ closer' : '↑ further'
    return `<option value="${k}">${reachLabels[k]} (${direction})</option>`
  }).filter(Boolean).join('')

  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:12px;">
        <b>${initiator.name}</b> currently engaged with <b>${opp.name}</b>
        at <b>${currentLabel}</b>.
      </p>
      <p style="margin:0 0 8px 0;font-size:11px;font-style:italic;opacity:0.8;">
        Costs 1 AP. The opponent will be prompted to Resist (opposed
        Evade), Attack instead (opposed combat skill vs your Evade), or
        Allow.
      </p>
      <div class="form-group">
        <label>Target Reach</label>
        <select name="targetReach">${targetOpts}</select>
      </div>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Change Range — ${initiator.name}` },
    content,
    ok: {
      label: 'Begin (1 AP)',
      callback: (event, button) => {
        const form = button.form
        return { targetReach: form.querySelector('[name="targetReach"]').value }
      },
    },
  }).catch(() => null)

  if (!result?.targetReach) return

  await initiateChangeRange(initiator, opp, eng, result.targetReach)
}

/**
 * Spend 1 AP on the initiator and post a chat card to the opponent
 * with response buttons (Resist / Attack / Allow).
 */
async function initiateChangeRange (initiator, opponent, engagement, targetReach) {
  const reachLabels = ELYSIUM.WEAPON_REACHES || {}

  // Deduct 1 AP from the initiator
  const ap = initiator.actor?.system?.actionPoints?.value ?? 0
  await initiator.actor?.update({
    'system.actionPoints.value': Math.max(0, ap - 1),
  })

  // Post the prompt card via Archetype C partial. Buttons preserve
  // data-elysium-cr-action verbatim (audit-5 hook for resolveChangeRange).
  const body = `<p>${game.i18n.format('Elysium.Chat.ChangeRangeDescription', {
      initiator: `<b>${initiator.name}</b>`, opponent: `<b>${opponent.name}</b>`,
    })}</p>
    <p>${game.i18n.format('Elysium.Chat.ChangeRangeArrow', {
      from: reachLabels[engagement.reach] || engagement.reach,
      to: `<b>${reachLabels[targetReach] || targetReach}</b>`,
    })}</p>`
  const hint = game.i18n.format('Elysium.Chat.ChangeRangeResponsePrompt', { opponent: opponent.name })
  const buttons = [
    { action: 'resist-win',  label: game.i18n.localize('Elysium.Chat.ChangeRangeBtnResistWin'),
      tooltip: game.i18n.localize('Elysium.Chat.ChangeRangeBtnResistWinTip'),
      dataAttrs: { 'cr-initiator': initiator.id, 'cr-opponent': opponent.id, 'cr-target': targetReach } },
    { action: 'resist-lose', label: game.i18n.localize('Elysium.Chat.ChangeRangeBtnResistLose'),
      tooltip: game.i18n.localize('Elysium.Chat.ChangeRangeBtnResistLoseTip'),
      dataAttrs: { 'cr-initiator': initiator.id, 'cr-opponent': opponent.id, 'cr-target': targetReach } },
    { action: 'attack',      label: game.i18n.localize('Elysium.Chat.ChangeRangeBtnAttack'),
      tooltip: game.i18n.localize('Elysium.Chat.ChangeRangeBtnAttackTip'),
      dataAttrs: { 'cr-initiator': initiator.id, 'cr-opponent': opponent.id, 'cr-target': targetReach } },
    { action: 'allow',       label: game.i18n.localize('Elysium.Chat.ChangeRangeBtnAllow'),
      tooltip: game.i18n.localize('Elysium.Chat.ChangeRangeBtnAllowTip'),
      dataAttrs: { 'cr-initiator': initiator.id, 'cr-opponent': opponent.id, 'cr-target': targetReach } },
  ]
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-prompt.hbs',
    {
      variant: 'fire',
      title: game.i18n.localize('Elysium.Chat.ChangeRangeTitle'),
      icon: 'arrows-left-right',
      body,
      hint,
      actionAttr: 'data-elysium-cr-action',
      buttons,
    }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor: initiator.actor }),
    flags: { elysium: { changeRange: true } },
  })
}

/**
 * Resolve a Change Range outcome based on the chosen button. Updates
 * engagement reach on both sides if the change succeeds.
 *
 * @param {string} action       'resist-win' | 'resist-lose' | 'attack' | 'allow'
 * @param {string} initiatorId  combatant id
 * @param {string} opponentId   combatant id
 * @param {string} targetReach  Mythras reach letter
 */
export async function resolveChangeRange (action, initiatorId, opponentId, targetReach) {
  const combat = game.combat
  if (!combat) return

  const initiator = combat.combatants.get(initiatorId)
  const opponent  = combat.combatants.get(opponentId)
  if (!initiator || !opponent) return

  const reachLabels = ELYSIUM.WEAPON_REACHES || {}

  if (action === 'resist-win') {
    const rwBody = `<p>${game.i18n.format('Elysium.Chat.ChangeRangeResisted', {
      opponent: `<b>${opponent.name}</b>`,
    })}</p>`
    const rwHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'info', icon: 'shield', body: rwBody }
    )
    await ChatMessage.create({
      content: rwHtml,
      speaker: ChatMessage.getSpeaker({ actor: initiator.actor }),
    })
    return
  }

  // For all other outcomes, update engagement reach on both sides
  const aList = getEngagements(initiator).map(e =>
    e.withId === opponentId ? { ...e, reach: targetReach } : e
  )
  const bList = getEngagements(opponent).map(e =>
    e.withId === initiatorId ? { ...e, reach: targetReach } : e
  )
  await initiator.update({ 'flags.elysium.engagements': aList })
  await opponent.update({ 'flags.elysium.engagements': bList })

  let summary = ''
  if (action === 'resist-lose') {
    summary = `<b>${initiator.name}</b> wins the contest — reach is now <b>${reachLabels[targetReach]}</b>.`
  } else if (action === 'attack') {
    summary = `<b>${opponent.name}</b> attacked instead — resolve that attack separately. <b>${initiator.name}</b> closes regardless; reach is now <b>${reachLabels[targetReach]}</b>.`
  } else if (action === 'allow') {
    summary = `<b>${opponent.name}</b> allowed the change — reach is now <b>${reachLabels[targetReach]}</b>.`
  }

  const sumHtml = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'fire', icon: 'arrows-left-right', body: `<p>${summary}</p>` }
  )
  await ChatMessage.create({
    content: sumHtml,
    speaker: ChatMessage.getSpeaker({ actor: initiator.actor }),
  })

  // Re-render any open weapon sheets so the engagement display updates
  for (const actor of [initiator.actor, opponent.actor]) {
    if (!actor) continue
    for (const item of actor.items) {
      if (item.type === 'weapon' && item.sheet?.rendered) {
        item.sheet.render(false)
      }
    }
    if (actor.sheet?.rendered) actor.sheet.render(false)
  }
}

/**
 * Wire click handlers on Change Range chat-card buttons. Called once
 * during ready hook.
 */
export function wireChangeRangeChatHandlers () {
  // Delegate clicks on chat log
  document.body.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-elysium-cr-action]')
    if (!btn) return
    ev.preventDefault()
    if (!game.user.isGM && !game.user.hasPermission?.('SETTINGS_MODIFY')) {
      ui.notifications?.warn('Only the GM can resolve Change Range outcomes.')
      return
    }
    const action      = btn.dataset.elysiumCrAction
    const initiatorId = btn.dataset.crInitiator
    const opponentId  = btn.dataset.crOpponent
    const targetReach = btn.dataset.crTarget
    await resolveChangeRange(action, initiatorId, opponentId, targetReach)
  })
}

export const ElysiumEngagementUI = {
  patchCombatTrackerContextMenu,
  registerContextMenu: registerEngagementContextMenu,
  openEngageDialog,
  openDisengageDialog,
  openChangeRangeDialog,
  establishEngagement,
  breakEngagement,
  resolveChangeRange,
  wireChangeRangeChatHandlers,
}
