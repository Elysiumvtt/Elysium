import { ElysiumActiveEffectSheet } from '../../sheets/elysium-active-effect-sheet.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Armor item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Includes active-effects PART (audit-5 lock: legacy
 * `active-effect-change-edit` class hook preserved through the
 * shell-effects partial; ElysiumActiveEffectSheet.activateListeners
 * still bound in _onRender).
 *
 * Detail body split into 4 logical sub-grids per c3-armor-2:
 * Protection / Encumbrance / Penalties / Power. Plus owner-only
 * actual-ENC + hit location + equip status block.
 *
 * Per c3-armor-1: player-branch `physMod`/`stealthMod` camelCase
 * bug (which rendered values as blank) fixed in detail template
 * by using DataModel-correct `physmod`/`stealthmod` field names.
 */
export class ElysiumArmorSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['armor'],
    position: { width: 720, height: 720 },  // wide tier per audit-3
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/armor.detail.hbs',
      scrollable: [''],
    },
    effects:     { template: 'systems/elysium/templates/item/parts/item-shell-effects.hbs' },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'effects', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const actor = this.item.parent

    context.burdenOptions  = await ElysiumSelectLists.getArmorBurdenOptions()
    context.priceOptions   = await ElysiumSelectLists.getPriceOptions()
    if (actor) {
      context.hitLocOptions = await ElysiumSelectLists.getHitLocOptions(actor)
    }
    context.equippedOptions = await ElysiumSelectLists.getEquippedOptions(this.document.type)
    context.burdenName   = game.i18n.localize('Elysium.' + this.item.system.burden)
    context.priceName    = game.i18n.localize('Elysium.' + this.item.system.price)
    context.equippedName = game.i18n.localize('Elysium.' + this.item.system.equipStatus)

    // Active-effects context (audit-5 lock)
    context.effects = ElysiumActiveEffectSheet.getItemEffectsFromSheet(this.document)
    const changesActiveEffects = ElysiumActiveEffectSheet.getEffectChangesFromSheet(this.document)
    context.effectKeys = changesActiveEffects.effectKeys
    context.effectChanges = changesActiveEffects.effectChanges

    // Header chips per c3-2: AV + Burden + (when owned) Status
    const av = this.item.system.av1 ?? 0
    const chips = [
      { label: game.i18n.localize('Elysium.av'),     value: String(av) },
      { label: game.i18n.localize('Elysium.burden'), value: context.burdenName },
    ]
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.status'),
        value: context.equippedName,
      })
    }
    context.itemHeaderChips = chips

    return context
  }

  /** Active-effects listener wiring is required for the trash icon and
   *  inline-edit selects/inputs inside the effects tab. */
  _onRender(context, _options) {
    ElysiumActiveEffectSheet.activateListeners(this)
  }
}
