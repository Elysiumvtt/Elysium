export function listen() {
  Hooks.on('drawNote', async (application) => {
    // Direct flag read — see render-note-config.js for rationale.
    if (application.document.flags?.elysium?.['hide-background'] ?? false) {
      application.controlIcon.bg.clear()
    }
  })
}
