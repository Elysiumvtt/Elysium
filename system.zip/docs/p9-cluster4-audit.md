# P9 cluster 4 (background + statistics) — prep audit

Captured 2026-05-14, after alpha.34 smoke pass. Source-of-truth document
ahead of the cluster 4 ship.

## Decisions inherited

- All cluster 1/2/3 shared partials available.
- The P9 audit's cluster 4 scope was: "background + statistics drill-down
  absorption into header tiles" with statistics tab deleted.
- Default smoke pattern is offline-render + **action-handler invocation
  tests** (lesson reinforced after alpha.33 + alpha.34 hotfixes).
- All new shared partials registered in `init.mjs:2a`.
- Side finding #5 (Claude-in-Chrome bridge wedges on ProseMirror iframes)
  means the background rebuild — which has TWO ProseMirror editors per
  story section — has elevated smoke risk. Offline-render workaround
  is required.

## Phase scope (originally planned vs revised)

The P9 audit assumed statistics was a thin "drill-down view" with 6-10
lines of stat detail per tile. **On re-inspection of the legacy
template**, the statistics tab is much richer:

1. **Characteristic grid** — 7 stats × 7 columns:
   `name | initial | ancestry | experience | effects | total | failCounter`.
   Two editable inputs per stat (`base`, `culture`), a "roll all stats"
   button when unlocked, and a fail-counter active-state highlight.
2. **Bonus & Resource block** — manual editable inputs for HP mod, PP mod,
   Proactive AP mod, Reactive AP mod. Plus computed display of total ENC
   and EXP Dice.
3. **Powers list** — display-only badges showing active traditions
   (arcane / divine / mysticism / sorcery / mutation / super).

The audit's "fold to per-tile drill-down popover" decision absorbs the
read-only derived display but does NOT capture the editable inputs or
the non-stat-specific bonus block. Drill-down alone is incomplete.

## Open recommendation requiring user sign-off

Four ways forward:

**(A) Full absorption into drill-down**: per-tile popover becomes a mini
sheet with base + culture inputs + derived breakdown. Plus a separate
new card somewhere for bonus block (HP mod, PP mod, AP mods, ENC, EXP
Dice). Plus powers list moves to the header card meta block.
Pro: matches the P9 audit lock-in.
Con: large scope; popover with text inputs needs Foundry V14
ApplicationV2 dialog wiring; multiple decisions packed into one ship.

**(B) Reverse the P9 audit lock**: keep statistics as a tab, rebuild it
against new identity. Simplest preservation of function.
Pro: low risk, no design churn.
Con: explicitly reverses an audit-locked decision (Q1 from P9 prep
audit, signed off as "header drill-down").

**(C) Hybrid**: per-tile drill-down for the stat-row data (read-only +
the two inputs), small "Bonus & Resources" card on Items tab or as a
new footer card for the non-stat editable bonuses, powers list as
display-only chips in the header meta.
Pro: best long-term design, matches the spirit of the P9 audit.
Con: most touch surface; three decisions packed into one ship; the
"new footer card" placement needs a layout decision.

**(D) Defer statistics retirement to P12**: ship cluster 4 as
background-only. Statistics tab stays legacy. P12 polish phase has
the bandwidth to think the statistics absorption through carefully
with mockups, with the legacy template serving the editing need in
the meantime.
Pro: best velocity. Audit said it was a "drill-down view" — turns
out it's the primary editing surface for stat creation and ancestry-
mod adjustment. That's a bigger problem than a P9-rush should try
to solve.
Con: one fewer surface retired in P9.

### My recommendation: (D) — defer statistics retirement to P12

The P9 audit underestimated the statistics tab's role. It's not a
"drill-down view" — it's the primary editing surface for character
creation and ancestry application. Folding it correctly needs a
deliberate design pass with mockups, not a mid-ship pivot. P12 is the
right home for this kind of design-from-scratch work because it
overlaps with light-theme retirement, branded assets, and other
cosmetic-but-substantial decisions.

The legacy statistics template will continue to render against
`css/legacy.css` until P12 — same arrangement as `css/legacy.css`,
`css/npc.css`, and `styles/elysium.css` for the rest of the legacy
surface (per the P7 framing-B decision).

Cluster 4 becomes **background-only**. Cluster 5 (magic family + smart
consolidation) closes out P9. Statistics retirement becomes its own
P12 work item alongside the legacy-CSS retirement and theme cleanup.

## If (D) is locked, cluster 4 scope is just background

### Background tab — legacy shape

```
- New-section button (gated on isLocked)
- For each storySection:
  - Section header: title input (editable) + reorder up/down + delete
  - Section body: ProseMirror editor (when editable) OR enriched HTML
```

Two ProseMirror editors per section: one in the visible region, plus
Foundry's internal toolbar (which embeds the chrome-extension iframe
that wedges the bridge per side finding #5). Offline-render smoke
will be the only viable path; live click-testing requires fresh tab
+ navigate-recovery between attempts.

### Data dependencies (verified)

```
context.storySections[]   — array of {title, value, enriched, isFirst, isLast}
                            built in character.mjs context-prep from
                            actor.system.stories[]
context.editable          — boolean (true when sheet is editable)
context.isLocked          — boolean (sheet lock state)
```

### Action handlers (all already registered)

```
storyUp, storyDown, storyDelete  — section reorder + delete
addNewSection                    — NOT currently a registered handler;
                                    legacy uses a button with class
                                    'addNewSection' that's likely
                                    wired via a separate click listener.
                                    Need to verify.
```

Verification gate: confirm `addNewSection` is wired before ship. If
it's not registered, ship adds an `addNewStorySection` action handler
in `base-actor-sheet.mjs`.

### Target v1.0.0 design

Single section card wrapping all story sections, with one new partial
`story-section.hbs` encapsulating a single section's title row +
ProseMirror body. The story-section partial accepts a section index
and the editable flag.

Section header pattern:
- When locked: title-as-display (no input, no buttons)
- When editable: title-as-input + reorder up/down + delete buttons in
  a small right-aligned group

ProseMirror body styled with consistent card chrome per the audit
recommendation in the P9 prep audit ("ProseMirror chrome restyled to
match `--ely-text-body` on `--ely-surface-1`"). Foundry's default
prosemirror toolbar is kept as-is.

Top-of-tab "Add Section" button uses the same `.button-primary`
treatment as combat tab's healing actions.

### New shared partials

| Partial | Purpose | NPC adaptation |
|---|---|---|
| `story-section.hbs` | One story section: title row + body | NPC sheets don't typically have a Background tab in legacy. Optional partial reuse if NPC gets a bio. |

One new partial. Registered in `init.mjs:2a`.

### CSS additions

Estimated ~80 lines:
- `.elysium-story-section` container
- `.elysium-story-section-header` (title row with conditional editable / locked variants)
- `.elysium-story-title-input` (clean override of legacy bio-section-title styling)
- `.elysium-story-controls` (reorder + delete button group)
- `.elysium-story-body` (prosemirror chrome — background + padding + border)
- `.elysium-story-add` (top-of-tab add button — `.button-primary` reuse with margin override)

### Legacy classes retired in background

`bio-control`, `bio-section`, `bio-section-value`, `bio-section-title`,
`section-header`, `story-subtitle`, `flexrow-elysium`, `header-buttons`,
`move-section-up`, `move-section-down`, `delete-section`, `story`,
`button`, `addNewSection`. ~14 classes.

## Smoke plan for cluster 4

Per the alpha.33/.34 lesson, smoke now includes action-handler
invocation tests for any new `data-action`:

1. Offline-render `background` part — verify section count, title text,
   editable input vs locked text-display, reorder/delete buttons
   conditional on isFirst/isLast.
2. **Action invocation**: build a fake row, invoke `storyUp`,
   `storyDown`, `storyDelete`, and `addNewStorySection` (if added)
   via the bound action handler. Verify the actor's `system.stories`
   array changes as expected.
3. CSS verification via offscreen test element for the new classes.
4. ProseMirror bridge avoidance: confirm the section template renders
   to HTML correctly via the offline-render path; do NOT attempt to
   render the sheet live during smoke (it WILL wedge the bridge).
5. Regression: all 16 PARTS still render.

## Out of scope for cluster 4

- Statistics tab rebuild (deferred to P12 per recommendation D)
- Statistics-tab drill-down popover on header tiles (deferred)
- Bonus & Resources card placement (deferred)
- Powers list relocation (deferred)
- Item sheet rebuilds (P10)

## Open questions requiring lock-in before ship

1. **MAIN**: Defer statistics retirement to P12 (option D)? **Strongly
   recommended.** If user chooses (A), (B), or (C), the audit needs a
   revision pass before ship.

2. **background-cluster4-1**: Confirm `addNewSection` handler wiring.
   If the legacy uses an inline click listener on `.addNewSection`
   rather than the action handler system, we add an
   `addNewStorySection` static action handler in `base-actor-sheet.mjs`
   and switch the legacy listener off in the rebuild. Recommendation:
   **add the action handler** for consistency with the rest of the
   v1.0.0 surface — no inline JS listeners, every interaction routed
   through `data-action`.

3. **background-cluster4-2**: ProseMirror toolbar — keep Foundry
   default per the P9 audit, or restyle? Recommendation: **keep Foundry
   default**. Restyling a Foundry framework component is out of scope.

## Proposed ship sequence

Single small alpha (alpha.35) assuming option D is locked:

1. Verify `addNewSection` wiring; add action handler if needed.
2. Add `story-section.hbs` to `init.mjs:2a`.
3. Write `story-section.hbs`.
4. Rewrite `character.background.hbs`.
5. Append CSS (~80 lines).
6. Pre-flight sweep: brace balance, handlebars balance, token
   resolution, `node --check`.
7. Package + present.
8. Offline-render smoke + handler invocation tests.

After cluster 4 closes: cluster 5 (magic family + smart consolidation)
is the final P9 cluster.

## Ready-to-go checklist

- [x] Legacy template inspected
- [x] Context dependencies verified
- [ ] User decision on statistics retirement (recommend D)
- [ ] `addNewSection` handler wiring verified during ship
- [x] Offline-render smoke pattern proven for ProseMirror surfaces
