// Auto-extracted from module/elysium/hooks/register-hooks.mjs
// (v0.21.0 register-hooks refactor).
//
// renderChatMessageHTML hook: delegates click handlers on the various
// Elysium-posted chat-card buttons. Each button class has its own routing
// function below, kept independent so they can be unit-tested or replaced
// in isolation.
//
// Button classes handled:
//   [data-cast-action]              — Spend AP / Abandon / Undo PP on cast cards
//   .elysium-disrupt-btn            — Disrupt-sustain on damage to a sustainer
//   .elysium-cast-disrupt-btn       — Cast-disruption on damage to an active caster
//   .elysium-cap-btn                — GM approval/deny on stat-cap override requests
//
// Card-render decorations (v0.22.0-alpha.12, Phase D):
//   - Hit-location tag visibility gating (all users)
//   - Combat-card GM action button injection (crit-armor / crit-parry /
//     fumble) — GM-only

import {
  injectCombatCardButtons,
  applyHitLocationVisibility,
} from '../mechanics/combat-card-buttons.mjs'

/**
 * Top-level dispatcher — invoked by the renderChatMessageHTML hook.
 *
 * V14 passes the HTMLElement directly; V13 passed jQuery — handle both.
 */
export function onRenderChatMessageHTML (msg, html, data) {
  const root = html instanceof Element ? html : html?.[0] || html
  if (!root) return

  // Phase D: hit-location tag visibility (all users, before any GM-only logic).
  applyHitLocationVisibility(root)

  // Phase D: GM-only combat-resolution action buttons.
  injectCombatCardButtons(msg, root)

  // Cast-card buttons (Spend AP, Abandon, Undo PP) — gated on the
  // castCard flag since those data-cast-action selectors only appear
  // on cast cards.
  if (msg.flags?.['elysium']?.castCard) {
    wireCastCardButtons(root)
  }

  // v0.10.3: Disrupt-sustain buttons (posted automatically when a
  // sustainer takes damage). These appear on plain ChatMessages
  // without the castCard flag, so they're delegated outside the
  // cast-card gate above.
  wireDisruptSustainButtons(root)

  // v0.16.0: Cast-disruption buttons. Posted when an actively-casting
  // wizard takes damage. Player rolls their own Willpower; on failure,
  // accumulated SL is reduced by wound severity (1 minor / 2 serious /
  // all critical).
  wireCastDisruptButtons(root)

  // v0.11.0: Cap-override and EXP-dice override approval buttons
  // (posted by the stat-improvement subsystem). Only GMs see these
  // (chat cards are whispered to GM), and only GMs should act on them.
  wireCapOverrideButtons(root)
}

function wireCastCardButtons (root) {
  const buttons = root.querySelectorAll('[data-cast-action]')
  for (const btn of buttons) {
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      const action = btn.dataset.castAction
      const actorId = btn.dataset.actorId
      const actor = game.actors.get(actorId)
      if (!actor) return

      // Permission check — only the actor's owner or GM can drive these.
      if (!actor.isOwner) {
        ui.notifications?.warn(
          `You don't have ownership of ${actor.name}.`)
        return
      }

      const casting = game.system?.api?.casting
      if (!casting) {
        ui.notifications?.error('Casting API not available — system fork v0.9.0+ required.')
        return
      }

      if (action === 'spend-ap') {
        await casting.spendCastAP(actor)
      } else if (action === 'abandon') {
        await casting.abandonCast(actor)
      } else if (action === 'undo-pp') {
        const amount = Number(btn.dataset.ppAmount ?? 0)
        if (amount > 0) {
          await casting.refundPP(actor, amount)
          ui.notifications?.info(`Refunded ${amount} PP to ${actor.name}.`)
          btn.disabled = true
          btn.textContent = '✓ Refunded'
        }
      }
    })
  }
}

function wireDisruptSustainButtons (root) {
  const disruptBtns = root.querySelectorAll('.elysium-disrupt-btn')
  for (const btn of disruptBtns) {
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      const actorId = btn.dataset.actorId
      const spellId = btn.dataset.spellId
      const spellName = btn.dataset.spellName
      const actor = game.actors.get(actorId)
      if (!actor) return
      if (!actor.isOwner && !game.user.isGM) {
        ui.notifications?.warn(`You don't have ownership of ${actor.name}.`)
        return
      }
      const casting = game.system?.api?.casting
      if (!casting?.disruptSustain) return
      // Prompt for attacker's hit roll value.
      const result = await foundry.applications.api.DialogV2.prompt({
        window: { title: `Disrupt ${spellName}` },
        content: `<p>Enter the attacker's d100 hit roll to test
          ${actor.name}'s Willpower vs disruption:</p>
          <input type="number" name="attackerRoll" min="1" max="100" value="50" autofocus />`,
        ok: {
          label: 'Roll Disruption',
          callback: (event, button, dialog) => {
            const input = dialog.element.querySelector('input[name="attackerRoll"]')
            return Number(input?.value) || 0
          },
        },
        rejectClose: false,
      })
      if (result == null || result === 0) return
      await casting.disruptSustain(actor, spellId, result)
      btn.disabled = true
    })
  }
}

function wireCastDisruptButtons (root) {
  const castDisruptBtns = root.querySelectorAll('.elysium-cast-disrupt-btn')
  for (const btn of castDisruptBtns) {
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      const actorId = btn.dataset.actorId
      const severity = btn.dataset.severity
      const slLossRaw = btn.dataset.slLoss
      const damage = Number(btn.dataset.damage) || 0
      const actor = game.actors.get(actorId)
      if (!actor) return
      if (!actor.isOwner && !game.user.isGM) {
        ui.notifications?.warn(`You don't have ownership of ${actor.name}.`)
        return
      }
      const casting = game.system?.api?.casting
      if (!casting?.applyDisruptionRoll) return

      const wp = casting.findWillpowerSkill(actor)
      // Roll Willpower (d100 vs WP%). If no Willpower skill, the save
      // automatically fails (target = 0).
      const roll = await new Roll('1d100').evaluate()
      const rollValue = roll.total
      const succeeded = wp.found && rollValue <= wp.total

      await roll.toMessage({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor: `<strong>${actor.name}</strong> rolls Willpower (${wp.found ? wp.total + '%' : 'no skill — auto-fail'}) vs cast disruption`,
      })

      const slLoss = slLossRaw === 'all' ? 'all' : Number(slLossRaw)
      const result = await casting.applyDisruptionRoll(actor, { rollValue, succeeded }, {
        slLoss, severity, damage, willpowerName: wp.name,
      })

      if (result) {
        let outcomeText = ''
        let variant = 'info'
        if (result.outcome === 'concentration_held') {
          outcomeText = `<span class="elysium-disrupt-success"><i class="fas fa-check"></i> Concentration held — no SL lost.</span>`
          variant = 'success'
        } else if (result.outcome === 'cast_disrupted') {
          outcomeText = `<span class="elysium-disrupt-fail"><i class="fas fa-times"></i> Cast disrupted — accumulated SL reduced from ${result.slBefore} to ${result.slAfter} (lost ${result.slLost}). The wizard can continue accumulating from zero.</span>`
          variant = 'danger'
        } else {
          outcomeText = `<span class="elysium-disrupt-partial"><i class="fas fa-exclamation"></i> Concentration shaken — accumulated SL reduced from ${result.slBefore} to ${result.slAfter} (lost ${result.slLost}).</span>`
          variant = 'fire'
        }
        // Per c2 D4: edge case — preserve elysium-disrupt-success/fail/partial
        // inner classes (cluster-styled in elysium.css). Caller-built body.
        foundry.applications.handlebars.renderTemplate(
          'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
          { variant, icon: 'bolt', body: outcomeText }
        ).then(html =>
          ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor }),
            content: html,
          })
        ).catch(err => console.error('Elysium | cast-disrupt result post failed:', err))
      }
      btn.disabled = true
    })
  }
}

function wireCapOverrideButtons (root) {
  const capBtns = root.querySelectorAll('.elysium-cap-btn')
  for (const btn of capBtns) {
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      if (!game.user.isGM) {
        ui.notifications?.warn('Only the GM can approve override requests.')
        return
      }
      const actorId = btn.dataset.actorId
      const statKey = btn.dataset.statKey
      const actor = game.actors.get(actorId)
      if (!actor) return
      const api = game.system.api?.elysium
      if (!api?.statImprovement) return
      const approved = btn.classList.contains('elysium-cap-approve')
      // Route based on card type — dice-override card has its own class.
      const card = btn.closest('.elysium-stat-cap-card')
      const isDiceCard = card?.classList.contains('elysium-stat-dice-card')
      if (isDiceCard) {
        if (api.statImprovement.handleExpDiceApproval) {
          await api.statImprovement.handleExpDiceApproval(actor, statKey, approved)
        }
      } else {
        if (api.statImprovement.handleCapApproval) {
          await api.statImprovement.handleCapApproval(actor, statKey, approved)
        }
      }
      // Disable both buttons in the card to prevent double-clicks.
      card?.querySelectorAll('.elysium-cap-btn').forEach(b => {
        b.disabled = true
      })
      btn.classList.add('elysium-cap-btn-resolved')
    })
  }
}
