/**
 * Sorcery casting (v0.19.0).
 *
 * Replaces the v0.18.x stub. Tier-based spontaneous casting modeled on
 * the divine pipeline, with these differences from divine:
 *   - One skill check (essence skill) instead of two (Channeling + Faith)
 *   - Spontaneous & reliable: the spell ALWAYS fires. The d100 produces
 *     a resistance value used for opposed saves only — there is no
 *     failure mode where the spell fizzles (per locked v0.19.0 design)
 *   - Tier thresholds: 1/50/70/85/95 (same numbers as divine but sorcery
 *     gates on only the essence skill, not a Channeling+Faith pair)
 *   - Flat PP cost from `powerCost` (most abilities 2 PP, iconics 3 PP)
 *
 * Pipeline:
 *   1. Find essence skill on the actor (e.g. "Elemental Essence").
 *      Abort if not found.
 *   2. Compute which tiers are available (essence skill >= threshold).
 *      Iconic abilities (`baseTier: 5`) are only castable at T5.
 *   3. Open tier-choice dialog (reuses divine's, with sorcery-themed labels).
 *      Player picks one of the available tiers. Cancel returns immediately.
 *   4. Spend AP (per apCostByTier[tier-1]) and pay PP (from powerCost).
 *      Insufficient PP → overcast → fatigue (existing payPP behavior).
 *   5. Roll d100 for the resistance value (always succeeds).
 *   6. Post chat card. Register sustain if isSustained. Forbidden warning.
 *
 * Phase D-1 deliverables: schema, skeleton pipeline, tier-choice, PP/AP,
 * sustain registration, chat card, forbidden-warning. Phase D-2 will add
 * hit-location targeting and armor-vs-damage integration.
 */

import { payPP, spendAP, rollD100, postCastCard, classifyRoll, findSkill } from './cast-shared.mjs'
import { TierChoiceDialog } from './tier-choice-dialog.mjs'
import { addSustain } from './sustain.mjs'// v0.19.0 Phase D-2: hit-location targeting + armor-vs-damage integration
import { applyArmorToDamage, rollMultipleHitLocations } from '../combat/armor-vs-damage.mjs'
/**
 * v0.19.0 locked tier thresholds for sorcery. Changed from the v0.18.x
 * stub (1/25/50/75/100) to (1/50/70/85/95).
 */
const TIER_THRESHOLDS = {
  1: 1,    // Nascent      (any essence skill)
  2: 50,   // Developing
  3: 70,   // Established
  4: 85,   // Potent
  5: 95,   // Transcendent
}

/**
 * Sorcery-themed tier band labels. Passed to the tier-choice dialog so
 * the UI shows "Nascent (1+)" instead of divine's "Untested (1+)".
 */
const TIER_LABELS = {
  1: 'Nascent (1+)',
  2: 'Developing (50+)',
  3: 'Established (70+)',
  4: 'Potent (85+)',
  5: 'Transcendent (95+)',
}

/**
 * Compute the highest tier the sorcerer can cast at, given the essence
 * skill total. Returns 0 if below tier 1 threshold (which is 1% — anyone
 * with any essence skill qualifies for at least tier 1).
 */
export function maxCastableSorceryTier (essenceSkillTotal) {
  let max = 0
  for (let t = 1; t <= 5; t++) {
    if (essenceSkillTotal >= TIER_THRESHOLDS[t]) max = t
  }
  return max
}

/**
 * Find the actor's essence skill for the given essence name.
 *
 * Essence skills are skill items with subgroup 'sorcery' and a name that
 * includes the essence (e.g. "Elemental Essence" matches essence "elemental").
 * If no name match is found, fall back to any sorcery-subgroup skill (this
 * supports actors who only have one sorcery skill regardless of name).
 *
 * @param {Actor} actor
 * @param {string} essence — e.g. 'elemental', 'death', 'vitality', 'ward'
 * @returns {Item|null}
 */
function findEssenceSkill (actor, essence) {
  if (!essence) {
    return findSkill(actor, { subgroup: 'sorcery' })
  }
  const needle = String(essence).toLowerCase()
  for (const itm of actor.items) {
    if (itm.type !== 'skill') continue
    if (itm.system?.elysium?.skillSubgroup !== 'sorcery') continue
    if (itm.name.toLowerCase().includes(needle)) return itm
  }
  // Fall back to any sorcery skill if no name match
  return findSkill(actor, { subgroup: 'sorcery' })
}

/**
 * Begin a sorcery cast. Validates pre-conditions, opens the tier-choice
 * dialog, and resolves the spell on player confirmation.
 *
 * Replaces the v0.18.x flat single-AP `castSorcery`; that name is
 * preserved at the bottom of this file as a back-compat alias.
 *
 * @param {Actor} actor
 * @param {Item}  spell — a sorcery item
 */
export async function beginSorceryCast (actor, spell) {
  if (!actor || !spell) return
  if (spell.type !== 'sorcery') {
    ui.notifications?.warn('beginSorceryCast: not a sorcery item.')
    return
  }

  // Step 1: locate the essence skill on the actor.
  const essence = spell.system?.elysium?.essence || ''
  const essenceSkill = findEssenceSkill(actor, essence)
  if (!essenceSkill) {
    ui.notifications?.warn(
      `${actor.name} has no Sorcery essence skill ` +
      `(looking for "${essence}"). Drag the skill from the Skills compendium first.`)
    return
  }
  const skillTotal = Number(essenceSkill.system?.total) || 0

  // Step 2: determine available tiers.
  // - baseTier is the lowest tier the ability can be cast at (iconics: 5).
  // - maxTier is the highest authored tier (typically 5).
  // - skillTotal gates the upper bound: tier 2 needs 50+, tier 3 needs 70+, etc.
  const baseTier = Math.max(1, Number(spell.system?.elysium?.baseTier) || 1)
  const maxTier  = Math.min(5, Number(spell.system?.elysium?.maxTier)  || 5)
  const skillCap = maxCastableSorceryTier(skillTotal)
  const effectiveCap = Math.min(maxTier, skillCap)

  if (effectiveCap < baseTier) {
    ui.notifications?.warn(
      `${actor.name}'s ${essenceSkill.name} (${skillTotal}%) is below the ` +
      `tier ${baseTier} threshold (${TIER_THRESHOLDS[baseTier]}%). ` +
      `Cannot cast ${spell.name}.`)
    return
  }

  const availableTiers = []
  for (let t = baseTier; t <= effectiveCap; t++) availableTiers.push(t)

  // Step 3: open tier-choice dialog. The divine dialog is reused; we pass
  // skillTotal in the channelTotal slot and -1 (sentinel) in faithTotal.
  // The template's display of faith will read "-1%" until Phase D-2 polishes
  // the template to hide the faith row when faithTotal is the sentinel.
  // This is intentionally cosmetic — the underlying mechanic is correct.
  const apCostByTier = Array.isArray(spell.system?.elysium?.apCostByTier)
    ? spell.system.elysium.apCostByTier
    : [1, 1, 1, 1, 1]
  const effectByTier = spell.system?.elysium?.effectByTier ?? {}

  const chosen = await TierChoiceDialog.open({
    actor,
    spell,
    availableTiers,
    apCostByTier,
    effectByTier,
    channelTotal: skillTotal,
    faithTotal: -1,
  })
  if (!chosen) return    // player cancelled

  const chosenTier = chosen.tier

  // Step 4: AP + PP payment.
  const apCost = Number(apCostByTier[chosenTier - 1]) || 1
  if (apCost > 0) {
    const ok = await spendAP(actor, apCost)
    if (!ok) {
      ui.notifications?.warn(`${actor.name} cannot spend ${apCost} AP this round. Cast aborted.`)
      return
    }
  }

  // Flat PP cost from powerCost (most abilities: 2 PP; iconics: 3 PP).
  // Phase H will introduce per-essence keystone discounts; for D-1 the
  // flat cost is correct.
  const ppCost = Number(spell.system?.elysium?.powerCost) || 2
  const ppResult = await payPP(actor, ppCost, true)
  if (ppResult.fizzled) {
    ui.notifications?.warn(`${actor.name} could not pay ${ppCost} PP. Cast aborted.`)
    return
  }

  // Step 5: roll d100 for the resistance value. Sorcery is spontaneous
  // and reliable — the spell ALWAYS fires. The roll is informational
  // (for opposed saves only).
  const { value: rollValue } = await rollD100()
  classifyRoll(skillTotal, rollValue)   // for future logging/analytics

  // Step 6: build the chat card description.
  const tierEffect = effectByTier[String(chosenTier)] ?? effectByTier[chosenTier] ?? ''
  const damageType = spell.system?.elysium?.damageType ?? ''
  const isDamageSpell = !!spell.system?.elysium?.isDamageSpell
  const forbidden = !!spell.system?.elysium?.forbidden

  let description = `<p><strong>Tier ${chosenTier} effect:</strong> ${tierEffect}</p>`
  if (forbidden) {
    description = `<p class="elysium-forbidden-warning"><strong>⚠ Forbidden essence cast.</strong> ` +
      `Most cultures consider this magic taboo; the GM may invoke social consequences.</p>` + description
  }
  description += spell.system?.description ?? ''

  await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: spell.id,
    spellName: spell.name,
    tradition: 'sorcery',
    schoolName: essence,
    schoolSkillName: essenceSkill.name,
    schoolSkillTotal: skillTotal,
    completed: true,        // sorcery always succeeds
    abandoned: false,
    finalRoll: rollValue,
    resistanceValue: rollValue,
    saveSkill: spell.system?.elysium?.saveSkill ?? '',
    apSpent: apCost,
    ppSpent: ppResult.ppSpent,
    fatigueAdded: ppResult.fatigueAdded ?? 0,
    chosenTier,
    isDamageSpell,
    damageType,
    description,
  })

  // v0.19.0 Phase D-2: damage resolution.
  // If this is a damage spell with a damageByTier expression and the user
  // has targeted token(s), roll damage and apply the cross-tradition
  // armor-vs-damage table to each affected hit location.
  //
  // The locationsByTier field controls how many random locations are hit
  // per target. Default 1 location at all tiers; high-tier AoE abilities
  // may set [1,1,1,2,3] (2 locs at T4, 3 at T5).
  //
  // If no targets are selected, the chat card lands without damage rolls
  // and the GM applies manually — same as v0.18.x fallback behavior.
  if (isDamageSpell) {
    await _resolveSorceryDamage(actor, spell, chosenTier, damageType)
  }

  // Step 7: register sustain if the ability is sustained.
  // Same pattern as divine: use `maintainPPPerRound` (typically 1) for
  // the per-round upkeep, not the full cast cost.
  const isSustained = !!spell.system?.elysium?.isSustained
  if (isSustained) {
    const maintain = Number(spell.system?.elysium?.maintainPPPerRound) || 1
    await addSustain(actor, {
      spellId: spell.id,
      spellName: spell.name,
      ppPerRound: maintain,
      schoolName: essence || 'sorcery',
    })
  }
}

/**
 * Backward-compat wrapper: keep the v0.18.x `castSorcery` name so existing
 * sheet bindings continue to work. Routes through the new pipeline.
 */
export async function castSorcery (actor, spell) {
  return beginSorceryCast(actor, spell)
}

/**
 * v0.19.0 Phase D-2: damage resolution for a sorcery cast.
 *
 * Reads the per-tier damage expression and locations-affected count from
 * the spell. For each token the caster has targeted, rolls N random hit
 * locations, rolls damage for each, applies the cross-tradition armor-vs-
 * damage table, and posts a per-target damage chat message.
 *
 * Behavior matrix:
 *  - No targets selected → silently no-op; GM applies manually
 *  - damageByTier[tier-1] is empty → silently no-op; GM applies manually
 *  - casterChoosesLocation is true → ALL targets, ALL locations get the
 *    chest hit location (placeholder for self-heal / single-location
 *    self-buff abilities). Phase H may refine to a location-picker dialog.
 *  - Otherwise → roll random hit location(s) per target
 *
 * @param {Actor}  actor
 * @param {Item}   spell
 * @param {number} chosenTier — 1-5
 * @param {string} damageType — e.g. 'fire', 'necrotic'
 */
async function _resolveSorceryDamage (actor, spell, chosenTier, damageType) {
  const ely = spell.system?.elysium ?? {}
  const damageByTier = Array.isArray(ely.damageByTier) ? ely.damageByTier : []
  const damageExpr = damageByTier[chosenTier - 1]
  if (!damageExpr || !String(damageExpr).trim()) return

  const locationsByTier = Array.isArray(ely.locationsByTier) ? ely.locationsByTier : [1, 1, 1, 1, 1]
  const locCount = Math.max(1, Number(locationsByTier[chosenTier - 1]) || 1)
  const casterChoosesLocation = !!ely.casterChoosesLocation

  // Resolve targets. Foundry exposes user-targeted tokens via game.user.targets.
  const targets = Array.from(game.user?.targets ?? [])
  if (targets.length === 0) {
    // No targets — post a notice that the GM should apply damage manually,
    // since we don't know who's being hit.
    const body = `<p><em>${spell.name} dealt damage but no targets were selected.</em></p>
      <p>Damage expression: <code>${damageExpr}</code> (${damageType || 'unspecified'} damage to
      ${locCount} ${locCount === 1 ? 'location' : 'locations'} per target). GM should resolve manually.</p>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'danger', icon: 'circle-exclamation', body }
    )
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
    return
  }

  // Resolve per target.
  for (const tok of targets) {
    const targetActor = tok.actor
    if (!targetActor) continue

    const locations = casterChoosesLocation
      // Placeholder: caster-choice path defers to GM until a picker dialog
      // is added in Phase H. For now, treat as "first available location."
      ? (targetActor.items.filter(i => i.type === 'hit-location').slice(0, locCount))
      : await rollMultipleHitLocations(targetActor, locCount)

    if (locations.length === 0) {
      const body = `<p><em>${targetActor.name} has no hit locations defined; ${spell.name} damage skipped.</em></p>`
      const html = await foundry.applications.handlebars.renderTemplate(
        'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
        { variant: 'danger', body }
      )
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: html,
      })
      continue
    }

    // Per-location damage roll. Each location takes a fresh roll of the
    // damage expression (per locked design: multi-location AoE rolls the
    // dice per location, not once shared).
    const perLocationResults = []
    for (const loc of locations) {
      const roll = await new Roll(damageExpr).roll()
      const rawDamage = roll.total
      const armorResult = applyArmorToDamage(rawDamage, damageType, targetActor, loc._id)
      perLocationResults.push({
        location: loc,
        rollFormula: roll.formula,
        rollResult: roll.result,
        rawDamage,
        finalDamage: armorResult.final,
        totalAP: armorResult.totalEffectiveAP,
        breakdown: armorResult.breakdown,
      })
    }

    // Build a chat message summarising all per-location damage on this target.
    const rows = perLocationResults.map(r => {
      const locName = r.location.system?.displayName || r.location.name || '(location)'
      const breakdown = r.breakdown.length
        ? r.breakdown.map(b =>
            b.category === 'none' ? `${b.pieceName} bypassed` :
            b.category === 'half' ? `${b.pieceName} ${b.effectiveAP} AP (half)` :
            b.category === 'corrosive' ? `${b.pieceName} ${b.effectiveAP} AP (corroded)` :
            `${b.pieceName} ${b.effectiveAP} AP`
          ).join('; ')
        : 'no armor'
      return `<li>
        <strong>${locName}:</strong> rolled ${r.rollFormula} = ${r.rollResult} = ${r.rawDamage}
        → after armor (${breakdown}) → <strong>${r.finalDamage}</strong> damage
      </li>`
    }).join('')

    const dmgTypeTag = damageType
      ? `<span class="elysium-cast-damage-type-tag elysium-damage-${damageType}">${damageType}</span>`
      : ''

    const body = `<ul>${rows}</ul>`
    const footer = `<em>GM: apply each final-damage value to the corresponding hit location via the actor sheet's Add Damage button.</em>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
      {
        variant: 'fire',
        title: `${spell.name} → ${targetActor.name} ${dmgTypeTag}`,
        icon: 'wand-magic-sparkles',
        body,
        footer,
      }
    )
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  }
}

