# P5.2 Handoff — Character DataModel

**Audience**: Claude in the next chat session. This doc is the spec — read it, implement against it, smoke-test, ship. Don't re-derive what's already here.

**Context you need**:
- Source tree state: post-P5.1, in the uploaded `files.zip` (system + module zips at top level — see "Packaging convention" at the end of this doc).
- Running Foundry world: `test-2` at `https://elysiumvtt.com/game` (Foundry 14.361, system 1.0.0-alpha.1).
- Read FIRST: `docs/p5-prep-audit.md` (NPC live findings, V14 API confirmations), `docs/datamodel-design.md` P5.2 section (design intent), and the P5.1 implementation in `module/data/actor/npc.mjs` + `module/data/actor/_shared.mjs` (you'll reuse the shared helpers).

## P5.1 status (already shipped, do not redo)

- `module/data/actor/_shared.mjs` — exports `makeStats`, `makeHealth`, `makePower`, `makeFatigue`, `makeActionPoints`, `makeResourcePair`, `STAT_KEYS`
- `module/data/actor/npc.mjs` — `NPCDataModel`, stored-schema-only, 31 schema fields
- `module/hooks/init.mjs` — `CONFIG.Actor.dataModels.npc = NPCDataModel` (in section 3a, after CONFIG.Actor.documentClass)
- Live-verified: NPC create/render/persist/compendium-drop all green, choices validation enforced via `DataModelValidationError`
- Version: `1.0.0-alpha.1` (per the P5 plan — version bump is at P5.2 ship, see below)

## What P5.2 ships

1. `module/data/actor/character.mjs` — `CharacterDataModel extends foundry.abstract.TypeDataModel`, stored-schema-only
2. Update to `module/hooks/init.mjs` — add `CONFIG.Actor.dataModels.character = CharacterDataModel` next to the NPC registration
3. Version bump: `1.0.0-alpha.1` → `1.0.0-alpha.2` in `system.json` (per the original P5 prompt: "bump to alpha.2 for the character DataModel")
4. CHANGELOG.md entry for `[1.0.0-alpha.2]`
5. ROADMAP-v1.0.0.md entry marking P5.2 complete

## Schema spec — implement EXACTLY this

CharacterDataModel uses the same shared helpers as NPC for base-template fields. Sparse-declares the character-side elysium partition (which NPC sparse-skips). Adds character-own fields.

### From base template (use _shared.mjs helpers, same as NPC):

```js
stats:        makeStats(),         // 7 stats × 11 fields each
health:       makeHealth(),        // value/max/mod/mjrwnd/daily — KEEP daily, see P5.1 reason
power:        makePower(),         // value/max/mod — battVal/battMax already dropped
fatigue:      makeFatigue(),       // value/max/mod/level/recoveryType (choices: physical/magical)
actionPoints: makeActionPoints(),  // 10 fields (11 from audit minus _v0140doc)
tempHP:       makeResourcePair(0, 0),
luckPoints:   makeResourcePair(0, 0),
sanity:       makeResourcePair(0, 0),
res5:         makeResourcePair(0, 0),
dmgmodTier:   new fields.StringField({ initial: '+0' }),
wealthValue:  new fields.NumberField({ integer: true, initial: 0 }),
```

These 11 fields are bit-identical to the NPC schema. **Do not duplicate the helper code; import from `./_shared.mjs`.**

### Character-side elysium partition (9 fields NPC sparse-skips)

These are the ones NPC doesn't carry. Live-grepped during P5.2 prep (counts are code occurrences):

```js
elysium: new fields.SchemaField({
  // === KEPT, full schema (grep-confirmed live usage) ===

  // expDice (17 occurrences) — EXP-dice progression resource.
  // Read/written by elysium/actor/stat-improvement.mjs and creation/creation.mjs.
  expDice: new fields.SchemaField({
    available: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    diceSize:  new fields.NumberField({ integer: true, initial: 4 }),
  }),

  // expDiceOverride (3 occurrences in stat-improvement.mjs) — NOT in template.json
  // but actively written via `'system.elysium.expDiceOverride': true/false`.
  // MUST declare or DataModel-strict validation will reject the writes.
  // It's a one-shot boolean consumed by the next stat-improvement roll.
  expDiceOverride: new fields.BooleanField({ initial: false }),

  // buildPoints (8 occurrences) — point-buy pool for character creation.
  buildPoints: new fields.SchemaField({
    total:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    ancestry:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    spent:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    remaining: new fields.NumberField({ integer: true, initial: 0 }),  // can go negative if over-spent
  }),

  // skillPoints (8 occurrences) — same shape as buildPoints.
  skillPoints: new fields.SchemaField({
    total:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    ancestry:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    spent:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    remaining: new fields.NumberField({ integer: true, initial: 0 }),
  }),

  // statNaturalMax (5 occurrences, see SIDE-FINDING #1 below) — keyed-by-stat-name
  // dynamic object. Values are numbers (the natural-max ceiling for each stat).
  // Use TypedObjectField per audit's V14 API recommendation.
  statNaturalMax: new fields.TypedObjectField(
    new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  ),

  // ancestryId (6 occurrences) — DocumentUUIDField is the typed upgrade per
  // the audit's V14 API note, but StringField with initial: '' is also fine
  // and matches existing data shape. Use StringField for minimum risk; can
  // upgrade to DocumentUUIDField in P12 cleanup.
  ancestryId: new fields.StringField({ initial: '' }),

  // creatureType / creatureSubtype / creatureTags / languages — ALSO needed
  // on character (NPC has these; character is a creature too). Same shape:
  creatureType: new fields.StringField({
    initial: 'humanoid',
    choices: ['humanoid', 'beast', 'undead', 'construct',
              'spirit', 'elemental', 'plant', 'aberration'],
  }),
  creatureSubtype: new fields.StringField({ initial: 'human' }),
  creatureTags:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
  languages:       new fields.ArrayField(new fields.StringField(), { initial: [] }),

  // === DROPPED (zero system.elysium readers/writers, grep-confirmed) ===
  //
  // patron, essences, schoolMastery, companion are template.json fields
  // with ZERO live system.elysium.* reads or writes. They were intended for
  // the v0.9.0–v0.20.0 magic/companion subsystems but those subsystems
  // ended up using flags.elysium.* instead (see SIDE-FINDING #1).
  //
  // Drop strategy: do NOT declare. If a future feature needs them, add then.
}),
```

### Character-own fields (22 from template.json)

Grep verdicts:

```js
// === KEPT as-is ===
age:             new fields.NumberField({ integer: true, initial: 0, min: 0 }),
background:      new fields.HTMLField({ initial: '' }),
backstory:       new fields.HTMLField({ initial: '' }),
biography:       new fields.HTMLField({ initial: '' }),
culture:         new fields.StringField({ initial: '' }),
description:     new fields.HTMLField({ initial: '' }),
gender:          new fields.StringField({ initial: '' }),
hand:            new fields.StringField({ initial: 'Right' }),  // no choices — free-text
height:          new fields.StringField({ initial: '' }),
lock:            new fields.BooleanField({ initial: false }),
majorWnd:        new fields.BooleanField({ initial: false }),
minorWnd:        new fields.BooleanField({ initial: false }),
move:            new fields.NumberField({ integer: true, initial: 0 }),
personalityName: new fields.StringField({ initial: '' }),
professionName:  new fields.StringField({ initial: '' }),
religion:        new fields.StringField({ initial: '' }),
skillOrder:      new fields.BooleanField({ initial: true }),  // template default is true
wealth:          new fields.NumberField({ integer: true, initial: 0 }),
weight:          new fields.StringField({ initial: '' }),

// skillcategory: TypedObjectField keyed by skill category id → number.
// Heavy use in actor.mjs, character.mjs, check.mjs (8+ occurrences). The
// dynamic-key pattern is exactly what TypedObjectField is for.
skillcategory: new fields.TypedObjectField(
  new fields.NumberField({ integer: true, initial: 0 }),
),

// stories: ArrayField of {title, value} objects. Each story has a title
// (free-text input) and value (HTML rich-text via prose-mirror).
// Heavy use in character.background.hbs and base-actor-sheet.mjs (7+ sites).
// `enriched`, `isFirst`, `isLast` are derived/template-stamped — NOT stored.
stories: new fields.ArrayField(
  new fields.SchemaField({
    title: new fields.StringField({ initial: '' }),
    value: new fields.HTMLField({ initial: '' }),
  }),
  { initial: [] },
),

// === DROPPED ===
//
// distincitve (note the typo in template.json) — ZERO grep occurrences in
// .mjs or .hbs. Pre-existing dead field. Safe to drop. Do not preserve
// the typo'd name.
```

Total character schema: 11 base + 13 elysium subkeys + 21 own = **45 fields**, well under the audit's "~80 target" because the audit was counting nested subkeys. Actual top-level schema slot count matches the design target.

## init.mjs change

Add right after the NPC registration:

```js
import { NPCDataModel } from '../data/actor/npc.mjs'
import { CharacterDataModel } from '../data/actor/character.mjs'   // NEW

// ... in Init() function, section 3a:
CONFIG.Actor.dataModels.npc       = NPCDataModel
CONFIG.Actor.dataModels.character = CharacterDataModel              // NEW
```

## Smoke-test checklist (run after install)

The same approach P5.1 used worked well. Run these against the live test-2 world via the Claude in Chrome `javascript_tool`:

1. **Boot check**: `CONFIG.Actor.dataModels.character?.name === 'CharacterDataModel'` and schema has 45 expected top-level fields
2. **Create character**: `Actor.create({type: 'character', name: 'P5.2 Smoke Char'})`, confirm `actor.system instanceof CharacterDataModel`
3. **Sheet render**: `await actor.sheet.render(true)`, confirm element in DOM, no exceptions. **WARNING**: don't return DOM refs from the eval — return only primitive scalars (number/boolean/string). Returning DOM refs wedges the Chrome bridge with "Cannot access a chrome-extension:// URL of different extension". This was a recurring P5.1 testing-environment issue, not a Foundry bug.
4. **Persistence roundtrip** on multiple field types:
   - NumberField: `update({'system.move': 12})` → reread → expect 12
   - StringField w/ choices: `update({'system.elysium.creatureType': 'undead'})` → expect persisted
   - StringField w/ invalid choice: `update({'system.elysium.creatureType': 'invalid'})` → expect `DataModelValidationError` in console, value unchanged
   - ArrayField: `update({'system.elysium.languages': ['common']})` → expect persisted
   - HTMLField: `update({'system.biography': '<p>Hello</p>'})` → expect persisted
   - TypedObjectField: `update({'system.skillcategory.combat': 30})` → expect persisted
   - SchemaField nested: `update({'system.elysium.buildPoints.spent': 5})` → expect persisted
5. **Derived data still works**: confirm `actor.system.stats.str.total` is a number (populated by `_prepDerivedStats`), `actor.system.skillcategory` accumulates skill category totals (populated by `actor.mjs:168`)
6. **Compendium content drop**: drop a compendium skill onto the character via `createEmbeddedDocuments`, confirm `elysiumidFlag` preserved (this validates the P4 hotfix still holds on the character path)
7. **NPC unchanged**: create an NPC, confirm it still works (regression check)

## Side findings flagged for ROADMAP / P12

When P5.2 is verified green, add these to the ROADMAP decision log as side findings (do NOT fix during P5.2 — they're orthogonal and would conflate scope):

**SIDE-FINDING #1 — system-vs-flags character-elysium mismatches** (pre-existing, likely from elysium-subsystem integration era; same shape as the P4 brpidFlag mismatch).

Five fields are READ from `flags.elysium.*` but WRITTEN to `system.elysium.*`:

| Field | Read site | Write site |
|---|---|---|
| `patron.standing` | `magic.mjs:204` | `magic.mjs:217` |
| `statNaturalMax` | `ancestry-drop.mjs:352`, `creation.mjs:117,171` | `ancestry-drop.mjs:359,477` |

The READS use `actor.flags?.['elysium']?.X` and the WRITES use `'system.elysium.X'` update keys. These are silent no-ops — the writes go to system, the reads come back undefined from flags, fall through to defaults. The data is being persisted but never read.

The P5.2 CharacterDataModel declaring `system.elysium.statNaturalMax` etc. is the right thing structurally, but doesn't FIX this bug — that requires changing the reads to use `actor.system.elysium.X`. Defer to a dedicated bug-sweep phase or P12 cleanup. Document but don't fix.

**SIDE-FINDING #2 — dropped character-elysium fields are not declared**

`patron`, `essences`, `schoolMastery`, `companion` (with sub-fields like `companion.powSpent`, `companion.companionActorId`) are in template.json's base.elysium but ZERO `system.elysium.X` reads or writes exist. They were apparently planned for the v0.9.0–v0.20.0 magic/companion subsystems but those subsystems ended up using flags. Dropped from CharacterDataModel schema. If a future feature needs them, declare then.

**SIDE-FINDING #3 — `distincitve` typo**

template.json `character.distincitve` (sic — the 'c' and 'i' are swapped). ZERO usage anywhere. Drop without preserving typo. If anyone's character data actually has this field set, it'll be silently dropped during DataModel cleanData.

## Migration concerns (test-2 world)

test-2 is a fresh world with no existing character actors (P5.1 smoke test confirmed `game.actors.size === 0`). P5.2 will be tested against newly-created characters only. Production users with existing characters will need migration support eventually — track this as a P12 concern, not a P5.2 blocker.

## Packaging convention (THIS IS THE PROCESS — DO NOT REINVENT IT)

When you (next Claude) ship a build to the user, present TWO files SIDE BY SIDE at the top level of `/mnt/user-data/outputs/`:

1. `system.json` — copied verbatim from `/home/claude/work/system/system.json`
2. `system.zip` — the contents of `/home/claude/work/system/` packed at the root of the zip (NOT a folder inside the zip)

Use `present_files` to surface both. The exact recipe:

```bash
rm -f /mnt/user-data/outputs/system.zip /mnt/user-data/outputs/system.json
cd /home/claude/work/system
zip -qr /mnt/user-data/outputs/system.zip . -x "*.DS_Store"
cd /home/claude/work
cp system/system.json /mnt/user-data/outputs/system.json
```

Then call `present_files(["/mnt/user-data/outputs/system.json", "/mnt/user-data/outputs/system.zip"])`.

**Do NOT** put the contents under a top-level folder named `system/` inside the zip. The contents (system.json, module/, packs/, etc.) sit at the zip root.

**Do NOT** present only the zip. The user needs both files.

The user has had to correct this packaging twice before. Don't make them do it a third time.

## Stop-and-check-in discipline

P5.2 is the larger of the two P5 ships. The original P5 prompt set up an explicit "stop after P5.1, check in" gate that I (P5.1 Claude) honored.

For P5.2: after the smoke test verifies green, STOP before P5.3 (Acceptance) or P6 (Item DataModels). Capture a visual-regression baseline via the test/visual-regression/ harness if the user wants one. Update CHANGELOG and ROADMAP. Then check in with the user.

P5.3 and P6 are subsequent phases; don't roll them in.

## Quick orientation for the next Claude

1. `view /home/claude/work/system/` (extract files.zip first)
2. `view /home/claude/work/system/docs/p5-2-handoff.md` ← you're reading it
3. `view /home/claude/work/system/module/data/actor/npc.mjs` ← copy the structure
4. `view /home/claude/work/system/module/data/actor/_shared.mjs` ← import these helpers
5. Write `character.mjs` per the spec above
6. Edit `init.mjs` to register the character DataModel
7. Bump `system.json` version to 1.0.0-alpha.2
8. Add CHANGELOG entry under `[1.0.0-alpha.2]`
9. Add ROADMAP entry marking P5.2 complete
10. `node --check` sweep (expect 161/161 after adding character.mjs)
11. Pack via the packaging convention above
12. Smoke-test via Claude in Chrome
13. STOP and check in

Estimated effort: 30–45 minutes for a clean session that follows this spec.
