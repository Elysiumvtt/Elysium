import { ElysiumOptionalRuleSettings } from './settings-optional-rules.mjs'
import { ElysiumDiceSettings } from './settings-dice.mjs'
import { ElysiumCombatRuleSettings } from './settings-combat.mjs'
import { ElysiumXPSettings } from './settings-xp.mjs'
import { ElysiumNPCSettings } from './settings-npc.mjs'
import { ElysiumCharSettings } from './settings-character.mjs'
import { ElysiumDisplaySettings } from './settings-display.mjs'
import { ElysiumIDSettings } from './settings-elysiumid.mjs'

export async function registerSettings() {

  //Game Settings Menu Buttons-----------------------------------------------
  // v0.20.0: Power Rules menu removed — its three toggles (mutation/sorcery/super)
  // duplicated Elysium's per-tradition magic toggles, and those have themselves
  // been deleted as the campaign-level magic gate. Power sources are now gated
  // by what's available in the compendium.

  //Optional Rules Menu Button
  game.settings.registerMenu('elysium', 'optionalRules', {
    name: 'Elysium.Settings.optionalRulesHint',
    label: 'Elysium.Settings.optionalRules',
    icon: 'fas fa-book',
    type: ElysiumOptionalRuleSettings,
    restricted: true
  })
  ElysiumOptionalRuleSettings.registerSettings()

  //Dice Options Menu Button
  game.settings.registerMenu('elysium', 'diceOptions', {
    name: 'Elysium.Settings.diceOptionsHint',
    label: 'Elysium.Settings.diceOptions',
    icon: 'fas fa-dice',
    type: ElysiumDiceSettings,
    restricted: true
  })
  ElysiumDiceSettings.registerSettings()

  //Combat Options Menu Button
  game.settings.registerMenu('elysium', 'combatOptions', {
    name: 'Elysium.Settings.combatOptionsHint',
    label: 'Elysium.Settings.combatOptions',
    icon: 'fas fa-swords',
    type: ElysiumCombatRuleSettings,
    restricted: true
  })
  ElysiumCombatRuleSettings.registerSettings()

  //XP Options Menu Button
  game.settings.registerMenu('elysium', 'xpOptions', {
    name: 'Elysium.Settings.xpOptionsHint',
    label: 'Elysium.Settings.xpOptions',
    icon: 'fas fa-file-certificate',
    type: ElysiumXPSettings,
    restricted: true
  })
  ElysiumXPSettings.registerSettings()

  //NPC Options Menu Button
  game.settings.registerMenu('elysium', 'npcOptions', {
    name: 'Elysium.Settings.npcOptionsHint',
    label: 'Elysium.Settings.npcOptions',
    icon: 'fas fa-hood-cloak',
    type: ElysiumNPCSettings,
    restricted: true
  })
  ElysiumNPCSettings.registerSettings()

  //Character Options Menu Button
  game.settings.registerMenu('elysium', 'charOptions', {
    name: 'Elysium.Settings.charOptionsHint',
    label: 'Elysium.Settings.charOptions',
    icon: 'fas fa-helmet-battle',
    type: ElysiumCharSettings,
    restricted: true
  })
  ElysiumCharSettings.registerSettings()

  // v0.20.0: gameMods menu (hpMod) removed — Elysium uses `hpMultiplier`
  // (registered by the elysium subsystem) instead.

  //Display Settings Button
  game.settings.registerMenu('elysium', 'displayOptions', {
    name: 'Elysium.Settings.displayOptionsHint',
    label: 'Elysium.Settings.displayOptions',
    icon: 'fas fa-palette',
    type: ElysiumDisplaySettings,
    restricted: true
  })
  ElysiumDisplaySettings.registerSettings()

  //ElysiumID Settings Button
  game.settings.registerMenu('elysium', 'elysiumidOptions', {
    name: 'Elysium.Settings.elysiumidOptionsHint',
    label: 'Elysium.Settings.elysiumidOptions',
    icon: 'fas fa-fingerprint',
    type: ElysiumIDSettings,
    restricted: true
  })
  ElysiumIDSettings.registerSettings()

  //Individual Game Settings---------------------------------------------------
  game.settings.register('elysium', "switchShift", {
    name: "Elysium.Settings.switchShift",
    hint: "Elysium.Settings.switchShiftHint",
    scope: "client",
    config: true,
    type: Boolean,
    default: false
  });

  game.settings.register('elysium', "defaultTab", {
    name: "Elysium.Settings.defaultTab",
    hint: "Elysium.Settings.defaultTabHint",
    scope: "client",
    config: true,
    type: Boolean,
    default: false
  });

  //Invisible Game Settings----------------------------------------------------
  game.settings.register('elysium', "development", {
    name: "",
    hint: "",
    scope: "world",
    requiresReload: false,
    config: false,
    type: Boolean,
    default: false
  });

  // v0.20.0: 'beastiary' setting removed — was an alternate HP code path
  // alongside useHPL. Both forced true in the Elysium fork; the cleanup
  // hardcodes per-location HP semantics, making both flags redundant.

  // v0.21.0: 'gameVersion' setting removed — gated the dead BRP-classic
  // 13.1.53 migration in module/setup/update.mjs (also deleted). Per the
  // v0.20.0 design decision ("new world required, no migration"), the
  // migration path was never useful for Elysium users.

}

