// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { getSetting } from '../../settings/register-settings.mjs'

export function extendStatisticsTab (html, actor) {
    const grid = html.querySelector('.personal-stats-grid')
    if (!grid) return

    // Replace the Total XP cell value with EXP Dice (core mechanic v0.20.0)
    replaceTotalXPWithExpDice(grid, actor)

    // Remove any previous Elysium injections (avoid duplicates on re-render)
    grid.querySelectorAll('[data-elysium-row]').forEach(el => el.remove())

    // Collect Elysium stats to display, then render two per row
    const stats = []
    const hr = getHealingRateStat(actor)
    if (hr) stats.push(hr)
    const luck = getLuckPointsStat(actor)
    if (luck) stats.push(luck)
    const fatigue = getFatigueStat(actor)
    if (fatigue) stats.push(fatigue)
    // Casting Penalty is no longer rendered on the CHAR tab — it's a derivative
    // effect of worn armor or active effects, so it appears as a chip in the
    // Conditions panel on the Combat tab via _injectConditionsPanel instead.

    // Render in pairs (5-cell grid: leftLabel + leftValue + spacer + rightLabel + rightValue)
    for (let i = 0; i < stats.length; i += 2) {
      const left = stats[i]
      const right = stats[i + 1]
      appendStatPairRow(grid, left, right)
    }
  }

export function appendStatPairRow (grid, left, right) {
    if (!left) return

    const cells = []
    // Left side: label cell with new-row class to start a fresh grid row
    cells.push(makeLabelCell(left.label, true, left.tooltip, left.kind))
    cells.push(makeValueCell(left.value, left.tooltip, left.kind))
    // Spacer (empty div)
    const spacer = document.createElement('div')
    spacer.dataset.elysiumRow = left.kind
    cells.push(spacer)
    // Right side: label cell + value cell (or empty placeholders)
    if (right) {
      cells.push(makeLabelCell(right.label, false, right.tooltip, right.kind))
      cells.push(makeValueCell(right.value, right.tooltip, right.kind))
    } else {
      const empty1 = document.createElement('div')
      empty1.dataset.elysiumRow = left.kind
      cells.push(empty1)
      const empty2 = document.createElement('div')
      empty2.dataset.elysiumRow = left.kind
      cells.push(empty2)
    }

    for (const c of cells) grid.appendChild(c)
  }

export function makeLabelCell (text, isNewRow, tooltip, kind) {
    const div = document.createElement('div')
    div.className = isNewRow ? 'new-row bold' : 'bold'
    div.textContent = text
    if (tooltip) div.dataset.tooltip = tooltip
    div.dataset.elysiumRow = kind
    return div
  }

export function makeValueCell (value, tooltip, kind) {
    const div = document.createElement('div')
    div.className = 'attrib-disp centre'
    div.textContent = ` ${value}`
    if (tooltip) div.dataset.tooltip = tooltip
    div.dataset.elysiumRow = kind
    return div
  }

export function getHealingRateStat (actor) {
    if (!getSetting('enableMythrasHealingRate', true)) return null
    const hr = actor.flags?.['elysium']?.derived?.healingRate
    if (hr === undefined || hr === null) return null
    return {
      kind: 'healingRate',
      label: game.i18n.localize('Elysium.HealingRate.Title'),
      value: String(hr),
      tooltip: game.i18n.localize('Elysium.HealingRate.Tooltip'),
    }
  }

export function getLuckPointsStat (actor) {
    if (!getSetting('enableLuckPoints', true)) return null
    const luck = actor.system?.luckPoints
    if (!luck) return null
    return {
      kind: 'luckPoints',
      label: game.i18n.localize('Elysium.Luck.Title'),
      value: `${luck.value || 0} / ${luck.max || 0}`,
      tooltip: game.i18n.localize('Elysium.Luck.Tooltip'),
    }
  }

export function getFatigueStat (actor) {
    if (!getSetting('showFatigueOnSheet', true)) return null
    const fat = actor.system?.fatigue
    if (!fat) return null
    const fatData = ELYSIUM.FATIGUE_LEVELS[fat.level || 0] || ELYSIUM.FATIGUE_LEVELS[0]
    return {
      kind: 'fatigue',
      label: game.i18n.localize('Elysium.Fatigue.Title'),
      value: game.i18n.localize(`Elysium.Fatigue.Levels.${fatData.label}`),
      tooltip: `${game.i18n.localize('Elysium.Fatigue.LevelLabel')}: ${fat.level || 0} / 9`,
    }
  }

export function replaceTotalXPWithExpDice (grid, actor) {
    const exp = actor.system?.elysium?.expDice
    const available = exp?.available || 0
    const diceSize = exp?.diceSize || 4

    // Find the label cell containing 'totalXP' or its localised form,
    // then the immediately following cell which holds the value.
    const labels = grid.querySelectorAll('.bold')
    for (const label of labels) {
      const text = label.textContent?.trim()
      if (!text) continue

      // BRP-base localised "Total XP" — we relabel this via i18n elsewhere.
      // Match either the original or any of our possible relabels.
      if (/total\s*xp/i.test(text) || /exp\s*dice/i.test(text)) {
        // Replace label text content directly to ensure it shows our term
        label.textContent = game.i18n.localize('Elysium.Exp.Title')

        // Find the next sibling that's the value cell
        const valueCell = label.nextElementSibling
        if (valueCell?.classList.contains('attrib-disp')) {
          valueCell.textContent = ` ${available}d${diceSize}`
          valueCell.dataset.tooltip = game.i18n.localize('Elysium.Exp.Tooltip')
          valueCell.classList.add('elysium-exp-cell')
        }
        return
      }
    }
  }
