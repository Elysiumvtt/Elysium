/**
 * Elysium init handler — runs during Foundry's `init` hook.
 *
 * Responsibilities:
 *   - Register the core settings (combat, dice, display, NPC, character,
 *     optional-rules, XP, ElysiumID menus).
 *   - Define the system's custom document classes (Actor, Item, Combat,
 *     ActiveEffect) and combat tracker.
 *   - Register Handlebars helpers and the eight item-type sheets.
 *   - Initialize subsystems: ElysiumCanvasInterface, ElysiumID.
 *   - Expose the cross-package casting + combat APIs on `game.system.api`
 *     so external code (macros, modules) can call into them without
 *     importing module-internal files.
 *
 * The Elysium subsystem (`module/elysium/elysium.mjs`) registers its own
 * `init` hook separately and extends `game.system.api.elysium` similarly.
 */

import { registerSheets } from '../setup/register-sheets.mjs'
import { ElysiumID } from '../elysiumid/elysiumid.mjs'
import { ElysiumActor } from '../actor/actor.mjs'
import { ElysiumItem } from '../item/item.mjs'
import { NPCDataModel } from '../data/actor/npc.mjs'
import { CharacterDataModel } from '../data/actor/character.mjs'
import { WoundDataModel }       from '../data/item/wound.mjs'
import { ReputationDataModel }  from '../data/item/reputation.mjs'
import { FailingDataModel }     from '../data/item/failing.mjs'
import { PowerModDataModel }    from '../data/item/powerMod.mjs'
import { SkillcatDataModel }    from '../data/item/skillcat.mjs'
import { PersonalityDataModel } from '../data/item/personality.mjs'
import { PassionDataModel }     from '../data/item/passion.mjs'
import { PersTraitDataModel }   from '../data/item/persTrait.mjs'
import { AllegianceDataModel }  from '../data/item/allegiance.mjs'
import { MutationDataModel }    from '../data/item/mutation.mjs'
import { SuperDataModel }       from '../data/item/super.mjs'
import { AbilityDataModel }     from '../data/item/ability.mjs'
import { GearDataModel }        from '../data/item/gear.mjs'
import { CultureDataModel }     from '../data/item/culture.mjs'
import { HitLocationDataModel } from '../data/item/hit-location.mjs'
import { ArmorDataModel }       from '../data/item/armor.mjs'
import { WeaponDataModel }      from '../data/item/weapon.mjs'
import { DivineDataModel }      from '../data/item/divine.mjs'
import { MysticismDataModel }   from '../data/item/mysticism.mjs'
import { ArcaneDataModel }      from '../data/item/arcane.mjs'
import { SorceryDataModel }     from '../data/item/sorcery.mjs'
import { CareerDataModel }  from '../data/item/career.mjs'
import { SkillDataModel }       from '../data/item/skill.mjs'
import { Elysium } from '../setup/config.mjs'
import ElysiumCanvasInterfaceInit from '../apps/elysium-canvas-interface-init.mjs'
import { registerSettings } from '../settings/register-settings.mjs'
import { handlebarsHelper } from '../setup/handlebar-helper.mjs'
import { ElysiumCombat } from '../combat/combat.mjs'
import { ElysiumCombatTracker } from '../combat/combat-tracker.mjs'
import { ElysiumActiveEffect } from '../apps/active-effect.mjs'
import { ElysiumCheck } from '../apps/check.mjs'

// v0.19.0: cross-tradition damage-vs-armor resolution.
import {
  applyArmorToDamage,
  formatArmorBreakdownHTML,
  rollRandomHitLocation,
  rollMultipleHitLocations,
} from '../combat/armor-vs-damage.mjs'

// v0.9.0+: casting subsystem.
import { beginArcaneCast, spendCastAP, abandonCast, repostCastCard } from '../casting/arcane-cast.mjs'
import { castDivine, beginDivineCast, spendDivineCastAP, abandonDivineCast, maxCastableTier } from '../casting/divine-cast.mjs'
import { castSorcery, beginSorceryCast, maxCastableSorceryTier } from '../casting/sorcery-cast.mjs'
import { castMysticism } from '../casting/mysticism-cast.mjs'
import {
  refundPP,
  computeSL,
  classifyRoll,
  manipulationCost,
  manipulationDiscount,
  summariseManipulation,
  MANIPULATION_BASE_COST,
  clearProactiveAPGate,
  hasSpentProactiveAP,
} from '../casting/cast-shared.mjs'
import { openManipulationDialog } from '../casting/manipulation-dialog.mjs'
import {
  addSustain,
  removeSustain,
  runSustainUpkeep,
  disruptSustain,
  getActiveSustains,
} from '../casting/sustain.mjs'
import { learnArcaneSpell } from '../casting/spell-learning.mjs'

// v0.16.0: active-cast disruption (Willpower save → SL loss when wizard
// takes damage mid-cast) + live custom-spell builder.
import {
  checkActiveCastDisruption,
  applyDisruptionRoll,
  classifyWoundSeverity,
  slLossForSeverity,
  findWillpowerSkill,
} from '../casting/cast-disruption.mjs'
import { CustomSpellBuilder } from '../casting/custom-spell-builder.mjs'

export default function Init () {
  // 1. Globals — accessible via `game.elysium.*` from macros and elsewhere.
  game.elysium = {
    ElysiumActor,
    ElysiumItem,
    rollItemMacro,
    rollCharMacro,
    ClickRegionLeftUuid:  ElysiumCanvasInterfaceInit.ClickRegionLeftUuid,
    ClickRegionRightUuid: ElysiumCanvasInterfaceInit.ClickRegionRightUuid,
  }
  CONFIG.Elysium = Elysium

  // 2. Settings & Handlebars helpers (must run before any sheet renders).
  registerSettings()
  handlebarsHelper()

  // 2a. Shared Handlebars partials (P9 cluster 1, alpha.30+). Sheet PARTS
  //     auto-register as partials when their PART template renders, but
  //     SHARED sub-partials invoked via `{{> "path"}}` inside other
  //     templates have no PART entry and must be pre-loaded. Without this
  //     call, the consuming tab fails to render with
  //     "The partial ... could not be found".
  //
  //     New shared partials are added here as P9/P10/P11 introduce them.
  //     Returns a promise; we don't await it — `loadTemplates` resolves
  //     well before any sheet render in normal Foundry boot order
  //     (init → ready → sheet open), but we DO want any registration
  //     errors to surface in console.
  foundry.applications.handlebars.loadTemplates([
    'systems/elysium/templates/actor/parts/tab-section-card-header.hbs',
    'systems/elysium/templates/actor/parts/improve-checkbox.hbs',
    'systems/elysium/templates/actor/parts/section-card-header-button.hbs',
    // Cluster 2 (alpha.32) — combat tab partials
    'systems/elysium/templates/actor/parts/weapon-row.hbs',
    'systems/elysium/templates/actor/parts/hit-location-row.hbs',
    'systems/elysium/templates/actor/parts/wound-badge.hbs',
    'systems/elysium/templates/actor/parts/chip-range.hbs',
    'systems/elysium/templates/actor/parts/hp-progress.hbs',
    // Cluster 3 (alpha.33) — items + social + pers partials
    'systems/elysium/templates/actor/parts/armor-group-header.hbs',
    'systems/elysium/templates/actor/parts/armor-row.hbs',
    'systems/elysium/templates/actor/parts/gear-row.hbs',
    'systems/elysium/templates/actor/parts/coinage-card.hbs',
    'systems/elysium/templates/actor/parts/allegiance-row.hbs',
    'systems/elysium/templates/actor/parts/reputation-row.hbs',
    'systems/elysium/templates/actor/parts/passion-row.hbs',
    'systems/elysium/templates/actor/parts/pers-trait-row.hbs',
    // Cluster 4 (alpha.35) — background tab partial
    'systems/elysium/templates/actor/parts/story-section.hbs',
    // Cluster 5 (alpha.36) — magic tab partials
    'systems/elysium/templates/actor/parts/magic/magic-skill-summary.hbs',
    'systems/elysium/templates/actor/parts/magic/spell-row.hbs',
    'systems/elysium/templates/actor/parts/magic/arcane-body.hbs',
    'systems/elysium/templates/actor/parts/magic/divine-body.hbs',
    'systems/elysium/templates/actor/parts/magic/mysticism-body.hbs',
    'systems/elysium/templates/actor/parts/magic/sorcery-body.hbs',
    // Cluster 5 (alpha.36) — super tab partials
    'systems/elysium/templates/actor/parts/super-row.hbs',
    'systems/elysium/templates/actor/parts/failing-row.hbs',
    // Cluster 5 (alpha.37) — consolidated Magic sub-tab strip
    'systems/elysium/templates/actor/parts/magic-subtab-strip.hbs',
    // P10 cluster 1 (alpha.38) — item-sheet shell partials + utilities
    'systems/elysium/templates/item/parts/item-shell-header.hbs',
    'systems/elysium/templates/item/parts/item-shell-tabs.hbs',
    'systems/elysium/templates/item/parts/item-shell-description.hbs',
    'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs',
    'systems/elysium/templates/item/parts/item-shell-effects.hbs',
    'systems/elysium/templates/item/parts/item-field-row.hbs',
    'systems/elysium/templates/item/parts/item-field-grid.hbs',
    'systems/elysium/templates/item/parts/item-chip.hbs',
    'systems/elysium/templates/item/parts/item-section-card.hbs',
    // P10 cluster 2 (alpha.39) — single-page inline partials
    'systems/elysium/templates/item/parts/item-singlepage-description.hbs',
    'systems/elysium/templates/item/parts/item-singlepage-effects.hbs',
    // P10 cluster 3b (alpha.41) — specialism header variant + shared skill row
    'systems/elysium/templates/item/parts/item-shell-header-specialism.hbs',
    'systems/elysium/templates/item/parts/item-skill-row.hbs',
    // P10 cluster 4 (alpha.42) — toggle row + AP grid + tier-effect row
    'systems/elysium/templates/item/parts/item-toggle-row.hbs',
    'systems/elysium/templates/item/parts/item-ap-grid.hbs',
    'systems/elysium/templates/item/parts/item-tier-effect-row.hbs',
    // P11 cluster 1 (alpha.45) — shared chat-card partials
    'systems/elysium/templates/chat/parts/chat-card-shell.hbs',
    'systems/elysium/templates/chat/parts/chat-card-participant-row.hbs',
    'systems/elysium/templates/chat/parts/chat-card-success-pip.hbs',
    'systems/elysium/templates/chat/parts/chat-card-tooltip-rows.hbs',
    'systems/elysium/templates/chat/parts/chat-card-resolve-footer.hbs',
    // P11 cluster 2 (alpha.46) — group-roll quartet shared body
    'systems/elysium/templates/chat/parts/chat-card-grouproll.hbs',
    // P11 cluster 4 (alpha.48) — actor-list micro-card shared shell (XP-result + rollStats)
    'systems/elysium/templates/chat/parts/chat-card-actor-list.hbs',
    // P11 cluster 5 (alpha.49) — dialog row shared shell (9 of 10 cluster-5 dialogs)
    'systems/elysium/templates/dialog/parts/dialog-row.hbs',
    // P12 cluster 2 (alpha.52) — 3 archetypes covering 45 inline-HTML ChatMessage.create migrations
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
    'systems/elysium/templates/chat/parts/chat-card-prompt.hbs',
  ]).catch(err => {
    console.error('Elysium | Failed to pre-load shared partials:', err)
  })

  // 3. Document classes. Foundry instantiates these whenever it constructs
  //    an Actor/Item/etc. — must be set before any documents load.
  CONFIG.Actor.documentClass        = ElysiumActor
  CONFIG.Item.documentClass         = ElysiumItem
  CONFIG.Combat.documentClass       = ElysiumCombat
  CONFIG.ui.combat                  = ElysiumCombatTracker
  CONFIG.ActiveEffect.documentClass = ElysiumActiveEffect

  // 3a. DataModels. P5.1 ships the NPC DataModel and P5.2 ships the
  //     Character DataModel — both stored-schema-only.
  //     ElysiumActor.prepareDerivedData continues to populate derived
  //     fields (label/total/deriv/visible/skillcategory).
  //     P6.1 adds the six trivial item DataModels (wound, reputation,
  //     failing, powerMod, skillcat, personality).
  //     P6.2 adds the eight standard-complexity item DataModels (passion,
  //     persTrait, allegiance, mutation, super, ability, gear, culture).
  //     P6.3 adds the three combat-item DataModels (hit-location, armor,
  //     weapon). P6.4 adds the four magic-item DataModels (divine,
  //     mysticism, arcane, sorcery) — the deepest schemas in the system
  //     (sorcery alone has ~38 slots). P6.5 adds the final two item types
  //     (career, skill) — 23 of 23 item types complete.
  //     ElysiumItem.prepareData and per-sheet _prepareContext continue
  //     to populate item-side derived fields.
  CONFIG.Actor.dataModels.npc       = NPCDataModel
  CONFIG.Actor.dataModels.character = CharacterDataModel

  CONFIG.Item.dataModels.wound       = WoundDataModel
  CONFIG.Item.dataModels.reputation  = ReputationDataModel
  CONFIG.Item.dataModels.failing     = FailingDataModel
  CONFIG.Item.dataModels.powerMod    = PowerModDataModel
  CONFIG.Item.dataModels.skillcat    = SkillcatDataModel
  CONFIG.Item.dataModels.personality = PersonalityDataModel

  CONFIG.Item.dataModels.passion     = PassionDataModel
  CONFIG.Item.dataModels.persTrait   = PersTraitDataModel
  CONFIG.Item.dataModels.allegiance  = AllegianceDataModel
  CONFIG.Item.dataModels.mutation    = MutationDataModel
  CONFIG.Item.dataModels.super       = SuperDataModel
  CONFIG.Item.dataModels.ability     = AbilityDataModel
  CONFIG.Item.dataModels.gear        = GearDataModel
  CONFIG.Item.dataModels.culture     = CultureDataModel

  CONFIG.Item.dataModels['hit-location'] = HitLocationDataModel
  CONFIG.Item.dataModels.armor           = ArmorDataModel
  CONFIG.Item.dataModels.weapon          = WeaponDataModel

  CONFIG.Item.dataModels.divine     = DivineDataModel
  CONFIG.Item.dataModels.mysticism  = MysticismDataModel
  CONFIG.Item.dataModels.arcane     = ArcaneDataModel
  CONFIG.Item.dataModels.sorcery    = SorceryDataModel

  CONFIG.Item.dataModels.career = CareerDataModel
  CONFIG.Item.dataModels.skill      = SkillDataModel

  // Active Effects are never copied to the Actor, but still apply from
  // within the Item if `transfer === true` on the effect.
  CONFIG.ActiveEffect.legacyTransferral = true

  // 4. Subsystems with their own init steps.
  ElysiumCanvasInterfaceInit.initSelf()
  ElysiumID.init()

  // 5. Public API surface. The Elysium subsystem appends its own
  //    `game.system.api.elysium` slot from its own init hook.
  game.system.api = {
    ...(game.system.api ?? {}),
    casting: _buildCastingApi(),
    combat:  _buildCombatApi(),
  }

  // 6. Sheet registration. Runs last so that any sheet that consults
  //    `game.elysium` or `CONFIG.Elysium` during construction finds them ready.
  registerSheets()
}

// === API builders =================================================
// Split out so the Init function stays narrow and the API shape is
// easy to spot. The contents are flat property bags — every entry is a
// function or constant imported above.

function _buildCastingApi () {
  return {
    // Arcane casting (v0.9.0).
    beginArcaneCast,
    spendCastAP,
    abandonCast,
    repostCastCard,

    // Divine casting (v0.18.0 multi-AP pipeline).
    castDivine,
    beginDivineCast,
    spendDivineCastAP,
    abandonDivineCast,
    maxCastableTier,

    // Sorcery (v0.19.0 tier-based pipeline).
    castSorcery,
    beginSorceryCast,
    maxCastableSorceryTier,

    // Mysticism (single-call).
    castMysticism,

    // Shared cast utilities.
    refundPP,
    computeSL,
    classifyRoll,

    // Manipulation dialog + cost computation (v0.10.0).
    manipulationCost,
    manipulationDiscount,
    summariseManipulation,
    MANIPULATION_BASE_COST,
    openManipulationDialog,

    // Sustained spells (v0.10.0).
    addSustain,
    removeSustain,
    runSustainUpkeep,
    disruptSustain,
    getActiveSustains,

    // Spell learning (v0.10.0).
    learnArcaneSpell,

    // Proactive-AP-per-turn gate (v0.10.2).
    clearProactiveAPGate,
    hasSpentProactiveAP,

    // Active-cast disruption (v0.16.0).
    checkActiveCastDisruption,
    applyDisruptionRoll,
    classifyWoundSeverity,
    slLossForSeverity,
    findWillpowerSkill,

    // Live custom-spell builder (v0.16.0).
    openCustomSpellBuilder: actor => CustomSpellBuilder.open(actor),
  }
}

function _buildCombatApi () {
  return {
    applyArmorToDamage,
    formatArmorBreakdownHTML,
    // Hit-location targeting (v0.19.0 Phase D-2).
    rollRandomHitLocation,
    rollMultipleHitLocations,
  }
}

// === Macro helpers ================================================
// Wired into `game.elysium` above so hotbar item drops can roll items by uuid.

function rollItemMacro (itemUuid) {
  Item.fromDropData({ type: 'Item', uuid: itemUuid }).then(item => {
    if (!item || !item.parent) {
      const name = item?.name ?? itemUuid
      ui.notifications.warn(`Could not find item ${name}. You may need to delete and recreate this macro.`)
      return
    }
    item.roll()
  })
}

function rollCharMacro (actor, characteristic) {
  ElysiumCheck._trigger({
    rollType:      'CH',
    cardType:      'NO',
    characteristic,
    shiftKey:      'false',
    actor,
    token:         '',
  })
}
