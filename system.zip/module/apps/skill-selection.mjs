import ElysiumDialog from '../setup/elysium-dialog.mjs'

export class SkillsSelectDialog extends ElysiumDialog {

  _onRender(context, _options) {
    this.element.querySelectorAll('.select.rollable').forEach(n => n.addEventListener("click", this._onSelectClicked.bind(this)))
  }

  async _onSelectClicked(event) {
    const chosen = event.currentTarget.closest('.mediumIcon')
    const choice = chosen.dataset.set
    let change = 1
    if (this.options.data.selectOptions[choice].selected) change = -1
    //Don't allow spend over picks
    if (this.options.data.added + change <= this.options.data.picks) {
      //Update points spent and the stats value on the form
      const form = event.currentTarget.closest('.skill-select')
      const divCount = form.querySelector('.count')
      const selected = form.querySelector('.item-' + choice)
      if (this.options.data.selectOptions[choice].selected) {
        this.options.data.selectOptions[choice].selected = false
        selected.innerHTML = '<a><i class="fa-regular fa-square"></i> </a>'
      } else {
        this.options.data.selectOptions[choice].selected = true
        selected.innerHTML = '<a><i class="fa-regular fa-square-check"></i> </a>'
      }
      //Change the points spent
      this.options.data.added = await (this.options.data.selectOptions.filter(option => (option.selected))).length
      divCount.innerText = this.options.data.added
    }
  }

  static async create(selectOptions, picks, type) {
    const destination = 'systems/elysium/templates/dialog/skillSelect.hbs';
    const winTitle = game.i18n.format("Elysium.selectItem", { type: type });
    for (let option of selectOptions) {
      option.selected = false
    }
    const data = {
      selectOptions,
      picks,
      added: 0
    }
    const html = await foundry.applications.handlebars.renderTemplate(destination, data);

    return new Promise(resolve => {
      // SkillsSelectDialog.wait keeps the dialog open when the user hasn't
      // picked enough skills (button.disabled=true + closeOnSubmit=false).
      // Once the pick count matches, the callback flips closeOnSubmit=true
      // and resolves with the selected array. This wrapper-Promise pattern
      // is preserved (not converted to await DialogV2.wait) because the
      // "stay open until enough picks" semantics rely on a callback that
      // doesn't always close — DialogV2.wait would resolve on any button
      // press regardless. v0.21.0 audit confirmed this is the correct shape.
      SkillsSelectDialog.wait(
        {
          window: { title: winTitle },
          form: {closeOnSubmit: false },
          title: winTitle,
          content: html,
          data,
          buttons:[{
            label: game.i18n.localize("Elysium.confirm"),
            callback: (event, button, dialog) => {
              if (dialog.options.data.added < dialog.options.data.picks) {
                button.disabled = true
              } else {
              dialog.options.form.closeOnSubmit = true
              const selected = dialog.options.data.selectOptions.filter(option => (option.selected))
              return resolve(selected)
              }
            }
          }],
        }
      )

    })
  }
}
