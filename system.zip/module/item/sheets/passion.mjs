import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumPassionSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['passion'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template: 'systems/elysium/templates/item/passion.detail.hbs',
      scrollable: ['']
    },
  }

  static TAB_ORDER = null

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const itemData = context.item
    itemData.system.total = (itemData.system.base ?? 0) + (itemData.system.xp ?? 0);

    // Header chips per c2-2 lock — Base + XP + Total when owned.
    const chips = [];
    if (context.hasOwner) {
      chips.push(
        { label: game.i18n.localize('Elysium.base'), value: String(this.item.system.base ?? 0) },
        { label: game.i18n.localize('Elysium.xp'), value: String(this.item.system.xp ?? 0) },
        { label: game.i18n.localize('Elysium.total'), value: String(this.item.system.total ?? 0) },
      );
    }
    context.itemHeaderChips = chips;

    return context
  }

  _onRender(context, _options) {
  }
}
