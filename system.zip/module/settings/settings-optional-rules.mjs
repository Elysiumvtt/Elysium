// =============================================================================
// Elysium: Optional Rules settings (v0.20.0)
// =============================================================================
//
// Hardcoded-on (deleted as toggleable settings; assumed true everywhere):
//   - useHPL        per-location HP is core to Mythras combat
//   - usePassion    passions support Faith / cultural identity
//   - usePersTrait  personality traits are core character data
//   - useAlleg      allegiance is how Faith is modelled
//
// Deleted entirely (Elysium uses a fixed terminology, no overrides needed):
//   - useEDU            (Elysium has 7 stats; EDU is not one of them)
//   - hpLabelLong/Short, ppLabelLong/Short, fpLabelLong/Short,
//     sanLabelLong/Short, res5LabelLong/Short, sanLabelLoss
//     The system uses fixed localized strings via the Ancestry relabel module.
//
// v0.20.0: useFP deleted. Elysium uses the Mythras fatigue ladder
// (exposed via the elysium subsystem CHAR-tab panel); the BRP-classic
// flat fatigue points pool was a parallel system on the same actor and
// double-bookkeeping for the same exhaustion concept. Bleeding writes
// to Mythras fatigue per Mythras p72.
// Kept: useSAN, useRes5, skillBonus, useAVRand, useReputation.

const SETTINGS = {

  useSAN: {
    name: 'Elysium.Settings.useSAN',
    hint: 'Elysium.Settings.useSANHint',
    scope: 'world',
    config: false,
    default: false,
    type: Boolean
  },

  useRes5: {
    name: 'Elysium.Settings.useRes5',
    hint: 'Elysium.Settings.useRes5Hint',
    scope: 'world',
    config: false,
    default: false,
    type: Boolean
  },

  skillBonus: {
    name: "Elysium.Settings.skillBonus",
    hint: "Elysium.Settings.skillBonusHint",
    scope: "world",
    config: false,
    type: String,
    default: 0
  },

  useAVRand: {
    name: 'Elysium.Settings.useAVRand',
    hint: 'Elysium.Settings.useAVRandHint',
    scope: 'world',
    config: false,
    default: false,
    type: Boolean
  },

  useReputation: {
    name: 'Elysium.Settings.useReputation',
    hint: 'Elysium.Settings.useReputationHint',
    scope: 'world',
    config: false,
    default: 0,
    type: String
  }
}

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api
export class ElysiumOptionalRuleSettings extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'rulesmenu'],
    id: 'char-settings',
    actions: {
      reset: ElysiumOptionalRuleSettings.onResetDefaults,
    },
    form: {
      handler: ElysiumOptionalRuleSettings.formHandler,
      closeOnSubmit: true,
      submitOnChange: false
    },
    position: {
      width: 550,
      height: 'auto',
    },
    tag: 'form',
    window: {
      resizable: true,
      title: 'Elysium.systemSettings',
      contentClasses: ["standard-form"]
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/settings/optional-settings.hbs',
            scrollable: ['']
     },
    footer: { template: 'templates/generic/form-footer.hbs' }
  }

  async _prepareContext(options) {
    const isGM = game.user.isGM;
    const optSet = {}
    for (const [k, v] of Object.entries(SETTINGS)) {
      optSet[k] = {
        value: game.settings.get('elysium', k),
        setting: v
      }
    }
    optSet.skillBonusList = {
      "0": game.i18n.localize('Elysium.none'),
      "1": game.i18n.localize('Elysium.simple'),
      "2": game.i18n.localize('Elysium.advanced')
    }

    optSet.useRepList = {
      "0": game.i18n.localize('Elysium.none'),
      "1": game.i18n.localize('Elysium.single'),
      "2": game.i18n.localize('Elysium.multiple'),
    }
    return {
      isGM,
      optSet,
      buttons: [
        { type: "submit", icon: "fa-solid fa-save", label: "SETTINGS.Save" },
        { type: "reset", action: "reset", icon: "fa-solid fa-undo", label: "SETTINGS.Reset" },
      ]
    }
  }

  static registerSettings() {
    for (const [k, v] of Object.entries(SETTINGS)) {
      game.settings.register('elysium', k, v)
    }
  }

  static async onResetDefaults(event) {
    event.preventDefault()
    for await (const [k, v] of Object.entries(SETTINGS)) {
      await game.settings.set('elysium', k, v?.default)
    }
    return this.render()
  }

  static async formHandler(event, form, formData) {
    const settings = foundry.utils.expandObject(formData.object)
    await Promise.all(
      Object.entries(settings)
        .map(([key, value]) => game.settings.set("elysium", key, value))
    )
  }

}
