// =====================================================================
// ELYSIUM | Armor Wear — crit-triggered armor damage (v0.22.0-alpha.10)
// =====================================================================
//
// Per the alpha.9 Phase A rules-change rewrite, armor only takes damage
// from critical hits. Phase A established the schema and removed the
// old location-scaling. This module (Phase B) is the actual damage
// effect: when a critical hit lands on a location, every equipped armor
// piece on that location loses 1 AP. Broken at AP 0 (provides no
// protection until repaired).
//
// "Critical hit" means EITHER:
//   - Major Wound — the hit reduced the location's currHP to ≤ 0
//   - Attack-roll critical — the attacker rolled resultLevel >= 4
//   - Both — a major-wound-via-critical-attack damages armor twice
//     (once per trigger; no special interaction beyond that)
//
// State storage: armor's current AP lives in BRP's standard `system.av1`
// field (Phase A made it the source of truth). Max for repair lives in
// `system.elysium.apMax`. Broken state is derived: `av1 === 0`.
//
// Triggers (where this module is called from):
//   - `module/elysium/hooks/item.mjs` Major Wound trigger
//     (existing setTimeout firing rollCritical also calls
//      applyCritDamageToArmorAtLocation)
//   - Damage chat card — when an attack with resultLevel >= 4 is
//     resolved, the card surfaces an "Apply Crit Armor Damage" button
//     that calls applyCritDamageToArmorAtLocation manually.
//
// The auto-trigger from Major Wound is unconditional (rules-faithful);
// the attack-roll-crit trigger is GM-facilitated because BRP-classic
// damage flow doesn't carry the attacker's resultLevel through to the
// damage chokepoint.
// =====================================================================

const FLAG_NS = 'elysium'

// ---------------------------------------------------------------------
// Core wear helpers
// ---------------------------------------------------------------------

/**
 * Decrement an armor piece's current AP by `amount`. Clamps at 0.
 * Idempotent for items already at 0 (no further decrement).
 *
 * Side effect: posts a chat card noting the damage with reason.
 *
 * @param {Item} item      - the armor piece
 * @param {number} amount  - AP to remove (default 1)
 * @param {string} reason  - human-readable trigger label
 *                            ('major-wound' | 'attack-crit' | etc.)
 * @returns {Promise<{previous, current, broken, didDecrement}>}
 */
export async function applyArmorDamage (item, amount = 1, reason = 'critical-hit') {
  if (!item || item.type !== 'armor') {
    return { previous: 0, current: 0, broken: false, didDecrement: false }
  }
  const prev = Number(item.system?.av1) || 0
  if (prev <= 0) {
    // Already broken — no further damage to track
    return { previous: 0, current: 0, broken: true, didDecrement: false }
  }
  const next = Math.max(0, prev - Math.max(0, amount))
  await item.update({ 'system.av1': next })
  const broken = next === 0

  await _postArmorWearCard(item, prev, next, reason)

  return { previous: prev, current: next, broken, didDecrement: prev !== next }
}

/**
 * Restore current AP toward apMax. Clamps at apMax. Useful for the
 * repair button on the armor sheet (or future Craft-check integration).
 *
 * @param {Item} item      - the armor piece
 * @param {number} amount  - AP to restore (default 1)
 * @returns {Promise<{previous, current, fullyRepaired}>}
 */
export async function repairArmorPiece (item, amount = 1) {
  if (!item || item.type !== 'armor') {
    return { previous: 0, current: 0, fullyRepaired: false }
  }
  const prev = Number(item.system?.av1) || 0
  const apMax = Number(item.system?.elysium?.apMax) || 0
  if (apMax <= 0) {
    // No max defined — repair is a no-op
    return { previous: prev, current: prev, fullyRepaired: false }
  }
  if (prev >= apMax) {
    return { previous: prev, current: prev, fullyRepaired: true }
  }
  const next = Math.min(apMax, prev + Math.max(0, amount))
  await item.update({ 'system.av1': next })
  return { previous: prev, current: next, fullyRepaired: next >= apMax }
}

/**
 * Check whether an armor piece is broken (av1 === 0). Includes the
 * apMax > 0 guard so pieces that never had AP (apMax=0) don't show
 * as broken.
 *
 * @param {Item} item
 * @returns {boolean}
 */
export function isArmorBroken (item) {
  if (!item || item.type !== 'armor') return false
  const apMax = Number(item.system?.elysium?.apMax) || 0
  if (apMax <= 0) return false   // never had AP, not "broken"
  return (Number(item.system?.av1) || 0) === 0
}

/**
 * Apply 1 AP of crit damage to every equipped armor piece on the given
 * hit-location. This is the main entry point fired by the trigger hooks.
 *
 * Multi-piece behavior: if the location has multiple equipped armor
 * pieces (multi-stratum layering), EACH takes 1 AP damage. Per
 * discussion with the user, the rules-faithful interpretation is that
 * the blow damages the layered defense as a whole, not just one piece.
 * If a future rule wants outer-piece-only, the filter is one line.
 *
 * Skips broken pieces (already at av1=0).
 *
 * @param {Actor}  actor
 * @param {string} hitLocationId
 * @param {string} reason - 'major-wound' or 'attack-crit'
 * @returns {Promise<Array<{name, previous, current, broken}>>}
 */
export async function applyCritDamageToArmorAtLocation (actor, hitLocationId, reason) {
  if (!actor || !hitLocationId) return []

  const pieces = actor.items.filter(i =>
    i.type === 'armor' &&
    i.system?.hitlocID === hitLocationId &&
    i.system?.equipStatus === 'equipped'
  )
  if (pieces.length === 0) return []

  const results = []
  for (const piece of pieces) {
    const apMax = Number(piece.system?.elysium?.apMax) || 0
    if (apMax <= 0) continue   // skip pieces that never had AP (natural armor edge case)
    const r = await applyArmorDamage(piece, 1, reason)
    results.push({ name: piece.name, ...r })
  }
  return results
}

// ---------------------------------------------------------------------
// Chat-card surface
// ---------------------------------------------------------------------

async function _postArmorWearCard (item, prevAP, newAP, reason) {
  const actor = item.parent
  const apMax = Number(item.system?.elysium?.apMax) || 0
  const broken = newAP === 0
  const reasonLabel =
    reason === 'major-wound' ? game.i18n.localize('Elysium.Chat.ArmorReasonMajorWound') :
    reason === 'attack-crit' ? game.i18n.localize('Elysium.Chat.ArmorReasonAttackCrit') :
    reason

  const apMaxText = apMax ? ` / ${apMax}` : ''
  const body =
    `<p>${game.i18n.format('Elysium.Chat.ArmorWearBody', {
      actor: `<b>${actor?.name || 'Armor'}</b>`,
      item: `<b>${item.name}</b>`,
      reason: reasonLabel,
      prevAP,
      newAP: `<b>${newAP}</b>${apMaxText}`,
      apMax: '',
    })}</p>` +
    (broken ? `<p><b>${game.i18n.localize('Elysium.Chat.ArmorBroken')}</b></p>` : '')

  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: broken ? 'danger' : 'bonus-dark', icon: 'shield-halved', body }
  )
  await ChatMessage.create({
    content: html,
    speaker: actor ? ChatMessage.getSpeaker({ actor }) : undefined,
    flags: { [FLAG_NS]: { armorWearCard: true } },
  })
}

/**
 * Build an HTML button string for the damage chat card's "Apply Crit
 * Armor Damage" surface. The damage card emits this when the attack's
 * resultLevel is >= 4 (Critical success). Click handler wired in
 * `wireArmorWearChatHandlers` below.
 *
 * @param {string} defenderActorId
 * @param {string} hitLocationId
 * @returns {string}
 */
export function buildApplyCritArmorButtonHTML (defenderActorId, hitLocationId) {
  return `
    <button type="button"
            class="elysium-armor-wear-btn"
            data-elysium-armor-wear-action="apply-crit"
            data-defender-id="${defenderActorId}"
            data-location-id="${hitLocationId}"
            style="background:#a07020;color:#fff;border:1px solid #806010;padding:2px 8px;border-radius:3px;cursor:pointer;">
      Apply Crit Armor Damage
    </button>
  `
}

// ---------------------------------------------------------------------
// Chat-card delegation
// ---------------------------------------------------------------------

/**
 * Wire delegated click handlers for armor-wear UI:
 *   - "Apply Crit Armor Damage" button on damage chat cards
 *   - "Repair +1" button on the armor item sheet
 *
 * Called once during the ready hook.
 */
export function wireArmorWearChatHandlers () {
  document.body.addEventListener('click', async (ev) => {
    // Damage chat-card button
    const damBtn = ev.target.closest('[data-elysium-armor-wear-action]')
    if (damBtn) {
      ev.preventDefault()
      const action = damBtn.dataset.elysiumArmorWearAction
      if (action === 'apply-crit') {
        const defenderId = damBtn.dataset.defenderId
        const locationId = damBtn.dataset.locationId
        if (!defenderId || !locationId) {
          ui.notifications?.warn('Missing defender or location ID on armor-wear button.')
          return
        }
        const actor = game.actors?.get(defenderId)
        if (!actor) {
          ui.notifications?.warn('Defender actor not found.')
          return
        }
        const results = await applyCritDamageToArmorAtLocation(actor, locationId, 'attack-crit')
        if (results.length === 0) {
          ui.notifications?.info(`${actor.name} has no equipped armor on that location.`)
        } else {
          damBtn.disabled = true
          damBtn.style.opacity = '0.5'
          damBtn.textContent = 'Applied'
        }
      }
      return
    }

    // Armor item-sheet Repair button
    const repBtn = ev.target.closest('[data-elysium-armor-action]')
    if (repBtn) {
      ev.preventDefault()
      const action = repBtn.dataset.elysiumArmorAction
      if (action === 'repair') {
        const itemId = repBtn.dataset.itemId
        if (!itemId) return
        // Resolve via game.items or any actor
        let item = game.items?.get(itemId)
        if (!item) {
          for (const a of game.actors?.contents || []) {
            const found = a.items.get(itemId)
            if (found) { item = found; break }
          }
        }
        if (!item) {
          ui.notifications?.warn('Armor item not found.')
          return
        }
        const r = await repairArmorPiece(item, 1)
        ui.notifications?.info(
          `${item.name}: ${r.previous} → ${r.current} AP${r.fullyRepaired ? ' (fully repaired)' : ''}.`
        )
      }
    }
  })
}

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

export const ElysiumArmorWear = {
  applyArmorDamage,
  repairArmorPiece,
  isArmorBroken,
  applyCritDamageToArmorAtLocation,
  buildApplyCritArmorButtonHTML,
  wireArmorWearChatHandlers,
}
