# P12 cluster 2 prep audit — inline-HTML ChatMessage.create migration

**Status**: PENDING
**Target alpha**: alpha.52
**Scope**: P12's second sub-cluster per the P12 prep audit Option B sequencing. Covers item 1.6 from the P12 prep audit: migrate inline-HTML `ChatMessage.create({content: '<div>...'})` callsites across the codebase onto Handlebars templates with v1.0.0 marker classes and token-driven styling.
**Inheritance from**: P12 prep audit (D1 Option B sub-cluster split; sized c2 at "44 callsites, largest single P12 item"); P11 cluster 1 audit (the chat-card shell partial vocabulary established for cluster-1); P11 cluster 4 audit (the partial-block pattern via `@partial-block`); P12 c1 audit (the F1 130-rgba scope discovery — directly relevant here since many migration-target classes ARE already styled in the F1-territory CSS).

**Scope adjustment from prep-audit estimate**: the P12 prep audit cited 44 callsites; live alpha.51 measurement finds **45 inline-HTML callsites across 23 files**, plus 4 already-template callsites (out of cluster-2 scope). The prep audit's number was slightly undercounted; the actual scope is comparable but the per-callsite work is more heterogeneous than the phase-audit framing suggested.

---

## 1. Live measurement at alpha.51 baseline

### 1.1 Callsite re-count

Total `ChatMessage.create(...)` callsites across `module/`: **49**.

Classification:
- **Already template-based (out of c2 scope)**: 4
  - `base-actor-sheet.mjs:330` — uses `chat/rollStats.html` (P11 c4)
  - `apps/charDev.mjs:163` — uses `chat/XP-result.html` (P11 c4)
  - `apps/check.mjs:672` — generic chat dispatcher (sends pre-rendered HTML from any P11 card)
  - `apps/utilities.mjs:257` — uses `chat/itemDescription.html` (P11 c4)
  - `casting/cast-shared.mjs:394` — explicitly tagged "uses rendered HTML" by phase-audit; sample inspection shows it uses pre-rendered cast-card output

- **Inline-HTML migration targets**: **45**

The 4-callsite discrepancy from the phase audit (44 vs 45) traces to the 11 "unknown" callsites the phase-audit ran past too quickly. Each was inspected manually for this audit; 7 turned out to be inline-HTML disguised as variable-content (the inline string built into `chatContent`/`html`/`content`/`message` one line above the call), and 4 turned out to be genuine template renders.

### 1.2 Per-file distribution (the 45 inline-HTML targets)

| Count | File |
|---|---|
| 6 | `module/elysium/mechanics/charge-ui.mjs` |
| 4 | `module/casting/sustain.mjs` |
| 3 | `module/casting/sorcery-cast.mjs` |
| 3 | `module/elysium/actor/stat-improvement.mjs` |
| 3 | `module/elysium/hooks/item.mjs` |
| 3 | `module/elysium/mechanics/covering-stance.mjs` |
| 3 | `module/elysium/mechanics/engagement-ui.mjs` |
| 3 | `module/elysium/mechanics/outmanoeuvre.mjs` |
| 2 | `module/elysium/creation/creation.mjs` |
| 2 | `module/elysium/critical/critical-roller.mjs` |
| 2 | `module/elysium/fatigue/fatigue-manager.mjs` |
| 2 | `module/elysium/magic/magic.mjs` |
| 2 | `module/elysium/sheets/actor/combat-tab.mjs` |
| 1 (×8 files) | `casting/divine-cast.mjs`, `casting/spell-learning.mjs`, `combat-extension.mjs`, `hooks/chat-card.mjs`, `armor-wear.mjs`, `weapon-wear.mjs` |
| **45** | **Total across 23 files** |

### 1.3 Marker class inventory (the 45 callsites' top-level wrapper classes)

The migration is partly *already begun* — many callsites already use a v1.0.0-style marker class on the outer `<div>` (e.g. `.elysium-sustain-notice`, `.elysium-critical-card`). Per family suffix:

| Suffix | Count | Classes |
|---|---|---|
| `-notice` (status) | 4 | sustain-notice (×2 files), cast-disrupt-notice, no-target-notice, pow-loss-notice |
| `-card` (general) | 8 | armor-wear-card, covering-stance-card, critical-card, outmanoeuvre-card, sorcery-damage-card, stat-cap-card, stat-improve-card, weapon-wear-card |
| `-prompt` (interactive prompt) | 3 | charge-prompt, change-range-prompt, knockback-prompt |
| `-result` (action outcome) | 2 | cast-disrupt-result, charge-result |
| `-applied-card` (passive effect applied) | 2 | passive-block-applied-card, ward-applied-card |
| `-warning` | 2 | engagement-warning, forbidden-warning |
| Other / no top-level marker | rest | Inline notices that pre-date v1.0.0 (plain `<p>`/`<div>`) |

### 1.4 CSS coverage (already-styled vs unstyled)

Of 19 top-level marker classes inventoried, **10 already have CSS rules** in `styles/elysium.css` — meaning the migration is part-completed visually but unfinished structurally. These rules are part of the **F1 130-rgba territory** (the c1 audit's deferred discovery — `styles/elysium.css` has 130 hardcoded color literals). Migrating the templates to v1.0.0 partials without retokening their CSS leaves them as styled-but-not-retokenned, which is honest but mixed-quality.

**Already styled** (sample):
- `.elysium-cast-disrupt-notice` (elysium.css:2464)
- `.elysium-stat-improve-card` (elysium.css:2097)
- `.elysium-stat-cap-card` (elysium.css:2143)
- `.elysium-sustain-notice` (elysium.css:1925)
- `.elysium-critical-card`, `.elysium-fatigue-roll`, `.elysium-overcast`, `.elysium-luck-save`, `.elysium-ongoing-damage`, `.elysium-stat-advance` (all in elysium.css:100-140 region)

**Unstyled** (sample — these would need new CSS in c2 if not deferred):
- `.elysium-armor-wear-card`, `.elysium-weapon-wear-card` (wear cards never had CSS)
- `.elysium-charge-prompt`, `.elysium-charge-result`, `.elysium-knockback-prompt`, `.elysium-change-range-prompt` (charge-ui + engagement-ui — inline-style-only, no CSS rules)
- `.elysium-covering-stance-card`, `.elysium-passive-block-applied-card`, `.elysium-ward-applied-card`
- `.elysium-outmanoeuvre-card`, `.elysium-sorcery-damage-card`
- `.elysium-pow-loss-notice`, `.elysium-no-target-notice`
- `.elysium-engagement-warning`, `.elysium-forbidden-warning`

### 1.5 Inline-style density

Many of the 45 callsites carry **inline `style="..."` declarations** in their HTML strings — the anti-pattern cluster-3 retired for the hitloc-tag, alpha.51 retired for the brace-badge, and this audit must address at scale. Spot-sample distribution from the most inline-style-heavy files:

- `charge-ui.mjs` callsites carry ~12 inline-style declarations each (h3/h4 color, p margin/font-size, ul margin/padding, button flex/gap)
- `engagement-ui.mjs` charge-range-prompt callsite carries 6 inline styles
- `combat-tab.mjs:509` engagement-warning carries 5 inline styles + 3 hardcoded color literals (`#882929`, `#884400`, `#005500`)
- `critical-roller.mjs:282-296` critical card has no inline styles (cleanest)
- `creation.mjs:153, 200` stat-advance cards have inline styles

### 1.6 i18n key usage

Several callsites use `game.i18n.localize(...)` / `game.i18n.format(...)` for some strings, others are hardcoded English. Migration must respect existing localization (preserve i18n calls in the template-context-building JS) AND surface untranslated English literals as P12-c3 lang-completion candidates. Specific instances:

- `critical-roller.mjs`: 5 distinct i18n keys (`Elysium.Critical.Title`, `.Roll`, `.Effects`, `.Ongoing`, `.PermanentNote` + `Elysium.Luck.SavedByLuck`)
- `fatigue-manager.mjs:113`: 4 keys (`Elysium.Fatigue.EffortRoll`, `.Roll`, `.Fumble`, `.Failed`, `.Critical`, `.Passed`)
- `magic.mjs:68`: 2 keys (`Elysium.Magic.Overcast`, `.OvercastFatigue`)
- `magic.mjs:177`: 1 key (`Elysium.Magic.ForbiddenSchool`)
- Most other callsites: hardcoded English (charge-ui prompts, engagement-ui prompts, stat-improvement cards, armor/weapon wear, sustain notices)

**Implication for c2**: a side-effect of the migration is the opportunity to lift the hardcoded English into i18n keys. Whether to take that opportunity is Q6 below.

---

## 2. Archetype analysis — proposed partial vocabulary

The phase-audit hand-waved "5 partials" but didn't enumerate. Live inspection shows the 45 callsites collapse to **3 structural archetypes**, not 5:

### Archetype A — Notice (passive announcement)

A simple status announcement with no buttons, no interactive elements. Usually 1-3 paragraphs of context with an optional FA icon prefix.

Examples: sustain-begin notice, pow-loss notice, no-target notice, cast-disrupt notice (informational variant), passive-block-applied, ward-applied, weapon-wear, armor-wear, stat-advance, stat-cap-info, overcast notice, ongoing-damage, fatigue-update, sustain-disrupt, charge-result-resolved (simple variant), knockback-stayed, knockback-prone, engagement-allowed-summary, outmanoeuvre-success/withdraw/disengage.

**Count**: ~25 of 45 callsites fall here.

**Structural template**:
```hbs
<div class="elysium-chat-notice elysium-chat-notice--{{variant}}">
  {{#if icon}}<i class="fas fa-{{icon}}"></i>{{/if}}
  <div class="elysium-chat-notice__body">
    {{{body}}}
  </div>
</div>
```

Where `body` is rendered HTML (the caller pre-renders the localized + actor-namespaced string), `variant` is a token-accent suffix (e.g. `info`, `danger`, `bonus`, `success`, `fire`) matching the chat-card Section D accent token vocabulary.

### Archetype B — Roll card (roll-bearing, no interaction)

A card that shows a roll outcome with structured data (roll value, target, success/fail banner, optional damage rows, optional condition list).

Examples: stat-improvement-card, stat-cap-card, critical-card, fatigue-roll, learn-card, sorcery-damage-card.

**Count**: ~8 of 45 callsites.

**Structural template**:
```hbs
<div class="elysium-chat-roll-card elysium-chat-roll-card--{{variant}}">
  <header class="elysium-chat-roll-card__header">
    {{#if icon}}<i class="fas fa-{{icon}}"></i>{{/if}}
    {{title}}
  </header>
  <div class="elysium-chat-roll-card__body">
    {{{body}}}
  </div>
  {{#if footer}}
  <footer class="elysium-chat-roll-card__footer">
    {{{footer}}}
  </footer>
  {{/if}}
</div>
```

### Archetype C — Action prompt (interactive buttons)

A prompt that includes one or more action buttons with `data-elysium-*-action` hooks. The JS in the same module file listens to clicks and routes to a follow-up handler.

Examples: charge-prompt, change-range-prompt, knockback-prompt, cast-disrupt-prompt, sorcery-damage-prompt.

**Count**: ~5 of 45 callsites. Lowest count, highest complexity per callsite.

**Structural template**:
```hbs
<div class="elysium-chat-prompt elysium-chat-prompt--{{variant}}">
  <header class="elysium-chat-prompt__header">
    {{#if icon}}<i class="fas fa-{{icon}}"></i>{{/if}}
    {{title}}
  </header>
  <div class="elysium-chat-prompt__body">
    {{{body}}}
  </div>
  <div class="elysium-chat-prompt__buttons">
    {{#each buttons}}
      <button type="button"
              data-elysium-action="{{action}}"
              data-tooltip="{{tooltip}}"
              {{#each dataAttrs}}data-{{@key}}="{{this}}"{{/each}}>
        {{label}}
      </button>
    {{/each}}
  </div>
</div>
```

The `data-elysium-action` attribute uses a uniform attribute name (currently the codebase uses `data-elysium-charge-action`, `data-elysium-cr-action`, `data-elysium-kb-action` — these would need to either be preserved as-is OR unified to `data-elysium-action` with a `data-elysium-action-family` discriminator. See Q3.)

### Archetype distribution check

- **A (Notice)**: 25 callsites → 1 partial covers all
- **B (Roll card)**: 8 callsites → 1 partial covers all
- **C (Action prompt)**: 5 callsites → 1 partial covers all
- **Edge cases**: ~7 callsites have shapes that don't cleanly fit (engagement-warning has a `<ul>`-based body with per-engagement rows; multi-tab stat advance has 2 unrelated card-bodies side-by-side). Either each gets a one-off partial OR they compose Archetype A with `{{{body}}}` building the bespoke markup in the caller. Decision Q4.

**Conclusion: 3 new partials + ~5 callsites that stay caller-built**. Phase-audit's "5 partials" estimate was wrong direction — fewer partials with more flexibility is the cleaner outcome.

---

## 3. Findings

### F1 — The scope is meaningfully larger than the phase audit reported

The phase audit said "44 callsites + ~5 new partials = ~400-600 LOC." Live inspection: **45 callsites, 3 new partials, 23 files modified, plus ~5 callsites that may stay caller-built, plus the question of whether to also retoken the 10 already-styled marker classes' CSS rules** (which sit in the F1 130-rgba territory).

The honest scope estimate is **600-900 LOC across templates + ~150-200 LOC across module JS** (each callsite shrinks from ~25-line inline string to ~5-10 lines of context-building + `renderTemplate` + `ChatMessage.create`).

### F2 — Many callsites carry hardcoded English strings

About 25 of 45 callsites have user-facing English literals not in i18n. Examples:
- charge-ui.mjs prompts: "Charge!", "Charge bonuses (apply to attack):", "Attack roll: +1 difficulty grade", "Damage Mod: ... → ...", button labels "Parry", "Evade", "Counterattack"
- engagement-ui.mjs change-range prompt: "Change Range", button labels "Resisted (kept reach)", "Resist failed", "Attacked instead", "Allowed"
- stat-improvement.mjs: "Spent 1 EXP die (X remaining)", "Success — STR increased by 1"

Migrating to templates without lifting these to i18n means the templates carry English literals — a quality regression from the existing pattern (where some callsites already use `game.i18n.localize(...)`). Two responses possible (Q6 below):
- **Lift to i18n during c2**: adds ~30 new i18n keys × 3 langs = 90 entries to c2's scope. Es/fr gap further widens (was 202; would be ~232). C3 lang sweep absorbs the new gap.
- **Preserve as English literals**: faster c2 ship; leaves the existing hardcoded literals as-is.

### F3 — Already-styled markers sit in F1 territory

10 of 19 top-level marker classes have CSS rules in `styles/elysium.css`. Those rules are styled with the legacy color literals that the c1 audit's F1 finding will sweep in P12-c4. **c2 has 3 routing options for these rules**:

1. **Leave them as-is** (styled but not retokenned) — they ARE rendered correctly; the F1 rgba retokens happen in c4 anyway. c2's diff stays small.
2. **Retoken these specific rules during c2** — folds the F1 sweep into c2 partially. Inconsistent scope.
3. **Retoken these rules + the rest of F1 during c2** — explodes c2's scope.

**Recommendation**: option 1. c2 is markup migration; F1 sweep happens as scheduled in c4. Cross-reference noted.

### F4 — Some `data-elysium-*-action` attribute names diverge

The 3 callsites with action buttons use 3 different attribute names:
- `data-elysium-charge-action` (charge-ui)
- `data-elysium-cr-action` (change-range)
- `data-elysium-kb-action` (knockback)

These are JS-imperative hooks (each file's event listener reads its own family). Unifying them to `data-elysium-action` with a discriminator would require changing the JS handlers too, which expands scope beyond template migration.

**Recommendation**: preserve the family-specific attribute names verbatim in c2. The Archetype C partial accepts a `dataAttrs` object so each callsite can pass its own attribute family. Lock the 3 attribute names to the audit-5 lock list after c2 ships (currently they're not formally locked — but they're class-hook-equivalent: the JS reads them).

### F5 — Some inline strings are non-template (already legitimately context-built)

`fatigue-manager.mjs:31` calls `this._formatChat(actor, level, source)` which returns an HTML string built by a static method. `cast-shared.mjs:394` passes pre-rendered `html` from cast-shared internal pipeline.

For migration purposes, the `_formatChat` helper inside fatigue-manager IS the inline-HTML builder — moving the HTML out to a template means refactoring `_formatChat` to instead return a context object that the caller renders via the new partial. Same pattern for any other "helper builds HTML string" callsite.

This is a small refactor but it ripples through every consumer of these helpers. Audit before code — but during c2, not now.

### F6 — Inline-style hardcoded colors are a separate but related anti-pattern

`combat-tab.mjs:506-508` has:
```js
const headerColor = worstState === 'bay' ? '#882929'
                  : worstState === 'encroached' ? '#884400'
                  : '#444'
```

These are state-mapped color literals in JS. Moving them to a partial doesn't fix them — the partial would receive `headerColor` as a context variable and apply `style="color:{{headerColor}}"`, still inline-style. The fix is variant-class-based CSS:
```hbs
<div class="elysium-chat-card--bay">  <!-- styled .elysium-chat-card--bay { color: var(--ely-accent-danger); } -->
```

Same pattern as Section D in elysium-chat.css. The variant-class approach is cleanly tokenisable and avoids the inline-style anti-pattern.

**Implication**: c2 partials need a `--{{variant}}` BEM modifier system, and c2 also needs new Section-D-style accent rules added to a stylesheet. Q5 below: which stylesheet receives the new rules?

---

## 4. Cluster-2 options

### Option A — Strict template migration only (no CSS, no i18n, no helper refactor)

Migrate the 45 callsites to use new templates. Don't lift English to i18n. Don't add CSS rules. Don't refactor `_formatChat`. Inline-style content variables stay inline-style (passed through partials via `{{{body}}}`).

**Pros**: smallest possible diff. Mechanical, low-risk per callsite.
**Cons**: largely cosmetic — most inline-HTML stays inline-HTML, just routed through a partial. Doesn't address F4 (data-elysium-* divergence), F5 (helper functions), or F6 (inline-style colors). Sets a bad precedent for c4.

### Option B — Template + i18n lift, no CSS additions (RECOMMENDED)

Migrate the 45 callsites to templates. Lift hardcoded English to i18n keys. Pass context objects (not pre-built HTML) into partials, so partials own the structural markup and callers own the data. Don't add new CSS rules — the styled markers already have CSS in F1 territory, the unstyled ones get a minimal `elysium-chat-notice` family rule added to `elysium-chat.css` only if necessary for layout/readability.

**Pros**: cleanest scope. Each callsite becomes ~5 lines of context-building. Partials are reusable. F2 lift to i18n closes a real localization gap. F6 (inline-style colors) addressed via variant classes on the partial; new variant rules added to elysium-chat.css Section D (token-driven, 3-5 LOC each).
**Cons**: larger diff than Option A. Adds ~30 i18n keys × 3 langs = 90 entries to lang files (widens es/fr gap, but c3 absorbs anyway). Doesn't refactor `_formatChat` (defer to a follow-up if needed).

### Option C — Full migration including helper refactor + CSS retoken for already-styled markers

Option B + refactor `_formatChat` (and any other HTML-builder helpers) to return context objects + retoken the 10 already-styled marker classes' CSS rules during c2 (folding part of F1 forward).

**Pros**: most thorough.
**Cons**: scope explosion. The CSS retoken alone needs its own per-rule decision pass (the 10 rules carry rgba/hardcoded-color literals that need either retoken targets defined or new tokens added). Conflicts with F1's deferred-to-c4 routing.

### Option D — Staged ship: c2a notices, c2b cards, c2c prompts

Split into 3 sub-ships matching the 3 archetypes:
- **c2a** (alpha.52): the 25 Archetype A notices + new `chat-card-notice.hbs` partial + lift their English to i18n
- **c2b** (alpha.53): the 8 Archetype B roll cards + new `chat-card-roll.hbs` partial + lift their English to i18n
- **c2c** (alpha.54): the 5 Archetype C action prompts + new `chat-card-prompt.hbs` partial + lift their English to i18n + edge-case handling

Lang completion + acceptance (originally c3) becomes c2d / c3.

**Pros**: each sub-ship is small, audit-then-stop discipline clean per archetype. Risk localized per ship.
**Cons**: 3 ship cycles for what could be 1 ship. P12 phase plan grows further (3 clusters → 6+ clusters).

---

## 5. Decisions (lockable now)

### D1 — Sub-cluster scope: Option B

Recommended. Migrate all 45 callsites in one c2 ship. Lift hardcoded English to i18n. Use variant classes (BEM modifier) for state-mapped colors. Defer CSS retoken of already-styled markers to c4 (where F1 sweep handles them at scale).

### D2 — Partial vocabulary: 3 partials

- `templates/chat/parts/chat-card-notice.hbs` — Archetype A (status announcement)
- `templates/chat/parts/chat-card-roll.hbs` — Archetype B (roll outcome)
- `templates/chat/parts/chat-card-prompt.hbs` — Archetype C (interactive prompt)

Each composes the existing `chat-card-shell.hbs` partial-block from cluster-1 for the `.elysium-chat-card` marker class + scoping wrapper.

### D3 — Variant accent system

Each new partial takes a `variant` context parameter (e.g. `'info'`, `'danger'`, `'success'`, `'bonus'`, `'fire'`, `'mind'`). The partial renders a BEM modifier class: `elysium-chat-notice--{{variant}}`. New Section D-style rules in `elysium-chat.css` token-drive the accent border-left + optional background tint per variant.

Variants align with the existing chat-card Section D vocabulary established in P11 c2/c3/c4.

### D4 — Edge cases stay caller-built

The ~5 edge-case callsites with shapes that don't cleanly fit the 3 archetypes (engagement-warning's `<ul>` body, stat-advance's two-section layout) stay caller-built in c2. They go through the partials only for outer-shell consistency; the body content is pre-built HTML passed as `{{{body}}}`. Each is documented in the c2 ship CHANGELOG as a per-callsite exception.

### D5 — `_formatChat` and similar HTML-builder helpers

Refactor in c2: each helper that today returns an HTML string is refactored to return a context object. The caller does `renderTemplate('.../chat-card-notice.hbs', ctx)` then `ChatMessage.create({content: html, ...})`. ~3 helpers affected (fatigue-manager._formatChat, possibly 1-2 others surfaced during code).

### D6 — Action button attribute names

Per F4: preserve `data-elysium-charge-action`, `data-elysium-cr-action`, `data-elysium-kb-action` verbatim — they're JS-imperative hooks. The Archetype C partial accepts `dataAttrs` as a passthrough object. After c2 ships, add these 3 attribute family names to the audit-5 lock list.

---

## 6. Open questions

### Q1 (blocking) — Lift hardcoded English to i18n during c2?

Per F2 + D1: yes, lift. Adds ~30 new keys × 3 langs = 90 entries (en authoritative, es/fr stubbed for c3 sweep).

Override: `proceed without i18n lift` if you'd rather defer.

### Q2 (blocking) — How to handle already-styled markers?

Per F3 + D1: leave the 10 already-styled markers' CSS rules untouched in c2. They render correctly via existing CSS; the retoken happens in c4 as part of the F1 sweep.

Override: `proceed with c4 fold-in` if you'd rather retoken these 10 rules during c2.

### Q3 (blocking) — Edge-case callsite handling

Per D4: ~5 callsites stay caller-built (outer shell from partial, body from caller). Alternative: write 1-off partials for each.

Override: `proceed with one-off partials for edge cases`.

### Q4 (non-blocking) — Variant token assignments

Proposed mapping:
- sustain-notice → variant=`mind` (matches casting family chat-cards)
- pow-loss-notice → variant=`mind` 
- cast-disrupt-notice / no-target-notice → variant=`danger`
- charge-prompt / charge-result / knockback-prompt → variant=`action` (matches CB/CM family)
- engagement-warning / change-range-prompt → variant=`fire` (orange — caution/transition)
- weapon-wear / armor-wear → variant=`bonus-dark` (gold-muted, wear is informational)
- critical-card → variant=`danger`
- stat-improve-card / stat-advance / stat-cap → variant=`success` (improvement = green)
- fatigue-roll / fatigue-update → variant=`fire` (fatigue = orange-warning)
- learn-card → variant=`bonus` (gold — knowledge gain)
- overcast → variant=`danger`
- ongoing-damage → variant=`danger`
- outmanoeuvre → variant=`info`
- covering-stance / passive-block / ward → variant=`info`
- forbidden-warning → variant=`danger`

22 variant assignments, mapping to 7 distinct accent tokens already defined in elysium-tokens.css. Refine at code time if any look wrong.

### Q5 (non-blocking) — New Section D rules location

Per F6 + D3: new variant accent rules added to `styles/elysium-chat.css` Section D (the existing 15-card-type accent block). The 3 new partials live in `templates/chat/parts/`, alongside the 7 cluster-1/c2/c4 partials.

### Q6 (non-blocking) — Smoke methodology

Per cluster-1-5 pattern: render each callsite via fixture in the test world's console, compare DOM before/after migration. Audit-5 contract checks include:
- All `data-elysium-*-action` attributes preserved verbatim across the 5 Archetype C callsites
- All i18n keys resolve (no `Elysium.X.Y` literal strings in rendered output)
- Variant BEM class applied correctly per the Q4 mapping
- The `chat-card-shell` outer marker is present on every migrated card
- No inline `style="..."` declarations remain in any of the 45 migrated callsites

### Q7 (non-blocking) — Compendium / Phase D interaction

A subset of these callsites' chat messages may be consumed by Phase D injection (the combat-card buttons hook). Verification at code time: confirm none of the c2 cards trigger Phase D filter (it filters on `rollType==='CM'` — none of the 45 cards have that rollType, but spot-check anyway).

### Q8 (non-blocking) — Version bump

alpha.51 → alpha.52 per Option B 3-cluster sequencing. Phase plan grows from 3 to 4 clusters (c1/c2/c3/c4) per c1 audit's F1 discovery; this audit does not change that count further.

---

## 7. Recommendation

Lock the c2 scope per D1-D6:

- **D1 Option B**: 45 callsites in one ship; lift English to i18n; variant-class-based color system; F1-territory CSS retoken deferred to c4
- **D2** 3 new partials: `chat-card-notice.hbs`, `chat-card-roll.hbs`, `chat-card-prompt.hbs`
- **D3** Variant accent system: `--{{variant}}` BEM modifier, new Section D rules in elysium-chat.css
- **D4** ~5 edge cases stay caller-built (body as `{{{body}}}`)
- **D5** Refactor HTML-builder helpers (`_formatChat` etc.) to return context objects
- **D6** Preserve `data-elysium-*-action` attribute family names; lock to audit-5 list after ship

**Estimated c2 ship contents**:
- 3 new partials (~150 LOC total)
- 45 callsites refactored (-450 LOC inline HTML + +200 LOC context-building + renderTemplate calls = net -250 LOC across module JS)
- 1-3 helper refactors (~50 LOC churn)
- ~30 new i18n keys in en.json (es/fr widened, absorbed in c3)
- ~5-10 new Section D variant rules in elysium-chat.css (~50-80 LOC)
- system.json version bump
- CHANGELOG entry
- ROADMAP execution log + progress tracker

**Net diff estimate**: **-100 to -200 LOC overall** (the inline HTML retirement dominates; new partials + variant rules + i18n keys add some back). Smaller than the prep audit's "+400-600 LOC" estimate — context-building is meaningfully more compact than inline HTML strings.

**Risk assessment**: medium-high per-callsite (each callsite is a behavioral surface that could regress if context-building misses a field), low cumulative (each callsite's regression surface is bounded; smoke fixtures catch most issues).

---

## 8. Cluster-2 lock list additions (post-ship)

- `data-elysium-charge-action` (charge-ui dispatch)
- `data-elysium-cr-action` (change-range dispatch)
- `data-elysium-kb-action` (knockback dispatch)
- `data-elysium-action` (if unified — but D6 keeps the family-specific names)
- The 3 new partial paths: `systems/elysium/templates/chat/parts/chat-card-{notice,roll,prompt}.hbs`

---

## 9. Cross-references

- `docs/p12-prep-audit.md`: D1 sub-cluster split sequencing
- `docs/p12-c1-audit.md`: F1 130-rgba discovery + c4 routing (this audit's F3 references that)
- `docs/p11-cluster1-audit.md`: chat-card-shell partial-block pattern (composed by all 3 new partials)
- `docs/p11-cluster3-audit.md`: hitloc-tag retoken methodology (style-as-token migration template)
- `docs/p11-cluster4-audit.md`: partial-block syntax with full-path close tag

---

## 10. Pre-decision checklist

Before responding `proceed with recommended`:

- [ ] Confirm F1 scope adjustment: 45 callsites across 23 files, not 44 across 19
- [ ] Accept D1 Option B: lift to i18n, defer F1 territory CSS retoken to c4
- [ ] Accept D2: 3 new partials (Notice / Roll / Prompt)
- [ ] Accept D3: variant BEM modifier with token-driven Section D accents
- [ ] Accept D4: ~5 edge-case callsites stay caller-built
- [ ] Accept D5: refactor HTML-builder helpers to return context objects
- [ ] Accept D6: preserve `data-elysium-*-action` family names verbatim, lock after ship
- [ ] Accept Q1 (yes lift to i18n), Q2 (leave already-styled markers), Q3 (edge cases caller-built) default-accepts

If overriding, name the override: `proceed without i18n lift`, `proceed with c4 fold-in`, `proceed with one-off partials`, `proceed with option A/C/D`, etc.
