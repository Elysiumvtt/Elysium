/**
 * Elysium subsystem — entry point.
 *
 * Loaded as part of the elysium system (no longer a separate module).
 * This file installs the Elysium hooks, registers settings, exposes the
 * API surface on game.system.api, and wires up the runtime patches.
 *
 * Architecture:
 *   - Settings register all toggles (one menu per category)
 *   - Hooks attach Elysium logic to system events
 *   - Active Effect templates implement the buff/debuff/condition system
 *   - Data extensions live in system.elysium.* on items and actors
 *   - Critical tables, conditions, fatigue and ancestry use module data
 */

import { ELYSIUM } from './config/config.mjs'
import { registerSettings } from './settings/register-settings.mjs'
import { registerHooks } from './hooks/register-hooks.mjs'
import { ElysiumActorExtension } from './actor/actor-extension.mjs'
import { ElysiumActiveEffectFactory } from './active-effects/factory.mjs'
import { ElysiumCriticalRoller } from './critical/critical-roller.mjs'
import { ElysiumFatigueManager } from './fatigue/fatigue-manager.mjs'
import { ElysiumAncestryDrop } from './actor/ancestry-drop.mjs'
import { ElysiumMagic } from './magic/magic.mjs'
import { ElysiumCombatExtension } from './combat/combat-extension.mjs'
import { ElysiumCharacterCreation } from './creation/creation.mjs'
import { ElysiumAncestryRelabel } from './helpers/ancestry-relabel.mjs'
import { ElysiumMythrasHP } from './actor/mythras-hp.mjs'
import { ElysiumEngagement } from './mechanics/engagement.mjs'
import { ElysiumEngagementUI } from './mechanics/engagement-ui.mjs'
import { ElysiumCharge } from './mechanics/charge.mjs'
import { ElysiumChargeUI } from './mechanics/charge-ui.mjs'
import { ElysiumOutmanoeuvre } from './mechanics/outmanoeuvre.mjs'
import { ElysiumCoveringStance } from './mechanics/covering-stance.mjs'
import { ElysiumArmorWear } from './mechanics/armor-wear.mjs'
import { ElysiumWeaponWear } from './mechanics/weapon-wear.mjs'
import { ElysiumCombatCardButtons } from './mechanics/combat-card-buttons.mjs'
import { migrateArmorHpSchemaOnce } from './migrations/armor-hp-schema-v0220a9.mjs'
import * as effectGrades from './mechanics/effect-grades.mjs'
import * as restrictedAP from './mechanics/restricted-ap.mjs'
import * as statImprovement from './actor/stat-improvement.mjs'

Hooks.once('init', () => {
  console.log('Elysium | Initialising subsystem')

  // Expose subsystem on CONFIG and the system API
  CONFIG.ELYSIUM = ELYSIUM
  game.system.api ??= {}
  game.system.api.elysium = {
    config: ELYSIUM,
    activeEffects: ElysiumActiveEffectFactory,
    criticalRoller: ElysiumCriticalRoller,
    fatigue: ElysiumFatigueManager,
    ancestryDrop: ElysiumAncestryDrop,
    magic: ElysiumMagic,
    combat: ElysiumCombatExtension,
    creation: ElysiumCharacterCreation,
    actor: ElysiumActorExtension,
    relabel: ElysiumAncestryRelabel,
    engagement: ElysiumEngagement,
    engagementUI: ElysiumEngagementUI,
    charge: { ...ElysiumCharge, ...ElysiumChargeUI },
    outmanoeuvre: ElysiumOutmanoeuvre,
    coveringStance: ElysiumCoveringStance,
    // Back-compat alias for alpha.7 callers; the unified module exposes
    // the same passive-block surface (getPassivelyBlockingItemsForLocation
    // etc.) so external integrations continue to work.
    passiveBlock: ElysiumCoveringStance,
    armorWear: ElysiumArmorWear,
    weaponWear: ElysiumWeaponWear,
    combatCardButtons: ElysiumCombatCardButtons,
    effectGrades,
    restrictedAP,
    statImprovement,
  }

  // Register Elysium settings and hooks
  // v0.20.0: registerHandlebarsHelpers() removed — the six helpers it
  // installed (elysiumFatigueLabel, elysiumPips, elysiumSigned,
  // elysiumEssenceTier, elysiumDifficulty, elysiumJoin) had zero callers.
  registerSettings()
  registerHooks()

  console.log('Elysium | Initialised')
})

// After the system registers its Actor class, install the Mythras HP
// override on prepareDerivedData. `setup` runs after init completes.
Hooks.once('setup', () => {
  ElysiumMythrasHP.install()
  // Patch the CombatTracker context menu to add Engage/Disengage entries.
  ElysiumEngagementUI.patchCombatTrackerContextMenu()
})

// Apply the ancestry term relabel after the system's translations load.
Hooks.once('i18nInit', () => {
  ElysiumAncestryRelabel.initialise()
})

Hooks.once('ready', async () => {
  console.log('Elysium | Ready')

  // Wire delegated handlers for engagement chat-card buttons
  ElysiumEngagementUI.wireChangeRangeChatHandlers()

  // Wire delegated handlers for charge / knockback chat-card buttons
  ElysiumChargeUI.wireChargeChatHandlers()

  // Wire delegated handlers for outmanoeuvre follow-up buttons
  ElysiumOutmanoeuvre.wireOutmanoeuvreChatHandlers()

  // Wire delegated handlers for covering-stance (passive-block + ward)
  // chat-card buttons
  ElysiumCoveringStance.wireCoveringStanceChatHandlers()

  // Wire delegated handlers for armor-wear "Apply Crit Armor Damage" button
  ElysiumArmorWear.wireArmorWearChatHandlers()

  // Wire delegated handlers for weapon-wear "Apply Fumble / Crit-Parry
  // Weapon Damage" buttons and the weapon-sheet Repair button.
  ElysiumWeaponWear.wireWeaponWearChatHandlers()

  // Initial derived-stat calculation pass over any pre-existing actors.
  if (game.user.isGM) {
    ElysiumActorExtension.verifyAllActors()
  }

  // v0.22.0-alpha.9: one-time migration of armor items from the old
  // location-scaled HP schema to the new flat-AP schema. Idempotent;
  // guarded by a world flag so re-runs are no-ops.
  await migrateArmorHpSchemaOnce()
})
