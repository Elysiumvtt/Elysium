# Testing environment notes

This document captures **environmental quirks** of the test setup that affect how Claude (or any AI assistant) should run UI-event-level verification against the live Foundry build. These are not bugs in the system — they're observations about the Chrome-bridge testing harness that future sessions need to know about so they don't lose hours rediscovering them.

> **If you are Claude reading this in a fresh session**: this file documents a real, reproducible workaround that was discovered during v1.1.0 c1 verification. The trick is not folklore. It has been confirmed working.

---

## The "open Foundry window freezes the Chrome bridge" issue

### Symptom

After rendering a Foundry application/sheet via the Chrome bridge (e.g. `actor.sheet.render(true)` via `javascript_tool`), subsequent bridge calls fail with one of these errors:

- `Cannot access a chrome-extension:// URL of different extension`
- `Detached while handling command.`
- `Object reference chain is too long` (less common)

The Foundry UI itself is still alive and responsive to keyboard/mouse — the bridge has just lost its ability to access the tab. Waiting 8-20 seconds does NOT recover the bridge on its own.

### Root cause (informed guess)

The bridge appears to lose focus access to the tab once a modal-like Foundry application window takes UI focus. Foundry's `ApplicationV2`-based sheets and dialogs render into the DOM with z-index overlays that may shadow the extension's focus tracking. Once stuck, the bridge cannot inspect the DOM, dispatch clicks, or evaluate JS until the offending application DOM is removed.

This affects:
- Actor sheets (any subclass of `ElysiumActorSheetV2`)
- Item sheets (any subclass of `ElysiumItemSheetV2`)
- `DialogV2` instances opened via API
- The `ElysiumIDEditor` (after the initial open — re-open after close is fine)

This does **not** affect:
- Bare scene rendering (`canvas` operations)
- Settings UI opened by the GM menu
- Chat panel / sidebar interactions
- `ui.notifications.*` toast messages

### Confirmed workaround

**When the bridge gets stuck after opening a Foundry application, run this JS call to forcibly remove the application DOM:**

```js
document.querySelectorAll('.application').forEach(el => el.remove())
```

This re-acquires bridge access. It worked reliably during c1 verification (multiple times across multiple flows).

Two-step pattern depending on bridge state:

1. **If the bridge can still execute JS** (some calls return successfully but with timing weirdness, e.g. "Detached while handling command" but the side-effect did execute): queue the DOM-remove call as a normal `javascript_tool` action. The call will queue, execute, remove the windows, and the bridge will recover on the next call.

2. **If the bridge is fully stuck** (every call returns `Cannot access a chrome-extension:// URL`): the JS call can't dispatch. In this case, the user must manually close the open Foundry window (click the X on the open sheet/dialog). After manual close, the bridge recovers within ~1 second.

### Verification pattern that works

For UI-event-level verification of sheet actions / drop flows / dialog interactions:

1. **Use short, focused JS calls** rather than long async chains. The bridge tolerates `actor.sheet.render(true)` better as a fire-and-forget call than as part of an `await`-heavy chain.

2. **Probe state separately from rendering**. Render first, wait via the bridge's `wait` action, then probe DOM/state with a small JS call.

3. **Always clean up at the end**: after each UI flow, run the DOM-remove cleanup as a defensive close. This keeps the bridge healthy for the next flow.

4. **For end-to-end click verification**: instead of trying to click the button via `computer.left_click` (which may be intercepted by extension overlays), use JS-side `document.querySelector('button[data-action="X"]').click()`. The browser's synthetic-click dispatch fires the V14 action handler the same way a real click would.

### Example: c1 verification flow that worked

```js
// 1. Render the sheet — short, focused call
game.actors.getName('c1_test_char').sheet.render(true); 'render-called'

// 2. Wait via bridge
// (bridge's wait action, 2 seconds)

// 3. Probe DOM in a separate small call
!!document.querySelector('button[data-action="editElysiumID"]')

// 4. Fire the click via JS, not via bridge left_click
document.querySelector('button[data-action="editElysiumID"]').click()

// 5. Wait, then probe what opened
// (bridge wait, 1 second)
Object.values(foundry.applications.instances).map(a => a.constructor.name).join(',')

// 6. Take a screenshot to confirm visually
// (bridge screenshot action)

// 7. Defensive cleanup — close all open apps + remove their DOM
for (const app of Object.values(foundry.applications.instances)) {
  try { app.close(); } catch(e){}
}
document.querySelectorAll('.application').forEach(el => el.remove())
```

This pattern verified all three remaining c1 UI flows (editElysiumID button click, drag-drop `_onDropItemCreate`, NoteConfig map-note hide-background) end-to-end with full DOM probes and screenshots — no bridge stalls.

### What does NOT work

- **Waiting**: 20+ seconds of `bridge.wait` does not recover a stuck bridge.
- **`app.close()` alone**: marks the application closed in `foundry.applications.instances` (the registry drops to 0) but doesn't always remove the DOM in time for the next bridge call. The DOM removal must happen explicitly.
- **Trying to open another popup as a "focus flush"** (the previously-imagined workaround based on a half-remembered "popup-close trick" phrasing): the JS call to open the popup never executes because the bridge is already stuck. The DOM-remove call works because it's a synchronous DOM operation that completes whether or not the bridge can read the result back.
- **`computer.left_click` on application elements while a Foundry sheet is open**: usually triggers the chrome-extension URL error. Use JS-side `.click()` instead.

### When you cannot recover the bridge

If the bridge is fully stuck and JS dispatch is blocked, **ask the user to manually close the open Foundry window**. They can click the X on the open sheet. After their click, the bridge is healthy again within 1 second.

This is not graceful, but it's reliable. Better to ask once than burn 5 cycles trying to self-recover.

---

## Methodology lineage

This workaround was discovered during v1.1.0 c1 verification (2026-05-16). The conversation history shows a prior session reportedly found the same trick, but Claude's memory didn't retain the specifics across the session boundary. This document is the durable record so future sessions don't have to rediscover it from scratch.

Reference: see `CHANGELOG.md` `[1.1.0]` entry's "Verification methodology for c1 post-install" section for the c1 UI-flows that the workaround unblocked.
