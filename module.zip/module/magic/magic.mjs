/**
 * Elysium Magic System Manager
 *
 * Handles mechanics shared across the five magic systems:
 *   - Power Points pool (universal resource)
 *   - SL accumulation tracking (Arcane multi-round casts)
 *   - MP allocation logic
 *   - School efficiency lookup
 *   - Overcasting damage
 *   - Scroll/Permanent Rune POW management
 *   - Casting penalty application
 *   - Patron standing for Divine
 *   - Sorcery essence growth thresholds
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'

export class ElysiumMagic {

  // === POWER POINTS =================================================

  /**
   * Spend PP from actor pool.
   * If overcasting is enabled and PP would go negative, deal HP damage.
   */
  static async spendPP (actor, amount, options = {}) {
    if (amount <= 0) return true

    const current = actor.system.power?.value || 0
    const overcastEnabled = getSetting('enableOvercasting', true)

    if (current >= amount) {
      // Normal spend
      await actor.update({
        'system.power.value': current - amount,
      })
      return true
    }

    // Insufficient PP
    if (!overcastEnabled) {
      ui.notifications.warn(game.i18n.format('Elysium.Magic.InsufficientPP', {
        actor: actor.name, current, required: amount,
      }))
      return false
    }

    // Overcasting: PP debt becomes HP damage
    const deficit = amount - current
    const hpDamage = deficit * (options.overcastMultiplier || 1)

    await actor.update({
      'system.power.value': 0,
      'system.health.value': Math.max(0, (actor.system.health?.value || 0) - hpDamage),
    })

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div class="elysium-overcast">
          <h4>${actor.name} — ${game.i18n.localize('Elysium.Magic.Overcast')}</h4>
          <p>${game.i18n.format('Elysium.Magic.OvercastDamage', {
            deficit, hpDamage,
          })}</p>
        </div>
      `,
    })

    return true
  }

  /**
   * Recover PP — call once per hour of game time per the rules
   */
  static async recoverPP (actor, asleep = false, hours = 1) {
    const current = actor.system.power?.value || 0
    const max = actor.system.power?.max || ElysiumActorExtension.calculatePowerPointsMax(actor)

    let recovery = hours * 1
    if (asleep) {
      const hr = actor.flags?.elysium?.derived?.healingRate || 1
      recovery = hours * hr
    }

    const newValue = Math.min(max, current + recovery)
    await actor.update({
      'system.power.value': newValue,
    })

    return newValue
  }


  // === ARCANE: SUCCESS LEVELS / MP =================================

  /**
   * Calculate Success Levels from a casting roll.
   * SL = tens(skill) - tens(roll)
   */
  static calculateSL (rollTotal, skillTotal) {
    if (rollTotal > skillTotal) return 0    // failure → 0 SL
    const tensRoll  = Math.floor(rollTotal / 10)
    const tensSkill = Math.floor(skillTotal / 10)
    return Math.max(0, tensSkill - tensRoll)
  }

  /**
   * Determine MP cost for a school given user's school skill %.
   * Returns reduction object: { manaReduction, slReduction }
   */
  static getSchoolEfficiency (schoolSkillPct) {
    if (!getSetting('enableArcane', true)) return { manaReduction: 0, slReduction: 0 }

    for (const tier of ELYSIUM.ARCANE.schoolEfficiency) {
      if (schoolSkillPct >= tier.thresholdMin && schoolSkillPct <= tier.thresholdMax) {
        return tier
      }
    }
    return { manaReduction: 0, slReduction: 0 }
  }

  /**
   * Cast a spell from the Arcane system.
   * Returns the cast outcome.
   */
  static async castArcane (actor, spell, options = {}) {
    if (!getSetting('enableArcane', true)) return null

    const technique = options.techniqueSkill || 0
    const form      = options.formSkill || 0
    const school    = options.schoolSkill || 0
    const mpAllocated = options.mp || 1

    const schoolBonus = (school > 50) ? Math.floor((school - 50) / 10) * 5 : 0
    const castSkill = Math.min(technique, form) + schoolBonus

    // Apply armour penalty if enabled
    let finalSkill = castSkill
    if (getSetting('enableArmourCastingPenalty', true)) {
      const cp = actor.flags?.elysium?.derived?.castingPenalty
      if (cp?.finalPenalty) finalSkill += cp.finalPenalty
    }

    // Difficulty
    if (options.improvised) finalSkill -= 20

    finalSkill = Math.max(1, finalSkill)

    const roll = await new Roll('1d100').evaluate()
    const sl = this.calculateSL(roll.total, finalSkill)
    const isFumble = roll.total >= 99

    const efficiency = this.getSchoolEfficiency(school)
    const requiredSL = Math.max(1, mpAllocated - efficiency.slReduction)
    const ppCost = Math.max(0, mpAllocated - efficiency.manaReduction)
                  + (options.improvised ? ELYSIUM.ARCANE.improvisedManaSurcharge : 0)

    const succeeded = (sl >= requiredSL) && !isFumble

    if (isFumble) {
      // Fumble: all SL lost
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<p>⚠ ${game.i18n.localize('Elysium.Magic.ArcaneFumble')} — ${spell.name}</p>`,
      })
      return { succeeded: false, fumble: true, roll: roll.total, sl: 0, ppCost: 0 }
    }

    if (succeeded) {
      await this.spendPP(actor, ppCost)
    }

    return {
      succeeded,
      roll: roll.total,
      sl,
      requiredSL,
      ppCost,
      finalSkill,
    }
  }


  // === DIVINE: STANDING =============================================

  /**
   * Get current PP recovery rate based on Patron standing
   */
  static getDivineRecoveryRate (actor) {
    const standing = actor.flags?.elysium?.patron?.standing || 'faithful'
    return ELYSIUM.DIVINE.ppRecoveryStanding[standing]
  }

  /**
   * Set patron standing (GM action)
   */
  static async setPatronStanding (actor, standing) {
    if (!ELYSIUM.DIVINE.standings.includes(standing)) {
      ui.notifications.error(`Invalid standing: ${standing}`)
      return false
    }
    await actor.update({
      'flags.elysium.patron.standing': standing,
    })
    return true
  }


  // === SORCERY: ESSENCE GROWTH =====================================

  /**
   * Lookup growth tier for an essence skill %
   */
  static getEssenceGrowthTier (essenceSkillPct) {
    if (essenceSkillPct >= 100) return 'transcendent'
    if (essenceSkillPct >= 76)  return 'potent'
    if (essenceSkillPct >= 51)  return 'established'
    if (essenceSkillPct >= 26)  return 'developing'
    return 'nascent'
  }

  /**
   * Get resistance difficulty against a sorcery ability
   */
  static getSorceryResistanceDifficulty (essenceSkillPct) {
    if (essenceSkillPct >= 91) return 'extremelyDifficult'
    if (essenceSkillPct >= 76) return 'veryDifficult'
    if (essenceSkillPct >= 51) return 'difficult'
    return 'standard'
  }


  // === MYSTICISM: MEDITATION =======================================

  /**
   * Recover PP through 1 hour of meditation.
   * Cannot be combined with sleep.
   */
  static async meditate (actor, hours = 1) {
    if (!getSetting('enableMysticism', true)) return null

    const pow = ElysiumActorExtension._parseStatTotal(actor.system.stats?.pow)
    const powBonus = Math.max(1, ElysiumMagic._powBonus(pow))

    const current = actor.system.power?.value || 0
    const max = actor.system.power?.max || pow
    const recovery = (powBonus * hours)
    const newValue = Math.min(max, current + recovery)

    await actor.update({
      'system.power.value': newValue,
    })

    return { recovered: newValue - current, total: newValue }
  }

  static _powBonus (pow) {
    if (pow <= 4)  return -2
    if (pow <= 8)  return -1
    if (pow <= 12) return 0
    if (pow <= 16) return 1
    if (pow <= 20) return 2
    return 3
  }


  // === SCROLLS & PERMANENT RUNES ===================================

  /**
   * Inscribe a scroll — costs temporary POW
   */
  static async inscribeScroll (actor, spellMP, options = {}) {
    const tempPow = (actor.flags?.elysium?.tempPowSacrificed || 0)
    await actor.update({
      'flags.elysium.tempPowSacrificed': tempPow + ELYSIUM.ARCANE.scrollPowSacrifice,
    })

    return {
      cost: ELYSIUM.ARCANE.scrollPowSacrifice,
      total: tempPow + ELYSIUM.ARCANE.scrollPowSacrifice,
    }
  }

  /**
   * Permanent rune — 1 POW per 5 MP permanent
   */
  static calculateRunePowCost (totalMP) {
    return Math.ceil(totalMP / ELYSIUM.ARCANE.permanentRunePerMP)
  }
}
