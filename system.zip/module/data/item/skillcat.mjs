/**
 * SkillcatDataModel — schema for items of type 'skillcat' (skill category).
 *
 * Skill-category items configure how a skill-category bonus is computed
 * from the actor's stats:
 *   - `attrib`: 8 stats (str/con/int/siz/pow/dex/cha/edu) → tier string
 *     "0".."4" indicating primary/secondary/negative role per the
 *     _categoryprimary/_categorysecondary/_categorynegative formulas
 *     in actor.mjs.
 *   - `stat`: single-stat override (or 'none' to use the attrib formula).
 *     When set, actor.mjs uses `Math.ceil(systemData.stats[stat].total / 2)`
 *     as the bonus.
 *   - `mod`: flat numeric modifier added on top.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. Uses makeItemBase().
 *
 * Implementation notes:
 *   - `attrib` values are STRINGS, not numbers — actor.mjs's switch
 *     compares against literal "0".."4" strings (see template.json
 *     defaults which use string literals). Preserve string typing.
 *   - `attrib` uses an explicit SchemaField (not TypedObjectField) because
 *     the 8 keys are FIXED: str/con/int/siz/pow/dex/cha/edu. This is the
 *     "include edu" set; actor.mjs skips edu at read time per the v0.20.0
 *     "EDU not used in Elysium" comment, but the field is kept for storage
 *     compatibility.
 *   - `stat` has a choices list including 'none' plus all 8 stats.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

const ATTRIB_TIER_CHOICES = ['0', '1', '2', '3', '4']
const STAT_OVERRIDE_CHOICES = ['none', 'str', 'con', 'int', 'siz', 'pow', 'dex', 'cha', 'edu']

function makeAttribTierField () {
  return new fields.StringField({ initial: '0', choices: ATTRIB_TIER_CHOICES })
}

export class SkillcatDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      attrib: new fields.SchemaField({
        str: makeAttribTierField(),
        con: makeAttribTierField(),
        int: makeAttribTierField(),
        siz: makeAttribTierField(),
        pow: makeAttribTierField(),
        dex: makeAttribTierField(),
        cha: makeAttribTierField(),
        edu: makeAttribTierField(),
      }),
      stat: new fields.StringField({ initial: 'none', choices: STAT_OVERRIDE_CHOICES }),
      mod:  new fields.NumberField({ integer: true, initial: 0 }),
    }
  }
}
