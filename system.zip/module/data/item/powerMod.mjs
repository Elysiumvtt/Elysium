/**
 * PowerModDataModel — schema for items of type 'powerMod'.
 *
 * Power modifiers tweak a super-power's effective cost (cpcMod) and may
 * be marked as "per-level" (perLvl) to scale with the parent super's level.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. Uses makeItemBase().
 *
 * Field set matches template.json exactly. Same {shortDesc, cpcMod} pair
 * as `failing`: `shortDesc` is an optional display-name override surfaced
 * by the actor-sheet super tab's row partials. Labeled "Display Name"
 * (i18n key `Elysium.displayName`) on the item sheet. Plus the `perLvl`
 * toggle.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class PowerModDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      shortDesc: new fields.StringField({ initial: '' }),
      cpcMod:    new fields.NumberField({ integer: true, initial: 0 }),
      perLvl:    new fields.BooleanField({ initial: false }),
    }
  }
}
