/**
 * HitLocationDataModel — schema for items of type 'hit-location'.
 *
 * Per P6.3 spec (docs/p6-3-handoff.md). Stored-schema-only.
 * 23 compendium items in hit-locations.db.
 *
 * Notable schema decisions:
 *   - DECLARES BASE despite template's `"templates": []`. Compendium
 *     hit-locations populate `description: ""` on every item, and
 *     strict validation needs the field declared to accept those
 *     writes. Zero code reads hit-location.description; the field is
 *     pure compendium-content metadata. Template-vs-compendium
 *     mismatch flagged for P12.
 *   - DECLARES LEGACY ballistic fields `bap` and `bapRnd` (not in
 *     template). Both ride along on every compendium hit-location even
 *     though v0.21.0 removed ballistic-armor from the system. Same
 *     pattern as the av2/avr2/armBal/armVar fields on armor — required
 *     to accept compendium drops, but zero code reads them. P12 to
 *     regenerate compendium without these and then drop schema decls.
 *   - `criticalEntry` is `ObjectField({ nullable: true, initial: null })`
 *     per compendium content (23/23 are null). Shape unknown when
 *     populated; permissive ObjectField.
 *   - `locType` is the only locked enum here: ['abdomen', 'chest',
 *     'general', 'head', 'limb']. 5 well-bounded values.
 *   - v1.0.0-alpha.11 (side-finding #13): hit-location's `creatureType`
 *     was renamed to `bodyPlan`. It was conceptually a body-plan template
 *     tag (humanoid skeleton, quadruped skeleton, hexapod skeleton, etc.)
 *     overlapping in name only with actor-side `creatureType` (creature
 *     classification: humanoid/beast/undead/...). They live at different
 *     paths and represent different concepts; rename disambiguates.
 *   - DROPS three `_doc` keys from template.json's
 *     `hit-location.elysium`: _bodyPart_doc, _side_doc, _index_doc.
 *     They're template-only documentation strings, not real fields.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class HitLocationDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      displayName:    new fields.StringField({ initial: '' }),
      // v1.0.0-alpha.11 (side-finding #13): renamed from creatureType.
      bodyPlan:       new fields.StringField({ initial: '' }),
      lowRoll:        new fields.NumberField({ integer: true, initial: 0 }),
      highRoll:       new fields.NumberField({ integer: true, initial: 0 }),
      fractionHP:     new fields.NumberField({ initial: 1 }),    // non-integer (can be fractional)
      fractionENC:    new fields.NumberField({ initial: 1 }),    // non-integer
      map:            new fields.NumberField({ integer: true, initial: 0 }),
      hide:           new fields.BooleanField({ initial: true }),
      locType: new fields.StringField({
        initial: 'limb',
        choices: ['abdomen', 'chest', 'general', 'head', 'limb'],
      }),
      bleeding:       new fields.BooleanField({ initial: false }),
      dead:           new fields.BooleanField({ initial: false }),
      severed:        new fields.BooleanField({ initial: false }),
      incapacitated:  new fields.BooleanField({ initial: false }),
      currHP:         new fields.NumberField({ integer: true, initial: 0 }),
      maxHP:          new fields.NumberField({ integer: true, initial: 0 }),
      // wounds: array of stored wound objects (populated at runtime by the damage system).
      // ObjectField inner shape — wounds are stored differently from the wound item DataModel.
      wounds:         new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      adj:            new fields.NumberField({ integer: true, initial: 0 }),
      apRnd:          new fields.StringField({ initial: '0' }),  // string per template
      ap:             new fields.NumberField({ integer: true, initial: 0, min: 0 }),

      // v1.0.0-alpha.11 (side-finding #14): legacy ballistic fields
      // bapRnd and bap removed. They were pre-v0.21.0 BRP-classic
      // ballistic-armor remnants with zero code readers; compendium
      // regenerated to remove the ride-along values.

      elysium: new fields.SchemaField({
        creatureSubtype: new fields.StringField({ initial: '' }),
        creatureTags:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        criticalRolls:   new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
        criticalEntry:   new fields.ObjectField({ nullable: true, initial: null }),
        locationConditions: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
        maxHPModifier:   new fields.NumberField({ integer: true, initial: 0 }),
        bodyPart:        new fields.StringField({ initial: '' }),  // 'head'/'chest'/.../'wing'/'tail' or '' per _bodyPart_doc
        side:            new fields.StringField({ initial: '' }),  // 'left'/'right' or '' per _side_doc
        index:           new fields.NumberField({ integer: true, initial: 0, min: 0 }),  // enum index per _index_doc
        // _bodyPart_doc, _side_doc, _index_doc DROPPED — documentation only
      }),
    }
  }
}
