// =====================================================================
// ELYSIUM | Hit-Location-at-Attack — roll location at attack-roll time
// (v0.22.0-alpha.12 / Phase D)
// =====================================================================
//
// When a CM (combat-weapon) roll is made against a targeted defender,
// the d20 hit location is rolled at attack-roll time and stashed on
// the chatCard entry. This makes the location available to:
//   - The chat-card button injection (crit-armor button can pre-bind
//     the location)
//   - The damage-application flow (future Phase E may consume this)
//   - The GM as a narrative cue ("the swing comes in toward the head")
//
// Visibility is controlled by the `hitLocationVisibility` setting:
//   - 'gm-only' (default): the visible tag on the chat card is hidden
//     for non-GMs. The data itself stays on the card (the buttons need
//     it), only the visible tag is masked.
//   - 'everyone': the location is shown to all viewers.
//
// GM override (per the v0.22.0-alpha.12 design call): only the GM may
// override the rolled location. PC attackers see no dialog — their
// rolled location is final. The dialog appears only when the user
// driving the roll is a GM (typical NPC attacks, or GM-rolled PC
// attacks).
//
// The override is a pure narrative tool: no difficulty modifier, no
// resource cost. If a future phase wants called-shot mechanics
// (penalties, attribute trades), they can layer on top.
// =====================================================================

import { rollRandomHitLocation } from '../../combat/armor-vs-damage.mjs'
import { ElysiumActorDetails } from '../../apps/actorDetails.mjs'

/**
 * Roll a hit location on the defender of a CM attack roll. If the
 * driver is a GM, prompt for an optional override.
 *
 * Idempotent: if `config.hitLocationId` is already set (e.g. a re-roll
 * path), the function is a no-op.
 *
 * Side effect: sets `config.hitLocationId` and `config.hitLocationName`
 * on success. Leaves them undefined on failure (no defender, no
 * locations, etc.) so downstream code can detect the absence.
 *
 * @param {object} config - the ElysiumCheck roll config (mutated)
 * @returns {Promise<void>}
 */
export async function rollHitLocationForAttack (config) {
  // Gate: only for CM rolls with a real target.
  if (config?.rollType !== 'CM') return
  if (!config.targetId || !config.targetType || config.targetType === 'none') return
  if (config.hitLocationId) return   // idempotent

  // Resolve defender; bail if we can't find them.
  let defender = null
  try {
    defender = await ElysiumActorDetails._getParticipant(config.targetId, config.targetType)
  } catch (e) {
    return
  }
  if (!defender) return

  const locs = defender.items.filter(i => i.type === 'hit-location')
  if (locs.length === 0) return

  // Roll d20 via the existing helper.
  let chosen = null
  try {
    chosen = await rollRandomHitLocation(defender)
  } catch (e) {
    return
  }
  if (!chosen) return

  // If the user driving the roll is a GM, offer an override dialog.
  if (game.user?.isGM) {
    const override = await _promptGMOverride(defender, locs, chosen)
    if (override) chosen = override
  }

  config.hitLocationId   = chosen._id
  config.hitLocationName = chosen.system?.displayName || chosen.name
}

/**
 * Show the GM a brief dialog with the rolled location and a dropdown
 * of all the defender's hit locations to pick from. Returns the chosen
 * location item, or `null` if the GM accepted the rolled value.
 *
 * The dialog auto-cancels (resolves to null) if dismissed without a
 * choice, which is the same as accepting the roll.
 *
 * @param {Actor} defender
 * @param {Item[]} locs    - all hit-location items on the defender
 * @param {Item} rolled    - the d20-rolled location
 * @returns {Promise<Item|null>}
 */
async function _promptGMOverride (defender, locs, rolled) {
  const rolledName = rolled.system?.displayName || rolled.name
  const sortedLocs = [...locs].sort((a, b) =>
    (Number(b.system?.lowRoll) || 0) - (Number(a.system?.lowRoll) || 0)
  )
  const options = sortedLocs.map(l => {
    const name = l.system?.displayName || l.name
    const sel  = l._id === rolled._id ? ' selected' : ''
    return `<option value="${l._id}"${sel}>${name}</option>`
  }).join('')

  const content = `
    <div style="margin-bottom:6px;">
      Rolled hit location: <b>${rolledName}</b>
    </div>
    <div style="margin-bottom:6px;color:#666;font-size:11px;">
      As GM, you may override this (called-shot narrative tool — no penalty applied).
      Closing this dialog accepts the rolled location.
    </div>
    <div class="form-group">
      <label>Hit Location</label>
      <select name="elysium-hitloc-override" autofocus>${options}</select>
    </div>
  `

  let pickedId = null
  try {
    pickedId = await foundry.applications.api.DialogV2.prompt({
      window: { title: `Hit Location — Attack on ${defender.name}` },
      content,
      ok: {
        label: 'Accept / Override',
        callback: (event, button, dialog) => {
          const sel = dialog.element.querySelector('select[name="elysium-hitloc-override"]')
          return sel?.value || null
        },
      },
      rejectClose: false,
    })
  } catch (e) {
    // User cancelled or some error — accept the rolled location.
    return null
  }
  if (!pickedId || pickedId === rolled._id) return null
  return locs.find(l => l._id === pickedId) || null
}
