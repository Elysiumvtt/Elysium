// Additional Handlebar helpers

export const handlebarsHelper = function () {
  Handlebars.registerHelper('isAnd', function (cond1, cond2, options) {
    return (cond1 && cond2) ? options.fn(this) : options.inverse(this);
  }),

    Handlebars.registerHelper('isOr', function (cond1, cond2, options) {
      return (cond1 || cond2) ? options.fn(this) : options.inverse(this);
    })

  Handlebars.registerHelper('concat', function () {
    var outStr = '';
    for (var arg in arguments) {
      if (typeof arguments[arg] != 'object') {
        outStr += arguments[arg];
      }
    }
    return outStr;
  });

  Handlebars.registerHelper('toLowerCase', function (str) {
    return str.toLowerCase();
  });

  Handlebars.registerHelper('loop', function (from, to, inc, block) {
    var output = '';
    for (var i = from; i <= to; i += inc)
      output += block.fn(i);
    return output;
  });

  Handlebars.registerHelper('counter', function (index) {
    return index + 1;
  });

  Handlebars.registerHelper('concat', function () {
    var outStr = '';
    for (var arg in arguments) {
      if (typeof arguments[arg] != 'object') {
        outStr += arguments[arg];
      }
    }
    return outStr;
  });

  Handlebars.registerHelper('toLowerCase', function (str) {
    return str.toLowerCase();
  });

  // v0.9.0 — cast-card support helpers
  Handlebars.registerHelper('gt', function (a, b) {
    return Number(a) > Number(b);
  });

  Handlebars.registerHelper('lt', function (a, b) {
    return Number(a) < Number(b);
  });

  // v0.10.8 — eq helper. Foundry V13+ removed the built-in `eq`; we
  // need it for selected-option matching in the F/T per-row dropdowns
  // and for tradition checks in cast-card.hbs. Strict (===) comparison
  // after string coercion so type quirks (number vs string from data
  // attributes) don't cause false negatives.
  Handlebars.registerHelper('eq', function (a, b) {
    if (a == null && b == null) return true;
    if (a == null || b == null) return false;
    return String(a) === String(b);
  });

  Handlebars.registerHelper('percentOf', function (numerator, denominator) {
    const n = Number(numerator) || 0;
    const d = Number(denominator) || 1;
    if (d === 0) return 0;
    const pct = Math.round((n / d) * 100);
    return Math.max(0, Math.min(100, pct));
  });

}
