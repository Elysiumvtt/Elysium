// Auto-extracted from module/elysium/hooks/register-hooks.mjs by tools/extract-functions.mjs
// (v0.21.0 register-hooks refactor).
//
// Top-level Foundry hook handlers extracted from the central registerHooks
// dispatcher. Each function is exported by name; the dispatcher imports them
// and wires them via Hooks.on(eventName, handler).



import { ElysiumSheetExtension } from '../sheets/sheet-extension.mjs'

export async function _onRenderItemSheet (app, html, data) {
  await ElysiumSheetExtension.extendItemSheet(app, html, data)
}
