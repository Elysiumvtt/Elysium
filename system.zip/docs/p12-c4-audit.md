# P12 cluster 4 prep audit — color retoken + actor-itemDrop defensive pass + fatigue recovery type vocab

**Status**: PENDING
**Target alpha**: alpha.54
**Scope**: three work items per prior audits:
1. **F1' (renamed from c1 audit's F1)**: color-literal retoken sweep of `styles/elysium.css`
2. **F2**: defensive optional-chain pass over actor-itemDrop.mjs brittle sites
3. **F8**: align `_worstRecoveryType` helper vocabulary with the schema choices vocabulary

After c4 closes, **P12 ends** and v1.0.0-rc.1 is the next ship.

**Inheritance from**:
- P12 c1 audit Q1: F1 130-rgba leakage finding deferred to a standalone scoping audit
- P12 c3 acceptance pass: F2 (22 sibling sites in actor-itemDrop.mjs) and F8 (recovery type vocab mismatch surfaced from live verification)

---

## 1. Live measurement at alpha.53 baseline

### 1.1 F1' — color literal landscape in `styles/elysium.css`

Full color-literal scan at alpha.53. Earlier ship documentation tracked "130 rgba leaks" — the live count has grown slightly because c1, c2, c3 didn't reduce elysium.css color load. Honest numbers:

| Metric | styles/elysium.css | All other CSS combined |
|---|---|---|
| rgba/rgb literals | **133** | 55 (legacy 45, sheets 3, tokens 7) |
| Hex literals | **139** | 93 (legacy 18, sheets 7, tokens 67, tracker 1) |
| Named colors | 0 | 34 (legacy 20, tokens 13, tracker 1) |
| **Total color literals** | **272** | 182 |

The 272 literals in elysium.css are the **F1' target**. The 182 in other files include:
- 67 hex literals in `elysium-tokens.css` — these ARE the tokens, expected and correct
- 45 rgba + 18 hex + 20 named in `legacy.css` — orphan-cleanup territory, not c4 scope
- 3 rgba + 7 hex in `elysium-sheets.css` — small island, c4 candidate or v1.1.0
- 7 rgba in `elysium-tokens.css` (`--ely-surface-overlay`, `--ely-overlay-subtle`, `--ely-shadow-overlay`, +4 internal) — also correct, are token bodies

**Scope correction from c1 audit**: c1 reported "130 rgba leaks", which was accurate at alpha.50 baseline. Post-c1 + c2 + c3, the live count is **133 rgba + 139 hex = 272 color literals** in elysium.css. The c1 audit only measured rgba — hex literals were never counted. The actual scope is **2× what the c1 audit named**.

### 1.2 F1' — literal-to-token matching

How well do the 272 literals match existing `--ely-*` tokens via exact-string lookup?

| Match category | Count |
|---|---|
| Exactly matches an existing token | **3** (1.1%) |
| Doesn't match any token | **269** (98.9%) |
| Distinct unmatched values | **203** |

**A token-retoken-only strategy is not viable for the bulk of the surface.** Most literals are unique values that don't exist in the token system. The retoken effort would require either:
- Creating 50-100+ new tokens (large surface expansion)
- Accepting that many literals are true one-offs that should stay as literals
- Or some hybrid where high-frequency literals become tokens, low-frequency literals get a documented inline-comment exception

### 1.3 F1' — color family clustering

Grouping by base RGB (ignoring alpha) reveals the design landscape:

| Base RGB | Hex | Occurrences | Alpha variants | Role in design |
|---|---|---|---|---|
| `rgb(0, 0, 0)` | `#000000` | 17 | 0.03, 0.04, 0.05, 0.1, 0.15, 0.2, 0.25, 0.4 | Black overlays, drop-shadows, gradient stops |
| `rgb(120, 70, 30)` | `#78461e` | 15 | 0.08-0.35 (9 distinct) | Bronze accent — sheet borders, hover states |
| `rgb(136, 41, 41)` | `#882929` | 14 | 0.1, 0.3, 1.0 | **Project's signature crimson** — same as `--ely-accent-action` |
| `rgb(120, 50, 30)` | `#78321e` | 12 | 0.04-0.25 (7 distinct) | Bronze-red, related to 120/70/30 hue family |
| `rgb(140, 110, 60)` | `#8c6e3c` | 7 | 0.1, 0.3, 0.4, 0.5 | Gold-amber muted |
| `rgb(136, 136, 136)` | `#888888` | 7 | 1.0 | Neutral gray |
| `rgb(90, 56, 24)` | `#5a3818` | 5 | 1.0 | Deep bronze |

Top 4 hues account for 58 literals (21% of total). Top 25 hues account for ~50%. Coverage:

| Coverage | Bases required |
|---|---|
| 80% of all literals | top **88** distinct base hues |
| 90% | top **115** |
| 95% | top **129** |

The long tail is real: 142 distinct base RGB triples in 272 literals = average 1.9 occurrences per hue. Many literals are bespoke one-offs.

### 1.4 F1' — by-property breakdown

Where do the literals appear?

| Property | Literal count |
|---|---|
| `background` | 120 |
| `color` | 82 |
| `border` + `border-color` + `border-bottom` + `border-left` etc. | 64 |
| Misc (filter, gradient stops, shadow inline) | 6 |

Background and color use account for 75% of literals. Border use accounts for ~25%.

### 1.5 F2 — actor-itemDrop.mjs brittle sites

| Metric | Count |
|---|---|
| `.flags.elysium.elysiumidFlag` accesses without optional-chain | **22 brittle sites** |
| `.flags?.elysium?.elysiumidFlag` accesses (defensive) | 2 (L393 + L633) |

**Scope correction from c3 audit**: c3 reported 19 brittle sites. Live count post-c3 is 22. The miscount in c3 was because the regex match treated multi-access lines (e.g. L393's `.filter(dItm => dItm.flags?.elysium?.elysiumidFlag?.id).filter(cItm => cItm.flags.elysium.elysiumidFlag.id`) as one site when there are actually two (one defensive, one brittle, same line).

Brittle sites span:
- 12 sites in dup-check + skill-group-check logic (L62, L64, L68, L70, L106-109, L135-138, L155-158, L169-172, L183-186, L203-206)
- 5 sites in single-item id reads (L101, L300, L541, L575)
- 2 sites in defensive-chain-followed-by-brittle (L393, L633)
- The 2 already-defensive sites prove prior author awareness

All 22 are reachable from programmatic item-drop paths with malformed items (e.g., compendium imports from foreign systems, modules creating items without BRP-ID metadata).

### 1.6 F8 — recovery type vocabulary state

| Component | Vocabulary |
|---|---|
| Schema (`module/data/actor/_shared.mjs:104`) | `['physical', 'magical']` |
| Helper (`fatigue-manager.mjs::_worstRecoveryType`) | `{asphyxiation: 0, physical: 1, bloodloss: 2}` |

The two vocabularies share only `'physical'`. The schema is the source of truth (it's enforced at data layer; values outside `choices` would fail validation if Foundry enforced choices strictly — but `StringField.choices` is a soft validator that warns rather than rejects).

**Callsite landscape** (11 total calls across the system):
- `'physical'`: 9 callsites (combat bleed, effort failure × 2, manual increment/decrement, recovery decrement, setLevel default, plus the 2 setLevel internal calls)
- `'magical'`: 1 callsite (`magic.mjs:62` overcast path)
- `'asphyxiation'`: 0 callsites
- `'bloodloss'`: 0 callsites

The helper's vocabulary has 2 values (`asphyxiation`, `bloodloss`) that nothing in the system uses, and is missing the value (`magical`) that the overcast path actually passes. Result: the overcast call's `'magical'` is silently dropped by `_worstRecoveryType` — the helper returns the existing `typeA` (usually `'physical'`) because `order['magical']` is `undefined` and `undefined > anything` is `false`.

User impact: the schema's `magical` value never persists on actors — overcast fatigue always shows as physical-recovery. This is a soft bug (no crash, but the schema's design intent of distinguishing magical from physical fatigue recovery is moot).

### 1.7 Inline-style anti-pattern (FYI — not c4 scope)

While measuring for c4, also caught: **58 inline-style sites remaining** across .mjs files (mostly combat/casting/sheet-fields surface). The c2 audit estimated 31 in non-c2 paths; live count is higher. Top files: covering-stance.mjs (14), combat-card-buttons.mjs (8), combat-tab.mjs (8), outmanoeuvre.mjs (6).

This is **not c4 scope** per the cluster theme (color retoken + bug-fix). Flagged for either a future cluster or v1.1.0 polish. Recording here as future-work documentation.

---

## 2. Behavioural acceptance surface

c4 is a polish + bug-fix cluster. Acceptance is:

1. **Visual regression**: any literal-to-token retoken must not change rendered colors visibly. CSS computed-style verification before/after.
2. **Defensive guard**: F2 sites that previously threw on malformed items must skip cleanly. New programmatic item-drop test.
3. **Recovery type semantics**: F8 fix must ensure overcast tags fatigue as magical-recovery. Verify schema field correctly holds `'magical'` after overcast.
4. **No console errors during sheet rendering and chat-card posting** after all three fixes land.

---

## 3. Findings

### F1' — Scope is 2× larger than the c1 audit named

c1's F1 named 130 rgba leaks; live measurement at alpha.53 finds 272 color literals (133 rgba + 139 hex). The hex literals were never counted in c1's measurement. **Honest framing of the work**: the project has 272 color decisions in `styles/elysium.css`, of which 3 are tokenized and 269 are literals.

Treating all 269 as "leaks that must become tokens" is the maximalist position. A more honest position: many of the 269 literals are bespoke values that don't belong in a token system because they're truly one-off design decisions. The right scope question is: **which literals SHOULD be tokens?**

Candidates:
- High-frequency literals (top 4-25 bases) — these are repeated design decisions that ARE tokens in disguise. Examples: `#882929` ×9 is the project's signature crimson, IS exactly `--ely-accent-action`. Why isn't it `var(--ely-accent-action)`? Probably because the rule predates the token system.
- Low-frequency unique literals — true one-offs (a gradient stop, a specific opacity for a specific overlay). These should stay as literals with maybe an inline comment.

### F1' — Three viable strategies

**Strategy A — Maximalist tokenization**: create new tokens for every distinct color value not already tokenized. ~100 new tokens. Token system bloats to ~210 tokens. Hard to maintain. Not recommended.

**Strategy B — High-frequency tokenization**: introduce tokens for the top 4-25 most-frequently-used color bases. Retoken those literals (~58-110 occurrences). Long-tail literals stay as-is. Token system grows by ~15-25 entries. Pragmatic.

**Strategy C — Audit-only**: catalog the 272 literals, classify each, document which would become tokens in v1.1.0, but make no changes to elysium.css in c4. Defer the actual retoken to v1.1.0 polish.

### F1' — Pre-existing token-related issue

Note the **3 literals that DO match existing tokens** — these are particularly egregious cases:
- `rgb(0, 0, 0)` ×17 doesn't match `--ely-surface-overlay` which is `rgba(0, 0, 0, 0.7)` (alpha differs)
- `#882929` ×9 matches `--ely-accent-action: #8a2020`? Actually no, `#8a2020` vs `#882929` are different colors (off by 2 in red, 9 in green/blue). So they DON'T match — there are two near-identical project-crimson values floating around.

This is interesting: the system has both `#882929` (9 uses) and `--ely-accent-action: #8a2020` (the token). They're visually similar but not identical. Which is canonical? The token system says `#8a2020`; the actual elysium.css usage says `#882929`. Probably the token was defined at one alpha, the CSS rules predate the token system and use a slightly different value. **The retoken work would harmonize these**.

### F2 — Mechanical pass, low risk

22 sites. Each one becomes `?.flags?.elysium?.elysiumidFlag?.id`. The .filter(...) chain ones need a defensive `.filter(itm => itm.flags?.elysium?.elysiumidFlag?.id)` guard upstream before the .filter that accesses the ID. Estimated diff: ~40-60 LOC.

### F8 — One-function fix, but a design decision

The fix is small (~5 LOC: change the helper's vocabulary). But it requires a design decision: which vocabulary is right?

Options:
- **Option α**: Schema is canonical. Helper aligns to 2-value vocab (`physical`, `magical`). `_worstRecoveryType` returns the worse of the two (magical > physical, since magical fatigue is harder to recover from per Mythras).
- **Option β**: Helper had the right design intent (3 types). Update schema to `['physical', 'magical', 'asphyxiation', 'bloodloss']` to match. But no callsites pass `asphyxiation` or `bloodloss`, so the helper's vocab was speculative — extending the schema to match speculative code is wrong.

Option α is the right call. The schema and the callsites converge; the helper is the outlier.

### F1' / F2 / F8 interactions

The three items are independent. F1' is pure CSS; F2 is pure JS; F8 is one JS function. No interactions.

---

## 4. Cluster-4 options

### Option A — Full c4 maximalist scope

All three items, with F1' Strategy A (maximalist tokenization, 100+ new tokens). Largest scope, highest risk of visual regression.

### Option B — Honest c4 (RECOMMENDED)

All three items, with F1' Strategy B (high-frequency tokenization, ~15-25 new tokens). F2 + F8 as straightforward sub-items. Pragmatic scope, tractable verification.

### Option C — Split c4 from F1'

F2 + F8 ship in c4 (alpha.54). F1' becomes its own scoping audit + cluster (alpha.55 = c5). P12 grows from 4 clusters to 5.

### Option D — c4 minimal

F2 + F8 only. F1' deferred to v1.1.0. P12 stays at 4 clusters; v1.0.0-rc.1 comes faster. F1' scope as v1.1.0 polish opportunity.

---

## 5. Decisions (lockable now)

### D1 — Sub-cluster scope: Option B

Recommended. All three work items in c4. F1' Strategy B: tokenize the top 15-25 high-frequency color bases; long-tail literals stay as-is with documentation. F2 mechanical pass on 22 sites. F8 vocabulary alignment per Option α (schema canonical).

### D2 — F1' tokenization scope: top hues by frequency, with cutoff

Tokenize bases that appear ≥4 times in `styles/elysium.css`. At alpha.53 baseline, that's:
- `rgb(0, 0, 0)` ×17 — already `--ely-surface-overlay` (rgba 0.7) — add `--ely-surface-shadow` for darker drop variants; consider opacity tokens
- `rgb(120, 70, 30)` ×15 — new `--ely-accent-bronze` (and variants for alpha)
- `rgb(136, 41, 41)` ×14 — investigate vs. `#8a2020` discrepancy; harmonize to canonical project-crimson
- `rgb(120, 50, 30)` ×12 — new `--ely-accent-bronze-deep`
- `rgb(140, 110, 60)` ×7 — new `--ely-accent-amber-muted`
- `rgb(136, 136, 136)` ×7 — likely matches an existing text token? `--ely-text-muted` is `#888880` (close); audit per-occurrence
- `rgb(90, 56, 24)` ×5 — new `--ely-accent-bronze-shadow`
- `rgb(94, 52, 112)` ×4 — already close to `--ely-accent-mind`; harmonize
- `rgb(168, 60, 26)` ×4 — already close to `--ely-accent-fire`; harmonize
- `rgb(140, 100, 80)` ×4 — new token candidate
- `rgb(160, 60, 60)` ×4 — close to `--ely-accent-danger`; harmonize
- `rgb(90, 74, 48)` ×4 — new token candidate

~12 new tokens covers 96 literal occurrences (35% of the 272 total). Acceptable scope.

### D3 — Long-tail handling

Literals appearing 1-3 times stay as literals. Each becomes annotated with `/* one-off: <reason> */` comment if its location isn't self-documenting. This is honest documentation — not every color value should be a token.

### D4 — F2 methodology

Same defensive-guard pattern as the c3 F1 fix (`itm.flags?.elysium?.elysiumidFlag?.id`). For .filter chains, add `.filter(itm => itm.flags?.elysium?.elysiumidFlag?.id)` as the first filter in the chain. The 2 already-defensive sites (L393, L633) are the canonical pattern.

### D5 — F8 fix: align helper to schema (Option α)

Update `_worstRecoveryType` to:
```js
static _worstRecoveryType (typeA, typeB) {
  // worst = magical > physical (magical fatigue is harder to recover per Mythras)
  const order = { physical: 1, magical: 2 }
  if ((order[typeB] || 0) > (order[typeA] || 0)) return typeB
  return typeA
}
```

The `|| 0` defaults handle any future schema additions without throwing.

### D6 — Verification: live render + computed-style snapshot

c4 verification:
1. Before-ship: snapshot computed-style of representative sheets (character + 3 item types) via Chrome bridge
2. Apply F1' retoken
3. Re-snapshot after each retoken batch
4. Diff: any pixel-level color change requires manual review
5. Live-render confirms no visual regression

Plus the standard pre-flight sweep: CSS brace balance, JS parse, JSON parse, lang counts unchanged, etc.

---

## 6. Open questions

### Q1 (blocking) — Option B lock?

Per D1: yes, recommended. Override paths: `proceed option A` (maximalist), `proceed option C` (split F1' to c5), `proceed option D` (F2+F8 only, defer F1' to v1.1.0).

### Q2 (blocking) — F1' new token names

Per D2 the recommended new tokens are bronze-family + amber + harmonization tweaks. Override per-token name suggestions welcome.

Naming convention follows `--ely-accent-<HUE>[-<MOD>]`:
- `--ely-accent-bronze`, `--ely-accent-bronze-deep`, `--ely-accent-bronze-shadow`
- `--ely-accent-amber-muted`
- Plus 1-2 alpha-variant tokens if rgba is the common form

Alternative naming: `--ely-surface-bronze-tint` for translucent uses (rgba alphas < 0.5).

### Q3 (non-blocking) — F1' #882929 vs #8a2020 harmonization

Two near-identical project-crimson values exist. Options:
- A: Keep `--ely-accent-action: #8a2020` as canonical; retoken `#882929` ×9 → `var(--ely-accent-action)`. Visual delta: imperceptible (3 RGB units different = <2% perceived).
- B: Update `--ely-accent-action: #882929` (the more common literal); existing token consumers shift slightly. Visual delta: imperceptible the other direction.
- C: Both are valid distinct shades; create `--ely-accent-action-deep: #882929` as a second crimson token.

A is recommended (minimal disruption to existing token consumers; the few sites using token rather than literal stay visually unchanged).

### Q4 (non-blocking) — F2 sweep diff size

~40-60 LOC across 22 sites. Smallest possible diff: just add `?` before each `.elysium.elysiumidFlag.id` access. Cleaner approach: refactor the duplicate-check patterns into a helper that takes (item, brpid) and returns boolean. Both work. Smaller diff is safer.

### Q5 (non-blocking) — F8 schema validation enforcement

Now: schema declares `choices: ['physical', 'magical']` but Foundry's StringField only warns on invalid choices (doesn't throw). If we want stricter enforcement, that's a separate scope. F8 is just the helper fix.

### Q6 (non-blocking) — c4 verification depth

Two levels:
- Light: pre-flight + smoke render of one sheet + manual look
- Deep: computed-style snapshot diff across N sheets/cards before & after

Light is c4 default. Deep is overkill for a polish cluster but possible if user requests.

### Q7 (non-blocking) — Order of operations

F1' / F2 / F8 are independent. Recommended order: F8 (smallest, sets the pattern) → F2 (mechanical sweep) → F1' (largest, most verification needed). Or F1' first (biggest visual change to get out of the way) → F2 → F8. Either works.

---

## 7. Recommendation

Lock c4 scope per D1-D6:

- **D1 Option B**: F1' (high-frequency tokenization) + F2 (22-site defensive pass) + F8 (helper vocab alignment)
- **D2** ~12 new tokens for top bases by frequency
- **D3** Long-tail literals stay as literals with inline comments
- **D4** Defensive-guard pattern matching c3's F1 fix
- **D5** Helper aligns to schema (Option α)
- **D6** Light verification: pre-flight + smoke render + manual look

**Estimated c4 ship contents**:
- `styles/elysium-tokens.css`: +~12 new tokens (~15 LOC)
- `styles/elysium.css`: ~96 literal retokens + ~50-80 inline comments for long-tail literals (~150 LOC delta in pattern: literal → `var(--ely-X)` substitution)
- `module/actor/actor-itemDrop.mjs`: 22 sites get optional-chain guards (~40 LOC)
- `module/elysium/fatigue/fatigue-manager.mjs`: `_worstRecoveryType` updated (~5 LOC)
- `system.json`: version bump
- `CHANGELOG.md`: entry with all three fixes documented
- `ROADMAP-v1.0.0.md`: execution log + P12 progress tracker update to "all 4 clusters shipped"

**Risk assessment**: low-medium.
- F1' has medium visual-regression risk (color changes are subtle but real). Mitigated by D6 verification.
- F2 is low-risk mechanical (defensive guards never make brittle code worse).
- F8 is low-risk (one function, well-understood semantic change).

**Net diff estimate**:
- CSS: +~30 LOC, modified ~150 lines
- JS: +~45 LOC
- Tokens: +~12 entries

**P12 progress after c4**:
- c1 ✓ (alpha.51) mechanical CSS + attribute cleanup
- c2 ✓ (alpha.52) inline-HTML ChatMessage.create migration
- c3 ✓ (alpha.53) lang completion + cumulative acceptance
- **c4 (alpha.54)** — this ship: color retoken + actor-itemDrop defensive pass + fatigue recovery type fix
- **After c4: P12 closes. v1.0.0-rc.1 next.**

---

## 8. Cluster-4 lock list additions (post-ship)

- ~12 new `--ely-accent-bronze*` / `--ely-accent-amber-muted` / variant tokens — locked as canonical color tokens
- No new audit-5 class hook locks expected (c4 is style + bug-fix, not surface migration)

---

## 9. Cross-references

- `docs/p12-c1-audit.md`: Q1 original F1 finding (130-rgba leaks named, hex literals not measured)
- `docs/p12-c3-audit.md`: F2 19-site count (now corrected to 22)
- `docs/v1.0.0-acceptance-results.md`: F8 vocabulary mismatch surfaced from live verification
- `styles/elysium-tokens.css`: 113 existing tokens, c4 adds ~12 more
- `styles/elysium.css`: 272 color literals at alpha.53 baseline
- `module/actor/actor-itemDrop.mjs`: 22 brittle sites + 2 defensive sites
- `module/elysium/fatigue/fatigue-manager.mjs`: helper requires vocab fix

---

## 10. Pre-decision checklist

Before responding `proceed with recommended`:

- [ ] Confirm F1' scope is 272 literals (not 130 — that was rgba-only)
- [ ] Confirm F2 count is 22 (not 19 — c3 audit miscounted)
- [ ] Accept D1 Option B: tokenize top hues, accept long-tail as literals
- [ ] Accept D2 token naming pattern (bronze-family + amber)
- [ ] Accept D5 Option α for F8 (schema canonical)
- [ ] Accept D6 light verification (no deep snapshot diff)

If overriding: `proceed option A` (maximalist tokens), `proceed option C` (split F1' to c5), `proceed option D` (minimal — F2+F8 only).

---

## 11. Phase-plan position

c4 is the **final cluster** of P12. After c4 ships:
- P12 closes (4 clusters total per the post-c1 plan)
- **v1.0.0-rc.1** is the next ship
- Pre-rc.1 manual acceptance run (the deferred MANUAL categories from c3) is the gate

If c4 surfaces new findings (likely from F1' visual diffing), routing per Q5: small visual regressions → in-cluster hotfix; structural color-system issues → defer to v1.1.0.

The "polish + acceptance" P12 theme delivers:
- c1: mechanical legacy cleanup
- c2: chat-card architecture finalization
- c3: i18n completion + bug-surfacing acceptance
- c4: color system harmonization + remaining latent-bug closure

P12 ships v1.0.0-ready code. v1.0.0-rc.1 is just bundling + manual verification.
