/**
 * Custom Spell Builder (v0.16.0).
 *
 * Live spell-authoring dialog opened from the Arcane tab's "Cast Custom"
 * button. The wizard picks the spell's identity (name, school, Forms,
 * Techniques, isDamageSpell flag, requiredSL, basePP), and the dialog
 * creates a real spell item on the actor, then invokes the standard
 * arcane casting pipeline.
 *
 * After the cast resolves, the dialog offers "save to spellbook" or
 * "discard" — saving keeps the item permanent for future casts; discard
 * removes it. The discard prompt happens whether the cast succeeded,
 * fizzled, or wild-magicked, so the player can decide based on outcome.
 *
 * Pre-create-then-cast flow chosen for simplicity:
 *   - Cast pipeline reads from a real Foundry document, not a synthetic.
 *   - Player can decide to keep based on how the cast went.
 *   - Cleanup is straightforward (delete the item on discard).
 *
 * Filters:
 *   - School picker offers only schools the actor has the skill for.
 *   - Form picker offers only Forms the actor knows (skill items with
 *     arcaneRole === 'form' on the actor).
 *   - Technique picker likewise for Techniques.
 *   - If the actor has zero Forms or Techniques, the dialog warns the
 *     player and refuses to open.
 */

import { beginArcaneCast } from './arcane-cast.mjs'
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api

export class CustomSpellBuilder extends HandlebarsApplicationMixin(ApplicationV2) {

  constructor (options = {}) {
    super(options)
    this._actor = options.actor
    this._draft = {
      name: 'Custom Spell',
      school: '',
      forms: [],
      techniques: [],
      isDamageSpell: false,
      requiredSL: 1,
      basePP: 1,
    }
    this._resolve = null
    this._promise = new Promise(res => { this._resolve = res })
    this._resolved = false
  }

  static DEFAULT_OPTIONS = {
    id: 'elysium-custom-spell-builder',
    classes: ['elysium', 'custom-spell-builder'],
    tag: 'div',
    window: {
      title: 'Cast Custom Spell',
      icon: 'fas fa-magic',
      resizable: true,
    },
    position: { width: 560, height: 'auto' },
    actions: {
      proceed: CustomSpellBuilder._onProceed,
      cancel:  CustomSpellBuilder._onCancel,
      toggleForm: CustomSpellBuilder._onToggleForm,
      toggleTechnique: CustomSpellBuilder._onToggleTechnique,
      toggleDamage: CustomSpellBuilder._onToggleDamage,
    },
  }

  static PARTS = {
    body: { template: 'systems/elysium/templates/casting/custom-spell-builder.hbs' },
  }

  /** Public API: open and await a spell-cast outcome. */
  static async open (actor) {
    if (!actor) return null

    // Sanity check — must own at least one school skill, one Form, one Technique.
    const schoolSkills = (actor.items?.contents ?? []).filter(i =>
      i.type === 'skill' && i.system?.elysium?.skillSubgroup === 'arcane' &&
      !['form', 'technique'].includes(i.system?.elysium?.arcaneRole))
    if (schoolSkills.length === 0) {
      ui.notifications?.warn(
        `${actor.name} has no arcane school skills. Drag a school like ` +
        `Evocation or Abjuration from the Skills compendium first.`)
      return null
    }

    const formSkills = (actor.items?.contents ?? []).filter(i =>
      i.type === 'skill' && i.system?.elysium?.arcaneRole === 'form')
    if (formSkills.length === 0) {
      ui.notifications?.warn(
        `${actor.name} has no Forms. Drag at least one Form from the ` +
        `Arcane Knowledge compendium first.`)
      return null
    }

    const techSkills = (actor.items?.contents ?? []).filter(i =>
      i.type === 'skill' && i.system?.elysium?.arcaneRole === 'technique')
    if (techSkills.length === 0) {
      ui.notifications?.warn(
        `${actor.name} has no Techniques. Drag at least one Technique from ` +
        `the Arcane Knowledge compendium first.`)
      return null
    }

    const dialog = new CustomSpellBuilder({ actor })
    dialog._schoolSkills = schoolSkills
    dialog._formSkills = formSkills
    dialog._techSkills = techSkills
    dialog._draft.school = schoolSkills[0]?.name ?? ''
    dialog.render(true)
    return dialog._promise
  }

  async _prepareContext (_options) {
    return {
      draft: this._draft,
      schoolOptions: (this._schoolSkills ?? []).map(s => ({
        name: s.name,
        selected: s.name === this._draft.school,
      })),
      formOptions: (this._formSkills ?? []).map(s => ({
        id: s.id,
        name: s.name,
        specName: s.system?.specName ?? s.name,
        selected: this._draft.forms.includes(s.system?.specName ?? s.name),
      })),
      techniqueOptions: (this._techSkills ?? []).map(s => ({
        id: s.id,
        name: s.name,
        specName: s.system?.specName ?? s.name,
        selected: this._draft.techniques.includes(s.system?.specName ?? s.name),
      })),
    }
  }

  // ===== Event delegations: capture inputs as the player edits =========

  _onChangeForm (event) {
    // Native input change events; we use this for text/number inputs.
    const target = event.target
    if (!target || !target.matches('input, select')) return
    const field = target.dataset.field
    if (!field) return
    if (field === 'name') {
      this._draft.name = String(target.value ?? '').trim() || 'Custom Spell'
    } else if (field === 'school') {
      this._draft.school = String(target.value ?? '')
    } else if (field === 'requiredSL') {
      this._draft.requiredSL = Math.max(1, Number(target.value) || 1)
    } else if (field === 'basePP') {
      this._draft.basePP = Math.max(0, Number(target.value) || 0)
    }
  }

  /**
   * Override _attachPartListeners to wire up native input events
   * (since the action dispatch only handles click events).
   */
  _attachPartListeners (partId, htmlElement, options) {
    super._attachPartListeners(partId, htmlElement, options)
    htmlElement.addEventListener('change', this._onChangeForm.bind(this))
    htmlElement.addEventListener('input', this._onChangeForm.bind(this))
  }

  // ===== Action handlers ==============================================

  static _onToggleForm (event, target) {
    const specName = target?.dataset?.specName
    if (!specName) return
    const idx = this._draft.forms.indexOf(specName)
    if (idx === -1) this._draft.forms.push(specName)
    else this._draft.forms.splice(idx, 1)
    this.render()
  }

  static _onToggleTechnique (event, target) {
    const specName = target?.dataset?.specName
    if (!specName) return
    const idx = this._draft.techniques.indexOf(specName)
    if (idx === -1) this._draft.techniques.push(specName)
    else this._draft.techniques.splice(idx, 1)
    this.render()
  }

  static _onToggleDamage () {
    this._draft.isDamageSpell = !this._draft.isDamageSpell
    this.render()
  }

  static async _onProceed () {
    if (this._resolved) return
    if (!this._draft.school) {
      ui.notifications?.warn('Pick a school for the custom spell.')
      return
    }
    if (this._draft.forms.length === 0) {
      ui.notifications?.warn('Pick at least one Form for the custom spell.')
      return
    }
    if (this._draft.techniques.length === 0) {
      ui.notifications?.warn('Pick at least one Technique for the custom spell.')
      return
    }
    // Build and save the spell item on the actor, then cast it.
    const spellData = _buildArcaneSpellItem(this._draft, /*custom*/true)
    this._resolved = true
    this.close()

    let createdSpell = null
    try {
      const created = await this._actor.createEmbeddedDocuments('Item', [spellData])
      createdSpell = created?.[0] ?? null
    } catch (err) {
      console.error('Elysium | Custom spell create failed:', err)
      ui.notifications?.error('Failed to create custom spell.')
      this._resolve(null)
      return
    }
    if (!createdSpell) {
      this._resolve(null)
      return
    }

    // Cast normally. After the cast resolves (or is abandoned), prompt
    // for keep-or-discard.
    await beginArcaneCast(this._actor, createdSpell)

    // Wait for the cast to fully resolve before prompting. The active-cast
    // flag is the signal — when it's gone, the cast is done.
    await _waitForCastToEnd(this._actor, createdSpell.id)

    // Prompt keep/discard.
    const keep = await foundry.applications.api.DialogV2.confirm({
      window: { title: 'Save to Spellbook?' },
      content: `<p>Keep <strong>${createdSpell.name}</strong> in
        ${this._actor.name}'s spellbook for future casts?</p>
        <p style="font-size: 0.9em; opacity: 0.85;">Choosing "No" will
        delete the spell item.</p>`,
      yes: { label: 'Keep' },
      no: { label: 'Discard' },
      defaultYes: false,
    })
    if (!keep) {
      try {
        await this._actor.deleteEmbeddedDocuments('Item', [createdSpell.id])
      } catch (err) {
        console.error('Elysium | Custom spell discard failed:', err)
      }
    }
    this._resolve({ keptSpellId: keep ? createdSpell.id : null })
  }

  static _onCancel () {
    if (this._resolved) return
    this._resolved = true
    this.close()
    this._resolve(null)
  }
}

/**
 * Build a Foundry-compatible arcane spell item-data object from a
 * builder draft. Schema matches template.json's arcane spell shape with
 * v0.16.0 additions (isDamageSpell, no magnitude).
 */
function _buildArcaneSpellItem (draft, custom = false) {
  return {
    name: draft.name,
    type: 'arcane',
    img: 'icons/svg/aura.svg',
    system: {
      description: custom
        ? `<p><em>Authored at cast time via the Custom Spell Builder.</em></p>`
        : '',
      cost: String(draft.basePP),
      mpCurr: 0,
      mpMax: 0,
      pcost: draft.basePP,
      magicChosen: true,
      spellCat: 'Custom',
      elysium: {
        school: draft.school,
        validSchools: [],
        techniques: draft.techniques,
        forms: draft.forms,
        requiredSL: draft.requiredSL,
        basePP: draft.basePP,
        isDamageSpell: !!draft.isDamageSpell,
        baseline: { range: 0, duration: 0, targets: 0, area: 0 },
        isReactive: false,
        isSustained: false,
        isRitual: false,
        isPermanent: false,
        powerCost: draft.basePP,
        apCost: 1,
        saveSkill: '',
      },
    },
  }
}

/**
 * Poll the actor's active-cast flag until it clears (cast is resolved)
 * or 60 seconds pass (timeout). The cast pipeline clears the flag on
 * completion, abandonment, or fizzle.
 */
async function _waitForCastToEnd (actor, spellId, timeoutMs = 60000) {
  const start = Date.now()
  while (Date.now() - start < timeoutMs) {
    const active = actor.getFlag('elysium', 'activeCast')
    if (!active || active.spellId !== spellId) return
    await new Promise(res => setTimeout(res, 500))
  }
  // Timeout — return anyway, prompts will still post but might be premature.
}
