/**
 * GearDataModel — schema for items of type 'gear'.
 *
 * Per P6.2 spec. Stored-schema-only. 150 compendium items across
 * equipment.db (76), conditions.db (50), and tomes.db (24).
 *
 * COMPENDIUM-DRIVEN FIELDS: `elysium.{arcaneRole, isTome, linkedSkill}`
 * are NOT in template.json but appear on tome compendium items. Schema
 * MUST declare them or tome drops fail strict validation.
 *
 * Notes:
 *   - `arcaneRole` on a gear item is DIFFERENT from `arcaneRole` on a
 *     skill item (the casting system reads skill.system.elysium.arcaneRole
 *     in cast-shared.mjs:289). Each type's DataModel declares it
 *     independently. The skill-side declaration comes in P6.5.
 *   - `isTome` and `linkedSkill` have ZERO code readers — pure metadata
 *     stored by content creators. Must still be declared for strict
 *     validation to allow the writes.
 *   - v1.0.0-alpha.11 (side-finding #8): `equipStatus` is now choices-
 *     locked to `['stowed', 'equipped']`. The elysium/hooks/item.mjs
 *     preCreateItem hook runs a PRE-validation normalizer (mutates
 *     `data` directly before cleanData runs) that maps legacy
 *     'carried'/'worn' compendium values to 'stowed'. Previously the
 *     normalizer ran post-validation, which forced the schema to leave
 *     equipStatus as a free StringField.
 *   - `enc` and `cost` are non-integer NumberFields (no `integer: true`)
 *     per template defaults (fractional values are stored).
 */

import { makeItemBase, migrateLegacyEquipStatus } from './_shared.mjs'

const fields = foundry.data.fields

export class GearDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      quantity:    new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      enc:         new fields.NumberField({ initial: 0 }),  // non-integer
      price:       new fields.StringField({ initial: '' }),
      cost:        new fields.NumberField({ initial: 0 }),  // non-integer
      equipStatus: new fields.StringField({
        initial: 'stowed',
        choices: ['stowed', 'equipped'],   // v1.0.0-alpha.11 (#8)
      }),
      pSCurr:      new fields.NumberField({ integer: true, initial: 0 }),
      pSMax:       new fields.NumberField({ integer: true, initial: 0 }),
      elysium: new fields.SchemaField({
        // Template-declared:
        isContainer:  new fields.BooleanField({ initial: false }),
        containedIn:  new fields.StringField({ initial: '' }),
        capacity:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // Compendium-driven (tome metadata):
        arcaneRole:   new fields.StringField({ initial: '' }),
        isTome:       new fields.BooleanField({ initial: false }),
        linkedSkill:  new fields.StringField({ initial: '' }),
      }),
    }
  }

  /**
   * v1.0.0-alpha.11 (side-finding #8): pre-validation normalizer for the
   * legacy compendium values 'carried' and 'worn' on equipStatus.
   * Runs before cleanData's choices check.
   */
  static migrateData (source) {
    return migrateLegacyEquipStatus(source)
  }
}
