import { ElysiumCharacterSheet } from '../actor/sheets/character.mjs'
import { ElysiumActorDetails } from './actorDetails.mjs'
import { ElysiumCheck } from './check.mjs'
import ElysiumDialog from '../setup/elysium-dialog.mjs';

export class ElysiumUtilities {

  static async getDataset(el, dataitem) {
    const elem = await el.target ? el.target : el[0];
    const element = await elem?.closest(".item");
    return element.dataset[dataitem];
  }

  static async triggerEdit(el, actor, dataitem) {
    const itemId = await this.getDataset(el, dataitem)
    if (!itemId) { return }
    const item = actor.items.get(itemId);
    item.sheet.render(true);
    return
  }

  static async triggerDelete(el, actor, dataitem) {
    const itemId = await this.getDataset(el, dataitem)
    if (!itemId) { return }
    const name = actor.items.get(itemId).name
    const type = actor.items.get(itemId).type
    const confirmation = await this.confirmation(name, type);
    if (confirmation) {
      await ElysiumCharacterSheet.confirmItemDelete(actor, itemId);
    }
    return confirmation
  }

  static async confirmation(name, type) {
    let title = ""
    if (type === 'chatMsg') {
      title = game.i18n.localize('Elysium.' + name)
    } else {
      title = game.i18n.localize('Elysium.delete') + ":" + game.i18n.localize('Elysium.' + type) + "(" + name + ")";
    }
    const confirmation = await ElysiumDialog.confirm({
      window: {title: title},
      content: game.i18n.localize('Elysium.proceed'),
    });
    return confirmation;
  }

  static async getDataFromDropEvent(event, entityType = 'Item') {
    if (event.originalEvent) return []
    try {
      const dataList = JSON.parse(event.dataTransfer.getData('text/plain'))
      if (dataList.type === 'Folder' && dataList.documentName === entityType) {
        const folder = await fromUuid(dataList.uuid)
        if (!folder) return []
        return folder.contents
      } else if (dataList.type === entityType) {
        const item = await fromUuid(dataList.uuid)
        if (!item) return []
        return [item]
      } else {
        return []
      }
    } catch (err) {
      return []
    }
  }

  static async careerDelete(event, actor) {
    const confirmation = await this.triggerDelete(event, actor, "itemId")
    if (!confirmation) { return }

  }

  //Update attributes
  static async updateAttribute(actor, token, att, adj) {
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor)
    let checkprop = ""
    const newVal = partic.system[att].value
    const newMax = partic.system[att].max
    if (adj === 'spend') {
      checkprop = { [`system.${att}.value`]: newVal - 1 }
    } else if (adj === 'recover' && newVal < newMax) {
      checkprop = { [`system.${att}.value`]: newVal + 1 }
    } else if (adj === 'restore') {
      checkprop = { [`system.${att}.value`]: newMax }
    } else { return }
    partic.update(checkprop)
  }

  //Create Macro
  static createMacro(bar, data, slot) {
    if (data.type !== 'Item') return
    const item = fromUuidSync(data.uuid, bar)
    if (!item) return
    let command = ''
    command = `game.elysium.rollItemMacro("${data.uuid}");`
    if (command !== '') {
      // Create the macro command
      const macro = game.macros.contents.find(
        m => m.name === item.name && m.command === command
      )
      if (!macro) {
        Macro.create(foundry.utils.duplicate({
          name: item.name,
          type: 'script',
          img: item.img,
          command: command,
          flags: { "elysium.itemMacro": true }
        })).then(macro => {
          game.user.assignHotbarMacro(macro, slot)
        })
        return false
      }
      game.user.assignHotbarMacro(macro, slot)
      return false
    }
    return true
  }

  //Convert to Kebab Case
  static toKebabCase(s) {
    if (!s) {
      return ''
    }
    const match = s.match(/[A-Z]{2,}(?=[A-Z][a-z]+[0-9]*|\b)|[A-Z]?[a-z]+[0-9]*|[A-Z]|[0-9]+/g)

    if (!match) {
      return ''
    }

    return match.join('-').toLowerCase()
  }

  //Copy to Clipboard
  static async copyToClipboard(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text)
      } else {
        const textArea = document.createElement('textarea')
        textArea.value = text
        textArea.style.position = 'fixed'
        textArea.style.left = '-999px'
        textArea.style.top = '-999px'
        document.body.appendChild(textArea)
        textArea.focus()
        textArea.select()
        return new Promise((resolve, reject) => {
          document.execCommand('copy')
            ? resolve()
            : reject(
              new Error(game.i18n.localize('Elysium.UnableToCopyToClipboard'))
            )
          textArea.remove()
        }).catch(err => ui.notifications.error(err))
      }
    } catch (err) {
      ui.notifications.error(game.i18n.localize('Elysium.UnableToCopyToClipboard'))
    }
  }

  //Regex expression
  static quoteRegExp(string) {
    // https://bitbucket.org/cggaertner/js-hacks/raw/master/quote.js
    const len = string.length
    let qString = ''

    for (let current, i = 0; i < len; ++i) {
      current = string.charAt(i)

      if (current >= ' ' && current <= '~') {
        if (current === '\\' || current === "'") {
          qString += '\\'
        }

        qString += current.replace(/[-[\]/{}()*+?.\\^$|]/g, '\\$&')
      } else {
        switch (current) {
          case '\b':
            qString += '\\b'
            break

          case '\f':
            qString += '\\f'
            break

          case '\n':
            qString += '\\n'
            break

          case '\r':
            qString += '\\r'
            break

          case '\t':
            qString += '\\t'
            break

          case '\v':
            qString += '\\v'
            break

          default:
            qString += '\\u'
            current = current.charCodeAt(0).toString(16)
            for (let j = 4; --j >= current.length; qString += '0');
            qString += current
        }
      }
    }
    return qString
  }

  //Sort by Name Key
  static sortByNameKey(a, b) {
    return a.name
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase()
      .localeCompare(
        b.name
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .toLocaleLowerCase()
      )
  }

  //Send Item Description to Chat
  static async sendToChat(el, actor, dataitem) {
    const itemId = await this.getDataset(el, dataitem)
    if (!itemId) { return }
    const item = actor.items.get(itemId);
    //let description = item.system.description.replace(/(<([^>]+)>)/g, "");
    const description = item.system.description
    const label = item.name
    // F15 (rc.7): chatType retired — see charDev.mjs:showXPChat. V14 ChatMessage.type
    // requires a string; the legacy CONST.CHAT_MESSAGE_STYLES.OTHER (=0) fails.
    // Dropping `type` lets V14 use its default ("base") which is correct for
    // item-description chat cards.
    const chatTemplate = 'systems/elysium/templates/chat/itemDescription.html'

    const chatMsgData = {
      description,
      label,
      chatTemplate,
    }
    const html = await ElysiumCheck.startChat(chatMsgData)

    const chatData = {
      author: game.user.id,
      content: html,
      speaker: {
        actor,
        alias: actor.name,
      },
    }
    const msg = await ChatMessage.create(chatData)
    return msg._id

  }

  static updateCharSheets () {
    if (game.user.isGM) {
      for (const a of game.actors.contents) {
        if (a?.type === 'character' && a?.sheet && a?.sheet?.rendered) {
          a.render(false)
        }
      }
    } else {
      for (const a of game.actors.contents) {
        if (a.isOwner) {
          a.render(false)
        }
      }
    }
  }

}
