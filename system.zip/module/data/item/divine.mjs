/**
 * DivineDataModel — schema for items of type 'divine'.
 *
 * Per P6.4 spec (docs/p6-4-handoff.md). Stored-schema-only. 30 compendium
 * items in spells-divine.db.
 *
 * Compendium content fully aligns with template.json (no compendium-only
 * fields). Side-finding #16: `domain` (top-level) duplicates
 * `elysium.domain` (same 6-value set across all compendium items) —
 * pre-existing redundancy, P12 to dedup.
 *
 * Schema decisions:
 *   - `cost` is a StringField with initial '1' (per template; same
 *     pattern as super.cpc/pppl from P6.2).
 *   - `apCostByTier` and `powCostByTier` are fixed-length-5 integer
 *     arrays (5 tiers). Foundry doesn't enforce array length; logical
 *     constraint only.
 *   - `effectByTier` is a SchemaField with 5 explicit string-digit keys
 *     ("1".."5"), each a string. Audit confirmed all 30 compendium
 *     items use exactly these 5 keys. Locks shape; P12 if mods ever
 *     want 6-tier spells.
 *   - All string enums (domain, damageType, saveSkill) left FREE
 *     per content-extensibility risk.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class DivineDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      category: new fields.StringField({ initial: '' }),
      range:    new fields.StringField({ initial: '' }),
      duration: new fields.StringField({ initial: '' }),
      cost:     new fields.StringField({ initial: '1' }),    // STRING per template
      domain:   new fields.StringField({ initial: '' }),

      elysium: new fields.SchemaField({
        domain:        new fields.StringField({ initial: '' }),
        tier:          new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        baseTier:      new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        maxTier:       new fields.NumberField({ integer: true, initial: 5, min: 0 }),

        // Fixed-length-5 arrays per tier (logical constraint, not schema-enforced)
        apCostByTier: new fields.ArrayField(
          new fields.NumberField({ integer: true }),
          { initial: [1, 1, 2, 2, 3] },
        ),
        powCostByTier: new fields.ArrayField(
          new fields.NumberField({ integer: true }),
          { initial: [0, 0, 0, 0, 0] },
        ),

        // Fixed 5-key SchemaField for tier-effect descriptions ("1".."5").
        // All 30 compendium items use exactly these keys.
        effectByTier: new fields.SchemaField({
          '1': new fields.StringField({ initial: '' }),
          '2': new fields.StringField({ initial: '' }),
          '3': new fields.StringField({ initial: '' }),
          '4': new fields.StringField({ initial: '' }),
          '5': new fields.StringField({ initial: '' }),
        }),

        isReactive:         new fields.BooleanField({ initial: false }),
        isRitual:           new fields.BooleanField({ initial: false }),
        ritualMinutes:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        powerCost:          new fields.NumberField({ integer: true, initial: 0 }),
        apCost:             new fields.NumberField({ integer: true, initial: 1 }),
        reactionCost:       new fields.NumberField({ integer: true, initial: 0 }),
        autoActivate:       new fields.BooleanField({ initial: true }),
        spellTags:          new fields.ArrayField(new fields.StringField(), { initial: [] }),
        minFaithRank:       new fields.NumberField({ integer: true, initial: 0 }),
        isDamageSpell:      new fields.BooleanField({ initial: false }),
        damageType:         new fields.StringField({ initial: '' }),
        saveSkill:          new fields.StringField({ initial: '' }),
        isSustained:        new fields.BooleanField({ initial: false }),
        maintainPPPerRound: new fields.NumberField({ integer: true, initial: 0 }),
      }),
    }
  }
}
