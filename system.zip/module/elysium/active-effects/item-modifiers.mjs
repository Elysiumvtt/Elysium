// =====================================================================
// ELYSIUM | item-modifiers.mjs
// =====================================================================
// Helpers for managing per-item Active Effects that grant modifiers
// to the wearing/wielding actor (v0.4.0+).
//
// Architecture:
//   - Each modifier on an item is its own AE with transfer:true and a
//     single change in changes[]
//   - AE name = item name (so the EFF tab groups visually by item)
//   - AE is tagged flags.elysium.itemModifier:true
//   - When item is worn/wielded → AE.disabled = false
//   - When item is carried/packed/stored → AE.disabled = true
//   - Foundry sums all enabled AEs onto actor.flags['elysium'].modifiers.*
//   - Code that needs a modifier reads `actor.flags['elysium'].modifiers.X`
//
// Items themselves never directly mutate actor data — everything goes
// through Foundry's AE system, so the EFF tab shows what's active and
// the player can see what's modifying their character.
// =====================================================================

import { ELYSIUM } from '../config/config.mjs'/* ===================================================================
 * MODE TRANSLATION
 * =================================================================== */

/** Map a preset's mode string to Foundry's CONST.ACTIVE_EFFECT_CHANGE_TYPES. */
export function presetModeToConst (mode) {
  const T = CONST.ACTIVE_EFFECT_CHANGE_TYPES
  switch ((mode || 'ADD').toUpperCase()) {
    case 'ADD':       return T.ADD
    case 'MULTIPLY':  return T.MULTIPLY
    case 'OVERRIDE':  return T.OVERRIDE
    case 'UPGRADE':   return T.UPGRADE
    case 'DOWNGRADE': return T.DOWNGRADE
    default:          return T.ADD
  }
}

/** Inverse: Foundry mode constant to a preset-friendly string. */
export function modeConstToPreset (modeConst) {
  const T = CONST.ACTIVE_EFFECT_CHANGE_TYPES
  switch (modeConst) {
    case T.ADD:       return 'ADD'
    case T.MULTIPLY:  return 'MULTIPLY'
    case T.OVERRIDE:  return 'OVERRIDE'
    case T.UPGRADE:   return 'UPGRADE'
    case T.DOWNGRADE: return 'DOWNGRADE'
    default:          return 'ADD'
  }
}

/* ===================================================================
 * ITEM MODIFIER QUERIES
 * =================================================================== */

/**
 * List all item-modifier AEs on a given item.
 * Returns the AE document objects (not raw data).
 */
export function listItemModifierAEs (item) {
  if (!item?.effects) return []
  return item.effects.filter(ae => ae.flags?.['elysium']?.itemModifier === true)
}

/* ===================================================================
 * CREATE / UPDATE / DELETE
 * =================================================================== */

/**
 * Add a new item-modifier AE to an item.
 *
 * @param {Item}    item      The owning item (typically armor/weapon/equip)
 * @param {Object}  options
 *   - presetKey    {string}  Optional MODIFIER_PRESETS key. If given,
 *                            the change.key, mode, and label come from the preset.
 *   - attributeKey {string}  Custom Attribute Key (used for "Custom..." entries).
 *                            Required if presetKey not given.
 *   - value        {string|number}  Modifier value. Strings allowed for dice.
 *   - mode         {string}  'ADD' | 'MULTIPLY' | 'OVERRIDE' | 'UPGRADE' | 'DOWNGRADE'
 *                            Defaults to preset's mode, then 'ADD'.
 *   - label        {string}  Optional override for the modifier label
 *
 * @returns {Promise<ActiveEffect>}
 */
export async function addItemModifier (item, options = {}) {
  const preset = options.presetKey ? ELYSIUM.MODIFIER_PRESETS[options.presetKey] : null
  const key    = options.attributeKey || preset?.key
  if (!key) throw new Error('addItemModifier: missing attributeKey or presetKey')

  const mode  = options.mode || preset?.mode || 'ADD'
  const label = options.label || preset?.label || key.split('.').pop()
  const value = options.value ?? 0

  // AE name = item name so the EFF tab groups by item visually.
  // The label of the modifier itself goes in flags so we can render it
  // in our own UI without losing it.
  const aeData = {
    name: item.name,
    icon: item.img || 'icons/svg/aura.svg',
    transfer: true,
    disabled: _isItemEquippedAsModifier(item) === false,
    changes: [{
      key,
      mode:  presetModeToConst(mode),
      value: String(value),
      priority: 20,
    }],
    flags: {
      elysium: {
        itemModifier: true,
        presetKey:    options.presetKey || null,
        modifierLabel: label,
      },
    },
  }

  const [created] = await item.createEmbeddedDocuments('ActiveEffect', [aeData])
  return created
}

/**
 * Update an existing item-modifier AE.
 *
 * @param {Item}         item
 * @param {string}       aeId
 * @param {Object}       changes
 *   - value        {string|number}
 *   - mode         {string}
 *   - attributeKey {string}  optional new key
 *   - label        {string}  optional new label
 */
export async function updateItemModifier (item, aeId, changes) {
  const ae = item.effects.get(aeId)
  if (!ae) return null

  const existingChange = ae.changes?.[0] || {}
  const newChange = {
    key:      changes.attributeKey ?? existingChange.key,
    mode:     changes.mode ? presetModeToConst(changes.mode) : existingChange.mode,
    value:    changes.value !== undefined ? String(changes.value) : existingChange.value,
    priority: existingChange.priority ?? 20,
  }

  const update = { changes: [newChange] }
  if (changes.label !== undefined) {
    update['flags.elysium.modifierLabel'] = changes.label
  }

  return await ae.update(update)
}

/**
 * Delete an item-modifier AE by id.
 */
export async function removeItemModifier (item, aeId) {
  const ae = item.effects.get(aeId)
  if (!ae) return null
  return await ae.delete()
}

/* ===================================================================
 * EQUIP STATE SYNC
 * =================================================================== */

/**
 * Should this item's modifier AEs be enabled, given its current equip state?
 *
 * v0.5.0+ uses a unified binary `equipStatus`:
 *   - 'equipped' → modifiers active (worn armor, wielded weapon, used gear)
 *   - 'stowed'   → modifiers disabled (in inventory, not in active use)
 */
function _isItemEquippedAsModifier (item) {
  return item?.system?.equipStatus === 'equipped'
}

/**
 * Sync all item-modifier AEs on the given item to match its equip state.
 * Called from the updateItem hook when equipStatus changes.
 *
 * @param {Item} item
 */
export async function syncEquipState (item) {
  const aes = listItemModifierAEs(item)
  if (aes.length === 0) return

  const shouldBeEnabled = _isItemEquippedAsModifier(item)
  const updates = aes
    .filter(ae => ae.disabled !== !shouldBeEnabled)
    .map(ae => ({ _id: ae.id, disabled: !shouldBeEnabled }))

  if (updates.length > 0) {
    await item.updateEmbeddedDocuments('ActiveEffect', updates)
  }
}

