import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumReputationSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['reputation'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template: 'systems/elysium/templates/item/reputation.detail.hbs',
      scrollable: ['']
    },
  }

  // Single-page (no tabs) — base hoist handles ['header', 'details']
  static TAB_ORDER = null

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const itemData = context.item
    itemData.system.total = itemData.system.base;

    // Header chips per c2-2 lock — Base score when owned only.
    const chips = [];
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.base'),
        value: String(this.item.system.base ?? 0),
      });
    }
    context.itemHeaderChips = chips;

    return context
  }

  _onRender(context, _options) {
  }
}
