/**
 * ArmorDataModel — schema for items of type 'armor'.
 *
 * Per P6.3 spec. Stored-schema-only. 26 compendium items in armor.db.
 *
 * Notable schema decisions:
 *   - LOCKED choices on three elysium enums: flexibility, layer,
 *     wornStratum. Each is mechanically meaningful with well-bounded
 *     values per the v0.20.0 layering rules.
 *   - LOCKED choices on equipStatus (added v1.0.0-alpha.11, #8): the
 *     preCreateItem normalizer in elysium/hooks/item.mjs now mutates
 *     data pre-validation so legacy 'carried'/'worn' compendium values
 *     are normalized to 'stowed' before the choices check runs.
 *   - FREE on `material`, `castingLocation`. material has 14 compendium
 *     values plus content-extensibility; castingLocation has only 'arm'
 *     observed (insufficient ground truth).
 *   - `castingPenaltyOverride` is nullable (null in all 26 compendium).
 *   - DROPS three `_doc` keys: _layer_doc, _wornStratum_doc, _apMax_doc.
 *   - `enc` and `cost` are non-integer NumberFields. Compendium has 26/26
 *     float enc values.
 *
 * v1.0.0-alpha.11 (side-finding #14): the four legacy ballistic-armor
 * fields (av2, avr2, armBal, armVar) were removed alongside their
 * compendium ride-along values. They were pre-v0.21.0 BRP-classic
 * ballistic-armor remnants with zero code readers.
 */

import { makeItemBase, migrateLegacyEquipStatus } from './_shared.mjs'

const fields = foundry.data.fields

export class ArmorDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      av1:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      avr1:       new fields.StringField({ initial: '' }),
      burden:     new fields.StringField({ initial: '' }),
      enc:        new fields.NumberField({ initial: 0 }),       // non-integer
      mnplmod:    new fields.NumberField({ integer: true, initial: 0 }),
      percmod:    new fields.NumberField({ integer: true, initial: 0 }),
      physmod:    new fields.NumberField({ integer: true, initial: 0 }),
      stealthmod: new fields.NumberField({ integer: true, initial: 0 }),
      sizRng:     new fields.NumberField({ integer: true, initial: 0 }),
      time:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      quantity:   new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      ppMax:      new fields.NumberField({ integer: true, initial: 0 }),
      ppCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      price:      new fields.StringField({ initial: '' }),
      cost:       new fields.NumberField({ initial: 0 }),       // non-integer
      hitlocID:   new fields.StringField({ initial: '' }),
      equipStatus: new fields.StringField({
        initial: 'stowed',
        choices: ['stowed', 'equipped'],   // v1.0.0-alpha.11 (#8)
      }),
      coverage:   new fields.StringField({ initial: '' }),
      pSCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      pSMax:      new fields.NumberField({ integer: true, initial: 0 }),

      elysium: new fields.SchemaField({
        flexibility: new fields.StringField({
          initial: 'flexible',
          choices: ['flexible', 'inflexible'],
        }),
        material:    new fields.StringField({ initial: 'cloth' }),  // FREE — 14 values, content-extensible
        layerOrder:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        castingLocation:        new fields.StringField({ initial: 'arm' }),  // FREE — only 'arm' observed
        castingPenaltyOverride: new fields.NumberField({ nullable: true, initial: null }),
        containedIn: new fields.StringField({ initial: '' }),
        layer: new fields.StringField({
          initial: 'worn',
          // Per _layer_doc: 'worn' (default), 'natural' (stacks freely),
          // 'magical' (one per location). Compendium has worn+magical.
          choices: ['worn', 'natural', 'magical'],
        }),
        wornStratum: new fields.StringField({
          initial: 'soft',
          // Per _wornStratum_doc: 'soft' (max 2 AP — leather/padded/gambeson),
          // 'mail' (max 3 AP — chain/scale/brigandine), 'plate' (max 5 AP — rigid plate).
          choices: ['soft', 'mail', 'plate'],
        }),
        apMax:       new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // _layer_doc, _wornStratum_doc, _apMax_doc DROPPED — documentation only
      }),
    }
  }

  /**
   * v1.0.0-alpha.11 (side-finding #8): pre-validation normalizer for the
   * legacy compendium values 'carried' and 'worn' on equipStatus.
   * Runs before cleanData's choices check.
   */
  static migrateData (source) {
    return migrateLegacyEquipStatus(source)
  }
}
