/**
 * Elysium Ancestry Drop Handler
 *
 * Hooks into the BRP-base culture item drop sequence to:
 *   - Confirm replacement if existing ancestry present
 *   - Apply stat modifiers as Active Effects
 *   - Apply BP/SP adjustments
 *   - Create Mutation items for racial traits
 *   - Apply natural armor/weapons
 *   - Apply resistance Active Effects
 *   - Add starting languages
 *   - Adjust stat natural maxima
 */

import { ELYSIUM } from '../config/config.mjs'
export class ElysiumAncestryDrop {

  static async handlePreCreate (item, data, options, userId) {
    if (!item.parent) return true
    const ancestryData = item.system?.elysium?.ancestry
    if (!ancestryData) return true   // not an Elysium ancestry; nothing to do

    const actor = item.parent

    // Check for existing ancestry on the actor
    const existing = actor.items.find(i =>
      i.type === 'culture' &&
      i.system?.elysium?.ancestry &&
      i.id !== item.id
    )

    if (existing) {
      // Show replacement dialog
      const confirmed = await this._confirmReplacement(actor, existing, item)
      if (!confirmed) return false

      // Remove existing ancestry items, AEs, mutations
      await this._cleanupAncestry(actor, existing.id)
      await existing.delete()
    }

    // Check for subraces
    if (ancestryData.subraces?.length > 0) {
      const subraceChoice = await this._chooseSubrace(item)
      if (!subraceChoice) return false
      // Store choice for post-create
      options.elysiumSubraceUuid = subraceChoice
    }

    return true
  }

  static async handlePostCreate (item, options, userId) {
    if (!item.parent) return
    const ancestry = item.system?.elysium?.ancestry
    if (!ancestry) return

    const actor = item.parent

    // 1. Apply stat modifiers as Active Effects
    if (ancestry.statMods?.length > 0) {
      await this._applyStatModifiers(actor, item, ancestry.statMods)
    }

    // 2. Adjust BP/SP pools
    if (ancestry.buildPoints || ancestry.skillPoints) {
      await this._adjustPointPools(actor, ancestry)
    }

    // 3. Create racial trait Mutations
    if (ancestry.traits?.length > 0) {
      await this._createTraitMutations(actor, item, ancestry.traits)
    }

    // 4. Apply natural armor
    if (ancestry.naturalArmor?.ap > 0) {
      await this._applyNaturalArmor(actor, item, ancestry.naturalArmor)
    }

    // 5. Apply natural weapons
    if (ancestry.naturalWeapons?.length > 0) {
      await this._applyNaturalWeapons(actor, item, ancestry.naturalWeapons)
    }

    // 6. Apply resistance AEs
    if (ancestry.resistances) {
      await this._applyResistances(actor, item, ancestry.resistances)
    }

    // 7. Apply starting languages
    if (ancestry.languages?.length > 0) {
      await this._applyLanguages(actor, ancestry.languages)
    }

    // 8. Adjust natural stat maxima
    await this._adjustStatMaxima(actor, ancestry.statMods)

    // 9. Update move stats from ancestry
    await this._applyAncestryMove(actor, ancestry)

    // 10. Apply hit-location set for this ancestry's body shape.
    // Reads ancestry.hitLocationSet (e.g. 'humanoid', 'quadruped'); defaults
    // to 'humanoid' if unset. Replaces any existing hit locations on the
    // actor to avoid mixing creature-type sets. Skipped if the actor
    // already has hit locations AND a subrace will run next (the subrace
    // can override) — handled by the subrace step which re-applies its own
    // set if specified.
    if (!options.elysiumSubraceUuid) {
      await this._applyHitLocationSet(actor, ancestry.hitLocationSet || 'humanoid')
    }

    // 11. Process subrace if selected
    if (options.elysiumSubraceUuid) {
      const subraceItem = await fromUuid(options.elysiumSubraceUuid)
      if (subraceItem) {
        const subraceData = subraceItem.toObject()
        subraceData.flags['elysium'] ??= {}
        subraceData.system.elysium.ancestry = subraceData.system.elysium.ancestry || {}
        subraceData.system.elysium.ancestry.parentId = item.id
        subraceData.system.elysium.ancestry.isSubrace = true
        await actor.createEmbeddedDocuments('Item', [subraceData])
        // Apply the subrace's hit-location set if it specifies one;
        // otherwise fall back to the parent ancestry's set.
        const subShape = subraceData.system.elysium.ancestry.hitLocationSet
                         || ancestry.hitLocationSet
                         || 'humanoid'
        await this._applyHitLocationSet(actor, subShape)
      }
    }

    // Record ancestry on actor
    await actor.update({
      'system.elysium.ancestryId': item.id
    }, { render: false })

    ui.notifications.info(
      game.i18n.format('Elysium.Ancestry.Applied', { name: item.name })
    )
  }

  static async handlePostDelete (item, options, userId) {
    if (!item.parent) return
    if (!item.system?.elysium?.ancestry) return
    await this._cleanupAncestry(item.parent, item.id)
  }

  // === IMPLEMENTATION ===============================================

  static async _confirmReplacement (actor, existing, newItem) {
    const content = `
      <div class="elysium-dialog">
        <p>${game.i18n.localize('Elysium.Ancestry.ReplaceWarning')}</p>
        <ul>
          <li><strong>${game.i18n.localize('Elysium.Ancestry.Current')}:</strong> ${existing.name}</li>
          <li><strong>${game.i18n.localize('Elysium.Ancestry.New')}:</strong> ${newItem.name}</li>
        </ul>
        <p>${game.i18n.localize('Elysium.Ancestry.ReplaceConsequences')}</p>
      </div>
    `
    // DialogV2.wait resolves with the action string of the clicked button.
    // rejectClose:false makes window-X cancellation resolve to `null` rather
    // than throw — same semantic as the old `resolve(false)` Cancel button.
    const choice = await foundry.applications.api.DialogV2.wait({
      window: { title: game.i18n.localize('Elysium.Ancestry.ReplaceTitle') },
      content,
      buttons: [
        { action: 'cancel',  label: game.i18n.localize('Cancel') },
        { action: 'confirm', label: game.i18n.localize('Elysium.Ancestry.Replace'), default: true },
      ],
      rejectClose: false,
    })
    return choice === 'confirm'
  }

  static async _chooseSubrace (item) {
    const subraces = item.system.elysium.ancestry.subraces
    const options = subraces.map(s => `<option value="${s.uuid}">${s.name}</option>`).join('\n')

    // The "apply" button needs to read the <select>'s value, so we use the
    // per-button callback form. That callback returns the chosen value, which
    // DialogV2.wait then resolves with. Cancel/close → null (rejectClose:false).
    const result = await foundry.applications.api.DialogV2.wait({
      window: { title: game.i18n.localize('Elysium.Ancestry.ChooseSubrace') },
      content: `
        <div class="elysium-dialog">
          <p>${game.i18n.localize('Elysium.Ancestry.ChooseSubraceHint')}</p>
          <select id="subrace-select">${options}</select>
        </div>
      `,
      buttons: [
        { action: 'cancel', label: game.i18n.localize('Cancel') },
        { action: 'apply',  label: game.i18n.localize('Apply'), default: true,
          callback: (event, button, dialog) => {
            const select = dialog.element.querySelector('#subrace-select')
            return select?.value || null
          }},
      ],
      rejectClose: false,
    })
    // result is the action string for 'cancel', or the callback's return for 'apply',
    // or null for window-close. Normalise: only 'apply' produces a uuid.
    if (typeof result === 'string' && result !== 'cancel') return result
    return null
  }

  static async _applyStatModifiers (actor, ancestryItem, statMods) {
    const effects = []
    for (const mod of statMods) {
      effects.push({
        name: `${ancestryItem.name}: ${mod.stat.toUpperCase()} ${mod.value >= 0 ? '+' : ''}${mod.value}`,
        icon: 'icons/svg/aura.svg',
        origin: ancestryItem.uuid,
        flags: {
          elysium: {
            ancestryMod: true,
            ancestryId:  ancestryItem.id,
            statMod:     true,
          }
        },
        changes: [{
          key:   `system.stats.${mod.stat.toLowerCase()}.culture`,
          mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
          value: String(mod.value),
        }],
        disabled: false,
        transfer: false,
      })
    }
    if (effects.length > 0) {
      await actor.createEmbeddedDocuments('ActiveEffect', effects)
    }
  }

  static async _adjustPointPools (actor, ancestry) {
    const flags = actor.flags?.['elysium'] || {}
    const buildPoints = flags.buildPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    const skillPoints = flags.skillPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }

    buildPoints.ancestry += (ancestry.buildPoints || 0)
    skillPoints.ancestry += (ancestry.skillPoints || 0)

    buildPoints.remaining = buildPoints.total + buildPoints.ancestry - buildPoints.spent
    skillPoints.remaining = skillPoints.total + skillPoints.ancestry - skillPoints.spent

    await actor.update({
      'system.elysium.buildPoints': buildPoints,
      'system.elysium.skillPoints': skillPoints,
    }, { render: false })
  }

  static async _createTraitMutations (actor, ancestryItem, traits) {
    const itemsToCreate = []
    for (const trait of traits) {
      try {
        const sourceItem = await fromUuid(trait.uuid)
        if (!sourceItem) {
          console.warn(`Elysium | Could not load mutation ${trait.uuid}`)
          continue
        }
        const data = sourceItem.toObject()
        data.flags['elysium'] ??= {}
        data.system.elysium.ancestryMod = true
        data.system.elysium.ancestryId = ancestryItem.id
        itemsToCreate.push(data)
      } catch (e) {
        console.warn(`Elysium | Error loading trait ${trait.uuid}: ${e.message}`)
      }
    }
    if (itemsToCreate.length > 0) {
      await actor.createEmbeddedDocuments('Item', itemsToCreate)
    }
  }

  static async _applyNaturalArmor (actor, ancestryItem, naturalArmor) {
    const data = {
      name: `${ancestryItem.name} (Natural Armor)`,
      type: 'armor',
      img:  ancestryItem.img || 'icons/svg/aura.svg',
      system: {
        av1: naturalArmor.ap || 0,
        enc: 0,
        equipStatus: 'equipped',
        coverage: naturalArmor.locations || 'all',
      },
      flags: {
        elysium: {
          flexibility:   'natural',
          layerOrder:    0,
          material:      'natural',
          ancestryMod:   true,
          ancestryId:    ancestryItem.id,
          apMax:         999,   // natural armor effectively unbreakable
        }
      }
    }
    await actor.createEmbeddedDocuments('Item', [data])
  }

  static async _applyNaturalWeapons (actor, ancestryItem, weapons) {
    const items = []
    for (const w of weapons) {
      try {
        const source = await fromUuid(w.uuid || w)
        if (!source) continue
        const data = source.toObject()
        data.flags['elysium'] ??= {}
        data.system.elysium.ancestryMod = true
        data.system.elysium.ancestryId  = ancestryItem.id
        items.push(data)
      } catch (e) {
        console.warn(`Elysium | natural weapon load fail: ${e.message}`)
      }
    }
    if (items.length > 0) await actor.createEmbeddedDocuments('Item', items)
  }

  static async _applyResistances (actor, ancestryItem, resistances) {
    const effects = []
    for (const dmgType in resistances) {
      const tier = resistances[dmgType]
      effects.push({
        name: `${ancestryItem.name}: ${dmgType} ${tier}`,
        icon: 'icons/svg/aura.svg',
        origin: ancestryItem.uuid,
        flags: {
          elysium: {
            ancestryMod: true,
            ancestryId:  ancestryItem.id,
            resistance:  { damageType: dmgType, tier },
          }
        },
        changes: [],   // logical only — read by damage resolver
        disabled: false,
        transfer: false,
      })
    }
    if (effects.length > 0) {
      await actor.createEmbeddedDocuments('ActiveEffect', effects)
    }
  }

  static async _applyLanguages (actor, languages) {
    const current = actor.flags?.['elysium']?.languages || []
    const merged = Array.from(new Set([...current, ...languages]))
    await actor.update({
      'system.elysium.languages': merged
    }, { render: false })
  }

  static async _adjustStatMaxima (actor, statMods) {
    if (!statMods?.length) return
    // v1.0.0-alpha.11 (side-finding #1): read from system.elysium.*,
    // matching the writer below and the CharacterDataModel TypedObjectField
    // declaration. Previously the read was flags.elysium.* — silent
    // empty-read on every call.
    const maxima = actor.system?.elysium?.statNaturalMax || {}
    for (const mod of statMods) {
      const stat = mod.stat.toLowerCase()
      const baseMax = ELYSIUM.STAT_NATURAL_MAX_BASE
      maxima[stat] = baseMax + mod.value
    }
    await actor.update({
      'system.elysium.statNaturalMax': maxima
    }, { render: false })
  }

  static async _applyAncestryMove (actor, ancestry) {
    if (typeof ancestry.baseMove === 'number') {
      await actor.update({
        'system.move': ancestry.baseMove,
        'system.elysium.ancestryMove': {
          baseMove: ancestry.baseMove,
          flyMove:  ancestry.flyMove || 0,
          swimMove: ancestry.swimMove || 0,
        }
      }, { render: false })
    }
  }

  /**
   * Apply a hit-location body-shape set to an actor by name (e.g. 'humanoid',
   * 'quadruped', 'centaur'). Looks up the spec in ELYSIUM.HIT_LOCATION_SETS,
   * sources the underlying records from the elysium-compendium.hit-locations
   * pack, overrides each record's roll range (and optional displayName) per
   * the spec, then creates the resulting hit-location items on the actor.
   *
   * Removes any existing hit locations on the actor first to avoid mixing
   * creature-type sets — applying a new set is a deliberate replacement.
   *
   * Returns the number of locations applied (0 on failure).
   *
   * Public API: also exposed as game.system.api.elysium.ancestryDrop
   * .applyHitLocationSet(actor, shape) for use by macros and other modules.
   */
  static async applyHitLocationSet (actor, shape) {
    return this._applyHitLocationSet(actor, shape)
  }

  static async _applyHitLocationSet (actor, shape) {
    if (!actor) return 0
    const partSpecs = ELYSIUM.HIT_LOCATION_SETS?.[shape]
    if (!Array.isArray(partSpecs) || partSpecs.length === 0) {
      console.warn(`Elysium | Unknown hit-location set "${shape}" — skipping auto-apply.`)
      return 0
    }

    const pack = game.packs.get('elysium-compendium.hit-locations')
    if (!pack) {
      // Compendium module not present (e.g. running system without compendium).
      // Silently skip rather than warning — this is a valid configuration.
      return 0
    }

    // Wipe any existing hit locations to avoid mixing creature-type sets.
    const existing = actor.items.filter(i => i.type === 'hit-location').map(i => i.id)
    if (existing.length > 0) {
      await actor.deleteEmbeddedDocuments('Item', existing)
    }

    // Load all hit-location docs once, then assemble the requested set.
    const allDocs = await pack.getDocuments()
    const docsByName = new Map()
    for (const d of allDocs) {
      if (d.type === 'hit-location') docsByName.set(d.name, d)
    }

    const itemsData = []
    const missing = []
    for (const spec of partSpecs) {
      const doc = docsByName.get(spec.name)
      if (!doc) { missing.push(spec.name); continue }
      const data = doc.toObject()
      delete data._id
      data.system.lowRoll  = spec.low
      data.system.highRoll = spec.high
      if (spec.displayName) data.system.displayName = spec.displayName
      itemsData.push(data)
    }

    if (missing.length > 0) {
      ui.notifications.warn(
        `Hit-location set "${shape}" is missing parts in the compendium: ${missing.join(', ')}`
      )
    }
    if (itemsData.length === 0) return 0

    await actor.createEmbeddedDocuments('Item', itemsData)
    return itemsData.length
  }

  static async _cleanupAncestry (actor, ancestryId) {
    // Remove items with this ancestry mod flag
    const itemsToDelete = actor.items
      .filter(i => i.flags?.['elysium']?.ancestryId === ancestryId)
      .map(i => i.id)
    if (itemsToDelete.length > 0) {
      await actor.deleteEmbeddedDocuments('Item', itemsToDelete)
    }

    // Remove AEs with this ancestry mod flag
    const effectsToDelete = actor.effects
      .filter(e => e.flags?.['elysium']?.ancestryId === ancestryId)
      .map(e => e.id)
    if (effectsToDelete.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', effectsToDelete)
    }

    // Reset point pool ancestry adjustments
    const flags = actor.flags?.['elysium'] || {}
    const buildPoints = flags.buildPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    const skillPoints = flags.skillPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    buildPoints.ancestry = 0
    skillPoints.ancestry = 0
    buildPoints.remaining = buildPoints.total - buildPoints.spent
    skillPoints.remaining = skillPoints.total - skillPoints.spent

    await actor.update({
      'system.elysium.buildPoints': buildPoints,
      'system.elysium.skillPoints': skillPoints,
      'system.elysium.ancestryId': '',
      'system.elysium.statNaturalMax': {},
    }, { render: false })
  }
}
