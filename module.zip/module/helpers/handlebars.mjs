/**
 * Elysium Handlebars helpers
 */

import { ELYSIUM } from '../config/config.mjs'

export function registerHandlebarsHelpers () {
  // Format a fatigue level as its localised label
  Handlebars.registerHelper('elysiumFatigueLabel', (level) => {
    const data = ELYSIUM.FATIGUE_LEVELS[level || 0]
    if (!data) return ''
    return game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`)
  })

  // Render a row of pip elements (filled + empty)
  Handlebars.registerHelper('elysiumPips', (current, max) => {
    let result = ''
    for (let i = 0; i < (max || 0); i++) {
      result += `<span class="elysium-pip ${i < (current || 0) ? 'filled' : 'empty'}"></span>`
    }
    return new Handlebars.SafeString(result)
  })

  // Format a percentage with sign
  Handlebars.registerHelper('elysiumSigned', (value) => {
    const v = Number(value || 0)
    return (v >= 0 ? '+' : '') + v
  })

  // Get growth tier label
  Handlebars.registerHelper('elysiumEssenceTier', (skillPct) => {
    const pct = Number(skillPct || 0)
    if (pct >= 100) return 'Transcendent'
    if (pct >= 76)  return 'Potent'
    if (pct >= 51)  return 'Established'
    if (pct >= 26)  return 'Developing'
    return 'Nascent'
  })

  // Conditional difficulty grade name
  Handlebars.registerHelper('elysiumDifficulty', (modifier) => {
    const m = Number(modifier || 0)
    if (m >= 40) return 'Very Easy'
    if (m >= 20) return 'Easy'
    if (m === 0) return 'Standard'
    if (m >= -20) return 'Difficult'
    if (m >= -40) return 'Very Difficult'
    return 'Extremely Difficult'
  })

  // Concat with separator (used in templates)
  Handlebars.registerHelper('elysiumJoin', (...args) => {
    args.pop()    // Remove options object
    return args.filter(a => a !== null && a !== undefined && a !== '').join(', ')
  })
}
