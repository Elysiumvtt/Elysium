/**
 * Elysium Visual Regression Harness — Capture
 * --------------------------------------------------------------------------
 * Captures structured snapshots of rendered Foundry UI for visual regression
 * testing. Run in the Foundry browser context (macro, console, or test runner).
 *
 * Snapshot format: see docs/snapshot-format.md (also: top of this file).
 *
 * Usage:
 *
 *   // In Foundry console or a macro:
 *   import { captureSheet, captureAll, downloadSnapshot } from
 *     '/systems/elysium/test/visual-regression/capture.mjs'
 *
 *   const snap = await captureSheet(someActor.sheet)
 *   downloadSnapshot(snap, 'baseline-character-empty')
 *
 *   // Or capture a known canonical state:
 *   const snaps = await captureAll()
 *
 * The diff tool (./diff.mjs) compares captured snapshots against baseline
 * snapshots committed in ./baseline/. See ./README.md for the full workflow.
 * --------------------------------------------------------------------------
 */


/* ============================================================================
 * Marker definitions
 * ----------------------------------------------------------------------------
 * Each marker is a {selector, label, props} triple. `props` is the list of
 * computed-style properties we care about for that selector. `label` is a
 * human-readable name used in diff output.
 *
 * To add a new marker: pick a selector that uniquely (or repeatably)
 * identifies the element on a known sheet state. Pick the smallest set of
 * properties whose change would constitute a visual regression worth knowing
 * about. Be deliberate — captured properties are the diff's signal/noise
 * ratio.
 * ============================================================================ */

const VISUAL_PROPS = ['color', 'background-color', 'border-color', 'border-width', 'border-style', 'font-family', 'font-size', 'font-weight']
const LAYOUT_PROPS = ['display', 'grid-template-columns', 'flex-direction', 'padding', 'margin', 'gap']

/**
 * Markers for the character actor sheet. Each entry captures one visually
 * load-bearing element. Selectors are written to be stable across the rebuild
 * (semantic when possible) but some will need updating as templates evolve.
 */
const CHARACTER_SHEET_MARKERS = [
  // Identity / outer chrome
  { selector: '.application.elysium', label: 'sheet-root', props: ['background-color', 'background-image', 'color'] },
  { selector: '.sheet-title, .elysium-sheet-title', label: 'sheet-title', props: VISUAL_PROPS },

  // Card-level structural elements
  { selector: '.resource-label, .elysium-card-title', label: 'resource-label', props: VISUAL_PROPS },

  // Tab strip
  { selector: '.elysiumTab, .elysium-tab', label: 'tab-inactive', props: VISUAL_PROPS },
  { selector: '.active .elysiumTab, .active .elysium-tab', label: 'tab-active', props: VISUAL_PROPS },

  // Stat / characteristic
  { selector: '.char-stat-grid, .characteristic-grid, .elysium-stat-grid', label: 'stat-grid', props: LAYOUT_PROPS },

  // Tertiary content
  { selector: '.diff-label', label: 'diff-label', props: VISUAL_PROPS },
  { selector: '.darkred', label: 'darkred-emphasis', props: VISUAL_PROPS },

  // Hit points bar (heavy visual element worth tracking)
  { selector: '.hp-bar, .health-bar, .elysium-hp-bar', label: 'hp-bar', props: VISUAL_PROPS },

  // Logo / brand
  { selector: '.logo-img', label: 'logo-img', props: ['width', 'height'] },
]

const ITEM_SHEET_MARKERS = [
  { selector: '.application.elysium.item', label: 'item-root', props: VISUAL_PROPS },
  { selector: '.application.elysium.item .sheet-title', label: 'item-title', props: VISUAL_PROPS },
  { selector: '.application.elysium.item input', label: 'item-input', props: VISUAL_PROPS },
  { selector: '.application.elysium.item .diff-label', label: 'item-diff-label', props: VISUAL_PROPS },
]

/**
 * Markers for the NPC actor sheet. v1.0.0-alpha.11 (side-finding #4) — the
 * NPC sheet uses templates/actor/npcV2.*.hbs which have distinct classes
 * from the character sheet (`npc-main-sheet`, `npc-stats-grid`,
 * `npc-name-grid`, `charname`, etc). The character markers don't match
 * those, so prior to this fix the NPC capture was character-marker-only
 * and matched 1/10 markers. With this NPC-specific list, NPC captures
 * have their own marker palette.
 */
const NPC_SHEET_MARKERS = [
  // Outer chrome — root and the NPC-specific class
  { selector: '.application.elysium', label: 'sheet-root', props: ['background-color', 'background-image', 'color'] },
  { selector: '.application.elysium.npcv2', label: 'npc-root', props: VISUAL_PROPS },

  // Header block
  { selector: '.npc-header-sheet', label: 'npc-header', props: VISUAL_PROPS },
  { selector: '.npc-name-grid', label: 'npc-name-grid', props: LAYOUT_PROPS },

  // Main content
  { selector: '.npc-main-sheet', label: 'npc-main', props: VISUAL_PROPS },
  { selector: '.npc-stats-grid', label: 'npc-stats-grid', props: LAYOUT_PROPS },
  { selector: '.npc-points-grid', label: 'npc-points-grid', props: LAYOUT_PROPS },

  // Tertiary content
  { selector: '.charname', label: 'npc-charname-label', props: VISUAL_PROPS },
  { selector: '.npc-inp', label: 'npc-name-input', props: VISUAL_PROPS },
  { selector: '.npcpersonal-inp', label: 'npc-stat-input', props: VISUAL_PROPS },
]

const CHAT_CARD_MARKERS = [
  { selector: '.chat-message', label: 'chat-message-root', props: VISUAL_PROPS },
  { selector: '.chat-message .elysium-combat-card-buttons', label: 'combat-card-buttons', props: VISUAL_PROPS },
  { selector: '.chat-message .elysium-hitloc-tag', label: 'hitloc-tag', props: VISUAL_PROPS },
  { selector: '.chat-message button', label: 'chat-button', props: VISUAL_PROPS },
]

const DIALOG_MARKERS = [
  { selector: '.dialog .window-content, .application.dialog', label: 'dialog-root', props: VISUAL_PROPS },
  { selector: '.dialog .diff-label, .dialog .elysium-dialog-label', label: 'dialog-label', props: VISUAL_PROPS },
  { selector: '.dialog button[data-action]', label: 'dialog-button', props: VISUAL_PROPS },
]


/* ============================================================================
 * Token reference capture
 * ----------------------------------------------------------------------------
 * Captures the CSS custom property values for the v1.0.0 design tokens.
 * Detects token drift independently of which DOM elements consume them.
 * ============================================================================ */

const ELYSIUM_TOKEN_NAMES = [
  // Text
  '--ely-text-body', '--ely-text-body-strong', '--ely-text-decorative', '--ely-text-muted',
  '--ely-text-disabled', '--ely-text-link', '--ely-text-inverse', '--ely-text-on-bonus',
  // Surface
  '--ely-surface-base', '--ely-surface-card', '--ely-surface-raised', '--ely-surface-sunken',
  '--ely-surface-highlight', '--ely-surface-overlay',
  // Accent
  '--ely-accent-action', '--ely-accent-bonus', '--ely-accent-danger', '--ely-accent-success', '--ely-accent-info',
  // Border
  '--ely-border-subtle', '--ely-border-decorative', '--ely-border-focus', '--ely-border-strong',
  // Spacing (sample)
  '--ely-space-2', '--ely-space-3', '--ely-space-4',
  // Radius (sample)
  '--ely-radius-2', '--ely-radius-3',
  // Typography (sample)
  '--ely-font-family-display', '--ely-font-family-body',
  '--ely-font-size-3', '--ely-font-size-5', '--ely-font-size-7',
]

const LEGACY_BRP_TOKEN_NAMES = [
  // Track these too so we can see when the legacy palette diverges
  '--ely-legacy-background', '--ely-legacy-border-color', '--ely-legacy-colour-primary', '--ely-legacy-colour-secondary',
  '--ely-legacy-title-colour', '--ely-legacy-icon-primary',
]


/* ============================================================================
 * Capture functions
 * ============================================================================ */

/**
 * Capture computed style values for one marker definition. Returns an object
 * with the matched element's tag, class list, and the chosen properties.
 *
 * If multiple elements match the selector, returns the first one only —
 * intentionally — to keep snapshots stable. If you need to capture multiple
 * instances, define separate markers with more specific selectors.
 *
 * If no element matches, returns null (which the diff tool treats as "this
 * element was not present in this state"). Distinguishing "absent" from
 * "differently styled" is important.
 *
 * @param {object} marker {selector, label, props}
 * @param {Document|Element} [scope] - root to search from; defaults to document
 * @returns {object|null}
 */
export function captureMarker (marker, scope = document) {
  // Check scope itself first (covers the "marker IS the sheet root" case),
  // then fall back to descendant search. Element.matches() is the API for
  // self-match testing — Document doesn't have it, so we feature-check.
  let el = null
  if (typeof scope.matches === 'function' && scope.matches(marker.selector)) {
    el = scope
  } else {
    el = scope.querySelector(marker.selector)
  }
  if (!el) return null

  const cs = window.getComputedStyle(el)
  const result = {
    label: marker.label,
    selector: marker.selector,
    tag: el.tagName.toLowerCase(),
    classes: [...el.classList].sort(),
  }

  for (const prop of marker.props) {
    result[prop] = cs.getPropertyValue(prop).trim()
  }

  return result
}

/**
 * Capture every marker in a list against a scope. Returns an array of
 * marker results (with nulls preserved for absent markers).
 */
export function captureMarkers (markers, scope = document) {
  return markers.map(m => captureMarker(m, scope))
}

/**
 * Capture the current values of all tracked design tokens. Returns a flat
 * {tokenName: value} map. Tokens not defined return empty strings; the
 * diff tool handles that case.
 *
 * @param {Element} [scope] - the element to query tokens from; defaults to document.documentElement
 * @returns {Object}
 */
export function captureTokens (scope = document.documentElement) {
  const cs = window.getComputedStyle(scope)
  const result = {}
  for (const name of [...ELYSIUM_TOKEN_NAMES, ...LEGACY_BRP_TOKEN_NAMES]) {
    result[name] = cs.getPropertyValue(name).trim()
  }
  return result
}

/**
 * Capture a single open sheet. The sheet's element identity is used as the
 * scope so multiple sheets in the same DOM don't bleed into each other.
 *
 * @param {Application} sheet - a Foundry sheet Application instance
 * @returns {object} snapshot
 */
export async function captureSheet (sheet) {
  if (!sheet?.element) {
    throw new Error('captureSheet: sheet has no .element — is it rendered?')
  }
  const scope = sheet.element

  // Pick marker set based on sheet type.
  // v1.0.0-alpha.11 (side-finding #4): NPC actors now dispatch to
  // NPC_SHEET_MARKERS instead of CHARACTER_SHEET_MARKERS (which targets
  // a different template tree).
  let markers
  const docType = sheet.document?.documentName
  const subtype = sheet.document?.type
  if (docType === 'Actor') {
    markers = subtype === 'npc' ? NPC_SHEET_MARKERS : CHARACTER_SHEET_MARKERS
  } else if (docType === 'Item') {
    markers = ITEM_SHEET_MARKERS
  } else {
    markers = []  // unknown — caller can still get the bare snapshot
  }

  return {
    schemaVersion: 1,
    capturedAt: new Date().toISOString(),
    target: {
      kind: 'sheet',
      docType,
      subtype,
      name: sheet.document?.name,
      docId: sheet.document?.id,
    },
    foundry: {
      version: game?.release?.generation ?? null,
      systemVersion: game?.system?.version ?? null,
      systemId: game?.system?.id ?? null,
      theme: document.body.classList.contains('theme-dark') ? 'dark' : 'light',
    },
    tokens: captureTokens(),
    markers: captureMarkers(markers, scope),
    outerHTML: scope.outerHTML,
  }
}

/**
 * Capture chat log state. Snapshots all visible chat messages with their
 * combat-card-button presence (the Phase D output surface from v0.22.0).
 */
export function captureChatLog () {
  const log = document.querySelector('#chat-log, .chat-log, [data-tab="chat"] .chat-log')
  if (!log) return null

  return {
    schemaVersion: 1,
    capturedAt: new Date().toISOString(),
    target: { kind: 'chat-log' },
    foundry: {
      version: game?.release?.generation ?? null,
      systemVersion: game?.system?.version ?? null,
      systemId: game?.system?.id ?? null,
      theme: document.body.classList.contains('theme-dark') ? 'dark' : 'light',
    },
    tokens: captureTokens(),
    messageCount: log.querySelectorAll('.chat-message').length,
    markers: captureMarkers(CHAT_CARD_MARKERS, log),
  }
}

/**
 * Capture a dialog window if one is currently open. Returns null if no dialog.
 */
export function captureOpenDialog () {
  const dialog = document.querySelector('.application.dialog, .dialog.app')
  if (!dialog) return null
  return {
    schemaVersion: 1,
    capturedAt: new Date().toISOString(),
    target: { kind: 'dialog', windowTitle: dialog.querySelector('.window-title, header')?.textContent?.trim() },
    foundry: {
      version: game?.release?.generation ?? null,
      systemVersion: game?.system?.version ?? null,
      systemId: game?.system?.id ?? null,
      theme: document.body.classList.contains('theme-dark') ? 'dark' : 'light',
    },
    tokens: captureTokens(),
    markers: captureMarkers(DIALOG_MARKERS, dialog),
  }
}

/**
 * Convenience: dump a snapshot to the user as a downloaded JSON file. Stable
 * filenames make committing baselines straightforward.
 *
 * @param {object} snapshot - from any capture* function
 * @param {string} [name] - optional override filename (no extension)
 */
export function downloadSnapshot (snapshot, name) {
  const target = snapshot.target
  const stem = name ?? [
    target?.kind ?? 'unknown',
    target?.docType ?? null,
    target?.subtype ?? null,
    target?.name?.replace(/[^a-zA-Z0-9_-]+/g, '_') ?? null,
  ].filter(Boolean).join('-')

  const json = JSON.stringify(snapshot, null, 2)
  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)

  const a = document.createElement('a')
  a.href = url
  a.download = `${stem}.snapshot.json`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

/**
 * Capture every currently-open sheet plus the chat log. Returns a map.
 *
 * Useful for "snapshot the world right now" workflows.
 */
export async function captureAll () {
  const result = {}
  // All open sheet applications
  const apps = Object.values(ui.windows ?? {})
  for (const app of apps) {
    if (app?.document?.documentName === 'Actor' || app?.document?.documentName === 'Item') {
      const snap = await captureSheet(app)
      const key = `${snap.target.docType}-${snap.target.subtype}-${snap.target.docId}`
      result[key] = snap
    }
  }
  // Chat log
  const chat = captureChatLog()
  if (chat) result['chat-log'] = chat
  // Open dialog if any
  const dlg = captureOpenDialog()
  if (dlg) result['open-dialog'] = dlg

  return result
}


/* ============================================================================
 * Token-only capture (no sheet open required)
 * ----------------------------------------------------------------------------
 * The cheapest possible regression check — just confirms the design tokens
 * haven't drifted. Catches the case "session 5 accidentally changed
 * --ely-text-decorative".
 * ============================================================================ */

export function captureTokenSnapshot () {
  return {
    schemaVersion: 1,
    capturedAt: new Date().toISOString(),
    target: { kind: 'tokens-only' },
    foundry: {
      version: game?.release?.generation ?? null,
      systemVersion: game?.system?.version ?? null,
      systemId: game?.system?.id ?? null,
      theme: document.body.classList.contains('theme-dark') ? 'dark' : 'light',
    },
    tokens: captureTokens(),
  }
}
