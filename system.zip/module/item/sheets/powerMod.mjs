import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumPowerModSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['powerMod'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template: 'systems/elysium/templates/item/powerMod.detail.hbs',
      scrollable: ['']
    },
  }

  static TAB_ORDER = null

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Header chips per c2-2 lock — CPC mod chip always.
    const cpcRaw = this.item.system.cpcMod ?? 0;
    context.itemHeaderChips = [{
      label: game.i18n.localize('Elysium.cpcMod'),
      value: String(cpcRaw),
      tooltip: game.i18n.localize('Elysium.cpcModHint'),
    }];

    return context
  }

  _onRender(context, _options) {
  }
}
