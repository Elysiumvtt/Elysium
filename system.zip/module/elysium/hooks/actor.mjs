// Auto-extracted from module/elysium/hooks/register-hooks.mjs by tools/extract-functions.mjs
// (v0.21.0 register-hooks refactor).
//
// Top-level Foundry hook handlers extracted from the central registerHooks
// dispatcher. Each function is exported by name; the dispatcher imports them
// and wires them via Hooks.on(eventName, handler).



import { ElysiumActorExtension } from '../actor/actor-extension.mjs'

export async function _onCreateActor (actor, options, userId) {
  if (game.userId !== userId) return

  // Trigger derived stat calculation if stats have meaningful values
  // (skip on fresh blank actors — wait until user enters stats)
  const stats = actor.system?.stats
  const hasStats = stats && Object.values(stats).some(s =>
    (s?.base || 0) > 0 || (s?.redist || 0) > 0
  )
  if (hasStats) {
    await ElysiumActorExtension.calculateDerivedStats(actor)
  }
}

export async function _onUpdateActor (actor, change, options, userId) {

  // Recalculate derived stats if relevant fields changed
  if (_relevantFieldChanged(change)) {
    await ElysiumActorExtension.calculateDerivedStats(actor)
    // Re-render any open sheets so the new derived values appear immediately
    // without requiring the user to close and reopen the sheet.
    if (actor.sheet?.rendered) actor.sheet.render(false)
  }
}

export async function _onPreUpdateActor (actor, change, options, userId) {
  // Snapshot pre-update health so critical-tier transitions can be detected
  // after the update completes (compared against actor.system.health.value
  // in _onUpdateActor downstream).
  if (change.system?.health !== undefined) {
    options.elysiumPrevHealth = foundry.utils.deepClone(actor.system.health)
  }
}

export function _relevantFieldChanged (change) {
  if (!change.system) return false
  return change.system.stats !== undefined ||
         change.system.health !== undefined ||
         change.system.power !== undefined ||
         change.system.fatigue !== undefined
}
