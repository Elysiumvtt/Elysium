/**
 * Divine cast-time tier choice dialog (v0.18.0).
 *
 * Opens at the start of a divine cast. Player sees the tiers they can
 * cast at (gated by Channeling/Faith), with AP cost and effect preview
 * per tier. Player picks one; dialog returns { tier }.
 *
 * Per the v0.18.0 locked design (DESIGN-divine-v0.18.0.md):
 * - Cleric MUST have BOTH Channeling and Faith at the tier band to cast at it
 * - Player can choose to under-cast at a lower tier (e.g., Saint cleric
 *   casting Cure Wounds at T1 for a quick small heal)
 * - AP cost varies by tier (apCostByTier per spell)
 * - Effect description varies by tier (effectByTier per spell)
 */

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api

/**
 * Divine tier band labels (Channeling+Faith). 1/50/70/85/95.
 */
const DIVINE_TIER_LABELS = {
  1: 'Untested (1+)',
  2: 'Devotee (50+)',
  3: 'Anointed (70+)',
  4: 'Chosen (85+)',
  5: 'Saint (95+)',
}

/**
 * Sorcery tier band labels (essence skill). Same thresholds.
 */
const SORCERY_TIER_LABELS = {
  1: 'Nascent (1+)',
  2: 'Developing (50+)',
  3: 'Established (70+)',
  4: 'Potent (85+)',
  5: 'Transcendent (95+)',
}

export class TierChoiceDialog extends HandlebarsApplicationMixin(ApplicationV2) {

  constructor (options = {}) {
    super(options)
    this._actor = options.actor
    this._spell = options.spell
    this._availableTiers = options.availableTiers ?? [1]
    this._apCostByTier = options.apCostByTier ?? [1, 1, 2, 2, 3]
    this._effectByTier = options.effectByTier ?? {}
    this._channelTotal = options.channelTotal ?? 0
    this._faithTotal = options.faithTotal ?? 0

    this._resolve = null
    this._promise = new Promise(res => { this._resolve = res })
    this._resolved = false
    this._chosenTier = null
  }

  static DEFAULT_OPTIONS = {
    id: 'elysium-tier-choice-dialog',
    classes: ['elysium', 'tier-choice-dialog'],
    tag: 'div',
    window: {
      title: 'Choose Cast Tier',
      icon: 'fas fa-sun',
      resizable: true,
    },
    position: { width: 540, height: 'auto' },
    actions: {
      pickTier: TierChoiceDialog._onPickTier,
      cast:     TierChoiceDialog._onCast,
      cancel:   TierChoiceDialog._onCancel,
    },
  }

  static PARTS = {
    body: { template: 'systems/elysium/templates/casting/tier-choice-dialog.hbs' },
  }

  static async open (options) {
    const dialog = new TierChoiceDialog(options)
    dialog.render(true)
    return dialog._promise
  }

  async _prepareContext () {
    // v0.19.0: detect sorcery vs divine via the sentinel faithTotal: -1.
    // Sorcery passes only one skill (the essence skill) in the channelTotal
    // slot. Tier labels and the header layout differ per tradition.
    const isSorcery = this._faithTotal === -1
    const tradition = isSorcery ? 'sorcery' : 'divine'
    const labels = isSorcery ? SORCERY_TIER_LABELS : DIVINE_TIER_LABELS

    const tierOptions = this._availableTiers.map(tier => {
      const apCost = Number(this._apCostByTier[tier - 1]) || 1
      const effect = this._effectByTier[String(tier)] ?? this._effectByTier[tier] ?? '(no effect description)'
      return {
        tier,
        label: labels[tier] ?? `Tier ${tier}`,
        apCost,
        effect,
        selected: tier === this._chosenTier,
      }
    })

    return {
      spell: this._spell,
      spellName: this._spell?.name ?? '(unknown)',
      domain: this._spell?.system?.elysium?.domain ?? '',
      channelTotal: this._channelTotal,
      faithTotal: this._faithTotal,
      tierOptions,
      hasChosen: this._chosenTier !== null,
      isSorcery,
      tradition,
    }
  }

  static _onPickTier (event, target) {
    const tier = Number(target?.dataset?.tier)
    if (!Number.isFinite(tier) || tier < 1 || tier > 5) return
    this._chosenTier = tier
    this.render()
  }

  static _onCast () {
    if (this._resolved) return
    if (this._chosenTier === null) {
      ui.notifications?.warn('Pick a tier first.')
      return
    }
    this._resolved = true
    this._resolve({ tier: this._chosenTier })
    this.close()
  }

  static _onCancel () {
    if (this._resolved) return
    this._resolved = true
    this._resolve(null)
    this.close()
  }
}
