# P11 Cluster 5 prep audit — generic dialogs (10 templates in templates/dialog/)

**Status**: PENDING
**Target alpha**: alpha.49
**Scope**: 10 dialog templates — `selectPower`, `getValue`, `hitLocChoice`, `npcTokenCreate`, `selectItem`, `skillSelect`, `newWound`, `treatWound`, `damageDiff`, `difficulty`. Total 226 LOC.
**Inheritance from**: P11 prep audit (especially c11-12 "dialog markup is its own subscope"), cluster 1 audit (`.elysium-dialog` marker rule reservation in `styles/elysium-chat.css:46-83`), and the 7 chat partials shipped in clusters 1+2+4.

After alpha.49, **all generic dialog templates** are on v1.0.0. P11 ships closer to completion; remaining optional work is clusters 6 (island harmonisation) and 7 (combat-tracker cosmetic restyle).

---

## 1. Current-state inventory

### Template sizes and archetypes

| Template | LOC | Archetype |
|---|---|---|
| `selectPower.hbs` | 9 | label + select dropdown |
| `getValue.hbs` | 10 | label + numeric input |
| `hitLocChoice.hbs` | 10 | label + select with header |
| `npcTokenCreate.hbs` | 10 | conditional select wrapped in askStats |
| `selectItem.hbs` | 12 | radio-list iteration |
| `skillSelect.hbs` | 16 | click-to-toggle iteration with live counter |
| `newWound.hbs` | 19 | 2 conditional input/select sections |
| `treatWound.hbs` | 31 | 3 conditional input/select sections |
| `damageDiff.hbs` | 37 | 4 conditional select/input rows |
| `difficulty.hbs` | 72 | complex conditional form (addStat/difficulty/resistance/flatMod/range/hands/firstAid branches) |
| **Total** | **226** | — |

### Three structural archetypes

Across the 10 dialogs there are exactly three repeating shapes:

1. **Label + select dropdown** — 5 of 10 dialogs use this pattern (selectPower, hitLocChoice, npcTokenCreate, and as sub-rows in damageDiff/difficulty). Pattern:
   ```hbs
   <div class="flexrow">
     <label class="resource-label-diff">{{localize 'Elysium.X'}}</label>
     <select data-handle-change name="..."><br>
       {{selectOptions optsList selected=currentVal}}
     </select>
   </div>
   ```

2. **Label + numeric/text input** — 4 of 10 dialogs use this. Pattern:
   ```hbs
   <div class="flexcol">
     <div class="stat-name darkred centre">{{localize 'Elysium.X'}}</div>
     <div class="flexrow">
       <input class="stat-name centre" name="..." type="number"/>
     </div>
   </div>
   ```

3. **Iterated list** — 2 dialogs: `selectItem` (radio buttons in a single column) and `skillSelect` (clickable square icons in a 2-column grid with live point counter).

### Per-template specifics

**`selectPower.hbs`** — simplest, 9 LOC. Single label + single select. `<form>` wrapper.

**`getValue.hbs`** — 10 LOC. Single numeric input with prompt. `<br>` tags for spacing (legacy formatting).

**`hitLocChoice.hbs`** — 10 LOC. Header `<div class="diff-label">{{label}}</div>` + label + select.

**`npcTokenCreate.hbs`** — 10 LOC. `<section>` not `<form>` (only consumer is `create-token.mjs` which renders inline into a Dialog body, not as a standalone form). Conditional on `askStats`.

**`selectItem.hbs`** — 12 LOC. Title (`stat-name`) + radio list. Uses `{{#each newList as |type id|}}` iteration. Each row has `<label><input type="radio">{{type}}</label>`. First option auto-checked via `{{#if (eq @index 0)}}checked{{/if}}`.

**`skillSelect.hbs`** — 16 LOC. The most complex iteration: live point counter ("0 / N") at top, then iterated list of clickable squares. **Critical class-hook surface for audit-5 lock**:
- `.select.rollable` — bound to click handler at `module/apps/skill-selection.mjs:6`
- `.mediumIcon` — ancestor-closest from the click target
- `data-set="{{key}}"` — read via `chosen.dataset.set`
- `.skill-select` — `event.currentTarget.closest('.skill-select')` (the section wrapper)
- `.count` — `form.querySelector('.count')` (the live counter span)
- `.item-{{key}}` — `form.querySelector('.item-' + choice)` (target for toggle innerHTML swap)
- **All 6 must be preserved verbatim.**

**`newWound.hbs`** — 19 LOC. 2 conditional sections (`getDam`, `getLoc`) each with the "label + input/select" pattern.

**`treatWound.hbs`** — 31 LOC. 3 conditional sections (always-prompt + `getType`, `getWnd`) all the "label + input/select" pattern.

**`damageDiff.hbs`** — 37 LOC. Header + 4 conditional select/input rows (`askSuccess`, `askRange`, `askHands`, `askLevel`).

**`difficulty.hbs`** — 72 LOC. By far the most complex:
- Header `<div class="diff-label">{{label}}</div>`
- Conditional `addStat` select (for RE cards only)
- Conditional difficulty branch: `useDiffValue` toggles between a number input and a select dropdown
- `isOr` block helper for RE/PP showing a resistance input (with different label per cardType)
- Always-shown flatMod input
- 3 more conditional select rows (`askRange`, `askHands`, `firstAid`)

### Legacy class-hook inventory and retirement plan

| Class | CSS rule? | Consumers | Cluster-5 disposition |
|---|---|---|---|
| `flexcol`, `flexrow` | yes (`elysium-tokens` / `elysium.css`) | system-wide (~all sheets, all dialogs) | **KEEP** — generic layout utility, retokening is P12 scope |
| `stat-name` | yes (`legacy.css:299`) | 7 files inc. character.statistics.hbs, character.mjs, npc.mjs | **KEEP** — non-dialog consumers; layer v1.0.0 classes alongside |
| `centre` | yes (`legacy.css:399`) | system-wide | **KEEP** — generic |
| `darkred` | yes (`legacy.css:1384`) — already uses `var(--ely-legacy-colour-secondary)` | 3 dialogs + elysiumid-editor | **KEEP** — retoken to `var(--ely-text-danger)` candidate for P12 (cluster 5 preserves) |
| `resource-label-diff` | NO RULE | dialogs only | **drop from markup** — pure semantic-marker class; no CSS to retire |
| `diff-label` | yes (`legacy.css`) | 3 dialogs + 4 non-dialog templates | **KEEP** — cross-template consumer |
| `diff-number-input` | NO RULE | 1 dialog (difficulty.hbs) | **drop from markup** — pure semantic-marker class; no CSS to retire |
| `radioList`, `item-view` | NO RULE | selectItem only | **drop from markup** — no CSS to retire |
| `selectList` | yes (`legacy.css:1416`) | skillSelect only | **RETIRE CSS RULE + drop from markup** — sole consumer being rebuilt |
| `new-row`, `mediumIcon`, `bold`, `charname`, `count`, `skill-opt-label`, `item-{{key}}` | mixed | skillSelect-only (some) | **mostly preserve** — `.mediumIcon`, `.count`, `.item-{{key}}` are audit-5-locked JS hooks; `bold`, `charname`, `skill-opt-label` can stay or drop case-by-case |
| `font14` | yes (`legacy.css:501`) | selectItem + non-dialog actor-sheet consumers | **KEEP** — cluster 4 already retired the chat-card usage but actor-sheet uses remain |

**Eligible for retirement in cluster 5**:
- `selectList` rule from `css/legacy.css` (5 lines including the 3-property grid + braces) — sole consumer (skillSelect.hbs) is being rebuilt
- Pure semantic-marker class drops from markup (resource-label-diff, diff-number-input, radioList, item-view) — no CSS to retire, just markup cleanup

This is the **second P11 legacy CSS rule retirement** (after cluster 4's `.XPCheck`). Continues the eager-retirement pattern when a rule has zero consumers post-rebuild.

### `data-handle-change` finding

The `data-handle-change` attribute appears on ~all select/input elements in cluster-5 templates. **Pre-flight grep finds ZERO JS consumers** — it's a vestigial decorator probably left over from V12-era event delegation that V14 ApplicationV2's built-in form change-handler replaced. Could be retired entirely.

However, the P11 prep audit (c11-12) reserved attribute audits for later, and the cluster scope is "markup-token rebuild, not behavior refactor." **Recommendation: preserve `data-handle-change` verbatim in cluster 5**; flag for P12 attribute-cleanup sweep.

### JS-imperative class-hook contract — cluster-5 surface (audit-5 lock)

Per the audit-5 lock list and skill-selection.mjs source review:

- **skillSelect class hooks** (6 total, all listed above): `.select.rollable`, `.mediumIcon`, `data-set`, `.skill-select`, `.count`, `.item-{{key}}` — **all preserved verbatim**.
- **Foundry built-in form hooks**: `name="..."` attributes on inputs/selects, `data-dtype` for type coercion — **all preserved verbatim**.
- **`name` attributes**: every form field has a `name` attribute the JS reads via `dialog.element.querySelector('[name="X"]')` or via the form-data object. Must NOT change names.

### i18n keys inventory

Cluster-5 templates consume the following keys (all need to resolve in `lang/en.json`):

`Elysium.selectPower`, `Elysium.enterValue`, `Elysium.hitLoc`, `Elysium.tokenCreationRoll.prompt`, `Elysium.selectionsMade`, `Elysium.damagePrompt`, `Elysium.hit-location`, `Elysium.healPrompt`, `Elysium.healType`, `Elysium.selectWound`, `Elysium.askSuccess`, `Elysium.askRange`, `Elysium.askHands`, `Elysium.askLevel`, `Elysium.addStat`, `Elysium.diffValHint`, `Elysium.diffVal`, `Elysium.difficulty`, `Elysium.resistVal`, `Elysium.vsPOW`, `Elysium.flatModHint`, `Elysium.flatMod`

All to be verified during coding-time i18n sweep.

---

## 2. Architectural decisions for cluster 5

### c5-1: Composition vs new partials vs rebuild per template

Cluster-4 lesson learned: cluster-1's chat partials don't compose into dialog surfaces. The dialog archetypes (label+select, label+input, iterated list) are simpler shapes than chat cards.

Options:
- **(A) New shared partial** `dialog-row-select.hbs` + `dialog-row-input.hbs` for the two recurring row patterns. The 5 select-based dialogs and 4 input-based dialogs would compose these.
- **(B) Per-dialog rebuild** with no shared partials — each template stays standalone but adopts the `.elysium-dialog` marker and BEM-element classes.
- **(C) Hybrid** — shared partial for the row patterns only; iterated dialogs (selectItem, skillSelect) and the complex difficulty.hbs stay standalone.

**Trade-offs**:
- Option A reduces LOC and centralizes the row markup, but introduces a partial signature that 9 of 10 dialogs need to comply with. The partial would need to support `optionsList` AND `inputType` AND `selected` AND `label` AND `data-tooltip` — getting wide.
- Option B keeps each template independent but means the "label class, select class, input class" conventions get re-declared 10 times.
- Option C splits the difference — the recurring `flexrow > label + select/input` pattern (~30 LOC across the 9 simple dialogs) goes into a shared partial; the 2 iterated dialogs + the complex difficulty.hbs stay inline.

**Recommendation: Option C**. Build one shared partial `dialog-row.hbs` that handles BOTH select and input variants in a single signature (`field` context with `field.kind` ∈ `['select', 'input']`). The 9 simple dialogs (everything except skillSelect — selectItem is small enough either way) compose this; the 2 iterated dialogs and difficulty.hbs stay standalone. Estimated LOC savings: 226 → ~150 (-76).

### c5-2: New `dialog-row.hbs` partial — context contract

```
{
  field: {
    kind: 'select' | 'input',
    label: string,           // i18n key for the label
    name: string,            // form field name attribute
    tooltip?: string,        // i18n key for data-tooltip attribute
    // For kind='select':
    options: object,         // for {{selectOptions}} helper
    selected?: string,       // currently-selected value
    // For kind='input':
    inputType?: string,      // default 'text'; also 'number'
    value?: string|number,
    dtype?: string,          // data-dtype attribute
  }
}
```

```hbs
{{!-- dialog-row.hbs --}}
<div class="elysium-dialog__row">
  <label{{#if field.tooltip}} data-tooltip="{{localize field.tooltip}}"{{/if}}>{{localize field.label}}</label>
  {{#if (eq field.kind "select")}}
    <select data-handle-change name="{{field.name}}">
      {{selectOptions field.options selected=field.selected}}
    </select>
  {{else}}
    <input data-handle-change name="{{field.name}}" type="{{#if field.inputType}}{{field.inputType}}{{else}}text{{/if}}" value="{{field.value}}"{{#if field.dtype}} data-dtype="{{field.dtype}}"{{/if}}/>
  {{/if}}
</div>
```

**Recommendation: Apply as above.** The `.elysium-dialog__row` BEM-element class replaces the legacy `flexrow + resource-label-diff` combo. Section B in `elysium-chat.css` gets a new rule for `.elysium-dialog__row` (flex layout, label width, gap).

### c5-3: Wrapper structure for cluster-5 templates

Each rebuilt dialog wrapper:

```hbs
<form class="elysium elysium-dialog" id="...">
  {{!-- Optional header --}}
  <div class="elysium-dialog__title">{{label}}</div>
  
  {{!-- Composed rows --}}
  {{> "systems/elysium/templates/dialog/parts/dialog-row.hbs" field=...}}
  {{!-- ...more rows... --}}
</form>
```

The 9 simple dialogs follow this skeleton. The 2 iterated dialogs (selectItem, skillSelect) have a custom iteration body but still use the `elysium-dialog` marker + a `__title` slot.

**Recommendation: Apply.** Section B gets 2-3 new rules: `__row` (flex layout), `__title` (header typography — can reuse `.elysium-chat-card__title` or layer a `.elysium-dialog__title` selector alongside).

### c5-4: data-card-type attribute for dialogs?

`.elysium-chat-card` uses `data-card-type` for Section D accents. Dialogs don't have card-type variation — they have purpose variation (combat/healing/skill-pick/etc.).

Options:
- **(A) Add `data-dialog-type`** with codes per dialog (CP=selectPower, GV=getValue, HL=hitLocChoice, etc.) and populate accent rules.
- **(B) No accent attribute** — dialogs are functional UI, accent color isn't load-bearing for "what kind of dialog is this." The window title bar already carries that information.

**Recommendation: Option B**. Skip data-dialog-type and accent rules. Dialogs render as plain `.elysium-dialog` boxes with token-driven typography and the marker rule's base styling. If P12 wants to add dialog-type accents later for parity with chat-cards, the attribute can be added then.

### c5-5: skillSelect rebuild approach

skillSelect has 6 audit-5 JS-imperative class hooks. The rebuild must preserve ALL of them verbatim. The template structure:

```hbs
<section class="elysium elysium-dialog skill-select" id="skill-select-form">
  <div class="elysium-dialog__counter">
    <label>{{localize 'Elysium.selectionsMade'}}:</label>
    <span class="count">0</span>
    <span>/</span>
    <span>{{picks}}</span>
  </div>
  {{#each selectOptions as |option key|}}
    <div class="elysium-dialog__select-row">
      <div class="mediumIcon item-{{key}} select rollable" data-set="{{key}}">
        <a><i class="fa-regular fa-square"></i></a>
      </div>
      <div>{{option.name}}</div>
    </div>
  {{/each}}
</section>
```

**Preserved verbatim**: `.skill-select`, `.count`, `.mediumIcon`, `.item-{{key}}`, `.select`, `.rollable`, `data-set`. The retired classes are `.selectList`, `.new-row`, `.centre`, `.bold`, `.charname`, `.skill-opt-label`, `.font14` — all are CSS-only hooks that can be replaced by BEM-element classes or dropped entirely.

The legacy `<section>` element is preserved (skillSelect uses `<section>` not `<form>` — the dialog wrapper is a Dialog instance, not an HTML form).

**Recommendation: Apply.** Note in the changelog that 7 cosmetic classes were dropped from skillSelect markup while the 6 JS-imperative classes are all preserved.

### c5-6: difficulty.hbs rebuild approach

72 LOC, the largest cluster-5 template. It composes ~6 conditional rows. Each row IS a dialog-row pattern — but the conditionality differs (some show always, some show on cardType, some show on flag). Two options:

- **(A) Inline all 6 rows** (don't compose dialog-row partial) — easier to reason about, but duplicates the row markup.
- **(B) Compose dialog-row partial for each row** — saves LOC but adds 6 partial-include lines with their own arg lists.

**Recommendation: Option B**. The savings are real (6 × ~5 LOC saved = ~30 LOC reduction). Each partial-include is ~5 LOC of args. Final difficulty.hbs ~50 LOC (from 72).

There's one complication: the difficulty.hbs row with `useDiffValue` toggle has an EITHER select OR input variant (same field name, different markup). The dialog-row partial's `field.kind` switch handles this directly — the wrapper just picks the right `kind` based on `useDiffValue`.

The `isOr` block for RE/PP showing the resistance label/input — the dialog-row partial's label slot could take a Handlebars expression result, but cleanest is to pass the localized label string directly from the wrapper.

Refinement: extend the partial's `field.label` to accept either an i18n key (default) or an already-resolved literal string (when `field.labelLiteral=true`). This adds one branch to the partial.

Alternative: build the resistance-row inline in difficulty.hbs (it's only 1 row); compose dialog-row for the other 5 rows. This avoids the labelLiteral extension.

**Recommendation refined**: Compose dialog-row for 5 rows of difficulty.hbs; inline the resistance row. Final difficulty.hbs ~55 LOC.

### c5-7: Section B additions for `.elysium-dialog`

New rules in `styles/elysium-chat.css` Section B:

```css
/* Dialog-specific rules (P11 cluster 5, alpha.49) — extends the marker
 * rule defined in Section A. Token-driven layout for the dialog row
 * conventions used by 9 of 10 cluster-5 templates. */

.elysium-dialog__title {
  /* Reuses .elysium-chat-card__title's visual via a layered selector */
  color: var(--ely-text-decorative);
  font-size: var(--ely-font-size-2);
  font-weight: var(--ely-font-weight-bold);
  margin-bottom: var(--ely-space-2);
}

.elysium-dialog__row {
  display: flex;
  align-items: center;
  gap: var(--ely-space-2);
  margin-bottom: var(--ely-space-1);
}

.elysium-dialog__row > label {
  flex: 0 0 auto;
  min-width: 100px;
}

.elysium-dialog__row > select,
.elysium-dialog__row > input {
  flex: 1 1 auto;
}

.elysium-dialog__counter {
  display: flex;
  gap: var(--ely-space-1);
  margin-bottom: var(--ely-space-2);
  font-weight: var(--ely-font-weight-bold);
}

.elysium-dialog__select-row {
  display: grid;
  grid-template-columns: 30px 1fr;
  gap: var(--ely-space-1);
  align-items: center;
  padding: var(--ely-space-1) 0;
}
```

~25 LOC of new CSS in Section B.

### c5-8: ApplicationV2 vs Dialog vs DialogV2

The cluster-5 templates render into a mix of dialog containers:
- Some use Foundry's `Dialog` class (legacy V12-era)
- Some use `DialogV2` (the V14 recommended replacement)
- skillSelect uses a custom `SkillsSelectDialog` extending `ElysiumDialog` (per `module/apps/skill-selection.mjs`)

**Cluster 5 scope is template-level only.** The JS dispatch layer (which dialog class instantiates each template) is OUT of scope. The cluster-5 work just rebuilds the HTML/CSS of what gets rendered inside the dialog body. The dialog chrome (title bar, OK/Cancel buttons) is provided by Foundry's Dialog/DialogV2 framework and unchanged.

**Recommendation: Do NOT touch JS dispatch.** Template-only rebuild. If P12 wants to migrate the remaining `Dialog` instances to `DialogV2`, that's a separate effort.

### c5-9: Legacy CSS retirements in cluster 5

Per §1 retirement plan:
- `.elysium .selectList` (lines 1416-1420 of css/legacy.css — 5 lines, 1 brace pair) — sole consumer is skillSelect.hbs being rebuilt
- Markup-side drops: `resource-label-diff`, `diff-number-input`, `radioList`, `item-view` (no CSS rules to retire — all pure semantic-marker classes)

**Recommendation: Retire `.selectList` CSS rule.** Continues the cluster-4 eager-retirement pattern. After cluster 5: `css/legacy.css` 1633 → 1628 LOC (-5).

### c5-10: i18n key sweep

All 22 keys listed in §1 will be verified during the coding-time i18n sweep. No new keys expected (cluster 5 is markup rebuild, not new features).

### c5-11: Smoke methodology

10 dialogs × multiple branching states = ~25 distinct fixtures:
- selectPower × 1 (no variation)
- getValue × 1
- hitLocChoice × 1 (with selected value)
- npcTokenCreate × 2 (askStats true / false)
- selectItem × 1 (with 3 items)
- skillSelect × 1 (with 5 options, picks=2)
- newWound × 4 (getDam={true,false} × getLoc={true,false})
- treatWound × 3 (always-prompt + getType={true,false} + getWnd={true,false}; sample 3 combos)
- damageDiff × 4 (one for each askSuccess/askRange/askHands/askLevel)
- difficulty × 6 (cardType={NO,RE,PP}, useDiffValue={true,false}, plus askRange/askHands/firstAid)

Audit-5 contract checks per fixture:
- `<form class="elysium elysium-dialog">` or `<section class="elysium elysium-dialog">` present
- For skillSelect specifically: all 6 JS-hook classes present (`.select.rollable`, `.mediumIcon`, `data-set`, `.skill-select`, `.count`, `.item-X`)
- `name` attributes on all form fields match the legacy ones (preserves Foundry's form-data extraction)
- No retired classes present (resource-label-diff, diff-number-input, radioList, item-view, selectList)

**Live smoke**: trigger each dialog through actual game actions (cast spell → selectPower; first-aid → damageDiff; combat attack → difficulty; new character → rollStats; etc.). Most dialogs can be triggered through normal play; a few (npcTokenCreate) require dragging an NPC onto the scene.

---

## 3. Cluster-5 ship summary

**Files added** (1):
- `templates/dialog/parts/dialog-row.hbs` (~20 LOC) — shared row partial supporting select+input variants via `field.kind` switch.

**Files modified** — 10 templates rewritten:

| Template | Legacy LOC | Rebuilt LOC (est) |
|---|---|---|
| `selectPower.hbs` | 9 | ~8 |
| `getValue.hbs` | 10 | ~9 |
| `hitLocChoice.hbs` | 10 | ~10 |
| `npcTokenCreate.hbs` | 10 | ~10 |
| `selectItem.hbs` | 12 | ~12 |
| `skillSelect.hbs` | 16 | ~15 |
| `newWound.hbs` | 19 | ~14 |
| `treatWound.hbs` | 31 | ~22 |
| `damageDiff.hbs` | 37 | ~25 |
| `difficulty.hbs` | 72 | ~55 |
| **Total** | **226** | **~180** |

**Net templates**: -46 LOC (-20%), plus +20 LOC partial = -26 LOC net.

**Files modified** — CSS:
- `styles/elysium-chat.css`: +25 LOC (new Section B sub-block for dialog selectors)
- `css/legacy.css`: -5 LOC (`.elysium .selectList` retirement)

**Files modified** — registration + meta:
- `module/hooks/init.mjs`: +1 LOC (register new partial)
- `system.json`: version bump alpha.48 → alpha.49
- `CHANGELOG.md`: alpha.49 entry
- `ROADMAP-v1.0.0.md`: execution-log + progress-tracker update

**Net non-documentation change**: ~-5 LOC. Cluster 5 is the first cluster with a meaningful LOC reduction since cluster 3 (-82) — driven by the row-partial composition.

---

## 4. Out of scope for cluster 5

- The 51 inline-HTML `ChatMessage.create({content:...})` callsites (out of P11 per c11-8)
- ApplicationV2/Dialog/DialogV2 dispatch layer changes (template-only scope per c5-8)
- `data-handle-change` retirement (P12 attribute sweep)
- Retoken of `darkred` to `--ely-text-danger` (preserves `var(--ely-legacy-colour-secondary)` for now; P12 candidate)
- Optional clusters 6 (island harmonisation) and 7 (combat-tracker)
- Damage-type taxonomy alignment (P12 per c1-9)

---

## 5. Open questions for user lock-in

1. **Composition approach (c5-1)** — Option C: shared `dialog-row.hbs` partial for the 9 simple dialogs + standalone iterated dialogs (selectItem, skillSelect) + standalone-but-composes-row-partial for difficulty.hbs. Alternative: Option B (per-dialog rebuild, no shared partial). Recommendation: C.

2. **`data-dialog-type` attribute (c5-4)** — skip for cluster 5 (dialogs are functional UI, accent isn't load-bearing). Alternative: add with codes for parity with chat-card Section D. Recommendation: skip.

3. **`.elysium .selectList` legacy CSS retirement (c5-9)** — eager retire (sole consumer is skillSelect being rebuilt). Continues the cluster-4 pattern. Alternative: hold for P12 sweep. Recommendation: eager retire.

4. **`data-handle-change` attribute (§1 finding)** — has zero JS consumers system-wide; cluster 5 preserves verbatim for tight scope. Confirm: preserve, flag for P12?

5. **Pure-marker class drops** — drop `resource-label-diff`, `diff-number-input`, `radioList`, `item-view` from markup (no CSS rules to retire, just semantic-marker cleanup). Confirm: drop?

6. **Cluster 5 → next** — after cluster 5 ships, what's next? Options:
   - Optional cluster 6 (island harmonisation evaluation — are the 4 v1.0.0 islands cast-card/manipulation/csb/tcd still well-aligned after all the cluster-1-5 work, or do they need a re-sweep?)
   - Optional cluster 7 (combat-tracker cosmetic restyle)
   - Jump to P12 (polish + acceptance)
   Recommendation: ship cluster 5 first, then assess.

---

## 6. Ready-to-go checklist (cluster 5 ships when all green)

- [ ] User confirms decisions c5-1 through c5-11
- [ ] User answers the 6 open questions in §5
- [ ] User accepts scope-cut list in §4

Once locked, cluster 5 coding begins.
