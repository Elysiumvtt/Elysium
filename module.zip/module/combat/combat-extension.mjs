/**
 * Elysium Combat Extension
 *
 * Provides:
 *   - Custom initiative formula (1d10 + bonus - armour penalty)
 *   - Action Point pool refresh each combat round
 *   - Reaction AP separate from action AP
 *   - End-of-combat cleanup
 *
 * The BRP combat tracker is preserved — Elysium hooks into events
 * rather than replacing the tracker.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'

export class ElysiumCombatExtension {

  /**
   * Combat starts — initialise AP pools for all combatants
   */
  static async onCombatStart (combat, updateData) {
    if (!combat?.combatants) return
    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await this._refreshActionPoints(actor)
    }
  }

  /**
   * New round — refresh AP for all combatants
   */
  static async onRound (combat, updateData, updateOptions) {
    if (!combat?.combatants) return
    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await this._refreshActionPoints(actor)

      // Apply ongoing damage from conditions like Bleeding
      await this._applyOngoingDamage(actor)
    }
  }

  /**
   * New turn — currently no-op; reserved for per-turn effects
   */
  static async onTurn (combat, updateData, updateOptions) {
    // Reserved for per-turn logic (e.g. start-of-turn saves)
  }

  /**
   * Combat ends — clear AP pools, do cleanup
   */
  static async onCombatEnd (combat, options, userId) {
    if (!combat?.combatants) return
    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await actor.update({
        'flags.elysium.actionPoints.value':       0,
        'flags.elysium.actionPoints.reactValue':  0,
        'flags.elysium.actionPoints.attackValue': 0,
      }, { render: false })
    }
  }


  // === INITIATIVE ===================================================

  /**
   * Compute initiative for a combatant.
   * Returns the formula string for the BRP combat tracker.
   */
  static getInitiativeFormula (combatant) {
    const actor = combatant.actor
    if (!actor) return '1d10'

    const bonus = ElysiumActorExtension.calculateInitiativeBonus(actor)
    return `1d10 + ${bonus}`
  }


  // === ACTION POINT POOL REFRESH ====================================

  static async _refreshActionPoints (actor) {
    const apData = ElysiumActorExtension.calculateActionPoints(actor)
    if (!apData) return

    await actor.update({
      'flags.elysium.actionPoints': {
        max:         apData.max,
        value:       apData.max,
        base:        apData.base,
        reactMax:    apData.reactMax,
        reactValue:  apData.reactMax,
        attackMax:   apData.attackMax,
        attackValue: apData.attackMax,
        breakdown:   apData.breakdown,
      }
    }, { render: false })
  }


  // === ONGOING DAMAGE PROCESSING ====================================

  /**
   * Apply ongoing per-round damage from conditions like Bleeding.
   * Reads condition AEs and applies their per-round HP damage.
   */
  static async _applyOngoingDamage (actor) {
    let totalDamage = 0
    const sources = []

    for (const ae of actor.effects) {
      if (ae.disabled) continue
      const flags = ae.flags?.elysium
      if (!flags) continue

      // Bleeding condition: 1 HP per round
      if (flags.group === 'condition.Bleeding' || flags.condition === 'bleeding') {
        const rate = flags.bleedRate || 1
        totalDamage += rate
        sources.push(`${game.i18n.localize('Elysium.Conditions.Bleeding')} (${rate})`)
      }

      // Arterial bleeding: faster
      if (flags.group === 'condition.Arterial Bleeding' || flags.condition === 'arterialBleeding') {
        const rate = flags.bleedRate || 3
        totalDamage += rate
        sources.push(`${game.i18n.localize('Elysium.Conditions.ArterialBleeding')} (${rate})`)
      }

      // Burning, Poisoned, Decay, etc. - similar pattern
      if (flags.ongoingDamage) {
        totalDamage += flags.ongoingDamage.amount || 0
        sources.push(`${flags.ongoingDamage.source} (${flags.ongoingDamage.amount})`)
      }
    }

    if (totalDamage > 0) {
      const currentHP = actor.system.health?.value || 0
      const newHP = currentHP - totalDamage
      await actor.update({
        'system.health.value': newHP,
      })

      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `
          <div class="elysium-ongoing-damage">
            <h4>${actor.name} — ${game.i18n.localize('Elysium.Combat.OngoingDamage')}</h4>
            <p>${totalDamage} ${game.i18n.localize('Elysium.HP')}</p>
            <ul>${sources.map(s => `<li>${s}</li>`).join('')}</ul>
          </div>
        `,
      })
    }
  }


  // === LUCK POINT RECOVERY =========================================

  /**
   * Called manually at session start to refresh Luck Points.
   * Mythras: full pool restored each session.
   */
  static async refreshLuckPoints (actor) {
    if (!getSetting('enableLuckPoints', true)) return

    const pow = ElysiumActorExtension._parseStatTotal(actor.system.stats?.pow)
    const powBonus = Math.max(1, this._powBonus(pow))
    const max = ELYSIUM.LUCK_POINTS.base + powBonus

    await actor.update({
      'flags.elysium.luckPoints': {
        value: max,
        max:   max,
      }
    })
  }

  static _powBonus (pow) {
    // Standard BRP-ish bonus: -2 for low, +3 for high
    if (pow <= 4)  return -2
    if (pow <= 8)  return -1
    if (pow <= 12) return 0
    if (pow <= 16) return 1
    if (pow <= 20) return 2
    return 3
  }
}
