# P10 cluster 3 — 9 mid-tier item types (prep audit)

Captured 2026-05-14 after cluster 2 (alpha.39) smoke pass.
**Audit-then-stop**: no code shipped from this document.

## Scope

Cluster 3 covers the 9 mid-tier item types per P10 prep audit's audit-7
sequencing. All keep tabs (per audit-2). Mixed complexity — three light
sheets, three medium, three heavy:

| Type | Sheet LOC | Detail LOC | Mode | Specials |
|---|--:|--:|---|---|
| ability | 124 | 65 | tabbed | 2 extra HTMLFields (effectText, prerequisitesText) inline in details; `system.elysium.abilityType` static/percentile branch |
| hit-location | 102 | 105 | tabbed | NO description/gmNotes tabs (header + details only); custom form handler synthesizes `name` from displayName + bodyPlan; conditional `locType==='limb'` toggle row |
| skillcat | 143 | 117 | tabbed | 8 stat-attrib selects (currently buggy: 7 dead `advStatOptions*` context fields); CONFIG.Elysium.statsAbbreviations driven labels |
| mysticism | 135 | 101 | tabbed | 8 fields under `system.elysium.*` (discipline, tier, powerCost, apCost, saveSkill) + 3 top-level (range, duration, damage); spell-card style |
| divine | 170 | 187 | tabbed | Per-tier AP-cost grid (T1-T5) + per-tier effect textareas; 3 boolean checkboxes; damage-type colored tag; custom form handler resyncs name from category |
| armor | 145 | 134 | tabbed | Effects PART; 13 fields; **bug**: player branch references `physMod`/`stealthMod` (camelCase) vs GM branch's `physmod`/`stealthmod`; conditional ppMax-gated energy fields |
| super | 278 | 70 | tabbed | Drag/drop for powerMod items; custom header (`skill.header.hbs`); custom form handler synthesizes name from mainName+specName; 4-field GM/player split; 2 toggles; powerMod drop list |
| personality | 354 | 80 | tabbed | Skills + groups drag/drop; ElysiumUtilities.fromElysiumIDBest lookups; add/remove group buttons; 4 legacy class-hook listener bindings |
| culture | 397 | 126 | tabbed | personality++ PLUS stat-formula 2-col grid PLUS per-skill cultural bonus (ElysiumDialog.input prompts on drop) |

Total surface: **~1850 LOC of sheet classes + ~990 LOC of templates**.

### Width plan per audit-3

Current widths range 520-535. Per audit-3 all 9 → 560×640 default tier.
None of these are in the wide (720×720) bracket — that's reserved for
weapon/armor (cluster 5) ... wait, armor IS here, not in cluster 5.
Audit-3 actually said weapon/armor/arcane/sorcery/divine/mysticism/skill/career
go wide. So in cluster 3 four items go wide: **armor, divine, mysticism**
go to 720×720; the other 6 (ability, hit-location, skillcat, super,
personality, culture) go to 560×640.

Re-checking the prep audit audit-3 lock: "wide variant 720×720
(weapon/armor/arcane/sorcery/divine/mysticism/skill/career)" — that's
8 items. Armor + divine + mysticism are in cluster 3 → 3 of those 8.
The other 5 are in clusters 4/5/6.

### Action handlers in use (cluster 3)

Per template grep:
- **itemToggle** (existing, registered) — for `specialism`, `chosen`,
  `improve`, `oppimprove`, `injured`, `incapacitated`, `severed`,
  `unconscious`, `dead`
- **onEditImage** / **editBRPid** — header/frame (existing)
- **Drag/drop** custom infrastructure on super, personality, culture
  (NOT a V14 action — instance method `_onDrop` bound by dragDrop
  handler)
- **Imperative listeners** on legacy CSS class hooks (super /
  personality / culture):
  - `.item-delete` → `_onItemDelete`
  - `.item-view` → `_onItemView`
  - `.group-item-delete` → `_onGroupItemDelete` (personality/culture)
  - `.group-control` (add/remove group buttons) → `_onGroupControl`
    (personality/culture)

Per audit-5 lock pattern: these legacy class hooks should be
PRESERVED in the v1.0.0 markup with new BEM classes layered on top.
Migration to V14 action handlers is deferred to P12 (same deferral
as active-effects CRUD). Cluster 3 ships restyle-only on these
interactions.

## 1. Per-type ship plan

### 1.1 ability (124 → ~75 LOC)

**Specials**: 2 extra HTMLFields inline in details (`effectText`,
`prerequisitesText`). These aren't separate PARTs — they're rendered
inside the details body using the OLD `{{editor ...}}` Handlebars
helper rather than the v1.0.0 `<prose-mirror>` element.

**Long-term cleanup decisions**:

1. **c3-ability-1**: Migrate `{{editor ...}}` → `<prose-mirror>` so
   ability's inline HTMLFields use the same rendering pipeline as
   description/gmNotes/benefits. Recommendation: **yes** — single
   pipeline, consistent UX. Adds 2 enriched-HTML context fields
   (`enrichedEffectText`, `enrichedPrerequisitesText`) which the
   sheet class already prepares.

2. **c3-ability-2**: The `isPercentile` flag drives whether the
   Base/XP/Total panel renders. Keep the conditional; chip-set
   reflects it (see §2).

**Migration**: standard tabbed pattern. Sheet class shrinks to base
hoist + sheet-specific `_prepareContext` (adds catOptions,
abilityType, isPercentile, header chips, effectText / prerequisitesText
enrichment via override of `_preparePartContext`).

### 1.2 hit-location (102 → ~80 LOC)

**Specials**:
- NO description/gmNotes PARTs (header + details only — but still
  tabbed mode? Actually NO — only 1 tab, so effectively the tab
  strip is degenerate). Should we render the tab strip with 1 chip?
  Per cluster-1's TAB_ORDER design: setting `TAB_ORDER = ['header',
  'tabs', 'details']` renders a 1-chip tab strip. Alternative: keep
  hit-location as TAB_ORDER = null and inline the details.

**Long-term cleanup decisions**:

3. **c3-hitloc-1**: hit-location currently has only one content
   tab. Recommendation: **convert to single-page mode**
   (TAB_ORDER = null), same as cluster-2 single-page items.
   Eliminates the degenerate 1-chip strip; saves vertical space.
   This is consistent with audit-2's "case-by-case single-page
   decision" — hit-location wasn't on the original cluster-2 list,
   but its single-tab shape fits the same criterion.

4. **c3-hitloc-2**: 2 hardcoded English tooltips on the Body
   Part / Side / Index rows ("Mythras body-part designation...",
   "Laterality: left or right...", "Enumeration index..."). All
   3 should be moved to i18n keys for proper localization.
   Recommended keys: `Elysium.bodyPartHint`, `Elysium.bodySideHint`,
   `Elysium.bodyIndexHint`.

5. **c3-hitloc-3**: Pre-existing missing key `Elysium.severedHint`
   (flagged in cluster-2 sweep, line 90 of hit-location.detail.hbs).
   Fix: add the key with the existing tooltip text from neighboring
   `injuredHint`/`incapacitatedHint`/`deadHint` patterns.

6. **c3-hitloc-4**: The condition options block has 5 toggle chips
   with conditional `locType==='limb'` swap (severed-or-unconscious/
   dead). The Mythras body-plan toggles (`elysium.bodyPart`,
   `elysium.side`, `elysium.index`) are 3 more fields. Keep the
   exact same conditional structure; restyle only.

### 1.3 skillcat (143 → ~75 LOC)

**Specials**:
- 8 stat-attrib selects.
- **Buggy**: `advStatOptionsStr`/`advStatOptionsCon`/etc. are 7 dead
  context fields (the template only references `advStatOptionsCon`
  for all 8 selects, AND all 8 sheet-class lines call the same
  `ElysiumSelectLists.getAdvSkillCatOptions()` with no args). They're
  identical; only one is used.
- 8 `skillCatNameStr`/`skillCatNameCon`/etc. are similarly redundant
  (each does `Elysium.advSkillCat.<stat>` lookup; could be looped).

**Long-term cleanup decisions**:

7. **c3-skillcat-1**: Replace the 8 redundant `advStatOptions*`
   context fields with a single `advStatOptions`. The template's
   8 selects all reference the same options list. Recommendation:
   **yes** — clean dead code; reduces sheet-class LOC by 7 lines.

8. **c3-skillcat-2**: Replace the 8 redundant `skillCatName*`
   context fields with a single computed map:
   ```js
   context.skillCatNames = Object.fromEntries(
     Object.entries(this.item.system.attrib).map(([k, v]) =>
       [k, game.i18n.localize('Elysium.advSkillCat.' + v)])
   );
   ```
   Template references `{{skillCatNames.str}}`, etc. Cleaner.
   Recommendation: **yes**.

9. **c3-skillcat-3**: Build the per-stat row data structure in
   _prepareContext rather than repeating the 8 inline `<div>`
   blocks in the template:
   ```js
   context.statRows = Object.keys(this.item.system.attrib).map(stat => ({
     stat,
     label: game.i18n.localize(`Elysium.Stats${capitalize(stat)}Abbr`),
     value: this.item.system.attrib[stat],
     displayName: game.i18n.localize('Elysium.advSkillCat.' + this.item.system.attrib[stat]),
   }));
   ```
   Template loops `{{#each statRows}}` and renders one row per stat.
   Saves ~80 template lines.
   Recommendation: **yes**. Long-term clean.

### 1.4 mysticism (135 → ~65 LOC)

**Specials**:
- 8 fields, all GM-edit / player-readonly split.
- Uses `system.elysium.*` paths plus 3 top-level fields (range,
  duration, damage).
- Current template uses `elysium-spell-sheet` + `elysium-spell-row`
  classes — a v0.9.0 pattern that is NOT v1.0.0.

**Long-term cleanup decisions**:

10. **c3-mysticism-1**: Migrate `elysium-spell-*` classes to v1.0.0
    `item-field-grid` + `item-field-row` partials. This deletes the
    `.elysium-spell-sheet`, `.elysium-spell-row`, `.elysium-spell-readonly`
    legacy CSS — they're used here, in divine, and in cluster-4's
    arcane/sorcery. **For cluster 3**: migrate mysticism + divine
    templates; defer CSS deletion until cluster 4 (when arcane +
    sorcery also migrate).

11. **c3-mysticism-2**: 4 hardcoded English option labels in the
    saveSkill `<select>` ("Evade", "Willpower", "Endurance",
    "Brawn"). Same issue exists in divine. **Long-term fix**:
    pre-populate the options list in the sheet class via a new
    `getSpellSaveSkillOptions()` helper in `ElysiumSelectLists`.
    Then the template just emits `{{selectOptions saveSkillOptions
    selected=item.system.elysium.saveSkill}}`. Recommendation: **yes**.

### 1.5 divine (170 → ~85 LOC)

**Specials**:
- Most complex cluster-3 template.
- Per-tier AP-cost grid (T1-T5 numeric inputs).
- Per-tier effect textareas.
- 3 boolean checkboxes (isRitual, isReactive, isDamageSpell).
- Damage-type colored tag display.
- Custom form handler resyncs `name` from `category` localization.
- Hardcoded English on 6+ labels ("Base Tier", "Max Tier",
  "Damage Type", "Effects by Tier", "AP Cost by Tier", option
  values).

**Long-term cleanup decisions**:

12. **c3-divine-1**: All hardcoded English labels on the divine
    template need i18n keys. Proposed new keys: `Elysium.baseTier`,
    `Elysium.maxTier`, `Elysium.damageType`, `Elysium.effectsByTier`,
    `Elysium.apCostByTier`. Plus damage-type option labels
    (`Elysium.damageRadiant`, `Elysium.damageLightning`,
    `Elysium.damageFire`, `Elysium.damageSonic`, `Elysium.damageNone`).
    Plus saveSkill labels shared with mysticism (see c3-mysticism-2).
    Recommendation: **yes** — add all keys to en/es/fr.

13. **c3-divine-2**: damageType, saveSkill `<select>` should use
    `selectOptions` helper against new options lists in
    ElysiumSelectLists, not inline `<option>` blocks. Same pattern
    as c3-mysticism-2. Recommendation: **yes**.

14. **c3-divine-3**: The per-tier effect rows use `<textarea>` —
    a plain element, not a ProseMirror editor. Should each tier's
    effect text be ProseMirror-editable? Looking at the field
    purpose (short description of tier's effect), plain textarea is
    appropriate. Recommendation: **keep as textarea**; if a tier
    needs rich formatting it goes in the long-form description.

15. **c3-divine-4**: 3 boolean checkboxes (`isRitual`, `isReactive`,
    `isDamageSpell`) — currently rendered as native `<input
    type="checkbox">` elements. Should they convert to the
    `elysium-item-toggle` chip pattern (consistent with cluster-2's
    treated/perLvl/minorOnly chips)? Recommendation: **yes** —
    consistent toggle visual across all item sheets. itemToggle
    action handles the same; just need to add these properties to
    the allowed-list in `base-item-sheet.mjs::_onItemToggle`.

### 1.6 armor (145 → ~85 LOC)

**Specials**:
- Effects PART (audit-5 lock applies; preserve `active-effect-change-edit`
  in the v1.0.0 effects partial).
- 13 fields (4 AV + 9 stats) when GM, plus 3-4 owner fields.
- 2 fields use computed labels (`{{wealthLabel}}` from base context).

**Long-term cleanup decisions**:

16. **c3-armor-1**: **Bug fix** — player branch references
    `{{item.system.physMod}}` and `{{item.system.stealthMod}}`
    (camelCase) on lines 81/83 of armor.detail.hbs, but the actual
    DataModel field names are `physmod` and `stealthmod` (lowercase
    per lines 51/54 of the GM branch). Player view shows empty
    values for those fields. Fix on rewrite. Verified against
    armor DataModel for correct casing before ship.

17. **c3-armor-2**: 13 fields is a lot for one grid — should the
    detail be split into logical groups (Protection / Encumbrance /
    Penalties / Power)? Recommendation: **yes, 4 sub-groups via 4
    item-field-grid invocations**, each with a small label header.
    Cleaner mental model.

### 1.7 super (278 → ~140 LOC)

**Specials**:
- Custom header (`skill.header.hbs`) with specialism-aware
  name/specName layout.
- Drag/drop for powerMod items.
- Custom form handler synthesizes name from mainName + specName.
- 4 fields with GM/player split + 2 owner-only fields.
- 2 toggles + powerMod drop list with .item-view/.item-delete
  legacy class-hook listeners.

**Long-term cleanup decisions**:

18. **c3-super-1**: Migrate `skill.header.hbs` to a v1.0.0
    pattern. Two options:
    - (A) New `item-shell-header-specialism.hbs` partial used by
      super (and skill in cluster 5). Specialism-aware: when
      `system.specialism === true`, renders `mainName` + `/` +
      `specName` inputs; otherwise just `mainName`.
    - (B) Extend the standard `item-shell-header.hbs` to
      conditionally render specialism inputs when context flags
      it. Pollutes the standard header.
    Recommendation: **Option A** — dedicated partial for the
    specialism shape. Two consumers (super + skill) justify a
    separate partial.

19. **c3-super-2**: The powerMod drop list uses legacy class hooks
    (`.item-view`, `.item-delete`) bound by `_onRender` imperative
    listeners. Per audit-5 deferral pattern, preserve these class
    hooks in the v1.0.0 markup. V14-actions migration → P12.

20. **c3-super-3**: The `data-action="itemToggle" data-property="specialism"`
    and `data-property="chosen"` chips use the existing V14 action
    handler. Update template to use `elysium-item-toggle` BEM
    class layered on top, preserving the `data-action` /
    `data-property` attributes.

### 1.8 personality (354 → ~170 LOC)

**Specials**:
- Skills + groups drag/drop infrastructure (`#dragDrop` private +
  4 listener bindings).
- ElysiumUtilities.fromElysiumIDBest lookups in _prepareContext
  (synchronous-looking but actually awaits inside loops — slow but
  correct).
- Add/remove group buttons (`.group-control add-group`,
  `.group-control remove-group`).
- Per-skill delete buttons (`.item-delete`) and group-item-delete
  (`.group-item-delete`).

**Long-term cleanup decisions**:

21. **c3-personality-1**: 4 legacy class-hook listeners bound in
    `_onRender`. Preserve all 4 class hooks per audit-5 pattern;
    layer v1.0.0 BEM classes on top:
    - `.item-delete` → `.elysium-row-delete .item-delete`
    - `.item-view` → `.elysium-row-view .item-view`
    - `.group-item-delete` → `.elysium-row-delete .group-item-delete`
    - `.group-control` → `.elysium-group-control .group-control`
    V14-actions migration → P12.

22. **c3-personality-2**: The current per-skill row template
    (lines 7-26 of personality.detail.hbs) is a flexrow with
    name/category-conditional display. Same shape repeats inside
    each optional skill group (lines 53-73). Recommendation:
    **extract a shared partial** `templates/item/parts/item-skill-row.hbs`
    that takes a skill object + isGM flag. Used by personality
    AND culture (cluster 3) AND career (cluster 6). One source of
    truth.

### 1.9 culture (397 → ~190 LOC)

**Specials**:
- All of personality's machinery.
- Stat-formula 2-column grid.
- Per-skill cultural bonus (`skill.bonus`) prompted via
  ElysiumDialog.input on drop.
- Cultural Bonus display string (hardcoded English).

**Long-term cleanup decisions**:

23. **c3-culture-1**: Hardcoded "Cultural Bonus: " label needs
    i18n key. Proposed: `Elysium.culturalBonus`.

24. **c3-culture-2**: Stat formula grid has 8 stat rows in a
    2-column layout (paired str/con, int/siz, etc.). Currently
    each iteration emits 5 divs and conditionally a newrow break.
    Recommendation: **build the row-pair structure in
    _prepareContext** to avoid template-side gymnastics.

25. **c3-culture-3**: ElysiumDialog.input prompt-on-drop for
    cultural bonus is interaction logic, not display. Preserved
    as-is. The skill-row partial (c3-personality-2) just renders
    the bonus value; the dialog flow stays in `_onDrop`.

## 2. Header chips per cluster-3 item

Per audit-6 (per-cluster chip sets):

| Type | Chips |
|---|---|
| ability | Type (Static/Percentile) + Category + (when isPercentile && hasOwner) Total |
| hit-location | Location Type + (when owned) HP Adjustment |
| skillcat | Base Stat |
| mysticism | Discipline + Tier + Power Cost |
| divine | Domain + Tier Band (base→max) + Power Cost |
| armor | AV (fixed) + Burden + (when owned) Status |
| super | Range + Duration + Power Cost + (when owned) Level |
| personality | (when owned) Skill Count |
| culture | (when owned) Skill Count + Stat Formula Count |

Numerics stringified per cluster-1 lesson; empty strings em-dash.

## 3. Shared header partial — specialism variant

Per c3-super-1, introduce
`templates/item/parts/item-shell-header-specialism.hbs` for super
(and skill in cluster 5).

Structure:
```html
<header class="elysium-item-header elysium-item-header--specialism">
  <img class="elysium-item-header-image" ... />
  <div class="elysium-item-header-text">
    {{#if item.system.specialism}}
      <input class="elysium-item-header-name elysium-item-header-name--main" name="system.mainName" ...>
      <span class="elysium-item-header-name-separator">/</span>
      <input class="elysium-item-header-name elysium-item-header-name--spec" name="system.specName" ...>
    {{else}}
      <input class="elysium-item-header-name" name="system.mainName" ...>
    {{/if}}
    <div class="elysium-item-header-type">{{itemType}}</div>
    {{#if itemHeaderChips.length}}
      ...standard chips block...
    {{/if}}
  </div>
</header>
```

Key insight: the `item.name` write happens via the form-handler
(`mySuperHandler`), which reads `mainName` + `specName` from
formData and writes `name = mainName + ' (' + specName + ')'`. The
sheet header doesn't bind `name="name"`; it binds `name="system.mainName"`
and `name="system.specName"`. The name field is computed.

## 4. Shared item-skill-row partial

Per c3-personality-2, introduce
`templates/item/parts/item-skill-row.hbs` for personality, culture,
and (future) career.

Structure:
```html
<div class="elysium-item-skill-row" data-item-id="{{skill.uuid}}"
     data-elysiumid="{{skill.elysiumid}}">
  <div class="elysium-item-skill-row-name" data-tooltip="{{skill.elysiumid}}">
    {{skill.name}}
    {{#if skill.variable}}
      <span class="elysium-item-skill-row-modifier">({{ localize 'Elysium.var'}})</span>
    {{else if skill.group}}
      <span class="elysium-item-skill-row-modifier">({{ localize 'Elysium.grp'}})</span>
    {{else}}
      <span class="elysium-item-skill-row-modifier">({{skill.base}}%)</span>
    {{/if}}
    {{#if skill.bonus}}
      <span class="elysium-item-skill-row-bonus">
        {{localize 'Elysium.culturalBonus'}}:
        {{#if (lt skill.bonus 0)}}{{skill.bonus}}{{else}}+{{skill.bonus}}{{/if}}%
      </span>
    {{/if}}
  </div>
  {{#if isGM}}
    <div class="elysium-item-skill-row-controls">
      {{#if showView}}
        <a class="elysium-row-view item-view"
           data-tooltip="{{localize 'Elysium.viewItem'}}"
           data-uuid="{{skill.uuid}}">
          <i class="fas fa-magnifying-glass"></i>
        </a>
      {{/if}}
      <a class="elysium-row-delete {{deleteClass}}"
         data-tooltip="{{localize 'Elysium.deleteItem'}}"
         data-uuid="{{skill.uuid}}">
        <i class="fas fa-trash"></i>
      </a>
    </div>
  {{/if}}
</div>
```

Params:
- `skill` — required skill data object (uuid, elysiumid, name, variable, group, base, optional bonus)
- `isGM` — gate controls
- `deleteClass` — caller specifies legacy hook (`item-delete` for
  main list, `group-item-delete` for grouped — both class hooks
  preserved per audit-5)
- `showView` — optional, defaults true for the main list

## 5. ElysiumSelectLists additions

Per c3-mysticism-2 + c3-divine-2:
- `getSpellSaveSkillOptions()` — returns `[{value: '', label: '—'},
  {value: 'evade', label: ...}, ...]` with localized labels.
- `getSpellDamageTypeOptions()` — same shape for radiant/lightning/
  fire/sonic/'' damage types.

Both consumed by mysticism + divine templates.

## 6. i18n keys to add (new in cluster 3)

| Key | en | Notes |
|---|---|---|
| `Elysium.severedHint` | "Limb has been severed; movement and use of this location are impossible." | c3-hitloc-3 |
| `Elysium.bodyPartHint` | "Mythras body-part designation. Used for HP table, critical-table routing, and move-penalty (legs only)." | c3-hitloc-2 |
| `Elysium.bodySideHint` | "Laterality: left or right for paired limbs; blank for unpaired locations." | c3-hitloc-2 |
| `Elysium.bodyIndexHint` | "Enumeration index for creatures with multiple identical limbs (e.g. 0..3 on a spider's four left legs). Leave 0 for typical humanoids." | c3-hitloc-2 |
| `Elysium.baseTier` | "Base Tier" | c3-divine-1 |
| `Elysium.maxTier` | "Max Tier" | c3-divine-1 |
| `Elysium.damageType` | "Damage Type" | c3-divine-1 |
| `Elysium.effectsByTier` | "Effects by Tier" | c3-divine-1 |
| `Elysium.apCostByTier` | "AP Cost by Tier" | c3-divine-1 |
| `Elysium.culturalBonus` | "Cultural Bonus" | c3-culture-1 |
| `Elysium.saveSkillNone` | "—" | c3-mysticism-2 (option label) |
| `Elysium.saveSkillEvade` | "Evade" | c3-mysticism-2 |
| `Elysium.saveSkillWillpower` | "Willpower" | c3-mysticism-2 |
| `Elysium.saveSkillEndurance` | "Endurance" | c3-mysticism-2 |
| `Elysium.saveSkillBrawn` | "Brawn" | c3-mysticism-2 |
| `Elysium.damageRadiant` | "Radiant" | c3-divine-1 |
| `Elysium.damageLightning` | "Lightning" | c3-divine-1 |
| `Elysium.damageFire` | "Fire" | c3-divine-1 |
| `Elysium.damageSonic` | "Sonic" | c3-divine-1 |
| `Elysium.damageNone` | "— (none / healing)" | c3-divine-1 |

All keys added to en.json + es.json + fr.json (3 lang files).

## 7. itemToggle property allow-list addition

Per c3-divine-4, add `isRitual`, `isReactive`, `isDamageSpell` to
the allowed-list in `base-item-sheet.mjs::_onItemToggle` (line 103
list of permitted properties).

## 8. CSS additions

Estimated +150 lines, ~18 brace pairs across these new patterns:

- **Specialism header variant** — main/sep/spec input row.
- **Item-skill-row** — flex row with name, modifier badge, optional
  cultural bonus, and controls.
- **Per-stat formula grid** (culture) — 2-column stat label/inputs
  grid.
- **Per-tier effect grid** (divine) — T1-T5 tier-label + cost +
  textarea blocks.
- **AP-cost tier grid** (divine) — T1-T5 numeric cell row.
- **Damage-type tag** (divine read mode) — colored pill per type.
- **Boolean toggle row** (divine flags) — checkbox cluster matched
  to the `elysium-item-toggle` chip pattern via a new
  `--checkbox` variant.

## 9. Smoke risks specific to cluster 3

1. **Legacy class hook preservation** — super, personality, culture
   all bind imperative listeners on `.item-delete`, `.item-view`,
   `.group-item-delete`, `.group-control`. v1.0.0 markup MUST keep
   these class names on the same elements (BEM layered on top).
   Pre-flight: grep the rebuilt templates for each class.

2. **Drag/drop binding** — super, personality, culture use
   `#dragDrop` private + `_onDrop` infrastructure. The drop targets
   are identified by `.droppable` class on elements. v1.0.0 markup
   MUST keep `.droppable` on the same elements. The `.item-list`
   class on the `<ol>` containers is also referenced by
   `_onGroupControl` (`a.closest('.item-list.group')`) — must
   preserve.

3. **Specialism-aware header** — super's mainName/specName inputs.
   When `system.specialism` toggles from false → true, the header
   should show both fields. Currently the toggle is on the details
   tab, not the header — clicking the toggle re-renders details
   PART, which doesn't re-render header. Same issue exists today.
   Smoke note: render with both states to verify the toggle
   correctly propagates (Foundry V14 re-renders all PARTs on
   submitOnChange, so the header should refresh).

4. **Armor field-name bug fix** — armor.detail.hbs player branch
   has `physMod`/`stealthMod` (wrong) — fix to `physmod`/`stealthmod`
   on rewrite.

5. **Hit-location single-page mode** — converts from tabbed (1 tab)
   to single-page. The conversion changes PARTS shape, drops the
   tabs PART. Smoke: verify width adjusts cleanly (and that the
   `headerDisplay: true` flag continues to work — that's the
   current way hit-location handles its custom header).

6. **Mysticism + divine spell-card class deletion** — the
   `elysium-spell-sheet` + `elysium-spell-row` CSS will be retired
   in cluster 4 (when arcane + sorcery also migrate). Cluster 3
   keeps the CSS alive but the rebuilt mysticism + divine
   templates no longer use those classes.

7. **8-select skillcat dead-code removal** — replacing 8 redundant
   `advStatOptions*` with 1 changes the context shape. The new
   loop-based template will render 8 selects against the single
   `advStatOptions` field. Pre-flight verify: each select still
   gets the proper `selected` attribute via `selectOptions`.

8. **Culture skill-row partial sharing** — the new
   `item-skill-row` partial is used by personality + culture +
   (future) career. If career has different requirements
   (cluster 6), they'll need different partials or partial-block
   injection. Cluster 3 commits to the shape; cluster 6 may
   extend.

9. **Divine per-tier effect data shape** — `system.elysium.effectByTier`
   is an object keyed by string tier numbers. The current
   `_prepareContext` flattens this into a list. v1.0.0 template
   renders the list. Form submission writes back as
   `system.elysium.effectByTier.<tier>` (Foundry's flat-to-nested
   expansion handles it). Verify on smoke that editing tier 3's
   text persists correctly to `effectByTier.3`.

10. **Ability inline HTMLFields** — migrating `{{editor ...}}` →
    `<prose-mirror>` is a real behavior change for ability. Both
    render edit + view; both call enrichHTML; both persist on
    blur. Difference: `<prose-mirror>` is the modern element, used
    everywhere else in v1.0.0. Smoke: edit effectText, verify
    persists.

## 10. Cluster 3 open questions for user lock-in

1. **c3-1 (long-term cleanup decisions table §1.1-1.9)**: confirm
   all 25 recommendations, or flip specific rows. (Numbered
   c3-ability-1 through c3-culture-3 inline above.)

2. **c3-2 (header chip table §2)**: confirm or flip specific
   chip sets.

3. **c3-3 (hit-location → single-page mode)**: c3-hitloc-1
   recommends converting hit-location to single-page (it has
   only one content tab today). Confirm?

4. **c3-4 (shared item-skill-row partial)**: confirm
   extracting the skill-row partial for personality + culture
   (+ future career). Alternative is keeping each sheet's row
   markup inline.

5. **c3-5 (new ElysiumSelectLists helpers)**: confirm adding
   `getSpellSaveSkillOptions()` + `getSpellDamageTypeOptions()`.
   These are localized option lists; cleaner than inline `<option>`
   blocks. Used by mysticism + divine.

6. **c3-6 (boolean checkboxes → toggle chips on divine)**:
   c3-divine-4 recommends converting isRitual/isReactive/
   isDamageSpell from native checkboxes to `elysium-item-toggle`
   chips for visual consistency with cluster 2's toggles.
   Confirm?

7. **c3-7 (sub-grouping armor's 13 fields)**: c3-armor-2
   recommends splitting into 4 sub-grids (Protection / Encumbrance /
   Penalties / Power). Alternative is one big grid. Confirm
   sub-grouping?

8. **c3-8 (ship as one large alpha or split)**: 9 items in one
   ship is the biggest cluster yet. Estimated total surface change:
   ~9 sheet rewrites + ~9 template rewrites + 2 new shared partials
   + 1 new header variant + 2 new SelectLists helpers + 20 i18n
   keys + ~150 lines CSS. Likely 2-3 mid-smoke iteration patches.
   **Alternatives**:
   - (A) Single alpha (alpha.40) — biggest ship.
   - (B) Two sub-clusters: 3a = light/medium (ability, hit-location,
     skillcat, mysticism, divine, armor — the standalone sheets),
     3b = heavy (super, personality, culture — the drag/drop
     sheets). Alpha.40 + alpha.41.
   - (C) Three sub-clusters by complexity tier.
   **Recommendation: B** — the drag/drop sheets share enough
   machinery (item-skill-row partial, group controls) that they
   benefit from being shipped together; the 6 standalone sheets
   are independent migrations. Smoke risks are concentrated in
   3b, so isolating it lets 3a clear cleanly first.

## 11. Pre-flight checklist additions for cluster 3+ ships

From cluster 2 lessons:

- [x] CSS brace balance
- [x] Handlebars block balance on all touched templates
- [x] `node --check` on all touched .mjs
- [x] system.json + lang/*.json parse
- [x] Token sweep — every `var(--ely-*)` resolves
- [x] **NEW: i18n key existence sweep** — every static
      `'Elysium.X'` referenced in touched templates AND in touched
      .mjs `game.i18n.localize` calls resolves in `lang/en.json`.

## 12. Ready-to-go checklist

- [x] 9 sheet classes inspected (PARTS, _prepareContext, listener bindings)
- [x] 9 detail templates inspected
- [x] Special features catalogued (drag/drop, custom handlers, dialog usage)
- [x] Legacy class hooks identified (preserve per audit-5 pattern)
- [x] Per-item width plan (audit-3 wide-tier mapping)
- [x] Header chip plan per item
- [x] Cleanup decisions enumerated (25 c3-*-N decisions)
- [x] New shared partial designs (specialism header, item-skill-row)
- [x] New ElysiumSelectLists helper designs
- [x] i18n keys to add (20 new keys)
- [x] Pre-existing bugs flagged (armor field-name, skillcat dead code, severedHint missing)
- [x] Smoke risks enumerated (10 distinct)
- [ ] User decision on 8 cluster-3 open questions
- [ ] Approval to ship cluster 3 (sequencing per c3-8 decision)

---

**Audit posture**: read-only until user locks the 8 open questions.
