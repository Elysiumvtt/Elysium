/**
 * Elysium Actor Extension
 *
 * Adds derived stats and helper methods to actors:
 *   - Action Points pool (and reaction subpool)
 *   - Healing Rate (Mythras)
 *   - Move (from ancestry, modified by fatigue/wounds)
 *   - Effective fatigue level (merged from sources)
 *   - Casting penalty from worn armor
 *   - Armor AP cap enforcement
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
export class ElysiumActorExtension {

  /**
   * Calculate all Elysium derived stats for an actor.
   * Stored in flags.elysium.derived for sheet display and tools.
   */
  static async calculateDerivedStats (actor) {
    if (!actor) return

    const derived = {}

    // Action Points — four-pool model
    derived.actionPoints = this.calculateActionPoints(actor)

    // Healing Rate (Mythras style)
    if (getSetting('enableMythrasHealingRate', true)) {
      derived.healingRate = this.calculateHealingRate(actor)
    }

    // Initiative bonus
    derived.initiative = this.calculateInitiativeBonus(actor)

    // Move (base + modifiers)
    derived.move = this.calculateMove(actor)

    // Casting penalty: as of v0.4.0 this lives in
    // actor.flags['elysium'].modifiers.castingPenalty, populated by AEs
    // sourced from worn armor and active conditions. No derived calc
    // needed here — Foundry's AE engine handles aggregation.

    // Worn armor total AP (with cap) — soft/mail/plate stratum stacking is
    // core to Mythras combat and runs unconditionally.
    derived.wornArmorAP = this.calculateWornArmorAP(actor)

    // PP max from POW
    derived.powerPointsMax = this.calculatePowerPointsMax(actor)

    // Mana max for Wizards (POW + INT)
    // Note: per latest rule, Mana = PP. Kept for legacy/optional toggle.
    derived.manaMax = this.calculateManaMax(actor)

    // Luck Points max from POW (Mythras rule)
    if (getSetting('enableLuckPoints', true)) {
      derived.luckPoints = this.calculateLuckPointsMax(actor)
    }

    // v0.10.3: Damage Modifier (STR+SIZ → dice expression)
    derived.damageModifier = this.calculateDamageModifier(actor)

    // v0.10.3: Experience Modifier / XP Bonus (ceil(INT/2) — Elysium house rule)
    derived.xpBonus = this.calculateExperienceModifier(actor)

    // v0.11.0: Per-stat improvement caps (18 + ancestry mod).
    derived.statCaps = this.calculateStatCaps(actor)

    // Build the update payload
    // Always update the cached derived data
    const update = {
      'flags.elysium.derived': derived
    }

    // Sync runtime pools to derived values so the sheet displays
    // the correct maximums. Preserve current `value` when in combat
    // (only change `value` if it exceeds the new max, or if max was 0).
    if (derived.actionPoints) {
      const currentAP = actor.system?.actionPoints
      const oldMax = currentAP?.max || 0
      const oldVal = currentAP?.value || 0
      const newMax = derived.actionPoints.max || 0
      // If old max was 0 (fresh actor) or current value exceeds new max, sync value to max
      const newVal = (oldMax === 0 || oldVal > newMax) ? newMax : oldVal

      update['system.actionPoints'] = {
        max:          newMax,
        value:        newVal,
        base:         derived.actionPoints.base,
        reactMax:     derived.actionPoints.reactMax,
        reactValue:   derived.actionPoints.reactMax,
        attackMax:    derived.actionPoints.attackMax,
        attackValue:  derived.actionPoints.attackMax,
        defenseMax:   derived.actionPoints.defenseMax,
        defenseValue: derived.actionPoints.defenseMax,
        breakdown:    derived.actionPoints.breakdown,
      }
    }

    // Sync luck points runtime pool — same preserve-value-in-play logic.
    if (derived.luckPoints) {
      const currentLP = actor.system?.luckPoints
      const oldMax = currentLP?.max || 0
      const oldVal = currentLP?.value || 0
      const newMax = derived.luckPoints.max || 0
      // Fresh actor or stale data: sync value to new max.
      // Mid-session: keep current value unless it exceeds new max.
      const newVal = (oldMax === 0 || oldVal > newMax) ? newMax : oldVal

      update['system.luckPoints'] = {
        max:   newMax,
        value: newVal,
      }
    }

    // v0.20.0: Mirror the Mythras damage modifier from derived flags to
    // `system.dmgmodTier` so the combat-roll, charge, and weapon damage paths
    // can read it via the documented schema field. The derived flag remains
    // the source of truth; this is a denormalised write for downstream readers.
    if (derived.damageModifier !== undefined && derived.damageModifier !== null) {
      update['system.dmgmodTier'] = derived.damageModifier
    }

    // Update actor flag without triggering re-render storms
    await actor.update(update, { render: false, diff: false })

    // Note: Hit-location HP is now overridden in prepareDerivedData via
    // the ElysiumMythrasHP patch (actor/mythras-hp.mjs). It runs
    // synchronously every prep cycle, so we don't need to write to DB here.

    return derived
  }

  // === ACTION POINTS ================================================

  static calculateActionPoints (actor) {
    const intVal = this._parseStatTotal(actor.system.stats?.int)
    const dexVal = this._parseStatTotal(actor.system.stats?.dex)
    const sum = intVal + dexVal

    let baseAP = 1
    for (const row of ELYSIUM.AP_TABLE) {
      if (sum >= row.min && sum <= row.max) {
        baseAP = row.ap
        break
      }
    }
    if (sum > 84) baseAP = Math.floor((sum - 84) / 12) + 7

    // If no valid stats yet (fresh actor), still return a sensible structure
    if (sum === 0) {
      return {
        base: 0, max: 0, value: 0,
        reactMax: 0, reactValue: 0,
        attackMax: 0, attackValue: 0,
        defenseMax: 0, defenseValue: 0,
        breakdown: { base: 0 },
      }
    }

    // Active effect group modifiers
    const apMods = this._gatherAPModifiers(actor)

    // Wound penalties (cumulative)
    const woundPen = apMods.wound
    // Spell bonuses (best of)
    const spellBonus = apMods.spellBest
    // Skill bonuses (best of)
    const skillBonus = apMods.skillBest
    // Item slot bonuses (cumulative — based on anatomy)
    const itemBonus = apMods.itemSlots
    // Ancestry (best of)
    const ancestryBonus = apMods.ancestryBest
    // Fatigue penalty
    const fatiguePen = this._fatigueAPPenalty(actor)

    // v0.11.0: User-entered AP bonuses from the CHAR tab. These come
    // from abilities or other sources that grant flat AP bonuses; they
    // stack on top of the active-effect-derived bonuses.
    const proactiveBonus = Number(actor.system?.actionPoints?.mod) || 0
    const reactiveBonus = Number(actor.system?.actionPoints?.reactMod) || 0

    const total = Math.max(1, baseAP + spellBonus + skillBonus + ancestryBonus + itemBonus - woundPen - fatiguePen + proactiveBonus)
    const reactValue = (apMods.reactionPool || 0) + reactiveBonus
    const attackValue = apMods.attackPool || 0
    const defenseValue = apMods.defensePool || 0

    return {
      base:         baseAP,
      max:          total,
      value:        total,
      reactMax:     reactValue,
      reactValue:   reactValue,
      attackMax:    attackValue,
      attackValue:  attackValue,
      defenseMax:   defenseValue,
      defenseValue: defenseValue,
      breakdown: {
        base: baseAP,
        spell: spellBonus,
        skill: skillBonus,
        ancestry: ancestryBonus,
        items: itemBonus,
        wound: -woundPen,
        fatigue: -fatiguePen,
        proactiveBonus,
        reactiveBonus,
        attackPool:  attackValue,
        defensePool: defenseValue,
      }
    }
  }

  static _gatherAPModifiers (actor) {
    const mods = {
      spellBest: 0, skillBest: 0, ancestryBest: 0,
      itemSlots: 0, wound: 0,
      reactionPool: 0, attackPool: 0, defensePool: 0,
    }
    const groups = { spell: [], skill: [], ancestry: [] }

    for (const ae of actor.allApplicableEffects ? actor.allApplicableEffects() : actor.effects) {
      if (ae.disabled) continue
      const apFlag = ae.flags?.['elysium']?.apModifier
      if (!apFlag) continue

      switch (apFlag.group) {
        case 'spell':    groups.spell.push(apFlag.value);    break
        case 'skill':    groups.skill.push(apFlag.value);    break
        case 'ancestry': groups.ancestry.push(apFlag.value); break
        case 'wound':    mods.wound += Math.abs(apFlag.value); break
        case 'item':     mods.itemSlots += apFlag.value;     break
        case 'reaction': mods.reactionPool += apFlag.value;  break
        case 'attack':   mods.attackPool += apFlag.value;    break
        case 'defense':  mods.defensePool += apFlag.value;   break
      }
    }
    if (groups.spell.length)    mods.spellBest    = Math.max(...groups.spell)
    if (groups.skill.length)    mods.skillBest    = Math.max(...groups.skill)
    if (groups.ancestry.length) mods.ancestryBest = Math.max(...groups.ancestry)
    return mods
  }

  static _fatigueAPPenalty (actor) {
    const fatigue = actor.system?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    return fatLevel?.apPenalty || 0
  }

  // === HEALING RATE =================================================

  static calculateHealingRate (actor) {
    const con = this._parseStatTotal(actor.system.stats?.con)
    for (const row of ELYSIUM.HEALING_RATE_TABLE) {
      if (con >= row.min && con <= row.max) return row.rate
    }
    return 1
  }

  // === INITIATIVE ===================================================

  static calculateInitiativeBonus (actor) {
    const intVal = this._parseStatTotal(actor.system.stats?.int)
    const dexVal = this._parseStatTotal(actor.system.stats?.dex)
    const baseBonus = Math.floor((intVal + dexVal) / 2)

    const armorPen = this._calculateArmorPenalty(actor)
    const fatiguePen = this._fatigueInitiativePenalty(actor)

    return baseBonus - armorPen - fatiguePen
  }

  static _fatigueInitiativePenalty (actor) {
    const fatigue = actor.system?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    return Math.abs(fatLevel?.initiativePen || 0)
  }

  // === ARMOR PENALTY ===============================================

  static _calculateArmorPenalty (actor) {
    let totalEnc = 0
    for (const item of actor.items) {
      if (item.type !== 'armor') continue
      if (item.system.equipStatus !== 'equipped') continue
      const material    = item.system.elysium?.material    ?? 'cloth'
      const flexibility = item.system.elysium?.flexibility ?? 'flexible'
      if (material === 'natural') continue
      if (flexibility === 'natural') continue
      totalEnc += item.system.enc || 0
    }
    return Math.ceil(totalEnc / 5)
  }

  // === MOVE =========================================================

  static calculateMove (actor) {
    // Base from ancestry (default 30ft if no ancestry)
    let baseFt = 30

    const ancestry = actor.items.find(i =>
      i.type === 'culture' && i.system?.elysium?.ancestry
    )
    const ancestryData = ancestry?.system?.elysium?.ancestry || null
    if (ancestryData?.baseMove) {
      baseFt = ancestryData.baseMove
    }

    // Wound penalties (cumulative) — only legs reduce move.
    // Hit locations carry an explicit bodyPart designation
    // (system.elysium.bodyPart === 'leg' for legs). We honor side/index
    // implicitly by iterating every leg location and accumulating penalties.
    let flatPenalty = 0
    let multiplier = 1
    for (const item of actor.items) {
      if (item.type !== 'hit-location') continue
      if (item.system?.elysium?.bodyPart !== 'leg') continue

      const curr = item.system.currHP
      const max = item.system.maxHP
      if (max <= 0) continue

      // Severely Wounded leg: -5ft
      if (curr > 0 && curr <= Math.floor(max / 2)) flatPenalty += 5
      // Critically Wounded leg: half move
      if (curr <= 0 && curr > -max) multiplier = Math.min(multiplier, 0.5)
    }

    // Fatigue
    const fatigue = actor.system?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    if (fatLevel?.movePenalty) flatPenalty += Math.abs(fatLevel.movePenalty * 5)
    if (fatLevel?.moveMult !== undefined && fatLevel.moveMult < 1) {
      multiplier = Math.min(multiplier, fatLevel.moveMult)
    }

    const armPen = this._calculateArmorPenalty(actor)
    const finalFt = Math.max(1, Math.round((baseFt - flatPenalty) * multiplier))

    return {
      baseFt:        baseFt,
      currentFt:     finalFt,
      runFt:         Math.max(1, (finalFt * ELYSIUM.MOVEMENT.runMultiplier) - armPen * 5),
      sprintFt:      Math.max(1, (finalFt * ELYSIUM.MOVEMENT.sprintMultiplier) - armPen * 5),
      swimFt:        Math.max(1, Math.ceil(finalFt / 2) - armPen * 5),
      crawlFt:       Math.max(1, Math.floor(finalFt / 4)),
      armorPenalty: armPen,
    }
  }

  // === CASTING PENALTY ==============================================
  // Casting penalty lives in
  //   actor.flags['elysium'].modifiers.castingPenalty
  // populated by Active Effects on worn armor items (see
  // module/elysium/active-effects/item-modifiers.mjs).
  // Authoring rule: when a content author creates an armor piece, they
  // set the `castingPenalty` modifier AE directly on the item via the
  // sheet. v0.20.0 dropped the legacy world-load migration that auto-
  // generated these AEs from the ARMOR_FLEXIBILITY table.

  // === WORN ARMOR AP CAP ===========================================

  static calculateWornArmorAP (actor) {
    // Group worn armor by location, sum AP, enforce cap
    const byLocation = {}
    for (const item of actor.items) {
      if (item.type !== 'armor') continue
      if (item.system.equipStatus !== 'equipped') continue
      const loc = item.system.coverage || 'all'
      const flexibility = item.system.elysium?.flexibility ?? 'flexible'
      const ap = item.system.av1 || 0
      const isNatural = (flexibility === 'natural')

      if (!byLocation[loc]) byLocation[loc] = { worn: 0, natural: 0 }
      if (isNatural) byLocation[loc].natural += ap
      else byLocation[loc].worn += ap
    }

    // Apply cap to worn AP only
    const result = {}
    for (const loc in byLocation) {
      const wornCapped = Math.min(byLocation[loc].worn, ELYSIUM.ARMOR_AP_CAP)
      result[loc] = {
        worn:    byLocation[loc].worn,
        natural: byLocation[loc].natural,
        wornCapped,
        totalAP: wornCapped + byLocation[loc].natural,
      }
    }
    return result
  }

  // === POWER POINTS / MANA ==========================================

  static calculatePowerPointsMax (actor) {
    return this._parseStatTotal(actor.system.stats?.pow)
  }

  /**
   * Calculate Luck Points maximum per Mythras rules (v0.10.3).
   * POW → table: 1 at ≤6, 2 at 7–12, 3 at 13–18, +1 per 6 above.
   * Returns: { max, rate, pow }
   */
  static calculateLuckPointsMax (actor) {
    const pow = this._parseStatTotal(actor.system.stats?.pow)
    if (pow === 0) return { max: 0, rate: 0, pow: 0 }
    let rate = 1
    for (const row of ELYSIUM.LUCK_POINTS_TABLE) {
      if (pow >= row.min && pow <= row.max) { rate = row.rate; break }
    }
    return { max: rate, rate, pow }
  }

  // _powBonus removed in v0.10.3 — Mythras uses the simple table form.

  /**
   * Damage Modifier per Mythras (v0.10.3).
   * Indexed by STR+SIZ on DAMAGE_MOD_TABLE. Returns the dice expression
   * string (e.g. "+1d4", "-1d2", "+0", "+2d10+1d4").
   *
   * Beyond 130 the source says "Continue Progression"; for now we cap at
   * the highest table entry. Most player-tier characters never reach 131.
   */
  static calculateDamageModifier (actor) {
    const str = this._parseStatTotal(actor.system.stats?.str)
    const siz = this._parseStatTotal(actor.system.stats?.siz)
    const sum = str + siz
    if (sum === 0) return '+0'
    for (const row of ELYSIUM.DAMAGE_MOD_TABLE) {
      if (sum >= row.min && sum <= row.max) return row.dice
    }
    // Above 130: stay on the last entry until "Continue Progression"
    // is implemented. Marked TODO in DAMAGE_MOD_TABLE comment.
    const last = ELYSIUM.DAMAGE_MOD_TABLE[ELYSIUM.DAMAGE_MOD_TABLE.length - 1]
    return last.dice
  }

  /**
   * v0.20.0: Scale a damage-mod dice tier by a multiplier, walking the
   * canonical DAMAGE_MOD_TABLE by index.
   *
   * Algorithm: find the index of `tierString` in the table, multiply by
   * `multiplier`, round to the nearest integer index, clamp to the table
   * bounds, and return the dice expression at the resulting index.
   *
   * Examples (assuming the +0 tier is at index N):
   *   - scaleDamageModByMultiplier('+1d6',  1.0) → '+1d6'   (no change)
   *   - scaleDamageModByMultiplier('+1d6',  0.5) → roughly the midpoint
   *                                                between '+0' and '+1d6'
   *   - scaleDamageModByMultiplier('+1d6',  0.0) → '+0'
   *   - scaleDamageModByMultiplier('+1d6',  2.0) → doubled steps from '+0'
   *
   * The math operates on table INDEX rather than the dice formula itself
   * because the table's progression isn't linearly multiplicative — it
   * goes -1d6 → -1d4 → -1d2 → +0 → +1d2 → +1d4 → +1d6 → +1d8 → +1d10 → +1d12
   * with deliberately non-uniform spacing.
   */
  static scaleDamageModByMultiplier (tierString, multiplier) {
    const table = ELYSIUM.DAMAGE_MOD_TABLE
    const m = Number(multiplier)
    if (!isFinite(m)) return tierString
    if (m === 1.0) return tierString

    // Find the "neutral" (+0) row's index. We'll measure distance from there.
    let neutralIdx = table.findIndex(r => r.dice === '+0')
    if (neutralIdx < 0) neutralIdx = 0

    // Find the row matching the input tier.
    const baseIdx = table.findIndex(r => r.dice === tierString)
    if (baseIdx < 0) {
      // Fall back: if we can't find it, treat as neutral.
      return tierString
    }

    // Scale the offset from neutral, then add back to neutral.
    const stepsFromNeutral = baseIdx - neutralIdx
    const scaledSteps = Math.round(stepsFromNeutral * m)
    let resultIdx = neutralIdx + scaledSteps

    // Clamp to table bounds.
    resultIdx = Math.max(0, Math.min(table.length - 1, resultIdx))
    return table[resultIdx].dice
  }

  /**
   * Experience Modifier (XP Bonus) — Elysium house rule (v0.10.3).
   * Formula: ceil(INT / 2). Used as a percentile bonus to the
   * skill-improvement roll. Higher values = better chance to roll
   * over the current skill, which triggers a dice-improvement (1d4+1
   * by default, 1d6 with the Fast Learner ability — that's a future
   * feature; for now just the base modifier is computed).
   * Returns an integer percentage (e.g. 8 means +8%).
   */
  static calculateExperienceModifier (actor) {
    const int = this._parseStatTotal(actor.system.stats?.int)
    return Math.ceil(int / 2)
  }

  /**
   * v0.11.0: Compute per-stat improvement caps.
   *
   * Cap formula: 18 + ancestry modifier. The ancestry mod lives on
   * `system.stats.<key>.culture` (already populated by ancestry-application
   * code on actor-prep). A stat at or above its cap requires GM approval
   * to push beyond, handled via the at-cap chat-card flow.
   *
   * Returns an object keyed by stat: { str: 18, con: 20, ... }
   */
  static calculateStatCaps (actor) {
    const caps = {}
    const stats = actor.system?.stats ?? {}
    for (const key of ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha']) {
      const ancestryMod = Number(stats[key]?.culture) || 0
      caps[key] = 18 + ancestryMod
    }
    return caps
  }

  // === MYTHRAS HIT LOCATION HP =====================================

  /**
   * Compute Mythras hit-location HP based on CON + SIZ.
   *
   * Mythras formula:
   *   base = ceil((CON + SIZ) / 5)
   *   Leg     = base
   *   Abdomen = base + 1
   *   Chest   = base + 2
   *   Arm     = max(1, base - 1)
   *   Head    = base
   *   Tail    = base
   *   Wing    = max(1, base - 1)
   *
   * Returned object keys correspond to hit-location item `system.locType`.
   * Custom locations not matching these keys fall back to 'base'.
   *
   * Returns: { base, leg, abdomen, body, chest, arm, head, tail, wing, limb }
   */
  static calculateMythrasHitLocationHP (actor) {
    const con = this._parseStatTotal(actor.system.stats?.con)
    const siz = this._parseStatTotal(actor.system.stats?.siz)
    if (con === 0 && siz === 0) {
      return { base: 0, leg: 0, abdomen: 0, body: 0, chest: 0, arm: 0, head: 0, tail: 0, wing: 0, limb: 0 }
    }
    const base = Math.max(1, Math.ceil((con + siz) / 5))
    return {
      base,
      leg:     base,
      abdomen: base + 1,
      body:    base + 1,    // BRP sometimes uses 'body' for abdomen
      chest:   base + 2,
      arm:     Math.max(1, base - 1),
      head:    base,
      tail:    base,
      wing:    Math.max(1, base - 1),
      limb:    Math.max(1, base - 1),    // generic limb fallback
    }
  }

  /**
   * Apply Mythras hit-location HP to every hit-location item on the actor.
   * Call this whenever CON, SIZ, or hit-location items change.
   *
   * Strategy:
   *   - Compute new maxHP from Mythras formula
   *   - Preserve wounds: damage = oldMax - oldCurrHP; newCurrHP = newMax - damage
   *   - If location is fresh (currHP === maxHP === 0 from creation), set to full
   */
  static async applyMythrasHitLocationHP (actor) {
    if (!actor?.items?.size) return
    const hpTable = this.calculateMythrasHitLocationHP(actor)
    if (hpTable.base === 0) return    // no stats yet

    const updates = []
    for (const item of actor.items.contents) {
      if (item.type !== 'hit-location') continue

      const locType = item.system?.locType || 'limb'
      const newMax = hpTable[locType] ?? hpTable.base
      const oldMax = item.system?.maxHP || 0
      const oldCurr = item.system?.currHP || 0

      // Preserve damage taken (oldMax - oldCurr).
      // If max increased, currHP heals proportionally.
      // If currHP and maxHP both 0 (fresh), set currHP to newMax.
      let newCurr
      if (oldMax === 0) {
        newCurr = newMax
      } else {
        const damage = Math.max(0, oldMax - oldCurr)
        newCurr = Math.max(0, newMax - damage)
      }

      if (oldMax === newMax && oldCurr === newCurr) continue    // no change

      updates.push({
        _id: item.id,
        'system.maxHP':  newMax,
        'system.currHP': newCurr,
      })
    }
    if (updates.length > 0) {
      await actor.updateEmbeddedDocuments('Item', updates, { render: false })
    }
  }

  static calculateManaMax (actor) {
    // Used only if a setting later distinguishes — currently same as PP
    const pow = this._parseStatTotal(actor.system.stats?.pow)
    const intVal = this._parseStatTotal(actor.system.stats?.int)
    return pow + intVal
  }

  // === ARMOR VALIDATION ============================================

  /**
   * Called on item drop. Template.json provides system.elysium defaults
   * (flexibility, material, layerOrder, apMax), so this is currently
   * a no-op kept for future per-item validation hooks (stratum sanity
   * checks, etc.).
   */
  static async validateArmorLayer (item) {
    return true
  }

  // === HELPERS ======================================================

  static _parseStatTotal (statBlock) {
    if (!statBlock) return 0

    // Prefer BRP-base pre-computed total if available — it's authoritative
    if (typeof statBlock.total === 'number' && !isNaN(statBlock.total)) {
      return statBlock.total
    }

    // Fallback: reconstruct from individual fields
    // BRP-base stores stat as an object with base/redist/culture/exp/age/effects
    let total = 0
    total += Number(statBlock.base    ?? 0) || 0
    total += Number(statBlock.redist  ?? 0) || 0
    total += Number(statBlock.culture ?? 0) || 0
    total += Number(statBlock.exp     ?? 0) || 0
    total += Number(statBlock.age     ?? 0) || 0
    total += Number(statBlock.effects ?? 0) || 0
    return total
  }

  /**
   * Verify and refresh derived stats on every world actor. Called from
   * the ready hook to cover actors that were loaded before init ran.
   *
   * No data migration is performed — fresh-world only design (v0.20.0+).
   */
  static async verifyAllActors () {
    if (!game.actors) return
    for (const actor of game.actors.contents) {
      const stats = actor.system?.stats
      const hasStats = stats && Object.values(stats).some(s =>
        typeof s?.total === 'number' && s.total > 0
      )
      if (hasStats) {
        await this.calculateDerivedStats(actor)
      }
    }
  }
}
