const SETTINGS = {

  itemElysiumID: {
    name: "Elysium.Settings.itemElysiumID",
    hint: "Elysium.Settings.itemElysiumIDHint",
    scope: "world",
    config: false,
    type: Boolean,
    default: false
  },

  firstAidElysiumID: {
    name: "Elysium.Settings.firstAidElysiumID",
    hint: "Elysium.Settings.firstAidElysiumIDHint",
    scope: "world",
    config: false,
    type: String,
    default: "i.skill.first-aid"
  },

}

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api
export class ElysiumIDSettings extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'rulesmenu'],
    id: 'char-settings',
    actions: {
      reset: ElysiumIDSettings.onResetDefaults,
    },
    form: {
      handler: ElysiumIDSettings.formHandler,
      closeOnSubmit: true,
      submitOnChange: false
    },
    position: {
      width: 550,
      height: 'auto',
    },
    tag: 'form',
    window: {
      resizable: true,
      title: 'Elysium.systemSettings',
      contentClasses: ["standard-form"]
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/settings/elysiumid-settings.hbs',
            scrollable: ['']
     },
    footer: { template: 'templates/generic/form-footer.hbs' }
  }

  async _prepareContext(options) {
    const isGM = game.user.isGM;
    const optSet = {}
    for (const [k, v] of Object.entries(SETTINGS)) {
      optSet[k] = {
        value: game.settings.get('elysium', k),
        setting: v
      }
    }
    return {
      isGM,
      optSet,
      buttons: [
        { type: "submit", icon: "fa-solid fa-save", label: "SETTINGS.Save" },
        { type: "reset", action: "reset", icon: "fa-solid fa-undo", label: "SETTINGS.Reset" },
      ]
    }
  }

  static registerSettings() {
    for (const [k, v] of Object.entries(SETTINGS)) {
      game.settings.register('elysium', k, v)
    }
  }

  static async onResetDefaults(event) {
    event.preventDefault()
    for await (const [k, v] of Object.entries(SETTINGS)) {
      await game.settings.set('elysium', k, v?.default)
    }
    return this.render()
  }

  static async formHandler(event, form, formData) {
    const settings = foundry.utils.expandObject(formData.object)
    await Promise.all(
      Object.entries(settings)
        .map(([key, value]) => game.settings.set("elysium", key, value))
    )
  }

}
