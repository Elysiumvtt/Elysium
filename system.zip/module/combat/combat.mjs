export class ElysiumCombat extends Combat {

  async nextRound() {
    if (game.settings.get('elysium', 'initRound') !== 'no') {
      await this.resetAll();
    }
    if (game.settings.get('elysium', 'initRound') === 'auto') {
      await this.rollAll();
      await this.setupTurns();
    }
    super.nextRound()
  }

}
