#!/usr/bin/env node
/**
 * Elysium Visual Regression Harness — Diff
 * --------------------------------------------------------------------------
 * Compare a captured snapshot against a baseline snapshot. Reports semantic
 * differences in a human-readable form.
 *
 * Usage:
 *
 *   node test/visual-regression/diff.mjs \
 *       test/visual-regression/baseline/character-empty.snapshot.json \
 *       captured.snapshot.json
 *
 * Or programmatically:
 *
 *   import { diffSnapshots } from './diff.mjs'
 *   const result = diffSnapshots(baselineJson, capturedJson)
 *   if (result.hasChanges) console.log(formatDiff(result))
 *
 * Exit codes:
 *   0 — snapshots match (no semantic changes)
 *   1 — semantic differences found
 *   2 — argument or file error
 *
 * The diff tool is INTENTIONALLY noisy about marker presence: a marker that
 * was present in baseline but absent in capture (or vice versa) is reported
 * loudly because it usually means a selector changed and that's a structural
 * regression worth noticing.
 * --------------------------------------------------------------------------
 */

import fs from 'fs'
import path from 'path'


/**
 * Compare two snapshots. Returns:
 *   {
 *     hasChanges: bool,
 *     summary: { totalDiffs, byCategory: {tokens: N, markers: N, target: N} },
 *     details: [
 *       { category, label, kind: 'changed'|'added'|'removed', baseline, captured }
 *     ]
 *   }
 *
 * `outerHTML` is intentionally NOT diffed by this tool — the marker
 * granular diff captures everything we care about, and full-HTML diffs
 * are too noisy (whitespace, dynamic ids, etc.). If you want a coarse
 * HTML diff, write a separate tool.
 */
export function diffSnapshots (baseline, captured) {
  const details = []

  // ============ Target identity ============
  // Different sheet target = "you compared apples to oranges"
  if (baseline.target?.kind !== captured.target?.kind) {
    details.push({
      category: 'target',
      label: 'kind',
      kind: 'changed',
      baseline: baseline.target?.kind,
      captured: captured.target?.kind,
    })
  }
  if (baseline.target?.docType !== captured.target?.docType) {
    details.push({
      category: 'target',
      label: 'docType',
      kind: 'changed',
      baseline: baseline.target?.docType,
      captured: captured.target?.docType,
    })
  }

  // ============ Tokens ============
  const allTokens = new Set([
    ...Object.keys(baseline.tokens ?? {}),
    ...Object.keys(captured.tokens ?? {}),
  ])
  for (const name of allTokens) {
    const b = baseline.tokens?.[name]
    const c = captured.tokens?.[name]
    if (b === c) continue
    if (b === undefined || b === '') {
      details.push({ category: 'tokens', label: name, kind: 'added', baseline: null, captured: c })
    } else if (c === undefined || c === '') {
      details.push({ category: 'tokens', label: name, kind: 'removed', baseline: b, captured: null })
    } else {
      details.push({ category: 'tokens', label: name, kind: 'changed', baseline: b, captured: c })
    }
  }

  // ============ Markers ============
  const baselineMarkersByLabel = new Map(
    (baseline.markers ?? []).filter(m => m).map(m => [m.label, m])
  )
  const capturedMarkersByLabel = new Map(
    (captured.markers ?? []).filter(m => m).map(m => [m.label, m])
  )

  // Markers present in baseline but missing in captured
  for (const [label, baselineMarker] of baselineMarkersByLabel) {
    if (!capturedMarkersByLabel.has(label)) {
      details.push({
        category: 'markers',
        label,
        kind: 'removed',
        baseline: { tag: baselineMarker.tag, classes: baselineMarker.classes },
        captured: null,
      })
    }
  }

  // Markers present in captured but missing in baseline
  for (const [label, capturedMarker] of capturedMarkersByLabel) {
    if (!baselineMarkersByLabel.has(label)) {
      details.push({
        category: 'markers',
        label,
        kind: 'added',
        baseline: null,
        captured: { tag: capturedMarker.tag, classes: capturedMarker.classes },
      })
    }
  }

  // Markers present in both — compare every property
  for (const [label, baselineMarker] of baselineMarkersByLabel) {
    const capturedMarker = capturedMarkersByLabel.get(label)
    if (!capturedMarker) continue

    // Tag changes (e.g. div → span) are structural and noteworthy
    if (baselineMarker.tag !== capturedMarker.tag) {
      details.push({
        category: 'markers',
        label: `${label}.tag`,
        kind: 'changed',
        baseline: baselineMarker.tag,
        captured: capturedMarker.tag,
      })
    }

    // Class-list changes — also report
    const bcs = (baselineMarker.classes ?? []).join(' ')
    const ccs = (capturedMarker.classes ?? []).join(' ')
    if (bcs !== ccs) {
      details.push({
        category: 'markers',
        label: `${label}.classes`,
        kind: 'changed',
        baseline: baselineMarker.classes,
        captured: capturedMarker.classes,
      })
    }

    // Each property in the marker (ignore standard fields)
    const skip = new Set(['label', 'selector', 'tag', 'classes'])
    const props = new Set([
      ...Object.keys(baselineMarker),
      ...Object.keys(capturedMarker),
    ].filter(k => !skip.has(k)))

    for (const prop of props) {
      const b = baselineMarker[prop]
      const c = capturedMarker[prop]
      if (b === c) continue
      details.push({
        category: 'markers',
        label: `${label}.${prop}`,
        kind: 'changed',
        baseline: b,
        captured: c,
      })
    }
  }

  // Summary
  const byCategory = { tokens: 0, markers: 0, target: 0 }
  for (const d of details) byCategory[d.category] = (byCategory[d.category] ?? 0) + 1

  return {
    hasChanges: details.length > 0,
    summary: {
      totalDiffs: details.length,
      byCategory,
    },
    details,
  }
}


/**
 * Format diff result as a human-readable string.
 */
export function formatDiff (result) {
  if (!result.hasChanges) return '✓ no changes'

  const lines = []
  lines.push(`✗ ${result.summary.totalDiffs} change${result.summary.totalDiffs === 1 ? '' : 's'} detected`)
  lines.push(`  by category: tokens=${result.summary.byCategory.tokens}, markers=${result.summary.byCategory.markers}, target=${result.summary.byCategory.target}`)
  lines.push('')

  // Group by category for readability
  const byCategory = {}
  for (const d of result.details) {
    if (!byCategory[d.category]) byCategory[d.category] = []
    byCategory[d.category].push(d)
  }

  const order = ['target', 'tokens', 'markers']
  for (const cat of order) {
    const items = byCategory[cat]
    if (!items?.length) continue
    lines.push(`── ${cat} ──`)
    for (const d of items) {
      const arrow = d.kind === 'added' ? '+ ' : d.kind === 'removed' ? '- ' : '~ '
      const b = formatValue(d.baseline)
      const c = formatValue(d.captured)
      if (d.kind === 'added') {
        lines.push(`  ${arrow}${d.label}: ${c}`)
      } else if (d.kind === 'removed') {
        lines.push(`  ${arrow}${d.label}: ${b}  (was; now absent)`)
      } else {
        lines.push(`  ${arrow}${d.label}: ${b}  →  ${c}`)
      }
    }
    lines.push('')
  }

  return lines.join('\n')
}

function formatValue (v) {
  if (v === null || v === undefined) return '∅'
  if (Array.isArray(v)) return `[${v.join(', ')}]`
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}


/* ============================================================================
 * CLI
 * ============================================================================ */

// Cross-platform main detection (works with file:// import.meta.url)
const argv1Resolved = process.argv[1] ? path.resolve(process.argv[1]) : ''
const thisFile = new URL(import.meta.url).pathname
if (argv1Resolved === path.resolve(thisFile)) {
  const [, , baselineArg, capturedArg] = process.argv
  if (!baselineArg || !capturedArg) {
    console.error('usage: diff.mjs <baseline.snapshot.json> <captured.snapshot.json>')
    process.exit(2)
  }

  let baseline, captured
  try {
    baseline = JSON.parse(fs.readFileSync(baselineArg, 'utf8'))
    captured = JSON.parse(fs.readFileSync(capturedArg, 'utf8'))
  } catch (e) {
    console.error(`error reading snapshots: ${e.message}`)
    process.exit(2)
  }

  const result = diffSnapshots(baseline, captured)
  console.log(formatDiff(result))
  process.exit(result.hasChanges ? 1 : 0)
}
