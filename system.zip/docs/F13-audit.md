# F13 Audit — Legacy DOM-traversal anti-pattern in roll handlers

**Surfaced during**: rc.5 install live-verify, console error sweep (66+ exceptions captured)

**Severity**: HIGH (every roll-from-sheet UI click broken on V1.0.0 sheets)

**Pattern**: `event.target.closest('.item').dataset.itemId` (and variants). The `.closest('.item')` traversal returns `null` because V1.0.0 templates don't emit `class="item"` wrappers anymore — they emit semantic wrappers like `elysium-allegiance-row`, `elysium-weapon-row`, etc. The handler then throws `TypeError: Cannot read properties of null (reading 'dataset')`.

## Why latent for 17 alphas + 5 RCs

Same methodology gap as F12:
1. **alpha.37** introduced the consolidated magic-tab; the new templates emitted `data-action="X"` on inner elements with `data-item-id` on row wrappers (no `.item` class)
2. **rollType.mjs handlers were never updated** to match the new DOM structure
3. **No live-verify pass ever clicked a roll** on the new sheet — every regression test used API-level calls (`game.system.api.elysium.fatigue.increment(...)`, etc.)
4. The exceptions were silent from a user-functionality perspective (click does nothing visible) but logged to console — only surfaced because rc.5 live-verify happened to enumerate all console errors

## Full F13 scope inventory

### `module/apps/rollType.mjs` — 10 sites, all using `event.target.closest('.item').dataset.itemId`

| Line | Handler | Action name | Triggering template | Status |
|---|---|---|---|---|
| L58 | `_onSkillRoll` | `skillRoll` | left-rail-skills, magic-skill-summary, right-rail-senses, divine-body | **BROKEN** |
| L78 | `_onAllegianceRoll` | `allegianceRoll` | allegiance-row | **BROKEN** |
| L98 | `_onPassionRoll` | `passionRoll` | passion-row | **BROKEN** |
| L119 | `_onReputationRoll` | `reputationRoll` | reputation-row | **BROKEN** |
| L140 | `_onPersTraitRoll` | `personalityRoll` | pers-trait-row | **BROKEN** |
| L159 | `_onDamageRoll` | `damageRoll` | weapon-row | **BROKEN** |
| L172 | `_onImpactRoll` | `impactRoll` | (only legacy mysticism-body) | Legacy-only (low priority) |
| L185 | `_onWeaponRoll` (itemId) | `weaponRoll` | weapon-row | **BROKEN** |
| L186 | `_onWeaponRoll` (skillId) | `weaponRoll` | weapon-row | **BROKEN** (uses .skillId instead of .itemId) |
| L230 | `_onArmor` (nap case) | `armorRoll` | hit-location-row | **BROKEN** |

### `module/actor/sheets/base-actor-sheet.mjs` — 2 sites

| Line | Handler | Action name | Triggering template | Status |
|---|---|---|---|---|
| L649 | `_onXPRolls` | `xpRolls` (single) | character.dev | **BROKEN** |
| L1003 | `skillInline` | (change listener) | arcane-body / mysticism-body magic-grid dev mode + NPCv2 | Legacy-only (kept) |

### `module/actor/sheets/base-actor-sheet.mjs` — 4 bio-section sites at L984/L1050/L1059/L1071

These use `.closest('.bio-section').dataset.index` — but `bio-section` class IS still emitted in `story-section.hbs:L42`. **NOT broken.** Documented as v1.1.0 c1 Item 7 (legacy class listeners pending migration to V14 action handlers).

## Templates: the two data-id placement patterns

The new V14 templates use two patterns. Both fixes must handle both:

### Pattern A — data ON the clicked element

```hbs
<a class="elysium-skill-name"
   data-action="skillRoll"
   data-skill-id="{{skill.id}}">
  {{skill.name}}
</a>
```

Fix: read directly from `target.dataset.skillId` (the `target` parameter is the clicked element; the dataset is already exposed as `detail` by base-actor-sheet).

Templates: `left-rail-skills.hbs`, `right-rail-senses.hbs`, `pers-trait-row.hbs`.

### Pattern B — data on row wrapper, action on inner element

```hbs
<div class="elysium-allegiance-row"
     data-item-id="{{allegiance._id}}"
     data-document-class="Item"
     data-drag="true">
  ...
  <a class="elysium-allegiance-row-total elysium-rollable"
     data-action="allegianceRoll">
    {{allegiance.system.total}}%
  </a>
</div>
```

Fix: walk up to find the row wrapper using attribute selector `[data-item-id]` (NOT class selector `.item`, since the v1.0.0 wrappers use semantic class names).

Templates: `allegiance-row.hbs`, `passion-row.hbs`, `reputation-row.hbs`, `weapon-row.hbs`, `hit-location-row.hbs`, `magic-skill-summary.hbs`, `divine-body.hbs`, `pers-trait-row.hbs` (partially — has data on both), `character.dev.hbs` (dev-row).

## Proposed fix

A small ID-resolution helper that handles both patterns:

```js
// At top of rollType.mjs:
function resolveTargetItemId(event, detail, ...attrs) {
  // attrs are dataset property names in priority order, e.g. 'itemId', 'skillId'
  for (const attr of attrs) {
    if (detail?.[attr]) return detail[attr];
  }
  // Fallback: walk up to find the row wrapper carrying any of the target attrs
  const sel = attrs.map(a => `[data-${a.replace(/[A-Z]/g, m => '-' + m.toLowerCase())}]`).join(', ');
  const wrapper = event.target.closest(sel);
  if (!wrapper) return null;
  for (const attr of attrs) {
    if (wrapper.dataset[attr]) return wrapper.dataset[attr];
  }
  return null;
}
```

Then each handler call site becomes:

```js
// Before:
const skillId = event.target.closest('.item').dataset.itemId;

// After:
const skillId = resolveTargetItemId(event, detail, 'skillId', 'itemId');
```

For weaponRoll which reads both itemId and skillId:

```js
const itemId = resolveTargetItemId(event, detail, 'itemId');
const skillId = resolveTargetItemId(event, detail, 'skillId');
```

### Why this pattern (not just `detail.X`)

A simpler "just read `detail.X`" fix works only for Pattern A (data on clicked element). For Pattern B (data on row wrapper), `detail` only contains the clicked element's dataset, which won't have the item ID. The helper covers both. It's also safe against null (returns null instead of throwing).

### Why a helper (not inline at each site)

10 sites, all the same logic. A helper:
1. DRY — single place to fix if pattern changes again
2. Null-safe — no more throws from missing wrapper
3. Explicit — `resolveTargetItemId(event, detail, 'skillId', 'itemId')` documents the lookup priority
4. Same character count as the original line at call sites

## Sites to fix in rc.6

| File | Lines | Fix |
|---|---|---|
| `module/apps/rollType.mjs` | top of file | Add `resolveTargetItemId` helper |
| `module/apps/rollType.mjs` | L58 (`_onSkillRoll`) | `resolveTargetItemId(event, detail, 'skillId', 'itemId')` |
| `module/apps/rollType.mjs` | L78 (`_onAllegianceRoll`) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/apps/rollType.mjs` | L98 (`_onPassionRoll`) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/apps/rollType.mjs` | L119 (`_onReputationRoll`) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/apps/rollType.mjs` | L140 (`_onPersTraitRoll`) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/apps/rollType.mjs` | L159 (`_onDamageRoll`) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/apps/rollType.mjs` | L172 (`_onImpactRoll`) | `resolveTargetItemId(event, detail, 'itemId')` (legacy mysticism-body, low priority but easy to fix) |
| `module/apps/rollType.mjs` | L185-186 (`_onWeaponRoll`) | itemId + skillId resolved separately |
| `module/apps/rollType.mjs` | L230 (`_onArmor` nap case) | `resolveTargetItemId(event, detail, 'itemId')` |
| `module/actor/sheets/base-actor-sheet.mjs` | L649 (`_onXPRolls`) | Same pattern: walk up to `[data-item-id]` row wrapper; also read `data-opp` from wrapper |

## Sites left alone (not broken)

- `module/actor/sheets/base-actor-sheet.mjs` L984/L1050/L1059/L1071 — `.closest('.bio-section')` works (bio-section class is emitted in story-section.hbs); pending v1.1.0 c1 Item 7
- `module/actor/sheets/base-actor-sheet.mjs` L1003 — `skillInline` works in unlocked-mode magic-grid + NPCv2 contexts (the only contexts that wire it); pending v1.1.0 magic-grid-redesign

## v1.1.0 acceptance-pass methodology update

This finding (and F12 before it) confirms a systemic gap: **bridge acceptance passes have been API-level only, never UI-event level.** v1.1.0 acceptance methodology must include:

1. **Click every action-handler from the new sheet** — at minimum once per registered action in `base-actor-sheet.mjs:actions{}` (current count: ~50 actions)
2. **Verify each action produces the expected chat card / state change** (not just that it doesn't throw)
3. **Repeat with multi-discipline characters** (F12 lesson) — at least 2 magic disciplines configured
4. **Console error sweep mandatory** at end of every acceptance pass — not just "0 errors during render" but "0 errors after exercising every action"

This is documented as a v1.1.0 c1 sub-task (no code change — acceptance-pass discipline). Tracked here for visibility.

## Fix complexity assessment

**Code complexity**: LOW. 10 sites all converge on the same pattern. Helper is ~15 LOC.

**Testing complexity**: MEDIUM. Each affected handler needs a live UI click test:
- skillRoll: click a skill in left-rail-skills, magic-skill-summary, divine-body, right-rail-senses → 4 separate test points
- allegianceRoll, passionRoll, reputationRoll, personalityRoll: need fixture characters with those items
- weaponRoll, damageRoll: need a character with an equipped weapon
- armorRoll (nap): need a hit-location with apRnd > 0
- impactRoll: only triggered from unlocked-mode mysticism-body (low priority)
- xpRolls (single): needs items marked for improvement in dev tab

Total: ~8-10 distinct manual UI click verifications.

**Risk**: LOW. The fix is additive (helper + 11 site updates). No structural changes. Existing legacy contexts (NPCv2, character.statistics tab) continue to work because they emit `.item` class which still matches the `.closest('[data-item-id]')` pattern in the helper.
