import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfaceDrawingToggle extends ElysiumCanvasInterface {
  static get PERMISSIONS () {
    return {
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.INHERIT]: 'OWNERSHIP.INHERIT',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE]: 'OWNERSHIP.NONE',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED]: 'OWNERSHIP.LIMITED',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER]: 'OWNERSHIP.OBSERVER',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER]: 'OWNERSHIP.OWNER'
    }
  }

  static get icon () {
    return 'fa-solid fa-pencil'
  }

  static get triggerButtons () {
    const buttons = super.triggerButtons
    buttons[ElysiumCanvasInterfaceDrawingToggle.triggerButton.Both] = 'Elysium.ElysiumCanvasInterface.Buttons.Both'
    return buttons
  }

  static get triggerButton () {
    const button = super.triggerButton
    button.Both = 20
    return button
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterfaceDrawingToggle.triggerButtons,
        initial: ElysiumCanvasInterfaceDrawingToggle.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Button.Hint'
      }),
      action: new fields.NumberField({
        choices: ElysiumCanvasInterface.actionToggles,
        initial: ElysiumCanvasInterface.actionToggle.Off,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Action.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Action.Hint',
        required: true
      }),
      drawingUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'Drawing'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Drawing.Title',
          hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Drawing.Hint'
        }
      ),
      journalEntryUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'JournalEntry'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.JournalEntry.Title',
          hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.JournalEntry.Hint'
        }
      ),
      permissionDocument: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionDocument.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionDocument.Hint',
        required: true
      }),
      permissionDocumentHide: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionDocumentHide.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionDocumentHide.Hint',
        required: true
      }),
      journalEntryPageUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'JournalEntryPage'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.JournalEntryPage.Title',
          hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.JournalEntryPage.Hint'
        }
      ),
      permissionPage: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionPage.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionPage.Hint',
        required: true
      }),
      permissionPageHide: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceDrawingToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionPageHide.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.PermissionPageHide.Hint',
        required: true
      }),
      regionBehaviorUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'RegionBehavior'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.RegionBehavior.Title',
          hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.RegionBehavior.Hint'
        }
      ),
      regionButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Right,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerButton.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerButton.Hint'
      }),
      regionUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'Region'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerRegionUuids.Title',
          hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerRegionUuids.Hint'
        }
      ),
      triggerAsButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerAsButton.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.TriggerAsButton.Hint'
      }),
    }
  }

  static migrateData (source) {
    if (typeof source.triggerButton === 'undefined' && source.regionUuids?.length) {
      source.triggerButton = ElysiumCanvasInterfaceDrawingToggle.triggerButton.Both
    }
    if (typeof source.toggle !== 'undefined' && typeof source.action === 'undefined') {
      source.action = (source.toggle ? ElysiumCanvasInterface.actionToggle.On : ElysiumCanvasInterface.actionToggle.Off)
    }
    return source
  }

  async _handleMouseOverEvent () {
    return game.user.isGM
  }

  async #handleClickEvent (button) {
    let toggle = false
    switch (this.action) {
      case ElysiumCanvasInterface.actionToggle.On:
        toggle = true
        break
      case ElysiumCanvasInterface.actionToggle.Toggle:
        {
          const firstUuid = this.drawingUuids.first()
          if (firstUuid) {
            const doc = await fromUuid(firstUuid)
            toggle = doc.hidden
          }
        }
        break
    }
    for (const uuid of this.drawingUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ hidden: !toggle })
      } else {
        console.error('Drawing ' + uuid + ' not loaded')
      }
    }
    const permissionDocument = (!toggle ? this.permissionDocumentHide : this.permissionDocument)
    const permissionPage = (!toggle ? this.permissionPageHide : this.permissionPage)
    for (const uuid of this.journalEntryUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ 'ownership.default': permissionDocument })
      } else {
        console.error('Journal Entry ' + uuid + ' not loaded')
      }
    }
    for (const uuid of this.journalEntryPageUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ 'ownership.default': permissionPage })
      } else {
        console.error('Journal Entry Page ' + uuid + ' not loaded')
      }
    }
    for (const uuid of this.regionBehaviorUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ disabled: !toggle })
      } else {
        console.error('Region Behavior ' + uuid + ' not loaded')
      }
    }
    if (this.triggerButton === ElysiumCanvasInterfaceDrawingToggle.triggerButton.Both) {
      for (const uuid of this.regionUuids) {
        setTimeout(() => {
          if (button === this.regionButton) {
            if (this.triggerAsButton === ElysiumCanvasInterface.triggerButton.Right) {
              game.elysium.ClickRegionRightUuid(uuid)
            } else if (this.triggerAsButton === ElysiumCanvasInterface.triggerButton.Left) {
              game.elysium.ClickRegionLeftUuid(uuid)
            }
          }
        }, 100)
      }
    }
  }

  async _handleLeftClickEvent () {
    if ([ElysiumCanvasInterfaceDrawingToggle.triggerButton.Both, ElysiumCanvasInterface.triggerButton.Left].includes(this.triggerButton)) {
      this.#handleClickEvent(ElysiumCanvasInterface.triggerButton.Left)
    }
  }

  async _handleRightClickEvent () {
    if ([ElysiumCanvasInterfaceDrawingToggle.triggerButton.Both, ElysiumCanvasInterface.triggerButton.Right].includes(this.triggerButton)) {
      this.#handleClickEvent(ElysiumCanvasInterface.triggerButton.Right)
    }
  }
}
