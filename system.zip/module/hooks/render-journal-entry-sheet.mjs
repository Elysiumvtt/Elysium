import { ElysiumIDEditor } from '../elysiumid/elysiumid-editor.mjs'
export default function (application, element, context, options) {

  ElysiumIDEditor.addElysiumIDSheetHeaderButton(application, element)

  // Direct flag reads — 'elysium' is no longer an active flag scope post-system-id
  // rename, so getFlag('elysium', ...) would throw. Property access works because
  // it bypasses Foundry's scope validator while preserving the data namespace
  // (which is intentionally kept for compatibility with adventure content).
  if ((application.document.flags?.elysium?.['css-adventure-entry'] ?? false)) {
    if (!element.classList.contains('css-adventure-entry')) {
      element.classList.add('css-adventure-entry')
    }
    //Force to use themed-light
    if (!element.classList.contains('theme-light')) {
      element.classList.add('themed','theme-light')
    }

    if ((application.document.flags?.elysium?.['fixed-adventure-heading'] ?? false) && !element.classList.contains('fixed-adventure-heading')) {
      element.classList.add('fixed-adventure-heading')
      //Force to use themed-light
      if (!element.classList.contains('theme-light')) {
        element.classList.add('themed','theme-light')
      }      

      if (typeof application.document.pages?.contents?.[0]?.id === 'string') {
        const subheading = application.document.pages.get(application.document.pages.contents[0].id)?.flags?.elysium?.['fixed-adventure-subheading'] ?? ''
        if (subheading !== '') {
          element.classList.add('fixed-adventure-subheading')
          const short = subheading.trim().length === 0
          const div = document.createElement('div')
          div.classList.add('adventure-heading-section', 'flexrow-pen')
          div.innerHTML = '<div class="bookmark' + (short ? ' short' : '') + '"><img src="systems/elysium/assets' + (short ? 'bookmarks.webp' : 'bookmark.webp') + '"></div><div class="adventure-heading"><div class="heading">' + application.title + '</div>' + (short ? '' : '<div class="subheading">' + subheading + '</div>') + '</div>'
          element.querySelector('article.journal-entry-page')?.before(div)
        }
      }
    }
  }

}
