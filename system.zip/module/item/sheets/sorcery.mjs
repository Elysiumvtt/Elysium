import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Sorcery spell item sheet — P10 cluster 4 / alpha.42 rewrite.
 *
 * Per c4-sorcery-1: essence selector driven by getSorceryEssenceOptions
 *   helper (12 essences + empty; "(forbidden)" suffix composed helper-side).
 * Per c4-sorcery-3: damage type driven by getSorceryDamageTypeOptions
 *   (14 types + none); readonly view shows colored damage tag.
 * Per c4-sorcery-4: conditional Maintain PP/round row preserved.
 * Per c4-sorcery-6: form handler preserved unchanged — defensively
 *   maintains legacy variable-level fields (var, maxLvl, currLvl, memLvl)
 *   that the v1.0.0 template doesn't expose. DataModel cleanup deferred
 *   to P12.
 *
 * Inherits _getTabs, _configureRenderOptions, description/gmNotes prep
 * from base via cluster-2 hoist.
 */
export class ElysiumSorcerySheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['sorcery'],
    position: { width: 720, height: 720 },  // wide tier per c4-9
    form: { handler: ElysiumSorcerySheet.mySorceryHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/sorcery.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Selects — driven by cluster-3a + cluster-4 helpers
    context.essenceOptions    = await ElysiumSelectLists.getSorceryEssenceOptions()
    context.damageTypeOptions = await ElysiumSelectLists.getSorceryDamageTypeOptions()
    context.saveSkillOptions  = await ElysiumSelectLists.getSpellSaveSkillOptions()

    const ely = this.item.system?.elysium ?? {}

    // Localized display names for the readonly view
    const essenceRaw = ely.essence ?? ''
    const essenceCap = essenceRaw
      ? essenceRaw.charAt(0).toUpperCase() + essenceRaw.slice(1)
      : ''
    context.essenceName = essenceRaw
      ? game.i18n.localize(`Elysium.essence${essenceCap}`)
      : '—'
    context.essenceIsForbidden = ['death', 'blight', 'void'].includes(essenceRaw)

    const damageTypeRaw = ely.damageType ?? ''
    const damageTypeKey = damageTypeRaw === ''
      ? 'Elysium.damageNone'
      : 'Elysium.damage' + damageTypeRaw.charAt(0).toUpperCase() + damageTypeRaw.slice(1)
    context.damageTypeName = game.i18n.localize(damageTypeKey)

    const saveSkillRaw = ely.saveSkill ?? ''
    const saveSkillKey = saveSkillRaw === ''
      ? 'Elysium.saveSkillNone'
      : 'Elysium.saveSkill' + saveSkillRaw.charAt(0).toUpperCase() + saveSkillRaw.slice(1)
    context.saveSkillName = game.i18n.localize(saveSkillKey)

    // Header chips per audit-3-cluster-3: Essence + Tier Band + Power Cost
    const baseTier = Math.max(1, Number(ely.baseTier) || 1)
    const maxTier  = Math.min(5, Math.max(baseTier, Number(ely.maxTier) || 5))
    const tierBand = baseTier === maxTier ? `T${baseTier}` : `T${baseTier}–T${maxTier}`
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.essence'),        value: context.essenceName },
      { label: game.i18n.localize('Elysium.tier'),           value: tierBand },
      { label: game.i18n.localize('Elysium.powerPointCost'), value: String(ely.powerCost ?? 2) },
    ]

    // Flag chips driving item-toggle-row partial. Storage paths are
    // explicit so the cluster-4 enhanced _onItemToggle writes to
    // system.elysium.* (the correct DataModel field paths). Without
    // propertyPath, writes would land at system.<prop> (junk path).
    context.flagChips = [
      { property: 'isDamageSpell',
        propertyPath: 'system.elysium.isDamageSpell',
        active: !!ely.isDamageSpell,
        label: game.i18n.localize('Elysium.damageSpell') },
      { property: 'isSustained',
        propertyPath: 'system.elysium.isSustained',
        active: !!ely.isSustained,
        label: game.i18n.localize('Elysium.sustained') },
      { property: 'forbidden',
        propertyPath: 'system.elysium.forbidden',
        active: !!ely.forbidden,
        label: game.i18n.localize('Elysium.forbidden'),
        tooltip: game.i18n.localize('Elysium.forbiddenHint') },
      { property: 'casterChoosesLocation',
        propertyPath: 'system.elysium.casterChoosesLocation',
        active: !!ely.casterChoosesLocation,
        label: game.i18n.localize('Elysium.casterChoosesLocation'),
        tooltip: game.i18n.localize('Elysium.casterChoosesLocationHint') },
    ]

    return context
  }

  /** @override — builds per-tier rows for the details body. */
  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context)
    if (partId !== 'details') return context

    const ely = this.item.system?.elysium ?? {}
    const baseTier = Math.max(1, Number(ely.baseTier) || 1)
    const maxTier  = Math.min(5, Math.max(baseTier, Number(ely.maxTier) || 5))
    const apCostByTier    = Array.isArray(ely.apCostByTier)    ? ely.apCostByTier    : [1, 1, 1, 1, 1]
    const effectByTier    = (ely.effectByTier && typeof ely.effectByTier === 'object') ? ely.effectByTier : {}
    const damageByTier    = Array.isArray(ely.damageByTier)    ? ely.damageByTier    : ['', '', '', '', '']
    const locationsByTier = Array.isArray(ely.locationsByTier) ? ely.locationsByTier : [1, 1, 1, 1, 1]

    // Active-tier rows for the Effects by Tier section
    const effectsByTierList = []
    for (let t = baseTier; t <= maxTier; t++) {
      effectsByTierList.push({
        tier: t,
        apCost: Number(apCostByTier[t - 1]) || 1,
        text: effectByTier[String(t)] ?? effectByTier[t] ?? '',
        damageExpr: damageByTier[t - 1] ?? '',
        locations: Number(locationsByTier[t - 1]) || 1,
        idx: t - 1,
      })
    }
    context.effectsByTierList = effectsByTierList

    // Full T1-T5 cell list for the AP-cost grid
    const apCostByTierList = []
    for (let i = 0; i < 5; i++) {
      apCostByTierList.push({
        tier: i + 1,
        cost: Number(apCostByTier[i]) || 1,
        idx: i,
      })
    }
    context.apCostByTierList = apCostByTierList

    return context
  }

  /**
   * Form-submission handler. Defensively preserves legacy variable-level
   * fields (var, maxLvl, currLvl, memLvl) that the v1.0.0 template
   * doesn't expose. Per c4-7: DataModel cleanup is P12 work.
   *
   * P10 cluster 4 (alpha.42) post-ship fix: the legacy code ended with
   * `this.item.render(false)` — a V12-era explicit re-render. V14
   * auto-renders after document.update, so the trailing render was
   * triggering a second render that re-fired the form handler in an
   * infinite loop once the cluster-4 base-sheet resilience fix
   * started including the `header` + `tabs` parts on initial render.
   * Removed: V14 handles re-rendering correctly.
   */
  static async mySorceryHandler(event, form, formData) {
    if (formData.object['system.maxLvl'] === undefined) {
      formData.object['system.maxLvl'] = this.item.system.maxLvl
    }
    if (formData.object['system.maxLvl'] < 1) formData.object['system.maxLvl'] = 1

    if (!this.item.system.var) {
      formData.object['system.currLvl'] = formData.object['system.maxLvl']
      formData.object['system.memLvl']  = formData.object['system.maxLvl']
    } else {
      // Variable-level path. Preserve when template fields absent.
      const currIn = formData.object['system.currLvl'] ?? this.item.system.currLvl ?? 1
      const memIn  = formData.object['system.memLvl']  ?? this.item.system.memLvl  ?? 1
      const currLvl = Math.min(Math.max(currIn, 1), formData.object['system.maxLvl'])
      const memLvl  = Math.min(Math.max(memIn, 1), currLvl)
      formData.object['system.currLvl'] = currLvl
      formData.object['system.memLvl']  = memLvl
    }
    await this.document.update(formData.object)
  }
}
