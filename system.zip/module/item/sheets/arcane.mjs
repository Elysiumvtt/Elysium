import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'
import { getArcaneFormsTechniquesFromCompendium } from '../../casting/cast-shared.mjs'

/**
 * Arcane spell item sheet — P10 cluster 4 / alpha.42 rewrite.
 *
 * Per c4-arcane-1: F/T compendium-driven row dropdowns preserved with
 *   ftAdd / ftRemove static action handlers (unchanged); precomputed
 *   `selected` flags on per-row options preserved (avoids cached-template
 *   `(eq)` helper bug from v0.10.9). Submit-data coercion preserved.
 * Per c4-arcane-2: header chips — School + Required SL + Base PP + AP Cost.
 * Per c4-arcane-3: native checkbox flag-block migrated to elysium-item-toggle
 *   chips (isRitual + isPermanent) via shared item-toggle-row partial.
 *   Storage path is system.elysium.* (handler reads data-property-path).
 * Per c4-arcane-6: cluster-4 ship retires the v0.10.0-era diagnostic
 *   console.log calls. One defensive console.warn retained for invalid
 *   ftKind path.
 */
export class ElysiumArcaneSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['arcane'],
    position: { width: 720, height: 640 },  // wide tier per c4-9
    actions: {
      ftAdd:    ElysiumArcaneSheet._onFTAdd,
      ftRemove: ElysiumArcaneSheet._onFTRemove,
    },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/arcane.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    context.itemType = game.i18n.localize('Elysium.arcane')

    // Save-skill select (shared cluster-3a helper)
    context.saveSkillOptions = await ElysiumSelectLists.getSpellSaveSkillOptions()
    const saveSkillRaw = this.item.system?.elysium?.saveSkill ?? ''
    const saveSkillKey = saveSkillRaw === ''
      ? 'Elysium.saveSkillNone'
      : 'Elysium.saveSkill' + saveSkillRaw.charAt(0).toUpperCase() + saveSkillRaw.slice(1)
    context.saveSkillName = game.i18n.localize(saveSkillKey)

    // Header chips per c4-arcane-2: School + RequiredSL + BasePP + APCost
    const ely = this.item.system?.elysium ?? {}
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.arcaneSchool'),
        value: ely.school ? ely.school : '—' },
      { label: game.i18n.localize('Elysium.arcaneRequiredSL'),
        value: String(ely.requiredSL ?? 1) },
      { label: game.i18n.localize('Elysium.arcaneBasePP'),
        value: String(ely.basePP ?? 0) },
      { label: game.i18n.localize('Elysium.apCost'),
        value: String(ely.apCost ?? 1) },
    ]

    // Flag chips driving the item-toggle-row partial. Storage path
    // (system.elysium.*) is explicit so the handler's _onItemToggle
    // (cluster-4 enhanced) writes to the correct nested DataModel field.
    context.flagChips = [
      { property: 'isRitual',    propertyPath: 'system.elysium.isRitual',
        active: !!ely.isRitual,    label: game.i18n.localize('Elysium.isRitual') },
      { property: 'isPermanent', propertyPath: 'system.elysium.isPermanent',
        active: !!ely.isPermanent, label: game.i18n.localize('Elysium.isPermanent') },
    ]

    return context
  }

  /** @override — F/T compendium row data for the details body. */
  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context)
    if (partId !== 'details') return context

    try {
      const ft = await getArcaneFormsTechniquesFromCompendium()
      const storedForms = this.item.system?.elysium?.forms ?? []
      const storedTechs = this.item.system?.elysium?.techniques ?? []

      // Per c4-arcane-1: precompute `selected` on each option to avoid
      // cached-template (eq) helper bug from v0.10.9. Also surface any
      // stored value that no longer exists in the compendium with a
      // labelled "(not in compendium)" entry so the GM can fix or remove.
      const baseFormOptions = [{ value: '', label: '—' }, ...ft.forms]
      for (const stored of storedForms) {
        if (stored && !ft.forms.some(o => o.value === stored)) {
          baseFormOptions.push({
            value: stored,
            label: `(${stored}) ${game.i18n.localize('Elysium.arcaneNotInCompendium')}`,
          })
        }
      }
      const baseTechOptions = [{ value: '', label: '—' }, ...ft.techniques]
      for (const stored of storedTechs) {
        if (stored && !ft.techniques.some(o => o.value === stored)) {
          baseTechOptions.push({
            value: stored,
            label: `(${stored}) ${game.i18n.localize('Elysium.arcaneNotInCompendium')}`,
          })
        }
      }

      // Display all stored rows including empty strings (v0.10.11 fix:
      // a freshly-clicked "+ Forms" button creates an empty row; it
      // must remain visible so the user can pick a value).
      const cleanForms = [...storedForms]
      const cleanTechs = [...storedTechs]
      context.formRows = cleanForms.map(value => ({
        value,
        options: baseFormOptions.map(opt => ({ ...opt, selected: opt.value === value })),
      }))
      context.techniqueRows = cleanTechs.map(value => ({
        value,
        options: baseTechOptions.map(opt => ({ ...opt, selected: opt.value === value })),
      }))

      // Bare option lists retained for future client-side row-append logic.
      context.formOptions = baseFormOptions
      context.techniqueOptions = baseTechOptions
    } catch (err) {
      console.warn('Elysium: failed to load F/T compendium options', err)
      context.formOptions = [{ value: '', label: '—' }]
      context.techniqueOptions = [{ value: '', label: '—' }]
      context.formRows = []
      context.techniqueRows = []
    }
    return context
  }

  /**
   * Normalise per-row F/T submissions. The template emits
   * `<select name="system.elysium.forms.0">`, etc. After expandObject,
   * this lands as either an array `['fire','force']` or a numeric-keyed
   * object `{0:'fire',1:'force'}`. Coerce to array; drop empty entries
   * so the "—" placeholder doesn't pollute storage.
   */
  _prepareSubmitData(event, form, formData, updateData) {
    const submitted = super._prepareSubmitData(event, form, formData, updateData)
    const sys = submitted?.system?.elysium
    if (sys) {
      sys.forms      = this._coerceArray(sys.forms)
      sys.techniques = this._coerceArray(sys.techniques)
    }
    return submitted
  }

  _coerceArray(value) {
    let arr
    if (Array.isArray(value))                       arr = value
    else if (value && typeof value === 'object')    arr = Object.values(value)
    else if (value === undefined || value === null) arr = []
    else                                            arr = [value]
    return arr
      .map(v => (v == null ? '' : String(v)))
      .filter(v => v.length > 0)
  }

  // V14 action: append a new (empty) F/T row.
  static async _onFTAdd(event, target) {
    event?.preventDefault?.()
    let kind = target?.dataset?.ftKind
    // Defensive fallback: if the action target is the inner <i> not the
    // wrapping <a>, climb to find data-ft-kind.
    if (!kind && target?.closest) {
      const wrapper = target.closest('[data-ft-kind]')
      kind = wrapper?.dataset?.ftKind
    }
    if (!kind || !['forms', 'techniques'].includes(kind)) {
      console.warn('Elysium ftAdd: invalid or missing kind', kind)
      return
    }
    const path = `system.elysium.${kind}`
    const current = foundry.utils.getProperty(this.item, path) ?? []
    await this.item.update({ [path]: [...current, ''] })
  }

  // V14 action: remove a F/T row by index.
  static async _onFTRemove(event, target) {
    event?.preventDefault?.()
    const kind = target?.dataset?.ftKind
    const idx = Number(target?.dataset?.ftIndex)
    if (!kind || !['forms', 'techniques'].includes(kind)) return
    if (!Number.isInteger(idx) || idx < 0) return
    const path = `system.elysium.${kind}`
    const current = foundry.utils.getProperty(this.item, path) ?? []
    if (idx >= current.length) return
    await this.item.update({ [path]: current.filter((_, i) => i !== idx) })
  }
}
