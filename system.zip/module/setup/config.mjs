export const Elysium = {};

Elysium.stats = {
  "str": "Elysium.StatsStr",
  "con": "Elysium.StatsCon",
  "siz": "Elysium.StatsSiz",
  "int": "Elysium.StatsInt",
  "pow": "Elysium.StatsPow",
  "dex": "Elysium.StatsDex",
  "cha": "Elysium.StatsCha",
  "edu": "Elysium.StatsEdu"
};

Elysium.statsAbbreviations = {
  "str": "Elysium.StatsStrAbbr",
  "con": "Elysium.StatsConAbbr",
  "siz": "Elysium.StatsSizAbbr",
  "int": "Elysium.StatsIntAbbr",
  "pow": "Elysium.StatsPowAbbr",
  "dex": "Elysium.StatsDexAbbr",
  "cha": "Elysium.StatsChaAbbr",
  "edu": "Elysium.StatsEduAbbr",
  "fixed": "Elysium.fixed",
  "none": "Elysium.none",
};

Elysium.statsDerived = {
  "str": "Elysium.StatsStrDeriv",
  "con": "Elysium.StatsConDeriv",
  "siz": "Elysium.StatsSizDeriv",
  "int": "Elysium.StatsIntDeriv",
  "pow": "Elysium.StatsPowDeriv",
  "dex": "Elysium.StatsDexDeriv",
  "cha": "Elysium.StatsChaDeriv",
  "edu": "Elysium.StatsEduDeriv",
};

Elysium.keysActiveEffects = {
  'system.stats.str.effects': 'Elysium.StatsStrAbbr',
  'system.stats.con.effects': 'Elysium.StatsConAbbr',
  'system.stats.int.effects': 'Elysium.StatsIntAbbr',
  'system.stats.siz.effects': 'Elysium.StatsSizAbbr',
  'system.stats.pow.effects': 'Elysium.StatsPowAbbr',
  'system.stats.dex.effects': 'Elysium.StatsDexAbbr',
  'system.stats.cha.effects': 'Elysium.StatsChaAbbr',
  'system.health.effects': 'Elysium.health',
  'system.power.effects': 'Elysium.mp',
  // v0.20.0: 'system.fatigue.effects' removed — Elysium fatigue is a Mythras
  // ladder (level/label), not a flat value/max pool with effect modifiers.
  // To impose AP/skill penalties from fatigue, use the Elysium subsystem's
  // flags.elysium.modifiers.apPenalty / .allSkills keys instead.
};
