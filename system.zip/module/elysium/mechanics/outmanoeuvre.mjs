// =====================================================================
// ELYSIUM | Outmanoeuvre (Mythras p114)
// =====================================================================
//
// A character facing multiple opponents uses movement to limit the
// number who can attack them. The manoeuvrer makes a group opposed
// Evade roll against any foes who opt in; foes who lose the contest
// cannot attack the manoeuvrer for the rest of this combat round.
//
// Eligibility:
//   - The combatant must be engaged with ≥2 different opponents
//     (room-to-move is a tabletop/GM judgment, not a hard check here)
//
// Resolution (this module):
//   - Manoeuvrer spends 1 AP and rolls Evade — GM enters SL externally
//   - Each opt-in foe spends 1 AP and rolls Evade — GM enters SL
//   - Foes who lose (manoeuvrer's SL > foe's SL; manoeuvrer wins ties)
//     get `blockedFrom: [...prev, manoeuvrerCombatantId]` for this round
//   - If the manoeuvrer beats ALL opt-in foes: special bonus — GM
//     picks "Engage one foe" or "Withdraw"
//   - Opt-out foes don't roll, don't spend AP, are NOT blocked
//
// State storage:
//   combatant.flags['elysium'].outmanoeuvre = {
//     blockedFrom: [<manoeuvrerCombatantId>, ...]
//   }
//
// Per-round; cleared at round start by combat-extension.mjs::onRound
// via ElysiumOutmanoeuvre.clearAllOutmanoeuvreBlocks(combat).
//
// This module is GM-facilitated state tracking, similar to engagement
// and change-range. We don't intercept attack rolls — the GM sees the
// blocked state on the sheet/chat-card and enforces it socially. The
// `isBlockedFrom` helper is exposed for future automation if a true
// combat-roll gate becomes desirable later.
// =====================================================================

import { getEngagements } from './engagement.mjs'

const FLAG_NS = 'elysium'
const FLAG_KEY = 'outmanoeuvre'

const SL_LABELS = {
  3: 'Critical',
  2: 'Success',
  1: 'Fail',
  0: 'Fumble',
}

// ---------------------------------------------------------------------
// State accessors (pure helpers)
// ---------------------------------------------------------------------

/**
 * Read the array of combatant IDs that `combatant` is blocked from
 * attacking this round. Always returns an array (empty if none).
 *
 * @param {Combatant} combatant
 * @returns {string[]}
 */
export function getBlockedFrom (combatant) {
  return combatant?.flags?.[FLAG_NS]?.[FLAG_KEY]?.blockedFrom || []
}

/**
 * True if `attacker` cannot attack `target` this round because they
 * lost an outmanoeuvre contest to that target.
 *
 * @param {Combatant} attacker
 * @param {Combatant} target
 * @returns {boolean}
 */
export function isBlockedFrom (attacker, target) {
  if (!attacker || !target) return false
  return getBlockedFrom(attacker).includes(target.id)
}

/**
 * True if `combatant` has enough engagements to attempt an
 * outmanoeuvre — defined as engagements with ≥2 distinct opponents.
 *
 * Room-to-move is intentionally not checked here; it's a tabletop
 * judgment the GM makes before opening the dialog.
 *
 * @param {Combatant} combatant
 * @returns {boolean}
 */
export function eligibleToOutmanoeuvre (combatant) {
  if (!combatant) return false
  const distinctOpponents = new Set(
    getEngagements(combatant).map(e => e.withId)
  )
  return distinctOpponents.size >= 2
}

/**
 * Round-end cleanup. Clears the outmanoeuvre.blockedFrom flag on every
 * combatant in the combat. Called from combat-extension.mjs::onRound
 * at the start of each round.
 *
 * @param {Combat} combat
 */
export async function clearAllOutmanoeuvreBlocks (combat) {
  if (!combat?.combatants) return
  for (const c of combat.combatants) {
    if (getBlockedFrom(c).length === 0) continue
    await c.update({
      [`flags.${FLAG_NS}.${FLAG_KEY}`]: null,
    })
  }
}

// ---------------------------------------------------------------------
// Dialog flow
// ---------------------------------------------------------------------

/**
 * Open the outmanoeuvre dialog for a manoeuvrer. Shows the list of
 * opposing engaged combatants with opt-in checkboxes and SL inputs;
 * the manoeuvrer enters their own SL too. On submit, calls
 * resolveOutmanoeuvre.
 *
 * The dialog is GM-only (others see the chat card output).
 *
 * @param {Combatant} manoeuvrer
 */
export async function openOutmanoeuvreDialog (manoeuvrer) {
  if (!eligibleToOutmanoeuvre(manoeuvrer)) {
    ui.notifications?.warn(
      `${manoeuvrer.name} needs to be engaged with at least 2 different opponents to outmanoeuvre.`
    )
    return
  }

  const combat = game.combat
  if (!combat) return

  // Build the list of distinct opposing combatants from engagement records.
  // De-duplicate by withId (in case of multiple engagements with same foe
  // via different weapons; we still treat them as one foe in the contest).
  const distinctIds = [...new Set(getEngagements(manoeuvrer).map(e => e.withId))]
  const foes = distinctIds
    .map(id => combat.combatants.get(id))
    .filter(c => c)

  if (foes.length < 2) {
    ui.notifications?.warn(
      `${manoeuvrer.name} needs at least 2 distinct opposing engaged combatants.`
    )
    return
  }

  const slOptions = (selectedValue = 2) => {
    return Object.entries(SL_LABELS)
      .sort(([a], [b]) => Number(b) - Number(a))   // critical first
      .map(([val, label]) => {
        const sel = Number(val) === selectedValue ? ' selected' : ''
        return `<option value="${val}"${sel}>${label}</option>`
      }).join('')
  }

  const foeRows = foes.map(foe => `
    <tr>
      <td><input type="checkbox" name="optIn:${foe.id}" checked></td>
      <td>${foe.name}</td>
      <td>
        <select name="sl:${foe.id}">${slOptions(2)}</select>
      </td>
    </tr>
  `).join('')

  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:12px;">
        <b>${manoeuvrer.name}</b> attempts to outmanoeuvre opposing
        engaged combatants. Manoeuvrer spends 1 AP; each opt-in foe
        spends 1 AP. Resolve Evade rolls externally and enter the
        success levels below.
      </p>
      <div class="form-group">
        <label><b>${manoeuvrer.name}</b>'s Evade SL</label>
        <select name="manoeuvrerSL">${slOptions(2)}</select>
      </div>
      <hr>
      <p style="margin:4px 0;font-size:11px;font-style:italic;opacity:0.8;">
        Uncheck a foe to have them opt out (no AP cost, not blocked).
      </p>
      <table style="width:100%;font-size:12px;">
        <thead><tr><th>Opt-in</th><th>Foe</th><th>Evade SL</th></tr></thead>
        <tbody>${foeRows}</tbody>
      </table>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Outmanoeuvre — ${manoeuvrer.name}` },
    content,
    ok: {
      label: 'Resolve',
      callback: (event, button) => {
        const form = button.form
        const manoeuvrerSL = Number(form.querySelector('[name="manoeuvrerSL"]').value)
        const foeRolls = []
        for (const foe of foes) {
          const optIn = form.querySelector(`[name="optIn:${foe.id}"]`).checked
          const sl = Number(form.querySelector(`[name="sl:${foe.id}"]`).value)
          foeRolls.push({ foeId: foe.id, optIn, sl })
        }
        return { manoeuvrerSL, foeRolls }
      },
    },
  }).catch(() => null)

  if (!result) return
  await resolveOutmanoeuvre(manoeuvrer.id, result.manoeuvrerSL, result.foeRolls)
}

/**
 * Resolve the outmanoeuvre contest. Spends AP from the manoeuvrer and
 * each opt-in foe, writes blockedFrom flags on losing foes, and posts
 * the result chat card. If the manoeuvrer beats every opt-in foe,
 * posts a follow-up card with "Engage one" / "Withdraw" buttons.
 *
 * @param {string} manoeuvrerId  combatant id
 * @param {number} manoeuvrerSL  0-3
 * @param {Array<{foeId, optIn, sl}>} foeRolls
 */
export async function resolveOutmanoeuvre (manoeuvrerId, manoeuvrerSL, foeRolls) {
  const combat = game.combat
  if (!combat) return
  const manoeuvrer = combat.combatants.get(manoeuvrerId)
  if (!manoeuvrer) return

  // Spend 1 AP from the manoeuvrer
  await _spendAP(manoeuvrer, 1)

  // Process each foe roll; collect outcomes for the chat card
  const outcomes = []
  let optInCount = 0
  let blockedCount = 0

  for (const { foeId, optIn, sl } of foeRolls) {
    const foe = combat.combatants.get(foeId)
    if (!foe) continue

    if (!optIn) {
      outcomes.push({ foe, optIn: false, blocked: false })
      continue
    }
    optInCount++
    await _spendAP(foe, 1)

    // Manoeuvrer wins ties (active party convention)
    const manoeuvrerWins = manoeuvrerSL >= sl
    if (manoeuvrerWins) {
      blockedCount++
      const prev = getBlockedFrom(foe)
      const next = prev.includes(manoeuvrerId) ? prev : [...prev, manoeuvrerId]
      await foe.update({
        [`flags.${FLAG_NS}.${FLAG_KEY}.blockedFrom`]: next,
      })
    }
    outcomes.push({
      foe, optIn: true, blocked: manoeuvrerWins, foeSL: sl,
    })
  }

  // Build the result chat card
  const rows = outcomes.map(o => {
    if (!o.optIn) {
      return `<tr>
        <td>${o.foe.name}</td>
        <td><em>opted out</em></td>
        <td><span style="opacity:0.6;">not blocked</span></td>
      </tr>`
    }
    const slLabel = SL_LABELS[o.foeSL] || o.foeSL
    const badge = o.blocked
      ? `<span style="background:#7a2222;color:#fff;padding:2px 6px;border-radius:3px;font-size:11px;">BLOCKED</span>`
      : `<span style="background:#2a6e2a;color:#fff;padding:2px 6px;border-radius:3px;font-size:11px;">can attack</span>`
    return `<tr>
      <td>${o.foe.name}</td>
      <td>${slLabel}</td>
      <td>${badge}</td>
    </tr>`
  }).join('')

  const beatsAll = optInCount > 0 && blockedCount === optInCount
  const followUpButtons = beatsAll
    ? `<hr>
       <p><em>${manoeuvrer.name} beat every opposing foe. Choose a bonus outcome:</em></p>
       <div class="elysium-chat-prompt__buttons">
         <button type="button" data-elysium-om-action="engage-one"
                 data-om-manoeuvrer="${manoeuvrerId}"
                 data-tooltip="Manoeuvrer safely closes to engage one foe of choice for the rest of the round. No mechanical effect beyond the existing blocks.">
           Engage one foe
         </button>
         <button type="button" data-elysium-om-action="withdraw"
                 data-om-manoeuvrer="${manoeuvrerId}"
                 data-tooltip="Manoeuvrer withdraws from the fight entirely — all engagement records on the manoeuvrer are cleared.">
           Withdraw
         </button>
       </div>`
    : ''

  // Per c2 audit D4: edge case — caller-built body wraps table + optional
  // button block. `data-elysium-om-action` is JS-imperative (audit-5 hook,
  // chat-card.mjs binding).
  const body = `<p><b>${manoeuvrer.name}</b> rolled Evade
      <b>${SL_LABELS[manoeuvrerSL] || manoeuvrerSL}</b>.</p>
    <table>
      <thead><tr><th>Foe</th><th>Foe SL</th><th>Outcome</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    ${followUpButtons}`

  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', title: 'Outmanoeuvre', icon: 'person-running', body }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor: manoeuvrer.actor }),
    flags: { [FLAG_NS]: { outmanoeuvreCard: true } },
  })
}

/**
 * Resolve a "beats-all" follow-up button outcome.
 *
 * @param {string} action       'engage-one' | 'withdraw'
 * @param {string} manoeuvrerId combatant id
 */
export async function resolveOutmanoeuvreFollowUp (action, manoeuvrerId) {
  const combat = game.combat
  if (!combat) return
  const manoeuvrer = combat.combatants.get(manoeuvrerId)
  if (!manoeuvrer) return

  if (action === 'engage-one') {
    const body = `<p>${game.i18n.format('Elysium.Chat.OutmanoeuvreClose', {
      actor: `<b>${manoeuvrer.name}</b>`,
    })}</p>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'info', icon: 'person-running', body }
    )
    await ChatMessage.create({
      content: html,
      speaker: ChatMessage.getSpeaker({ actor: manoeuvrer.actor }),
    })
    return
  }

  if (action === 'withdraw') {
    // Clear all engagement records on the manoeuvrer. Also clear the
    // mirroring engagement entries on each former opponent (engagements
    // are bidirectional).
    const myEngagements = getEngagements(manoeuvrer)
    const opponentIds = myEngagements.map(e => e.withId)

    await manoeuvrer.update({
      [`flags.${FLAG_NS}.engagements`]: [],
    })

    for (const oid of opponentIds) {
      const opp = combat.combatants.get(oid)
      if (!opp) continue
      const oppList = getEngagements(opp).filter(e => e.withId !== manoeuvrer.id)
      await opp.update({
        [`flags.${FLAG_NS}.engagements`]: oppList,
      })
    }

    const body = `<p>${game.i18n.format('Elysium.Chat.OutmanoeuvreWithdraw', {
      actor: `<b>${manoeuvrer.name}</b>`,
    })}</p>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'info', icon: 'person-running', body }
    )
    await ChatMessage.create({
      content: html,
      speaker: ChatMessage.getSpeaker({ actor: manoeuvrer.actor }),
    })
  }
}

// ---------------------------------------------------------------------
// AP helper
// ---------------------------------------------------------------------

async function _spendAP (combatant, n) {
  const actor = combatant.actor
  if (!actor) return
  const ap = actor.system?.actionPoints?.value ?? 0
  await actor.update({
    'system.actionPoints.value': Math.max(0, ap - n),
  })
}

// ---------------------------------------------------------------------
// Combat-tracker context-menu integration
// ---------------------------------------------------------------------

/**
 * Append the Outmanoeuvre entry to a combatant context-menu options
 * array. Mutates `options` in place. Called from
 * engagement-ui.mjs::patchCombatTrackerContextMenu, parallel to the
 * existing engagement and charge entries.
 *
 * Visibility condition: combatant must be engaged with ≥2 distinct
 * opponents in the active combat.
 */
export function registerOutmanoeuvreContextMenu (html, options) {
  const elOf = (li) => (li?.[0] instanceof Element ? li[0] : li)

  options.push({
    name: 'Elysium: Outmanoeuvre…',
    icon: '<i class="fas fa-people-arrows"></i>',
    condition: (li) => {
      const el = elOf(li)
      const combatantId = el?.dataset?.combatantId
      const combatant = game.combat?.combatants.get(combatantId)
      return eligibleToOutmanoeuvre(combatant)
    },
    callback: (li) => {
      const el = elOf(li)
      const combatantId = el?.dataset?.combatantId
      const combatant = game.combat?.combatants.get(combatantId)
      if (combatant) openOutmanoeuvreDialog(combatant)
    },
  })
}

// ---------------------------------------------------------------------
// Chat-card delegation
// ---------------------------------------------------------------------

/**
 * Wire click handlers on outmanoeuvre follow-up buttons. Called once
 * during ready hook.
 */
export function wireOutmanoeuvreChatHandlers () {
  document.body.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-elysium-om-action]')
    if (!btn) return
    ev.preventDefault()
    if (!game.user.isGM && !game.user.hasPermission?.('SETTINGS_MODIFY')) {
      ui.notifications?.warn('Only the GM can resolve Outmanoeuvre outcomes.')
      return
    }
    const action = btn.dataset.elysiumOmAction
    const manoeuvrerId = btn.dataset.omManoeuvrer
    await resolveOutmanoeuvreFollowUp(action, manoeuvrerId)
  })
}

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

export const ElysiumOutmanoeuvre = {
  // State accessors
  getBlockedFrom,
  isBlockedFrom,
  eligibleToOutmanoeuvre,
  clearAllOutmanoeuvreBlocks,

  // Flow
  openOutmanoeuvreDialog,
  resolveOutmanoeuvre,
  resolveOutmanoeuvreFollowUp,

  // Integration helpers
  registerContextMenu: registerOutmanoeuvreContextMenu,
  wireOutmanoeuvreChatHandlers,
}
