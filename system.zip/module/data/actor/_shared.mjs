/**
 * Shared DataModel field-builders for actor types.
 *
 * Each helper returns a SchemaField with the field set the live data exposes.
 * "Stored-schema-only" by design (P5 decision; see docs/p5-prep-audit.md):
 * derived fields populated by ElysiumActor.prepareDerivedData (label, total,
 * deriv, visible, formula, etc.) are deliberately OMITTED from these schemas.
 * They get stamped onto the live data each prep cycle and dropped on save.
 *
 * Field set sources:
 *   - template.json (stored defaults)
 *   - docs/p5-prep-audit.md (live-probe ground truth)
 *
 * Decisions encoded here:
 *   - actionPoints includes all 11 stored fields (audit corrected P3's "6")
 *   - actionPoints._v0140doc is REPLACED by an inline JS comment (see below)
 *   - power drops battVal/battMax (zero readers, grep-confirmed during P5.1)
 *   - power, health, fatigue all keep .effects OUT of schema; reads use ?? 0
 *   - fatigue.recoveryType is KEPT with choices ['physical', 'magical'] —
 *     audit corrected P3's "drop candidate" call after live probe
 *   - health keeps .daily — audit said drop but grep found live writes in
 *     damage.mjs and base-actor-sheet.mjs (resets to 0); removing would
 *     break those updates under strict-schema validation
 *   - stats has 11 stored fields per audit; edu is excluded from per-actor
 *     stats block (only appears in baseStats for stat-generation rolls)
 */

const fields = foundry.data.fields

const STAT_KEYS = ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha']

/**
 * Per-stat stored shape (11 fields). Used as the value-shape inside `stats`.
 * Note: `int` and `siz` use cost: 3 by template default; per-stat overrides
 * happen via the `initial:` in `makeStats()`, not here.
 */
function makeStatSchemaField (cost = 1) {
  return new fields.SchemaField({
    base:         new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    redist:       new fields.NumberField({ integer: true, initial: 0 }),       // can be negative
    culture:      new fields.NumberField({ integer: true, initial: 0 }),
    exp:          new fields.NumberField({ integer: true, initial: 0 }),
    age:          new fields.NumberField({ integer: true, initial: 0 }),
    effects:      new fields.NumberField({ integer: true, initial: 0 }),
    cost:         new fields.NumberField({ integer: true, initial: cost, min: 1 }),
    formula:      new fields.StringField({ initial: '' }),
    improve:      new fields.BooleanField({ initial: false }),
    failCounter:  new fields.NumberField({ integer: true, initial: 0 }),
    capOverride:  new fields.BooleanField({ initial: false }),
  })
}

/**
 * The full 7-stat block. Stat-cost varies by stat (INT/POW/DEX = 3, others = 1)
 * per template.json defaults; we encode that here.
 */
export function makeStats () {
  // Per template.json: str/con/siz/cha cost 1; int/pow/dex cost 3.
  const costs = { str: 1, con: 1, int: 3, siz: 1, pow: 3, dex: 3, cha: 1 }
  const stats = {}
  for (const k of STAT_KEYS) {
    stats[k] = makeStatSchemaField(costs[k])
  }
  return new fields.SchemaField(stats)
}

/**
 * Health block (5 fields). `daily` is preserved despite zero meaningful reads
 * (live damage code resets it to 0 via update; removing breaks those writes
 * under strict DataModel validation).
 */
export function makeHealth () {
  return new fields.SchemaField({
    value:   new fields.NumberField({ integer: true, initial: 10, min: 0 }),
    max:     new fields.NumberField({ integer: true, initial: 10, min: 0 }),
    mod:     new fields.NumberField({ integer: true, initial: 0 }),
    mjrwnd:  new fields.NumberField({ integer: true, initial: 5, min: 0 }),
    daily:   new fields.NumberField({ integer: true, initial: 0 }),
  })
}

/**
 * Power block (3 fields). battVal/battMax dropped — zero code readers,
 * grep-confirmed during P5.1.
 */
export function makePower () {
  return new fields.SchemaField({
    value:  new fields.NumberField({ integer: true, initial: 5, min: 0 }),
    max:    new fields.NumberField({ integer: true, initial: 5, min: 0 }),
    mod:    new fields.NumberField({ integer: true, initial: 0 }),
  })
}

/**
 * Fatigue block (5 fields). recoveryType is kept with choices constraint —
 * live probe confirmed it's populated with "physical" by default.
 */
export function makeFatigue () {
  return new fields.SchemaField({
    value:         new fields.NumberField({ integer: true, initial: 5, min: 0 }),
    max:           new fields.NumberField({ integer: true, initial: 5, min: 0 }),
    mod:           new fields.NumberField({ integer: true, initial: 0 }),
    level:         new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    recoveryType:  new fields.StringField({ initial: 'physical', choices: ['physical', 'magical'] }),
  })
}

/**
 * ActionPoints block (11 fields). v0.14.0 added defenseValue/defenseMax for
 * defensive-only AP pool (granted by Combat Stance Defensive ability).
 * Combat Stance Offensive grants attackValue; Combat Stance Balanced grants
 * regular value (unrestricted).
 */
export function makeActionPoints () {
  return new fields.SchemaField({
    value:         new fields.NumberField({ integer: true, initial: 0 }),
    max:           new fields.NumberField({ integer: true, initial: 0 }),
    reactValue:    new fields.NumberField({ integer: true, initial: 0 }),
    reactMax:      new fields.NumberField({ integer: true, initial: 0 }),
    attackValue:   new fields.NumberField({ integer: true, initial: 0 }),
    attackMax:     new fields.NumberField({ integer: true, initial: 0 }),
    defenseValue:  new fields.NumberField({ integer: true, initial: 0 }),
    defenseMax:    new fields.NumberField({ integer: true, initial: 0 }),
    mod:           new fields.NumberField({ integer: true, initial: 0 }),
    reactMod:      new fields.NumberField({ integer: true, initial: 0 }),
  })
}

/**
 * Simple {value, max} resource pairs used by tempHP, luckPoints, sanity, res5.
 */
export function makeResourcePair (initialValue = 0, initialMax = 0) {
  return new fields.SchemaField({
    value:  new fields.NumberField({ integer: true, initial: initialValue }),
    max:    new fields.NumberField({ integer: true, initial: initialMax }),
  })
}

export { STAT_KEYS }
