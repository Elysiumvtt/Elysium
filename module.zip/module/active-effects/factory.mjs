/**
 * Elysium Active Effect Factory
 *
 * Creates standardised Active Effects for:
 *   - Conditions (Bleeding, Stunned, Frozen, etc.)
 *   - Wound penalties (cumulative)
 *   - Buffs and boons
 *   - Debuffs and afflictions
 *   - Aura effects
 *
 * AE flags structure:
 *   flags.elysium = {
 *     group:         'condition.Stunned' | 'wound' | 'aura' | etc.
 *     condition:     'stunned' (machine name)
 *     ongoing:       boolean (applies per round)
 *     duration:      { rounds, minutes, hours, days }
 *     bleedRate:     number (HP loss per round)
 *     ongoingDamage: { amount, source }
 *     stacking:      'best' | 'cumulative' | 'replace'
 *   }
 */

import { ELYSIUM } from '../config/config.mjs'

export class ElysiumActiveEffectFactory {

  /**
   * Create a condition AE on an actor.
   * Defaults to "best of" stacking — multiple sources of the same
   * condition do not stack except for the Wound group.
   */
  static async applyCondition (actor, conditionName, options = {}) {
    const M = ELYSIUM.MODULE_ID
    const group = `condition.${conditionName}`

    // Check existing same-group effects
    const existing = actor.effects.filter(e =>
      e.flags?.elysium?.group === group
    )

    // Wound condition is cumulative; others use best-of (skip if exists)
    if (conditionName !== 'Wound' && existing.length > 0) {
      // Update best-of: keep the more severe one if applicable
      const stacking = options.stacking || 'best'
      if (stacking === 'best') return null    // skip
      if (stacking === 'replace') {
        await actor.deleteEmbeddedDocuments('ActiveEffect',
          existing.map(e => e.id))
      }
    }

    const aeData = this._buildConditionAE(conditionName, options)
    aeData.flags.elysium.group = group

    return await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }

  static _buildConditionAE (conditionName, options) {
    const def = CONDITION_DEFINITIONS[conditionName] || {}

    return {
      name: conditionName,
      icon: def.icon || 'icons/svg/aura.svg',
      duration: options.duration || def.duration || {},
      changes: this._buildChanges(conditionName, def, options),
      flags: {
        elysium: {
          condition:     def.machineName || conditionName.toLowerCase(),
          ongoing:       def.ongoing || false,
          bleedRate:     options.bleedRate || def.bleedRate,
          ongoingDamage: options.ongoingDamage || def.ongoingDamage,
          stacking:      options.stacking || def.stacking || 'best',
          fromSource:    options.source || 'manual',
        }
      },
      disabled: false,
      transfer: false,
    }
  }

  static _buildChanges (conditionName, def, options) {
    const changes = []

    if (def.skillModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.allSkills',
        mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
        value: String(def.skillModifier),
      })
    }
    if (def.apModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.apPenalty',
        mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
        value: String(Math.abs(def.apModifier)),
      })
    }
    if (def.moveModifier) {
      changes.push({
        key:   'flags.elysium.modifiers.moveModifier',
        mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
        value: String(def.moveModifier),
      })
    }
    if (def.statModifiers) {
      for (const stat in def.statModifiers) {
        changes.push({
          key:   `system.stats.${stat}.effects`,
          mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
          value: String(def.statModifiers[stat]),
        })
      }
    }
    return changes
  }


  /**
   * Remove a condition by name
   */
  static async removeCondition (actor, conditionName) {
    const group = `condition.${conditionName}`
    const ids = actor.effects
      .filter(e => e.flags?.elysium?.group === group)
      .map(e => e.id)
    if (ids.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', ids)
    }
  }


  /**
   * Apply a wound penalty (cumulative across all wound sources)
   */
  static async applyWoundPenalty (actor, severity, locationName) {
    let apPenalty = 0
    let skillPenalty = 0

    switch (severity) {
      case 'wounded':           apPenalty = 0; skillPenalty = 0; break
      case 'severelyWounded':   apPenalty = 0; skillPenalty = -20; break
      case 'criticallyWounded': apPenalty = 1; skillPenalty = -40; break
      case 'severed':           apPenalty = 1; skillPenalty = -40; break
    }

    if (apPenalty === 0 && skillPenalty === 0) return null

    const aeData = {
      name: `${locationName} - ${severity}`,
      icon: 'icons/svg/blood.svg',
      changes: [
        { key: 'flags.elysium.modifiers.apPenalty', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: String(apPenalty) },
        { key: 'flags.elysium.modifiers.allSkills', mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: String(skillPenalty) },
      ],
      flags: {
        elysium: {
          group:    'wound',
          location: locationName,
          severity: severity,
          stacking: 'cumulative',
        }
      },
      disabled: false,
      transfer: false,
    }

    return await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }
}


// Definitions for all standard conditions
const CONDITION_DEFINITIONS = {
  // Physical
  Staggered: {
    machineName: 'staggered',
    icon: 'icons/svg/daze.svg',
    apModifier: -1,
    duration: { rounds: 1 },
    stacking: 'best',
  },
  Stunned: {
    machineName: 'stunned',
    icon: 'icons/svg/daze.svg',
    skillModifier: -40,
    apModifier: -1,
    duration: { rounds: 1 },
    stacking: 'best',
  },
  Prone: {
    machineName: 'prone',
    icon: 'icons/svg/falling.svg',
    skillModifier: -20,
    moveModifier: -10,
    stacking: 'best',
  },
  Entangled: {
    machineName: 'entangled',
    icon: 'icons/svg/net.svg',
    skillModifier: -20,
    moveModifier: -15,
    stacking: 'best',
  },
  Rooted: {
    machineName: 'rooted',
    icon: 'icons/svg/net.svg',
    moveModifier: -100,
    stacking: 'best',
  },
  Paralysed: {
    machineName: 'paralysed',
    icon: 'icons/svg/paralysis.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },
  Unconscious: {
    machineName: 'unconscious',
    icon: 'icons/svg/sleep.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },
  Dying: {
    machineName: 'dying',
    icon: 'icons/svg/blood.svg',
    apModifier: -99,
    moveModifier: -100,
    ongoing: true,
    stacking: 'best',
  },
  Dead: {
    machineName: 'dead',
    icon: 'icons/svg/skull.svg',
    apModifier: -99,
    moveModifier: -100,
    stacking: 'best',
  },

  // Bleeding
  Bleeding: {
    machineName: 'bleeding',
    icon: 'icons/svg/blood.svg',
    ongoing: true,
    bleedRate: 1,
    stacking: 'best',
  },
  'Arterial Bleeding': {
    machineName: 'arterialBleeding',
    icon: 'icons/svg/blood.svg',
    ongoing: true,
    bleedRate: 3,
    stacking: 'best',
  },

  // Environmental / damage
  Burning: {
    machineName: 'burning',
    icon: 'icons/svg/fire.svg',
    ongoing: true,
    ongoingDamage: { amount: 2, source: 'Burning' },
    stacking: 'best',
  },
  Frozen: {
    machineName: 'frozen',
    icon: 'icons/svg/frozen.svg',
    moveModifier: -50,
    skillModifier: -20,
    stacking: 'best',
  },
  Frostbitten: {
    machineName: 'frostbitten',
    icon: 'icons/svg/frozen.svg',
    skillModifier: -20,
    stacking: 'best',
  },
  Shocked: {
    machineName: 'shocked',
    icon: 'icons/svg/lightning.svg',
    apModifier: -99,
    duration: { rounds: 1 },
    stacking: 'best',
  },
  Suffocating: {
    machineName: 'suffocating',
    icon: 'icons/svg/lungs.svg',
    ongoing: true,
    stacking: 'best',
  },

  // Mental
  Fear: {
    machineName: 'fear',
    icon: 'icons/svg/terror.svg',
    skillModifier: -20,
    stacking: 'best',
  },
  Terror: {
    machineName: 'terror',
    icon: 'icons/svg/terror.svg',
    skillModifier: -40,
    stacking: 'best',
  },
  Charmed: {
    machineName: 'charmed',
    icon: 'icons/svg/heart.svg',
    stacking: 'best',
  },
  Dominated: {
    machineName: 'dominated',
    icon: 'icons/svg/eye.svg',
    stacking: 'best',
  },
  Silenced: {
    machineName: 'silenced',
    icon: 'icons/svg/mute.svg',
    stacking: 'best',
  },
  Blinded: {
    machineName: 'blinded',
    icon: 'icons/svg/blind.svg',
    skillModifier: -40,
    stacking: 'best',
  },
  Deafened: {
    machineName: 'deafened',
    icon: 'icons/svg/deaf.svg',
    stacking: 'best',
  },
  Invisible: {
    machineName: 'invisible',
    icon: 'icons/svg/invisible.svg',
    stacking: 'best',
  },

  // Beneficial
  Hasted: {
    machineName: 'hasted',
    icon: 'icons/svg/clockwork.svg',
    apModifier: 1,
    moveModifier: 15,
    stacking: 'best',
  },
  Blessed: {
    machineName: 'blessed',
    icon: 'icons/svg/holy.svg',
    skillModifier: 10,
    stacking: 'best',
  },
  Stoneskin: {
    machineName: 'stoneskin',
    icon: 'icons/svg/shield.svg',
    stacking: 'best',
  },
  Regenerating: {
    machineName: 'regenerating',
    icon: 'icons/svg/regen.svg',
    ongoing: true,
    stacking: 'best',
  },
}
