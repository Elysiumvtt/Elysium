# Changelog

All notable changes to the Elysium rules module will be documented in this file.

## [0.1.0] — 2026-05-01

### Initial Release

Complete framework implementation for the Elysium ruleset on the BRP system.

### Architecture
- Three-package layout: ElysiumBRP (system fork) + Elysium (this module) + ElysiumCompendium (content)
- This module reads Elysium item data via `ElysiumData` helper, supporting both `system.elysium.*` (ElysiumBRP fork) and `flags.elysium.*` (stock BRP fallback)

#### Combat
- Action Points system (INT+DEX based pool, refreshed each combat round)
- Wound thresholds (Wounded / Severely Wounded / Critically Wounded / Severed)
- Critical wound tables (Head / Arm / Body / Leg / Tail-Wing / Aquatic) with built-in fallback data
- Mythras-style Special Effects (differential success-based)
- Mythras Healing Rate (CON-based, 1-5)
- Mythras Fatigue system (10 levels with merge rules)
- Armour layering (Natural / Flexible / Inflexible) with 10 AP cap on worn armour
- Luck Points (2 + POW bonus, full recovery per session)
- Shield passive blocking
- Initiative formula (1d10 + bonus - armour penalty)

#### Magic — All Five Systems
- **Arcane**: Schools / Techniques / Forms / Success Levels / MP allocation / overcasting / school efficiency / scrolls / permanent runes
- **Sorcery**: Three primary essences + confluence, ability growth thresholds (Nascent → Transcendent), restricted essences (Death/Void/Corruption/Chaos)
- **Divine/Patron**: Channel skill, domain spells, patron standing affecting recovery, prayer rituals
- **Mysticism**: Activation rolls only when ability IS the action, meditation recovery
- **Superpowers/Passives**: No-cost conditional/always-on abilities, Favoured Enemy tier progression
- All systems share single PP pool (POW score)
- Armour casting penalty applies to Arcane and Sorcery; Divine and Mysticism exempt

#### Character
- 4D6 drop lowest stat rolling (default; configurable to other methods)
- EXP Dice advancement system (gamble: 1 die + 3D6 vs current; guaranteed: dice equal to current score)
- Stat natural maximum adjusted by ancestry modifiers
- 70% starting skill cap (configurable)
- Profession packages (4 primary + 6 secondary + 2 bonus skills)
- Ancestry drag-drop with subrace dialog
- Combination ancestry support (TP trade-off)
- Mutations and Superpowers as item types
- Vision types (Low-Light/Infravision/Darkvision via Mutation; Blindsight/Truesight via Superpower)

#### Settings
- Master Enable toggle
- 27 individual rule toggles
- Stat roll method selector
- Ancestry terminology selector (Culture/Ancestry/Race/Species)
- EXP advancement timing selector
- Display options (difficulty grade names, fatigue display)

#### Active Effects
- Standard condition AE factory (30+ conditions defined)
- Wound penalty AEs (cumulative stacking)
- Group-based stacking ('best' / 'cumulative' / 'replace')
- Ongoing damage processing (Bleeding, Burning, etc.)

#### UI
- Action Point pip display
- Fatigue meter
- Luck Points display
- Casting penalty breakdown tooltip
- Elysium fields on Weapon, Armour, and Culture (Ancestry) item sheets
