// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { aeModeLabel } from '../shared.mjs'

export function injectItemModifiersIntoEffectsTab (html, actor) {
    const tab = html.querySelector('.tab.effects') || html.querySelector('[data-tab="effects"]')
    if (!tab) return
    if (tab.querySelector('.elysium-item-modifiers')) return    // already injected

    // Collect every item-modifier AE across all items on this actor
    const grouped = new Map()    // item.id -> { item, aes: [] }
    for (const item of actor.items) {
      const aes = item.effects?.contents?.filter(ae =>
        ae.flags?.['elysium']?.itemModifier === true
      ) || []
      if (aes.length === 0) continue
      grouped.set(item.id, { item, aes })
    }

    const section = document.createElement('div')
    section.className = 'elysium-item-modifiers'

    if (grouped.size === 0) {
      section.innerHTML = `
        <div class="elysium-item-modifiers-header">
          ${game.i18n.localize('Elysium.Modifiers.SectionTitle') || 'Worn Item Modifiers'}
        </div>
        <div class="elysium-item-modifiers-empty">
          ${game.i18n.localize('Elysium.Modifiers.NoneOnActor') || 'No item modifiers — equip items with modifier effects to see them here.'}
        </div>
      `
      tab.appendChild(section)
      return
    }

    // Build rows. AEs are tagged `disabled` reflecting the item's equip
    // state (synced by updateItem hook); show active/inactive icon.
    const rowsHtml = Array.from(grouped.values()).flatMap(({ item, aes }) =>
      aes.map(ae => {
        const change = ae.changes?.[0] || {}
        const presetKey = ae.flags?.['elysium']?.presetKey
        const preset    = presetKey ? ELYSIUM.MODIFIER_PRESETS[presetKey] : null
        const label     = ae.flags?.['elysium']?.modifierLabel
                       || preset?.label
                       || (change.key || '').split('.').pop()
                       || 'Modifier'
        const modeStr = aeModeLabel(change.mode)
        const value   = change.value ?? '0'
        const isActive = !ae.disabled
        const activeIcon = isActive
          ? `<i class="fas fa-person-rays" data-tooltip="${game.i18n.localize('Elysium.active')}"></i>`
          : `<i class="fas fa-person-rays fade" data-tooltip="${game.i18n.localize('Elysium.inactive')}"></i>`

        return `
          <div class="elysium-mod-row">
            <span class="elysium-mod-source" title="${item.name}">${item.name}</span>
            <span class="elysium-mod-effect" title="${change.key || ''}">${label}</span>
            <span class="elysium-mod-amount">${modeStr === 'Add' ? value : `${value} (${modeStr})`}</span>
            <span class="elysium-mod-active">${activeIcon}</span>
          </div>
        `
      })
    ).join('')

    section.innerHTML = `
      <div class="elysium-item-modifiers-header">
        ${game.i18n.localize('Elysium.Modifiers.SectionTitle') || 'Worn Item Modifiers'}
      </div>
      <div class="elysium-mod-grid">
        <div class="elysium-mod-grid-header">
          <span>${game.i18n.localize('Elysium.sourceItem') || 'Source Item'}</span>
          <span>${game.i18n.localize('Elysium.effect') || 'Effect'}</span>
          <span>${game.i18n.localize('Elysium.amount') || 'Amount'}</span>
          <span>${game.i18n.localize('Elysium.active') || 'Active'}</span>
        </div>
        ${rowsHtml}
      </div>
    `
    tab.appendChild(section)
  }
