# P10 cluster 5 prep audit — skill body + weapon → alpha.43

**Status**: PROPOSAL. Awaiting user confirmation per project rule "audit-then-stop per cluster".

After this cluster lands, **22/23 item types** are on v1.0.0 (95%); only career remains (cluster 6 → alpha.44).

## Scope summary

Two heterogeneous item types in this cluster — picked together because they're the last two non-spell legacy sheets and each is large enough that splitting them would mean a 3rd small cluster:

1. **Skill** (343 LOC sheet + 223 LOC template). Owns the most complex drag/drop on item sheets: drop a skill onto a Group skill to add it to the group skill list. Has custom form handler that synchronizes name from mainName+specName. **Header was already swapped to v1.0.0 specialism partial in alpha.41 (P10 cluster 3b, c3b-4)** — only the detail body needs migration. Sheet should fold onto `ElysiumDragDropItemSheet` base (cluster-3b intermediate) — preserves drag/drop boilerplate while reusing its hoists.

2. **Weapon** (191 LOC sheet + 341 LOC template). The largest item template in the system (~67 DataModel fields). NO drag/drop. Has active-effect editing (binds `ElysiumActiveEffectSheet.activateListeners`). Mythras Size / Reach / Force fields already migrated to natively-rendered elements (per `injectWeaponFields` comment "v0.5.3+: native rendering"). Sheet uses base `ElysiumItemSheetV2` — no intermediate base class needed.

## Pre-flight inventory

| | Skill | Weapon |
|---|---|---|
| Sheet LOC | 343 | 191 |
| Template LOC | 223 | 341 |
| DataModel LOC | 103 | 152 |
| Has drag/drop | yes — `[data-drag]` → `.droppable` | no |
| Has form handler | yes — `mySkillHandler` (name composition) | no |
| Has `_onRender` listeners | yes — `item-delete`, `item-view` | yes — `ElysiumActiveEffectSheet.activateListeners` |
| Header part | `parts/item-shell-header-specialism.hbs` (cluster-3b) ✓ | `item.header.hbs` (LEGACY) |
| TAB_ORDER state | overrides `_configureRenderOptions` per cluster-1+2 pattern | overrides `_configureRenderOptions` per cluster-1+2 pattern |
| Legacy CSS dependency | `css/legacy.css`: `.skill-display`, `.skill-cat`, `.skill-scores` (3 classes) | `css/legacy.css`: `.weapon-scores`, `.weapon-display`, `.weapon-input`, `.weapon-main-scores`, `.weapon-2main-scores` (5 classes) |
| sheet-extension injection | none | `injectWeaponFields` (engagement-info badge + weapon HP + item-modifiers) |

## Decisions to lock

### c5-1 — Skill: full migration onto `ElysiumDragDropItemSheet`?

**Question**: skill currently extends `ElysiumItemSheetV2` (base) and copies ~62 LOC of drag/drop boilerplate inline. cluster 3b's `ElysiumDragDropItemSheet` was explicitly designed to amortize this — comment in `base-dragdrop-item-sheet.mjs` says "will be reused by skill in cluster 5".

**Options**:
- **A (recommended)**: extend `ElysiumDragDropItemSheet`. Removes ~62 LOC of drag/drop boilerplate, ~10 LOC of `_onItemDelete`/`_onItemView` (inherits flavor methods), inherits default `_onRender` wiring.
- **B**: keep extending `ElysiumItemSheetV2` directly. Preserves skill's custom flavors. More code; no precedent reason.

→ **A**, with override of `_onDrop` (skill needs the "Group Skill check" + dup detection that's unique to skill; the cluster-3b default flavors don't cover this).

### c5-2 — Weapon: any base class consolidation?

**Question**: weapon has no drag/drop, no spell-style multi-tier UI. Two other sheets do active-effect editing (armor + super, via `ElysiumActiveEffectSheet.activateListeners`). Worth a base class for AE-aware sheets?

**Options**:
- **A**: hoist `ElysiumActiveEffectSheet.activateListeners(this)` into a small intermediate class `ElysiumAEAwareItemSheet`. Reuses: weapon, armor, super (3 sheets). Saves ~3 LOC × 3 = ~9 LOC. Adds ~30 LOC base class.
- **B (recommended)**: keep extending `ElysiumItemSheetV2`. The hoist isn't worth a base class for 3 LOC × 3 sheets; AE is a generic per-sheet concern, not a sheet-shape concern.

→ **B**. No intermediate base for AE-handling.

### c5-3 — Skill detail body shape (v1.0.0 rebuild)

**Question**: skill detail body has two distinct modes — single-skill (most skills, ~107 of 107 compendium) and group-skill (a single grouped-skills container). What partials does it need?

**Skill detail content** (single-skill mode):
1. Skill group dropdown (Standard/Career/Combat/Magic — drives character-sheet section grouping)
2. Category + (optional) weapon subtype (BRP modifier label)
3. Subgroup (magic tradition for arcane/sorcery/divine/mysticism skills)
4. Options chip row (noXP, specialism, variable, group, basic, chosen, combat)
5. Stat formula 2-row grid (rule1 stat + value; rule2 stat + value + Func)
6. Score breakdown (base + xp + career + personal + personality + culture + effects + total)

**Skill detail content** (group-skill mode):
1. Skill group dropdown (same as above)
2. Options chip row (same)
3. Dropped-skills list with delete controls + read-only name+base display

**Reused partials**:
- `item-toggle-row.hbs` — 7 option chips → 7-element `flagChips` array. ✓ Already shared.
- `item-skill-row.hbs` — cluster-3b partial; suitable for the dropped-skills list. ✓
- `item-field-row.hbs` + `item-field-grid.hbs` — for the dropdown fields. ✓
- `item-shell-header-specialism.hbs` — already on skill since alpha.41. ✓

**New partials needed**: none. All needed partials already exist from cluster 1+3b+4.

**Header chip plan**: `itemHeaderChips` array — 3 chips:
- `{label: 'Group', value: <Standard/Career/Combat/Magic or '—'>}`
- `{label: 'Category', value: <localized BRP category>}`
- `{label: 'Subgroup', value: <Arcane School / Sorcery Essence / etc. or '—'>}`

→ **Approve**.

### c5-4 — Weapon detail body shape (v1.0.0 rebuild)

**Question**: weapon's 341-line template is the densest in the system. What's its structural shape under v1.0.0?

**Weapon detail content** (5 logical groups, ~67 fields total):
1. **Damage** group (3 dmg formulas + 4 range bands)
2. **Type/Skills** group (weaponType + skill1 + skill2 + dmg bonus + special + hands)
3. **Attack/Special** group (att + radius + crew)
4. **HP/AP** group (ap + hpCurr + STR + DEX requirements + ROF + ammoType + ammo + ammoCurr + mal + parry + price + cost + enc + npcVal + pSCurr + pSMax + coverage + quantity)
5. **Damage type flags** group (15 boolean flags: burst, stun, entangle, explosive, fire, pierce, sonic, choke, cold, emp, poison, disease, acid, constrict, spclDmg)
6. **Mythras Elysium fields** (already native): weaponSize, reach, force, isMelee, damageType, thrownPenalty, reloadType, damageBonusMultiplier

**Reused partials**:
- `item-toggle-row.hbs` — 15 damage-type chips → 15-element `flagChips` array. ✓
- `item-field-row.hbs` + `item-field-grid.hbs` — for all the named fields. ✓
- `item-shell-header.hbs` — standard header. ✓
- NEW partial proposed: `item-stat-grid.hbs` — for the dense numeric stat blocks (label + value + label + value × N). Each cell is `(label, value, name=binding-path, type=number|text)`. Replaces the 2-column / 5-column grid patterns currently inline in weapon + skill scores section.

Actually wait — let me NOT add a new partial. The existing `item-field-row.hbs` (1 label + 1 input/display) covers it once the template is restructured into vertical groups instead of horizontal grids. v1.0.0 sheets across the board favor vertical field-rows over dense grids (see armor as the reference). This dovetails with the "no new partials in this cluster" plan.

→ **Approve** with the no-new-partials plan. Restructure weapon body to vertical field-rows organized into labeled section cards.

**Header chip plan**: `itemHeaderChips` array — 4 chips:
- `{label: 'Weapon Type', value: <melee/ranged/—>}`
- `{label: 'Size', value: <S/M/L>}`
- `{label: 'Reach', value: <T/S/M/L/VL/H>}`
- `{label: 'Damage', value: <dmg1 formula>}` (omit if blank/0)

→ **Approve**.

### c5-5 — Damage-type flag chips for weapon

15 flag chips for damage types. Each is a boolean toggle (e.g., `system.burst`, `system.fire`, `system.cold`). Use `itemToggle` action with `data-property-path="system.<flag>"`.

Note: this is the FIRST consumer of `item-toggle-row.hbs` with **flat property paths** (not `system.elysium.`). The cluster 4 itemToggle fix is forward-compatible: `data-property-path` is read verbatim, no path-shape assumption. ✓

→ **Approve**.

### c5-6 — Legacy CSS retirement (skill + weapon)

After both sheets are rebuilt:

**Skill legacy classes to retire** from `css/legacy.css`:
- `.skill-display`, `.skill-cat`, `.skill-scores` — sole consumer is skill.detail.hbs; gone after rebuild.

**Weapon legacy classes to retire** from `css/legacy.css`:
- `.weapon-scores`, `.weapon-display`, `.weapon-input`, `.weapon-main-scores`, `.weapon-2main-scores` — sole consumer is weapon.detail.hbs; gone after rebuild.

**Pre-flight grep gate**: before deletion, `grep` confirms ZERO remaining `.hbs`/`.mjs` references. Same retirement protocol as cluster 4 (171 lines deleted).

Estimated legacy.css line count delta: roughly -120 to -180 lines depending on the actual rules.

→ **Approve**.

### c5-7 — Shared classes that survive

These classes are used by skill + weapon but **also other surviving consumers** — preserve in legacy.css:
- `.base-grid`, `.options-grid`, `.item-list`, `.item-name`, `.item-controls`, `.item-control`, `.item-delete`, `.item-view`, `.item-title`, `.stat-input`, `.stat-display`, `.hitloc-display`, `.gear-display-plain`

Verify pre-flight: grep across all remaining template files to confirm no other survivors will break. The legacy.css retirement is *only* the 8 classes that uniquely belong to skill+weapon.

→ **Approve**.

### c5-8 — Sheet-extension `injectWeaponFields` interaction

`injectWeaponFields` injects engagement-info badge + weapon HP + item-modifiers fieldset into `.tab.details` after weapon render. Three concerns under v1.0.0:

1. **Selector stability**: injection looks for `html.querySelector('.tab.details')`. v1.0.0 weapon detail will keep `class="item tab details ..."` (same as cluster 4 sorcery/arcane). ✓
2. **Engagement-info DOM placement**: injection inserts via DOM API into the detail tab; v1.0.0 layout shouldn't affect this. ✓
3. **Wielded Modifiers fieldset**: same — DOM injection into the detail tab. ✓

→ No changes needed to `injectWeaponFields`. The cluster-4 spell-sheet rebuilds proved that v1.0.0 detail templates preserve `.tab.details` class. Verify post-rebuild via smoke (test step in c5-13).

### c5-9 — Form handler preservation for skill

`mySkillHandler` composes `item.name = mainName + ' (' + specName + ')'` when `specialism=true`, else `name = mainName`. Also synchronizes `groupSkills` on the item for group-skill saves. Both behaviors are still wanted under v1.0.0.

→ **Preserve handler unchanged**. The handler reads `formData.object['system.mainName']` / `system.specName` — these come from the specialism-aware header partial (already in use since alpha.41). v1.0.0 detail body changes don't affect handler.

### c5-10 — Skill _prepareContext rebuild

Sheet's `_prepareContext` builds 7+ dropdown option maps and resolves several display names. Most stays.

**Add**:
- `itemHeaderChips` array (per c5-3): Group / Category / Subgroup
- `flagChips` array (per c5-3): 7 toggle chips for options (noXP/specialism/variable/group/basic/chosen/combat)

**Keep**:
- statOptions, catOptions, wpnOptions, funcOptions, subgroupOptions, skillGroupOptions, skillCategoryOptions
- stat1/stat2/catName/wpnType/funcDisp display names
- grpSkill array (for group-skill mode)

**Drop**:
- inline `itemData.system.total = ...` computation. Move to a getter on the DataModel (P12 work; for now keep in sheet for symmetry with legacy).

→ **Approve plan**.

### c5-11 — Weapon _prepareContext rebuild

Sheet's `_prepareContext` builds 10+ option maps. Restructure for v1.0.0:

**Add**:
- `itemHeaderChips` array (per c5-4): Weapon Type / Size / Reach / Damage
- `flagChips` array (per c5-5): 15 damage-type toggles

**Keep**: existing option-map computations and display-name resolution

**Drop**: `context.npcOwner` is set but apparently used only for one localization path — verify post-rebuild whether it's still referenced.

→ **Approve plan**.

### c5-12 — i18n key additions

New keys needed (estimate):
- Skill header chips: 3 labels (already exist as cat names) → 0 new
- Skill flag chip tooltips: 7 chips × (label + tooltip) — labels mostly already exist (`Elysium.noXP`, `Elysium.specialism`, etc.); tooltips already exist → 0 new
- Weapon header chips: `Elysium.weaponType`, `Elysium.size` (new), `Elysium.reach`, `Elysium.damage` → ~1 new × 3 langs = 3 entries
- Weapon damage-type flag labels: 15 flags — most have existing keys (`Elysium.fire`, `Elysium.cold`, etc.); a few may need `Elysium.burst`, `Elysium.choke`, `Elysium.emp`, `Elysium.entangle`, `Elysium.constrict`, `Elysium.spclDmg` → ~5-7 new × 3 langs = 15-21 entries
- Section card titles: `Elysium.weaponDamageSection`, `Elysium.weaponTypeSection`, `Elysium.weaponHPSection`, `Elysium.weaponFlagsSection`, `Elysium.skillScoresSection`, `Elysium.skillOptionsSection` → 6 new × 3 langs = 18 entries

Total estimate: **~25-30 new keys × 3 langs = ~75-90 entries**.

→ **Approve**.

### c5-13 — Smoke checklist for alpha.43

Tests in order (each must pass before next):

| # | Test |
|---|---|
| a | Game loads cleanly with no system errors logged |
| b | Skill sheet opens; v1.0.0 header chips render (3 chips); options chip row works (clicking flips DataModel field) |
| c | Skill in `group=true` mode shows the group-skills list, not the score grid; in `specialism=true` shows main/spec name fields in header |
| d | Skill drag/drop: drag a skill from compendium onto a group-skill's drop zone; the skill appears in the group list |
| e | Skill sheet's form-handler still composes `item.name` correctly when toggling specialism |
| f | Skill score breakdown renders correctly for owned-by-character skill (with all 7 contribution fields) |
| g | Weapon sheet opens; v1.0.0 header chips render (4 chips); damage-flag chip row works |
| h | Weapon damage formulas (dmg1/dmg2/dmg3) render and save |
| i | Weapon's Wielded Modifiers fieldset still injects (sheet-extension `injectWeaponFields` ran) |
| j | Weapon's engagement-info badge appears when actor is engaged with the weapon (only if test world has combat state) |
| k | Console clean of system-level errors after all the above |
| l | Closing+reopening sheets doesn't accumulate event listeners (no double-click bugs) |
| m | After legacy.css retirement: no broken styling on any OTHER surviving template (sweep gear / armor / passion / reputation / etc.) |
| n | Adding to header chip presence to smoke: each cluster-3a/3b/4 sheet's chip zone still has its v1.0.0 header (regression check from alpha.42 bug #2) |

→ **Approve**.

## Cumulative deliverables

After cluster 5 (alpha.43):

- **Sheets rebuilt**: 21 of 23 item types on v1.0.0 (91%). Career remains (cluster 6 → alpha.44).
- **LOC reduction estimate**: skill 343 → ~190 (-153 -45%) by folding onto `ElysiumDragDropItemSheet`; weapon 191 → ~150 (-41 -21%) by simplifying _prepareContext (no shape change to base class); templates reduce ~30-40% via partial reuse. Subtotal: -200 to -250 sheet LOC + -150 to -200 template LOC.
- **CSS retirement**: ~120-180 lines from `css/legacy.css` (8 skill+weapon classes).
- **i18n additions**: ~25-30 new keys × 3 langs.
- **No new shared partials**: cluster 1+3b+4 partials cover all needed shapes.

## Risks identified

1. **Skill drag/drop regression**: cluster-3b base class's `_onDrop` doesn't cover skill's group-check logic. Override per c5-1 must preserve duplicate-detection and "group-skill can't be added to main list" warning. Fix: keep skill's `_onDrop` as override; don't inherit base flavor.

2. **Weapon sheet-extension dependency**: any subtle DOM-shape change to weapon detail might break `injectWeaponFields` or `injectEngagementInfo`. Mitigation: preserve `.tab.details` class on root section + smoke test j explicitly.

3. **Legacy.css retirement breaking other consumers**: if `.skill-display` is used in any actor template or chat card we missed, retirement breaks it. Mitigation: pre-flight `grep` gate before deletion (per c5-6).

4. **Active-effect editing for weapon**: weapon currently has an `effects` PART rendered by `item.active-effects.hbs`. Need to verify cluster-5 weapon still surfaces this part. Plan: keep `effects` in PARTS + TAB_ORDER; reuse `parts/item-shell-effects.hbs` (cluster-3a partial) and drop the legacy `item.active-effects.hbs`.

## Open questions

None — all 13 decisions have a recommended answer above. User confirms or pushes back on any.

## Next steps (after approval)

1. Add full TAB_ORDER + parts plumbing for skill + weapon (matching cluster 4 form)
2. Rewrite weapon.mjs + sorcery.detail.hbs equivalent for weapon
3. Rewrite skill.mjs + skill.detail.hbs onto `ElysiumDragDropItemSheet`
4. Pre-flight grep gate for legacy.css retirement
5. Pre-flight sweep (CSS brace + Handlebars block + node --check + lang parity)
6. Package alpha.43 + smoke a→n
