# P11 Cluster 4 prep audit — chat micro-cards (XP-result / rollStats / itemDescription)

**Status**: PENDING
**Target alpha**: alpha.48
**Scope**: 3 chat templates — `XP-result.html`, `rollStats.html`, `itemDescription.html`. Smallest cluster of P11 by LOC.
**Inheritance from**: P11 prep audit, cluster 1 audit, cluster 2 audit, cluster 3 audit, and the 6 chat partials shipped in clusters 1+2.

After alpha.48, **11 of 11 legacy chat-card templates** (100%) are on v1.0.0. P11's chat-card scope closes; remaining P11 work is cluster 5 (generic dialogs in `templates/dialog/`).

---

## 1. Current-state inventory

### Template sizes

| Template | LOC | Surface |
|---|---|---|
| `XP-result.html` | 18 | XP-tick result (posted when a player succeeds at a skill check) |
| `rollStats.html` | 12 | Character-creation opening stats roller (3d6 × 7 stats) |
| `itemDescription.html` | 5 | "Post item description to chat" feature on every item sheet |
| **Total** | **35** | — |

Cluster 4 is the smallest cluster in P11 by far — the legacy templates total 35 LOC, less than cluster 2's `chat-card-grouproll.hbs` partial (151 LOC) by itself.

### Per-template structural diff vs cluster-1/2/3 cards

Cluster 4 cards share NONE of the structural traits the other clusters share:

- **No `chatCard` array** — these cards don't iterate participants at all. The data shape is flat (XP-result uses `success` array of skill records; rollStats uses `results` array of stat records; itemDescription is just two strings).
- **No participant portrait pattern** — XP-result and rollStats show ONE actor portrait at the top of the card (the rolling actor), not per-participant.
- **No pip strip** — XP-result shows a single icon (certificate or skull) per skill row indicating success or fail of XP-tick; rollStats shows no icons.
- **No tooltip block** — these are flat results, no owner-only expand-tooltip needed.
- **No buttons** — read-only result cards.
- **No `gr-card` class on XP-result + rollStats** — Phase D mount-point unused on these (they're not combat surfaces).
- **`itemDescription.html` does have `gr-card`** — preserved as a class hook for hook-contract uniformity, though Phase D injection filters on `rollType === 'CM'` and these have no rollType so never trigger.

The cluster-1 partials don't apply to any of these three cards. The shapes are too card-specific to compose via the participant-row / tooltip-rows / shell / resolve-footer partials.

### Per-template variation

**`XP-result.html`** (line-by-line read):
```hbs
<form class="elysium">
  <div class="dice-roll">
    <div class="font14" style="display: block">
      <div class="XPCheck bold"> {{localize 'Elysium.xpRoll'}}</div>
      <img class="open-actor" src="{{actrImage}}" height="60" width="60" />
      {{#each success as | line key|}}
        <div class="flavour-result" style="padding-left: 10px">
          {{line.name}} ({{line.score}}-{{line.diceRoll}})
          {{#if (eq line.level 1)}}
            +{{improvVal}}
            <i class="result-success fas fa-certificate"></i>
          {{else}}
            <i class="result-fail fas fa-skull"></i>
          {{/if}}
        </div>
      {{/each}}
    </div>
  </div>
</form>
```

- Title: `Elysium.xpRoll`
- Portrait: single, top
- Body: list of skill rows `{name} ({score}-{diceRoll}) [+improvVal][icon]`
- Inline styles: 2 (`display: block` on font14 wrapper, `padding-left: 10px` on each skill row)
- Class hooks (legacy CSS-only, no JS): `XPCheck`, `bold`, `font14`, `flavour-result`, `dice-roll`, `open-actor`, `result-success`, `result-fail`

**`rollStats.html`** (line-by-line read):
```hbs
<form class="elysium">
  <div class="dice-roll">
    <div class="font14" style="display: block">
      <div class="XPCheck bold"> {{localize 'Elysium.rollStats'}}</div>
      <img class="open-actor" src="{{actrImage}}" height="60" width="60" />
      {{#each results as | line key|}}
        <div class="flavour-result" style="padding-left: 10px">
          {{line.label}} ({{line.formula}}: {{line.diceRolled}}) = {{line.result}}
        </div>
      {{/each}}
    </div>
  </div>
</form>
```

- **Structurally near-identical to XP-result** — same outer shell (form/dice-roll/font14/XPCheck-header), same portrait, same iteration shape. The difference is per-row content (no success/fail icon; instead "formula: diceRolled = result").
- Title: `Elysium.rollStats`
- Inline styles: same 2
- Class hooks: same as XP-result minus `result-success`/`result-fail`

**`itemDescription.html`** (line-by-line read):
```hbs
<form class="elysium gr-card">
  <div class="">
    <div class="bold">{{label}}</div>
    <div class='name'>{{{description}}}</div>
  </div>
</form>
```

- Title: `{{label}}` (item.name)
- Body: `{{{description}}}` triple-stash to render embedded HTML
- No portrait, no list, no rows
- Class hooks: `gr-card`, `bold`, `name`

### Legacy CSS inventory

- **`.elysium .XPCheck`** (`css/legacy.css:1340`): `background: rgba(0,0,0,0.25); border: 1px solid black; border-radius: 3px; padding-left: 5px;` — the "boxed list header" styling.
- **`.elysium .font14`** (`css/legacy.css:501`): `font-size: 14px;` — generic.
- **`.elysium .character .font14`** (`css/legacy.css:505`): different size when nested in an actor sheet. Not consumed by chat cards.
- **`.flavour-result`** — NO CSS RULE EXISTS. The class is a hook with zero styling; only the inline `padding-left: 10px` does the work.
- **`.bold`** — generic utility, `font-weight: bold` somewhere.
- **`.name`** — used by itemDescription. May or may not have styling.

### JS callsites

- `XP-result.html` → `module/apps/charDev.mjs:144` (one consumer, simple `renderTemplate` + `ChatMessage.create`).
- `rollStats.html` → `module/actor/sheets/base-actor-sheet.mjs:316` (one consumer, character-creation roll-stats button).
- `itemDescription.html` → `module/apps/utilities.mjs:237` (one consumer, "post description" item-sheet action).

All three are simple renderTemplate-then-ChatMessage-create flows. No data-shape changes needed.

---

## 2. JS-imperative class-hook contract — cluster-4 surface

Nothing JS-imperative on cluster 4. The only JS hooks across these 3 templates:
- `open-actor` — Foundry built-in click handler that opens the actor sheet. Preserved on the img element.

Everything else (`XPCheck`, `font14`, `flavour-result`, `bold`, `name`, `dice-roll`, `gr-card`) is a CSS-only hook. Phase D never targets these cards (no `rollType === 'CM'` filter match). Audit-5 lock applies only to `open-actor` here.

---

## 3. Architectural decisions for cluster 4

### c4-1: Composition vs new partial vs rebuild

Cluster 1's partials don't apply. Cluster 4's 3 templates share a lot with EACH OTHER (XP-result and rollStats are near-identical) but not with the other 8 chat-card templates.

Options:
- **(A) Build a new shared `chat-card-list.hbs` partial** for the XP-result + rollStats pair (portrait-then-list shape), and a separate one-off `chat-card-static.hbs` partial for itemDescription. Two new partials.
- **(B) Build one shared `chat-card-list.hbs` partial** for XP-result + rollStats; rebuild itemDescription as a 5-LOC template without a partial.
- **(C) Rebuild all three as small standalone templates**, no new partials. The 35 LOC is small enough that partial-composition doesn't save meaningful code.

**Recommendation**: Option B. The XP-result + rollStats pair are near-identical and a shared partial captures the symmetry cleanly. itemDescription is so small (5 LOC) that wrapping it in a partial-composition is pure overhead.

New partial: `chat-card-flat-list.hbs` (the "list" partial name is already conceptually overloaded with `gr-list` — pick a non-conflicting name). Or `chat-card-actor-list.hbs` to emphasize the "actor portrait + list of rows" pattern.

**Recommendation refined**: name the new partial `chat-card-actor-list.hbs`. Its context contract:

```
{
  titleKey: string,           // i18n key for the boxed header
  actorImg: string,           // actor portrait src
  actorName: string,          // actor name (for the open-actor tooltip)
  rows: [{html: string, ...}], // pre-rendered row HTML strings, or...
  // OR a body slot that the calling template fills with {{#each}} iteration:
  body: function,             // Handlebars partial-block style
}
```

The "pre-rendered row HTML" approach requires building HTML strings in JS, which is awkward. The "body slot via partial-block" approach is the cleanest Handlebars pattern — let the calling template pass the iteration body as a block:

```hbs
{{#> "systems/elysium/templates/chat/parts/chat-card-actor-list.hbs"
     titleKey="Elysium.xpRoll" actorImg=actrImage actorName=actrName}}
  {{#each success as |line key|}}
    <div class="elysium-chat-card__row">
      {{line.name}} ({{line.score}}-{{line.diceRoll}})
      {{#if (eq line.level 1)}}
        +{{../improvVal}} <i class="result-success fas fa-certificate"></i>
      {{else}}
        <i class="result-fail fas fa-skull"></i>
      {{/if}}
    </div>
  {{/each}}
{{/}}
```

Handlebars' partial-block syntax (`{{#> name}}...{{/}}`) renders the partial with the block content available as `{{> @partial-block}}` inside the partial. This is supported in Handlebars 4+ which Foundry uses.

Let me verify Foundry's Handlebars version supports partial-blocks. (To be confirmed at code-time; if it doesn't, fall back to option (C) — inline the row markup in each template.)

### c4-2: Marker class + data-card-type for cluster 4

XP-result and rollStats aren't really "card types" in the same way as cluster 1/2/3 cards. They're flat chat messages. But for consistency with the rest of cluster 1-3 work:

- **XP-result**: `data-card-type="XP"` (new card type, no existing collision)
- **rollStats**: `data-card-type="RS"` (new, no collision)
- **itemDescription**: `data-card-type="ID"` (new, no collision)

The `elysium-chat-card` marker class layers alongside `elysium` (and `gr-card` for itemDescription):

- XP-result: `<form class="elysium elysium-chat-card" data-card-type="XP">`
- rollStats: `<form class="elysium elysium-chat-card" data-card-type="RS">`
- itemDescription: `<form class="elysium gr-card elysium-chat-card" data-card-type="ID">`

**Recommendation**: Apply as above. Section D gets 3 new placeholder entries; populate at c4 time.

### c4-3: Section D accents for cluster 4

| Card type | Card | Recommended accent token | Rationale |
|---|---|---|---|
| XP | XP-result | `--ely-accent-success` (green) | Improvement / progress |
| RS | rollStats | `--ely-accent-info` (blue) | Informational / character-creation utility |
| ID | itemDescription | `--ely-accent-bonus` (gold) | Neutral content card |

**Recommendation**: Apply as above.

### c4-4: Inline-style retirement

XP-result and rollStats both have 2 inline styles each:
- `style="display: block"` on the font14 div (cosmetic, `display: block` is the div default — likely redundant; might be a leftover from a prior `display: inline-block` change).
- `style="padding-left: 10px"` on each row (semantic — indents rows below the portrait).

**Recommendation**: Drop the `display: block` (redundant). Move the row indent into a new CSS rule `.elysium-chat-card__row` (or similar) in `elysium-chat.css` Section B. Use `padding-left: var(--ely-space-2)` or `var(--ely-space-3)` (whichever is closest to 10px).

### c4-5: Legacy class hook retirement on cluster 4

Cluster 4 introduces v1.0.0 markup. The legacy class hooks (`XPCheck`, `font14`, `flavour-result`) have no JS consumers; they're CSS-only. Options:

- **(A) Retire all three legacy classes** in cluster 4 — replace with v1.0.0 token-driven CSS. Aggressive but correct.
- **(B) Layer v1.0.0 classes alongside legacy ones** (`<div class="XPCheck elysium-chat-card__title">`) so the legacy `.XPCheck` background-and-border styling still applies until P12 retires it.
- **(C) Drop the legacy classes entirely** since cluster 4 templates are the SOLE consumers — once cluster 4 ships, `XPCheck` has zero callers and can be retired from legacy.css too.

`XPCheck` has zero non-chat-template consumers (verified at audit-time by grep — the class is only used by XP-result.html and rollStats.html in the codebase). After cluster 4, retiring it is safe.

`font14` has actor-sheet consumers (line 505 `.elysium .character .font14`) — KEEP.

`flavour-result` has no CSS rule at all — retire freely (it's a class with no styling, just a semantic marker).

**Recommendation**: Option C — drop `XPCheck` and `flavour-result` from cluster-4 markup; retire the `.elysium .XPCheck` rule from `css/legacy.css` (4 lines removed from a 1640-line file); leave `font14` consumers untouched since it has actor-sheet callers.

This is the first **legacy CSS rule retirement** of P11 (clusters 1-3 retired markup-level inline styles only). Documented as part of the orphaning sweep that the P11 prep audit (c11-13) reserved for P12 — but XPCheck is so isolated it makes sense to retire eagerly here rather than wait.

### c4-6: i18n keys

Existing keys consumed:
- `Elysium.xpRoll` (XP-result title) — verified exists
- `Elysium.rollStats` (rollStats title) — verified exists
- No keys in itemDescription (uses `{{label}}` direct from item.name)

**Zero new i18n keys.**

### c4-7: itemDescription rebuild

itemDescription is 5 LOC. The rebuild adds the `elysium-chat-card` marker + `data-card-type="ID"` and replaces the inner div structure with `__title` + body slot. No partial composition needed.

```hbs
<form class="elysium gr-card elysium-chat-card" data-card-type="ID">
  <div class="elysium-chat-card__title">{{label}}</div>
  <div class="elysium-chat-card__body">{{{description}}}</div>
</form>
```

The `__title` and `__body` BEM-element classes can fall back to the marker rule's typography. CSS rule for `__body` in Section B reserves no specific styling — it's a content slot that inherits from the marker rule. The triple-stash `{{{description}}}` preserves embedded HTML for rich item descriptions.

**Recommendation**: Apply as shown.

### c4-8: Smoke methodology

The 3 cluster-4 cards have minimal variation. Smoke covers:

- **XP-result** × 2 fixtures: success-on-some / fail-on-all (verify icon switching + improvVal display).
- **rollStats** × 1 fixture: 7 stats rolled.
- **itemDescription** × 2 fixtures: plain text description, HTML-formatted description (verify triple-stash preserves markup).

Audit-5 contract checks per fixture:
- Form has `elysium-chat-card` marker class
- `data-card-type` attribute correct
- `open-actor` class hook preserved on the img element (XP/RS only)
- No `.cardbutton` (read-only cards)
- No `.chat-dice` (no bottom summary)
- Title renders via `__title` class
- Row indent applies via CSS not inline style

**Live smoke**: post one of each via the JS console or via game actions (XP-tick after a skill check, "Roll Stats" button on a new character, item-sheet "Post to Chat" button).

---

## 4. Cluster-4 ship summary

**Files added** (1):
- `templates/chat/parts/chat-card-actor-list.hbs` (~20 LOC) — shared partial for the XP-result + rollStats pair. Uses Handlebars partial-block syntax for the body slot. (If Foundry's Handlebars version doesn't support partial-blocks, fall back to inline-without-partial; partial registration deferred.)

**Files modified** (3 templates + CSS + system + changelog + roadmap):

- `templates/chat/XP-result.html` — 18 → ~14 LOC (compose actor-list partial)
- `templates/chat/rollStats.html` — 12 → ~12 LOC (compose actor-list partial)
- `templates/chat/itemDescription.html` — 5 → ~5 LOC (cosmetic: add marker class + data-card-type; same line count)
- `styles/elysium-chat.css` — add Section D entries for XP/RS/ID (3 selectors); add `__row` row-indent rule in Section B (~12 LOC total)
- `css/legacy.css` — retire `.elysium .XPCheck` rule (4 lines removed); preserve `.font14` rules (actor-sheet consumers)
- `module/hooks/init.mjs` — register new `chat-card-actor-list.hbs` partial (1 path line)
- `system.json` — version bump alpha.47 → alpha.48
- `CHANGELOG.md` — alpha.48 entry
- `ROADMAP-v1.0.0.md` — execution-log entry + progress-tracker update (11/11 chat-card templates on v1.0.0; P11 chat-card scope CLOSES)

**Net LOC**: -4 templates, +20 partial, +12 CSS, -4 legacy CSS, +1 init = **+25 LOC net**. Cluster 4 is net positive because cluster-4 templates are already so small that any rebuild adds overhead. The win isn't LOC — it's consistency (all 11 chat templates use the v1.0.0 scoping marker and Section D accent pattern) and the first legacy CSS rule retirement of P11.

---

## 5. Out of scope for cluster 4

- The 10 generic dialogs (cluster 5): `templates/dialog/*.hbs`
- The 51 inline-HTML `ChatMessage.create({content:...})` callsites in `module/elysium/mechanics/` and `module/casting/` (out of P11 per c11-8)
- Optional cluster 6 (island harmonisation evaluation)
- Optional cluster 7 (combat-tracker cosmetic restyle)
- Remaining legacy CSS retirement candidates (P12 sweep)
- Damage-type taxonomy alignment (P12 per c1-9)

---

## 6. Open questions for user lock-in

1. **Handlebars partial-block support (c4-1)** — the recommended `chat-card-actor-list.hbs` uses Handlebars partial-block syntax (`{{#> name}}...{{/}}`). Foundry V14 uses Handlebars 4+ which supports this, but I haven't confirmed it's enabled in Foundry's Handlebars instance specifically. If it doesn't work, fall back to inline-without-partial (option C from c4-1 — rebuild all 3 as small standalone templates with no shared partial). The fallback adds ~10 LOC across the two affected templates and removes the partial. Either is fine; recommend trying partial-block first since it's the cleanest expression. Confirm: try partial-block, fall back to inline if it doesn't work?

2. **Eager legacy CSS retirement of `.XPCheck` (c4-5)** — cluster 4 is the first cluster in P11 to retire a CSS rule from `css/legacy.css`. The P11 prep audit (c11-13) reserved this for the P12 final sweep, but `.XPCheck` is so isolated (only consumer is cluster-4 templates being rebuilt) that holding it until P12 just clutters legacy.css. Recommend retire eagerly. Alternative: leave the rule in place and let P12 sweep it. Confirm: eager retire?

3. **Section D accent colors for cluster 4 card types (c4-3)** — XP=green, RS=blue, ID=gold. Alternative: don't accent these at all (they're not really "cards" in the same sense as cluster 1/2/3 cards). Recommend: apply accents anyway for visual consistency with Section D being "fully populated" after cluster 4.

4. **`data-card-type` values for cluster 4 (c4-2)** — chose 2-letter codes XP / RS / ID to match the existing 2-letter scheme (CB/OP/GR/CO/NO/RE/PP/CM/IM/DM/AR/QC). The 2-letter pattern is non-load-bearing — JS doesn't read these values, they're only consumed by Section D's `[data-card-type="..."]` attribute selectors. Alternative codes welcome. Recommend XP/RS/ID.

5. **`itemDescription` HTML body slot styling (c4-7)** — the rebuilt itemDescription template wraps the description in `<div class="elysium-chat-card__body">`. This BEM-element class needs a CSS rule in Section B that defines what an unstructured-content body slot looks like (padding, max-width, prose typography). Alternative: don't add a `__body` class; let the description render bare. Recommend add the class + give it minimal padding (var(--ely-space-2)) and let the marker rule's typography cascade.

6. **Cluster 4 to cluster 5 sequencing** — after cluster 4 closes the chat-card scope, cluster 5 picks up `templates/dialog/*.hbs` (10 generic dialogs). The dialogs are a different surface entirely (ApplicationV2-rendered, mostly modal). The cluster-1 `chat-card-shell.hbs` doesn't compose; cluster-1's `.elysium-dialog` marker class (already shipped) does. Confirm: ship cluster 4 first as alpha.48, then audit cluster 5?

---

## 7. Ready-to-go checklist (cluster 4 ships when all green)

- [ ] User confirms decisions c4-1 through c4-8
- [ ] User answers the 6 open questions in §6
- [ ] User accepts scope-cut list in §5

Once locked, cluster 4 coding begins.
