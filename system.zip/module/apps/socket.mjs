import { ElysiumCheck } from './check.mjs'
import { GRCard } from '../cards/combined-card.mjs'
import { ElysiumDamage } from '../combat/damage.mjs'
import { ElysiumUtilities } from './utilities.mjs'

export class ElysiumSystemSocket {

  static async callSocket(data) {
    switch (data.type) {
      case 'chatUpdate':
        if (data.to === game.user.id) {
          ElysiumCheck.handleChatButton(data.value);
        }
        break;

      case 'GRAdd':
        if (data.to === game.user.id) {
          GRCard.GRAdd(data.value.config, data.value.msgId);
        }
        break;

      case 'firstAidFumble':
        if (data.to === game.user.id) {
          ElysiumDamage.firstAidFumble(data.value.actorId, data.value.actorType, data.value.locationId);
        }
        break;

      case 'toggleMapNotes':
        game.settings.set('core', NotesLayer.TOGGLE_SETTING, data.toggle === true);
        break;

      case 'updateChar':
        ElysiumUtilities.updateCharSheets();
        break;
    }
  }
}
