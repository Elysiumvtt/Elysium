# P5 Prep Audit — Live Findings

Captured 2026-05-13 via live probes against the loaded v1.0.0-alpha.1 build in
the `test-2` world (Foundry 14.361). These findings inform P5 implementation
decisions that P3's static design couldn't determine.

## Foundry V14 DataModel API surface (confirmed)

All field classes from P3's decision matrix are present in `foundry.data.fields`:
- NumberField, StringField, BooleanField, ArrayField, SchemaField, ObjectField
- HTMLField, ForeignDocumentField, DocumentIdField, FilePathField, ColorField,
  IntegerSortField

V14 also has these we didn't list in P3:
- **TypedObjectField** — keyed-by-string dynamic objects with known value shape.
  Better fit than ObjectField for `elysium.statNaturalMax` (keyed by stat name,
  values are `{value: int}`) and `elysium.schoolMastery` (keyed by school name).
- **TypedSchemaField** — discriminated-union schema, value shape varies by type.
  Probably overkill for our needs.
- **SetField** — alternative to ArrayField when order doesn't matter (e.g.
  `creatureTags`, `languages`).
- **JSONField** — stringified-JSON values. Not needed for our schema.
- **DocumentUUIDField** — typed UUID reference. Slight upgrade over StringField
  for `companionActorId`.

`foundry.abstract.TypeDataModel` is the base class. Registration goes into
`CONFIG.Actor.dataModels[type]` and `CONFIG.Item.dataModels[type]` slots in
the `init` hook. The `system.json` `documentTypes` block is already populated
correctly (no manifest change needed).

## NPC actor — ground-truth field shapes

Captured by creating an NPC and inspecting `toObject().system`. Use these
EXACT shapes when writing NPCDataModel:

### Base template fields (shared with character)

**`stats.<str|con|int|siz|pow|dex|cha>`** — 7 stat blocks, each with 11 stored fields:
- base: NumberField(integer, initial: 0, min: 0)
- redist: NumberField(integer, initial: 0)        # can be negative
- culture: NumberField(integer, initial: 0)
- exp: NumberField(integer, initial: 0)
- age: NumberField(integer, initial: 0)
- effects: NumberField(integer, initial: 0)
- cost: NumberField(integer, initial: 1, min: 1)  # SP cost; INT and SIZ use 3
- formula: StringField(initial: "")
- improve: BooleanField(initial: false)
- failCounter: NumberField(integer, initial: 0)
- capOverride: BooleanField(initial: false)

Note: only 7 stats in actual data (no `edu` in stats), though template.json
defines `edu` in CONFIG. Base actor template stats fields are 7, not 8.

Derived stat fields (populated in `prepareDerivedData`, NOT in defineSchema):
- `label`, `labelShort`, `labelDeriv` — i18n-localized labels
- `total` — base + redist + culture + exp + age + effects
- `deriv` — derived modifier (varies by stat)
- `visible` — whether the stat shows on the sheet

**`health`** — 5 fields:
- value: NumberField(integer, initial: 10, min: 0)
- max: NumberField(integer, initial: 10, min: 0)
- mod: NumberField(integer, initial: 0)
- mjrwnd: NumberField(integer, initial: 5, min: 0)
- daily: NumberField(integer, initial: 0)  # P3 candidate for drop; CONFIRMED
                                            # unused, drop in P5.1 — but grep
                                            # source first to be sure

**`power`** — 5 fields:
- value: NumberField(integer, initial: 5, min: 0)
- max: NumberField(integer, initial: 5, min: 0)
- mod: NumberField(integer, initial: 0)
- battVal: NumberField(integer, initial: 0)  # P3 candidate for drop
- battMax: NumberField(integer, initial: 0)  # P3 candidate for drop
Battery fields ARE populated (value 0). Decision: grep source for reads
before dropping; if zero reads, drop.

**`fatigue`** — 5 fields:
- value: NumberField(integer, initial: 5, min: 0)
- max: NumberField(integer, initial: 5, min: 0)
- mod: NumberField(integer, initial: 0)
- level: NumberField(integer, initial: 0, min: 0)
- recoveryType: StringField(initial: "physical", choices: ["physical", "magical"])

`recoveryType` is actually populated ("physical"). NOT unused —
P3's candidate-for-drop note was wrong. Keep with choices constraint.

**`actionPoints`** — 11 fields (NOT 6 as P3 said):
- value, max, reactValue, reactMax, attackValue, attackMax — all NumberField(integer, initial: 0)
- defenseValue, defenseMax — v0.14.0 additions, NumberField(integer, initial: 0)
- mod, reactMod — NumberField(integer, initial: 0)
- _v0140doc field DROPPED — replace with code comment

**`tempHP`** — {value: int, max: int}, both initial 0.

**`luckPoints`** — {value: int, max: int}, both initial 0.

**`dmgmodTier`** — StringField(initial: "+0"). Stat-derived damage modifier tier.

**`sanity`** — {value: int, max: int}. POPULATED on fresh NPC (5/5).
NOT unused — P3's candidate-for-drop note was wrong. Keep.

**`res5`** — {value: int, max: int}, both 0. P3 said unused; value IS populated
but at 0/0. Probably vestigial. Grep source for reads before dropping.

**`wealthValue`** — NumberField(integer, initial: 0).

### Base `elysium` partition (13 sub-keys)

The `system.elysium.*` partition that P3 says to flatten. For NPC's purposes,
sparse-declare only the NPC-relevant ones:

NPC needs (4 fields):
- creatureType: StringField(initial: "humanoid", choices: [...])
- creatureSubtype: StringField(initial: "human")
- creatureTags: ArrayField of StringField, initial []
- languages: ArrayField of StringField, initial []

NPC does NOT need (character-only, sparse-skip per P3 Decision 3):
- expDice, buildPoints, skillPoints — character progression
- statNaturalMax — character ancestry mechanics
- patron — character divine allegiance
- essences — character sorcery
- schoolMastery — character magic mastery
- ancestryId — character ancestry reference
- companion — character companion ledger

### NPC's own fields (19 listed in template.json, all confirmed populated)

- description: HTMLField(initial: "")
- extDesc: HTMLField(initial: "")
- majorWnd: BooleanField(initial: false)
- minorWnd: BooleanField(initial: false)
- moveTitle: StringField(initial: "Move")
- move: NumberField(integer, initial: 0)
- altMoveTitle: StringField(initial: "Alt Move")
- altMove: NumberField(integer, initial: 0)
- lock: BooleanField(initial: false)
- viewTab: StringField(initial: "2")  # no choices constraint per P3 risk note
- showNotes: BooleanField(initial: false)
- sanLoss: StringField(initial: "")
- sanDesc: StringField(initial: "")
- movDesc: StringField(initial: "")
- ap: NumberField(integer, initial: 0)
- apRnd: StringField(initial: "")
- baseStats: TypedObjectField, keys = stat names, values = SchemaField({
    average: StringField, random: StringField })
- hp: SchemaField({ multi: NumberField(initial: 0.5), 
                    stat1: StringField(initial: "siz"), 
                    stat2: StringField(initial: "con") })
- mod: SchemaField({ strdb: BooleanField(initial: false) })

### Derived top-level fields (populated by ElysiumActor.prepareDerivedData,
### NOT in stored schema — do NOT include in defineSchema)

- `brpidFlagItems` — **P4 MISS**, must rename before P5 starts. See hotfix
  step in the prompt.
- `redistInc`, `redistDec`, `redistTotal` — character-only redistribution
- `xpBonus` — experience-bonus modifier

## DataModel strategy decision (NEW — was open in P3)

**Decision**: P5 implements **stored-schema-only DataModels**.
`prepareDerivedData` logic stays in `ElysiumActor` for the migration.

Rationale: ElysiumActor already overrides prepareData/prepareBaseData/
prepareDerivedData/_prepareCharacterData and populates derived fields.
Moving all of that into DataModel's prepareDerivedData during P5 would be
a second big change layered on the DataModel migration. Keeping the existing
prep code lets P5 focus on what DataModels are FOR (schema typing and
validation). Migration of prep into DataModels deferred to P12 or P5.4
follow-up.

## DataModel viability confirmed

Live test: instantiated a minimal TestNPCModel against an existing NPC's
data. Validation passed. health.value and health.max retrieved correctly.
The P3 schema strategy is viable on a real V14 install.

## Open items requiring source-side grep audit before locking schema

- `res5`: confirm zero reads in source before dropping
- `power.battVal`, `power.battMax`: confirm zero reads
- `health.daily`: confirm zero reads
- `schoolMastery` value-shape: probe magic-school code (P6.4 territory but
  flag now so audit happens then)
- `essences`, `creatureTags`, `languages`: ArrayField (ordered) or SetField
  (unordered)? Probably ArrayField for essences (casting sequence may matter),
  SetField for the other two. Grep how each is consumed.

## brpid<UpperCase> hotfix scope

The P4 regex `\bbrpid\b` didn't match identifiers where `brpid` is followed
by an uppercase letter (no word boundary between lowercase letter and
uppercase letter). Confirmed miss: `brpidFlagItems`. Grep needed:

  grep -rE "\bbrpid[A-Z]" --include="*.mjs" --include="*.hbs" --include="*.html" \
       /home/claude/work/system/ /home/claude/work/module/

For each match, rename brpid → elysiumid preserving the following uppercase
letter. Re-run integrity sweeps after.