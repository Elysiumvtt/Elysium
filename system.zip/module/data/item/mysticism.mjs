/**
 * MysticismDataModel — schema for items of type 'mysticism'.
 *
 * Per P6.4 spec. Stored-schema-only. 5 compendium items in
 * abilities-mysticism.db.
 *
 * Compendium content fully aligns with template.json (no compendium-only
 * fields). Schema is the simplest in P6.4.
 *
 * Schema decisions:
 *   - Top-level uses makeSpellBaseFields() — the 17-field spell-base
 *     block shared with arcane (per P6.4 audit, both types declare
 *     bit-identical top-level shapes minus arcane's `mem` field).
 *   - `elysium` uses makeThemedBundle() for activation/benefits/
 *     drawbacks/addOns (bit-identical to ability per audit).
 *   - The `_doc` documentation string from template's `elysium._doc`
 *     is DROPPED.
 *   - All string enums (discipline, saveSkill) FREE per content
 *     extensibility.
 */

import { makeItemBase, makeSpellBaseFields, makeThemedBundle } from './_shared.mjs'

const fields = foundry.data.fields

export class MysticismDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      ...makeSpellBaseFields(),

      elysium: new fields.SchemaField({
        discipline: new fields.StringField({ initial: '' }),
        tier:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        powerCost:  new fields.NumberField({ integer: true, initial: 0 }),
        apCost:     new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill:  new fields.StringField({ initial: '' }),
        // _doc DROPPED — template-only documentation string
        ...makeThemedBundle(),
      }),
    }
  }
}
