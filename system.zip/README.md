# Elysium BRP — v0.20.0

A self-contained Mythras-flavored fork of the **Basic Role Playing** system for Foundry VTT.

## What This System Is

As of v0.20.0 ElysiumBRP is a single, self-contained system. The previously separate "Elysium" rules module has been folded into the system itself — there is no longer a separate rules module to install. The only optional companion is the **ElysiumCompendium** content module (skills, weapons, armor, ancestries, spells, conditions, and critical tables).

### System ID

`elysium` — this is a full fork, not a drop-in extension. Worlds built on stock BRP are not compatible without conversion.

## Features

### Mythras-Flavored Combat
- **Per-location HP** computed from the Mythras CON+SIZ table, scaled by a per-campaign `hpMultiplier` world setting (0.5–4.0)
- **Hit-location body-part schema** — `bodyPart` (arm/leg/wing/tail/head/chest/abdomen), `side` (left/right), `index` (for creatures with multiple identical limbs)
- **Critical injury tables** that route by `bodyPart` when a location drops to 0 HP
- **Per-location conditions** (Bleeding, Burning, Poisoned, Frostbitten, Decayed, Withered, etc.) with ongoing-damage and max-HP-loss semantics
- **Charge** mechanics with Damage Mod stepping and weapon Size scaling
- **Knockback** in feet (squares × 5ft), with Brace combat action halving excess
- **Engagement** tracking with multi-opponent support

### Four-Pool Action Points
The character's AP pool is split into four pools per the v0.14.0 design (now fully wired):
- `value / max` — **proactive general** (your turn, any action)
- `attackValue / attackMax` — **proactive restricted** (your turn, attacks only; granted by Combat Stance Offensive)
- `reactValue / reactMax` — **reactive general** (others' turns, any reaction)
- `defenseValue / defenseMax` — **reactive restricted** (others' turns, parry/evade only; granted by Combat Stance Defensive)

The sheet header shows the pool format `8/8 · A 1 · R 2 · D 1` (any pool at zero max is omitted).

### Four Magic Traditions
- **Arcane** — multi-AP cast pipeline with SL accumulation, Forms/Techniques system, manipulation dialog, sustained spells, wild-magic on F/T failure, active-cast disruption when the wizard takes damage
- **Divine** — tier-choice casting gated by Channeling + Faith allegiance, multi-AP commitment, Faith roll for wild-magic, POW-sacrifice spells (e.g. Resurrection)
- **Sorcery** — tier-based spontaneous casting on essence skills, always-fires (resistance-value only), forbidden-essence flag
- **Mysticism** — single-roll Focus casting with tier penalty

All four traditions share a single PP pool, the same overcast-into-fatigue rules, and the active-cast slot.

### Damage Modifier
Mythras-style damage modifier from STR+SIZ via `system.dmgmodTier` (a dice expression like `+1d6`). Per-weapon scaling via `weapon.system.elysium.damageBonusMultiplier` (default 1.0; 0 = no bonus, 0.5 = half, 2.0 = double). Walks `DAMAGE_MOD_TABLE` by index for non-linear progression.

### Other Subsystems
- **Ancestry framework** — culture items carry full ancestry data (stat mods, traits, natural armor, languages, subraces). Drop sequence applies AEs, BP/SP, mutations, languages, stat maxima
- **Stat improvement** — Characteristic improvement subsystem with marker, roll, auto-improve, and at-cap GM approval
- **Fatigue** — Mythras fatigue ladder with movement and AP penalties
- **Conditions** — 30+ definitions as Active Effects with per-location and per-actor variants
- **Custom-spell builder** — live spell composer on the Arcane tab

## Installation

In Foundry's setup screen:

1. Click **Game Systems** → **Install System**
2. Paste this manifest URL:
   ```
   https://github.com/Elysiumvtt/ElysiumBRP/releases/latest/download/system.json
   ```
3. Click Install

Then install the optional content module via **Add-on Modules** → **Install Module** using the ElysiumCompendium manifest.

### Upgrading from a Previous Elysium Install

v0.20.0 is **a fresh-world release**. Worlds built on the prior split (elysium + elysium + elysium-compendium) are not compatible. Create a new world. Migration code has been removed entirely.

Before launching the new world: uninstall the "Elysium" rules module if previously installed — its functionality is now part of the system.

## Compatibility

- Foundry V14 (verified at 14.360)
- Grid units: feet (5 ft per square)

## Credit

Based on **BRP V14.2** by Dangermouse and JamesB. Original repo at `https://github.com/cragstone/brp`.

The Elysium fork extends and modifies the BRP V14 base with Mythras-flavored mechanics, four-tradition magic, per-location HP, action points, conditions, critical tables, and a custom-spell builder.
