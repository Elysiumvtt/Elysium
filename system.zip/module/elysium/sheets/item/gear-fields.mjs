// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { injectItemModifiers } from './item-modifiers.mjs'

export function injectGearFields (html, item) {
    const target = html.querySelector('.tab.details') ||
                   html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return
    if (target.querySelector('.elysium-gear-fields')) return

    const sys = item.system?.elysium || {}
    const isContainer = sys.isContainer === true
    const capacity = Number(sys.capacity) || 0

    // Build the gear-specific fieldset (container settings + contents listing
    // when this is a container). Always render so users can toggle container.
    const fieldsetHtml = `
      <fieldset class="elysium-gear-fields">
        <legend>${game.i18n.localize('Elysium.Gear.Fields') || 'Elysium Gear Properties'}</legend>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Gear.IsContainerHint') || 'Mark this item as a container (backpack, pouch, chest). Other items can be stored inside it.'}">
            ${game.i18n.localize('Elysium.Gear.IsContainer') || 'Is Container'}
          </label>
          <input type="checkbox" name="system.elysium.isContainer" ${isContainer ? 'checked' : ''}>
        </div>
        <div class="form-group elysium-container-only" style="display:${isContainer ? '' : 'none'}">
          <label data-tooltip="${game.i18n.localize('Elysium.Gear.CapacityHint') || 'Maximum total ENC the container can hold (0 = unlimited).'}">
            ${game.i18n.localize('Elysium.Gear.Capacity') || 'Capacity (ENC)'}
          </label>
          <input type="number" name="system.elysium.capacity"
                 value="${capacity}" min="0" max="9999">
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = fieldsetHtml
    target.appendChild(wrapper.firstElementChild)

    // If this gear IS a container AND it's owned by an actor, list its contents
    if (isContainer && item.parent) {
      injectContainerContents(html, item, target)
    }

    // Worn Modifiers fieldset (works for any gear)
    injectItemModifiers(html, item, target)
  }

export function injectContainerContents (html, container, target) {
    if (target.querySelector('.elysium-container-contents')) return
    const actor = container.parent
    if (!actor) return

    const contained = actor.items.filter(i =>
      i.id !== container.id &&
      (i.system?.elysium?.containedIn === container.id)
    )

    let totalEnc = 0
    const rowsHtml = contained.map(i => {
      const enc = Number(i.system?.enc || 0) * Number(i.system?.quantity || 1)
      totalEnc += enc
      return `
        <div class="elysium-container-row" data-item-id="${i.id}">
          <span class="elysium-cont-name" title="${i.name}">${i.name}</span>
          <span class="elysium-cont-qty">×${i.system?.quantity || 1}</span>
          <span class="elysium-cont-enc">${enc.toFixed(1)} ENC</span>
          <a class="elysium-cont-remove" data-elysium-cont-remove
             data-tooltip="Remove from container"><i class="fas fa-times"></i></a>
        </div>
      `
    }).join('')

    const cap = Number(container.system?.elysium?.capacity || 0)
    const capLabel = cap > 0 ? `${totalEnc.toFixed(1)} / ${cap}` : `${totalEnc.toFixed(1)}`

    const fieldsetHtml = `
      <fieldset class="elysium-container-contents">
        <legend>${game.i18n.localize('Elysium.Gear.Contents') || 'Contents'}
          <span style="font-weight:400;font-size:11px;opacity:0.8;">
            (${capLabel} ENC)
          </span>
        </legend>
        <div class="elysium-container-list">
          ${rowsHtml || `<div class="elysium-container-empty">${game.i18n.localize('Elysium.Gear.Empty') || 'Empty — drop items into this container by editing them and setting "Stored In".'}</div>`}
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = fieldsetHtml
    const fieldset = wrapper.firstElementChild
    target.appendChild(fieldset)

    // Wire remove buttons
    fieldset.querySelectorAll('[data-elysium-cont-remove]').forEach(btn => {
      btn.addEventListener('click', async (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        const row = btn.closest('.elysium-container-row')
        const itemId = row?.dataset.itemId
        if (!itemId) return
        const innerItem = actor.items.get(itemId)
        if (!innerItem) return
        await innerItem.update({ 'system.elysium.containedIn': '' })
      })
    })
  }
