/**
 * Elysium Fatigue Manager (Mythras-style)
 *
 * Handles:
 *   - Setting and incrementing fatigue level
 *   - Applying fatigue Active Effects (skill grade, AP penalty, move penalty, init penalty)
 *   - Recovery calculations (Recovery Period ÷ HR)
 *   - Different recovery types (physical/asphyxiation/blood loss)
 *   - Merging multiple fatigue sources (highest level + worst recovery type)
 *   - Endurance rolls for fatigue gain from effort
 */

import { ELYSIUM } from '../config/config.mjs'
export class ElysiumFatigueManager {

  /**
   * Set actor's fatigue to a specific level (0-9)
   */
  static async setLevel (actor, level, recoveryType = 'physical', source = 'manual') {

    const data = ELYSIUM.FATIGUE_LEVELS[level]
    // Granular paths so we don't clobber BRP-base's existing system.fatigue.value/max
    await actor.update({
      'system.fatigue.level':        level,
      'system.fatigue.label':        data.label,
      'system.fatigue.recoveryType': recoveryType,
    })

    await this._applyFatigueEffect(actor, level)

    const ctx = this._formatChat(actor, level, source)
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      ctx
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  }

  /**
   * Increment actor's fatigue by N levels
   */
  static async increment (actor, amount = 1, recoveryType = 'physical', source = '') {
    const current = actor.system?.fatigue?.level ?? 0
    const newLevel = Math.min(9, current + amount)
    if (newLevel === current) return

    // Apply worst recovery type if multiple sources
    const currentType = actor.system?.fatigue?.recoveryType || 'physical'
    const finalType = this._worstRecoveryType(currentType, recoveryType)

    await this.setLevel(actor, newLevel, finalType, source)
  }

  /**
   * Decrement actor's fatigue by N levels (recovery)
   */
  static async decrement (actor, amount = 1) {
    const current = actor.system?.fatigue?.level ?? 0
    const newLevel = Math.max(0, current - amount)
    if (newLevel === current) return

    await this.setLevel(actor, newLevel, 'physical', 'recovery')
  }

  /**
   * Make Endurance roll for effort - on fail, increment fatigue
   */
  static async effortRoll (actor, effortType = 'strenuous') {

    const enduranceSkill = actor.items.find(i =>
      i.type === 'skill' && /endurance/i.test(i.name)
    )
    if (!enduranceSkill) {
      ui.notifications.warn(game.i18n.localize('Elysium.Fatigue.NoEnduranceSkill'))
      return null
    }

    const skillTotal = enduranceSkill.system?.total ?? enduranceSkill.system?.value ?? 0
    let difficultyMod = 0
    switch (effortType) {
      case 'light':     difficultyMod = +40; break
      case 'medium':    difficultyMod = +20; break
      case 'strenuous': difficultyMod = 0;   break
    }

    const roll = await new Roll('1d100').evaluate()
    const target = skillTotal + difficultyMod

    // v0.14.0: crit/fumble formulas aligned with apps/check.mjs.
    //   Crit:   roll <= floor(skill / 10)
    //   Fumble: roll >= 91 + floor(skill / 10), clamped to 100.
    // High-skill characters crit more often and fumble less; 00 always fumbles.
    const isCrit   = roll.total <= Math.floor(target / 10)
    const isFumble = roll.total >= Math.min(100, 91 + Math.floor(target / 10))
    const isFail   = roll.total > target
    const isPass   = !isFail

    let outcomeText
    let variant
    if (isFumble) {
      outcomeText = game.i18n.localize('Elysium.Fatigue.Fumble')
      variant = 'danger'
      await this.increment(actor, 2, 'physical', 'effort fumble')
    } else if (isFail) {
      outcomeText = game.i18n.localize('Elysium.Fatigue.Failed')
      variant = 'fire'
      await this.increment(actor, 1, 'physical', 'effort failure')
    } else if (isCrit) {
      outcomeText = game.i18n.localize('Elysium.Fatigue.Critical')
      variant = 'success'
    } else if (isPass) {
      outcomeText = game.i18n.localize('Elysium.Fatigue.Passed')
      variant = 'success'
    }

    const erBody = `<p>${enduranceSkill.name} ${skillTotal}% ${difficultyMod >= 0 ? '+' : ''}${difficultyMod} = ${target}%</p>
      <p>${game.i18n.localize('Elysium.Roll')}: <strong>${roll.total}</strong></p>
      <p>${outcomeText}</p>`
    const erHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
      {
        variant,
        title: `${game.i18n.localize('Elysium.Fatigue.EffortRoll')}: ${effortType}`,
        icon: 'face-tired',
        body: erBody,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: erHtml,
    })

    return { isPass, isFail, isCrit, isFumble, roll: roll.total }
  }

  /**
   * Recovery rate calculator
   */
  static getRecoveryMinutes (level, healingRate, recoveryType = 'physical') {
    const data = ELYSIUM.FATIGUE_LEVELS[level]
    if (!data?.recoveryMins) return null

    let effectiveHR = healingRate

    if (recoveryType === 'bloodloss') {
      effectiveHR = Math.max(1, Math.floor(healingRate / 2))
    }

    if (recoveryType === 'asphyxiation') {
      // Special: 1 level per minute regardless of HR
      return 1
    }

    return Math.ceil(data.recoveryMins / effectiveHR)
  }

  /**
   * Quick rest (manual GM trigger) — recover one level if appropriate
   */
  static async restRecover (actor, restMinutes = 60, restQuality = 'lightActivity') {
    const current = actor.system?.fatigue?.level || 0
    if (current === 0) return

    const recoveryType = actor.system?.fatigue?.recoveryType || 'physical'

    // Get HR with rest quality modifier
    let hr = actor.flags?.['elysium']?.derived?.healingRate || 1
    switch (restQuality) {
      case 'fullBedRest':     hr += 1; break
      case 'exceptionalCare': hr += 1; break
      case 'malnourished':    hr = Math.max(1, Math.floor(hr / 2)); break
      case 'strenuous':       return  // no recovery
    }

    const requiredMins = this.getRecoveryMinutes(current, hr, recoveryType)
    if (restMinutes >= requiredMins) {
      await this.decrement(actor, 1)
    }
  }

  // === FATIGUE ACTIVE EFFECT MANAGEMENT =============================

  static async _applyFatigueEffect (actor, level) {
    const data = ELYSIUM.FATIGUE_LEVELS[level]

    // Remove old fatigue AE if any
    const existingFatigueAEs = actor.effects.filter(e =>
      e.flags?.['elysium']?.group === 'fatigue'
    ).map(e => e.id)
    if (existingFatigueAEs.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', existingFatigueAEs)
    }

    // No effect if Fresh
    if (level === 0) return

    // Build new AE
    const changes = []
    if (data.skillGrade !== null && data.skillGrade !== 0) {
      changes.push({
        key:   'flags.elysium.modifiers.allSkills',
        mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
        value: String(data.skillGrade),
      })
    }
    if (data.apPenalty !== null && data.apPenalty > 0) {
      changes.push({
        key:   'flags.elysium.modifiers.apPenalty',
        mode:  CONST.ACTIVE_EFFECT_CHANGE_TYPES.ADD,
        value: String(data.apPenalty),
      })
    }

    const aeData = {
      name: game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`),
      icon: 'icons/svg/sleep.svg',
      changes,
      flags: {
        elysium: {
          group:        'fatigue',
          fatigueLevel: level,
          fatigueData:  data,
        }
      },
      disabled: false,
      transfer: false,
    }

    await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }

  // === HELPERS ======================================================

  static _worstRecoveryType (typeA, typeB) {
    // Schema-canonical vocabulary per data/actor/_shared.mjs:104 choices.
    // worst = magical > physical (magical fatigue is harder to recover per Mythras).
    // Defensive `|| 0` defaults handle any future schema-additions or
    // unrecognized values without throwing. Pre-alpha.54 the helper used
    // stale vocab {asphyxiation, physical, bloodloss} that didn't match
    // the schema, causing the overcast path's 'magical' tag to be silently
    // dropped (F8 finding from c3 acceptance pass).
    const order = { physical: 1, magical: 2 }
    if ((order[typeB] || 0) > (order[typeA] || 0)) return typeB
    return typeA
  }

  static _formatChat (actor, level, source) {
    // Refactored in P12-c2 (alpha.52) per c2 audit D5: returns context
    // object for chat-card-notice partial rendering by callers, rather
    // than building HTML inline. Callers do renderTemplate themselves
    // because the call signature for renderTemplate is async and this
    // helper can't be made async without breaking the sync callers.
    const data = ELYSIUM.FATIGUE_LEVELS[level]
    const bullets = [
      data.skillGrade   ? `<li>${game.i18n.localize('Elysium.Fatigue.SkillGrade')}: ${data.skillGrade}%</li>` : '',
      data.apPenalty    ? `<li>${game.i18n.localize('Elysium.Fatigue.APPenalty')}: -${data.apPenalty}</li>` : '',
      data.movePenalty  ? `<li>${game.i18n.localize('Elysium.Fatigue.MovePenalty')}: ${data.movePenalty * 5}ft</li>` : '',
      data.initiativePen? `<li>${game.i18n.localize('Elysium.Fatigue.InitiativePen')}: ${data.initiativePen}</li>` : '',
    ].filter(Boolean).join('')
    const sourceLine = source ? `<p><em>${source}</em></p>` : ''
    const body = `<p><strong>${game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`)}</strong>
        (${game.i18n.localize('Elysium.Fatigue.Level')} ${level})</p>
      ${sourceLine}
      ${bullets ? `<ul>${bullets}</ul>` : ''}`
    return {
      variant: 'fire',
      title: `${actor.name} — ${game.i18n.localize('Elysium.Fatigue.Title')}`,
      icon: 'face-tired',
      body,
    }
  }
}
