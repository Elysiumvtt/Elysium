// =====================================================================
// ELYSIUM | Combat-Card Button Injection — v0.22.0-alpha.12 / Phase D
// =====================================================================
//
// Phases B (armor crit) and C (weapon fumble + crit-parry) built the
// damage helpers. This module is the surface that makes them visible
// during play: it inspects resolved CM (weapon) chat cards and appends
// the relevant GM-action buttons.
//
// Inputs:
//   - msg.flags.elysium.chatCard — array of resolved-roll entries with
//     particId, particType, itemId (weapon), resultLevel, origResLevel
//     (set on OP/CB resolutions), targetId/targetType, hitLocationId,
//     hitLocationName.
//   - msg.flags.elysium.cardType — 'NO' | 'OP' | 'CB' | 'GR' | 'CO'
//   - msg.flags.elysium.rollType — 'CM' for weapon rolls.
//   - msg.flags.elysium.state    — must be 'closed' (resolved).
//
// Button types emitted (each only when conditions are met):
//
//   1. FUMBLE — emitted when a participant rolled resultLevel === 0.
//      The GM rolls the fumble table separately and clicks the button
//      if the table indicates weapon damage. One button per fumbler.
//      Always offered (the table decides whether to apply damage).
//
//   2. CRIT-ARMOR — emitted when a participant's attack reached
//      Critical (origResLevel >= 4 if it's an opposed/combat resolution,
//      else resultLevel >= 4 for NO cards) AND has a known target +
//      hit location. Pre-bound to the rolled location. The GM clicks
//      AFTER the parry contest resolves to "the blow lands."
//      SUPPRESSED when a sub-crit parry exists in the same card (see
//      below) — in that case the crit-parry button is emitted instead.
//
//   3. CRIT-PARRY — emitted on OP/CB cards with 2 weapon participants
//      where one rolled origResLevel >= 4 (attacker critted) and the
//      other rolled origResLevel < 4 (parry below critical). Per the
//      Phase C rule, the parry weapon takes 1 HP. The button is pre-
//      bound to the sub-crit participant's weapon.
//
// Pair-aware logic (OP/CB only): if attack-crit + sub-crit parry both
// present, emit CRIT-PARRY (not CRIT-ARMOR) — the blow was diverted
// into the weapon. If attack-crit + crit-parry both present, emit
// neither — the parry held cleanly. If only one weapon roll exists
// (NO card), emit CRIT-ARMOR if it crit.
//
// Idempotency: skip injection if any elysium-*-wear-action button
// already exists in the rendered root.
//
// Permission: only the GM sees these buttons. Non-GMs get no injection.
// =====================================================================

import { ElysiumArmorWear }  from './armor-wear.mjs'
import { ElysiumWeaponWear } from './weapon-wear.mjs'

const PANEL_CLASS = 'elysium-combat-card-buttons'

/**
 * Top-level injector. Called from chat-card.mjs::onRenderChatMessageHTML
 * for every rendered message.
 *
 * @param {ChatMessage} msg
 * @param {HTMLElement} root
 */
export function injectCombatCardButtons (msg, root) {
  if (!root || !msg) return
  if (!game.user?.isGM) return                            // GM-only UI

  const cardFlag = msg.flags?.elysium
  if (!cardFlag) return
  if (cardFlag.state !== 'closed') return                      // unresolved cards skipped
  if (cardFlag.rollType !== 'CM') return                       // only weapon rolls
  const chatCard = Array.isArray(cardFlag.chatCard) ? cardFlag.chatCard : null
  if (!chatCard || chatCard.length === 0) return

  // Idempotency — if a panel is already injected, bail.
  if (root.querySelector(`.${PANEL_CLASS}`)) return

  // Build the button HTML based on card type and result levels.
  const buttonsHTML = _buildButtonsHTML(cardFlag, chatCard)
  if (!buttonsHTML) return

  // Append the panel below the form's main content. The chat template
  // wraps everything in <form class="cardFlag gr-card"> — appending inside
  // that form keeps spacing consistent with existing cards.
  const panel = document.createElement('div')
  panel.className = PANEL_CLASS
  panel.style.cssText = 'margin-top:6px;padding:6px;border-top:1px solid #806010;'
  panel.innerHTML = `
    <div style="font-size:11px;color:#806010;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px;">
      GM Actions — Phase D
    </div>
    ${buttonsHTML}
  `
  const form = root.querySelector('form.elysium.gr-card') || root
  form.appendChild(panel)
}

/**
 * Apply the hit-location-visibility setting to any rendered location
 * tags in the chat card. Runs for ALL users (not just GMs) so the
 * setting hides the tag from non-GMs. Called from chat-card.mjs
 * separately from injectCombatCardButtons.
 *
 * Idempotent: re-applying is a no-op (same display value either way).
 *
 * @param {HTMLElement} root
 */
export function applyHitLocationVisibility (root) {
  if (!root) return
  const tags = root.querySelectorAll('.elysium-hitloc-tag')
  if (tags.length === 0) return
  let visibility = 'gm-only'
  try {
    visibility = game.settings.get('elysium', 'hitLocationVisibility') || 'gm-only'
  } catch (e) {
    // Setting not yet registered — fall through with default.
  }
  const hideFromNonGM = (visibility === 'gm-only')
  for (const tag of tags) {
    if (hideFromNonGM && !game.user?.isGM) {
      tag.style.display = 'none'
    } else {
      tag.style.display = ''
    }
  }
}

/**
 * Build the per-card button HTML based on the resolved participants.
 *
 * @param {object} cardFlag - msg.flags.elysium
 * @param {Array}  chatCard - cardFlag.chatCard
 * @returns {string} HTML (possibly empty)
 */
function _buildButtonsHTML (cardFlag, chatCard) {
  const cardType = cardFlag.cardType
  const isOpposed = cardType === 'OP' || cardType === 'CB'

  // Sort copy by origResLevel (or resultLevel) desc so we can identify
  // a "highest scorer".
  const sorted = [...chatCard].sort((a, b) => {
    const al = Number(a.origResLevel ?? a.resultLevel) || 0
    const bl = Number(b.origResLevel ?? b.resultLevel) || 0
    return bl - al
  })

  // Pair-aware crit-parry detection (only meaningful on opposed cards
  // with at least 2 weapon participants).
  let critParryEmitted = false
  let suppressCritArmorForId = null   // skip crit-armor for this particId

  if (isOpposed && sorted.length >= 2) {
    const top  = sorted[0]
    const next = sorted[1]
    const topRL  = Number(top.origResLevel ?? top.resultLevel)   || 0
    const nextRL = Number(next.origResLevel ?? next.resultLevel) || 0
    // Crit attack + sub-crit parry: parry weapon takes damage.
    if (topRL >= 4 && nextRL >= 2 && nextRL < 4 && next.itemId) {
      // The 2nd-place participant is the parrier whose weapon takes
      // the hit. We use the attacker's hitLocationId/targetId only
      // for the suppression decision — the button itself is bound to
      // the parrier.
      suppressCritArmorForId = top.particId
      critParryEmitted = true
    }
    // Crit-vs-crit: parry holds, no damage either way. Both crit-armor
    // buttons should be suppressed.
    if (topRL >= 4 && nextRL >= 4) {
      // We don't emit a crit-parry button (rule exception), and we
      // don't want crit-armor either since the parry held.
      suppressCritArmorForId = top.particId
    }
  }

  const parts = []

  // Per-participant buttons (fumble + crit-armor).
  for (const entry of chatCard) {
    const rl     = Number(entry.resultLevel) || 0
    const origRL = Number(entry.origResLevel ?? rl) || 0
    const partName = entry.particName || 'Unknown'

    // 1. Fumble — always offered when resultLevel === 0.
    if (rl === 0 && entry.itemId) {
      const btn = ElysiumWeaponWear.buildApplyFumbleDamageButtonHTML(
        entry.particId, entry.itemId
      )
      parts.push(`
        <div style="margin-bottom:3px;">
          <span style="font-size:11px;color:#a04040;margin-right:6px;">
            ${partName} fumbled —
          </span>${btn}
        </div>
      `)
    }

    // 2. Crit-armor — only for attack-side participants that scored a
    // crit AND have a target AND have a rolled hit location AND aren't
    // suppressed by a crit-parry resolution.
    const wasCrit = origRL >= 4 || rl >= 4
    if (wasCrit
        && entry.targetId
        && entry.hitLocationId
        && suppressCritArmorForId !== entry.particId) {
      const btn = ElysiumArmorWear.buildApplyCritArmorButtonHTML(
        entry.targetId, entry.hitLocationId
      )
      const locLabel = entry.hitLocationName || 'hit location'
      parts.push(`
        <div style="margin-bottom:3px;">
          <span style="font-size:11px;color:#806010;margin-right:6px;">
            ${partName} critical →
            <b>${locLabel}</b> armor:
          </span>${btn}
        </div>
      `)
    }
  }

  // 3. Crit-parry — single button per card, bound to the parry weapon.
  if (critParryEmitted) {
    const top  = sorted[0]
    const next = sorted[1]
    const topRL  = Number(top.origResLevel ?? top.resultLevel)   || 0
    const nextRL = Number(next.origResLevel ?? next.resultLevel) || 0
    const btn = ElysiumWeaponWear.buildApplyCritParryButtonHTML(
      next.particId, next.itemId, topRL, nextRL
    )
    parts.push(`
      <div style="margin-bottom:3px;">
        <span style="font-size:11px;color:#806010;margin-right:6px;">
          ${top.particName || 'Attacker'} critted vs
          ${next.particName || 'Parrier'} sub-crit parry →
        </span>${btn}
      </div>
    `)
  }

  return parts.join('')
}

/**
 * Apply the hit-location-visibility setting to any rendered location
 * tags in the chat card. Tags are emitted unconditionally by the
 * template; here we hide them from non-GMs if the setting calls for it.
 *
 * Idempotent: re-applying is a no-op (same display value either way).
 */
// (intentionally removed — duplicated by the exported applyHitLocationVisibility above)

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

export const ElysiumCombatCardButtons = {
  injectCombatCardButtons,
  applyHitLocationVisibility,
}
