/**
 * Elysium Combat Extension
 *
 * Provides:
 *   - Custom initiative formula (1d10 + bonus - armor penalty)
 *   - Action Point pool refresh each combat round
 *   - Reaction AP separate from action AP
 *   - End-of-combat cleanup
 *
 * The BRP-base combat tracker is preserved — Elysium hooks into events
 * rather than replacing the tracker.
 */

import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'
export class ElysiumCombatExtension {

  /**
   * Combat starts — initialise AP pools for all combatants
   */
  static async onCombatStart (combat, updateData) {
    if (!combat?.combatants) return
    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await this._refreshActionPoints(actor)
    }
  }

  /**
   * New round — refresh AP for all combatants and run sustain upkeep
   */
  static async onRound (combat, updateData, updateOptions) {
    if (!combat?.combatants) return

    // v0.22.0: clear per-round outmanoeuvre blocks at the start of the
    // round. The block flags are set during the previous round when
    // foes lose the contest; they only apply for that one round.
    const outmanoeuvre = game.system.api?.elysium?.outmanoeuvre
    if (outmanoeuvre?.clearAllOutmanoeuvreBlocks) {
      try {
        await outmanoeuvre.clearAllOutmanoeuvreBlocks(combat)
      } catch (err) {
        console.warn('Elysium: clearAllOutmanoeuvreBlocks failed:', err)
      }
    }

    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await this._refreshActionPoints(actor)

      // Apply ongoing damage from conditions like Bleeding
      await this._applyOngoingDamage(actor)

      // v0.10.2: round refresh also clears the proactive-AP gate as a
      // safety net (in addition to per-turn clearing).
      const sustainAPI = game.system.api?.casting
      if (sustainAPI?.clearProactiveAPGate) {
        try {
          await sustainAPI.clearProactiveAPGate(actor)
        } catch (err) {
          console.warn('Elysium: clearProactiveAPGate failed for', actor.name, err)
        }
      }

      // v0.10.0: drain PP for active sustained spells; broken sustains
      // collapse and post a chat notice. The system-fork casting API
      // owns the sustain state.
      if (sustainAPI?.runSustainUpkeep) {
        try {
          await sustainAPI.runSustainUpkeep(actor)
        } catch (err) {
          console.warn('Elysium: sustain upkeep failed for', actor.name, err)
        }
      }
    }
  }

  /**
   * New turn — clear the once-per-turn proactive-AP gate for the actor
   * whose turn just began (v0.10.2), and re-post any in-progress cast
   * card for that same actor (v0.10.3).
   *
   * v0.10.5: clarified semantics. The cast card re-posts ONLY on the
   * caster's OWN next turn — not on any intervening turn. We resolve
   * the incoming combatant from updateData.turn (the value Foundry is
   * applying), and only that one actor gets the gate clear and re-post.
   * Adds debug logging so play-testers can see what's happening.
   */
  static async onTurn (combat, updateData, updateOptions) {
    if (!combat?.combatants) return

    // Resolve the incoming combatant. Foundry V14 fires combatTurn
    // AFTER the update is applied, so combat.turn matches updateData.turn.
    let incomingCombatant = null
    if (Number.isInteger(updateData?.turn)) {
      incomingCombatant = combat.turns?.[updateData.turn]
    }
    if (!incomingCombatant) {
      incomingCombatant = combat.combatant
    }

    const incomingActor = incomingCombatant?.actor
    console.debug('Elysium onTurn:', {
      updateDataTurn: updateData?.turn,
      combatTurn: combat?.turn,
      resolvedActor: incomingActor?.name,
    })
    if (!incomingActor) return

    const api = game.system.api?.casting
    if (!api) return

    if (api.clearProactiveAPGate) {
      try { await api.clearProactiveAPGate(incomingActor) }
      catch (err) { console.warn('Elysium: clearProactiveAPGate failed', err) }
    }
    if (api.repostCastCard) {
      try { await api.repostCastCard(incomingActor) }
      catch (err) { console.warn('Elysium: repostCastCard failed', err) }
    }
  }

  /**
   * Combat ends — clear AP pools, do cleanup
   */
  static async onCombatEnd (combat, options, userId) {
    if (!combat?.combatants) return
    const api = game.system.api?.casting
    for (const combatant of combat.combatants) {
      const actor = combatant.actor
      if (!actor) continue
      await actor.update({
        'system.actionPoints.value':        0,
        'system.actionPoints.reactValue':   0,
        'system.actionPoints.attackValue':  0,
        'system.actionPoints.defenseValue': 0,
      }, { render: false })
      // v0.10.2: drop the proactive-AP gate flag so it doesn't carry
      // into the next encounter or out-of-combat play.
      if (api?.clearProactiveAPGate) {
        try { await api.clearProactiveAPGate(actor) } catch {}
      }
    }
  }

  // === INITIATIVE ===================================================

  /**
   * Compute initiative for a combatant.
   * Returns the formula string for the BRP-base combat tracker.
   */
  static getInitiativeFormula (combatant) {
    const actor = combatant.actor
    if (!actor) return '1d10'

    const bonus = ElysiumActorExtension.calculateInitiativeBonus(actor)
    return `1d10 + ${bonus}`
  }

  // === ACTION POINT POOL REFRESH ====================================

  /**
   * Refresh an actor's Action Points pool to maximum.
   * Public method — safe to call from macros and console.
   */
  static async refreshActionPoints (actor) {
    return this._refreshActionPoints(actor)
  }

  static async _refreshActionPoints (actor) {
    const apData = ElysiumActorExtension.calculateActionPoints(actor)
    if (!apData) return

    await actor.update({
      'system.actionPoints': {
        max:          apData.max,
        value:        apData.max,
        base:         apData.base,
        reactMax:     apData.reactMax,
        reactValue:   apData.reactMax,
        attackMax:    apData.attackMax,
        attackValue:  apData.attackMax,
        defenseMax:   apData.defenseMax,
        defenseValue: apData.defenseMax,
        breakdown:    apData.breakdown,
      }
    }, { render: false })
  }

  // === ONGOING ROUND-START EFFECTS ===================================

  /**
   * Apply per-round effects from ongoing condition AEs.
   *
   * Mythras Bleeding semantics: bleeding advances Fatigue by 1 level per round
   * (representing cumulative blood loss draining the body's reserves), it does
   * NOT cause direct HP damage. Other conditions like Burning still deal direct
   * damage because that maps to fire's character.
   *
   * Apply ongoing damage at end-of-round.
   *
   * Source of truth (v0.6.0+): `hit-location.system.elysium.locationConditions`
   * — each entry is { name, amount, source }. The condition's definition
   * in CONDITION_DEFINITIONS specifies how damage is routed:
   *   - damageRouting: 'self'   → wound created on the location it lives on
   *   - damageRouting: 'random' → wound created on a random hit-location
   *
   * Bleeding (any kind) advances Fatigue +1 instead of dealing direct HP
   * damage (Mythras p72: bleeding causes exhaustion, not vitality loss).
   * Other ongoing-damage conditions (Burning, Immolation, Corrosion,
   * Decayed, Shocked, Frostbitten, Poisoned) deal HP damage to the
   * routed location.
   *
   * Multiple conditions on the same location each tick separately.
   */
  static async _applyOngoingDamage (actor) {
    const factory = game.system.api?.elysium?.activeEffects
    if (!factory) return

    let fatigueAdvance = 0
    const damageEvents = []     // [{ targetLocationId, amount, source }]
    const maxHPLossEvents = []  // [{ locationItemId, amount, source }]
    const sources = []

    // Walk every hit-location item and its locationConditions list
    for (const item of actor.items) {
      if (item.type !== 'hit-location') continue
      const list = item.system?.elysium?.locationConditions || []
      if (list.length === 0) continue

      for (const cond of list) {
        const def = factory.getDefinition?.(cond.name)
        if (!def) continue

        // Bleeding-family: advance fatigue, no direct HP damage
        if (def.damageType === 'physical' && (def.bleedRate || cond.name.includes('Bleeding'))) {
          fatigueAdvance += 1
          // Arterial Bleeding also deals 1 HP to a random location
          if (cond.name === 'Arterial Bleeding' || def.bleedRate >= 3) {
            damageEvents.push({
              targetLocationId: null,    // routed random
              amount: 1,
              source: `${cond.name} (${item.name})`,
            })
          }
          sources.push(`${cond.name} on ${item.name} (+1 Fatigue${cond.name === 'Arterial Bleeding' ? ', 1 HP' : ''})`)
          continue
        }

        // Max HP loss (Withered) — reduces location maxHP rather than dealing damage
        if (def.ongoingMaxHPLoss) {
          const amount = Number(cond.amount) || Number(def.ongoingMaxHPLoss?.amount) || 0
          if (amount <= 0) continue
          maxHPLossEvents.push({
            locationItemId: item.id,
            amount,
            source: `${cond.name} (${item.name})`,
          })
          sources.push(`${cond.name} on ${item.name} (−${amount} Max HP)`)
          continue
        }

        // Other ongoing-damage conditions: route based on definition
        const amount = Number(cond.amount) || Number(def.ongoingDamage?.amount) || 0
        if (amount <= 0) continue

        if (def.damageRouting === 'random') {
          damageEvents.push({
            targetLocationId: null,
            amount,
            source: `${cond.name} (${item.name})`,
          })
          sources.push(`${cond.name} on ${item.name} (${amount} HP, random location)`)
        } else {
          // 'self' — damage the location the condition lives on
          damageEvents.push({
            targetLocationId: item.id,
            amount,
            source: `${cond.name} (${item.name})`,
          })
          sources.push(`${cond.name} on ${item.name} (${amount} HP)`)
        }
      }
    }

    if (fatigueAdvance === 0 && damageEvents.length === 0 && maxHPLossEvents.length === 0) return

    // Apply fatigue advancement
    if (fatigueAdvance > 0 && game.system.api?.elysium?.fatigue) {
      try {
        await game.system.api.elysium.fatigue.increment(actor, fatigueAdvance, 'physical', 'bleed')
      } catch (err) {
        console.error('Elysium | Bleeding fatigue advance failed:', err)
      }
    }

    // Apply Max HP loss events. Each event reduces the target location's
    // baseline maxHP by the specified amount. We persist this as a stacking
    // modifier flag on the location item so it survives prepareDerivedData
    // re-runs by mythras-hp.mjs (which recomputes maxHP from base stats).
    //
    // Storage: location.system.elysium.maxHPModifier (signed integer, default 0).
    // Negative values reduce the computed maxHP; mythras-hp.applyToActor
    // honors this modifier when assigning the final maxHP each prep cycle.
    for (const evt of maxHPLossEvents) {
      try {
        const loc = actor.items.get(evt.locationItemId)
        if (!loc) continue
        const currentMod = Number(loc.system?.elysium?.maxHPModifier) || 0
        const newMod = currentMod - evt.amount
        const currentMax = Number(loc.system?.maxHP) || 0
        const currentHP = Number(loc.system?.currHP) || 0
        const newMax = Math.max(1, currentMax - evt.amount)
        // Cap currHP at newMax to avoid HP > Max
        const newCurr = Math.min(currentHP, newMax)
        await loc.update({
          'system.elysium.maxHPModifier': newMod,
          'system.maxHP': newMax,
          'system.currHP': newCurr,
        })
      } catch (err) {
        console.error('Elysium | Max HP loss event failed:', err)
      }
    }

    // Apply each damage event by creating a wound on the right location
    const allLocations = actor.items.filter(i =>
      i.type === 'hit-location' && (i.system?.maxHP ?? 0) > 0)

    for (const evt of damageEvents) {
      try {
        let target
        if (evt.targetLocationId) {
          target = actor.items.get(evt.targetLocationId)
          // If the location is invalid or has no HP capacity, fall back to random
          if (!target || (target.system?.maxHP ?? 0) <= 0) {
            target = allLocations[Math.floor(Math.random() * allLocations.length)]
          }
        } else {
          if (allLocations.length === 0) continue
          target = allLocations[Math.floor(Math.random() * allLocations.length)]
        }
        if (!target) continue

        await Item.create({
          name: game.i18n.localize('Elysium.wound'),
          type: 'wound',
          system: {
            locId: target.id,
            value: evt.amount,
          },
        }, { parent: actor })
      } catch (err) {
        console.error('Elysium | Ongoing damage event failed:', err)
      }
    }

    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      {
        variant: 'danger',
        title: `${actor.name} — ${game.i18n.localize('Elysium.Combat.OngoingDamage')}`,
        icon: 'droplet',
        body: `<ul>${sources.map(s => `<li>${s}</li>`).join('')}</ul>`,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  }

  // === LUCK POINT RECOVERY =========================================

  /**
   * Called manually at session start to refresh Luck Points.
   * Mythras: full pool restored each session.
   * Uses ElysiumActorExtension.calculateLuckPointsMax for consistency.
   */
  static async refreshLuckPoints (actor) {
    if (!getSetting('enableLuckPoints', true)) return

    const { max } = ElysiumActorExtension.calculateLuckPointsMax(actor)

    await actor.update({
      'system.luckPoints': {
        value: max,
        max:   max,
      }
    })
  }
}
