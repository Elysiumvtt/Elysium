/**
 * Elysium Fatigue Manager (Mythras-style)
 *
 * Handles:
 *   - Setting and incrementing fatigue level
 *   - Applying fatigue Active Effects (skill grade, AP penalty, move penalty, init penalty)
 *   - Recovery calculations (Recovery Period ÷ HR)
 *   - Different recovery types (physical/asphyxiation/blood loss)
 *   - Merging multiple fatigue sources (highest level + worst recovery type)
 *   - Endurance rolls for fatigue gain from effort
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'

export class ElysiumFatigueManager {

  /**
   * Set actor's fatigue to a specific level (0-9)
   */
  static async setLevel (actor, level, recoveryType = 'physical', source = 'manual') {
    if (!getSetting('enableMythrasFatigue', true)) return
    level = Math.max(0, Math.min(9, level))

    const data = ELYSIUM.FATIGUE_LEVELS[level]
    await actor.update({
      'flags.elysium.fatigue': {
        level,
        label:        data.label,
        recoveryType: recoveryType,
      }
    })

    await this._applyFatigueEffect(actor, level)

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: this._formatChat(actor, level, source),
    })
  }

  /**
   * Increment actor's fatigue by N levels
   */
  static async increment (actor, amount = 1, recoveryType = 'physical', source = '') {
    if (!getSetting('enableMythrasFatigue', true)) return
    const current = actor.flags?.elysium?.fatigue?.level || 0
    const newLevel = Math.min(9, current + amount)
    if (newLevel === current) return

    // Apply worst recovery type if multiple sources
    const currentType = actor.flags?.elysium?.fatigue?.recoveryType || 'physical'
    const finalType = this._worstRecoveryType(currentType, recoveryType)

    await this.setLevel(actor, newLevel, finalType, source)
  }

  /**
   * Decrement actor's fatigue by N levels (recovery)
   */
  static async decrement (actor, amount = 1) {
    if (!getSetting('enableMythrasFatigue', true)) return
    const current = actor.flags?.elysium?.fatigue?.level || 0
    const newLevel = Math.max(0, current - amount)
    if (newLevel === current) return

    await this.setLevel(actor, newLevel, 'physical', 'recovery')
  }

  /**
   * Make Endurance roll for effort - on fail, increment fatigue
   */
  static async effortRoll (actor, effortType = 'strenuous') {
    if (!getSetting('enableMythrasFatigue', true)) return null

    const enduranceSkill = actor.items.find(i =>
      i.type === 'skill' && /endurance/i.test(i.name)
    )
    if (!enduranceSkill) {
      ui.notifications.warn(game.i18n.localize('Elysium.Fatigue.NoEnduranceSkill'))
      return null
    }

    const skillTotal = enduranceSkill.system?.total ?? enduranceSkill.system?.value ?? 0
    let difficultyMod = 0
    switch (effortType) {
      case 'light':     difficultyMod = +40; break
      case 'medium':    difficultyMod = +20; break
      case 'strenuous': difficultyMod = 0;   break
    }

    const roll = await new Roll('1d100').evaluate()
    const target = skillTotal + difficultyMod

    const isFumble = roll.total >= 99
    const isCrit   = roll.total <= Math.ceil(target / 20)
    const isFail   = roll.total > target
    const isPass   = !isFail

    let chatContent = `<div class="elysium-fatigue-roll">
      <h4>${game.i18n.localize('Elysium.Fatigue.EffortRoll')}: ${effortType}</h4>
      <p>${enduranceSkill.name} ${skillTotal}% ${difficultyMod >= 0 ? '+' : ''}${difficultyMod} = ${target}%</p>
      <p>${game.i18n.localize('Elysium.Roll')}: <strong>${roll.total}</strong></p>
      <p>`

    if (isFumble) {
      chatContent += game.i18n.localize('Elysium.Fatigue.Fumble')
      await this.increment(actor, 2, 'physical', 'effort fumble')
    } else if (isFail) {
      chatContent += game.i18n.localize('Elysium.Fatigue.Failed')
      await this.increment(actor, 1, 'physical', 'effort failure')
    } else if (isCrit) {
      chatContent += game.i18n.localize('Elysium.Fatigue.Critical')
    } else if (isPass) {
      chatContent += game.i18n.localize('Elysium.Fatigue.Passed')
    }

    chatContent += '</p></div>'
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: chatContent,
    })

    return { isPass, isFail, isCrit, isFumble, roll: roll.total }
  }

  /**
   * Recovery rate calculator
   */
  static getRecoveryMinutes (level, healingRate, recoveryType = 'physical') {
    const data = ELYSIUM.FATIGUE_LEVELS[level]
    if (!data?.recoveryMins) return null

    let effectiveHR = healingRate

    if (recoveryType === 'bloodloss') {
      effectiveHR = Math.max(1, Math.floor(healingRate / 2))
    }

    if (recoveryType === 'asphyxiation') {
      // Special: 1 level per minute regardless of HR
      return 1
    }

    return Math.ceil(data.recoveryMins / effectiveHR)
  }

  /**
   * Quick rest (manual GM trigger) — recover one level if appropriate
   */
  static async restRecover (actor, restMinutes = 60, restQuality = 'lightActivity') {
    const current = actor.flags?.elysium?.fatigue?.level || 0
    if (current === 0) return

    const recoveryType = actor.flags?.elysium?.fatigue?.recoveryType || 'physical'

    // Get HR with rest quality modifier
    let hr = actor.flags?.elysium?.derived?.healingRate || 1
    switch (restQuality) {
      case 'fullBedRest':     hr += 1; break
      case 'exceptionalCare': hr += 1; break
      case 'malnourished':    hr = Math.max(1, Math.floor(hr / 2)); break
      case 'strenuous':       return  // no recovery
    }

    const requiredMins = this.getRecoveryMinutes(current, hr, recoveryType)
    if (restMinutes >= requiredMins) {
      await this.decrement(actor, 1)
    }
  }


  // === FATIGUE ACTIVE EFFECT MANAGEMENT =============================

  static async _applyFatigueEffect (actor, level) {
    const data = ELYSIUM.FATIGUE_LEVELS[level]

    // Remove old fatigue AE if any
    const existingFatigueAEs = actor.effects.filter(e =>
      e.flags?.elysium?.group === 'fatigue'
    ).map(e => e.id)
    if (existingFatigueAEs.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', existingFatigueAEs)
    }

    // No effect if Fresh
    if (level === 0) return

    // Build new AE
    const changes = []
    if (data.skillGrade !== null && data.skillGrade !== 0) {
      changes.push({
        key:   'flags.elysium.modifiers.allSkills',
        mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
        value: String(data.skillGrade),
      })
    }
    if (data.apPenalty !== null && data.apPenalty > 0) {
      changes.push({
        key:   'flags.elysium.modifiers.apPenalty',
        mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
        value: String(data.apPenalty),
      })
    }

    const aeData = {
      name: game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`),
      icon: 'icons/svg/sleep.svg',
      changes,
      flags: {
        elysium: {
          group:        'fatigue',
          fatigueLevel: level,
          fatigueData:  data,
        }
      },
      disabled: false,
      transfer: false,
    }

    await actor.createEmbeddedDocuments('ActiveEffect', [aeData])
  }


  // === HELPERS ======================================================

  static _worstRecoveryType (typeA, typeB) {
    // worst = bloodloss > physical > asphyxiation
    const order = { asphyxiation: 0, physical: 1, bloodloss: 2 }
    if (order[typeB] > order[typeA]) return typeB
    return typeA
  }

  static _formatChat (actor, level, source) {
    const data = ELYSIUM.FATIGUE_LEVELS[level]
    return `
      <div class="elysium-fatigue-update">
        <h4>${actor.name} — ${game.i18n.localize('Elysium.Fatigue.Title')}</h4>
        <p><strong>${game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`)}</strong>
           (${game.i18n.localize('Elysium.Fatigue.Level')} ${level})</p>
        ${source ? `<p><em>${source}</em></p>` : ''}
        <ul>
          ${data.skillGrade ? `<li>${game.i18n.localize('Elysium.Fatigue.SkillGrade')}: ${data.skillGrade}%</li>` : ''}
          ${data.apPenalty ? `<li>${game.i18n.localize('Elysium.Fatigue.APPenalty')}: -${data.apPenalty}</li>` : ''}
          ${data.movePenalty ? `<li>${game.i18n.localize('Elysium.Fatigue.MovePenalty')}: ${data.movePenalty * 5}ft</li>` : ''}
          ${data.initiativePen ? `<li>${game.i18n.localize('Elysium.Fatigue.InitiativePen')}: ${data.initiativePen}</li>` : ''}
        </ul>
      </div>
    `
  }
}
