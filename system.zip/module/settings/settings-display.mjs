const SETTINGS = {

  actorFontColour: {
    name: "Elysium.Settings.actorFontColour",
    hint: "Elysium.Settings.actorFontColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorTitleColour: {
    name: "Elysium.Settings.actorTitleColour",
    hint: "Elysium.Settings.actorTitleColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorTertiaryColour: {
    name: "Elysium.Settings.actorTertiaryColour",
    hint: "Elysium.Settings.actorTertiaryColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorBackColour: {
    name: "Elysium.Settings.actorBackColour",
    hint: "Elysium.Settings.actorBackColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  secBackColour: {
    name: "Elysium.Settings.secBackColour",
    hint: "Elysium.Settings.secBackColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorTabNameColour: {
    name: "Elysium.Settings.actorTabNameColour",
    hint: "Elysium.Settings.actorTabNameColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorRollableColour: {
    name: "Elysium.Settings.actorRollableColour",
    hint: "Elysium.Settings.actorRollableColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorRollableShadowColour: {
    name: "Elysium.Settings.actorRollableShadowColour",
    hint: "Elysium.Settings.actorRollableShadowColourHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

  actorSheetBackground: {
    name: "Elysium.Settings.actorSheetBackground",
    hint: "Elysium.Settings.actorSheetBackgroundHint",
    scope: "world",
    config: false,
    type: String,
    filePicker: 'Image',
    default: "",
  },

  // F11 (rc.4 cleanup, 2026-05-15): `charSheetLogo` setting + display-settings.hbs file-picker UI + character.mjs:362 `context.logo = ...` line all retired together. The setting was wired to read a user-pickable logo image and stash it into character-sheet render context, but no template ever consumed `{{logo}}` — the rebuild dropped the logo display from the sheet header. Surfaced during rc.4 brand-art audit when investigating where the BRP-era `char-sheet-logo.png` was being used. Dead-code retirement.

  charSheetMainFont: {
    name: "Elysium.Settings.charSheetMainFont",
    hint: "Elysium.Settings.charSheetMainFontHint",
    scope: "world",
    config: false,
    type: String,
    filePicker: 'Other',
    default: "",
  },
  charSheetTitleFont: {
    name: "Elysium.Settings.charSheetTitleFont",
    hint: "Elysium.Settings.charSheetTitleFontHint",
    scope: "world",
    config: false,
    type: String,
    filePicker: 'Other',
    default: "",
  },
  charSheetMainFontSize: {
    name: "Elysium.Settings.charSheetMainFontSize",
    hint: "Elysium.Settings.charSheetMainFontSizeHint",
    scope: "world",
    config: false,
    type: Number,
    default: 16
  },

  charSheetTitleFontSize: {
    name: "Elysium.Settings.charSheetTitleFontSize",
    hint: "Elysium.Settings.charSheetTitleFontSizeHint",
    scope: "world",
    config: false,
    type: Number,
    default: 20
  },

  iconPrimary: {
    name: "Elysium.Settings.iconPrimary",
    hint: "Elysium.Settings.iconPrimaryHint",
    scope: "world",
    config: false,
    type: String,
    default: ""
  },

}

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api
export class ElysiumDisplaySettings extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'rulesmenu'],
    id: 'char-settings',
    actions: {
      reset: ElysiumDisplaySettings.onResetDefaults,
    },
    form: {
      handler: ElysiumDisplaySettings.formHandler,
      closeOnSubmit: true,
      submitOnChange: false
    },
    position: {
      width: 550,
      height: 'auto',
    },
    tag: 'form',
    window: {
      resizable: true,
      title: 'Elysium.systemSettings',
      contentClasses: ["standard-form"]
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/settings/display-settings.hbs',
      scrollable: ['']
     },
    footer: { template: 'templates/generic/form-footer.hbs' }
  }

  async _prepareContext(options) {
    const isGM = game.user.isGM;
    const optSet = {}
    for (const [k, v] of Object.entries(SETTINGS)) {
      optSet[k] = {
        value: game.settings.get('elysium', k),
        setting: v
      }
    }
    return {
      isGM,
      optSet,
      buttons: [
        { type: "submit", icon: "fa-solid fa-save", label: "SETTINGS.Save" },
        { type: "reset", action: "reset", icon: "fa-solid fa-undo", label: "SETTINGS.Reset" },
      ]
    }
  }

  static registerSettings() {
    for (const [k, v] of Object.entries(SETTINGS)) {
      game.settings.register('elysium', k, v)
    }
  }

  static async onResetDefaults(event) {
    event.preventDefault()
    for await (const [k, v] of Object.entries(SETTINGS)) {
      await game.settings.set('elysium', k, v?.default)
    }
    return this.render()
  }

  static async formHandler(event, form, formData) {
    const settings = foundry.utils.expandObject(formData.object)
    await Promise.all(
      Object.entries(settings)
        .map(([key, value]) => game.settings.set("elysium", key, value))
    )
  }

}
