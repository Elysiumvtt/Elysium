/**
 * SkillDataModel — schema for items of type 'skill'.
 *
 * Per P6.5 spec. Stored-schema-only. 131 compendium items
 * (107 in skills.db + 24 in arcane-knowledge.db).
 *
 * Skill is the most-referenced item type in the system. The casting subsystem
 * (cast-shared.mjs:289, custom-spell-builder.mjs:90,99) reads
 * `skill.system.elysium.arcaneRole` to identify form/technique skills for
 * arcane spell construction. Actor-itemDrop and the actor.mjs:168 prep chain
 * heavily read/write skill fields.
 *
 * Schema decisions:
 *   - SIX compendium-only fields declared (side-finding #14 family). Top-level:
 *     `cmbtSkill`, `fixed`, `magicSkill`, `career` — all booleans, zero
 *     code readers, pure compendium-content metadata. Elysium: `arcaneRole`,
 *     `forbidden`. arcaneRole IS read by the casting system (values '', 'form',
 *     'technique'); `forbidden` is empty in compendium, declared permissively.
 *   - `skill.category` initial is `'comnmod'` (matching compendium + code in
 *     module/apps/select-lists.mjs:51), not template's `'cmmnmod'` typo
 *     (side-finding #17). Becomes a non-issue when template's Item block
 *     is removed in P6.6.
 *   - `baseFormula` is a 3-key SchemaField with explicit keys "1", "2", "Func".
 *     Slots "1" and "2" are each `{stat, value}` SchemaFields.
 *   - `groupSkills` is permissive `ArrayField<ObjectField>` — empty in
 *     compendium; shape TBD when populated by runtime usage. P12 to tighten.
 *   - All string enums (category, skillCategory, skillSubgroup, arcaneRole,
 *     baseFormula.Func, baseFormula.X.stat) FREE — content-extensibility and
 *     legacy-value concerns. Same conservative decision as P6.4.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

/** Inner SchemaField for one baseFormula slot: {stat, value}. */
function makeFormulaSlot () {
  return new fields.SchemaField({
    stat:  new fields.StringField({ initial: 'fixed' }),
    value: new fields.NumberField({ integer: true, initial: 0 }),
  })
}

export class SkillDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      subType:     new fields.StringField({ initial: '' }),
      base:        new fields.NumberField({ integer: true, initial: 0 }),
      xp:          new fields.NumberField({ integer: true, initial: 0 }),
      culture:     new fields.NumberField({ integer: true, initial: 0 }),
      career:  new fields.NumberField({ integer: true, initial: 0 }),
      personality: new fields.NumberField({ integer: true, initial: 0 }),
      personal:    new fields.NumberField({ integer: true, initial: 0 }),
      effects:     new fields.NumberField({ integer: true, initial: 0 }),

      // baseFormula: SchemaField with explicit "1", "2", "Func" keys per template + compendium
      baseFormula: new fields.SchemaField({
        '1':  makeFormulaSlot(),
        '2':  makeFormulaSlot(),
        Func: new fields.StringField({ initial: 'or' }),
      }),

      noXP: new fields.BooleanField({ initial: false }),
      // Initial 'comnmod' — matches compendium + code; template's 'cmmnmod' is a typo
      // (side-finding #17). Template Item block removed in P6.6.
      category:    new fields.StringField({ initial: 'comnmod' }),
      chosen:      new fields.BooleanField({ initial: false }),
      specialism:  new fields.BooleanField({ initial: false }),
      group:       new fields.BooleanField({ initial: false }),
      groupSkills: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      variable:    new fields.BooleanField({ initial: false }),
      specName:    new fields.StringField({ initial: '' }),
      mainName:    new fields.StringField({ initial: '' }),
      prsnlty:     new fields.BooleanField({ initial: false }),
      occupation:  new fields.BooleanField({ initial: false }),
      cultural:    new fields.BooleanField({ initial: false }),
      improve:     new fields.BooleanField({ initial: false }),
      basic:       new fields.BooleanField({ initial: false }),
      combat:      new fields.BooleanField({ initial: false }),

      // Compendium-driven legacy (side-finding #14 family). Zero code readers.
      // Note `cmbtSkill` and `combat` are TWO DIFFERENT FIELDS with similar meaning;
      // both must be declared because both appear in stored data.
      cmbtSkill:    new fields.BooleanField({ initial: false }),
      fixed:        new fields.BooleanField({ initial: false }),
      magicSkill:   new fields.BooleanField({ initial: false }),
      career: new fields.BooleanField({ initial: false }),

      elysium: new fields.SchemaField({
        skillCategory: new fields.StringField({ initial: 'standard' }),
        skillSubgroup: new fields.StringField({ initial: '' }),
        // arcaneRole: '', 'form', or 'technique' per casting system. CRITICAL —
        // read by cast-shared.mjs:289 and custom-spell-builder.mjs:90,99 to route
        // form/technique skills during spell construction.
        arcaneRole:    new fields.StringField({ initial: '' }),
        // forbidden: paralleling arcane.elysium.forbidden. Empty in compendium.
        forbidden:     new fields.BooleanField({ initial: false }),
      }),
    }
  }
}
