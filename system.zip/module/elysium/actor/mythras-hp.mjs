/**
 * Elysium — Mythras Hit Location HP override
 *
 * BRP-base prepareDerivedData calculates each hit-location's maxHP from
 * `health.max / fractionHP + adj`. That's the Magic World / RuneQuest
 * style. Mythras (which Elysium uses) calculates HP from CON+SIZ
 * directly, with per-location modifiers.
 *
 * This module patches ElysiumActor.prototype.prepareDerivedData so that
 * AFTER BRP-base runs its standard prep, we override each hit-location's
 * maxHP and currHP using the Mythras formula.
 *
 * The patch is idempotent — it stores the original method and only
 * wraps it once. Safe to call multiple times.
 *
 * Mythras humanoid HP table:
 *   base    = ceil((CON+SIZ) / 5), minimum 1
 *   Leg     = base
 *   Abdomen = base + 1
 *   Chest   = base + 2
 *   Arm     = max(1, base - 1)
 *   Head    = base
 *
 * Custom locType strings ('tail', 'wing', 'limb') get sensible defaults.
 */

import { getSetting } from '../settings/register-settings.mjs'
import { ELYSIUM } from '../config/config.mjs'
import { ElysiumHitLocState } from './hit-loc-state.mjs'
let _patched = false

export class ElysiumMythrasHP {

  /**
   * Install the prepareDerivedData wrapper. Called once at init.
   *
   * Prep sequence after this wrapper installs:
   *   1. original.call(this)                       // BRP-base standard prep
   *   2. ElysiumMythrasHP.applyToActor             // override hit-loc maxHP
   *   3. ElysiumHitLocState.applyToActor           // derive currHP + flags
   *                                                //   + health.value pool
   *   4. ElysiumMythrasHP.relabelHealthAsTempHP    // header label only
   *
   * Steps 2 and 3 must be in this order: hit-loc-state reads the maxHP
   * that MythrasHP wrote. Splitting them keeps each module focused on
   * one concern (Mythras formula vs wound-derived state) and avoids
   * the actor-type branching that bolting both onto MythrasHP required
   * in alpha.1-.4.
   *
   * v0.22.0-alpha.9: armor-HP scaling removed. Armor HP is now flat
   * per material (see system.elysium.apMax) — the per-location surface-
   * area multipliers no longer apply.
   */
  static install () {
    if (_patched) return

    // Locate the ElysiumActor class. The system documents it via CONFIG.Actor.documentClass.
    const ActorClass = CONFIG?.Actor?.documentClass
    if (!ActorClass?.prototype?.prepareDerivedData) {
      console.warn('Elysium | Cannot patch prepareDerivedData — ElysiumActor not found')
      return
    }

    const original = ActorClass.prototype.prepareDerivedData

    ActorClass.prototype.prepareDerivedData = function () {
      // Run BRP-base standard prep first
      original.call(this)

      // Then run Elysium's hit-location prep chain. Each step is wrapped
      // in its own try/catch so a failure in one doesn't break the rest.
      try { ElysiumMythrasHP.applyToActor(this) }
      catch (err) { console.error('Elysium | MythrasHP.applyToActor failed:', err) }

      try { ElysiumHitLocState.applyToActor(this) }
      catch (err) { console.error('Elysium | HitLocState.applyToActor failed:', err) }

      try { ElysiumMythrasHP.relabelHealthAsTempHP(this) }
      catch (err) { console.error('Elysium | MythrasHP.relabelHealthAsTempHP failed:', err) }
    }

    _patched = true
    console.log('Elysium | Patched ElysiumActor.prepareDerivedData for Mythras HP')
  }

  /**
   * Compute Mythras HP base from an actor's CON+SIZ.
   * Synchronous — safe to call inside prepareDerivedData.
   */
  static computeBase (actor) {
    const stats = actor.system?.stats
    if (!stats) return 0

    // Use BRP-base pre-computed totals if available
    const con = (typeof stats.con?.total === 'number') ? stats.con.total : 0
    const siz = (typeof stats.siz?.total === 'number') ? stats.siz.total : 0

    if (con === 0 && siz === 0) return 0
    return Math.max(1, Math.ceil((con + siz) / 5))
  }

  /**
   * Map a location's body-part designation to its HP value given the base.
   *
   * Mythras HP table per location:
   *   Head, Leg, Tail = base
   *   Abdomen         = base + 1
   *   Chest           = base + 2
   *   Arm, Wing       = max(1, base - 1)
   *
   * v0.20.0: `bodyPart` is canonical (schema field on every hit-location).
   * If a hand-rolled location doesn't carry one, we fall through to the
   * BRP locType for a defensible baseline.
   *
   * v0.19.0: applies the `hpMultiplier` world setting (default 1.0,
   * range 0.5-4.0 step 0.25). The multiplier scales the raw Mythras
   * value, with Math.max(1, ...) preserving the canonical minimum of
   * 1 HP per location even when the multiplier is below 1.0. Rounding
   * uses Math.ceil so the multiplier favours the defender slightly,
   * which aligns with the "make game less deadly" intent for multipliers
   * above 1.0.
   */
  static hpForLocation (base, locType, bodyPart, name) {
    if (base === 0) return 0

    // Prefer the explicit bodyPart; fall through to a locType-based default
    // if no bodyPart is set (legacy / hand-rolled actors).
    const part = bodyPart || this._inferBodyPart(locType)

    let raw
    switch (part) {
      case 'head':    raw = base; break
      case 'chest':   raw = base + 2; break
      case 'abdomen': raw = base + 1; break
      case 'leg':     raw = base; break
      case 'arm':     raw = Math.max(1, base - 1); break
      case 'tail':    raw = base; break
      case 'wing':    raw = Math.max(1, base - 1); break
      default:        raw = base    // unknown part — neutral baseline
    }

    // v0.19.0: apply the HP multiplier. getSetting returns 1.0 if the
    // setting is unregistered (defensive fallback).
    const multiplier = Number(getSetting('hpMultiplier', 1.0)) || 1.0
    return Math.max(1, Math.ceil(raw * multiplier))
  }

  /**
   * Fallback inference when a hit-location doesn't carry an explicit
   * system.elysium.bodyPart. v0.20.0: the canonical field is bodyPart;
   * this is only used as a defensive baseline when content is hand-rolled
   * without it.
   */
  static _inferBodyPart (locType) {
    if (locType === 'head')    return 'head'
    if (locType === 'chest')   return 'chest'
    if (locType === 'abdomen') return 'abdomen'
    // 'limb' alone can't distinguish arm from leg without bodyPart;
    // default to 'leg' (= base HP, the safer/middle option).
    if (locType === 'limb')    return 'leg'
    return ''
  }

  /**
   * Override hit-location maxHP on an actor in place.
   * Runs synchronously inside prepareDerivedData. Does not write to DB —
   * BRP-base itself doesn't persist these either; they're derived data.
   *
   * v0.22.0-alpha.5: scope narrowed back to **maxHP only**. Per-location
   * currHP derivation, condition flag computation, actor-level cascade
   * flags, and the flat-HP pool decrement all live in
   * `module/elysium/actor/hit-loc-state.mjs::ElysiumHitLocState.applyToActor`
   * which the install wrapper sequences immediately after this. Both
   * modules iterate the actor's items; the cost is small and the
   * separation of concerns is worth it.
   *
   * Why this split: in alpha.1-.4 we tried bolting currHP/flag/health.value
   * logic onto MythrasHP, which produced an `actor.type === 'character'`
   * branch and a `_source` read for NPCs. Both were architectural smells.
   * Characters and NPCs share the same hit-location and wound-item schemas;
   * the prep flow should not pretend otherwise. Splitting the maxHP override
   * from the wound→currHP derivation lets each module operate uniformly on
   * any actor type with hit-location items.
   */
  static applyToActor (actor) {
    if (!actor?.items?.size) return
    const base = this.computeBase(actor)
    if (base === 0) return    // no stats yet; leave BRP-base defaults

    // BRP-base `health.mod` field (labelled "HP Bonus" on the CHAR tab, editable
    // by the player) used to add to the actor's overall HP pool. Under
    // Elysium's per-location HP model, a flat HP bonus applies to every
    // location instead. health.effects works the same way (Active Effect
    // contributions to HP).
    const hpMod = (Number(actor.system?.health?.mod) || 0)
                + (Number(actor.system?.health?.effects) || 0)

    for (const item of actor.items) {
      if (item.type !== 'hit-location') continue

      const locType  = item.system?.locType || 'limb'
      const bodyPart = item.system?.elysium?.bodyPart || ''
      const name     = item.name || ''
      // v0.19.4: Withered condition reduces maxHP per-location via a
      // signed modifier stored on the hit-location item. Negative values
      // shrink the location's HP cap; positive values can buffer it.
      // The modifier is applied AFTER the Mythras formula + hpMod, so
      // it stacks on top of the derived baseline.
      const withMod = Number(item.system?.elysium?.maxHPModifier) || 0
      const baseHp  = this.hpForLocation(base, locType, bodyPart, name) + hpMod
      const newMax  = Math.max(1, baseHp + withMod)

      item.system.maxHP = newMax
    }
  }

  /**
   * After BRP-base computes system.health.value/max from total HP and wounds,
   * override the visible values to mirror the actor's Temp HP pool.
   *
   * Why: BRP-base health.value naturally goes negative as wounds accumulate
   * (because each wound subtracts from health.max), which is misleading
   * once per-location HP is the source of truth. Repurposing health.{value,max}
   * Relabel the header HP panel from "Hit Points" to "Temp HP" so users
   * don't mistake it for general vitality (per-location HP is the real
   * vitality in Mythras). v0.5.0+: we no longer hijack value/max — those
   * come from system.tempHP via the inputs in the panel — but BRP-base's
   * native label still reads "Hit Points". Override just the label.
   *
   * Important: only override `label` (the long-form name used in the
   * header panel). DO NOT override `labelAbbr` — BRP-base reuses the abbr
   * as the column header in the hit-location and weapon damage tables
   * ("HP" / "DAMAGE +HP") and as a parameter in the "{HP} Bonus" CHAR
   * tab row. Overriding labelAbbr leaks "Temp HP" into all of those.
   */
  static relabelHealthAsTempHP (actor) {
    actor.system.health.label = game.i18n.localize('Elysium.TempHP.Title')
  }
}
