import { ElysiumCheck } from '../apps/check.mjs'
import { OPCard } from './opposed-card.mjs'
export class CBCard {

  //Resolve a combat card - roll dice, update and close
  static async CBResolve(config) {
    const targetMsg = await game.messages.get(config.targetChatId)
    const chatCards = targetMsg.flags.elysium.chatCard

    //Sort chatCards by result level, by roll and then by rawValue
    chatCards.sort(function (a, b) {
      const x = a.rawScore;
      const y = b.rawScore;
      const r = a.rollVal;
      const s = b.rollVal;
      const p = a.resultLevel;
      const q = b.resultLevel;
      if (p > q) { return -1 };
      if (p < q) { return 1 };
      if (r > s) { return -1 };
      if (r < s) { return 1 };
      if (x > y) { return -1 };
      if (x < y) { return 1 };
      return 0;
    });

    const newchatCards = []
    //Get the success level of the second placed person
    let adjLevel = 0
    if (chatCards.length > 1) {
      adjLevel = chatCards[1].resultLevel
      adjLevel = Math.max(adjLevel - 1, 0)
    }
    for (let i of chatCards) {
      i.origResLevel = i.resultLevel
      if (i.origResLevel > 1) {
        i.resultLevel = Math.max(i.resultLevel - adjLevel, 2)
      }
      i.resultLabel = game.i18n.localize('Elysium.resultLevel.' + i.resultLevel)
      i.origResLabel = game.i18n.localize('Elysium.resultLevel.' + i.origResLevel)
      newchatCards.push(i)
      await OPCard.showDiceRoll(i)
    }

    await targetMsg.update({
      'flags.elysium.chatCard': newchatCards,
      'flags.elysium.state': 'closed',
    })
    const pushhtml = await ElysiumCheck.startChat(targetMsg.flags.elysium)
    await targetMsg.update({ content: pushhtml })
    await ElysiumCheck.tickXP(targetMsg.flags.elysium)
    return
  }

}
