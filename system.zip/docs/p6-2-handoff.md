# P6.2 Prep Audit — Standard Item DataModels

Companion to `p6-prep-audit.md`. Captured 2026-05-13 against the v1.0.0-alpha.4 source
tree and ElysiumCompendium content.

## Scope: 8 types

| Type | Own | Elysium subkeys | Compendium content |
|---|---|---|---|
| passion | 3 (base, improve, xp) | 4 (isSpecialism, parentName, specialismName, category) | none |
| culture | 4 (skills, groups, move, stats) | 1 deeply nested (ancestry: 14 sub-fields) | 20 items in ancestries.db |
| persTrait | 6 (oppName, base, improve, oppimprove, xp, basic) | none | none |
| allegiance | 9 (allegPoints, opposeAlleg, allegTitle, improve, allegEnemy, allegAllied, allegApoth, benefits, xp) | none | 1 item |
| mutation | 3 (impact, minorOnly, minor) | 3 (visionType, visionRange, abilityTier) | 69 items |
| super | 12 (powerMod, category, cpc, cpcSpent, level, range, duration, pppl, specialism, specName, mainName, chosen) | 10 (tier, maxTier, prerequisite, category, theme, usesPerEncounter, currentUses, visionType, visionRange, favouredEnemy) | 18 items |
| ability | 6 (base, xp, improve, noXP, effectText, prerequisitesText) | 7 useful + 2 doc strings (abilityType, category, theme, activation, benefits, drawbacks, addOns; + _doc, _addOnSchema_doc) | 47 items |
| gear | 7 (quantity, enc, price, cost, equipStatus, pSCurr, pSMax) | 3 template + 3 compendium-only (isContainer, containedIn, capacity; arcaneRole, isTome, linkedSkill) | 150 items across equipment.db + conditions.db + tomes.db |

Plus the shared base template: `description`, `gmDescription` (HTMLFields).

Total declared schema slots across all 8 types: ~70 (P3 estimate was right for P6.2).

## Compendium-content divergences (CRITICAL — schema MUST accept all live values)

### ability — needs declaration of an extra field

- `elysium.arcaneParent` (StringField). NOT in template.json. Present in compendium content
  (used by some ability items to reference an arcane parent spell/school). Without it,
  compendium drops will fail strict validation.

### gear — needs declaration of three extra fields, all in `elysium`

The compendium ships gear with these `elysium.X` keys not in template.json:
- `arcaneRole` — string (values: 'form', 'technique', and possibly others). Used by tomes.
  **Note**: skill items ALSO have a `system.elysium.arcaneRole` field that the casting
  system reads (`module/casting/cast-shared.mjs:289` etc.). That's a different field on a
  different type — the gear-side `arcaneRole` and skill-side `arcaneRole` are independent
  declarations on their respective DataModels.
- `isTome` — boolean. Marks gear items as tomes. NO code reads this; pure metadata.
- `linkedSkill` — string (e.g., `'i.skill.form-animal'`). Links tome to a skill. NO code
  reads this; pure metadata.

The original `elysium.{isContainer, containedIn, capacity}` from template.json are NOT
present on most compendium gear (tomes have neither set). Both sets must coexist in
the schema; live data may have either, neither, or both.

### culture — the ancestry shape

`culture.elysium.ancestry` is the largest single nested SchemaField in P6.2. 14 sub-fields
including arrays of objects and nested SchemaFields. Confirmed shapes from compendium:

- `isElysiumAncestry: boolean` (whether this culture is also an ancestry)
- `baseMove: number`
- `flyMove: number`
- `swimMove: number`
- `buildPoints: number`
- `skillPoints: number`
- `statMods: [{stat: string, value: number}]` — stat strings observed: 'INT' (uppercase!). Note: actor stats use lowercase ('int'); the case mismatch is pre-existing content data, schema accepts any string.
- `traits: [{uuid: string, name: string}]` — references to mutation/ability items. **Note shape: {uuid, name}, NOT {uuid, elysiumid}** like personality skills.
- `naturalArmor: {ap: number, locations: string}` — `locations` is a string like 'all'
- `naturalWeapons: []` — observed empty in all 20 compendium ancestries; shape TBD when populated. Conservative: `ArrayField<ObjectField>` to accept any shape until usage data exists. **Defer locking shape to P12.**
- `resistances: {}` — observed empty. Likely TypedObjectField<NumberField> when populated. Same defer-to-P12 rationale.
- `languages: [string]` — array of strings, e.g. `['Draconic']`
- `subraces: []` — array of (presumably) culture IDs. Empty in all 20 compendium ancestries.
- `parentId: string` — id of the parent culture if isSubrace
- `isSubrace: boolean`
- `hitLocationSet: string` — values observed: 'humanoid' only. Free-string for now.

**Schema decision for `naturalWeapons`/`resistances`/`subraces`**: declare as
`ArrayField<ObjectField>` / `ObjectField` / `ArrayField<StringField>` respectively. Avoid
locking inner shapes for fields where live compendium data is empty (no ground truth).
Side-finding for P12: tighten shapes once content populates these.

### culture top-level skill/group/stats fields

Template.json declares `{skills, groups, move, stats}` at culture's top level. Compendium
content has NONE of these populated (all 20 ancestries have no `skills`/`groups`/`move`/`stats`
at top level — those are pure character-creation-tool fields used when a culture is dragged
onto a character).

The `skills` and `groups` on culture use the `{uuid, elysiumid, bonus}` shape from
`culture.mjs:_onDrop:217,243`. **Critical**: bonus is included — NOT identical to
`personality.skills` which uses `{uuid, elysiumid}`. Two different shapes; do NOT factor
into a shared helper.

The `stats` field is a per-stat `{formula: string, mod: number}` block. 7 stats (no edu).

### Live data shapes vs template — passion, persTrait, allegiance, mutation, super

- `passion`: template + compendium align. No divergences.
- `persTrait`: no compendium content; trust template.json.
- `allegiance`: template + compendium align across all 10 fields. Clean.
- `mutation`: compendium has `description` + the 3 elysium subkeys only. Template's
  top-level `{impact, minorOnly, minor}` are absent from compendium content (they default
  from schema). Schema declares all 6; compendium-content writes only initialize what's there.
- `super`: same pattern as mutation — compendium has only `description` + the 10 elysium
  subkeys. Template's 12 top-level fields default-initialize. Schema declares all.

## String-enum choices decisions

Following the P3 design's caution about `viewTab` ("locking down the choices list might
break if a saved instance has an outdated value"), I'm conservative about adding `choices:`
constraints. Audit results:

### NOT locked (free StringField — risk too high)

- `ability.elysium.abilityType` ∈ {passive, percentile, static} — only 3 observed values but
  used by automation logic; future content extension is plausible. Leave free.
- `ability.elysium.category` ∈ {arcane, general, magical, martial} — content categories
  that may be extended. Leave free.
- `ability.elysium.theme` ∈ 17 values across compendium — content-creator-extensible by
  design (matches character-class concept). Leave free.
- `ability.elysium.activation.type` ∈ {passive, sustained, triggered} — same reasoning,
  leave free.
- `super.elysium.category` ∈ {aura, conditional, passive, triggered} — leave free.
- `super.elysium.theme` ∈ 6 observed values, same content-extensibility argument. Leave free.
- `mutation.impact` — template default 'adv'; compendium has no examples (only description
  populated). Leave free.
- `gear.equipStatus` ∈ {equipped, stowed, carried, worn} — the elysium/hooks/item.mjs:34-47
  normalizer auto-corrects legacy 'carried'/'worn' to 'stowed' POST-create. Schema validation
  fires BEFORE the normalizer, so if I add `choices: ['equipped', 'stowed']` then compendium
  drops with legacy 'carried' values fail before the normalizer can fix them. Two options:
  (a) include all legacy values in choices, (b) leave free. Going with (b) — leave free.
  Captures the same risk pattern as `viewTab`. Side-finding #8 for P12: revisit once
  legacy-content normalization can run pre-validation (would need a Foundry feature, not
  available in V14).
- `passion.elysium.category` ∈ {general, ...?} — only template default 'general' known;
  free.

### Locked with choices (low risk, well-bounded)

None in P6.2. Every enum candidate has either content-extensibility risk, a legacy-content
risk, or insufficient ground truth to lock confidently. P6.3 (combat) and P6.4 (magic) will
have more lockable choices (damage types, hit locations, etc.).

## Documentation-only fields in template.json — must NOT declare in schema

These fields are pure documentation strings template.json carries to remind developers about
the shape:

- `ability.elysium._doc` (under `activation`) — drop. Just template-doc text.
  Wait — re-checking, the actual field is `ability.elysium.activation._doc`. Let me
  re-state: template.json's `ability.elysium.activation` contains a `_doc` key inside it.
  Schema for `activation` declares the 5 real fields (type, actionCost, ppCost, duration,
  endConditions) and drops `_doc`.
- `ability.elysium._addOnSchema_doc` — drop. Documentation for the `addOns` array shape.

If these appear in any stored data, DataModel cleanData will silently drop them. Theoretical
migration concern only — they were never meant to be stored.

## Sheet drag-drop shapes

Three shapes for skill-reference arrays across P6.2/P6.1/P6.5 types:

| Shape | Used by |
|---|---|
| `{uuid, elysiumid}` | personality (P6.1), super.powerMod |
| `{uuid, elysiumid, bonus}` | culture.skills, culture.groups[].skills |
| `{uuid, name}` | culture.elysium.ancestry.traits |

Three distinct shapes — do NOT factor into a single shared helper. Each is its own
`SchemaField` inside the relevant DataModel.

## Other dynamic write findings

None for P6.2. Per-type grep showed sheet writes stay within template-declared fields
(only `super` writes `system.mainName` to ensure it's populated on first open — a populated-default
flow, not an undeclared field).

## Side findings flagged (NOT for P6.2 — log only)

**#8 — `equipStatus` legacy-value handling.** The `elysium/hooks/item.mjs` `preCreateItem`
normalizer corrects legacy 'carried'/'worn' values to 'stowed' AFTER schema validation. Adding
`choices: ['equipped', 'stowed']` would reject legacy compendium drops before normalization
could run. Leave as free StringField; P12 reconsiders if Foundry exposes a pre-validation
data-migration hook.

**#9 — `culture.elysium.ancestry.statMods[].stat` casing.** Compendium uses uppercase ('INT',
'STR'); actor.system.stats keys are lowercase ('int', 'str'). Pre-existing content quirk;
free StringField accepts either. Code that consumes statMods presumably normalizes case (or
should). Side-finding for P12 audit.

**#10 — `culture.elysium.ancestry.{naturalWeapons, resistances, subraces}` inner shapes
unknown.** All empty in 20-of-20 compendium ancestries. Schemas declared with permissive
inner shapes (ArrayField<ObjectField>, ObjectField, ArrayField<StringField>). Tighten once
ground-truth content exists. P12.

# P6.2 implementation spec — schemas

## Shared helpers (`module/data/item/_shared.mjs` additions)

P6.2 doesn't introduce new helpers. Each type's skill-ref shape is too divergent for
shared abstraction (per audit above). `makeItemBase()` continues to cover description+
gmDescription.

## Per-type schemas

### passion.mjs (3 own + base + 4 elysium = 9 slots)

```js
...makeItemBase(),
base:    new fields.NumberField({ integer: true, initial: 0 }),
improve: new fields.BooleanField({ initial: false }),
xp:      new fields.NumberField({ integer: true, initial: 0 }),
elysium: new fields.SchemaField({
  isSpecialism:    new fields.BooleanField({ initial: false }),
  parentName:      new fields.StringField({ initial: '' }),
  specialismName:  new fields.StringField({ initial: '' }),
  category:        new fields.StringField({ initial: 'general' }),  // not locked
}),
```

### persTrait.mjs (6 own + base = 8 slots)

```js
...makeItemBase(),
oppName:     new fields.StringField({ initial: '' }),
base:        new fields.NumberField({ integer: true, initial: 0 }),
improve:     new fields.BooleanField({ initial: false }),
oppimprove:  new fields.BooleanField({ initial: false }),
xp:          new fields.NumberField({ integer: true, initial: 0 }),
basic:       new fields.BooleanField({ initial: false }),
```

### allegiance.mjs (9 own + base = 11 slots)

```js
...makeItemBase(),
allegPoints:  new fields.NumberField({ integer: true, initial: 0 }),
opposeAlleg:  new fields.StringField({ initial: '' }),
allegTitle:   new fields.StringField({ initial: '' }),
improve:      new fields.BooleanField({ initial: false }),
allegEnemy:   new fields.BooleanField({ initial: false }),
allegAllied:  new fields.BooleanField({ initial: false }),
allegApoth:   new fields.BooleanField({ initial: false }),
benefits:     new fields.StringField({ initial: '' }),  // free-text per template; not HTMLField (template default is "")
xp:           new fields.NumberField({ integer: true, initial: 0 }),
```

### mutation.mjs (3 own + base + 3 elysium = 8 slots)

```js
...makeItemBase(),
impact:    new fields.StringField({ initial: 'adv' }),  // free (no compendium ground truth)
minorOnly: new fields.BooleanField({ initial: false }),
minor:     new fields.BooleanField({ initial: true }),
elysium: new fields.SchemaField({
  visionType:   new fields.StringField({ initial: '' }),  // free
  visionRange:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  abilityTier:  new fields.NumberField({ integer: true, initial: 1, min: 1 }),
}),
```

### super.mjs (12 own + base + 10 elysium = 23 slots)

```js
...makeItemBase(),
// powerMod is an ArrayField<{uuid, elysiumid}> per super.mjs:185
powerMod: new fields.ArrayField(
  new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
  }),
  { initial: [] },
),
category:    new fields.StringField({ initial: '' }),
cpc:         new fields.StringField({ initial: '1' }),       // stored as string per template
cpcSpent:    new fields.NumberField({ integer: true, initial: 0 }),
level:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
range:       new fields.StringField({ initial: '' }),
duration:    new fields.StringField({ initial: '' }),
pppl:        new fields.StringField({ initial: '1' }),       // stored as string per template
specialism:  new fields.BooleanField({ initial: false }),
specName:    new fields.StringField({ initial: '' }),
mainName:    new fields.StringField({ initial: '' }),
chosen:      new fields.BooleanField({ initial: false }),
elysium: new fields.SchemaField({
  tier:             new fields.NumberField({ integer: true, initial: 1, min: 0 }),
  maxTier:          new fields.NumberField({ integer: true, initial: 3, min: 0 }),
  prerequisite:     new fields.StringField({ initial: '' }),
  category:         new fields.StringField({ initial: 'passive' }),  // free
  theme:            new fields.StringField({ initial: '' }),         // free
  usesPerEncounter: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  currentUses:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  visionType:       new fields.StringField({ initial: '' }),
  visionRange:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  favouredEnemy: new fields.SchemaField({
    isfavouredEnemy: new fields.BooleanField({ initial: false }),  // template typo preserved
    targets:         new fields.ArrayField(new fields.StringField(), { initial: [] }),
  }),
}),
```

### ability.mjs (6 own + base + 8 elysium = 16 slots; includes arcaneParent NOT in template)

```js
...makeItemBase(),
base:               new fields.NumberField({ integer: true, initial: 0 }),
xp:                 new fields.NumberField({ integer: true, initial: 0 }),
improve:            new fields.BooleanField({ initial: false }),
noXP:               new fields.BooleanField({ initial: false }),
effectText:         new fields.HTMLField({ initial: '' }),
prerequisitesText:  new fields.HTMLField({ initial: '' }),
elysium: new fields.SchemaField({
  abilityType:   new fields.StringField({ initial: 'static' }),  // free
  category:      new fields.StringField({ initial: 'general' }), // free
  theme:         new fields.StringField({ initial: '' }),         // free
  arcaneParent:  new fields.StringField({ initial: '' }),         // NOT in template — declared per compendium audit
  activation: new fields.SchemaField({
    type:          new fields.StringField({ initial: 'passive' }),  // free
    actionCost:    new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    ppCost:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    duration:      new fields.StringField({ initial: '' }),
    endConditions: new fields.ArrayField(new fields.StringField(), { initial: [] }),
    // _doc field DROPPED — documentation-only string in template.json, not a real field
  }),
  // benefits/drawbacks: arrays of {text}
  benefits: new fields.ArrayField(
    new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
    { initial: [] },
  ),
  drawbacks: new fields.ArrayField(
    new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
    { initial: [] },
  ),
  // addOns: array of {name, description, requiredSkillPercent, xpDiceCost, ppCost?, effect?}
  addOns: new fields.ArrayField(
    new fields.SchemaField({
      name:                  new fields.StringField({ initial: '' }),
      description:           new fields.StringField({ initial: '' }),
      requiredSkillPercent:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      xpDiceCost:            new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      ppCost:                new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      effect:                new fields.StringField({ initial: '' }),
    }),
    { initial: [] },
  ),
  // _addOnSchema_doc DROPPED — documentation only.
}),
```

### gear.mjs (7 own + base + 6 elysium = 15 slots; includes 3 tome fields NOT in template)

```js
...makeItemBase(),
quantity:    new fields.NumberField({ integer: true, initial: 1, min: 0 }),
enc:         new fields.NumberField({ initial: 0 }),  // non-integer per template (could be fractional ENC)
price:       new fields.StringField({ initial: '' }),
cost:        new fields.NumberField({ initial: 0 }),  // non-integer per template
equipStatus: new fields.StringField({ initial: 'stowed' }),  // free, per side-finding #8
pSCurr:      new fields.NumberField({ integer: true, initial: 0 }),
pSMax:       new fields.NumberField({ integer: true, initial: 0 }),
elysium: new fields.SchemaField({
  // Template fields:
  isContainer:  new fields.BooleanField({ initial: false }),
  containedIn:  new fields.StringField({ initial: '' }),
  capacity:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
  // Compendium-only fields (tome metadata):
  arcaneRole:   new fields.StringField({ initial: '' }),
  isTome:       new fields.BooleanField({ initial: false }),
  linkedSkill:  new fields.StringField({ initial: '' }),
}),
```

### culture.mjs (4 own + base + 1 deep elysium = 6 top-level + ancestry deep nesting)

```js
...makeItemBase(),
// Top-level culture fields — used during character creation when culture is dropped on actor.
// Compendium cultures don't populate these (they default-initialize); the character-creation
// flow uses them when constructing a character.
skills: new fields.ArrayField(
  new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
    bonus:     new fields.NumberField({ integer: true, initial: 0 }),
  }),
  { initial: [] },
),
groups: new fields.ArrayField(
  new fields.SchemaField({
    options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
    skills: new fields.ArrayField(
      new fields.SchemaField({
        uuid:      new fields.StringField({ initial: '' }),
        elysiumid: new fields.StringField({ initial: '' }),
        bonus:     new fields.NumberField({ integer: true, initial: 0 }),
      }),
      { initial: [] },
    ),
  }),
  { initial: [] },
),
move: new fields.NumberField({ integer: true, initial: 0 }),
// stats: 7-stat block, each {formula, mod}. Fixed key set (str/con/int/siz/pow/dex/cha).
stats: new fields.SchemaField({
  str: new fields.SchemaField({ formula: new fields.StringField({ initial: '3d6' }),    mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  con: new fields.SchemaField({ formula: new fields.StringField({ initial: '3d6' }),    mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  int: new fields.SchemaField({ formula: new fields.StringField({ initial: '2d6+6' }),  mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  siz: new fields.SchemaField({ formula: new fields.StringField({ initial: '2d6+6' }),  mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  pow: new fields.SchemaField({ formula: new fields.StringField({ initial: '3d6' }),    mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  dex: new fields.SchemaField({ formula: new fields.StringField({ initial: '3d6' }),    mod: new fields.NumberField({ integer: true, initial: 0 }) }),
  cha: new fields.SchemaField({ formula: new fields.StringField({ initial: '3d6' }),    mod: new fields.NumberField({ integer: true, initial: 0 }) }),
}),
elysium: new fields.SchemaField({
  ancestry: new fields.SchemaField({
    isElysiumAncestry: new fields.BooleanField({ initial: false }),
    baseMove:          new fields.NumberField({ integer: true, initial: 30, min: 0 }),
    flyMove:           new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    swimMove:          new fields.NumberField({ integer: true, initial: 0, min: 0 }),
    buildPoints:       new fields.NumberField({ integer: true, initial: 0 }),
    skillPoints:       new fields.NumberField({ integer: true, initial: 0 }),
    statMods: new fields.ArrayField(
      new fields.SchemaField({
        stat:  new fields.StringField({ initial: '' }),  // free — content uses both 'INT' and 'int' case
        value: new fields.NumberField({ integer: true, initial: 0 }),
      }),
      { initial: [] },
    ),
    traits: new fields.ArrayField(
      new fields.SchemaField({
        uuid: new fields.StringField({ initial: '' }),
        name: new fields.StringField({ initial: '' }),
      }),
      { initial: [] },
    ),
    naturalArmor: new fields.SchemaField({
      ap:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      locations: new fields.StringField({ initial: 'all' }),
    }),
    // Permissive shapes for fields with no compendium ground truth (P12 to tighten)
    naturalWeapons: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
    resistances:    new fields.ObjectField({ initial: {} }),
    languages:      new fields.ArrayField(new fields.StringField(), { initial: [] }),
    subraces:       new fields.ArrayField(new fields.StringField(), { initial: [] }),
    parentId:       new fields.StringField({ initial: '' }),
    isSubrace:      new fields.BooleanField({ initial: false }),
    hitLocationSet: new fields.StringField({ initial: 'humanoid' }),
  }),
}),
```

## init.mjs registrations

8 imports, 8 `CONFIG.Item.dataModels[type]` assignments.

## Smoke test plan

Same shape as P6.1:
1. Boot — all 8 DataModels registered with expected field counts.
2. Create — `Item.create({type, name})` for each of 8 types, instanceof checks.
3. Schema defaults — sample default values per type.
4. Persistence roundtrip — one write per field-class type, distributed:
   - NumberField: `super.level = 5`
   - StringField (free): `allegiance.allegTitle = 'Lord'`
   - BooleanField: `mutation.minorOnly = true`
   - HTMLField: `ability.effectText = '<p>Effect</p>'`
   - Nested SchemaField: `culture.elysium.ancestry.baseMove = 40`
   - Deep-nested SchemaField: `ability.elysium.activation.actionCost = 2`
   - ArrayField (flat strings): `ability.elysium.activation.endConditions = ['fatigued']`
   - ArrayField (objects): `ability.elysium.benefits = [{text: 'Bonus +1'}]`
   - ArrayField of nested SchemaFields: `culture.elysium.ancestry.statMods = [{stat: 'INT', value: 1}]`
5. **Compendium drop test** — critical for P6.2: drop one of each compendium-having type
   (ability, gear, mutation, culture, allegiance, super) onto a character via
   `createEmbeddedDocuments`, confirm no validation errors. This is the test that
   validates the audit-driven schema decisions (especially `ability.elysium.arcaneParent`,
   `gear.elysium.{arcaneRole, isTome, linkedSkill}`).
6. Cleanup.

## Side findings logged for P12

- #8: equipStatus legacy-value handling (above)
- #9: culture.elysium.ancestry.statMods[].stat case mismatch (above)
- #10: culture.elysium.ancestry.{naturalWeapons, resistances, subraces} permissive shapes
