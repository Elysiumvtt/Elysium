# P7 Stylesheet consolidation — prep audit

Captured 2026-05-14, between P6 close (alpha.12) and P7 start.

## Decisions locked at audit time (user-confirmed)

1. **Framing B** — set-up-the-foundation-and-defer. Create the new file
   structure cleanly. Migrate stable foundation rules. Leave per-component
   rules in `css/legacy.css`, `css/npc.css`, and `styles/elysium.css`
   where they currently work. **The "delete legacy CSS" milestone moves
   to P12**, after P8–P11 have replaced the markup those rules style.

2. **Commit to v1.0.0 visuals from P7 forward.** Dark theme as the
   primary identity; v1.0.0 dark/bone/crimson palette applies wherever
   semantic tokens get retargeted. Half-measures across P7–P11 would
   produce a half-BRP-half-Elysium look for multiple phases; we accept
   the larger visual jump in P7 as the price of one clean cutover.

3. **Conservative dead-rule audit in P7.** Don't cross-reference each
   rule against current markup. Kill only rules with obviously-dead
   targets (e.g. selectors targeting class names that don't exist
   anywhere in `templates/`). Aggressive pruning happens naturally in
   P8–P11 as each surface gets rebuilt.

4. **Legacy variables stay in `css/legacy.css`.** They're part of what
   that file is for; moving them to `elysium-tokens.css` is busywork
   that gets undone when legacy.css is deleted in P12.

5. **Load order: new files first, legacy files last.** Preserves
   current specificity so any rule that *does* override a foundation
   rule keeps working. Order:
   ```
   tokens → reset → base → components → sheets → chat → legacy → npc → elysium-old
   ```

## Current state

### File inventory

| File | Lines | Blocks | --ely-legacy refs | Hex literals | Role |
|---|---:|---:|---:|---:|---|
| `styles/elysium-tokens.css` | 497 | 0 rules + ~85 token defs | 0 | many (token values) | P1 token system; foundation |
| `css/legacy.css` | 1719 | 234 | 80 | 18 | BRP-era foundation; theme `:root` blocks; `@font-face`; `@import` Google Fonts |
| `css/npc.css` | 298 | 40 | 19 | few | NPC sheet styles; uses some `--ely-legacy-*` vars (partial migration already) |
| `styles/elysium.css` | 3120 | 471 | 11 | 242 | Per-feature Elysium overrides; mostly hardcoded |
| **Total** | **5634** | **745** | **110** | | |

### Semantic token surface

P1 defined ~85 semantic tokens in `elysium-tokens.css`. **Zero active
consumers** of `--ely-*` (semantic) vars exist in code today. P7 changes
this number from 0 to >0; P8–P11 ratchet it further as components are
rebuilt.

### Theme structure

`legacy.css` defines three `:root` blocks (lines ~18, ~50, ~75):
1. Default — light-leaning baseline
2. `body.theme-light .application.elysium` — light theme variant
3. `body.theme-dark .application.elysium` — dark theme variant

ROADMAP open question (P12): "Light theme — retire entirely, or keep
as a token-overlay theme?" Per project pillars, **dark IS the v1.0.0
vision**. P7 doesn't *delete* the light theme block (per discipline #3
conservative pruning), but **stops developing for it** — new
component styles use semantic tokens that resolve to dark-theme
values.

### Bridge variables in `legacy.css`

`legacy.css` defines both `--actor-*` (BRP-era, internal use only) and
`--ely-legacy-*` (BRP-era, exposed for stylesheet consumers). The
`--ely-legacy-*` set is what consumers reference. P7 introduces a
**bridge layer** in `elysium-tokens.css` where each `--ely-legacy-*`
gets a semantic equivalent declared. This means a consumer can
incrementally migrate from `var(--ely-legacy-X)` → `var(--ely-Y)`
without value drift.

For dark theme (the default v1.0.0 target), bridge mappings are:
| Legacy var | Semantic var | Note |
|---|---|---|
| `--ely-legacy-background` (parchment image) | (none — drop in v1.0.0) | Dark theme replaces parchment with solid surface |
| `--ely-legacy-border-color` (cornsilk in dark, dark-red in light) | `--ely-border-decorative` | Bone in v1.0.0 (#c5aa8f) |
| `--ely-legacy-button-colour` | (use `--ely-surface-raised` for bg + `--ely-text-body` for fg) | |
| `--ely-legacy-colour-primary` (cornsilk in dark, black in light) | `--ely-text-body` | Off-white in v1.0.0 |
| `--ely-legacy-colour-secondary` (red-ish in both themes) | `--ely-accent-action` | Crimson in v1.0.0 |
| `--ely-legacy-colour-tertiary` (green in both themes) | `--ely-accent-success` | |
| `--ely-legacy-icon-primary` (red) | `--ely-accent-action` | |
| `--ely-legacy-icon-secondary` (grey) | `--ely-text-muted` | |
| `--ely-legacy-labelback` (#a2c2bb teal) | (use `--ely-surface-card` or `--ely-surface-raised`) | Legacy hardcoded background not preserved |
| `--ely-legacy-skill-culture` | `--ely-skill-cultural` | |
| `--ely-legacy-skill-main` | `--ely-skill-general` | |
| `--ely-legacy-skill-prof` | `--ely-skill-professional` | |
| `--ely-legacy-skill-psp` | `--ely-skill-magic` | |
| `--ely-legacy-skill-xp` | `--ely-skill-xp` | |
| `--ely-legacy-tab-shadow` (teal-ish) | (none — drop in v1.0.0) | |
| `--ely-legacy-tableback` | (use `--ely-surface-sunken` for striped rows) | |
| `--ely-legacy-tablerow` | (use `--ely-surface-raised`) | |
| `--ely-legacy-title-colour` | `--ely-text-decorative` | Bone in v1.0.0 (color shift from red→bone) |

**Mapping note**: many of these go from dark/red palette to bone/dark
palette. That's the deliberate v1.0.0 visual identity shift. Per
decision #2, P7 lands these intentional shifts; the harness records
them as expected drift, not regressions.

## P7 scope (Framing B)

### What P7 does

1. **Create 5 new files** as empty stubs with header comments and the
   load-order plan:
   - `styles/elysium-reset.css`
   - `styles/elysium-base.css`
   - `styles/elysium-components.css`
   - `styles/elysium-sheets.css`
   - `styles/elysium-chat.css`

2. **Wire them into `system.json` `styles` array** in the documented
   load order — new files first, legacy last:
   ```
   styles/elysium-tokens.css
   styles/elysium-reset.css
   styles/elysium-base.css
   styles/elysium-components.css
   styles/elysium-sheets.css
   styles/elysium-chat.css
   css/legacy.css
   css/npc.css
   styles/elysium.css
   ```

3. **Migrate `@font-face` + `@import` from `legacy.css` top to `elysium-reset.css`.**
   Reset is the right home for font loading because resets run early
   and other files depend on fonts being available. Update the local
   `url()` paths to resolve correctly from the new file location.
   Delete the migrated declarations from `legacy.css`.

4. **Populate `elysium-base.css` with typography + spacing primitives**
   driven by semantic tokens. These are the rules that previously
   lived in `legacy.css`'s global section (lines ~106-250 roughly):
   body/html font sizing, default link colors, headings. Each new rule
   uses `var(--ely-text-body)`, `var(--ely-font-family-body)`, etc. —
   the semantic tokens, not legacy. The values will resolve to v1.0.0
   dark/bone aesthetic on a default page (no theme class).

5. **Populate `elysium-components.css` with the SHARED component
   primitives**: buttons, focus styles, scrollbar styling, the
   foundation form-control look. Anything that *every* sheet uses
   without per-sheet customization. Rule of thumb: if it doesn't appear
   in markup outside the legacy sheet today, it's NOT a base-level
   primitive — leave it in legacy.css for now.

6. **Leave `elysium-sheets.css` and `elysium-chat.css` as stubs**
   in P7. They get content in P8 (sheets) and P11 (chat). P7's job is
   to create the file slots so the load-order machinery is in place.

7. **Visual-regression sweep** — re-capture baselines under the new
   foundation. Baselines from P5 (alpha2-character-empty-dark,
   alpha2-npc-empty-dark) will diff visibly because the underlying
   color tokens have shifted. Diffs are EXPECTED. New baselines named
   `alpha13-*` lock the v1.0.0 visual identity.

### What P7 does NOT do

- Does **not** delete `legacy.css`, `npc.css`, or `elysium.css`. All
  three remain in `system.json` `styles` and continue to apply their
  per-component rules. P12 deletes them after P8–P11 have rendered
  their content obsolete.

- Does **not** retarget consumers inside `legacy.css` / `npc.css` /
  `elysium.css` from `--ely-legacy-*` to `--ely-*`. That's risky
  busywork — those files keep their `--ely-legacy-*` consumption
  pattern, and `legacy.css` keeps defining the legacy vars in its
  `:root` blocks. The new files use the new semantic tokens; the old
  files use the old legacy vars; both coexist.

- Does **not** style the new sheet shell, tab strip, or item sheets.
  Those land in P8/P9/P10. P7 only prepares the foundation.

- Does **not** rebuild chat cards or dialogs. P11 owns chat surface.

- Does **not** revisit any of the 24 cumulative side findings from
  P5–P6. Those are closed.

### What P12 will do (preview, for context)

When P8–P11 replace the markup styled by `legacy.css`/`npc.css`/`elysium.css`,
those CSS files become deadweight. P12 picks them up:
- Audit each remaining rule against the post-P11 markup
- Delete rules whose targets don't exist in active templates
- Migrate any survivor rules into the appropriate new file
- Delete the three legacy files
- Final visual sweep

## Migration approach within each new file

`elysium-reset.css`:
- `@import` Google Fonts (from legacy.css:1)
- Two `@font-face` blocks (from legacy.css:3-16)
- Universal box-sizing reset
- Body baseline (font-family, font-size, line-height, color)
- All values pull from semantic tokens

`elysium-base.css`:
- Heading hierarchy (h1–h6 via `--ely-font-size-N` scale)
- Default link styling (`--ely-text-link*`)
- Spacing utility classes if any (TBD by need)
- Common typography conventions

`elysium-components.css`:
- Button baseline (.button, button) using `--ely-accent-action` family
- Focus ring (`--ely-border-focus`)
- Scrollbar styling (browsers permitting)
- Generic form-control look — text inputs, selects, checkboxes
- Conservative: only add what's known-needed for the shell P8 will
  build. Don't speculate.

`elysium-sheets.css`:
- **Empty in P7**. Header comment notes "populated in P8 onward".

`elysium-chat.css`:
- **Empty in P7**. Header comment notes "populated in P11".

## Risk assessment

ROADMAP rates P7 as "High risk — 4839 lines to audit." Under Framing B,
the actual P7 risk drops to **moderate**:

- We're not auditing 4839 lines. We're moving ~150 foundation lines
  from `legacy.css` to new files. Everything else stays put.
- The visual jump is real (intentional, per decision #2) — the dark
  theme + token-driven values will replace the BRP-era look anywhere
  the new foundation rules apply. The harness will catch unintended
  drift.
- Adverse interaction: an `elysium-base.css` rule could override a
  `legacy.css` rule via load order. Mitigation: in `elysium-base.css`,
  scope rules tightly (use `body`, `html`, `.application.elysium` as
  appropriate). Don't use unscoped element selectors that would
  cascade into sheet content. Test in live world after every meaningful
  edit.

## Acceptance criteria for P7

- Five new CSS files exist with the documented header comments and load
  ordering
- `system.json` `styles` array reflects the new ordering
- `legacy.css` no longer contains `@font-face` or `@import` declarations
  (moved to `elysium-reset.css`)
- All 25 type sheets still render (sweep against test world)
- Visual-regression baselines captured for at minimum: empty character
  sheet (dark), empty NPC sheet (dark), and one representative item
  sheet. Diffs from alpha.2 baselines documented as intentional
  v1.0.0-identity drift.
- Zero console warnings about missing CSS files or 404s on font assets
- No new side findings opened for in-scope work

## Version plan

P7 ships as `1.0.0-alpha.13`. Compendium module unchanged at v1.0.0-alpha.2
(P7 has no compendium impact).

## Estimated touch surface

| Bucket | Files | Notes |
|---|---|---|
| New stylesheet files | 5 | reset, base, components, sheets (stub), chat (stub) |
| Edited stylesheet files | 1 | `legacy.css` — strip top-of-file font loading |
| System manifest | 1 | `system.json` styles array |
| Baselines | 3 | `alpha13-character-empty-dark.snapshot.json`, `alpha13-npc-empty-dark.snapshot.json`, `alpha13-weapon-detail-dark.snapshot.json` |
| Docs | 1 | This audit doc; CHANGELOG entry; ROADMAP P7 row + dated entry |

Net: ~10 file touches. Substantially smaller than a literal-reading P7.
