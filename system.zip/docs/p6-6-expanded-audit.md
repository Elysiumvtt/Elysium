# P6.6 Expanded Audit — Schema/Code/Compendium Findings Cleanup

Companion to `p6-6-handoff.md`. Captured 2026-05-13 during the P6.6 live verification
session, after the original 4-work-item smoke surfaced 6 new side findings (#19–#24)
alongside the 18 already logged. User decision: **fix all remaining open findings**
at the core, no band-aids, before closing P6.

This doc enumerates every fix, the files touched, design decisions, migration plans
where required, and the smoke surface for each. It is the prep-audit equivalent
of `p6-prep-audit.md` for the expanded P6.6 scope.

---

## Scope summary

Original P6.6 scope (alpha.10, already shipped to source): template.json Item
block deletion + system.json htmlFields cleanup + acceptance sweep. Five side
findings auto-resolved by those edits (#6, #12, #15, #16, #17). #3 and #7 were
resolved by earlier P6 phases.

Expanded scope (alpha.11): fix the 17 remaining open findings.

**Discipline note**: this expansion violates the "side findings documented but
not fixed during their scope phase" rule that's served the project across five
prior sub-phases. The user has made this call explicitly and is aware of the
tradeoff: alpha.11's smoke results no longer cleanly attribute to a single
scope of work. To compensate, this audit doc enumerates each fix individually
and the final smoke specifies which surfaces each fix should not have broken.

**Outcome of this audit pass**: one finding (#21) couldn't be reproduced in
isolation — it was a likely side-effect of #20's render failures contaminating
subsequent personality renders in the bulk sweep. With #20 fixed, #21 should
disappear. Tagged "deferred pending re-verification post-#20-fix" below.

**Scope simplification (user decision)**: alpha.11 ships against a fresh world
with no pre-existing game data. The compendium content we control directly.
Therefore **no migration shims are written**. Findings that previously
required migration (#2, #11, #13) collapse to pure source/compendium edits.
No `module/elysium/migrations/` additions in this ship. No world-load
migration hooks. The standard migration-flag pattern remains in place for
future P-phases.

---

## Findings — final fix plan

### #1 — patron.standing / statNaturalMax flags vs system write mismatch

**AUDIT CORRECTION (caught during execution)**: the audit doc stated that
`statNaturalMax` was undeclared on CharacterDataModel and the fix should
move writers to `flags.elysium.*`. **That was wrong**: `statNaturalMax` IS
declared on CharacterDataModel as a TypedObjectField (alpha.2 P5.2 added
it). The actual root cause was a **read/write split**: writers write
`system.elysium.statNaturalMax` (declared, succeeds), but readers in
`creation.mjs:117/171` and `ancestry-drop.mjs:352` were reading from
`flags.elysium.statNaturalMax` (different path, always empty).

`patron.standing` is the genuinely-undeclared half of #1: the writer at
`magic.mjs:217` wrote `system.elysium.patron.standing` (undeclared →
silent drop) while the reader at `magic.mjs:204` reads
`flags.elysium.patron.standing`.

**Actual fix at the core**: for `statNaturalMax`, the data is structured
persistent state — it belongs in `system.elysium.*` (where it's already
declared). Fix the readers, not the writers: update the three readers to
read from `system.elysium.statNaturalMax`. For `patron.standing`, no
declaration exists and the data is ephemeral (per-session patron favor
tracking); move the writer to match the existing reader at
`flags.elysium.patron.standing`.

**Files actually touched**:
- `module/elysium/magic/magic.mjs:217` — writer `system.elysium.patron.standing`
  → `flags.elysium.patron.standing` ✓
- `module/elysium/creation/creation.mjs:117` — reader `flags.elysium.statNaturalMax`
  → `system.elysium.statNaturalMax` ✓
- `module/elysium/creation/creation.mjs:171` — same ✓
- `module/elysium/actor/ancestry-drop.mjs:352` — same ✓
- `module/data/actor/character.mjs:102-109` — updated stale comment that
  said "deferred, reads/writes split" — now resolved ✓

**Smoke**: drop a culture with statMods → verify `actor.system.elysium.statNaturalMax`
populates; call `setPatronStanding(actor, 'favoured')` → verify
`actor.flags.elysium.patron.standing` updates.

---

### #2 — Dropped character-elysium fields (patron, essences, schoolMastery, companion)

**Status**: closed by user decision. Fresh world, no migration concerns.
The DataModel correctly doesn't declare these fields (zero readers); any
hypothetical world with stored values for them would silently drop those
values on load, which is the correct behavior for vestigial data.

**Status in alpha.11**: no action needed. Closes finding.

---

### #4 — capture.mjs uses CHARACTER_SHEET_MARKERS for any Actor type

**Status**: fixed.

**Files actually touched**:
- `test/visual-regression/capture.mjs` — added `NPC_SHEET_MARKERS` (10 markers
  targeting `npcv2`-template classes); dispatch in `captureSheet` now picks
  by `subtype === 'npc'`.

**Smoke**: capture an NPC sheet; expect markersMatched ≥ 5/10 (vs 1/10 before).

---

### #5 — Claude-in-Chrome bridge wedge

**Status**: documented; no source change. The handoff and visual-regression
README already document the workaround pattern. Not a code defect; closing.

---

### #8 — equipStatus legacy values + free StringField

**Status**: fixed at the schema layer.

**Files actually touched**:
- `module/data/item/_shared.mjs` — new exported helper `migrateLegacyEquipStatus(source)`
  that mutates `source.equipStatus` 'carried'/'worn' → 'stowed'
- `module/data/item/armor.mjs` — equipStatus choices lock `['stowed', 'equipped']`;
  imports the helper; defines `static migrateData(source) { return migrateLegacyEquipStatus(source) }`
- `module/data/item/weapon.mjs` — same pattern
- `module/data/item/gear.mjs` — same pattern
- `module/elysium/hooks/item.mjs` — removed the post-construct normalizer block
  (now superseded by schema-layer migrateData hook); replaced with explanatory
  comment

**Smoke**: drop a compendium armor with legacy `equipStatus: 'carried'` from
the regenerated compendium — normalized to 'stowed' pre-validation. Direct
write of `'garbage'` → `DataModelValidationError` (choices lock active).

---

### #9 — culture.statMods.stat case mismatch

**Status**: fixed at the schema layer + compendium normalized.

**Files actually touched**:
- `module/data/item/culture.mjs` — `statMods.stat` is now a StringField with
  `choices: ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha']` and
  `initial: 'str'`. Lowercase canonical form enforced by choices lock.
- Compendium `ancestries.db` — 31 stat values normalized to lowercase across
  20 ancestries (script: `compendium-normalize-finding9.py`)

**Smoke**: drop a culture with statMods (e.g., Ghostwise Halfling); verify
stored values are lowercase; verify stat-mod AEs apply correctly.

---

### #10 — Culture permissive fields (naturalWeapons, resistances, subraces)

**Status**: AUDIT CONFIRMED, DEFERRED (per user decision: ok to defer if
no ground-truth exists).

**Audit result**: re-inspected compendium content for all 20 ancestries.
All have empty values for all three fields (`naturalWeapons: []`,
`resistances: {}`, `subraces: []`). Tightening shapes against zero
ground-truth content would be guessing. Permissive shapes stay until
real content exists.

**Status in alpha.11**: no action. Finding remains open; revisit when
compendium content populates these fields.

---

### #11 — favouredEnemy → nemesis rename

**Status**: fixed. No migration needed (fresh world per user decision).

**Files actually touched**:
- `module/data/item/super.mjs` — schema renamed: outer `favouredEnemy`
  SchemaField → `nemesis`, inner `isfavouredEnemy` BooleanField →
  `isNemesis`. Doc header rewritten to describe the rename rationale.
- `module/elysium/config/config.mjs` — `favouredEnemyMaxTypes: 3` →
  `nemesisMaxTypes: 3`
- Compendium `superpowers.db` — 36 key renames across 18 super docs
  (18 × outer + 18 × inner). Script: `compendium-rename-finding11.py`

**Smoke**: drop a Nemesis (compendium superpower) onto a character; verify
stored shape is `system.elysium.nemesis.{isNemesis, targets}`.

---

### #13 — creatureType name collision (actor vs hit-location)

**Status**: fixed by renaming the hit-location-side field to `bodyPlan`.
No migration needed (fresh world).

**Files actually touched**:
- `module/data/item/hit-location.mjs` — `creatureType` StringField →
  `bodyPlan` StringField; doc header rewritten to explain the rename
- `module/item/sheets/hit-location.mjs` — handler reads/writes
  `system.bodyPlan` (renamed from `system.creatureType`)
- `templates/item/hit-location.detail.hbs` — both edit and readonly bindings
  updated (lines 8, 58)
- Compendium `hit-locations.db` — 23 key renames (one per hit-location doc).
  Script: `compendium-rename-finding13.py`

**Note**: actor-side `creatureType` (declared on Character and NPC
DataModels) is unchanged. It lives at `system.elysium.creatureType`,
a different path than the renamed hit-location field.

**Smoke**: open a hit-location sheet (e.g., a fresh "Right Leg" from
compendium); verify the field saves correctly under the new name.

---

### #14 — Compendium-only zero-reader fields

**Status**: fixed — fields dropped from both schemas and compendium content.

**Files actually touched**:
- `module/data/item/armor.mjs` — dropped 4 ballistic fields
  (av2, avr2, armBal, armVar)
- `module/data/item/hit-location.mjs` — dropped 2 ballistic fields
  (bap, bapRnd)
- `module/data/item/arcane.mjs` — dropped 6 vestigial fields
  (cost, pcost, magicChosen, mpCurr, mpMax, spellCat)
- `module/data/item/sorcery.mjs` — dropped 1 vestigial field (subType)
- Compendium content cleaned (script: `compendium-cleanup-finding14.py`):
  - armor.db: 104 field removals (26 docs × 4 fields)
  - hit-locations.db: 46 (23 × 2)
  - spells-arcane.db: 252 (42 × 6)
  - abilities-sorcery.db: 264 (264 × 1)
  - arcane-knowledge.db: 0 (target fields weren't present; arcane-knowledge
    contains skill-typed docs, not arcane-typed)
- Total: 666 field removals across 379 compendium docs

**Smoke**: drop one of each affected compendium type onto a fresh character;
verify zero validation errors. Open each sheet, verify no template
references to removed fields are broken.

---

### #18 — CharacterDataModel.elysium.ancestryMove undeclared but written

**Status**: fixed by declaring the field on CharacterDataModel.

**Audit refinement during execution**: the audit's plan was to move the
writer to `flags.elysium.ancestryMove`. After inspection, declaring on
the DataModel was the better core fix: the data is persistent structured
state (the ancestry's contribution to movement, cached on the actor)
and that's exactly what `system.elysium.*` is for. The `flags.elysium.*`
home is for ephemeral runtime data.

**Files actually touched**:
- `module/data/actor/character.mjs` — added `ancestryMove` SchemaField
  with `{baseMove, flyMove, swimMove}` integers in the elysium block.
  Writer at `ancestry-drop.mjs:367` unchanged; write now persists.

**Smoke**: drop a culture, verify `actor.system.elysium.ancestryMove`
populates with the correct values.

---

### #19 — Hit-location world-scope creation TypeError

**Status**: fixed.

**Files actually touched**:
- `module/elysium/hooks/item.mjs:111` — added optional chain on
  `item.parent?.sheet?.rendered`. World-scope hit-location creation no
  longer throws.

**Smoke**: `Item.create({type: 'hit-location', name: 'X'})` at world scope;
no error.

---

### #20 — Unregistered `<type>Label` settings

**Status**: fixed via option (b) — removed the reads.

**Files actually touched**:
- `module/item/sheets/mutation.mjs:31-33` — removed the unregistered
  setting read block
- `module/item/sheets/sorcery.mjs:33-35` — same
- `module/item/sheets/super.mjs:38-40` — same

`itemType` now falls back to the base `ElysiumItemSheetV2._prepareContext`
which already sets it via i18n.

**Smoke**: render mutation, sorcery, super sheets — clean render with
i18n-driven label, no setting errors.

---

### #21 — Personality sheet render error

**Status**: AUDIT CONFIRMED NON-REPRODUCIBLE. Five back-to-back isolated
renders of an empty personality item completed without error. Expected
to dissolve completely once #20 is fixed (the original failure in the
bulk render sweep was almost certainly contamination from rendering
super/sorcery/mutation immediately before personality).

**Status in alpha.11**: no action. Re-verify post-#20-fix.

---

### #22 — Dynamic import path bug

**Status**: fixed.

**Files actually touched**:
- `module/elysium/sheets/item/item-modifiers.mjs:106` — `'../active-effects/...'`
  → `'../../active-effects/...'`

**Smoke**: drop armor/weapon/gear (which triggers `syncEquipState` →
`wireItemModifiers` import); no "Failed to fetch dynamically imported
module" errors.

---

### #23 — fromBRPIDBest → fromElysiumIDBest

**Status**: fixed. Two call sites renamed.

**Files actually touched**:
- `module/item/sheets/weapon.mjs:63,69` — both calls renamed

**Smoke**: open a weapon sheet against a real compendium weapon (e.g.,
Longsword with `skill1: 'i.skill.short-blades'`); expect clean render
with `skill1Name` populated.

---

### #24 — Ancestry-drop cascade prep errors

**Status**: fixed at the prep layer (option B from the design decisions).

**Files actually touched**:
- `module/actor/actor.mjs` — added `if (!itm.system) continue` guard at
  the top of every `for (let itm of actorData.items)` loop in
  `_prepDerivedStats`. Four loops guarded.

**Smoke**: drop a culture onto a character with pre-existing items (which
triggers `_applyHitLocationSet` delete-then-recreate cascade); verify no
"Failed data preparation" errors during the cascade. End-state of actor
remains correct (items applied, languages/stat-mods/move all written).

---

## Execution status (final)

All 17 in-scope findings handled. Of the 24 cumulative side findings:

- **Resolved by alpha.10 P6.6 baseline** (template/system.json edits):
  #3, #6, #7, #12, #15, #16, #17 (7 findings, auto-fixed by core P6.6 work)
- **Fixed in alpha.11 expanded P6.6**:
  #1, #4, #8, #9, #11, #13, #14, #18, #19, #20, #22, #23, #24 (13 findings)
- **Closed without source change**:
  #2 (fresh world — no migration concerns),
  #5 (environmental — documented),
  #10 (deferred — no ground-truth content exists for the shapes)
- **Re-verify after smoke**:
  #21 (expected to dissolve with #20 fix; non-reproducible in isolation)

## Actual touch surface

| Bucket | files touched | notes |
|---|---|---|
| .mjs source edits | 17 | actor/character DataModels, 7 item DataModels, 4 item sheets, 3 elysium-side modules, capture.mjs |
| .hbs template edits | 1 | hit-location.detail.hbs |
| .db compendium edits | 5 | armor, hit-locations, spells-arcane, abilities-sorcery, ancestries, superpowers |
| Helper scripts | 3 | compendium-cleanup-finding14.py, -rename-finding11.py, -rename-finding13.py, -normalize-finding9.py (4 scripts, in /home/claude/work/) |
| New module/ files | 0 | per user decision (no migrations) |

**Net field surface change**: 666 compendium-content field removals + 36 + 23
key renames + 31 case normalizations = 756 individual data mutations across
5 .db files.

## Versioning

Single ship: `1.0.0-alpha.11`. Per user decision (b3 in the message thread),
all work folds under the P6.6 sub-phase identity despite the expanded scope.
The original P6.6 minimal-cleanup work (template.json Item block deletion,
system.json gmNotes→gmDescription conversion) shipped to source as alpha.10
intermediate; alpha.11 supersedes that with the expanded work folded in.

## Discipline preserved

The "fix at the core, no band-aids" principle has been honored for every
finding above. Specifically:
- **#1**: declared-vs-flag analysis corrected the audit's plan during
  execution; readers were moved to match the declared field, not writers
  shoved into flags. Patron.standing kept in flags because its data is
  ephemeral runtime, not persistent state.
- **#8**: pre-validation normalizer via DataModel `static migrateData` —
  the V14-correct hook for source-data shape transformation. Schema-layer,
  not hook-layer band-aid.
- **#9**: schema-layer choices lock eliminates case ambiguity at the source.
- **#11, #13**: full rename across schema + sheet + template + compendium.
  No backwards-compat preservation.
- **#14**: compendium regeneration AND schema cleanup, not just one.
- **#18**: declared on DataModel matching the persistent-state principle,
  not punted to flags.
- **#19**: defensive optional chain at the actual fault site.
- **#20**: removes broken machinery rather than patching around it.
- **#22**: corrects the typo at the source.
- **#23**: completes the historic rename codemod.
- **#24**: hardens prep loop generically rather than refactoring ancestry-drop.
