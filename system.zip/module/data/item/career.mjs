/**
 * CareerDataModel — schema for items of type 'career'.
 *
 * Per P6.5 spec (docs/p6-5-handoff.md). Stored-schema-only.
 * 8 compendium items in careers.db.
 *
 * Schema decisions:
 *   - Template skills/groups use `{uuid, elysiumid}` shape (same as personality
 *     from P6.1). NOT factored into _shared.mjs because personality, career,
 *     and culture each use slightly different shapes (culture adds `bonus`,
 *     career+personality don't) — per project decision to avoid premature
 *     abstraction.
 *   - FOUR compendium-only top-level fields declared (side-finding #14 family):
 *     `commonSkills`, `careerSkills`, `culture`, `cultureBonus`. The first
 *     two are ARRAYS OF STRING SKILL NAMES (not {uuid, elysiumid} — a different
 *     shape despite the field-name overlap with culture item type's similarly-
 *     named fields). The character creator uses these for name-matching against
 *     actual skill items.
 *   - ONE compendium-only elysium field: `themes` — array of strings tagging
 *     the career's available ability-themes (e.g. ['fighter', 'vanguard']).
 *   - `powers` is declared as `ArrayField<ObjectField>` (permissive) — empty in
 *     all 8 compendium careers; shape unknown when populated. P12 to tighten.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

function makeSkillRef () {
  return new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
  })
}

export class CareerDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),

      // Template-declared character-creation fields
      skills: new fields.ArrayField(makeSkillRef(), { initial: [] }),
      groups: new fields.ArrayField(
        new fields.SchemaField({
          options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
          skills:  new fields.ArrayField(makeSkillRef(), { initial: [] }),
        }),
        { initial: [] },
      ),
      powers:    new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      minWealth: new fields.NumberField({ integer: true, initial: 0 }),
      maxWealth: new fields.NumberField({ integer: true, initial: 0 }),

      // Compendium-driven legacy (side-finding #14 family). Arrays of STRING skill
      // names — different shape from `skills`/`groups` above (which use the
      // {uuid, elysiumid} reference shape).
      commonSkills:       new fields.ArrayField(new fields.StringField(), { initial: [] }),
      careerSkills: new fields.ArrayField(new fields.StringField(), { initial: [] }),
      culture:            new fields.StringField({ initial: '' }),
      cultureBonus:       new fields.NumberField({ integer: true, initial: 0 }),

      elysium: new fields.SchemaField({
        isElysiumCareer: new fields.BooleanField({ initial: false }),
        tier:                new fields.StringField({ initial: 'basic' }),
        primaryGroupSize:    new fields.NumberField({ integer: true, initial: 4 }),
        secondaryGroupSize:  new fields.NumberField({ integer: true, initial: 6 }),
        bonusGroupSize:      new fields.NumberField({ integer: true, initial: 2 }),
        packageBPCost:       new fields.NumberField({ integer: true, initial: 0 }),
        packageSkillPoints:  new fields.NumberField({ integer: true, initial: 0 }),
        magicSystemAccess:   new fields.StringField({ initial: '' }),
        startingEquipment:   new fields.ArrayField(new fields.StringField(), { initial: [] }),
        startingAbilities:   new fields.ArrayField(new fields.StringField(), { initial: [] }),
        startingWealth:      new fields.NumberField({ integer: true, initial: 0 }),
        // Compendium-driven (side-finding #14 family)
        themes:              new fields.ArrayField(new fields.StringField(), { initial: [] }),
      }),
    }
  }
}
