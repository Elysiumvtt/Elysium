import { ElysiumUtilities } from '../apps/utilities.mjs'
import { ElysiumActorDetails } from '../apps/actorDetails.mjs'
import ElysiumDialog from '../setup/elysium-dialog.mjs';

export class ElysiumDamage {

  // Add Damage
  static async addDamage(target, actor, token, damage) {
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor)
    let getLoc = false
    let getDam = false
    let locs = {}
    let listLocs = {}
    let locationId = target.dataset.itemId;
    if (!locationId) {
      locs = actor.items.filter(itm => itm.type === 'hit-location')
      if (locs.length === 1) {
        locationId = locs[0]._id
      } else if (locs.length > 1) {
        getLoc = true
        locs.sort(function (a, b) {
          const x = a.system.lowRoll;
          const y = b.system.lowRoll;
          if (x < y) { return 1 };
          if (x > y) { return -1 };
          return 0;
        });
        for (let loc of locs) {
          let label = loc.system.displayName + "(" + loc.system.lowRoll + "-" + loc.system.highRoll + ")"
          if (loc.system.lowRoll === loc.system.highRoll) {
            label = loc.system.displayName + "(" + loc.system.lowRoll + ")"
          }
          listLocs = Object.assign(listLocs, { [loc._id]: label })
        }
      }
    }
    if (damage < 1) {
      getDam = true
    }
    if (getDam || getLoc) {
      const usage = await this.getWoundForm(getDam, getLoc, partic.name, listLocs)
      // Elysium fork: handle cancelled dialog (returns null/undefined)
      if (!usage) return
      if (getDam) { damage = Number(usage.damage) };
      if (getLoc) { locationId = usage.woundLoc};
    }
    if (damage < 1) { return }

    let location = ""
    if (actor) {
      location = actor.items.get(locationId)
    } else {
      location = token.actor.items.get(locationId)
    }

    //Check for damage at 2 or 3 times HPL (where current HP<=0 dealt with in actor.mjs)
    let checkprop = {}
    //If using HPL and this is a an actual hit location (not general)
    if (location.system.locType != 'general') {
      if (damage >= location.system.maxHP * 3 && location.system.locType === 'limb') {
        checkprop = {
          'system.severed': true,
          'system.bleeding': true
        }
      } else if (damage >= location.system.maxHP * 3 && location.system.locType != 'general') {
        checkprop = {
          'system.dead': true,
          'system.incapacitated': true,
          'system.bleeding': true
        }
      } else if (damage >= location.system.maxHP * 2 && location.system.locType === 'limb') {
        checkprop = {
          'system.incapacitated': true,
          'system.bleeding': true
        }
      } else if (damage >= location.system.maxHP * 2 && location.system.locType != 'general') {
        checkprop = {
          'system.unconscious': true,
          'system.bleeding': true
        }
      } else if (damage >= location.system.currHP && location.system.locType != 'limb') {
        checkprop = { 'system.bleeding': true }
      }
      damage = Math.min(damage, location.system.maxHP * 2)
      //Otherwise if not using HPL
    } else if (!true) {
      if (damage >= partic.system.health.mjrwnd) {
        await partic.update({
          'system.majorWnd': true,
          'system.health.daily': 0
        })
      } else if (partic.system.health.daily + damage >= partic.system.health.mjrwnd) {
        await partic.update({
          'system.minorWnd': true,
          'system.health.daily': 0
        })
      }
      if (!partic.system.minorWnd && !partic.system.majorWnd)
        await partic.update({ 'system.health.daily': partic.system.health.daily + damage })
    }
     await location.update(checkprop) 

    //Prepare the new wound data and create it
    const itemData = {
      name: game.i18n.localize('Elysium.wound'),
      type: 'wound',
      system: {
        locId: locationId,
        value: damage
      }
    };
    const newItem = await Item.create(itemData, { parent: partic });
    const key = await game.system.api.elysiumid.guessId(newItem)
    await newItem.update({
      'flags.elysium.elysiumidFlag.id': key,
      'flags.elysium.elysiumidFlag.lang': game.i18n.lang,
      'flags.elysium.elysiumidFlag.priority': 0
    })

    // v0.10.3: sustain disruption auto-prompt was wired here originally,
    // but only fired when damage came through this specific path (the
    // sheet's Add Damage button). v0.10.6 moved it to the rules-module's
    // createItem hook, which catches every wound regardless of how it
    // was applied — direct HP edits, GM macros, ongoing-bleed, etc.
  }

  static async allHeal(el, actor) {
    const confirmation = await ElysiumUtilities.confirmation('allHeal', 'chatMsg');
    if (confirmation) {
      for (let i of actor.items) {
        if (i.type === 'wound') {
          i.delete();
        } else if (i.type === 'hit-location') {
          i.update({
            'system.bleeding': false,
            'system.incapacitated': false,
            'system.injured': false,
            'system.unconscious': false
          })
        }
      }
    }
    return
  }

  //Treat a Wound - First Aid or Magic
  static async treatWound(event, actor, dataitem, type) {
    let itemID = ""
    if (dataitem === "itemId" || dataitem === "woundId") {
      itemID = await ElysiumUtilities.getDataset(event, dataitem)
    }

    let getType = false
    let getWnd = false
    let healTypes = {}
    let wndList = {}

    if (!['medical', 'magic'].includes(type)) {
      getType = true
      healTypes = Object.assign(healTypes, {
        'medical': game.i18n.localize('Elysium.medical'),
        'magical': game.i18n.localize('Elysium.magical')
      })
    }
    if (!itemID) {
      const wounds = actor.items.filter(itm => itm.type === 'wound')
      if (wounds.length === 0) { return }
      if (wounds.length === 1) {
        itemID = wounds[0]._id
      } else {
        getWnd = true
        wounds.sort(function (a, b) {
          const x = a.system.value;
          const y = b.system.value;
          if (x < y) { return 1 };
          if (x > y) { return -1 };
          return 0;
        });
        for (let wound of wounds) {
          const wndLoc = actor.items.get(wound.system.locId)
          let label = ""
          if (wndLoc) {
            label = wndLoc.system.displayName + "(" + wound.system.value + ")"
          } else {
            label = game.i18n.localize('Elysium.general') + "(" + wound.system.value + ")"
          }
          if (wound.system.treated) {
            label = label + " " + game.i18n.localize('Elysium.treated')
          }
          wndList = Object.assign(wndList, { [wound._id]: label })
        }
      }

    }
    let healing = 0
    const usage = await ElysiumDamage.healingAmount(game.i18n.localize('Elysium.treatWound'), getType, getWnd, wndList, healTypes)
    if (usage) {
      healing = Number(usage.treatWound);
      if (getType) { type = usage.healType };
      if (getWnd) { itemID = usage.woundId };
    } else if (!usage) return

    const item = actor.items.get(itemID);
    const hitLoc = actor.items.get(item.system.locId)
    if (item.system.treated && type === 'medical') {
      ui.notifications.warn(game.i18n.localize('Elysium.woundTreated'));
      return;
    }

    //If amout of healing is zero then simply ignore and stop
    if (healing === 0) { return }

    //If amount of healing >- wound then simply delete the wound
    if (healing >= item.system.value) {
      item.delete();
      actor.render(true)
      return
    }

    //Otherwise reduce the wound score by amount healed (or increase if a negative) and set treated status to true
    const newWound = item.system.value
    const checkProp = {
      'system.value': item.system.value - healing,
      'system.treated': true
    }
    item.update(checkProp)
    
      hitLoc.update({
        'system.bleeding': false,
        'system.incapacitated': false,
        'system.unconscious': false
      })
    
    //Take the opportunity to delete any wounds with zero damage they may not be visible
    await ElysiumDamage.cleanseWounds(actor)
  }

  static async naturalHeal(event, actor) {
    const usage = await ElysiumDamage.healingAmount(game.i18n.localize('Elysium.naturalHealing'), false, false)
    let healing = 0
    const updates = [];
    const deletes = [];
    if (usage) {
      healing = Number(usage.treatWound);
    }
    //If amout of healing is zero then simply ignore and stop
    if (healing === 0) { return }

    //Put wounds in array and sort lowest to highest damage
    const wounds = [];
    for (let i of actor.items) {
      if (i.type === 'wound') {
        wounds.push(i);
      }
    }
    wounds.sort(function (a, b) {
      const x = a.system.value;
      const y = b.system.value;
      if (x < y) { return -1 };
      if (x > y) { return 1 };
      return 0;
    });

    let nw = wounds.length;
    for (let i of wounds) {
      if (i.system.value < 1) {
        deletes.push(i._id)
      } else {
        const avgHeal = Math.ceil(healing / nw)
        const woundHeal = Math.min(healing, i.system.value, avgHeal);
        healing = healing - woundHeal;
        if (woundHeal >= i.system.value) {
          deletes.push(i._id)
        } else if (woundHeal > 0) {
          updates.push({
            _id: i._id,
            'system.treated.': true,
            'system.value': i.system.value - woundHeal
          })
        } else {
          updates.push({
            _id: i._id,
            'system.treated.': true
          })
        }
      }
      nw--;
    }
    await Item.updateDocuments(updates, { parent: actor });
    await Item.deleteDocuments(deletes, { parent: actor });
  }

  //Delete any wounds that have zero or less damage - they may not be visible on the character sheet
  static async cleanseWounds(actor) {
    for (let i of actor.items) {
      if (i.type === 'wound' && i.system.value < 1) {
        i.delete();
      }
    }
  }

  // Form to get amount of damage or healing
  static async healingAmount(title, getType, getWnd, wndList, healTypes) {
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/dialog/treatWound.hbs',
      {
        getType,
        getWnd,
        wndList,
        healTypes
      }
    )
    const dlg = await ElysiumDialog.input({
      window: {title: title},
      content: html,
      ok: {
        label: game.i18n.localize('Elysium.confirm')
      }
    })
    return dlg
  }

  static async resetDaily(event, actor) {
    actor.update({ 'system.health.daily': 0 })
    ui.notifications.warn(game.i18n.localize('Elysium.resetDaily')+": "+actor.name)
  }

  //Get New Wound Dialog
  static async getWoundForm(getDam, getLoc, name, locs) {
    const title = game.i18n.localize('Elysium.addWound') + ": " + name;
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/dialog/newWound.hbs',
      {
        getDam,
        getLoc,
        locs
      }
    )

    const dlg = await ElysiumDialog.input({
      window: {title: title},
      content: html,
      ok: {
        label: game.i18n.localize('Elysium.confirm')
      }
    })
    return dlg
  }

  //Treat Wound by UUID
  static async applyHealing(woundUuid, successLevel) {
    const wound = await fromUuid(woundUuid)
    const actor = wound.parent
    let healing = 0
    let healingForm = ""
    successLevel = 0
    switch (successLevel) {
      case 0:
        //Fumble - create a wound
        let locationId = "total"
        
          locationId = (actor.items.filter(itm => itm.type === 'hit-location').filter(nItm => nItm.system.locType === 'general'))[0]._id
        
        //If GM create wound routine, otherwise call socket so GM creates wound
        if (game.user.isGM) {
          await ElysiumDamage.firstAidFumble([actor._id], [actor.type], locationId)
        } else {
          const availableGM = game.users.find(d => d.active && d.isGM)?.id
          if (availableGM) {
            game.socket.emit('system.elysium', {
              type: 'firstAidFumble',
              to: availableGM,
              value: { actorId: actor._id, actorType: actor.type, locationId }
            })
          } else {
            ui.notifications.warn(game.i18n.localize('Elysium.noAvailableGM'))
          }
        }
        healing = -1
        break
      case 2:
        //Success
        healingForm = "1D3"
        break
      case 3:
        //Special Success
        healingForm = "2D3"
        break
      case 4:
        //Critical Success
        healingForm = "1D3+3"
        break
    }
    if (healingForm != "") {
      const healRoll = new Roll(healingForm)
      await healRoll.evaluate()
      healing = Number(healRoll.total)
      if (game.modules.get('dice-so-nice')?.active) {
        game.dice3d.showForRoll(healRoll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
      }
    }

    if (healing >= wound.system.value) {
      wound.delete();
      actor.render(true)
    } else {
      await wound.update({
        'system.treated': true,
        'system.value': wound.system.value - healing
      })
      actor.render(true)
    }

    return { value: healing, formula: healingForm }
  }

  //Create First Aid Fumble Wound
  static async firstAidFumble(actorId, actorType, locationId) {

    const actor = await ElysiumActorDetails._getParticipant(actorId, actorType)
    const itemData = {
      name: game.i18n.localize('Elysium.wound'),
      type: 'wound',
      system: {
        locId: locationId,
        value: 1
      }
    };
    const newItem = await Item.create(itemData, { parent: actor });
    const key = await game.system.api.elysiumid.guessId(newItem)
    await newItem.update({
      'flags.elysium.elysiumidFlag.id': key,
      'flags.elysium.elysiumidFlag.lang': game.i18n.lang,
      'flags.elysium.elysiumidFlag.priority': 0
    })
  }

}

