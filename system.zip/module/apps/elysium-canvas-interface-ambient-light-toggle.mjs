/* global foundry fromUuid game */
import ElysiumCanvasInterface from './elysium-canvas-interface.mjs'

export default class ElysiumCanvasInterfaceAmbientLightToggle extends ElysiumCanvasInterface {
  static get actionToggles () {
    const buttons = super.actionToggles
    buttons[ElysiumCanvasInterface.actionToggle.On] = 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Action.On'
    buttons[ElysiumCanvasInterface.actionToggle.Off] = 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Action.Off'
    return buttons
  }

  static get icon () {
    return 'fa-regular fa-lightbulb'
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Button.Hint'
      }),
      action: new fields.NumberField({
        choices: ElysiumCanvasInterfaceAmbientLightToggle.actionToggles,
        initial: ElysiumCanvasInterface.actionToggle.Off,
        label: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Action.Title',
        hint: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Action.Hint',
        required: true
      }),
      lightUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'AmbientLight'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Light.Title',
          hint: 'Elysium.ElysiumCanvasInterface.AmbientLightToggle.Light.Hint'
        }
      )
    }
  }

  async _handleMouseOverEvent () {
    return game.user.isGM
  }

  async #handleClickEvent () {
    let toggle = false
    switch (this.action) {
      case ElysiumCanvasInterface.actionToggle.On:
        toggle = true
        break
      case ElysiumCanvasInterface.actionToggle.Toggle:
        {
          const firstUuid = this.lightUuids.first()
          if (firstUuid) {
            const doc = await fromUuid(firstUuid)
            toggle = doc.hidden
          }
        }
        break
    }
    for (const uuid of this.lightUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ hidden: !toggle })
      } else {
        console.error('Ambient Light ' + uuid + ' not loaded')
      }
    }
  }

  async _handleLeftClickEvent () {
    if (this.triggerButton === ElysiumCanvasInterface.triggerButton.Left) {
      this.#handleClickEvent()
    }
  }

  async _handleRightClickEvent () {
    if (this.triggerButton === ElysiumCanvasInterface.triggerButton.Right) {
      this.#handleClickEvent()
    }
  }
}
