/**
 * ArcaneDataModel — schema for items of type 'arcane'.
 *
 * Per P6.4 spec. Stored-schema-only. 42 compendium items in spells-arcane.db.
 *
 * Schema decisions:
 *   - Top-level uses makeSpellBaseFields() (shared with mysticism) plus
 *     `mem` (arcane-only memorized flag).
 *   - SIX compendium-only fields declared (side-finding #14): cost,
 *     pcost, magicChosen, mpCurr, mpMax, spellCat. ZERO code reads any
 *     of them; they're vestigial legacy from older versions. Required
 *     to accept compendium drops; P6.6 candidate to regenerate
 *     compendium without these and then drop schema declarations.
 *   - `spellCat` duplicates `elysium.school` (side-finding #15).
 *     Pre-existing data redundancy; declared to accept stored data.
 *   - `elysium.baseline` is a 4-key nested SchemaField {range, duration,
 *     targets, area}, all integers.
 *   - All string enums (school, damageType, saveSkill) FREE per content
 *     extensibility.
 *   - `elysium.{techniques, forms, validSchools}` are
 *     ArrayField<StringField>; techniques/forms populated in compendium
 *     (e.g. Magic Missile has `techniques: ["Create"], forms: ["Force"]`);
 *     validSchools empty across all 42 spells.
 */

import { makeItemBase, makeSpellBaseFields } from './_shared.mjs'

const fields = foundry.data.fields

export class ArcaneDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      ...makeSpellBaseFields(),
      mem: new fields.BooleanField({ initial: false }),  // arcane-only spell-base extra

      // v1.0.0-alpha.11 (side-finding #14): six vestigial pre-magic-rebuild
      // fields removed (cost, pcost, magicChosen, mpCurr, mpMax, spellCat).
      // All had zero code readers. spellCat additionally duplicated
      // elysium.school (former #15). Compendium regenerated to remove
      // ride-along values.

      elysium: new fields.SchemaField({
        school:        new fields.StringField({ initial: '' }),
        validSchools:  new fields.ArrayField(new fields.StringField(), { initial: [] }),
        techniques:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        forms:         new fields.ArrayField(new fields.StringField(), { initial: [] }),
        requiredSL:    new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        basePP:        new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        isDamageSpell: new fields.BooleanField({ initial: false }),
        damageType:    new fields.StringField({ initial: '' }),
        forbidden:     new fields.BooleanField({ initial: false }),

        // baseline: 4-key nested SchemaField — range/duration/targets/area
        baseline: new fields.SchemaField({
          range:    new fields.NumberField({ integer: true, initial: 0 }),
          duration: new fields.NumberField({ integer: true, initial: 0 }),
          targets:  new fields.NumberField({ integer: true, initial: 0 }),
          area:     new fields.NumberField({ integer: true, initial: 0 }),
        }),

        isReactive:  new fields.BooleanField({ initial: false }),
        isSustained: new fields.BooleanField({ initial: false }),
        isRitual:    new fields.BooleanField({ initial: false }),
        isPermanent: new fields.BooleanField({ initial: false }),
        powerCost:   new fields.NumberField({ integer: true, initial: 0 }),
        apCost:      new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill:   new fields.StringField({ initial: '' }),
      }),
    }
  }
}
