import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumPersTraitSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['persTrait'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs: { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details: {
      template: 'systems/elysium/templates/item/persTrait.detail.hbs',
      scrollable: ['']
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes: { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' }
  }

  // Tabbed
  static TAB_ORDER = ['header', 'tabs', 'details', 'description']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const itemData = context.item
    itemData.system.total = (itemData.system.base ?? 0) + (itemData.system.xp ?? 0);
    // Opposed total = base - xp historically; preserve current shape (if computed elsewhere it'll resolve)

    // Header chips per c2-2 lock — Opposed-trait name always; Total + Opposed Total when owned.
    const oppName = this.item.system.oppName;
    const chips = [{
      label: game.i18n.localize('Elysium.opposedTrait'),
      value: oppName && oppName.length > 0 ? oppName : '—',
    }];
    if (context.hasOwner) {
      chips.push(
        { label: game.i18n.localize('Elysium.total'), value: String(this.item.system.total ?? 0) },
        { label: game.i18n.localize('Elysium.opposedTotal'), value: String(this.item.system.opptotal ?? 0) },
      );
    }
    context.itemHeaderChips = chips;

    context.tabs = this._getTabs(options.parts);
    return context
  }

  _onRender(context, _options) {
  }
}
