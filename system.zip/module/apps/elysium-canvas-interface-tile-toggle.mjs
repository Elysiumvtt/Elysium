import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfaceTileToggle extends ElysiumCanvasInterface {
  static get PERMISSIONS () {
    return {
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.INHERIT]: 'OWNERSHIP.INHERIT',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE]: 'OWNERSHIP.NONE',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED]: 'OWNERSHIP.LIMITED',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER]: 'OWNERSHIP.OBSERVER',
      [CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER]: 'OWNERSHIP.OWNER'
    }
  }

  static get icon () {
    return 'fa-solid fa-cubes'
  }

  static get triggerButtons () {
    const buttons = super.triggerButtons
    buttons[ElysiumCanvasInterfaceTileToggle.triggerButton.Both] = 'Elysium.ElysiumCanvasInterface.Buttons.Both'
    return buttons
  }

  static get triggerButton () {
    const button = super.triggerButton
    button.Both = 20
    return button
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterfaceTileToggle.triggerButtons,
        initial: ElysiumCanvasInterfaceTileToggle.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.Button.Hint'
      }),
      action: new fields.NumberField({
        choices: ElysiumCanvasInterface.actionToggles,
        initial: ElysiumCanvasInterface.actionToggle.Off,
        label: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Action.Title',
        hint: 'Elysium.ElysiumCanvasInterface.DrawingToggle.Action.Hint',
        required: true
      }),
      tileUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'Tile'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.TileToggle.Tile.Title',
          hint: 'Elysium.ElysiumCanvasInterface.TileToggle.Tile.Hint'
        }
      ),
      journalEntryUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'JournalEntry'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.TileToggle.JournalEntry.Title',
          hint: 'Elysium.ElysiumCanvasInterface.TileToggle.JournalEntry.Hint'
        }
      ),
      permissionDocument: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceTileToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceTileToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionDocument.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionDocument.Hint',
        required: true
      }),
      permissionDocumentHide: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceTileToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceTileToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionDocumentHide.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionDocumentHide.Hint',
        required: true
      }),
      journalEntryPageUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'JournalEntryPage'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.TileToggle.JournalEntryPage.Title',
          hint: 'Elysium.ElysiumCanvasInterface.TileToggle.JournalEntryPage.Hint'
        }
      ),
      permissionPage: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceTileToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceTileToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionPage.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionPage.Hint',
        required: true
      }),
      permissionPageHide: new fields.NumberField({
        choices: Object.keys(ElysiumCanvasInterfaceTileToggle.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceTileToggle.PERMISSIONS[k]); return c }, {}),
        initial: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionPageHide.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.PermissionPageHide.Hint',
        required: true
      }),
      regionBehaviorUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'RegionBehavior'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.TileToggle.RegionBehavior.Title',
          hint: 'Elysium.ElysiumCanvasInterface.TileToggle.RegionBehavior.Hint'
        }
      ),
      regionButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Right,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerButton.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerButton.Hint'
      }),
      regionUuids: new fields.SetField(
        new fields.DocumentUUIDField({
          type: 'Region'
        }),
        {
          label: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerRegionUuids.Title',
          hint: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerRegionUuids.Hint'
        }
      ),
      triggerAsButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerAsButton.Title',
        hint: 'Elysium.ElysiumCanvasInterface.TileToggle.TriggerAsButton.Hint'
      }),
    }
  }

  static migrateData (source) {
    if (typeof source.triggerButton === 'undefined' && source.regionUuids?.length) {
      source.triggerButton = ElysiumCanvasInterfaceTileToggle.triggerButton.Both
    }
    if (typeof source.toggle !== 'undefined' && typeof source.action === 'undefined') {
      source.action = (source.toggle ? ElysiumCanvasInterface.actionToggle.On : ElysiumCanvasInterface.actionToggle.Off)
    }
    return source
  }

  async _handleMouseOverEvent () {
    return game.user.isGM
  }

  async #handleClickEvent (button) {
    let toggle = false
    switch (this.action) {
      case ElysiumCanvasInterface.actionToggle.On:
        toggle = true
        break
      case ElysiumCanvasInterface.actionToggle.Toggle:
        {
          const firstUuid = this.tileUuids.first()
          if (firstUuid) {
            const doc = await fromUuid(firstUuid)
            toggle = doc.hidden
          }
        }
        break
    }
    for (const uuid of this.tileUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ hidden: !toggle })
      } else {
        console.error('Tile ' + uuid + ' not loaded')
      }
    }
    const permissionDocument = (!toggle ? this.permissionDocumentHide : this.permissionDocument)
    const permissionPage = (!toggle ? this.permissionPageHide : this.permissionPage)
    for (const uuid of this.journalEntryUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ 'ownership.default': permissionDocument })
      } else {
        console.error('Journal Entry ' + uuid + ' not loaded')
      }
    }
    for (const uuid of this.journalEntryPageUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ 'ownership.default': permissionPage })
      } else {
        console.error('Journal Entry Page ' + uuid + ' not loaded')
      }
    }
    for (const uuid of this.regionBehaviorUuids) {
      const doc = await fromUuid(uuid)
      if (doc) {
        await doc.update({ disabled: !toggle })
      } else {
        console.error('Region Behavior ' + uuid + ' not loaded')
      }
    }
    if (this.triggerButton === ElysiumCanvasInterfaceTileToggle.triggerButton.Both) {
      for (const uuid of this.regionUuids) {
        setTimeout(() => {
          if (button === this.regionButton) {
            if (this.triggerAsButton === ElysiumCanvasInterface.triggerButton.Right) {
              game.elysium.ClickRegionRightUuid(uuid)
            } else if (this.triggerAsButton === ElysiumCanvasInterface.triggerButton.Left) {
              game.elysium.ClickRegionLeftUuid(uuid)
            }
          }
        }, 100)
      }
    }
  }

  async _handleLeftClickEvent() {
    if ([ElysiumCanvasInterfaceTileToggle.triggerButton.Both, ElysiumCanvasInterface.triggerButton.Left].includes(this.triggerButton)) {
      this.#handleClickEvent(ElysiumCanvasInterface.triggerButton.Left)
    }
  }

  async _handleRightClickEvent() {
    if ([ElysiumCanvasInterfaceTileToggle.triggerButton.Both, ElysiumCanvasInterface.triggerButton.Right].includes(this.triggerButton)) {
      this.#handleClickEvent(ElysiumCanvasInterface.triggerButton.Right)
    }
  }
}
