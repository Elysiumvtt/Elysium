# P6 Prep Audit — Item DataModels

Companion to `p5-prep-audit.md`. Captured 2026-05-13 against the v1.0.0-alpha.3 source tree
(post-P5 actor-DataModel ship) and the ElysiumCompendium module's .db packs (the bulk
content shipped separately from the system, but the canonical migration test surface).

## Foundry V14 DataModel API surface

Same as P5 — see `p5-prep-audit.md` for the V14 field-class inventory. P6 will use:
- StringField (with `choices:` for enums), NumberField, BooleanField
- HTMLField (description, gmDescription)
- ArrayField (skills/groups arrays in personality, profession, culture)
- SchemaField (nested shapes like `wound`'s value/treated/locId block)
- TypedObjectField (skillcat.attrib keyed by stat name → string)

## The 23 item types — bucketing

Per the P3 design + this audit's compendium-availability findings:

| Bucket | Types | Has compendium content? |
|---|---|---|
| P6.1 trivial | wound, reputation, failing, powerMod, skillcat, personality | none |
| P6.2 standard | passion, culture, persTrait, allegiance, mutation, super, ability, gear | culture, allegiance, mutation, super, ability, gear |
| P6.3 combat | weapon, armor, hit-location | all 3 |
| P6.4 magic | arcane, divine, mysticism, sorcery | all 4 |
| P6.5 prof+skill | profession, skill | both |

Total field count across all 23 types: **246 own fields + extensive `system.elysium.*` partitions** (sorcery alone has 28 elysium sub-keys in live data; arcane has 17). This is substantially larger than P3 anticipated (P3 estimated ~80 fields; the actual is 3× that once `system.elysium.*` is counted).

## Item base template

`template.json.Item.templates.base` contains 2 fields shared across most types:
- `description: HTMLField(initial: '')`
- `gmDescription: HTMLField(initial: '')`

Two types skip the base template: `wound`, `hit-location`. They have no `description`/`gmDescription`. (Wound is created programmatically by the damage system; hit-location uses different shape.)

**FINDING — `system.json.documentTypes` declares `htmlFields: ["description", "gmNotes"]` for 23 item types, but the actual stored field is `gmDescription`.** There are zero `system.gmNotes` reads or writes anywhere in source. The `gmNotes` references in templates are tab/section names, not field names. This is a pre-existing manifest bug — the `htmlFields` declaration tells Foundry which fields contain HTML for enrichment purposes, and `gmNotes` is a phantom entry. Side-finding flagged for P6.6 fix (when system.json's `documentTypes` block is touched anyway to remove `htmlFields` for types whose DataModel uses `fields.HTMLField`, since DataModel fields self-declare HTML-ness).

## DataModel strategy (continuing from P5)

**Stored-schema-only.** `ElysiumItem.prepareData` and the per-sheet `_prepareContext` continue to populate derived fields (enrichedDescription, perSkill, grpSkill, statName, skillCatNameStr, etc.). No `prepareDerivedData` overrides in the DataModels. Same decision as P5.

**Sparse-field strategy.** Each type's DataModel declares only the fields that type actually uses. For the `system.elysium.*` partition specifically, each type sparse-declares the sub-keys it needs (e.g., gear declares `elysium.{isContainer, containedIn, capacity}`; weapon declares `elysium.{damageType, force, reach, special, weaponReach, weaponSize}`; etc.).

**No new prep code, no migration scripts.** Per project scope.

---

# P6.1 implementation spec

Six trivial types. Total declared fields across all P6.1 types: **15 own fields** (plus the
shared description/gmDescription base where applicable).

## Compendium content audit

Zero compendium data for any P6.1 type. No migration risk for these specifically. Smoke-test
plan: create one of each type fresh, set fields, persist, reload.

## Shared helpers (`module/data/item/_shared.mjs`)

P6.1 introduces ONE helper:

```js
makeItemBase()   // returns { description: HTMLField(''), gmDescription: HTMLField('') }
```

Other helpers will accrete as later P6.* sub-phases need them (e.g., `makeSkillList()` for
personality/profession/culture in P6.1/P6.2, `makeStrEnum(values)` for combat fields in P6.3).

## Schema spec — implement EXACTLY this

### wound (4 → 3 fields; `created` dropped)

Skips the `base` template (no description/gmDescription).

```js
value:   new fields.NumberField({ integer: true, initial: 1, min: 0 }),
treated: new fields.BooleanField({ initial: false }),
locId:   new fields.StringField({ initial: '' }),
// DROPPED: `created` (template.json default false; ZERO reads/writes anywhere in source — confirmed
//          via grep on 'system.created', 'wound.created', and 'created' in module/combat/+module/elysium/).
//          Pre-existing dead field. Safe to drop.
```

Notes:
- `value` represents damage remaining on the wound; `damage.mjs:223,278,409` write decreasing values as healing applies. `min: 0` mirrors the existing clamp logic.
- `treated` flips when medical first-aid succeeds (`damage.mjs:224,408`).
- `locId` references an embedded `hit-location` item via its id (used in `damage.mjs:223`, `apps/check.mjs`).

### reputation (1 + base = 3 fields)

```js
...makeItemBase(),
base: new fields.NumberField({ integer: true, initial: 0 }),
```

Just a numeric reputation score. The 42 hits on `system.base` are mostly other types
(skills set `base`, weapons set `base`, etc. — all generic `_calcBase` writes in
actor-itemDrop.mjs). Reputation's own `base` is the rep value.

### failing (2 + base = 4 fields)

```js
...makeItemBase(),
shortDesc: new fields.StringField({ initial: '' }),
cpcMod:    new fields.NumberField({ integer: true, initial: 0 }),
```

`shortDesc` is a short summary shown on character.super.hbs; `cpcMod` is a character-creation-point modifier integer (negative for failings, which give back points).

### powerMod (3 + base = 5 fields)

```js
...makeItemBase(),
shortDesc: new fields.StringField({ initial: '' }),
cpcMod:    new fields.NumberField({ integer: true, initial: 0 }),
perLvl:    new fields.BooleanField({ initial: false }),
```

Same shape as `failing` plus the `perLvl` toggle (whether the mod scales per super-power level).

### skillcat (3 + base = 5 fields)

```js
...makeItemBase(),
// attrib: 8-stat object, values are string-digits "0".."4" representing category-bonus tier.
// Stored as STRINGS, not numbers, per template.json. The switch in actor.mjs:_categoryXXX uses
// string comparisons against "0".."4".
attrib: new fields.SchemaField({
  str: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  con: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  int: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  siz: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  pow: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  dex: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  cha: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),
  edu: new fields.StringField({ initial: '0', choices: ['0', '1', '2', '3', '4'] }),  // EDU skipped at read time per v0.20.0; field kept for storage compatibility
}),
// stat: the "single-stat bonus" override. 'none' means use the attrib formula instead.
stat: new fields.StringField({
  initial: 'none',
  choices: ['none', 'str', 'con', 'int', 'siz', 'pow', 'dex', 'cha', 'edu'],
}),
mod: new fields.NumberField({ integer: true, initial: 0 }),
```

**Schema decision:** `attrib` could be a `TypedObjectField` over a String. Going with explicit
`SchemaField` instead because the 8 keys are FIXED (str/con/int/siz/pow/dex/cha/edu — the
"include edu" set, not the actor's 7-stat set). SchemaField encodes the shape explicitly.

### personality (2 + base = 4 fields)

```js
...makeItemBase(),
// skills: array of {uuid, elysiumid} references. Set by drag-drop in personality.mjs.
skills: new fields.ArrayField(
  new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
  }),
  { initial: [] },
),
// groups: array of {options, skills: [{uuid, elysiumid}]} — "choose N of these skills" optional groups.
groups: new fields.ArrayField(
  new fields.SchemaField({
    options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
    skills:  new fields.ArrayField(
      new fields.SchemaField({
        uuid:      new fields.StringField({ initial: '' }),
        elysiumid: new fields.StringField({ initial: '' }),
      }),
      { initial: [] },
    ),
  }),
  { initial: [] },
),
```

Note: `culture` (P6.2) and `profession` (P6.5) will use this same `{uuid, elysiumid}` skill-list shape. Not factoring into `_shared.mjs` yet — wait until P6.2/P6.5 confirm the shape is bit-identical there; if it is, refactor then.

## Total schema slot count for P6.1

| Type | Own fields | Base fields | Total slots |
|---|---|---|---|
| wound | 3 | 0 | 3 |
| reputation | 1 | 2 | 3 |
| failing | 2 | 2 | 4 |
| powerMod | 3 | 2 | 5 |
| skillcat | 3 (one is nested 8-stat) | 2 | 5 (12 incl. nested) |
| personality | 2 (both arrays) | 2 | 4 |
| **Total** | **14** | **10** | **24 top-level** |

## init.mjs change

Add 6 imports + 6 registrations:

```js
import { WoundDataModel }       from '../data/item/wound.mjs'
import { ReputationDataModel }  from '../data/item/reputation.mjs'
import { FailingDataModel }     from '../data/item/failing.mjs'
import { PowerModDataModel }    from '../data/item/powerMod.mjs'
import { SkillcatDataModel }    from '../data/item/skillcat.mjs'
import { PersonalityDataModel } from '../data/item/personality.mjs'

// ...in section 3a after CONFIG.Actor.dataModels.character:
CONFIG.Item.dataModels.wound       = WoundDataModel
CONFIG.Item.dataModels.reputation  = ReputationDataModel
CONFIG.Item.dataModels.failing     = FailingDataModel
CONFIG.Item.dataModels.powerMod    = PowerModDataModel
CONFIG.Item.dataModels.skillcat    = SkillcatDataModel
CONFIG.Item.dataModels.personality = PersonalityDataModel
```

## Smoke test plan

Same playbook as P5.2 — per-type via Claude in Chrome's `javascript_tool`:

1. **Boot**: confirm each `CONFIG.Item.dataModels[type].name === 'XYZDataModel'` and schema field count matches the table above.
2. **Create**: `Item.create({type: '<type>', name: 'P6.1 Smoke <Type>'})` for each of the 6 types; confirm `instanceof XYZDataModel`.
3. **Persistence roundtrip** per type — write to one of each field-class type:
   - NumberField: `wound.value = 5`, `reputation.base = 50`, `failing.cpcMod = -3`, `powerMod.cpcMod = 2`, `skillcat.mod = 10`
   - StringField (free): `failing.shortDesc = 'Test failing'`, `powerMod.shortDesc = 'Test mod'`
   - StringField w/ choices: `skillcat.stat = 'str'` (valid); `skillcat.stat = 'invalid'` (rejected, DataModelValidationError)
   - BooleanField: `wound.treated = true`, `powerMod.perLvl = true`
   - HTMLField: `reputation.description = '<p>Test</p>'`
   - SchemaField nested: `skillcat.attrib.str = '2'`
   - ArrayField: `personality.skills = [{uuid: 'a', elysiumid: 'b'}]`
4. **No-bridge-wedge confirmation**: don't render item sheets during the smoke (item sheets also use ProseMirror; same risk). Per-field operations don't need the sheet.
5. **Cleanup**: delete the 6 smoke items.

The acceptance is: create + persist + reload across all 6 types, zero console errors, choices enforcement on skillcat.stat.

## Side findings (NOT for P6.1 scope — log only)

**#6 — `system.json.documentTypes.Item.<type>.htmlFields: ["description", "gmNotes"]`** is wrong for 23 of 23 item types. Real field is `gmDescription`. `gmNotes` doesn't exist anywhere as a stored field. Fix in P6.6 when the manifest is touched to drop `htmlFields` (DataModel HTMLFields self-declare HTML-ness, making the manifest entries redundant). Estimated 23 line edits in system.json. Pre-existing manifest bug, low impact (Foundry's HTML enrichment falls back to detection if the manifest says nothing).

**#7 — wound.created is dead.** ZERO reads, ZERO writes anywhere. Drop in P6.1 schema (do not declare). If any existing world has a wound with `system.created` set, DataModel cleanData will silently drop it. Migration concern is theoretical only (wounds are short-lived combat artifacts; they don't persist across sessions in practical use).

## Open audits for later P6.* sub-phases

P6.2 will need its own audit pass:
- gear's elysium partition (Torch in compendium has NO elysium partition — declared on template; may need to be optional or use a different declaration shape)
- allegiance has 7 own fields in compendium not in template.json (allegAllied, allegApoth, allegEnemy, allegPoints, allegTitle, benefits, opposeAlleg) — schema MUST declare them
- culture's skills/powers/professionalSkills arrays — same shape audit as personality.skills

P6.3 will need:
- weapon.elysium full enum lock (damageType, weaponSize values from compendium)
- armor.elysium full enum lock (material, layer values from compendium)
- weaponType / equipStatus / sizRng choices

P6.4 will need:
- sorcery's 28 elysium sub-keys — biggest schema in the system
- arcane's 17 elysium sub-keys
- divine has fields like minFaithRank, ritualMinutes, spellTags in compendium not in template — schema must declare

P6.5 will need:
- skill's 25 own fields all audited (boilerplate-heavy)
- profession's groups/powers/skills (same {uuid, elysiumid} shape as personality? confirm)

P6.6 acceptance:
- All 23 types create/render/persist/reload
- ALL compendium content drops onto a character without validation errors (drop a sample of each compendium type — gear, armor, weapon, skill, ability, mutation, allegiance, culture, super, arcane, divine, mysticism, sorcery, hit-location, profession = 15 types with content)
- template.json deleted (Item block removed; only Item remains today, and it goes with this)
- Fix side-finding #6 (system.json htmlFields)
- Visual regression baselines for representative item sheets (1 weapon, 1 armor, 1 skill, 1 spell as canonical examples)
