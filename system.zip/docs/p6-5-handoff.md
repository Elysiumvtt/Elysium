# P6.5 Prep Audit — Profession + Skill DataModels

Companion to `p6-prep-audit.md`. Captured 2026-05-13 against v1.0.0-alpha.8.
Covers the last 2 item types: `skill` and `profession`.

## Compendium content

| Type | Pack | Item count |
|---|---|---|
| skill | skills.db + arcane-knowledge.db | 107 + 24 = 131 |
| profession | professions.db | 8 |

Skill is the most-referenced item type in the system. The casting subsystem reads
`skill.system.elysium.arcaneRole` to identify form/technique skills for arcane spell
construction. The actor-itemDrop flow heavily writes `skill.system.base` via
`_calcBase`. Skills accumulate to actor.system.skillcategory in the actor.mjs:168 prep
chain.

## Schema-shape findings

### skill — 6 compendium-only fields (NOT in template)

**Top-level**: `cmbtSkill, fixed, magicSkill, professional` — 4 boolean flags.
- `cmbtSkill`: combat skill marker (compendium uses this; `combat` is the template's
  name — two different fields with similar meaning, both must be declared)
- `fixed`: skill with a fixed base (not stat-derived)
- `magicSkill`: skill is a magic-system skill (compendium has both true/false values)
- `professional`: skill is professional-tier (vs common)

**Elysium**: `arcaneRole, forbidden` — 2 fields.
- `arcaneRole` ∈ {'', 'form', 'technique'}. **CRITICAL** — the casting system
  (cast-shared.mjs:289, custom-spell-builder.mjs:90,99) reads this to route F/T
  skills. Must be a StringField.
- `forbidden` is a boolean (paralleling `arcane.elysium.forbidden`). Empty in
  compendium; declare permissively.

ZERO code reads `cmbtSkill`, `fixed`, `magicSkill`, `professional` (they're metadata).
Same legacy-vestigial pattern as armor's `av2/avr2/armBal/armVar` and arcane's compendium-
only fields. P6.6 candidate to drop after compendium regen.

### profession — 5 compendium-only fields (NOT in template)

**Top-level**: `commonSkills, culture, cultureBonus, professionalSkills` — 4 fields.
- `commonSkills` and `professionalSkills`: arrays of **STRING skill names** (NOT
  `{uuid, elysiumid}` objects like personality.skills or culture.skills). Different
  shape despite the field-name overlap with culture item type. The character creator
  uses these for name-matching against actual skill items.
- `culture`: string, always `''` in 8 compendium professions.
- `cultureBonus`: int, always `0` in 8 compendium professions.

**Elysium**: `themes` — 1 field. Array of strings (e.g. `['fighter', 'vanguard']`
on the Fighter profession). The themes tags used by the v0.13.0 themed-ability system
to filter abilities a profession grants access to.

### Template-vs-compendium typo: `category` initial

Template defaults `skill.category: 'cmmnmod'`. Compendium uses `'comnmod'`. Code in
`module/apps/select-lists.mjs:51` uses `comnmod`. Template has a typo. Schema
initial: `'comnmod'` (matches compendium + code). Side finding #17 for P6.6:
fix the template — but since template's Item block is removed in P6.6 anyway, this
becomes a non-issue automatically.

### Template-vs-compendium drift: `baseFormula.Func` default

Template defaults `baseFormula.Func: 'or'`. Compendium uses `'and'` or `'fixed'`
(no 'or' anywhere). Schema initial: keep `'or'` for backward-compat with template;
free StringField (no choices lock — values are computed at runtime per settings).

### baseFormula shape

Two slots `"1"` and `"2"`, each `{stat, value}`, plus a `Func` combinator string.
Per compendium: `stat` ∈ {'', 'cha', 'con', 'dex', 'fixed', 'int', 'pow', 'siz', 'str'}
(7 actor stats + 'fixed' for non-stat skills + '' for the unset slot). Schema:
`SchemaField` with explicit "1", "2", "Func" keys; each slot is an inner SchemaField
`{stat: StringField, value: NumberField}`.

### profession base-template gap

Template declares profession with `templates: ['base']` so it gets description + gmDescription.
Confirmed by compendium content (Fighter has `description`).

## String-enum locking decisions

Same conservative approach as P6.4 — magic-adjacent fields and content-creator-extensible
values stay free. P6.5 specifics:

- `skill.category` ∈ 7 observed values (`cmbtmod, comnmod, knowmod, magic, mentmod,
  mnplmod, physmod`). The `apps/select-lists.mjs` localizer enumerates these. They could
  be locked — well-bounded, mechanic-driven, no extensibility expected. **Decision: FREE**
  because the typo'd `cmmnmod` may exist in old data; locking would reject reads of those
  legacy values. Free is safer.
- `skill.elysium.skillCategory` ∈ {'standard', 'magic'} per template/compendium values.
  Only 2 values; mechanically driven. Lock candidate. **Decision: FREE** for consistency
  with P6.4's magic-adjacent fields and because additional category values may emerge
  (`'ritual'` etc.) from future content.
- `skill.elysium.skillSubgroup` ∈ {'', 'arcane', ...} (`arcane` only on arcane-knowledge
  skills; 'divine'/'mysticism' plausibly added by future content). FREE.
- `skill.elysium.arcaneRole` ∈ {'', 'form', 'technique'}. **Locked enum candidate** —
  only 3 values, mechanically driven by the casting system. But: cast-shared.mjs uses
  `!==` comparisons so unknown values just fail the filter gracefully. Locking would
  reject hypothetical future content extending the role set. **Decision: FREE** for
  forward-compatibility with mod content.
- `profession.elysium.tier` — template default `'basic'`, compendium only `'basic'`. Free.
- `profession.elysium.magicSystemAccess` — string, no compendium data. Free.

**No locked enums in P6.5.** Same outcome as P6.4 for the same reasons.

## P5.2-style side finding caught during audit (NOT P6.5 scope)

**#18 — `system.elysium.ancestryMove` is written to character actors** in
`ancestry-drop.mjs:367` but is NOT declared on the P5.2 CharacterDataModel. Verified
live: the write does not throw, but the data is silently dropped (Foundry's strict-
validation cleanData behavior). The accompanying `system.move` write does persist.
**Effect**: character.system.move is set on ancestry drop; the ancestryMove block
(meant to cache ancestry-specific fly/swim move values) silently goes missing. Same
pattern as the P5.2 `patron.standing` finding. P12 candidate to either declare the
field on CharacterDataModel or change the write site.

## P6.5 implementation spec

### profession.mjs (5 own + 1 base + 11 elysium + 1 themes + 4 compendium-only = ~22 slots)

```js
class ProfessionDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      // Template-declared: skills/groups/powers + wealth range
      skills: new fields.ArrayField(
        new fields.SchemaField({
          uuid:      new fields.StringField({ initial: '' }),
          elysiumid: new fields.StringField({ initial: '' }),
        }),
        { initial: [] },
      ),
      groups: new fields.ArrayField(
        new fields.SchemaField({
          options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
          skills: new fields.ArrayField(
            new fields.SchemaField({
              uuid:      new fields.StringField({ initial: '' }),
              elysiumid: new fields.StringField({ initial: '' }),
            }),
            { initial: [] },
          ),
        }),
        { initial: [] },
      ),
      powers:    new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      minWealth: new fields.NumberField({ integer: true, initial: 0 }),
      maxWealth: new fields.NumberField({ integer: true, initial: 0 }),

      // Compendium-driven (side-finding #14 family)
      // arrays of STRING skill names (NOT {uuid, elysiumid} — different shape from skills/groups)
      commonSkills:        new fields.ArrayField(new fields.StringField(), { initial: [] }),
      professionalSkills:  new fields.ArrayField(new fields.StringField(), { initial: [] }),
      culture:             new fields.StringField({ initial: '' }),
      cultureBonus:        new fields.NumberField({ integer: true, initial: 0 }),

      elysium: new fields.SchemaField({
        isElysiumProfession: new fields.BooleanField({ initial: false }),
        tier:                new fields.StringField({ initial: 'basic' }),
        primaryGroupSize:    new fields.NumberField({ integer: true, initial: 4 }),
        secondaryGroupSize:  new fields.NumberField({ integer: true, initial: 6 }),
        bonusGroupSize:      new fields.NumberField({ integer: true, initial: 2 }),
        packageBPCost:       new fields.NumberField({ integer: true, initial: 0 }),
        packageSkillPoints:  new fields.NumberField({ integer: true, initial: 0 }),
        magicSystemAccess:   new fields.StringField({ initial: '' }),
        startingEquipment:   new fields.ArrayField(new fields.StringField(), { initial: [] }),
        startingAbilities:   new fields.ArrayField(new fields.StringField(), { initial: [] }),
        startingWealth:      new fields.NumberField({ integer: true, initial: 0 }),
        // Compendium-driven (side-finding #14 family)
        themes:              new fields.ArrayField(new fields.StringField(), { initial: [] }),
      }),
    }
  }
}
```

### skill.mjs (25 own + 1 base + 4 compendium-only + 2 elysium + 2 compendium-only-elysium = ~34 slots)

```js
class SkillDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      subType:     new fields.StringField({ initial: '' }),
      base:        new fields.NumberField({ integer: true, initial: 0 }),
      xp:          new fields.NumberField({ integer: true, initial: 0 }),
      culture:     new fields.NumberField({ integer: true, initial: 0 }),
      profession:  new fields.NumberField({ integer: true, initial: 0 }),
      personality: new fields.NumberField({ integer: true, initial: 0 }),
      personal:    new fields.NumberField({ integer: true, initial: 0 }),
      effects:     new fields.NumberField({ integer: true, initial: 0 }),

      // baseFormula: two stat slots + a combinator function string
      baseFormula: new fields.SchemaField({
        '1': new fields.SchemaField({
          stat:  new fields.StringField({ initial: 'fixed' }),
          value: new fields.NumberField({ integer: true, initial: 0 }),
        }),
        '2': new fields.SchemaField({
          stat:  new fields.StringField({ initial: 'fixed' }),
          value: new fields.NumberField({ integer: true, initial: 0 }),
        }),
        Func: new fields.StringField({ initial: 'or' }),  // template default; FREE
      }),

      noXP:        new fields.BooleanField({ initial: false }),
      // Initial 'comnmod' (matches compendium + code; template had typo 'cmmnmod') — side-finding #17
      category:    new fields.StringField({ initial: 'comnmod' }),
      chosen:      new fields.BooleanField({ initial: false }),
      specialism:  new fields.BooleanField({ initial: false }),
      group:       new fields.BooleanField({ initial: false }),
      groupSkills: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      variable:    new fields.BooleanField({ initial: false }),
      specName:    new fields.StringField({ initial: '' }),
      mainName:    new fields.StringField({ initial: '' }),
      prsnlty:     new fields.BooleanField({ initial: false }),
      occupation:  new fields.BooleanField({ initial: false }),
      cultural:    new fields.BooleanField({ initial: false }),
      improve:     new fields.BooleanField({ initial: false }),
      basic:       new fields.BooleanField({ initial: false }),
      combat:      new fields.BooleanField({ initial: false }),

      // Compendium-driven (side-finding #14 family)
      cmbtSkill:    new fields.BooleanField({ initial: false }),
      fixed:        new fields.BooleanField({ initial: false }),
      magicSkill:   new fields.BooleanField({ initial: false }),
      professional: new fields.BooleanField({ initial: false }),

      elysium: new fields.SchemaField({
        skillCategory: new fields.StringField({ initial: 'standard' }),
        skillSubgroup: new fields.StringField({ initial: '' }),
        // Compendium-driven
        // arcaneRole is the CRITICAL one — casting system reads this
        arcaneRole:    new fields.StringField({ initial: '' }),
        forbidden:     new fields.BooleanField({ initial: false }),
      }),
    }
  }
}
```

## init.mjs

2 imports, 2 registrations. Section comment updated to note P6.5 ships final pair.

## Smoke test plan

1. Boot — both DataModels registered
2. Create — both types
3. Defaults — confirm compendium-only fields default-init, baseFormula has the 3 keys
   "1"/"2"/"Func", `skill.category === 'comnmod'` (the typo fix), `arcaneRole === ''`
4. Persistence — covering baseFormula deep nesting, the arcaneRole write (mimics what
   compendium drops set), profession's STRING-array shapes (commonSkills, professionalSkills,
   themes — distinct from {uuid, elysiumid})
5. **Compendium drop test** — 1 skill (from skills.db), 1 skill (from arcane-knowledge.db
   — has arcaneRole='form'), 1 profession (Fighter — has 2 themes). Zero validation errors;
   verify arcaneRole persists; verify profession's themes preserved.
6. Regression: full sweep of P6.1/2/3/4 types + actors
7. Cleanup

## Side findings

- **#17** — Template's `skill.category` initial 'cmmnmod' is a typo of 'comnmod' (the
  value used by code + compendium). Schema uses correct 'comnmod' as initial. Becomes
  non-issue when template's Item block is removed in P6.6.
- **#18** — `CharacterDataModel.system.elysium.ancestryMove` is NOT declared but
  `ancestry-drop.mjs:367` writes to it. Silently dropped (verified live). Same pattern
  as P5.2 #1 (patron.standing). P12 candidate.
