/**
 * Elysium Actor Extension
 *
 * Adds derived stats and helper methods to actors:
 *   - Action Points pool (and reaction subpool)
 *   - Healing Rate (Mythras)
 *   - Move (from ancestry, modified by fatigue/wounds)
 *   - Effective fatigue level (merged from sources)
 *   - Casting penalty from worn armour
 *   - Armour AP cap enforcement
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumData } from '../helpers/data.mjs'

export class ElysiumActorExtension {

  /**
   * Calculate all Elysium derived stats for an actor.
   * Stored in flags.elysium.derived for sheet display and tools.
   */
  static async calculateDerivedStats (actor) {
    if (!actor) return
    if (!getSetting('masterEnable', true)) return

    const derived = {}

    // Action Points
    if (getSetting('enableActionPoints', true)) {
      derived.actionPoints = this.calculateActionPoints(actor)
    }

    // Healing Rate (Mythras style)
    if (getSetting('enableMythrasHealingRate', true)) {
      derived.healingRate = this.calculateHealingRate(actor)
    }

    // Initiative bonus
    derived.initiative = this.calculateInitiativeBonus(actor)

    // Move (base + modifiers)
    derived.move = this.calculateMove(actor)

    // Casting penalty from armour
    if (getSetting('enableArmourCastingPenalty', true)) {
      derived.castingPenalty = this.calculateCastingPenalty(actor)
    }

    // Worn armour total AP (with cap)
    if (getSetting('enableArmourLayering', true)) {
      derived.wornArmourAP = this.calculateWornArmourAP(actor)
    }

    // PP max from POW
    derived.powerPointsMax = this.calculatePowerPointsMax(actor)

    // Mana max for Wizards (POW + INT)
    // Note: per latest rule, Mana = PP. Kept for legacy/optional toggle.
    derived.manaMax = this.calculateManaMax(actor)

    // Update actor flag without triggering re-render storms
    await actor.update({
      'flags.elysium.derived': derived
    }, { render: false, diff: false })

    return derived
  }


  // === ACTION POINTS ================================================

  static calculateActionPoints (actor) {
    const intVal = actor.system.stats?.int?.formula
      ? this._parseStatTotal(actor.system.stats.int)
      : 0
    const dexVal = actor.system.stats?.dex?.formula
      ? this._parseStatTotal(actor.system.stats.dex)
      : 0
    const sum = intVal + dexVal

    let baseAP = 1
    for (const row of ELYSIUM.AP_TABLE) {
      if (sum >= row.min && sum <= row.max) {
        baseAP = row.ap
        break
      }
    }
    if (sum > 84) baseAP = Math.floor((sum - 84) / 12) + 7

    // Active effect group modifiers
    const apMods = this._gatherAPModifiers(actor)

    // Wound penalties (cumulative)
    const woundPen = apMods.wound
    // Spell bonuses (best of)
    const spellBonus = apMods.spellBest
    // Skill bonuses (best of)
    const skillBonus = apMods.skillBest
    // Item slot bonuses (cumulative — based on anatomy)
    const itemBonus = apMods.itemSlots
    // Ancestry (best of)
    const ancestryBonus = apMods.ancestryBest
    // Fatigue penalty
    const fatiguePen = this._fatigueAPPenalty(actor)

    const total = Math.max(1, baseAP + spellBonus + skillBonus + ancestryBonus + itemBonus - woundPen - fatiguePen)
    const reactValue = apMods.reactionPool || 0
    const attackValue = apMods.attackPool || 0

    return {
      base:        baseAP,
      max:         total,
      value:       total,        // current — refreshed each combat round
      reactMax:    reactValue,
      reactValue:  reactValue,
      attackMax:   attackValue,
      attackValue: attackValue,
      breakdown: {
        base: baseAP,
        spell: spellBonus,
        skill: skillBonus,
        ancestry: ancestryBonus,
        items: itemBonus,
        wound: -woundPen,
        fatigue: -fatiguePen,
      }
    }
  }

  static _gatherAPModifiers (actor) {
    const mods = {
      spellBest: 0, skillBest: 0, ancestryBest: 0,
      itemSlots: 0, wound: 0,
      reactionPool: 0, attackPool: 0,
    }
    const groups = { spell: [], skill: [], ancestry: [] }

    for (const ae of actor.allApplicableEffects ? actor.allApplicableEffects() : actor.effects) {
      if (ae.disabled) continue
      const apFlag = ae.flags?.elysium?.apModifier
      if (!apFlag) continue

      switch (apFlag.group) {
        case 'spell':    groups.spell.push(apFlag.value);    break
        case 'skill':    groups.skill.push(apFlag.value);    break
        case 'ancestry': groups.ancestry.push(apFlag.value); break
        case 'wound':    mods.wound += Math.abs(apFlag.value); break
        case 'item':     mods.itemSlots += apFlag.value;     break
        case 'reaction': mods.reactionPool += apFlag.value;  break
        case 'attack':   mods.attackPool += apFlag.value;    break
      }
    }
    if (groups.spell.length)    mods.spellBest    = Math.max(...groups.spell)
    if (groups.skill.length)    mods.skillBest    = Math.max(...groups.skill)
    if (groups.ancestry.length) mods.ancestryBest = Math.max(...groups.ancestry)
    return mods
  }

  static _fatigueAPPenalty (actor) {
    const fatigue = actor.flags?.elysium?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    return fatLevel?.apPenalty || 0
  }


  // === HEALING RATE =================================================

  static calculateHealingRate (actor) {
    const con = this._parseStatTotal(actor.system.stats?.con)
    for (const row of ELYSIUM.HEALING_RATE_TABLE) {
      if (con >= row.min && con <= row.max) return row.rate
    }
    return 1
  }


  // === INITIATIVE ===================================================

  static calculateInitiativeBonus (actor) {
    const intVal = this._parseStatTotal(actor.system.stats?.int)
    const dexVal = this._parseStatTotal(actor.system.stats?.dex)
    const baseBonus = Math.floor((intVal + dexVal) / 2)

    const armourPen = this._calculateArmourPenalty(actor)
    const fatiguePen = this._fatigueInitiativePenalty(actor)

    return baseBonus - armourPen - fatiguePen
  }

  static _fatigueInitiativePenalty (actor) {
    const fatigue = actor.flags?.elysium?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    return Math.abs(fatLevel?.initiativePen || 0)
  }


  // === ARMOUR PENALTY ===============================================

  static _calculateArmourPenalty (actor) {
    let totalEnc = 0
    for (const item of actor.items) {
      if (item.type !== 'armour') continue
      if (item.system.equipStatus !== 'worn') continue
      const material = ElysiumData.path(item, 'material', 'cloth')
      const flexibility = ElysiumData.path(item, 'flexibility', 'flexible')
      if (material === 'natural') continue
      if (flexibility === 'natural') continue
      totalEnc += item.system.enc || 0
    }
    return Math.ceil(totalEnc / 5)
  }


  // === MOVE =========================================================

  static calculateMove (actor) {
    // Base from ancestry (default 30ft if no ancestry)
    let baseFt = 30

    // Find ancestry item — check both system.elysium and flags.elysium
    const ancestry = actor.items.find(i =>
      i.type === 'culture' && ElysiumData.path(i, 'ancestry')
    )
    const ancestryData = ancestry ? ElysiumData.path(ancestry, 'ancestry', {}) : null
    if (ancestryData?.baseMove) {
      baseFt = ancestryData.baseMove
    }

    // Wound penalties (cumulative)
    let flatPenalty = 0
    let multiplier = 1
    for (const item of actor.items) {
      if (item.type !== 'hit-location') continue
      if (item.system.locType !== 'limb') continue   // legs only
      // Check if it's a leg specifically
      const isLeg = (item.system.locType === 'leg' ||
                     item.system.locType === 'limb' ||
                     /leg/i.test(item.name))
      if (!isLeg) continue

      const curr = item.system.currHP
      const max = item.system.maxHP

      // Severely Wounded leg: -5ft
      if (max > 0 && curr > 0 && curr <= Math.floor(max / 2)) flatPenalty += 5
      // Critically Wounded leg: half move
      if (max > 0 && curr <= 0 && curr > -max) multiplier = Math.min(multiplier, 0.5)
    }

    // Fatigue
    const fatigue = actor.flags?.elysium?.fatigue?.level || 0
    const fatLevel = ELYSIUM.FATIGUE_LEVELS[fatigue]
    if (fatLevel?.movePenalty) flatPenalty += Math.abs(fatLevel.movePenalty * 5)
    if (fatLevel?.moveMult !== undefined && fatLevel.moveMult < 1) {
      multiplier = Math.min(multiplier, fatLevel.moveMult)
    }

    const finalFt = Math.max(1, Math.round((baseFt - flatPenalty) * multiplier))

    return {
      baseFt:       baseFt,
      currentFt:    finalFt,
      runFt:        Math.max(1, (finalFt * ELYSIUM.MOVEMENT.runMultiplier) - this._calculateArmourPenalty(actor) * 5),
      sprintFt:     Math.max(1, (finalFt * ELYSIUM.MOVEMENT.sprintMultiplier) - this._calculateArmourPenalty(actor) * 5),
      swimFt:       Math.max(1, Math.ceil(finalFt / 2) - this._calculateArmourPenalty(actor) * 5),
      crawlFt:      Math.max(1, Math.floor(finalFt / 4)),
      armourPenalty: this._calculateArmourPenalty(actor),
    }
  }


  // === CASTING PENALTY ==============================================

  static calculateCastingPenalty (actor) {
    let totalPenalty = 0
    const breakdown = []

    for (const item of actor.items) {
      if (item.type !== 'armour') continue
      if (item.system.equipStatus !== 'worn') continue

      const flexibility = ElysiumData.path(item, 'flexibility', 'flexible')
      const locType = ElysiumData.path(item, 'castingLocation', 'arm')
      const flexConfig = ELYSIUM.ARMOUR_FLEXIBILITY[flexibility]

      if (!flexConfig) continue
      if (flexibility === 'natural') continue

      // Custom override on item if set
      const override = ElysiumData.path(item, 'castingPenaltyOverride')
      if (override !== undefined && override !== null) {
        totalPenalty += override
        breakdown.push({
          item: item.name,
          penalty: override,
          override: true,
        })
        continue
      }

      const key = `casting_${locType}`
      const pen = flexConfig[key] || 0
      totalPenalty += pen
      breakdown.push({
        item: item.name,
        location: locType,
        flexibility,
        penalty: pen,
      })
    }

    // Skill reduction — Flexible Armour skill / Inflexible Armour skill
    const skillReduction = this._calculateArmourSkillReduction(actor, 'casting')
    const finalPenalty = Math.min(0, totalPenalty + skillReduction)

    return {
      basePenalty: totalPenalty,
      skillReduction,
      finalPenalty,
      breakdown,
    }
  }

  static _calculateArmourSkillReduction (actor, type) {
    // Find Flexible Armour and Inflexible Armour skills
    // Apply best applicable reduction
    // TBD scaling — placeholder based on threshold table
    let reduction = 0
    for (const skill of actor.items.filter(i => i.type === 'skill')) {
      const skillName = skill.name?.toLowerCase() || ''
      if (skillName.includes('flexible armour') || skillName.includes('inflexible armour')) {
        const total = (skill.system?.total ?? skill.system?.value ?? 0)
        // Reduction tiers by skill
        if (total >= 100)  reduction = Math.max(reduction, 0)   // TBD reduction values
        else if (total >= 76) reduction = Math.max(reduction, 0)
        else if (total >= 51) reduction = Math.max(reduction, 0)
        else if (total >= 26) reduction = Math.max(reduction, 0)
      }
    }
    return reduction
  }


  // === WORN ARMOUR AP CAP ===========================================

  static calculateWornArmourAP (actor) {
    // Group worn armour by location, sum AP, enforce cap
    const byLocation = {}
    for (const item of actor.items) {
      if (item.type !== 'armour') continue
      if (item.system.equipStatus !== 'worn') continue
      const loc = item.system.coverage || 'all'
      const flexibility = ElysiumData.path(item, 'flexibility', 'flexible')
      const ap = item.system.av1 || 0
      const isNatural = (flexibility === 'natural')

      if (!byLocation[loc]) byLocation[loc] = { worn: 0, natural: 0 }
      if (isNatural) byLocation[loc].natural += ap
      else byLocation[loc].worn += ap
    }

    // Apply cap to worn AP only
    const result = {}
    for (const loc in byLocation) {
      const wornCapped = Math.min(byLocation[loc].worn, ELYSIUM.ARMOUR_AP_CAP)
      result[loc] = {
        worn:    byLocation[loc].worn,
        natural: byLocation[loc].natural,
        wornCapped,
        totalAP: wornCapped + byLocation[loc].natural,
      }
    }
    return result
  }


  // === POWER POINTS / MANA ==========================================

  static calculatePowerPointsMax (actor) {
    return this._parseStatTotal(actor.system.stats?.pow)
  }

  static calculateManaMax (actor) {
    // Used only if a setting later distinguishes — currently same as PP
    const pow = this._parseStatTotal(actor.system.stats?.pow)
    const intVal = this._parseStatTotal(actor.system.stats?.int)
    return pow + intVal
  }


  // === ARMOUR VALIDATION ============================================

  /**
   * Called on item drop to enforce layering rules and assign layer
   */
  static async validateArmourLayer (item) {
    // BRP HPL toggle exists - keep that working
    // Just ensure flags.elysium.flexibility is populated if missing
    const data = item.toObject()
    if (!data.flags?.elysium?.flexibility) {
      data.flags = data.flags || {}
      data.flags.elysium = data.flags.elysium || {}
      data.flags.elysium.flexibility = 'flexible'
      data.flags.elysium.layerOrder  = 1
      data.flags.elysium.material    = 'cloth'
      data.flags.elysium.armorHP     = { value: 10, max: 10 }
      item.updateSource(data)
    }
    return true
  }


  // === HELPERS ======================================================

  static _parseStatTotal (statBlock) {
    if (!statBlock) return 0
    // BRP stores stat as an object with base/redist/culture/exp/age/effects
    let total = 0
    total += statBlock.base    ?? 0
    total += statBlock.redist  ?? 0
    total += statBlock.culture ?? 0
    total += statBlock.exp     ?? 0
    total += statBlock.age     ?? 0
    total += statBlock.effects ?? 0
    return total
  }

  static verifyAllActors () {
    if (!game.actors) return
    for (const actor of game.actors.contents) {
      if (!actor.flags?.elysium) {
        // Initialise missing flags
        actor.update({
          'flags.elysium': {
            version:           '0.1.0',
            luckPoints:        { value: 0, max: 0 },
            fatigue:           { level: 0, label: 'fresh', recoveryType: 'physical' },
            actionPoints:      { value: 0, max: 0, reactValue: 0, reactMax: 0 },
            tempHP:            { value: 0, max: 0 },
          }
        }, { render: false })
      }
    }
  }
}
