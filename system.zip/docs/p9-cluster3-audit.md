# P9 cluster 3 (items + social + pers) — prep audit

Captured 2026-05-14, after alpha.32 smoke pass. Source-of-truth document
ahead of the three-tab combined ship.

## Decisions inherited

- All cluster 1 and cluster 2 shared partials available.
- Decisions from P9 prep audit:
  - **items-1**: wealth-as-label only, no numeric currency.
  - **items-2**: drop ballistic columns entirely (vestigial pre-v0.21.0).
  - **social-1**: allegiance title inline with name as sub-line.
  - **pers-1**: horizontal scale-bar visualization for trait pairs.
- Default smoke pattern is offline-render (instantiate sheet, render
  partial to HTML string, parse via DOMParser); live render reserved
  for interactivity.
- Every new shared partial registered in `init.mjs:2a` `loadTemplates`.

## Phase scope

P9 cluster 3 rebuilds three legacy tab templates in a single alpha
because they share enough row-shape DNA that coordinated naming +
single CSS pass is cheaper than three serialized ships:

| Tab | Lines | Legacy classes | Distinct actions | Rebuild scope |
|---|---:|---:|---:|---|
| items | 127 | 27 | 5 | Two section cards (Armor, Gear); armor row keeps hit-loc grouping logic |
| social | 62 | 17 | 5 | Two section cards (Allegiances, Reputations cond.) |
| pers  | 54 | 18 | 5 | Two section cards (Traits, Passions) |

Total: ~243 lines of legacy template; ~62 distinct legacy classes,
heavy overlap with cluster 2's already-retired set.

## Per-tab inventory

### Items tab

Two distinct concerns:

**Armor list** (lines 18–92) uses a grouped pattern: actor's hit-locations
are listed as "headers" (`armor.system.list === 0`), and armor items
covering each location are listed beneath as nested rows (`list === 1`,
matched via `hitlocID`). User can collapse/expand armor groups via the
`armorLocToggle` action which flips `hitloc.system.hide`.

Context-prep at `character.mjs:954-974` does the interleaving server-side
by mutating `armors[]` with two row types into one ordered array. The
template branches on `armor.system.list === 0` to render a header vs a
per-armor row.

Current per-armor-row fields: name, AV (av1 or avr1 if useAVRand), AP
energy (ppCurr/ppMax with editable input), PP storage (pSCurr/pSMax),
encumbrance, skill mod (`mnplmod/percmod/physmod/stealthmod` as a
slash-delimited triple/quad), hit-loc name, equipStatus toggle.

Current per-group-header fields: hit-loc name (header), summary AV,
summary energy/PP/enc, summary skill mods, expand/collapse toggle.

**Gear list** (lines 95–126): simple flat list. Fields: name, quantity
(editable input), encumbrance, PP storage (pSCurr/pSMax if applicable),
equipStatus toggle.

**Wealth** is NOT currently displayed on the items tab in the legacy
template. Per audit decision items-1, wealth-as-label only — but if it
isn't shown today, the v1.0.0 rebuild can either: (a) keep the same
behavior (wealth surfaced elsewhere via the header card), or (b) add a
small wealth card to the items tab. Open question items-cluster3-1.

**Ballistic columns**: already removed from the legacy template at v0.21.0
per the `BAP column header dropped` comment. The dropped fields are still
declared on the DataModel for compendium drop compatibility (per P6.3
side-finding #12) but no template renders them. Audit decision items-2
(drop ballistic entirely) is already done in the legacy template; the
v1.0.0 rebuild simply doesn't reintroduce them.

### Social tab

Two distinct concerns:

**Allegiances** (lines 3–28): per-allegiance row with name, improve
toggle, total %, allegiance title, rank, enemy flag (skull icon), opposed
allegiance name (truncated text).

**Reputations** (lines 33–62), gated on `useReputation > 0` setting:
per-reputation row with name + total %. When `system.lock === false`,
the total cell becomes an editable input for the base value.

### Pers tab

Two distinct concerns:

**Personality Traits** (lines 4–29): per-trait row with name + improve
toggle + total % (rollable) + balance icon + opposed-total % (rollable)
+ opp-improve toggle + opposed-trait name. The trait row layout is what
audit decision pers-1 transforms into a horizontal scale-bar.

**Passions** (lines 34–53): per-passion row with name + improve toggle
+ total %. Note: `context.passions` here is `passionsGeneral` (the
arcane-category passions are filtered out and shown on the arcane tab
instead — see `character.mjs:1018-1020`). No template change needed for
this filtering; it's already in context-prep.

## Data dependencies — verified

```
context.armors[]      — interleaved header rows + per-armor rows
                        (each item has .system.list 0|1 to distinguish)
  per row:
    armor.name, armor.system.av1, .avr1, .ppCurr, .ppMax, .pSCurr,
    .pSMax, .enc, .actlEnc, .mnplmod, .percmod, .physmod, .stealthmod,
    .hitlocID, .hitlocName, .equipStatus, .equippedName, .hasEffects
    .system.list, .system.hide, .system.show, .system.length

context.gears[]       — flat list, sorted alphabetically
  gear.name, gear.system.quantity, .actlEnc, .pSCurr, .pSMax,
  .equipStatus, .equippedName, .hasEffects

context.allegiances[] — flat list, sorted
  allegiance.name, .system.improve, .total, .allegTitle, .rank,
  .allegEnemy (bool), .opposeAlleg (string — opposing allegiance name)

context.reputations[] — flat list, sorted
  reputation.name, .system.total, .base (when unlocked for edit)

context.persTraits[]  — flat list
  persTrait.name, .system.improve, .total, .opptotal,
  .oppimprove, .oppName (string — opposed trait name)

context.passions[]    — passionsGeneral (arcane category filtered out)
  passion.name, .system.improve, .total

context.useAVRand     — setting, gates av1 vs avr1
context.useReputation — setting, gates Reputations section
context.system.lock   — gates reputation editable
```

## Action handlers — all already registered

```
viewDoc, createDoc, itemToggle           — universal
armorToggle, armorLocToggle              — items tab
allegianceRoll, reputationRoll           — social tab
passionRoll, personalityRoll             — pers tab
```

No new handlers needed. No `.mjs` changes for cluster 3.

## Target v1.0.0 design

### Items tab — two section cards stacked

**Card 1: Armor**

The hit-loc grouping mechanism is non-trivial to throw away — Mythras
ranks armor by hit-location, so the grouping is semantically meaningful,
not just visual. Keep the mechanism. Visual redesign:

- Per hit-loc group header: a sub-row with location name + summary
  values (total AV, summary skill mods) + collapse/expand chevron.
  Visually similar to the cluster 2 hit-location-row but as a subheader
  within the armor card.
- Per-armor row underneath (when group expanded): name + AV value +
  energy/PP fields (when applicable) + encumbrance + skill-mod chip
  triple + equipStatus toggle. The expand-detail-row pattern from
  weapons doesn't quite fit — armor fields are fewer than weapon's, and
  the grouping concept already gives a layered structure.
- Empty hit-loc groups (no armor): show the group header with a faded
  "—" placeholder; clicking the add-armor button drops armor pre-keyed
  to that location (current legacy behavior, preserved).
- New shared partial: `armor-row.hbs`.
- New shared partial: `armor-group-header.hbs` (the per-hit-loc header).

**Card 2: Gear**

Simple flat list:
- Per row: name, quantity input, encumbrance, PP storage (when
  applicable), equipStatus toggle.
- The `hasEffects` sparkle marker from cluster 2's weapon-row reused
  here (consistent treatment across all item types).
- New shared partial: `gear-row.hbs`.

### Social tab — two section cards stacked

**Card 1: Allegiances**

Per row:
- Name (top line, prominent)
- Allegiance title (sub-line, smaller, muted) per audit decision social-1
- Total % chip (clickable, rollable)
- Rank chip
- Enemy marker (skull icon when `allegEnemy === true`)
- Opposed allegiance name (small text, only when set)
- Improve checkbox (square 18×18)

Visually: think of each row as a card-within-a-card — the name + title
left-aligned, chips and improve checkbox right-aligned.

New shared partial: `allegiance-row.hbs`.

**Card 2: Reputations** (gated on `useReputation > 0`)

Simple list:
- Per row: name, total % (rollable, OR editable input when unlocked).
- Locked state determined by `system.lock`.

New shared partial: `reputation-row.hbs`.

### Pers tab — two section cards stacked

**Card 1: Personality Traits — horizontal scale-bar layout**

Per pers-1 decision. Each trait row redesigned as:

```
[improve]  Trait Name (65%) ━━━━●━━━━ (35%) Opposed Name  [opp improve]
```

The middle bar visually represents the split: a horizontal track with
a marker positioned by `total/(total+opptotal)`. Total + opptotal usually
sum to 100, so the marker position is `total%` along the bar.

The trait name and opposed name flank the bar; percentage values appear
under each side. Improve checkboxes anchor both ends.

Click handlers:
- `data-action="personalityRoll" data-opp="false"` on the trait-side
  percentage and name
- `data-action="personalityRoll" data-opp="true"` on the opposed-side

New shared partial: `pers-trait-row.hbs` (the scale-bar component).

**Card 2: Passions**

Same shape as allegiance row, simpler:
- Per row: passion name + total % chip + improve checkbox.
- New shared partial: `passion-row.hbs` (was deferred from cluster 1
  to cluster 3 per the alpha.30 scope tightening).

## New shared partials for cluster 3

| Partial | Tabs consuming | NPC adaptation |
|---|---|---|
| `armor-group-header.hbs` | items | NPC reuses; possibly with `editable=false` to hide expand toggle |
| `armor-row.hbs` | items | NPC sets editable=false to read-only the input fields |
| `gear-row.hbs` | items | NPC sets editable=false; quantity becomes read-only span |
| `allegiance-row.hbs` | social, possibly divine in cluster 5 (faith allegiances) | NPC reuses as-is for read-only |
| `reputation-row.hbs` | social | NPC reuses; respects own lock state |
| `passion-row.hbs` | pers, arcane (cluster 5 — passionsArcane) | NPC reuses as-is |
| `pers-trait-row.hbs` | pers | NPC reuses as-is (NPCs DO have personality traits in Mythras) |

7 new partials. All must be added to `init.mjs:2a` `loadTemplates` array
per the alpha.31 lesson.

## CSS additions

Estimated ~250-300 lines added to `styles/elysium-sheets.css`. Rule
blocks anticipated:

- `.elysium-armor-group-header` + variants (expanded/collapsed)
- `.elysium-armor-row` grid
- `.elysium-gear-row` grid
- `.elysium-allegiance-row` (name + sub-title + chips)
- `.elysium-reputation-row` (simple two-column)
- `.elysium-passion-row` (matches allegiance simplified)
- `.elysium-pers-trait-row` + `.elysium-pers-trait-scale-bar` +
  `.elysium-pers-trait-scale-marker` (the new scale-bar visualization)
- `.elysium-row-subtitle` (the muted-grey sub-line under primary names —
  reusable beyond this cluster)

Token-resolution sweep runs as part of the ship per cluster 2 lesson.

## Out of scope for cluster 3

- Armor / gear / allegiance / reputation / passion / persTrait **item
  sheet rebuilds** — P10.
- Magic-tab passions (`passionsArcane`) — handled in cluster 5 magic
  ship; this cluster only renders the general passions.
- Faith-allegiance surface on the divine tab — cluster 5.

## Open questions requiring lock-in before ship

1. **items-cluster3-1**: Wealth display on items tab — surface as a
   small card at the top, or leave wealth in the header card (current
   legacy doesn't show it on items at all). Recommendation: **leave in
   header card**. Adding a wealth card on items adds visual noise without
   functional gain; the header card already shows wealthName. Sign-off?

2. **items-cluster3-2**: Armor group-header expand/collapse persistence —
   currently persisted via `hitloc.system.hide` (writes to the hit-loc
   item). v1.0.0 should preserve this behavior (no schema churn).
   Acceptable, or move to per-session client-side state? Recommendation:
   **preserve current behavior** — minimal change, matches the rest of
   the project's "no migrations" rule.

3. **pers-cluster3-1**: Pers-trait scale-bar — single bar with center
   marker, or two side-by-side chips with a balance icon between them?
   Audit pre-locked horizontal scale-bar. Confirm or override?

4. **pers-cluster3-2**: When `total + opptotal != 100` (rare but possible
   for unusual builds), should the scale-bar normalize to the sum (so
   the marker sits proportionally), or stay capped at 100? Recommendation:
   **normalize to sum** — visually accurate to the relative split,
   matches the user's likely intent.

5. **social-cluster3-1**: Opposed-allegiance name — render inline with
   the row (sub-text), or only show on hover? Recommendation: **inline
   when set, hide row when empty**. Avoids empty placeholder space.

## Proposed ship sequence

Single alpha (alpha.33). Three tabs, shared partial work done once,
single CSS pass, single smoke.

1. Add 7 partials to `init.mjs:2a`.
2. Write all 7 partials.
3. Rewrite `character.items.hbs`, `character.social.hbs`,
   `character.pers.hbs`.
4. Append CSS.
5. Pre-flight sweep: token resolution, brace balance, handlebars block
   balance, JSON parse, `node --check init.mjs`.
6. Package + present.
7. Live smoke (offline-render): each tab's HTML, structural counts,
   legacy-class retirement.
8. CSS verification via offscreen-element pattern.

After cluster 3: clusters 4 (background + statistics drill-down) and
cluster 5 (magic family + smart consolidation) close out P9.

## Ready-to-go checklist

- [x] All actions exist in `base-actor-sheet.mjs`
- [x] All context fields verified in `character.mjs:_prepareContext`
- [x] Armor group/expand logic understood (must preserve)
- [x] Pre-flight token check planned
- [ ] User sign-off on 5 open questions
