import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfacePlaySound extends ElysiumCanvasInterface {
  static get actionToggles () {
    const buttons = super.actionToggles
    buttons[ElysiumCanvasInterface.actionToggle.On] = 'Elysium.ElysiumCanvasInterface.PlaySound.Action.Play'
    buttons[ElysiumCanvasInterface.actionToggle.Off] = 'Elysium.ElysiumCanvasInterface.PlaySound.Action.Stop'
    return buttons
  }

  static get icon () {
    return 'fa-solid fa-music'
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.PlaySound.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.PlaySound.Button.Hint'
      }),
      action: new fields.NumberField({
        choices: ElysiumCanvasInterfacePlaySound.actionToggles,
        initial: ElysiumCanvasInterface.actionToggle.Off,
        label: 'Elysium.ElysiumCanvasInterface.PlaySound.Action.Title',
        hint: 'Elysium.ElysiumCanvasInterface.PlaySound.Action.Hint',
        required: true
      }),
      playlistUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.PlaySound.Playlist.Title',
        hint: 'Elysium.ElysiumCanvasInterface.PlaySound.Playlist.Hint',
        type: 'Playlist'
      }),
      soundUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.PlaySound.Sound.Title',
        hint: 'Elysium.ElysiumCanvasInterface.PlaySound.Sound.Hint',
        type: 'PlaylistSound'
      })
    }
  }

  static migrateData (source) {
    if (typeof source.toggle !== 'undefined' && typeof source.action === 'undefined') {
      source.action = (source.toggle ? ElysiumCanvasInterface.actionToggle.On : ElysiumCanvasInterface.actionToggle.Off)
    }
    return source
  }

  async _handleMouseOverEvent () {
    return game.user.isGM
  }

  async #handleClickEvent () {
    let toggle = false
    switch (this.action) {
      case ElysiumCanvasInterface.actionToggle.On:
        toggle = true
        break
      case ElysiumCanvasInterface.actionToggle.Toggle:
        {
          const firstUuid = this.playlistUuid ?? this.soundUuid
          if (firstUuid) {
            const doc = await fromUuid(firstUuid)
            toggle = !doc.playing
          }
        }
        break
    }
    if (this.playlistUuid) {
      const playList = await fromUuid(this.playlistUuid)
      if (playList) {
        if (toggle) {
          playList.playAll()
        } else {
          playList.stopAll()
        }
      } else {
        console.error('Playlist ' + this.sceneUuid + ' not loaded')
      }
    }
    if (this.soundUuid) {
      const sound = await fromUuid(this.soundUuid)
      if (sound) {
        if (toggle) {
          sound.parent.playSound(sound)
        } else {
          sound.parent.stopSound(sound)
        }
      } else {
        console.error('Sound ' + this.sceneUuid + ' not loaded')
      }
    }
  }

  async _handleLeftClickEvent () {
    if ((this.playlistUuid || this.soundUuid) && this.triggerButton === ElysiumCanvasInterface.triggerButton.Left) {
      this.#handleClickEvent()
    }
  }

  async _handleRightClickEvent () {
    if ((this.playlistUuid || this.soundUuid) && this.triggerButton === ElysiumCanvasInterface.triggerButton.Right) {
      this.#handleClickEvent()
    }
  }
}
