# P7.5 + P8 prep audit — Career rename + Actor sheet shell rebuild

Captured 2026-05-14, between P7 close (alpha.13) and P8 start.

This audit covers two scope-buckets shipped as a **single combined alpha**
per user decision:

- **P7.5** — `profession` → `career` codemod across system source +
  compendium. Pre-rename so P8 templates use the new vocabulary.
- **P8** — actor sheet shell rebuild. Three-rail layout with vertical tab
  rail on the right edge, new header/stats/resources cards, defenses/
  conditions/senses/effects right-rail cards, skills left rail.

Both ship as **alpha.14** with compendium bumped to alpha.3.

### Locked design decisions (refinements over the initial draft)

- **One ship for the combined work** — both phases land in alpha.14
- **Statistics tab retained** in the slim tab strip — it's the drill-down
  view of the stats card (full breakdown columns: Initial / Ancestry /
  Experience / Effects / Total / Fail Count)
- **Background and Pers tabs left alone** in P8 — P9 rationalizes their
  content
- **Tab strip placement: vertical icon rail on the right edge** of the
  sheet, outside the right rail. Icon-only chips ~40-50px wide; tooltip
  per icon; active highlight on the selected tab
- **AP card displays separate pools**: General AP (always), plus
  Reaction / Attack / Defense pools when their max > 0. Each row has
  current/max and a refresh button. General row also has an edit button.
  PP is single-pool with current/max + refresh + edit.
- **Tab icon glyphs** chosen by code-driven defaults (no per-icon
  user-specifiable in P8). Map: Combat → swords, Items → sack,
  Background → scroll, Pers → mask-theater, Social → people-group,
  Arcane → hat-wizard, Divine → cross, Mysticism → eye, Sorcery → fire,
  Mutations → dna, Super → bolt, Statistics → table-list, Story →
  book-open, Dev → code.

The two phases are **logically separable** but **practically coupled** —
P8 templates will reference the new `career` term throughout. Shipping P7.5
first is the discipline that prevents that coupling from becoming a hard
dependency mid-P8.

---

## P7.5 — Career rename codemod

### Scope

System-wide rename: `profession` → `career`. Affected:

- ~136 source occurrences across ~28 files (module/, templates/, lang/, system.json)
- 10 compendium files including `professions.db` pack itself
- The DataModel item type `profession` itself renames to `career`
- The `professions.db` pack file renames to `careers.db`
- The compendium pack collection id `elysium-compendium.professions` renames

Per user decision: **full deep rename**, not just label-level.

### What the new "Profession" concept will mean (preview)

After P7.5, the term "Profession" in the Elysium vocabulary is **reserved
but unused**. It's earmarked for a future specialized-crafting subsystem
(blacksmithing, alchemy, brewing — concrete trades that produce items).
That subsystem doesn't ship in P7.5 or P8; the term is just kept off the
table so it doesn't get re-conflated with "career".

### Skill bucket renames

The skill "buckets" rename in parallel:

| Old term | New term | Notes |
|---|---|---|
| Standard Skills | Standard Skills | unchanged — these are universal skills any character has |
| Professional Skills | Career Skills | direct mapping with the new term |

The CSS variable `--ely-legacy-skill-prof` (cornflower blue) keeps its
legacy name (legacy vars don't get retargeted in P7; that's a P12 task).
The new semantic token `--ely-skill-professional` (defined in P1 at
`#5a7aa0` for the same shade) does NOT rename — it's still the
"professional" identifier in P1, since renaming P1 tokens would cascade.
We accept the term mismatch in the token name; P12 can revisit.

### Codemod approach

Follow the P4 pattern:

1. **System source** — text-replace `profession` → `career` everywhere,
   with case preservation:
   - `profession` → `career`
   - `Profession` → `Career`
   - `PROFESSION` → `CAREER`
   - `professionId` → `careerId`
   - `professionName` → `careerName`
   - `professionalSkills` → `careerSkills`
   - `Profession*` JS class names → `Career*`
2. **Item type** — `'profession'` → `'career'`. This is the type-key
   used in `Item.create({type})`, in `CONFIG.Item.dataModels`, in
   `template.json` (already empty), in `init.mjs` registrations, in
   item.mjs item type checks.
3. **DataModel file** — `module/data/item/profession.mjs` → `module/data/item/career.mjs`
4. **Sheet file** — `module/item/sheets/profession.mjs` → `module/item/sheets/career.mjs`
5. **Template file** — `templates/item/profession.detail.hbs` → `templates/item/career.detail.hbs`
6. **System.json** — `documentTypes.Item.profession` → `documentTypes.Item.career`
7. **Lang files** — every `Elysium.profession*` key → `Elysium.career*` key (es/en/fr)
8. **Compendium** — `packs/professions.db` → `packs/careers.db`,
   internal `"type": "profession"` → `"type": "career"`, plus any
   string fields containing "Profession" that are display labels
9. **Compendium module.json** — pack registration block

### Decisions to handle during codemod

**Decision: do "Career Skills" or keep field name `professionalSkills`?**
The DataModel has `commonSkills` and `professionalSkills` arrays on the
career (profession) item type. Per the principle of "full deep rename",
**rename to `careerSkills`** in the schema + compendium content.

**Decision: do strings inside HTML descriptions get touched?** Compendium
items have description HTML. The codemod should NOT touch HTML
description text because it could break sentence grammar ("his profession
was a baker" → "his career was a baker" is fine, but "professional
soldier" → "careeral soldier" is wrong). **Approach**: in compendium .db
content, only rename JSON KEYS and TYPE-VALUE strings, not free-text
description content. Inspect post-rename to verify.

**Decision: i18n key names case-fold.** `Elysium.profession` → `Elysium.career`
is straightforward. Sub-keys like `Elysium.professionApplied`,
`Elysium.deleteProfession`, `Elysium.professionName` all transform.
**Approach**: regex with case preservation.

### Risk surface

- **Item type rename is the risky bit**. Any existing item with
  `type: 'profession'` instantiated against the new code will fail to
  resolve a DataModel. Per the fresh-world principle (no migration),
  this is acceptable — the compendium is the only source of these items,
  and we control the compendium content.
- **Localization file shape**. Three lang files (en/es/fr) each have a
  `Settings` sub-section that needs careful merge to avoid key
  collisions, same as the P4 rename.
- **Inadvertent matches in non-Elysium contexts**. The word "profession"
  is generic; if there's a comment like "// historical: BRP profession
  system was based on..." we want to preserve the historical reference.
  **Approach**: dry-run the codemod, eyeball the diff for context.

### Verification

- 0 occurrences of `profession*` in source (excluding intentional
  historical-context comments and CHANGELOG)
- `Item.create({type: 'career'})` succeeds; `Item.create({type: 'profession'})` fails with unknown-type
- Compendium pack `careers.db` loads; old `professions.db` doesn't exist
- Render sweep on career-type item still works (P6.5-shipped DataModel
  intact, just renamed)
- Lang files merge correctly; `Elysium.career` keys resolve; no orphan
  `Elysium.profession*` keys remain

### Estimated touch surface

| Bucket | Count |
|---|---|
| .mjs files edited | ~15 |
| .mjs files renamed | 2 (profession.mjs → career.mjs in both data/item/ and item/sheets/) |
| .hbs files edited | ~6 |
| .hbs files renamed | 1 (profession.detail.hbs → career.detail.hbs) |
| .json files edited | 5 (system.json + 3 lang files + compendium module.json) |
| Compendium .db files edited | ~10 |
| Compendium .db files renamed | 1 (professions.db → careers.db) |

### Versioning

`1.0.0-alpha.14` (system). Compendium module bumps to `1.0.0-alpha.3`
because of the type-key change and pack-file rename — content-shape
incompatible with alpha.2.

---

## P8 — Actor sheet shell rebuild

### Goal

Rebuild the character and NPC sheet **shell** (container, header, layout,
rail structure) against P7 semantic tokens. Tab content stays unchanged
in this phase — old `character.*.hbs` templates render inside the new
tab containers. P9 rebuilds individual tab content.

### Layout

```
┌─────────────────────────────────────────────────────────────┐
│  HEADER CARD  (full width)                                  │
│  ┌────┐  Name              [Public][GM] [VE E R A D F I]    │
│  │portr│  Ancestry           Init Bonus  Move Base  Luck   │
│  │ #XP │  Career             [Lock]                        │
│  └────┘                                                     │
├─────────────────────────────────────────────────────────────┤
│  STATS CARD  (full width)                                   │
│  STR 16 (3d6+3) [✓]  →  Damage Mod  +1d4                    │
│  CON 14 (3d6+1) [✓]  →  Healing Rate  3                     │
│  INT 13 (3d6+0) [✓]  →  XP Bonus  +5                        │
│  SIZ 12 (3d6+0) [✓]  →  —                                   │
│  POW 15 (3d6+2) [✓]  →  —                                   │
│  DEX 14 (3d6+1) [✓]  →  —                                   │
│  CHA 11 (3d6-1) [✓]  →  Init Bonus  (shown in header strip) │
├─────────────────────────────────────────────────────────────┤
│  RESOURCES CARD  (full width)                               │
│  AP  3 / 4  [↻][✎]      PP  12 / 15  [↻][✎]                │
├──────────────┬──────────────────────────────┬───────────────┤
│  LEFT RAIL   │  CENTER                      │  RIGHT RAIL   │
│              │  ┌─Combat | Items | Char...─┐ │               │
│  SKILLS      │  │ (tab strip)              │ │  DEFENSES     │
│  Standard:   │  ├──────────────────────────┤ │  Temp HP: 0   │
│   Athletics  │  │                          │ │  HP: 24/30    │
│   Stealth    │  │  (tab content area —     │ │  ─────────    │
│   ...        │  │   old templates render   │ │  Head 5/5 AP3│
│  ─────────  │  │   unchanged in P8;       │ │   ↳ Plate(3) │
│  Career:     │  │   P9 rebuilds each tab)  │ │  Chest 8/8 AP5│
│   Tactics    │  │                          │ │   ↳ Mail(2)  │
│   Lore (...) │  │                          │ │   ↳ Plate(3) │
│   ...        │  │                          │ │  ...          │
│              │  └──────────────────────────┘ │  [Rest]       │
│              │                              │  ─────────    │
│              │                              │  CONDITIONS   │
│              │                              │  Bleeding·Leg │
│              │                              │  Prone        │
│              │                              │  ─────────    │
│              │                              │  SENSES       │
│              │                              │  Perception 47%│
│              │                              │  Darkvis 60ft │
│              │                              │  ─────────    │
│              │                              │  ACTIVE EFFECTS│
│              │                              │  Bless [✓]   │
│              │                              │  Rage  [✓]   │
└──────────────┴──────────────────────────────┴───────────────┘
```

### Component-by-component spec

#### Header card

- **Portrait** (left, 80×80) with an **EXP Dice** count badge overlay
  (small dark circle, bottom-right corner of portrait, showing
  `actor.system.elysium.expDice.available` — single number)
- **Name + meta block** (middle):
  - Name (h2, `--ely-text-decorative` color, BoucherieBlock font)
  - Ancestry name (small, `--ely-text-body`, "from {culture}" or
    similar)
  - Career name (small)
  - Lock toggle (small icon on the right of the meta block, persists
    the existing lock/unlock pattern)
- **Header strip** (right, single horizontal row):
  - **Roll-visibility pair**: `[Public] [GM]` — two toggle chips,
    one active at a time. Default: Public. Persists per-sheet to
    `flags.elysium.headerRollVisibility`.
  - **Difficulty strip**: 7 chips `[VE] [E] [R] [A] [D] [F] [I]`.
    Default highlight on `A` (Average). Single click sets the
    difficulty for the next roll; resets to `A` after roll fires.
    Tooltips on hover: "Very Easy (×3)", "Easy (×2)", etc.
    Persists per-sheet to `flags.elysium.headerDifficulty`.
  - **Initiative Bonus** chip — read-only value
    (`actor.flags.elysium.derived.initiative` or equivalent)
  - **Movement Base** chip — read-only (`actor.system.move`)
  - **Luck Points** chip — `current/max` with click-to-spend
    behavior (P8 builds chip; spend behavior is existing infra)
- **NPC variant**: identical structure, with a small "NPC" badge
  in the meta block under the name (or before the name). My choice:
  small chip on the right side of the name line — `Name [NPC]`.

#### Stats card

7 rows, each a single grid row with:

- **Stat block** (left, ~45% width):
  - Stat short name (`STR`, `CON`, etc.) — left-aligned, decorative font
  - Stat total — large number, center
  - Stat base — small subscript or parenthesis
  - Improve checkbox — right-aligned
  - Whole row is rollable (click = stat roll)
- **Arrow / connector** (visual cue, optional)
- **Derived pairing** (right, ~45% width):
  - Derived name (left)
  - Derived value (right, bold)

Pairings:
- STR → Damage Modifier
- CON → Healing Rate
- INT → XP Bonus
- SIZ → (empty — no pairing in v1.0.0 with AP/PP moved to Resources)
- POW → (empty — no pairing)
- DEX → (empty — no pairing)
- CHA → Initiative Bonus (note: also shown in header strip; OK to
  duplicate for the "STR-row-knows-its-derived" convention)

**Concern logged**: SIZ, POW, DEX have empty pairings. Three open
slots. Options for filling: nothing (clean dashes), or fill with
mechanically-relevant secondary derived stats. Decision deferred to
implementation; default = empty dashes for symmetry.

#### Resources card

Single full-width card with two sections:

- **AP** (left half):
  - Label "ACTION POINTS"
  - `current / max` — current editable, max read-only-derived
  - Refresh button — sets current to max
  - Edit button — opens a small dialog or makes current editable inline
- **PP** (right half):
  - Same shape as AP but reading `powerPoints`

The max values are derived from stats (`actor.flags.elysium.derived.actionPoints.max`
and `actor.flags.elysium.derived.powerPointsMax`). The current values
live in `actor.flags.elysium.derived.actionPoints.value` etc. Today's
sheet stores these in flags; the new sheet does the same.

#### Left rail — Skills

- Scrollable column, full rail height
- Title bar: "SKILLS"
- Skills grouped into two collapsible sections:
  - **Standard Skills** — all skills with `system.elysium.skillSubgroup === ''` or general (universal-skill identifier)
  - **Career Skills** — all skills with `system.elysium.skillSubgroup === 'career'` (post-rename)
- Inside each group, further subgroup by skill category
  (Manipulation / Knowledge / etc.) with subheaders
- Each skill row:
  - Skill name (left, clickable for skill roll)
  - Category tag (small, muted text)
  - Improve checkbox (small)
  - Total % (right, bold, larger)
- Click skill name → skill roll (existing `_onSkillRoll` action)
- Click improve checkbox → mark for improvement (existing infra)

#### Center — Tab strip + content

Tab strip slimmed from the current 15 conditional tabs to a curated list:

- **Combat** — always shown
- **Items** — always shown (renamed from "items" if needed for label
  consistency; check current label)
- **Char** — always shown — `pers` or `background` content
- **Social** — conditional on settings (existing condition)
- **Magic group** — one tab per active magic system the character has:
  - Arcane (if `system.arcane != ''`)
  - Divine (if `system.divine != ''`)
  - Mysticism (if `system.mysticism != ''`)
  - Sorcery (if `system.sorcery != ''`)
  - Mutations (if `system.mutation != ''`)
  - Super (if `system.super != ''`)
- **Story** — always shown (replaces / equivalent to current `background`?)
- **Dev** — if `game.settings.get('elysium', 'development')` is true

Tabs **removed from the strip** in P8:
- **Skills** — moved to left rail
- **Effects** — moved to right rail (Active Effects card)
- **Statistics** — content merged into the header Stats card

Tab content area: renders the existing `character.<tab>.hbs` template
unchanged. P9 rebuilds each tab against the new card design.

#### Right rail — Defenses card

- Title: "DEFENSES"
- **Temp HP** section at top: single editable number, label
  "Temporary HP". Persists to `actor.flags.elysium.tempHP` (existing
  infra from the wound-absorbs-tempHP mechanic).
- **Overall HP** section: `currentHP / maxHP` summary (computed from
  sum of hit-location HPs). Read-only display.
- **Hit-location list**: each location is a row, click to expand:
  - **Collapsed row**: `Head 5/5 AP3` — location name, current/max HP,
    AP value
  - **Expanded row**: shows armor layers contributing to AP
    - For each equipped armor item with this hit-location ID:
      `  ↳ Helm (Plate, AP 3)`
    - Built-in/natural armor: `↳ Natural (AP 0)`
- **Rest button** at bottom: "Rest...". In P8, button is a stub —
  clicking shows a `ui.notifications.warn("Rest dialog coming in P9")`
  notification. P9 builds the dialog with GM-approval flow.

#### Right rail — Conditions card

- Title: "CONDITIONS"
- **Actor-wide conditions**: list of `actor.effects` with `statuses.size > 0`
  - Each row: condition name (small chip / pill style)
- **Location-specific conditions**: each hit-location's
  `system.elysium.locationConditions[]` entries
  - Each row: condition name + affected location `Bleeding · Right Leg`

If actor has no conditions and no location conditions, show "None" or
hide the card entirely. Decision: **hide if empty**.

#### Right rail — Senses card

- Title: "SENSES"
- **Perception line**: `Perception <skill%>` — the actor's
  Perception-skill total. Clickable for a Perception roll.
- **Vision lines**: scan `actor.items` for `mutation` and `super` items
  with `system.elysium.visionType` set; each one becomes a row:
  `Dark Vision  60 ft` etc.
- If no vision specials, show only the Perception line.

#### Right rail — Active Effects card

- Title: "ACTIVE EFFECTS"
- List of `actor.effects.filter(e => e.statuses.size === 0)` — all
  AEs that aren't standard status conditions (those are in the
  Conditions card)
- Each row:
  - AE name (left, click to edit — opens existing `ActiveEffectConfig`)
  - Source item (small muted text underneath name, if `e.origin` points
    at an item)
  - Enable toggle (right)
  - Delete button (small)
- Includes a "+" button at the bottom of the card to create a new AE.

### Width and resizing

- Default width: **1200 px** (bumped from 865)
- Default height: **900 px** (bumped from 850)
- Resizable
- Minimum width: 1000 px (below this, rails would crush; clamp)
- Below 1000 px should be impossible by clamp, but if it happens
  somehow, layout responsively collapses rails — not in scope for
  P8; if it surfaces, log as a side finding

### File layout

#### New templates (P8 ships these)

```
templates/actor/parts/
├── header-card.hbs              (portrait + name + meta + strip)
├── stats-card.hbs               (7-row stat grid with derived pairings)
├── resources-card.hbs           (AP + PP)
├── tabs-strip.hbs               (slimmed tab navigation)
├── left-rail-skills.hbs         (the skill rail)
├── right-rail-defenses.hbs      (Temp HP + HP + hit-locations + Rest)
├── right-rail-conditions.hbs    (status + location conditions)
├── right-rail-senses.hbs        (Perception + vision types)
└── right-rail-effects.hbs       (active effects list)
```

Each part template renders inside the appropriate slot. The character
sheet container template (a rewritten `character.hbs` or a new
top-level template) composes these parts plus the existing tab-content
templates.

#### Edited templates (P8 may touch these to remove tab-strip entries
no longer needed, or to add wrapper classes)

- `templates/actor/character.header.hbs` — replaced by header-card.hbs
- `templates/global/parts/actor-tab-navigation.hbs` — replaced by tabs-strip.hbs

#### Edited code (P8)

- `module/actor/sheets/character.mjs`:
  - `PARTS` registration updated to include new parts
  - `_configureRenderOptions` updated to remove `skills`, `effects`,
    `statistics` from the conditional tabs list (they're moved to
    rails/header)
  - `_prepareContext` extended to populate new context paths needed
    by the rails (skill groups, hit-location list with armor layers,
    condition list, senses list, AE list)
  - Default width/height bumped
- `module/actor/sheets/npcV2.mjs`:
  - Repointed to use the same `PARTS` structure as character
  - "NPC" badge wired into the header part
  - Width/height bumped
- `module/actor/sheets/base-actor-sheet.mjs`:
  - New action handlers (rest-stub, AP/PP refresh, AP/PP edit, etc.)
  - Helper functions for rail context prep if they're shared

#### Edited stylesheets (P8)

- `styles/elysium-sheets.css` — fills in:
  - Three-rail grid layout (`.elysium-sheet-shell` outermost grid)
  - Header card styling
  - Stats card styling
  - Resources card styling
  - Skills rail styling (group headers, skill rows)
  - Defenses card styling (hit-loc rows, expand/collapse, layer dropdowns)
  - Conditions card styling
  - Senses card styling
  - Active Effects card styling
  - Tab strip styling

Per the P7 audit, this is where elysium-sheets.css gets its first content.
Estimated 600-1200 lines of new CSS in this file.

### What P8 deliberately does NOT do

- **No tab CONTENT rebuild** — Combat/Items/Char/Social/Magic tabs use
  the existing templates verbatim. P9 rebuilds them.
- **No new Profession/crafting subsystem** — the term is reserved (P7.5)
  but unbuilt.
- **No Rest dialog** — stub button only.
- **No Foundry V14 → V16 upgrade work** — DataModels handle this; no
  V16 prep needed in P8.
- **No retargeting of `--ely-legacy-*` vars** in legacy.css/elysium.css/npc.css.
  Those continue to apply to existing tab content. P12 deletes them
  when each surface is rebuilt.

### Acceptance criteria

- Character sheet renders with new 3-rail layout
- NPC sheet renders with same layout + "NPC" badge
- 7 stats card cells render with correct totals + derived pairings
- Skills rail populates with all 100+ skills grouped correctly
- Defenses card shows hit-locations with HP+AP, expandable for armor
  layers
- Conditions card shows actor + location conditions
- Senses card shows Perception + vision types
- Active Effects card shows AEs with toggle/delete/add
- Tab strip shows only the slimmed list of tabs
- Each tab's content renders unchanged from current
- AP and PP cards have refresh + edit buttons that work
- Header strip: Public/GM toggle works; difficulty strip sets
  difficulty for next roll; Luck Points chip shows value
- Visual regression baselines re-captured against the new shell

### Risk assessment

**Medium-high** per ROADMAP. Specific risks:

- **Three-rail layout in a Foundry V14 ApplicationV2** — V2 apps have a
  `PARTS` model. Each part is a separate Handlebars template that
  renders into a named slot. The three-rail shell needs to coordinate
  three independent scrollable areas; this requires careful CSS grid
  setup so the rails scroll independently while the tab content area
  scrolls separately.
- **Tab content compatibility** — old templates reference context
  variables that the old `_prepareContext` populated. The new
  context-prep MUST continue to populate ALL of those (skills array,
  combat tables, etc.) so old templates don't break. Approach: keep
  the entire current `_prepareContext` body, then ADD the new
  rail-related context paths. Don't subtract anything.
- **Card chrome (gear / help icons)** — per user decision, skip these
  entirely. Cards have just titles and content. Saves implementation
  time.
- **Edit-AP/PP** — the "edit" pattern needs a UI. Simplest: clicking
  the current/max display swaps it to an input. Alternative: opens a
  small inline number-stepper. Decision: inline editable input (click
  to edit, blur or Enter to commit). No dialog.

### Versioning

P8 ships as `1.0.0-alpha.15`. Compendium unchanged at v1.0.0-alpha.3
(P8 has no compendium impact; alpha.3 was set by P7.5).

### Estimated touch surface

| Bucket | Count |
|---|---|
| New .hbs files (parts) | 9 |
| Edited .hbs files (replaced) | 2 |
| Edited .mjs files | 3 |
| Edited .css (elysium-sheets.css) | 1 (gets ~600-1200 lines) |
| Baseline snapshots | 3 |

---

## Combined ship plan

| Alpha | Phase | Scope | Compendium |
|---|---|---|---|
| 14 | P7.5 | profession → career codemod | bump to alpha.3 |
| 15 | P8 | actor sheet shell | unchanged |

P7.5 ships first so P8 can use the new vocabulary from line 1. Each
ship gets its own live smoke pass against test-2 before the next
begins.
