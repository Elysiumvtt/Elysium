# P11 Cluster 7 prep audit — combat-tracker cosmetic restyle

**Status**: PENDING
**Target alpha**: alpha.51 (if recommendation is SHIP) or none (if NO SHIP)
**Scope**: Evaluate whether the Foundry V14 combat-tracker surface, as rendered by `templates/combat/combat-tracker.html` via the `ElysiumCombatTracker` subclass, should receive a v1.0.0 cosmetic restyle pass analogous to P11's chat-card + dialog work. The combat tracker is the last user-facing UI surface the v1.0.0 rebuild has not visited.
**Inheritance from**: P11 prep audit (open-question reserving cluster 7 as "optional combat-tracker cosmetic restyle"), cluster-1 audit (the `.application.elysium` scoping pattern + retoken methodology), cluster-3 audit (hitloc-tag inline-style retirement pattern — directly applicable to brace-badge), cluster-6 audit (island harmonisation findings inform whether combat-tracker would be a new "island").

Like cluster 6, this audit is an evaluation. It catalogs the current state, identifies the work that a full restyle would entail, weighs the cost against the benefit, and reaches a recommendation. Unlike cluster 6, cluster 7's work is meaningfully larger if pursued (12+ structural decisions vs cluster 6's 2 mechanical findings), so the audit needs to be thorough enough that a SHIP decision would be implementable without a second audit pass.

---

## 1. Current-state inventory

### Surface footprint

| Component | Path | LOC |
|---|---|---|
| Template | `templates/combat/combat-tracker.html` | 125 |
| Subclass | `module/combat/combat-tracker.mjs` | 7 |
| Render hook (brace-badge) | `module/elysium/hooks/render-combat-tracker.mjs` | 26 |
| Behavioural extension | `module/elysium/combat/combat-extension.mjs` | 390 (NOT in cluster-7 scope — pure behaviour) |
| Context-menu patch | `module/elysium/mechanics/engagement-ui.mjs:28-53` | 26 (patches V14 CombatTracker prototype) |
| **Cluster-7-relevant total** | — | **~184** |

### Elysium-owned CSS targeting combat-tracker

**Zero.** The combat-tracker template is rendered today with **no Elysium CSS of any kind** beyond what cascades from `.application.elysium` body rules (if that selector reaches the sidebar tracker at all — see §3 F4 below). The tracker inherits Foundry V14's default visual treatment entirely.

The `.elysium .combat-input-small` rule in `css/legacy.css:730` and `.elysium .quick-combat` rule at line 1454 are NOT combat-tracker rules — the former is an actor-sheet input field class, the latter is a chat-card class already retokenned in P11 cluster 3.

### Class-hook contract (audit-5 lock candidates)

The template contains both Foundry-API contract classes (these belong to the V14 CombatTracker prototype and CANNOT be renamed) and Elysium-injected hooks. Inventory:

**Foundry V14 CombatTracker API contract** (immutable — V14 reads/writes these):
- `data-combatant-id` on every `<li>` — V14 reads to identify which combatant a click targets; ALSO read by 4 Elysium subsystems (see below)
- `data-control="..."` on every action button (16 distinct values: `endCombat`, `rollAll`, `rollNPC`, `resetAll`, `toggleSceneLink`, `trackerSettings`, `toggleHidden`, `toggleDefeated`, `pingCombatant`, `panToCombatant`, `rollInitiative`, `previousRound`, `previousTurn`, `nextTurn`, `nextRound`, `startCombat`) — V14's event delegation dispatches off these
- `data-document-id` on encounter-cycle buttons — V14 navigates encounters off this
- `id="combat-tracker"` on the `<ol>` — V14 may select by id
- `id="combat-controls"` on the footer `<nav>` — V14 may select by id
- `class="combatant"` on each `<li>` — V14 styles + event-binds off this
- `class="combatant-control"` on combatant action buttons — V14 event-binds + applies `.active` state toggle off this
- `class="directory-item"`, `class="directory-list"`, `class="directory-footer"` — V14 base CSS family; sidebar styling cascades depend on these

**Elysium-injected hooks** (used by Elysium JS, must be preserved if rebuilt):
- `data-combatant-id` (the API contract attribute — reused by 4 Elysium subsystems below; this is both API-contract AND Elysium-hook)
  - `engagement-ui.mjs:80,90,95,113,118` — engage / change-range / disengage context-menu callbacks
  - `charge-ui.mjs` — registers context-menu off charge-eligible combatants
  - `outmanoeuvre.mjs` — registers context-menu off outmanoeuvre-eligible combatants
  - `render-combat-tracker.mjs:16` — locates row for brace-badge injection
- `.elysium-brace-badge` — class on the brace-badge `<i>` element; render hook checks `row.querySelector('.elysium-brace-badge')` to avoid double-injection
- `.token-name`, `.combatant-name`, `.name` — fallback selector list in `render-combat-tracker.mjs:19` for badge-insertion anchor (only `.token-name` actually exists in the current template; the other two are V13-era fallbacks)

**Foundry CSS-only inherited classes** (these would be retired if Elysium scoped its own styling):
- `flexrow`, `flexcol` — Foundry V14 flexbox utility classes
- `noborder`, `directory`, `directory-item`, `directory-list`, `directory-footer` — Foundry sidebar family
- `encounter-controls`, `encounter-title`, `encounters`, `encounter` — Foundry combat-tracker family
- `combat-button`, `combat-control`, `combat-create`, `combat-cycle`, `combat-settings`, `combatant-controls`, `token-image`, `token-name`, `token-effects`, `token-effect`, `token-resource`, `token-initiative`, `resource`, `initiative` — Foundry combat-tracker family

The Foundry family classes are NOT removable — they're how V14 styles + binds events. The question for cluster 7 is whether Elysium **adds** scoping marker classes alongside them (the `.elysium-cast-card` pattern from cluster 1) for token-driven re-skinning, or leaves them untouched.

### Inline-style anti-patterns already on disk

The brace-badge injection in `render-combat-tracker.mjs:23` uses an inline-style string:

```js
badge.style.cssText = 'margin-left:6px;color:#0066aa;'
```

The hardcoded color `#0066aa` (a saturated medium blue) is **not retokenned** to a `--ely-*` token. This is the same anti-pattern cluster 3 retired for the hitloc-tag chip. The badge has **no matching CSS rule anywhere** — confirmed via grep across `styles/` + `css/` + `templates/`. Retirement methodology is identical to cluster 3's hitloc retoken.

### Behavioural extensions (out of scope clarification)

`module/elysium/combat/combat-extension.mjs` (390 LOC) provides:
- Custom initiative formula (1d10 + bonus - armor penalty)
- Action Point pool refresh per round
- Per-round bleed-damage application
- Sustained-spell PP upkeep dispatch
- Per-round outmanoeuvre block clearing

**Cluster 7 does NOT touch any of this.** It's pure mechanic logic, no DOM, no template. Listed here only to clarify the scope boundary: cluster 7 is template + CSS + inline-style retirement only.

### Deferred ChatMessage.create callsites (out of scope clarification)

The P11 prep audit explicitly deferred 51 inline-HTML `ChatMessage.create({content:'<div style="..."'})` callsites in `module/elysium/mechanics/` and `module/casting/` as out-of-P11-scope. Live re-count at alpha.50: **27 callsites** distributed across 11 files:

| File | Count |
|---|---|
| `module/elysium/mechanics/charge-ui.mjs` | 6 |
| `module/casting/sustain.mjs` | 4 |
| `module/elysium/mechanics/outmanoeuvre.mjs` | 3 |
| `module/elysium/mechanics/engagement-ui.mjs` | 3 |
| `module/elysium/mechanics/covering-stance.mjs` | 3 |
| `module/casting/sorcery-cast.mjs` | 3 |
| Remaining 5 files | 1 each |

The discrepancy (51 vs 27) is likely that the prep audit counted both `ChatMessage.create` calls AND inline `<div style="..."` literals as separate items, or that some callsites have been collapsed since the prep audit. The exact number isn't important — what matters is that these are still **out of cluster 7 scope** and remain P12 polish work. Cluster 7 deals with the combat-tracker template/CSS only.

---

## 2. Structural archetype analysis

The combat-tracker template breaks into 3 structural regions:

### Region A — Header (lines 1–46)

Two horizontal nav bars:
1. **Encounters nav** (`<nav class="encounters">`) — GM-only — encounter create / cycle prev / current-index display / cycle next / delete-encounter
2. **Encounter controls** (`<div class="encounter-controls">`) — GM controls (roll-all / roll-NPC / initiative-reset / scene-link) + round-or-status title + settings cog

Both are button-strip patterns. The encounters nav has a centered text element between two paired button groups; the encounter-controls have a centered `<h3>` between symmetric GM button clusters. **Restyle target**: token-driven button styling, accent on the encounter title, consistent button hit-area.

### Region B — Combatant list (lines 48–86)

One `<li class="combatant">` per combatant, each containing:
- Token image (left)
- Name + per-combatant control row (center) — toggle-hidden, toggle-defeated, ping, pan-to (visibility-gated by GM/owner), and the `.token-effects` group with effect-icon imgs
- Optional resource readout (right side)
- Initiative display or roll-initiative button (far right)

**Restyle target**: row-as-card treatment (matches the `.elysium-chat-card` family aesthetic), token-driven row backgrounds with active-turn accent, initiative pill styling, effect-icon size + spacing normalisation, brace-badge retoken (Finding F3 below).

### Region C — Round/turn navigation footer (lines 88–104)

Conditional 5-button strip (GM: prev-round / prev-turn / END / next-turn / next-round) or 3-button (player with control: prev-turn / END-TURN / next-turn). The center button uses class `combat-control center` for visual emphasis.

**Restyle target**: footer-as-action-strip treatment matching dialog-row's `__row` family; "center" button accented as primary-action.

### Conclusion on archetypes

The 3 regions don't collapse to chat-card or dialog vocabularies. The combat-tracker has its own structural identity (continuous scrollable list + persistent header/footer chrome), unlike chat cards (single-purpose messages) or dialogs (modal task completion). **A cluster-7 ship would add a fourth UI vocabulary**, not reuse existing partials.

---

## 3. Findings

### F1 — Combat-tracker is the LAST unstyled user-facing surface

After P11 clusters 1–5 + alpha.50 hotfix, every user-facing surface has v1.0.0 styling EXCEPT the combat tracker:

| Surface | v1.0.0 status |
|---|---|
| Actor sheets (8 types) | DONE (P8/P9) |
| Item sheets (23 types) | DONE (P10) |
| Chat cards (15 types) | DONE (P11 c1-c4) |
| Generic dialogs (10 templates) | DONE (P11 c5) |
| Cast-card + 3 island dialogs | DONE (P11 c1 retoken) |
| **Combat tracker** | **NOT DONE** |

The combat tracker currently presents as Foundry V14's default sidebar styling, which uses Foundry's neutral grey-on-dark aesthetic, NOT Elysium's dark-bone-crimson identity. End-user experience: opening the combat tracker is a visible "I left the system" moment compared to the surrounding chat + sheets.

### F2 — Foundry's `.application.elysium` scoping does NOT reach the combat tracker

The body-typography rule at `styles/elysium-reset.css:86` (`/* .application.elysium { font-family: ... } */`) cascades to all Elysium application windows. The combat tracker, however, is rendered inside Foundry's `Sidebar` application, NOT a standalone application window. Whether `.application.elysium` reaches the sidebar tracker depends on Foundry's sidebar composition — it does NOT, based on inspection of the rendered tracker template, which starts with `<section class="{{cssClass}} directory flexcol">` where `{{cssClass}}` is Foundry's CombatTracker.cssClass (not `.application.elysium`).

**Implication**: any cluster-7 restyle must introduce its own scoping marker, analogous to `.elysium-chat-card` for chat or `.elysium-dialog` for dialogs. Candidate names: `.elysium-combat-tracker`, `.elysium-tracker`, `.elysium-encounter-tracker`. Decision deferred to c7-2 below.

### F3 — Brace-badge inline-style anti-pattern (matches cluster-3 hitloc retoken)

`module/elysium/hooks/render-combat-tracker.mjs:21-23`:
```js
badge.className = 'fas fa-shield elysium-brace-badge'
badge.dataset.tooltip = `${c.name} is bracing — knockback excess halved.`
badge.style.cssText = 'margin-left:6px;color:#0066aa;'
```

- The `.elysium-brace-badge` class has **zero CSS rules** anywhere (verified by grep across `styles/`, `css/`, `templates/`).
- The inline color `#0066aa` is a hardcoded blue not present in `elysium-tokens.css`.
- The 6px left margin is a literal not retokenned.

**Identical anti-pattern** to the pre-cluster-3 hitloc-tag inline-style (`margin-left:6px;padding:1px 6px;border-radius:3px;background:#604030;color:#fff;font-size:11px;`). Cluster 3 retoken methodology applies directly:
1. Add a CSS rule `.elysium-brace-badge { margin-left: var(--ely-space-1); color: var(--ely-text-info); }` (or comparable token)
2. Remove the `badge.style.cssText` line
3. Audit-5-lock the `.elysium-brace-badge` class (it's already a JS hook used for double-injection guard)

This is small-scope work (3 lines of JS + 1 CSS rule) that could ride along regardless of whether the larger cluster-7 restyle ships.

### F4 — The 16 `data-control` values are NOT renameable

Unlike clusters 1–5 where JS-imperative classes (`.cardbutton`, `.skill-select`, etc.) were Elysium-owned and locked against rename, the combat-tracker's `data-control="X"` attributes are part of Foundry V14's CombatTracker API contract. V14's `_onClickAction` (or equivalent) dispatches off these values. Renaming `data-control="endCombat"` to `data-control="elysium-endCombat"` would break the tracker.

This is a different lock posture from prior clusters: cluster 7's lock list is **inherited from Foundry**, not from Elysium audit-5. Any restyle must preserve all 16 `data-control` values verbatim AND every Foundry-family class (`combat-button`, `combatant`, `combat-control`, `combatant-control`, etc.).

### F5 — Context-menu integration is independent of template

`engagement-ui.mjs:28-53` patches `CombatTracker.prototype._getEntryContextOptions` to append Engage / Change Range / Disengage / Charge / Brace / Knockback / Outmanoeuvre entries to the V14 right-click context menu. This dispatch path reads `data-combatant-id` from the clicked `<li>` element but is otherwise template-independent — it doesn't care about styling, BEM structure, or marker classes.

**Implication**: cluster 7 restyling will NOT touch context-menu integration. The context menu is V14-rendered chrome that lives outside the template surface. Whatever cluster 7 does to the tracker's visual treatment, the right-click menu continues to work unchanged.

### F6 — Combat-tracker has 0 i18n keys to add

Every user-visible string in the template uses `{{localize 'COMBAT.X'}}` or `{{localize 'labels.X'}}` — these are Foundry V14 core translation keys, NOT Elysium i18n keys. A cluster-7 restyle would add zero new i18n entries.

### F7 — Token effect icons are unstyled

`<img class="token-effect" src="{{this}}" />` in lines 73-75 renders Foundry's status effect icons. Their size, spacing, and layout inside `.token-effects` is currently Foundry-default. A restyle would token-drive their size + gap, possibly add an active-effect glow or container.

---

## 4. Cluster-7 options

### Option A — NO SHIP (defer to P12)

Combat tracker stays on Foundry V14 default styling. F3 brace-badge retoken folds into P12 alongside cluster-6's px-literal cleanup and the `darkred` retoken.

**Cost**: zero work. **Benefit**: P11 closes immediately, P12 starts.

**Risk**: combat-tracker remains visually inconsistent with the rest of the v1.0.0 system indefinitely. Players opening combat will see a UI mode-switch every encounter.

### Option B — MINIMAL SHIP (brace-badge retoken only)

Ship F3 alone. Add `.elysium-brace-badge` rule to `styles/elysium-chat.css` (or a new `styles/elysium-tracker.css`), drop the inline-style line, retoken the color + spacing. Don't touch the broader combat-tracker template or chrome.

**Cost**: ~15 LOC (1 CSS rule + 3-line JS change + small CHANGELOG entry). Pre-flight sweep trivial.
**Benefit**: closes one inline-style anti-pattern. Establishes `.elysium-brace-badge` as a properly-classed hook.
**Risk**: leaves the broader F1 visual-misalignment problem completely unaddressed. Looks like half a fix.

### Option C — FULL COSMETIC SHIP

Add `.elysium-combat-tracker` scoping marker to the template root. Build `styles/elysium-tracker.css` from scratch (analogous to `elysium-chat.css`'s 6-section structure). Token-drive every region (header chrome / combatant row / footer). Ship F3 brace-badge retoken inside the same cluster. Optionally add Section D equivalents for combat states (active turn / defeated / hidden).

**Cost estimate**: 
  - Template: ~125 LOC → ~140 LOC (marker class + minor restructure for accent anchors)
  - New CSS file: ~250–350 LOC (greenfield, comparable to alpha.45's elysium-chat.css 25→457 build-out)
  - `system.json` styles array entry +1
  - F3 brace-badge retoken folded in
  - Live smoke: needs an actual encounter with combatants in the test world (more involved than chat-card fixture rendering — combat-tracker state depends on running combat + active turn + variety of combatant states)
  - Total estimated work: 2–3 ship-cycles of audit-then-code if broken into sub-clusters (header / body / footer), OR a single larger ship if scoped tighter

**Benefit**: F1 closes. Visual identity now reaches every user-facing surface. The "last unstyled island" is gone.

**Risk**: Combat tracker is a stateful + frequently-updated surface (every turn re-renders the active-turn highlight). Visual bugs are visible in every encounter, every turn. Slower-burning regressions (e.g. an active-turn accent that's hard to see at small zoom) won't necessarily surface in fixture renders.

### Option D — STAGED SHIP (header first, body+footer later)

Split Option C into two cluster ships:
- **c7a** (alpha.51): scoping marker + header chrome (Region A) + F3 brace-badge retoken + `styles/elysium-tracker.css` foundation file
- **c7b** (alpha.52): combatant list (Region B) + footer (Region C) + Section D state accents

**Cost**: ~60% of Option C's work in c7a, ~40% in c7b. Two ship cycles instead of one.
**Benefit**: smaller per-ship surface area; visible incremental improvement; audit-then-stop discipline applies cleanly per sub-cluster.
**Risk**: visual inconsistency mid-flight (header styled, body not) for whatever window separates c7a and c7b ships.

---

## 5. Open questions

These need explicit answers before SHIP work begins. Marked **(blocking)** for cluster 7 commit; non-blocking ones can be deferred to per-sub-cluster sub-audits if Option D is chosen.

### Q1 (blocking) — Scoping marker class name

Candidates: `.elysium-combat-tracker`, `.elysium-tracker`, `.elysium-encounter-tracker`. The first matches the template family naming. The second is shorter but less specific. The third is more semantically accurate (the tracker tracks the *encounter*, of which the combat is one phase).

**Recommendation**: `.elysium-combat-tracker`. Matches the existing `.elysium-chat-card` / `.elysium-dialog` naming pattern, is unambiguous, and lets `.elysium-encounter-tracker` remain available if a future feature distinguishes encounter-management UI from combat-runtime UI.

### Q2 (blocking) — CSS file location

Three options:
1. **Add to `styles/elysium-chat.css`** — currently the home for chat-card + dialog rules. Tracker isn't a chat surface but it's a "sidebar feature", semantically adjacent.
2. **Add to `styles/elysium-sheets.css`** — currently sheets only.
3. **New file `styles/elysium-tracker.css`** — its own surface, its own file. Add to `system.json` `styles` array.

**Recommendation**: option 3. The tracker is a distinct UI vocabulary (per §2 analysis) and giving it its own file keeps `elysium-chat.css`'s 6-section structure clean. Sets precedent for any future top-level sidebar surface to get its own file.

### Q3 (blocking) — Restyle scope: Option A / B / C / D

This is the audit's core question. Recommendation below in §6.

### Q4 — Brace-badge styling specifics (if F3 ships)

Current inline: `margin-left:6px;color:#0066aa;`. Retoken targets:
- `margin-left: var(--ely-space-1)` (matches existing chat-card chip spacing)
- `color: ?` — the `#0066aa` blue is `info`-family but `--ely-text-info` may or may not match the design intent

Recommendation: live-verify the retoken in the test world by spot-checking what `--ely-text-info` resolves to at the brace-badge size against the tracker background. If the contrast is wrong, propose a new `--ely-accent-defense` or `--ely-accent-brace` token.

### Q5 — Active-turn accent (if Option C or D ships)

V14 marks the current-turn combatant with a `.active` class added to the `<li class="combatant">`. The default rendering is a subtle highlight. The v1.0.0 identity calls for a stronger accent — likely a left-border or background tint using `--ely-accent-action` (crimson, matching the CB/CM/QC combat-family chat-card accents from cluster 3).

### Q6 — Defeated / hidden combatant state styling

V14 adds `.defeated` and `.hidden` classes to the `<li>` for those states. Recommendation: defeated → desaturated + reduced opacity; hidden → italic name + ghosted portrait. Both currently use Foundry defaults that don't match the v1.0.0 contrast level.

### Q7 — Token-effect icon sizing

Current Foundry default is ~16px square icons in a horizontal row inside `.token-effects`. The v1.0.0 chip vocabulary uses smaller (`--ely-space-3`) elements. Recommendation: token-drive size + gap; cap visible-count to N with overflow indicator if more.

### Q8 (blocking if Option D) — c7a/c7b split point

If Option D is chosen, where does Region A end and Region B start? Recommendation if Option D: c7a covers `<header class="combat-tracker-header">` through the closing `</header>` at line 46 PLUS the brace-badge retoken (F3) PLUS the new `styles/elysium-tracker.css` foundation file. c7b covers the `<ol id="combat-tracker">` through end of file PLUS Section D state accents.

### Q9 — Live-smoke methodology

Tracker state is more involved than chat-card fixture rendering. Recommendation: in the test world, create a combat encounter with 4-6 combatants representing the full state matrix (active GM-controlled / active player-controlled / inactive / defeated / hidden / no-initiative / with-resource / no-resource / with-effects / no-effects), advance through 2-3 rounds, screenshot at each state. Apply rules incrementally and re-screenshot.

### Q10 — Legacy CSS retirement

Cluster 4 retired `.elysium .XPCheck`, cluster 5 retired `.elysium .selectList`. Are there any combat-tracker-related rules in `css/legacy.css` to retire?

**Measured**: zero. `.elysium .combat-input-small` is an actor-sheet input class. `.elysium .quick-combat` is a chat-card class already in v1.0.0 use. No legacy CSS retires under cluster 7.

### Q11 — Class-hook lock list additions

If F3 ships (Options B/C/D), `.elysium-brace-badge` becomes a properly-locked JS-imperative class (currently used as a double-injection guard at `render-combat-tracker.mjs:18`). Add to the audit-5 lock list.

If Option C or D ships, the scoping marker `.elysium-combat-tracker` is CSS-imperative, not JS-imperative, and doesn't need lock status (changing it would break styling but no JS reads it).

---

## 6. Recommendation

### Recommended: **Option B — MINIMAL SHIP (brace-badge retoken only) — folded into P12**

Reasoning:

1. **The P11 mandatory scope is closed.** Chat-card + dialog rebuild — the P11 phase definition — completed at alpha.49. Clusters 6 and 7 were both labeled "optional" in the prep audit. The original choice to make them optional reflected the understanding that the phase's contracted deliverable was already complete.

2. **Option C/D is significant work.** A from-scratch `styles/elysium-tracker.css` build-out comparable to alpha.45's elysium-chat.css would be ~250–350 LOC of new CSS plus template restructuring. That's larger than any single P11 cluster ship (c2's 92-LOC partial was the previous high). The work is meaningfully bigger than cluster 6 was, which was zero-ship by recommendation.

3. **Option B closes the actual anti-pattern.** The brace-badge inline-style + hardcoded `#0066aa` is the same problem cluster 3 retired for the hitloc-tag. Doing it as a P12 polish line item is the right cost/value match. The broader F1 misalignment is real but isn't an anti-pattern — it's an aesthetic gap, and aesthetic gaps are P12 polish work.

4. **The P12 polish pass is the right framing.** P12's backlog already includes `darkred` retoken, `data-handle-change` retirement, lang-completion sweep, cluster-6 island cleanup (1 rgba + 36 px values), and orphaning-driven legacy CSS retirements. The F3 brace-badge retoken fits naturally there. The larger F1 question becomes a P12 sub-decision: "is the combat-tracker scope worth a P12 cluster, or is it acceptance-test deferral?"

5. **Foundry V14 API risk.** F4 noted that the combat-tracker template inherits Foundry's API contract (16 `data-control` values, class family, dispatch model). V14 is an early release; subsequent V14.x releases may change the API surface. Doing a heavy restyle now risks needing rework if V14.x updates the template structure. Letting the combat-tracker styling stabilize before investing in a restyle is defensible.

### If user prefers Option C or D

If the user explicitly wants a full restyle in P11 rather than P12, **Option D (staged)** is preferred over Option C (single ship):
- Smaller per-ship audit + smoke surface
- Audit-then-stop discipline cleaner per sub-cluster
- Visible incremental improvement
- Halt point if c7a surfaces complications

Option C would require a 4–5x larger audit document than this one and a 2–3x larger smoke matrix than any prior P11 cluster. The audit-then-stop discipline still applies per cluster, but the ship's surface area carries more regression risk in a single deployment.

### Decision needed

Per project rule 2, write `proceed with recommended` to commit Option B (brace-badge retoken folds into P12). To change the recommendation, name the option explicitly: `proceed with option C`, `proceed with option D`, `proceed with option A (skip everything)`, or `proceed with option B` (same as recommended).

---

## 7. P12 backlog routing (regardless of decision)

The following P12 backlog items are unchanged by this audit's recommendation. Items added or strengthened by this audit are marked **[c7]**.

| Item | Source | Notes |
|---|---|---|
| `data-handle-change` attribute retirement | cluster-5 | mechanical sweep |
| Lang completion (es-gap=206, fr-gap=206) | cluster-5 ship | translation work |
| `darkred` → `--ely-text-danger` retoken | HANDOFF-state.md | single `css/legacy.css:1384` rule |
| Island cleanup (1 rgba + 36 px values) | cluster-6 audit | mechanical retoken |
| Legacy CSS orphaning retirements | rolling | needs full consumer audit |
| **[c7]** Brace-badge inline-style retirement | this audit F3 | identical to cluster-3 hitloc retoken |
| **[c7]** Deferred 27 inline-HTML ChatMessage.create callsites | P11 prep + this audit | larger polish item |
| **[c7]** Combat-tracker visual misalignment (F1) | this audit | decide P12-cluster vs acceptance-defer |
| Behavioural acceptance testing | rolling | runtime checks of P7–P11 features |

---

## 8. Cross-references

- `docs/p11-prep-audit.md`: cluster 7 originally reserved as "optional combat-tracker cosmetic restyle"
- `docs/p11-cluster3-audit.md`: hitloc-tag inline-style retoken — the methodology template for F3
- `docs/p11-cluster6-audit.md`: cluster 6's parallel evaluate-and-defer pattern
- `module/elysium/hooks/render-combat-tracker.mjs`: F3 target
- `module/elysium/mechanics/engagement-ui.mjs:28-53`: context-menu integration (out of cluster-7 scope per F5)
- `templates/combat/combat-tracker.html`: the template under review

---

## 9. Pre-decision checklist

Before responding `proceed with recommended` (or alternative):

- [ ] Confirm understanding of recommendation: brace-badge retoken folds into P12, broader combat-tracker restyle deferred
- [ ] If choosing C or D instead, confirm appetite for ~250–350 LOC new CSS + larger smoke matrix
- [ ] If choosing C or D, decide Q1/Q2 (marker class name + CSS file location) now or at sub-audit time
