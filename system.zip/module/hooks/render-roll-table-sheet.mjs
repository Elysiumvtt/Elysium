import { ElysiumIDEditor } from '../elysiumid/elysiumid-editor.mjs'
export default function (application, element, context, options) {
  ElysiumIDEditor.addElysiumIDSheetHeaderButton(application, element)
}
