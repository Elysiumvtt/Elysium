// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { modeConstToPresetSheet, promptAttributeKey } from '../shared.mjs'

export function injectItemModifiers (html, item, target) {
    if (target.querySelector('.elysium-modifiers-fieldset')) return

    const aes = item.effects.contents.filter(ae =>
      ae.flags?.['elysium']?.itemModifier === true
    )

    // Build category-grouped optgroups for the presets dropdown
    const categories = Object.keys(ELYSIUM.MODIFIER_CATEGORIES).sort((a, b) =>
      ELYSIUM.MODIFIER_CATEGORIES[a].order - ELYSIUM.MODIFIER_CATEGORIES[b].order
    )
    const optgroups = categories.map(cat => {
      const presets = Object.entries(ELYSIUM.MODIFIER_PRESETS)
        .filter(([k, p]) => p.category === cat)
        .map(([k, p]) => `<option value="${k}">${p.label}</option>`)
        .join('')
      return `<optgroup label="${ELYSIUM.MODIFIER_CATEGORIES[cat].label}">${presets}</optgroup>`
    }).join('')

    // Build rows for existing modifiers
    const rowsHtml = aes.map(ae => {
      const change = ae.changes?.[0] || {}
      const presetKey = ae.flags?.['elysium']?.presetKey
      const preset    = presetKey ? ELYSIUM.MODIFIER_PRESETS[presetKey] : null
      const label     = ae.flags?.['elysium']?.modifierLabel
                     || preset?.label
                     || (change.key || '').split('.').pop()
                     || 'Modifier'
      const value     = change.value ?? '0'
      const mode      = modeConstToPresetSheet(change.mode)
      const isCustom  = !preset
      const keyDisplay = isCustom ? change.key : ''

      return `
        <div class="elysium-modifier-row" data-ae-id="${ae.id}">
          <span class="elysium-modifier-label" title="${change.key || ''}">${label}</span>
          ${isCustom ? `<input type="text" class="elysium-modifier-key" value="${keyDisplay}" placeholder="Attribute Key" data-elysium-mod-key>` : ''}
          <input type="text" class="elysium-modifier-value" value="${value}" data-elysium-mod-value>
          <select class="elysium-modifier-mode" data-elysium-mod-mode>
            <option value="ADD"      ${mode === 'ADD'      ? 'selected' : ''}>Add</option>
            <option value="MULTIPLY" ${mode === 'MULTIPLY' ? 'selected' : ''}>Multiply</option>
            <option value="OVERRIDE" ${mode === 'OVERRIDE' ? 'selected' : ''}>Override</option>
            <option value="UPGRADE"  ${mode === 'UPGRADE'  ? 'selected' : ''}>Upgrade</option>
            <option value="DOWNGRADE"${mode === 'DOWNGRADE'? 'selected' : ''}>Downgrade</option>
          </select>
          <a class="elysium-modifier-remove" data-elysium-mod-remove
             data-tooltip="Remove modifier"><i class="fas fa-times"></i></a>
        </div>
      `
    }).join('')

    // Type-aware legend: "Worn Modifiers" for armor/gear, "Wielded
    // Modifiers" for weapons. Falls back to the generic "Item Modifiers"
    // for unrecognised types.
    const legendKey = item.type === 'weapon'
      ? 'Elysium.Modifiers.WieldedTitle'
      : 'Elysium.Modifiers.Title'
    const fallbackTitle = item.type === 'weapon' ? 'Wielded Modifiers' : 'Worn Modifiers'
    const legend = game.i18n.localize(legendKey) || fallbackTitle

    const fieldsetHtml = `
      <fieldset class="elysium-modifiers-fieldset">
        <legend data-tooltip="${game.i18n.localize('Elysium.Modifiers.Hint')}">
          ${legend}
        </legend>
        <div class="elysium-modifiers-list">
          ${rowsHtml || `<div class="elysium-modifiers-empty">${game.i18n.localize('Elysium.Modifiers.None')}</div>`}
        </div>
        <div class="elysium-modifier-add">
          <select class="elysium-modifier-preset" data-elysium-add-preset>
            <option value="">— Add modifier —</option>
            ${optgroups}
            <optgroup label="Advanced">
              <option value="__custom__">Custom… (free-form Attribute Key)</option>
            </optgroup>
          </select>
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = fieldsetHtml
    const fieldset = wrapper.firstElementChild
    target.appendChild(fieldset)

    // Wire interactions
    wireItemModifiers(fieldset, item)
  }

export async function wireItemModifiers (fieldset, item) {
    // Lazy import to avoid circular dependency.
    // v1.0.0-alpha.11 (side-finding #22): the path was '../active-effects/...'
    // which resolves to 'module/elysium/sheets/active-effects/' (nonexistent).
    // The real file is at 'module/elysium/active-effects/', requiring '../../'.
    const { addItemModifier, updateItemModifier, removeItemModifier } =
      await import('../../active-effects/item-modifiers.mjs')

    // Remove buttons
    fieldset.querySelectorAll('[data-elysium-mod-remove]').forEach(btn => {
      btn.addEventListener('click', async (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        const row = btn.closest('.elysium-modifier-row')
        const aeId = row?.dataset.aeId
        if (!aeId) return
        await removeItemModifier(item, aeId)
      })
    })

    // Value/Mode/Key edits — debounced commit on blur or change
    fieldset.querySelectorAll('.elysium-modifier-row').forEach(row => {
      const aeId = row.dataset.aeId
      if (!aeId) return

      const valueInput = row.querySelector('[data-elysium-mod-value]')
      const modeSelect = row.querySelector('[data-elysium-mod-mode]')
      const keyInput   = row.querySelector('[data-elysium-mod-key]')

      const commit = async () => {
        const changes = {
          value: valueInput?.value ?? '0',
          mode:  modeSelect?.value ?? 'ADD',
        }
        if (keyInput) changes.attributeKey = keyInput.value || null
        await updateItemModifier(item, aeId, changes)
      }

      valueInput?.addEventListener('change', commit)
      modeSelect?.addEventListener('change', commit)
      keyInput?.addEventListener('change', commit)
    })

    // Add modifier dropdown
    const addSelect = fieldset.querySelector('[data-elysium-add-preset]')
    addSelect?.addEventListener('change', async (ev) => {
      const choice = ev.target.value
      if (!choice) return
      ev.target.value = ''    // reset

      if (choice === '__custom__') {
        // Custom: prompt for Attribute Key, then create with Add/0
        const attributeKey = await promptAttributeKey()
        if (!attributeKey) return
        await addItemModifier(item, {
          attributeKey,
          value: 0,
          mode:  'ADD',
          label: attributeKey.split('.').pop(),
        })
      } else {
        await addItemModifier(item, {
          presetKey: choice,
          value:     0,
        })
      }
    })
  }
