/**
 * WoundDataModel — schema for items of type 'wound'.
 *
 * Wounds are short-lived combat-state items created by the damage system
 * (module/combat/damage.mjs and module/elysium/hooks/item.mjs:384). They
 * track a single open wound's remaining damage, treatment status, and the
 * hit-location it sits on.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. No prepareDerivedData override —
 * ElysiumItem.prepareData and damage.mjs continue to manage wound lifecycle.
 *
 * Skips the base template (no description/gmDescription). Per template.json
 * `wound` declares `templates: []`.
 *
 * Field decisions:
 *   - `value` (initial 1, min 0): remaining damage. damage.mjs:223,278,409
 *     and hooks/item.mjs:384 write decremented values during healing.
 *   - `treated` (initial false): flips when medical first-aid succeeds
 *     (damage.mjs:224,408).
 *   - `locId` (StringField initial ''): id of the embedded hit-location item
 *     this wound is on. Read by damage.mjs:_handleWound and apps/check.mjs.
 *   - `created` DROPPED — pre-existing dead field. ZERO reads, ZERO writes
 *     anywhere in source (grep-confirmed against module/, templates/). See
 *     SIDE-FINDING #7 in docs/p6-prep-audit.md.
 */

const fields = foundry.data.fields

export class WoundDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      value:   new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      treated: new fields.BooleanField({ initial: false }),
      locId:   new fields.StringField({ initial: '' }),
    }
  }
}
