import { ElysiumActorItemDrop } from './actor-itemDrop.mjs'
import { ElysiumID } from '../elysiumid/elysiumid.mjs'

export class ElysiumActor extends Actor {

  prepareData() {
    super.prepareData();
  }

  prepareBaseData() {
    super.prepareBaseData();
  }

  prepareDerivedData() {
    // BRP-base prepareDerivedData runs synchronously per Foundry contract.
    // Dispatch to per-type preparation. Both _prepareCharacterData and
    // _prepareNpcData are sync — they never await anything (the awaited
    // operations are in update/create/roll methods elsewhere on this class).
    this._prepareCharacterData(this)
    this._prepareNpcData(this)
  }

  // Prepare Character-specific data
  _prepareCharacterData(actorData) {
    if (actorData.type !== 'character') return;
    const systemData = actorData.system;
    this._prepStats(actorData)
    this._prepDerivedStats(actorData)

    systemData.health.value = systemData.health.max;

    // Initialise power-tab activation flags.
    //
    // v0.8.0: with proper item types (`arcane`, `divine`, `mysticism`)
    // the activation logic is much cleaner — one type-check per tab,
    // no more `power` + `magicSystem` indirection. Skill-based and
    // passion-based triggers remain (a character may have Arcane
    // school skills before learning their first spell).
    //
    //   Arcane:    `arcane` items, Arcane school skills, Form/Technique passions
    //   Sorcery:   `sorcery` items, Sorcery essence skills
    //   Mysticism: `mysticism` items, Focus skill
    //   Divine:    `divine` items, Channeling skill, Faith allegiance
    //   Super, Mutation: native item-type checks
    systemData.arcane    = ''
    systemData.divine    = ''
    systemData.mysticism = ''
    systemData.sorcery   = ''
    systemData.mutation  = ''
    systemData.super     = ''

    for (const itm of actorData.items) {
      // Arcane
      if (!systemData.arcane && itm.type === 'arcane') {
        systemData.arcane = 'on'
      }
      if (!systemData.arcane && itm.type === 'skill' &&
          itm.system?.elysium?.skillSubgroup === 'arcane') {
        systemData.arcane = 'on'
      }
      if (!systemData.arcane && itm.type === 'passion' &&
          itm.system?.elysium?.category === 'arcane') {
        systemData.arcane = 'on'
      }

      // Sorcery
      if (!systemData.sorcery && itm.type === 'sorcery') {
        systemData.sorcery = 'on'
      }
      if (!systemData.sorcery && itm.type === 'skill' &&
          itm.system?.elysium?.skillSubgroup === 'sorcery') {
        systemData.sorcery = 'on'
      }

      // Mysticism
      if (!systemData.mysticism && itm.type === 'mysticism') {
        systemData.mysticism = 'on'
      }
      if (!systemData.mysticism && itm.type === 'skill' &&
          itm.system?.elysium?.skillSubgroup === 'mysticism') {
        systemData.mysticism = 'on'
      }

      // Divine
      if (!systemData.divine && itm.type === 'divine') {
        systemData.divine = 'on'
      }
      if (!systemData.divine && itm.type === 'allegiance' &&
          /faith/i.test(itm.name || '')) {
        systemData.divine = 'on'
      }
      if (!systemData.divine && itm.type === 'skill' &&
          itm.system?.elysium?.skillSubgroup === 'divine') {
        systemData.divine = 'on'
      }

      // Super / Mutation (unchanged)
      if (!systemData.super && itm.type === 'super') {
        systemData.super = 'on'
      }
      if (!systemData.mutation && itm.type === 'mutation') {
        systemData.mutation = 'on'
      }
    }

    //Initialise health statuses and other values
    systemData.dead = false;
    systemData.severed = false;
    systemData.unconscious = false;
    systemData.injured = false;
    systemData.incapacitated = false;
    systemData.bleeding = false
    systemData.enc = 0;
    systemData.av1 = 0;
    // v0.21.0: av2/avr2 (BRP-classic ballistic armor) removed.
    systemData.avr1 = "";
    systemData.psCurr = 0;
    systemData.psMax = 0;

    //Set Hit Location AP to zero
    for (let itm of actorData.items) {
      // v1.0.0-alpha.11 (side-finding #24): skip items in transient
      // construction states (e.g. mid-cascade during ancestry-drop).
      if (!itm.system) continue

      if (itm.type === 'hit-location') {
        itm.system.av1 = 0
        // v0.21.0: itm.system.av2/avr2 (BRP-classic ballistic armor) removed.
        itm.system.avr1 = ""
        itm.system.enc = 0
        itm.system.ppCurr = 0
        itm.system.pSCurr = 0
        itm.system.mnplmod = 0
        itm.system.percmod = 0
        itm.system.physmod = 0
        itm.system.stealthmod = 0
      }
    }

    //Calculate Skill Category Bonuses
    for (let itm of actorData.items) {
      // v1.0.0-alpha.11 (side-finding #24): skip items in transient
      // construction states.
      if (!itm.system) continue
      if (itm.type === 'skillcat') {
        let bonus = 0;
        if (game.settings.get('elysium', 'skillBonus') === "1" && itm.system.stat != 'none') {
          bonus = Math.ceil(systemData.stats[itm.system.stat].total / 2);
        } else if (game.settings.get('elysium', 'skillBonus') === "2") {
          for (let [key, value] of Object.entries(itm.system.attrib)) {
            if (key === 'edu' && true   /* v0.20.0: EDU not used in Elysium */) { continue }

            switch (value) {
              case "0":    //No adjustment
                break;
              case "1":    //Primary
                bonus += this._categoryprimary(systemData.stats[key].total)
                break;
              case "2":    //Secondary
                bonus += this._categorysecondary(systemData.stats[key].total)
                break;
              case "3":    //Negative
                bonus += this._categorynegative(systemData.stats[key].total)
                break;
              case "4":    //Negative Secondary
                bonus += this._categorynegsec(systemData.stats[key].total)
                break;
            }
          }
        }
        itm.system.bonus = bonus
        itm.system.total = itm.system.bonus + itm.system.mod
        // alpha.53 (P12-c3 acceptance F1): defensive guard. Items created
        // programmatically (or from sources lacking ElysiumID metadata) may not
        // have flags.elysium.elysiumidFlag — skip those rather than throwing
        // during prepareData. Was: `const key = itm.flags.elysium.elysiumidFlag.id`
        const key = itm.flags?.elysium?.elysiumidFlag?.id
        if (key) systemData.skillcategory[key] = itm.system.total;
      }
    }
    const effects = actorData.effects.map(i=> {return {origin: i.origin} })
    //Calcualte/adjust scores for items (itm)
    for (let itm of actorData.items) {
      // v1.0.0-alpha.11 (side-finding #24): skip items in transient
      // construction states.
      if (!itm.system) continue

      /*Replaced with code below as not correctly applying to weapons
      //Does the item have transferrable effects
      if (['gear', 'armor', 'weapon','wound'].includes(itm.type)) {
        if (itm.transferredEffects.length > 0) {
          itm.system.hasEffects = true;
        } else {
          itm.system.hasEffects = false;
        }
      }*/

      //Does the item have transferrable effects
      if (['gear', 'armor', 'weapon','wound'].includes(itm.type)) {
          itm.system.hasEffects = false;
        for (let effect of effects) {
          if (effect.origin === itm.uuid) {
            itm.system.hasEffects = true;
          }
        }
      }

      //If skill, arcane or mysticism calculate the total score and record the category bonus
      // v0.8.0: 'magic' → 'arcane', 'psychic' → 'mysticism'. Schema is the same.
      if (itm.type === 'skill' || itm.type === 'arcane' || itm.type === 'mysticism') {
        itm.system.total = itm.system.base + itm.system.xp + itm.system.effects + itm.system.career + itm.system.personality + itm.system.personal + itm.system.culture
        itm.system.catBonus = systemData.skillcategory[itm.system.category]

        //If Allegiance the set total and potential Ally status
      } else if (itm.type === 'allegiance') {
        itm.system.total = itm.system.allegPoints + itm.system.xp
        itm.system.potAlly = false

        //If Passion the set total
      } else if (itm.type === 'passion') {
        itm.system.total = itm.system.base + itm.system.xp

        //If Personality Trait the set total
      } else if (itm.type === 'persTrait') {
        itm.system.total = Math.max(0, Math.min(100, itm.system.base + itm.system.xp))
        itm.system.opptotal = 100 - itm.system.total

        //If Reputation set total
      } else if (itm.type === 'reputation') {
        itm.system.total = itm.system.base

        //If gear/weapon, calculates the encumbrance
      } else if (['gear', 'weapon'].includes(itm.type)) {
        if (itm.system.equipStatus === 'equipped') {
          itm.system.actlEnc = itm.system.quantity * itm.system.enc
          systemData.enc = Number(systemData.enc + itm.system.actlEnc)
        } else { itm.system.actlEnc = 0 }

        if (itm.system.equipStatus !== 'stowed') {
          if (itm.system.pSCurr > 0) { systemData.psCurr = systemData.psCurr + itm.system.pSCurr }
          if (itm.system.pSMax > 0) { systemData.psMax = systemData.psMax + itm.system.pSMax }
        }

        //If armor
      } else if (itm.type === 'armor') {
        //Calc encumbrance based on carry status and if using HPL
        itm.system.actlEnc = 0
        if (itm.system.equipStatus === 'equipped') {
          // v1.0.0-alpha.11 (side-finding #24 extension): guard the hitLoc
          // lookup. An equipped armor with an empty/invalid hitlocID would
          // otherwise throw on the undefined access. Pre-existing latent
          // bug exposed by compendium-drop testing.
          const hitLoc = actorData.items.get(itm.system.hitlocID)
          if (hitLoc?.system) {
            itm.system.actlEnc = Math.round(itm.system.quantity * itm.system.enc / hitLoc.system.fractionENC * 10) / 10
          }
          //If not equipped then zero ENC
        }
        systemData.enc = systemData.enc + itm.system.actlEnc
        if (itm.system.equipStatus !== 'stowed') {
          if (itm.system.pSCurr > 0) { systemData.psCurr = systemData.psCurr + itm.system.pSCurr }
          if (itm.system.pSMax > 0) { systemData.psMax = systemData.psMax + itm.system.pSMax }

            const hitLoc = actorData.items.get(itm.system.hitlocID)
            if (hitLoc?.system) {
              hitLoc.system.ppCurr += itm.system.ppCurr
              hitLoc.system.pSCurr += Number(itm.system.pSCurr)
            }

        }

        //Add the Armor Point Score to the Hit Location if equipped
        if (itm.system.equipStatus === 'equipped') {

            const hitLoc = actorData.items.get(itm.system.hitlocID)
            if (hitLoc?.system) {
              hitLoc.system.av1 += itm.system.av1
              hitLoc.system.mnplmod += itm.system.mnplmod
              hitLoc.system.percmod += itm.system.percmod
              hitLoc.system.physmod += itm.system.physmod
              hitLoc.system.stealthmod += itm.system.stealthmod
              // v0.21.0: av2/avr2 (BRP-classic ballistic armor) accumulation removed.
              if (itm.system.avr1 != "") {
                hitLoc.system.avr1 += "+" + itm.system.avr1
              }
            }

        }

          // v1.0.0-alpha.11 (side-finding #24 extension): this branch was
          // previously unguarded and ran regardless of equipStatus, so a
          // stowed armor with empty hitlocID would crash prep.
          const hitLoc = actorData.items.get(itm.system.hitlocID)
          if (hitLoc?.system) {
            hitLoc.system.enc += itm.system.actlEnc
          }

        // v0.8.0: removed legacy `power`-type record-ID block. BRP used
        // a single `power` item with system.category to identify the
        // character's primary power tradition, recorded in systemData.magic
        // (or .psychic / .sorcery / etc.) so templates could link to it.
        // In Elysium each tradition is its own tab activated by item
        // presence — no central "primary power" record needed. The
        // power-list display on the Statistics tab now hides entries
        // whose flag is empty rather than expecting an item ID.
      } else if (itm.type === 'career') {
        systemData.career = itm.name
        systemData.careerId = itm._id;
        // v0.22.0-alpha.5: hit-location HP and most condition state is owned
        // by mythras-hp.mjs (maxHP) + hit-loc-state.mjs (currHP, injured,
        // incapacitated, unconscious, flat-HP pool). Both run after this
        // prep via the prepareDerivedData wrapper.
        //
        // Only the per-location → actor cascade for flags that hit-loc-state
        // does NOT own (bleeding, severed, dead) remains here. These flags
        // are written by the damage flow (damage.mjs at crit thresholds) and
        // are not derived from currHP — they survive across prep cycles
        // until explicitly cleared (by healing/treatment).
      } else if (itm.type === 'hit-location') {
        if (itm.system.bleeding) { systemData.bleeding = true }
        if (itm.system.severed) { systemData.severed = true }
        if (itm.system.dead) { systemData.dead = true }
      }
      // v0.22.0-alpha.5: wound-item flat-HP decrement removed. hit-loc-state
      // sums wound damage across all locations and writes
      // actor.system.health.value = health.max - totalDamage after its loop.

    }

    //Calculate allegiance target
    const allegiances = actorData.items.filter(itm => itm.type === 'allegiance')
    allegiances.sort(function (a, b) {
      const x = a.system.total;
      const y = b.system.total;
      if (x < y) { return 1 };
      if (x > y) { return -1 };
      return 0;
    });
    //If there is one allegiance
    const ally = ""
    if (allegiances.length === 1 && allegiances[0].system.total >= 20) {
      actorData.items.get(allegiances[0]._id).system.potAlly = true
    } else if (allegiances.length > 1 && (allegiances[0].system.total - allegiances[1].system.total) >= 20) {
      actorData.items.get(allegiances[0]._id).system.potAlly = true
    }

    //Round ENC to 2 decimals
    systemData.enc = (systemData.enc).toFixed(2)
    // v0.20.0: BRP-classic fatigue.max calculation removed. Elysium uses the
    // Mythras fatigue ladder (system.fatigue.level / .label / .recoveryType)
    // exclusively; the flat value/max pool was double-bookkeeping.

    //v0.22.0: removed flat-health dead/unconscious thresholds.
    // Under Elysium's Mythras per-location wound model, unconsciousness
    // and death come from specific critical hits (head/chest at 0 or
    // below, or wound damage >= maxHP * 3 for non-limbs), not from
    // accumulated flat damage across all locations. The
    // `if (systemData.health.value < 3) unconscious = true` /
    // `if (< 1) dead = true` thresholds were BRP-classic semantics
    // that don't match the per-location wound model and were causing
    // characters to be flagged unconscious/dead by aggregate minor
    // damage when no single location was critical.

  }

  // Prepare NPC-specific data
  _prepareNpcData(actorData) {
    if (actorData.type !== 'npc') return;
    const systemData = actorData.system;
    this._prepStats(actorData)
    this._prepDerivedStats(actorData)

    for (let [key, stat] of Object.entries(actorData.system.baseStats)) {
      stat.label = game.i18n.localize(CONFIG.Elysium.stats[key]) ?? key;
      stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
      // Mark all stats as visible. EDU is hidden in Elysium (v0.20.0).
      stat.visible = key !== 'edu'
    }

    // v0.22.0-alpha.5: NPC hit-location maxHP is owned by mythras-hp.mjs;
    // currHP, condition flags, and the flat-HP pool are owned by
    // hit-loc-state.mjs. Both run after this prep via the prepareDerivedData
    // wrapper. No actor-type branching: both characters and NPCs use the
    // same wound-item model.

    for (let itm of actorData.items) {
      // v1.0.0-alpha.11 (side-finding #24): skip items in transient
      // construction states.
      if (!itm.system) continue
      // v0.8.0: 'magic' → 'arcane', 'psychic' → 'mysticism'.
      if (['skill', 'arcane', 'mysticism', 'passion', 'reputation'].includes(itm.type)) {
        itm.system.total = itm.system.base + (itm.system.effects ?? 0);
      } else if (['allegiance'].includes(itm.type)) {
        itm.system.total = itm.system.allegPoints;
      } else if (['persTrait'].includes(itm.type)) {
        itm.system.total = itm.system.base;
        itm.system.opptotal = 100 - itm.system.base;
      }
      // hit-location is fully owned by MythrasHP; no per-iteration work here
    }
  }

  getRollData() {
    const data = super.getRollData();

    // Prepare character roll data.
    this._getCharacterRollData(data);
    this._getNpcRollData(data);

    return data;
  }

  // Prepare character roll data.
  _getCharacterRollData(data) {
    if (this.type !== 'character') return;

    // Copy the ability scores to the top level
    if (data.stats) {
      for (let [k, v] of Object.entries(data.stats)) {
        data[k] = foundry.utils.deepClone(v);
      }
    }
  }

  // Prepare NPC roll data
  _getNpcRollData(data) {
    if (this.type !== 'npc') return;
  }

  //Prepare Stats
  _prepStats(actorData) {
    // Loop through ability scores, calculating total and derived scores
    actorData.system.redistInc = 0
    actorData.system.redistDec = 0
    for (let [key, stat] of Object.entries(actorData.system.stats)) {
      stat.label = game.i18n.localize(CONFIG.Elysium.stats[key]) ?? key;
      stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
      stat.labelDeriv = game.i18n.localize(CONFIG.Elysium.statsDerived[key]) ?? key;
      stat.total = Number(stat.base) + Number(stat.redist) + Number(stat.culture) + Number(stat.exp) + Number(stat.effects) + Number(stat.age);
      stat.deriv = stat.total * 5;
      if (stat.redist < 0) { actorData.system.redistDec = actorData.system.redistDec + stat.redist }
      if (stat.redist > 0) { actorData.system.redistInc = actorData.system.redistInc + stat.redist }

      // Mark all stats as visible. EDU is hidden in Elysium (v0.20.0).
      stat.visible = key !== 'edu'
    }
    if (actorData.type === 'npc') {
      for (let [key, stat] of Object.entries(actorData.system.baseStats)) {
        stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
        // Mark all stats as visible. EDU is hidden in Elysium (v0.20.0).
        stat.visible = key !== 'edu'
      }
    }
    actorData.system.redistTotal = actorData.system.redistInc + actorData.system.redistDec
  }

  // Calculate derived scores
  _prepDerivedStats(actorData) {
    const systemData = actorData.system
    if (actorData.type === 'character') {
      // v0.20.0: hpMod setting removed (Elysium uses hpMultiplier instead,
      // applied per-location by the Mythras HP override). This BRP-style
      // total HP baseline is overridden by ElysiumMythrasHP.applyToActor
      // in prepareDerivedData; the formula here is only a stub.
      systemData.health.max = Math.ceil((systemData.stats.con.total + systemData.stats.siz.total) / 2) + systemData.health.mod + (systemData.health.effects ?? 0);
    } else {
      let health = 0
      let formula = ""
      let statCount = 0
      if (systemData.hp.stat1 != 'none') {
        health += systemData.stats[systemData.hp.stat1].total
        statCount++
        formula = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[systemData.hp.stat1])
      }
      if (systemData.hp.stat2 != 'none') {
        health += systemData.stats[systemData.hp.stat2].total
        statCount++
        if (statCount === 2) { formula = formula + " + " }
        formula = formula + game.i18n.localize(CONFIG.Elysium.statsAbbreviations[systemData.hp.stat2])
      }
      health = Math.ceil(health * systemData.hp.multi)
      if (statCount === 1) {
        formula = "(" + formula + " * " + systemData.hp.multi + ")"
      } else if (statCount === 2) {
        formula = "((" + formula + ") * " + systemData.hp.multi + ")"
      }
      if (systemData.health.mod < 0) {
        formula = formula + " " + systemData.health.mod
      } else if (systemData.health.mod > 0) {
        formula = formula + " + " + systemData.health.mod
      }
      systemData.hp.formula = formula
      systemData.health.max = health + (systemData.health.mod ?? 0) + (systemData.health.effects ?? 0);
    }
    systemData.health.mjrwnd = Math.ceil(systemData.health.max / 2);
    systemData.power.max = systemData.stats.pow.total + systemData.power.mod + (systemData.power.effects ?? 0);
    systemData.xpBonus = Math.ceil(systemData.stats.int.total / 2);
    // v0.20.0: Elysium uses the Mythras damage modifier table via
    // system.dmgmodTier (a dice expression like '+1d6'). Per-weapon
    // scaling is via weapon.system.elysium.damageBonusMultiplier.
    // The old BRP dmgBonus/dmgSpecBonus tri-output is gone.

    // Resource labels — v0.20.0: fixed Elysium terminology, no per-resource
    // label-override settings. The Ancestry relabel module handles the
    // Culture/Ancestry/Race/Species swap; other labels are localization-only.
    // Note: system.fatigue.label/labelAbbr are NOT set here — those fields
    // are owned by the Elysium fatigue manager (Mythras ladder), which writes
    // the current level's label ("Fresh", "Winded", "Tired", ...) instead.
    systemData.power.label        = game.i18n.localize('Elysium.pp')
    systemData.power.labelAbbr    = game.i18n.localize('Elysium.ppShort')
    systemData.health.label       = game.i18n.localize('Elysium.health')
    systemData.health.labelAbbr   = game.i18n.localize('Elysium.hp')
    systemData.sanity.label       = game.i18n.localize('Elysium.sanity')
    systemData.sanity.labelAbbr   = game.i18n.localize('Elysium.san')
    systemData.sanity.labelLoss   = game.i18n.localize('Elysium.sanLoss')
    systemData.res5.label         = game.i18n.localize('Elysium.res5')
    systemData.res5.labelAbbr     = game.i18n.localize('Elysium.res5Abbr')
  }

  //Used for Rolling NPCs when token dropped
  get hasRollableCharacteristics() {
    for (const [, value] of Object.entries(this.system.baseStats)) {
      if (isNaN(Number(value.random))) return true
      if (isNaN(Number(value.average))) return true
    }
    return false
  }

  //Roll Random Stats
  async rollCharacteristicsValue() {
    const stats = {}
    for (const [key, value] of Object.entries(this.system.baseStats)) {
      if (value.random && !value.random.startsWith('@')) {
        const r = new Roll(value.random)
        await r.evaluate()
        if (r.total) {
          stats[`system.stats.${key}.base`] = Math.floor(
            r.total
          )
        }
      }
    }
    await this.update(stats)
    await this.updateVitals()
  }

  //Roll Average Stats
  async averageCharacteristicsValue() {
    const stats = {}
    for (const [key, value] of Object.entries(this.system.baseStats)) {
      if (value.average && !value.average.startsWith('@')) {
        const r = new Roll(value.average)
        await r.evaluate()
        if (r.total) {
          stats[`system.stats.${key}.base`] = Math.floor(
            r.total
          )
        }
      }
    }
    await this.update(stats)
    await this.updateVitals()
  }

  //Update Current HP, etc. when Rolled or Average Roll
  // v0.20.0: system.fatigue.value/max removed from this update — Elysium uses
  // the Mythras fatigue ladder (level/label) which has no value/max pool.
  async updateVitals() {
    const checkProp = {
      'system.health.value': this.system.health.max,
      'system.power.value': this.system.power.max,
      'system.sanity.value': this.system.sanity.max
    }
    await this.update(checkProp)
    
      const hitLocs = this.items.filter(itm => itm.type === 'hit-location').map(itm => {
        return { _id: itm.id, 'system.currHP': itm.system.maxHP }
      })
      await Item.updateDocuments(hitLocs, { parent: this })
    
  }

  //Create a new actor - When creating an actor set basics including tokenlink, bars, displays sight
  static async create(data, options = {}) {
    //If dropping from compendium check to see if the actor already exists in game.actors and if it does then get the game.actors details rather than create a copy
    if (options.fromCompendium) {
      const tempActor = await (game.actors.filter(actr => actr.flags?.elysium?.elysiumidFlag?.id === data.flags?.elysium?.elysiumidFlag?.id && actr.flags?.elysium?.elysiumidFlag?.priority === data.flags?.elysium?.elysiumidFlag?.priority))[0]
      if (tempActor) { return tempActor }
    }

    if (data.type === 'character') {
      data.prototypeToken = foundry.utils.mergeObject({
        actorLink: true,
        lockRotation: true,
        disposition: 1,
        displayName: CONST.TOKEN_DISPLAY_MODES.ALWAYS,
        displayBars: CONST.TOKEN_DISPLAY_MODES.ALWAYS,
        sight: {
          enabled: true,
          range: 30,
          visionMode:"basic"
        }
      }, data.prototypeToken || {})
    } else if (data.type === 'npc') {
      data.prototypeToken = foundry.utils.mergeObject({
        lockRotation: true,
        sight: {
          enabled: true,
          range: 30,
          visionMode:"basic"
        }
      }, data.prototypeToken || {})
    }

    const actor = await super.create(data, options)

    // v0.20.0: actorElysiumID auto-assign removed. Players who want a ElysiumID on
    // a new actor can set it via the ElysiumID editor on the actor sheet header.

    //Set up a general hit location for a new actor (per-location HP is core)
    if (actor.type === 'character') {
      const elysiumid = "i.hit-location.general"

      const itemData = [{
        name: game.i18n.localize('Elysium.general'),
        type: 'hit-location',
        img: 'systems/elysium/assets/Icons/arm-bandage.svg',
        flags: { elysium: { elysiumidFlag: { id: "i.hit-location.general" } } },
        system: {
          "fractionHP": 1,
          "fractionENC": 1,
          "lowRoll": 0,
          "highRoll": 0,
          "locType": "general"
        }
      }];
      const newItem = await Item.createDocuments(itemData, { parent: actor });
    }

    // v0.20.0: starterSkills / starterTraits onboarding removed. Elysium
    // character creation uses the ancestry/culture/career drop flow,
    // which seeds skills and traits structurally. BRP's flat-list bulk
    // import doesn't fit Elysium's package-based onboarding.

    //Add Skill Categories
    if (actor.type === 'character') {
      const newSkillCats = []
      const skillCatList = (await game.system.api.elysiumid.fromElysiumIDRegexBest({ elysiumidRegExp: new RegExp('^i.skillcat'), type: 'i' }))
      for (let itm of skillCatList) {
        if (actor.items.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === itm.flags.elysium.elysiumidFlag.id).length < 1) {
          newSkillCats.push(itm)
        }
      }
      await Item.createDocuments(newSkillCats, { parent: actor })
    }
    return actor
  }

  //Recalculate all skill base scores
  static async charBaseSkillScores(actor) {
    const change = []
    for (let itm of actor.items) {
      if (itm.type != 'skill') { continue }
      const baseScore = await ElysiumActorItemDrop._calcBase(itm, actor)
      change.push({ _id: itm._id, "system.base": baseScore })
    }
    await Item.updateDocuments(change, { parent: actor })
  }

  // Primary Skills Bonus
  _categoryprimary(statvalue) {
    var bonus = statvalue - 10;
    return bonus;
  }

  // Secondary Skills Bonus
  _categorysecondary(statvalue) {
    var bonus = (statvalue - 10) / 2
    if (bonus < 0) {
      bonus = Math.ceil(bonus);
    } else {
      bonus = Math.floor(bonus);
    }
    return bonus;
  }

  // Negative Skills Bonus
  _categorynegative(statvalue) {
    var bonus = 10 - statvalue;
    return bonus;
  }

  // Negative Secondary Skills Bonus
  _categorynegsec(statvalue) {
    var bonus = (10 - statvalue) / 2
    if (bonus < 0) {
      bonus = Math.ceil(bonus);
    } else {
      bonus = Math.floor(bonus);
    }
    return bonus;
  }

  //Damage Bonus
  //
  // v0.20.0: deleted. The BRP curve (half/full/dbl based on STR+SIZ) is
  // replaced by the Mythras DAMAGE_MOD_TABLE via system.dmgmodTier (set
  // by ElysiumActorExtension.calculateDamageModifier in the elysium
  // subsystem). Per-weapon scaling: weapon.system.elysium.damageBonusMultiplier.
}
