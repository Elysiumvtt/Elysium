# CHANGE LOG

---

> **Project transition point — 2026-05-12**
>
> v0.22.0 is the **final release on the BRP-era architecture**. The 0.x series carried the system from its initial fork through a 23-release cycle of rules expansion, code cleanup, mechanic additions, and content tuning. It is feature-complete for what it was — a Mythras-flavored fork of the BRP Foundry system with Elysium-specific rules layered on top.
>
> Development now moves to the **v1.0.0 Elysium rebuild** — a full presentation-layer rebuild, DataModel migration (Foundry V14→V16 prep), and identity rename ("Elysium BRP" → "Elysium"). This is a fork-declaring-its-own-identity release, not an incremental update. Backward compatibility is **not preserved** — `system.id` changes, i18n namespace changes, CSS prefix changes, and template structure is rebuilt from scratch.
>
> Roadmap: see `ROADMAP-v1.0.0.md` for the 12-phase plan and progress log.
>
> The 0.22.0 release will remain available as a final BRP-era reference; users wanting to keep the BRP-flavored system can pin to 0.22.0 indefinitely.

---

---

## [1.1.0] — 2026-05-16 — v1.1.0 c1 (Identity Hygiene Cluster)

**First v1.1.0 cluster ship.** Inherits the v1.0.0 audit-then-fix methodology. Pre-flight scope-locked via `docs/v1.1.0-c1-audit.md` before any code change; companion audit at `docs/v1.1.0-compendium-ip-audit.md` documents the parallel compendium IP review.

### Scope decision

c1 addresses the **half-renamed BRP→Elysium identity** the v1.0.0 P4 narrative claimed was complete. Live grep of v1.0.0 final disagreed with the "0 remaining BRP* identifiers" P4 claim: 159 .mjs/.js references plus 39 user-facing lang strings plus 270 ChaosiumCanvasInterface references plus a previously-undetected entire CCI subsystem (9 files, ~700 LOC). User direction selected the full rename scope: Category B (BRP-ID comments) + Category C (live JS identifiers) + Category D (data flags + settings + lang) + full CCI subsystem rename + Category A (historical-comment "BRP-base" rephrasing where ambiguity warrants).

### Methodology validation — audit-then-fix caught a wrong premise mid-flight

The c1 scope-lock decision originally framed `ChaosiumCanvasInterface` as a lang-keys-only namespace residue. The "verify user-facing claims at runtime before writing them" methodology rule (inherited from v1.0.0 rc.7) caught the premise as wrong during the audit-doc write: CCI is a live 9-file region-behavior subsystem with persisted world-data type-name implications, not orphan lang keys. The escalation produced a corrected scope decision (full CCI rename in c1) before any code touch. **The methodology paid off again.**

### Findings inventory at c1 ship

| ID | Category | Severity | What was fixed |
|---|---|---|---|
| **c1.F1** | D | High | `flags.brp.hide-background` → `flags.elysium.hide-background` (note-config hide-background flag) |
| **c1.F2** | D + silent bug | Medium | `localize('BRP.mapNoteNoBackground')` was a pre-existing latent bug — no `BRP.*` lang namespace exists (P4 merged it), call returned raw key string as fallback. Users saw literal "BRP.mapNoteNoBackground" as the label. Fixed by pointing at the existing `Elysium.mapNoteNoBackground` key. **Silent pre-c1 bug.** |
| **c1.F3** | D | Low | `itemBRPID` setting renamed → `itemElysiumID` (settings registry + item.mjs consumer + elysiumid-settings.hbs) |
| **c1.F4** | D | Low | `firstAidBRPID` setting renamed → `firstAidElysiumID` (settings registry + 2 check.mjs consumer refs + elysiumid-settings.hbs comment) |
| **c1.F5** | D | Low | `brpIconPrimary` setting renamed → `iconPrimary` (drop prefix entirely; settings registry + 2 character.mjs consumers + 3 display-settings.hbs refs + 6 lang keys) |
| **c1.F6** | D + lang | Low | 31 user-facing English/Spanish/French "BRPID" / "BRP-ID" strings updated to "ElysiumID". Also fixed a pre-existing `es.json` typo `"Opcione"` → `"Opciones"` |
| **c1.F7** | C | Low | `editBRPid` action + `_onEditBRPid` method renamed → `editElysiumID` / `_onEditElysiumID` (V14 action router; 2 base-sheet classes × 3 sites each = 6 sites) |
| **c1.F8** | C | Low | `_BRPonDropItemCreate` static method renamed → `_onDropItemCreate` (definition + 1 caller in base-actor-sheet); the method scope is `ElysiumActorItemDrop` so no prefix needed |
| **c1.F9** | C | Trivial | `addBRPIDSheetHeaderButton` callers renamed → `addElysiumIDSheetHeaderButton` (2 hook files; definition was already renamed by P4) |
| **c1.F10** | C | Trivial | `brpAE` local variable renamed → `legacyAE` (4 refs in elysium-active-effect-sheet.mjs; more descriptive than ElysiumAE since the variable holds a pre-rebuild legacy AE being upgraded) |
| **c1.F11** | C | Low | Foundry control / canvas-layer / tool internal names: `brpmenu` → `elysiummenu`, `brpgmtools` → `elysiumgmtools`, `brpdummy` → `elysiumdummy` (setup/menu.mjs + setup/layers.mjs + render-scene-controls.mjs; 17 sites total) |
| **c1.F12** | C | Trivial | Stale `// ID 20: BRP Creatures` placeholder comment retired at elysiumid.mjs L1 |
| **c1.F13** | C | Trivial | `Elysium BRP — system entry point.` header → `Elysium — system entry point.` in main.mjs |
| **c1.F14** | C + silent bug | Trivial | Rename-script artifact in elysiumid.mjs comment "renamed from 'elysium' to 'elysium'" corrected to "renamed from 'elysium-brp' to 'elysium'" — was a double-substitution casualty of P4's regex pass |
| **c1.F15** | B | Trivial | 9 "BRP-ID" references in active code comments renamed → "ElysiumID" (actor-itemDrop.mjs ×4, actor.mjs ×1, character.mjs ×2, career.mjs ×2) |
| **c1.F16** | CCI | Medium | **Full ChaosiumCanvasInterface subsystem rename → ElysiumCanvasInterface.** 9 .mjs files renamed on disk (`chaosium-canvas-interface*.mjs` → `elysium-canvas-interface*.mjs`); 8 class names renamed (base + 7 subclasses + Init); module/hooks/init.mjs updated (import path + 2 static accessors + init call + docstring); system.json `RegionBehavior` type registry (7 entries renamed); 24 lang keys × 3 locales = 72 lang keys renamed under `Elysium.Settings.*` and `Elysium.ElysiumCanvasInterface.*` namespaces; 21 user-facing labels updated from "CCI: ..." prefix to "ECI: ..." prefix to match the new abbreviation expansion |
| **c1.F17** | A | n/a | ~40 historical-context comments updated from "BRP" → "BRP-base" where the meaning is clearer (refers to the upstream Foundry BRP module the project forks, vs. generic BRP-family references). "BRP-classic" references (already disambiguated) and version-history notes (e.g. `v0.20.0: BRP-classic foo removed`) left intact. Categorical preservation of accurate technical archaeology |

### CCI rename special handling — persisted world-data implication

The CCI subclass names are registered into `CONFIG.RegionBehavior.dataModels` keyed on `constructor.name`. RegionBehavior documents in any existing world reference these names as the `type` field. After c1, existing RegionBehaviors of types `ChaosiumCanvasInterface*` fail validation on load.

**Acceptable per the v1.0.0 "no backward compatibility" policy** (locked at project start; documented in ROADMAP-v1.0.0.md scope decisions). v1.0.0 shipped 2026-05-15 — any user worlds containing CCI Region Behaviors have ~24 hours of existence at c1 ship time. A one-time fresh-world recreate is the documented migration path.

User-facing labels were updated from "CCI:" prefix to "ECI:" prefix in all 21 setting-button labels across en/es/fr because the abbreviation expanded from **C**haosium**C**anvas**I**nterface to **E**lysium**C**anvas**I**nterface; preserving "CCI" would have left the user-facing abbreviation orphaned from its meaning.

### Honest behavioural impact

**For all users on v1.0.0**:
- The `flags.brp.hide-background` flag on map notes is no longer read (1 map-pin flag; affects only notes where the GM explicitly set the hide-background toggle)
- World settings under names `itemBRPID` / `firstAidBRPID` / `brpIconPrimary` revert to defaults (lose their values)
- Existing scenes with `ChaosiumCanvasInterface*` RegionBehaviors fail to load; recreate as `ElysiumCanvasInterface*`
- The `BRP.mapNoteNoBackground` label was already showing the raw key string in the UI; now it shows the proper localized text — a visible improvement

**For all users on v1.0.0, no impact**:
- Compendium content (unchanged; separate audit found no Chaosium-publication content lifts to fix — see `docs/v1.1.0-compendium-ip-audit.md`)
- Character sheet rendering, rolls, combat, magic, character data, drag-drop flows — none of these surfaces touched by c1
- Existing actor/item flag data — only the one map-note `flags.brp.*` namespace was affected

**For new world creation**: no impact; rename is transparent.

### Ship contents

| File | Change category | Notes |
|---|---|---|
| `module/hooks/render-note-config.js` | D | flags.brp → flags.elysium; BRP.mapNoteNoBackground → Elysium.mapNoteNoBackground; expanded retirement comment documents the silent bug fix |
| `module/settings/settings-elysiumid.mjs` | D | 2 setting keys renamed (itemBRPID, firstAidBRPID) |
| `module/settings/settings-display.mjs` | D | 1 setting key renamed (brpIconPrimary → iconPrimary, plus lang refs) |
| `module/item/item.mjs` | D | 1 consumer of itemBRPID |
| `module/apps/check.mjs` | D | 2 consumers of firstAidBRPID |
| `module/actor/sheets/character.mjs` | D + B | 2 consumers of brpIconPrimary; 2 BRP-ID comments rephrased |
| `templates/settings/elysiumid-settings.hbs` | D | 2 setting-key refs renamed + 1 comment update |
| `templates/settings/display-settings.hbs` | D | 3 brpIconPrimary refs renamed |
| `lang/en.json` | D + CCI lang | brpIconPrimary→iconPrimary; 13 user-facing "BRPID" strings → "ElysiumID"; 8 ChaosiumCanvasInterface keys → ElysiumCanvasInterface; 7 "CCI:" labels → "ECI:" |
| `lang/es.json` | D + CCI lang | Same as en + Opcione typo fix |
| `lang/fr.json` | D + CCI lang | Same as en (no typo fixes needed) |
| `module/actor/sheets/base-actor-sheet.mjs` | C | editBRPid → editElysiumID (3 sites); _BRPonDropItemCreate caller updated |
| `module/item/sheets/base-item-sheet.mjs` | C | editBRPid → editElysiumID (3 sites) |
| `module/actor/actor-itemDrop.mjs` | C + B | _BRPonDropItemCreate → _onDropItemCreate definition; 4 BRP-ID comments rephrased; retirement-comment block documents the renames |
| `module/hooks/render-journal-entry-sheet.mjs` | C | addBRPIDSheetHeaderButton caller updated |
| `module/hooks/render-roll-table-sheet.mjs` | C | addBRPIDSheetHeaderButton caller updated |
| `module/sheets/elysium-active-effect-sheet.mjs` | C | brpAE → legacyAE (4 refs); retirement-comment block |
| `module/setup/menu.mjs` | C | brpmenu/brpgmtools/brpdummy → elysium* (12 sites) |
| `module/setup/layers.mjs` | C | brpmenu/brpgmtools → elysium* (4 sites) |
| `module/hooks/render-scene-controls.mjs` | C | brpdummy selector renamed |
| `module/elysiumid/elysiumid.mjs` | C + B | Stale "ID 20: BRP Creatures" retired; rename-script artifact corrected; BRP-ID comment rephrased |
| `module/main.mjs` | C | Header "Elysium BRP — system entry point." → "Elysium — system entry point." |
| `module/actor/actor.mjs` | B + A | 1 BRP-ID comment rephrased; 1 Cat A "BRP's prepareDerivedData" → "BRP-base prepareDerivedData" |
| `module/item/sheets/career.mjs` | B | 2 BRP-ID comments rephrased |
| `module/hooks/init.mjs` | CCI + A | CCI import + class refs renamed; docstring header updated |
| `system.json` | CCI + version | RegionBehavior type registry (7 entries); version 1.0.0 → 1.1.0 |
| `module/apps/chaosium-canvas-interface*.mjs` (×9) | CCI | **Renamed on disk** to `elysium-canvas-interface*.mjs` + class names + import paths + lang-key strings inside the code |
| 18 other .mjs files | A | ~40 historical-context comments rephrased BRP → BRP-base where ambiguity warrants |

**Total surface**: 38 .mjs/.js/.hbs/.json files touched (plus 9 file renames on disk + 1 file deletion via rename); 3 .json lang files updated; 0 CSS changes; 0 template structural changes; 0 new assets.

### c1 follow-up — system.json repo-URL hygiene + paired compendium v1.1.0 release

After the c1 ship, a verification pass on the compendium-side surfaced two additional stale-identity surfaces inside the system manifest itself:

- `system.json` L236-241: `url`, `manifest`, `download`, `readme`, `bugs`, `changelog` all pointed at `https://github.com/Elysiumvtt/ElysiumBRP/...` — stale repo URLs from before the v1.0.0 identity rename. Updated all 6 to `https://github.com/Elysiumvtt/Elysium/...`. This is the URL Foundry uses to update-check the system; users would have been pulling future releases from the wrong (potentially-defunct) repo path.

In parallel, a **paired compendium v1.1.0 release** was prepared addressing identity-hygiene surfaces in the companion `elysium-compendium` module:

- Compendium `.db` pack files verified clean (zero BRP identifier residue across all 22 packs); no content migration needed
- Compendium `module.json` description, version (`1.0.0-alpha.3` → `1.1.0`), and system-compat range (`0.20.0` → `1.1.0`) updated for v1.1.0 pairing
- Compendium `README.md` rewritten: stale "ElysiumBRP system fork + Elysium rules module" two-component description replaced with the current single-system reality; false "standalone with stock BRP" claim deleted (75 of 99 sampled entries depend on Elysium-specific `system.elysium.*` fields)
- Compendium `CREDITS.md` upstream-authors attribution preserved exactly as-is, pending separate legal/license review

See compendium-side `CHANGELOG.md` `[1.1.0]` entry for full detail.

### Pre-flight gate — clean

- All 38 touched .mjs files + all 9 renamed CCI files parse via `node --check` (47/47 OK)
- system.json + all 3 lang/*.json parse via `python3 -m json.tool` (4/4 OK)
- Exhaustive grep for `BRPID|BRPid|editBRPid|_BRPon|_onEditBRPid|addBRPIDSheetHeaderButton|brpIconPrimary|brpmenu|brpgmtools|brpdummy|brpAE|itemBRPID|firstAidBRPID` in source: **2 hits**, both inside retirement-comment lines documenting the renames (intentional preservation)
- Exhaustive grep for `flags\.brp\.|flags\?\.brp\.`: **1 hit**, inside the render-note-config.js retirement comment (intentional preservation; live code uses `flags.elysium.*`)
- Exhaustive grep for `BRP-ID` in code comments: **0 hits**
- Exhaustive grep for `ChaosiumCanvasInterface|chaosium-canvas-interface|Chaosium` in source/system.json/lang: **0 hits**
- No `chaosium-canvas-interface*.mjs` files remain on disk (9 renamed, 0 left)
- Lang structural-gap unchanged (en=1347 / es=1351 / fr=1351 — exact match with v1.0.0-rc.7 ship state; the 4-key gap is pre-existing legacy state, c1 did not widen it)
- Category A "BRP" historical refs preserved where genuinely accurate (`BRP-classic`, `v0.X.0:` version-history notes, i18n-namespace name refs)
- Version: `1.0.0` → `1.1.0` in system.json

### Methodology lessons carried forward

1. **Inherited rc.7 lesson — audit-then-fix bounds scope before code touch.** The c1 audit doc was composed before any edit; the scope-lock survived through 5 passes with no scope creep.
2. **Inherited rc.7 lesson — verify user-facing claims at runtime.** Applied during c1 audit: the original "remove the lang ChaosiumCanvasInterface namespace as a low-risk fix" framing was a wrong premise; checking code consumers caught it before any code touch.
3. **New c1 lesson — automated rename passes need exhaustive verification grep at COMPLETION, not at COMPOSITION.** The P4 "0 remaining BRP* identifiers" narrative used a regex check at script completion that didn't match the final source. v1.1.0 c1 verification grep at completion was substantively different from any composed estimate — and it caught everything the P4 pass missed. Future bulk-rename clusters: grep at the END.
4. **New c1 lesson — silent bugs hide in renamed code.** Two pre-c1 silent bugs surfaced during the rename work (`BRP.mapNoteNoBackground` localize call, rename-script "elysium → elysium" double-substitution). Both were invisible in normal user flows but real correctness issues. Bulk renames are a good opportunity to grep for inconsistencies that survived prior passes.

### Items deferred to v1.1.0 c2+ (per c1 audit doc)

- "Mythras" lang attributions (~30 strings) — rules-attribution decision needs separate consideration
- All other v1.1.0 scope-audit items (combat tracker, wound badge, inline-style sweep, statistics tab redesign, magic dev grids) — deliberately reserved for c2+
- Compendium content changes — IP audit found no required changes (see `docs/v1.1.0-compendium-ip-audit.md`)

### Verification methodology for c1 post-install

1. **Settings persistence**: open settings UI, confirm `iconPrimary` / `itemElysiumID` / `firstAidElysiumID` controls render with localized labels
2. **ID editor**: open any actor/item sheet, click the fingerprint button (now `editElysiumID` action) — ElysiumIDEditor opens
3. **Map note label**: configure a journal map pin, verify the "Hide background" label renders as localized text (not as a raw key string — pre-c1 it showed "BRP.mapNoteNoBackground" literally)
4. **Region behavior creation**: in a fresh scene, create a region, add a behavior of type `ElysiumCanvasInterfaceAmbientLightToggle` — type appears with "ECI: Light Toggle" label
5. **GM tools control**: in the scene controls, the GM tools menu opens (uses the `elysiummenu` internal name)
6. **Drag-drop**: drag a career with attached power-skills onto an actor — `_onDropItemCreate` (was `_BRPonDropItemCreate`) handles the drop; F9/F17 fixes from v1.0.0 still apply
7. **Console error sweep**: zero new errors after exercising every path; specifically zero `is not a registered game setting` errors and zero unresolved-key strings (`Elysium.X.Y` literal text appearing in UI where a localized string should be)

### Testing environment note

**IMPORTANT FOR FUTURE AI ASSISTANTS**: a Chrome-bridge environmental quirk was rediscovered during c1 verification. Rendering Foundry application/sheet windows via the bridge causes the bridge to lose tab access (`Cannot access a chrome-extension:// URL of different extension`). The confirmed workaround is `document.querySelectorAll('.application').forEach(el => el.remove())` after each UI flow. Full details — including symptoms, what works, what doesn't, and a worked verification-flow example — live at `docs/testing-environment-notes.md`. Read that file before attempting UI-event-level verification against the live Foundry build.

---

## [1.0.0] — 2026-05-15 — v1.0.0 FINAL

**v1.0.0 ships every documented finding F1-F17 fixed and zero deferrals.** The hotfix work below was performed in the rc.7 RC validation window; this entry consolidates the rc.7 fixes under the final v1.0.0 tag.

The rc.6→rc.7 cycle produced 6 fixed findings (F13→F14→F15→F16→F9→F17) through the audit-then-fix methodology. The "block v1.0.0 final tag pending audit" Option C decision produced 6 fixed findings where naive shipping at rc.5 would have left 5 latent. The methodology converged with zero new findings in the rc.7 final verification pass.

---

## [1.0.0-rc.7] — Hotfix: F14 + F15 + F16 + F9 + F17 (downstream bugs surfaced by F13 fix + new UI-event-level methodology + final v1.1.0 deferrals resolved)

**Two MEDIUM-severity bugs surfaced during the rc.6 UI-event-level verification pass** — both pre-existing, both made reachable by the F13 fix. Per the locked Option C decision, these were not deferred to v1.1.0; instead the audit-then-fix methodology was applied a second time within the v1.0.0 RC validation window. Per user direction "Path Z": fix both, ship rc.7, verify.

The rc.6 verification pass was the first time bridge testing exercised actual UI click events on every action handler (vs the API-level testing used in rc.1–rc.5). It immediately surfaced F14 + F15, validating the methodology gap analysis documented in rc.6's CHANGELOG and `docs/F13-audit.md`.

### F14 root-cause analysis — weapon-roll with no source-skill link throws

**Where**: `module/apps/check.mjs` L172-203 (CM and QC cases inside `normaliseRequest`).

**Pattern**:
```js
skill = particActor.items.get(config.skillId)
config.label = skill.name ?? ""              // ← throws if skill undefined
config.rawScore = skill.system.total + ...    // ← also throws
```

**Trigger**: User creates a weapon item without linking a source-skill (programmatically, OR via bare item-create-UI without picking a skill). The weapon-row template emits `data-skill-id="{{weapon.system.sourceID}}"` which becomes empty when `sourceID` is unset. The F13 helper correctly returns `null` for an empty-string skillId (since empty string is falsy in JS), then `items.get(null)` returns undefined, then `.name` throws.

**Latent since**: alpha.5-era weapon-skill linkage. The pre-F13 `event.target.closest('.item').dataset.itemId` would throw FIRST (at the null-closest step) before ever reaching check.mjs. The F13 fix made the downstream path reachable so the latent check.mjs bug finally became observable.

**Severity**: MEDIUM. Edge case but reachable through normal "create blank weapon item" workflows.

### F14 fix — defensive guards at 5 sites in check.mjs

Mirrors the F12+F13 lesson: do not trust that templates always emit valid data. Each case that does `skill = particActor.items.get(config.skillId)` now follows with `if (!skill) { ui.notifications.warn(...); return false }`. Applied to:

- **L116** (SK case)
- **L139** (AL / PA / RP shared case — defensive though template-emit pattern makes this case unreachable in practice)
- **L153** (PT case)
- **L184** (CM case — the case that actually surfaced the bug)
- **L207** (QC case — same pattern as CM)

Two lang keys added in en/es/fr (`errorSkillMissing`, `errorWeaponNoSkill`) for user-facing notification text. The keys take template interpolation for the weapon name in the no-source-skill variant.

### F15 root-cause analysis — `CHAT_MESSAGE_STYLES.OTHER` (numeric 0) fails V14 ChatMessage validation

**Where**: 4 files, 5 sites:
- `module/apps/charDev.mjs:152` — `showXPChat` (the site that surfaced)
- `module/apps/utilities.mjs:236-250` — item-description chat path
- `module/actor/sheets/base-actor-sheet.mjs:319-323` — rollStats output
- `module/apps/check.mjs:269,273,277,281` — `cardType` GR/OP/CO/CB cases (dead writes — see below)

**Pattern**:
```js
const chatType = CONST.CHAT_MESSAGE_STYLES.OTHER   // === 0 (numeric)
chatData = { type: chatType, ... }                 // ChatMessage.type expects STRING in V14
await ChatMessage.create(chatData)                 // throws DataModelValidationError
```

**Root cause**: V14 ChatMessage schema changed. The legacy `CONST.CHAT_MESSAGE_STYLES.OTHER` is a numeric enum value (=0) carried over from V11/V12. In V14, `ChatMessage.type` expects a string from the enum `["base", "ic", "ooc", "emote", "whisper", "roll"]`. Passing `0` fails `DataModelValidationError: type: "0" is not a valid type for the ChatMessage Document class`.

**Latent since**: V14 migration. One occurrence in `check.mjs:showChat:L681` was already manually commented out (`//type: chatMsgData.chatType,`) — someone hit this in the main roll-chat flow and patched it locally, but never grep'd for the broader pattern. The other 4 files retained the legacy pattern.

**Severity**: MEDIUM. XP-output chat cards fail silently (no chat-card posts; error visible only in console). Same for stat-rolls output and item-description chat-card.

### F15 fix — retire legacy `CHAT_MESSAGE_STYLES.OTHER` writes

3 sites that USE the value in ChatMessage.create:
- `charDev.mjs:showXPChat` — dropped `type` field; V14 defaults to `"base"`
- `utilities.mjs` item-description path — same fix
- `base-actor-sheet.mjs` rollStats output — same fix

4 dead writes in `check.mjs:normaliseRequest` (GR/OP/CO/CB cases at L269/273/277/281):
- These assigned `config.chatType = CONST.CHAT_MESSAGE_STYLES.OTHER` but the only downstream consumer (`showChat:L681`) was ALREADY commented out
- Pure dead code — retired cleanly with F15 retirement comment documenting why
- The two non-dead reads at L60 and L388 (which propagate `chatType` through chatMsgData but never reach a `ChatMessage.create` call now that L681 is commented) are left in place — harmless dead-data propagation, scope-creep to clean for an RC hotfix

V14's default `type: "base"` is the correct value for all 3 retired sites — these are "informational" chat cards (XP results, stat-roll summary, item-description display), not roll-result cards. The `type: "base"` default precisely matches the legacy `STYLES.OTHER` semantic intent.

### Sites intentionally NOT changed

- `module/apps/check.mjs:60` — `chatType: options.chatType,` (propagates undefined now that producers retired; dead data flow; safe)
- `module/apps/check.mjs:388` — same; dead data flow; safe
- `module/apps/check.mjs:681` — `//type: chatMsgData.chatType,` (already commented; archaeology preserved)

### Ship contents

| File | Change |
|---|---|
| `module/apps/check.mjs` | F14: 5 defensive `if (!skill)` guards added at SK/AL/PA/RP/PT/CM/QC cases; F15: 4 dead `config.chatType = ...STYLES.OTHER` writes retired |
| `module/apps/charDev.mjs` | F15: `showXPChat` retired the `type: chatType` field; V14 default applies |
| `module/apps/utilities.mjs` | F15: same retirement in item-description chat path |
| `module/actor/sheets/base-actor-sheet.mjs` | F15: same retirement in rollStats output |
| `lang/en.json` | F14: +2 keys (`errorSkillMissing`, `errorWeaponNoSkill`); 1345 → 1347 |
| `lang/es.json` | F14: +2 keys (Spanish translations); 1349 → 1351 |
| `lang/fr.json` | F14: +2 keys (French translations); 1349 → 1351 |
| `system.json` | version bump rc.6 → rc.7 |
| `CHANGELOG.md` | this rc.7 entry |
| `ROADMAP-v1.0.0.md` | rc.7 transition entry |

**No CSS changes. No template changes. No new assets.** 4 .mjs files modified, 3 lang files +2 keys each.

### Pre-flight gate — clean

- JSON parses 5/5
- JS parse OK on all 4 modified .mjs files
- Lang counts: en=1347, es=1351, fr=1351; structural gap 0 (each lang gained the same 2 keys)
- F14 verification: 3 `errorSkillMissing` references in check.mjs (SK, AL/PA/RP shared, PT); 2 `errorWeaponNoSkill` references (CM, QC); 5 defensive `if (!skill)` blocks
- F15 verification: 0 actual `CHAT_MESSAGE_STYLES` code references across charDev/utilities/base-actor-sheet/check (only 3 docstring/comment mentions documenting the historical pattern)
- F13 fix preserved (resolveTargetItemId helper + 10 call sites + 0 residual real `.closest('.item')` calls)
- CSS brace balance unchanged across all 9 stylesheets

### Behavioural impact

**For users with weapon items that have no linked source-skill**:
- Click on the weapon skill-roll button now shows a user-facing warning notification ("X has no source-skill linked. Open the weapon item and pick a skill to roll against.") instead of silently throwing in console
- No more silent failures; users see a clear actionable message

**For users hitting the corresponding latent paths in other roll types** (rare but possible if templates regress):
- Same user-facing notification pattern applied to SK/AL/PA/RP/PT cases

**For XP-rolls in dev tab**:
- Single-XP-rolls now post the chat-card correctly (was: silent failure + DataModelValidationError in console)

**For stat-roll output**:
- "Roll all stats" output chat-card now posts correctly (was: silent failure)

**For item-description chat-cards** (the "send description to chat" path in item sheets):
- Posts correctly (was: silent failure)

### Findings inventory at rc.7

| ID | Severity | Status |
|---|---|---|
| F1-F8 | Various | ✓ All fixed in c3/c4 |
| **F9** | **Low** | ✓ **Fixed in rc.7 (partner-fix with F17 below)** |
| F10 | High | ✓ Fixed in rc.2 |
| F11 | Low | ✓ Fixed in rc.4 |
| F12 | High | ✓ Fixed in rc.5 |
| F13 | High | ✓ Fixed in rc.6 |
| **F14** | **Medium** | ✓ **Fixed in rc.7 (defensive guards across 5 normaliseRequest cases)** |
| **F15** | **Medium** | ✓ **Fixed in rc.7 (legacy V11/V12 ChatMessage.type=numeric retired across 3 emission sites + 4 dead writes)** |
| **F16** | **Medium** | ✓ **Fixed in rc.7 (legacy `.actor-roll` cluster + orphan zebra-stripe rule retired + chat-body styles unified per Option B)** |
| **F17** | **Medium** | ✓ **Fixed in rc.7 (per-actor magic-category lookup correction + legacy 'power' type dead-code retirement)** |

**v1.0.0-rc.7 ships with zero documented deferrals.** Every F1-F17 fixed.

### The Option C methodology validation

Three consecutive RC hotfix cycles (rc.1→rc.2 / rc.4→rc.5 / rc.5→rc.6→rc.7) prove a consistent pattern:
1. **User-discovered bug** surfaces during real-user RC validation
2. **Audit-first approach** (Option C in rc.6) bounds the scope before fixing
3. **Comprehensive fix** ships in the next RC
4. **Verification pass** reveals downstream bugs that were masked
5. **Repeat** until verification produces zero findings

The "block v1.0.0 final tag pending audit" decision at rc.5→rc.6 has now produced 3 fixed findings (F13, F14, F15) where naive shipping would have left F14+F15 latent. The v1.0.0 final tag should not ship until a verification pass produces zero new findings.

### Verification methodology for rc.7 post-install

Repeat the rc.6 UI-event-level verification pass:

1. **F14 (weapon no source-skill)**: create a bare weapon item, click weapon-skill-roll button → user-facing notification appears, no console error, no DataModelValidationError
2. **F15 (XP-rolls chat-card)**: mark an item for improvement, click single-XP-roll button → chat-card posts successfully
3. **F15 (rollStats chat-card)**: click "roll all stats" (when actor is in unlocked state) → chat-card posts successfully
4. **F15 (item-description chat-card)**: open an item sheet, click the "send description to chat" button → chat-card posts successfully
5. **F13 regression**: every roll-from-sheet path still works as in rc.6 verification (skillRoll/passionRoll/reputationRoll/allegianceRoll/personalityRoll/weaponRoll-with-valid-skill/damageRoll/armorRoll/xpRolls)
6. **F8/F10/F11/F12 regressions all preserved**
7. **Console error sweep**: zero new errors after exercising every path; specifically zero `Cannot read properties of` errors and zero `DataModelValidationError` errors

### Next milestone

**v1.0.0-rc.7 is the candidate where every documented finding F1-F15 is fixed**. F9 remains the only deferred item, with documented rationale in `docs/v1.1.0-scope-audit.md`.

If the rc.7 UI-event-level verification pass produces **zero new findings**, the path to tagging v1.0.0 final is fully clear. If new findings surface, the audit-then-fix methodology repeats — but the surface for new findings is now narrowed by the cumulative work across rc.1-rc.7.

### v1.1.0 acceptance methodology update — now production-validated

The v1.1.0 c1 acceptance-pass discipline documented in rc.6 has been **validated by F14+F15** during rc.6→rc.7. The methodology surfaces real bugs that API-level testing missed. v1.1.0 c1 will adopt this as standard practice for every cluster ship.

### F16 root-cause analysis — legacy v0.x light-theme background breaks chat-card readability

**Where**: `css/legacy.css:751-803` (6 adjacent rules forming the v0.x `.actor-roll` cluster). The decisive rule at L768-776:
```css
.elysium .actor-roll .roll-details .header {
  height: 16px;
  width: 100%;
  display: flex;
  flex-direction: row;
  min-height: 40px;
  max-height: 40px;
  background-color: rgb(217, 219, 218);   /* light gray-tan — v0.x --actor-sheet-back residue */
}
```

**Trigger**: Any actor-roll chat-card (damage-roll, weapon-roll, group-roll, etc.) renders with the weapon/skill name (`.tag` span, `color: rgb(232, 230, 225)` near-white from `--ely-text-body`) sitting on a light gray-tan background. Result: **near-white text on near-white background** — unreadable.

**Surfaced**: During the rc.6 UI-event-level verification pass, F13's damage-roll test produced a chat-card with "_F13_weapon_test (0+0)" effectively invisible. Confirmed via DOM computed-style probe: `.tag` color was `rgb(232, 230, 225)` while parent `.header.roll-truncate` background was `rgb(217, 219, 218)`. The text-on-bg contrast ratio is roughly 1.07:1 — fails WCAG AA's 4.5:1 minimum by a wide margin.

**Why the v1.0.0 chat.css didn't win**: Two competing rules:

| Stylesheet | Selector | Specificity | Source order |
|---|---|---|---|
| `css/legacy.css:768` | `.elysium .actor-roll .roll-details .header` | (0,0,4,0) | later |
| `styles/elysium-chat.css:218` | `.elysium-chat-card .roll-details .header` | (0,0,3,0) | earlier |

Legacy wins on **both** specificity (4 classes vs 3) AND source order (`legacy.css` loads after `elysium-chat.css` per `system.json` `styles` array). The v1.0.0 rebuild added the new chat-css rules but didn't audit the cascade — legacy continued to dominate silently.

**Latent since**: v1.0.0 chat-card rebuild (cluster P9-P10). Required dark-theme rendering of an actor-roll chat-card to surface, which the API-level rc.1-rc.5 acceptance passes never exercised. UI-event-level rc.6 verification triggered it on the first damage-roll click.

**Severity**: Medium. Functional but unreadable. Cosmetic-only — no data loss, no exception, no broken interaction. But "users can't read the weapon name on their damage roll" is a real, repeating, every-combat experience-breaker.

### F16 fix — retire the legacy `.actor-roll` cluster outright (per user direction: Option B)

Three options considered:
- **Option A (band-aid)**: bump v1.0.0 selector specificity past legacy by adding `.actor-roll` hop or doubling the chat-card class (`.elysium.elysium-chat-card`). Leaves two competing rule sets in the cascade for the same surface. Rejected.
- **Option B (chosen)**: retire `css/legacy.css:751-803` outright. Clean, single-source-of-truth.
- **Option C (band-aid)**: tokenize the legacy rule (`rgb(217, 219, 218)` → `var(--ely-surface-sunken)`). Touches legacy.css, breaks the "legacy.css is frozen v0.x reference" contract. Rejected.

User direction was explicit: **"Option B — no band-aids, we want long-term fixes that are best for the code."** This is consistent with the F13 methodology (retire the v0.x DOM-traversal pattern rather than work around it).

### Safety verification before retirement

The `.actor-roll` class is emitted ONLY by chat-card templates:
- `templates/chat/parts/chat-card-participant-row.hbs:40`
- `templates/chat/parts/chat-card-tooltip-rows.hbs:28`
- `templates/chat/parts/chat-card-grouproll.hbs:51,98`

Zero emissions in actor sheets, NPCv2 sheets, item sheets, or any other surface. Verified via grep across all `templates/` *.hbs files. Live DOM probe confirmed: both `.actor-roll` elements in the test world were inside `.elysium-chat-card`. Retirement is safe.

### Coverage verification — v1.0.0 replaces all 6 retired rules

| Retired (legacy.css) | v1.0.0 replacement (elysium-chat.css) |
|---|---|
| L751-760 `.elysium .actor-roll` (flexrow + width 100%) | L188-197 `.elysium-chat-card .actor-roll` |
| L762-766 `.elysium .actor-roll .roll-details` (flexcol) | L211-216 `.elysium-chat-card .roll-details` (with `flex: 1` and `min-width: 0` improvements) |
| L768-776 `.elysium .actor-roll .roll-details .header` (★ BUG: light bg) | L218-225 `.elysium-chat-card .roll-details .header` (dark `--ely-surface-sunken` + subtle border) |
| L778-785 `.elysium .actor-roll .roll-details .header .name` (bold 14px) | L227-236 `.elysium-chat-card .roll-details .header .name` (tokenized font + ellipsis overflow — improvement) |
| L787-790 `.elysium .actor-roll .roll-details .header .a` | **ORPHAN** — no template emits `.a`. Was dead code. Retired with no replacement needed. |
| L792-803 `.elysium .actor-roll span.pending` | L248-259 `.elysium-chat-card span.pending` (tokenized, bordered, themed) |

Every retired rule has equal-or-better v1.0.0 coverage. The orphan `.a` rule was dead code.

### Ship contents (F16 addition to rc.7)

| File | Change |
|---|---|
| `css/legacy.css` | -53 lines (6 rules + spacing), +44 lines (retirement comment block documenting why). Brace balance 148/148 → 142/142 (12 braces removed). |

No JS changes. No template changes. No lang changes. No new assets. CSS-only.

### Pre-flight gate — clean (with F16 fold-in)

- CSS brace balance OK across all 10 stylesheets (legacy.css: 142/142, was 148/148; net -6 rules)
- Zero `.elysium .actor-roll` rule bodies remain in legacy.css (4 mentions are all in the retirement comment block + token references)
- Zero `rgb(217, 219, 218)` in rule bodies (3 remaining are: 2 in `--actor-sheet-back` token definitions which are valid for legacy actor-sheet-back consumers if any, plus 1 in the retirement comment block)
- v1.0.0 elysium-chat.css rules preserved: 3 `.elysium-chat-card .actor-roll` rule sites, 3 `--ely-surface-sunken` references, 6 `--ely-text-body` references
- JSON parses 5/5
- JS parse OK on all 5 rc.7-modified .mjs files (F13 + F14 + F15 all preserved)
- Lang counts unchanged from F14 ship (en=1347, es=1351, fr=1351; structural gap 0)

### Behavioural impact

**For every chat-card with `.actor-roll` rows**:
- Weapon name, skill name, and damage values now render with proper contrast (`--ely-text-body` light text on `--ely-surface-sunken` dark background)
- Damage roll, weapon roll, group roll, opposed roll, combat roll, cooperative roll — all visually consistent with the v1.0.0 dark-theme design system
- No more "users can't read what they just rolled" experience

**No regressions expected** since the v1.0.0 rules were already authored to replace the legacy rules — they just couldn't take effect due to cascade conflict. Retiring legacy unblocks them.

### F16 follow-through — readability investigation revealed deeper issues post-install

After the initial Option B retirement (the `.actor-roll` cluster) was installed, user feedback identified that the chat-card was still not visually right. Investigation via Chrome bridge zoom + computed-style probes revealed two additional issues underneath:

**Issue 1: typography weight too thin**. The v1.0.0 `.elysium-chat-card .roll-details .header .name` rule used `font-weight: var(--ely-font-weight-medium)` (500) at `font-size: var(--ely-font-size-1)` (11px). On a dark surface, 500-weight 11px text anti-aliases to a dim mid-gray, not crisp light text. The legacy rule used `font-weight: bold; font-size: 14px;` — the legacy authors had recognized this needed strong weight; the v1.0.0 rebuild over-tokenized to a too-light variant.

**Issue 2: orphan zebra-stripe rule adding green-gray tint**. CSS rule trace identified `css/legacy.css:983-986`:
```css
.elysium ol.dev-list li:nth-child(odd),
.elysium ol.gr-list li:nth-child(odd) {
  background-color: var(--ely-legacy-tableback);
}
```
where `--ely-legacy-tableback` resolves to `rgba(139, 155, 151, 0.39)` (light desaturated green-gray with 39% opacity). This rule was originally designed for actor-sheet item-list zebra striping but is doubly orphan in v1.0.0:

- **`.elysium ol.dev-list` is fully dead**. The v1.0.0 dev tab rebuild (P9 cluster 1) retired the `ol.dev-list` markup; only a documentation comment at `templates/actor/character.dev.hbs:4` mentions it as historical context. No template emits this class anywhere in v1.0.0.

- **`.elysium ol.gr-list` is emitted only by `templates/chat/parts/chat-card-grouproll.hbs:48`**. But the group-roll template wraps each participant's `<li class="actor-roll">` in its OWN `<div class="dice-roll">` wrapper. `li:nth-child(odd)` evaluates against the dice-roll div's children (where the li is always the first/only child = always odd) rather than against the parent ol — meaning the rule applies the tint to EVERY actor-roll, not alternating ones. It's not zebra-striping at all; it's "every chat-card actor-roll gets a green tint." Pure unintended noise.

Additionally, the v1.0.0 chat.css used `background: var(--ely-surface-sunken)` (#050505, near-black) on both `.header` and `span.pending` to create recess pockets. Combined with the green-tinted parent `.actor-roll` surface and the dark card background, the result was three nested rectangles each darker than the last, looking like a hole punched in the card rather than a recessed shelf.

### F16 follow-through fix — three coordinated changes

**Reference design** (per user-provided screenshot of Foundry's default chat-card): unified body surface, hierarchy through typography weight/size, optional pill borders only where information-bearing (success/fail roll outcomes), no decorative nested recesses. Translated to Elysium's dark theme.

**Change 1 — retire the orphan zebra-stripe rule** (`css/legacy.css:983-986`). Both selectors are fully orphan; rule retired with comment block documenting the audit. The `--ely-legacy-tableback` token is preserved since it has another consumer at L988 (`.elysium .button`) — though that rule is also worth auditing for v1.1.0 since v1.0.0 templates emit scoped button classes (`elysium-button`, `button-primary`, etc.), not bare `.button`. Out of scope for this hotfix.

**Change 2 — unify chat-card body surface** (`styles/elysium-chat.css:218-225, 248-259`). Removed `background: var(--ely-surface-sunken)` from `.header` and `span.pending`. The rows now sit on the card's natural `--ely-surface-card` (#1a1a1a) surface, with a subtle `border-bottom` on `.header` providing row separation. The value pill is borderless per user direction ("the value pill needs to be made borderless so it blends into the weapon name background").

**Change 3 — upgrade typography for readability**. `.header .name`: `font-size` 11px → 12px, `font-weight` medium → bold. `.tag` color: `--ely-text-body` (#e8e6e1) → `--ely-text-body-strong` (#ffffff) for maximum contrast on the dark surface. `span.pending`: `font-size` 11px → 16px (`--ely-font-size-4`), `font-weight` regular → bold, color `--ely-text-body` → `--ely-text-body-strong`. Establishes proper hierarchy: section title gold-bold-12px → weapon name white-bold-12px → damage value white-bold-16px.

**Change 4 — re-declare full border on roll-state variants** (`styles/elysium-chat.css:299-312`). The pre-fix `span.pending.roll-succ/fail/fumb` rules only overrode `border-color`, assuming a base `border: 1px solid X` existed on `.pending`. With the borderless base, they now need to declare a full border (`border: 1px solid var(--ely-accent-...)`) since the colored border IS information-bearing — it signals roll outcome to the user. These are the intentional exception to the "no decorative borders" body design.

### F16 follow-through verification (live in Chrome before source commit)

Tested via probe stylesheet injection in the live test world. Each design variant was rendered and screenshot-zoomed at 4× to verify readability:

- v1 (dark band, bold-12px): bands still too dark
- v2 (raised band #1f1f1f, bordered): better but bands still visually heavy
- v3 (transparent band, bordered pill): clean but pill border looks redundant
- **v4 (transparent band, borderless pill, bold-16px value)**: ✓ user-validated as matching reference design

Source-edit then mirrors v4 exactly. The probe was then re-injected matching the exact source-edit CSS (without `!important`, validating the cascade order works properly) and zoom-screenshot confirmed the rendered visual matches v4.

### F16 follow-through ship contents

| File | Change |
|---|---|
| `css/legacy.css` | Retired orphan zebra-stripe rule at L983-986 (3 lines + 1 closing brace + 1 selector continuation line = 5 lines retired, replaced with ~30 lines of retirement comment documenting the audit). Brace balance 142/142 → 140/140 (1 rule removed = 2 braces). |
| `styles/elysium-chat.css` | Updated `.header` (removed background + added padding); updated `.header .name` (bold + 12px); updated `.tag` color to text-body-strong; updated `span.pending` (removed background + border + radius, added bold + 16px); re-declared full border on `.pending.roll-succ/fail/fumb` state variants. Brace balance unchanged. |

No JS, no template, no lang, no asset changes. CSS-only follow-through.

### F16 follow-through pre-flight gate

- CSS brace balance OK across all 10 stylesheets (legacy.css: 142/142 → 140/140 after retirement; elysium-chat.css unchanged)
- Orphan rule fully retired (selector text appears only in retirement comment block, not as live rule)
- `--ely-legacy-tableback` token preserved (still has 1 valid consumer at L988 `.elysium .button`)
- All 3 roll-state variants (succ/fail/fumb) declare full borders
- JSON, JS, lang all unchanged from F14+F15+F16-initial ship state

### F9 root-cause analysis — `filter()`-truthy logic bug at `actor-itemDrop.mjs:305`

**LOW-severity pre-existing logic bug** at `module/actor/actor-itemDrop.mjs:305`, first documented during the F2 (alpha.54) defensive-guard sweep. F2 scope was strictly limited to "add optional-chain guards against null/undefined" — fixing the broken `filter()`-truthy logic was deferred to v1.1.0 as F9, since it's a behavior-change category distinct from crash-prevention. Per Option II at rc.7 (the fix-not-defer methodology applied for the 5th time), the deferral is resolved inline and v1.0.0 ships with zero documented deferrals beyond the planned v1.1.0 cluster work.

**The bug** (full pre-rc.7 context):

```js
for (let nPwr of itm.system.powers) {
  newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nPwr.elysiumid }))[0]
  if (!newSkill) continue
  if (!game.settings.get('elysium', [newSkill.system.category])) {
    ui.notifications.warn(newSkill.name + " : " + game.i18n.localize('Elysium.nopower'))
    continue
  }
  if (newSkill) {
    if (actor.items.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === newSkill.flags?.elysium?.elysiumidFlag?.id)) {
      continue            // ← always taken because filter() returns [] which is truthy
    } else {
      powerList.push(foundry.utils.duplicate(newSkill))   // ← never reached
    }
  }
}
```

**Root cause**: `Array.prototype.filter()` returns an array. **Arrays are always truthy in JavaScript**, including empty `[]`. So `if (actor.items.filter(...))` is **unconditionally true regardless of whether any items matched**. The `continue` branch always runs, the `else` (which pushes the candidate skill onto `powerList` for batch-creation) never runs.

**User-visible symptom**: dropping a career item with attached power-skills onto a character sheet silently fails to auto-create the parent skills. Users have to manually create them. Has affected character setup for power-using careers since the v0.x codebase.

**Why the rest of the file is clean**: a sibling pattern survey of `actor-itemDrop.mjs` found 3 `actor.items.filter(...)` usages:

| Site | Pattern | Status |
|---|---|---|
| L286 | `if (actor.items.filter(...).length > 0)` | ✓ correct |
| L305 | `if (actor.items.filter(...))` | ✗ F9 bug |
| L647 | `if (actor.items.filter(...).filter(...).length > 0)` | ✓ correct |

The author wrote the correct pattern at L286 and L647, but missed `.length > 0` at L305. Genuine isolated bug at a single site. Also swept the entire `module/` codebase for the same anti-pattern (`if (X.filter(...))` without `.length`/`find`/`some`/`every`): only L305 matched — all other `if (X.filter(...))` sites were combined with `.find()` or `.some()` (which return truthy/falsy correctly) and were not bugs.

### F9 fix — add the missing `.length > 0` check

Single-character-class change at `actor-itemDrop.mjs:305`. Pattern now aligns with the correct sibling usages at L286 and L647 in the same file:

```js
if (actor.items.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === newSkill.flags?.elysium?.elysiumidFlag?.id).length > 0) {
  continue
} else {
  powerList.push(foundry.utils.duplicate(newSkill))
}
```

Plus an extensive retirement-comment block above the line documenting:
- The pre-fix behavior (always-truthy bug)
- The user-visible symptom (silent failure of auto-skill-creation)
- The F2 deferral lineage (alpha.54 → v1.1.0 → rc.7 inline-fix)
- The sibling-pattern audit confirming the bug is single-site

### F9 fix — runtime verification via API probe

Demonstrated the bug behavior in the user's installed rc.7 (which still has the pre-fix code) via Chrome bridge:

```js
const fakeNewSkill = { flags: { elysium: { elysiumidFlag: { id: 'fake.brp-id.not-found.xyz123' } } } };
const filterResult = actor.items.filter(nitm => 
  nitm.flags?.elysium?.elysiumidFlag?.id === fakeNewSkill.flags?.elysium?.elysiumidFlag?.id
);
// filterResult = [] (empty array, length 0)
// pre-fix `if (filterResult)` = true  → continue (WRONG)
// post-fix `if (filterResult.length > 0)` = false → else branch (CORRECT)
```

Bug confirmed: pre-fix takes the wrong branch, post-fix takes the correct branch. The fix changes exactly the right behavior in exactly the right direction.

### F9 ship contents

| File | Change |
|---|---|
| `module/actor/actor-itemDrop.mjs` | L305 condition `if (actor.items.filter(...))` → `if (actor.items.filter(...).length > 0)`. Plus ~14 lines of retirement-comment block documenting the audit, the pre-fix behavior, the F2 deferral lineage, and the sibling-pattern survey results. |

No CSS, no template, no lang, no asset changes. Single JS line fix + comment.

### F9 pre-flight gate

- JS parse OK on `actor-itemDrop.mjs`
- Broken pattern fully retired (only appears in retirement comment, not as live code)
- Fixed pattern in place at L305
- Sibling correct patterns at L286 and L647 unchanged
- Whole-codebase sweep for `if (X.filter(...))` without `.length`/`find`/`some`/`every`: only the F9 retirement-comment line matched (false positive — comment, not executable code). No other anti-pattern sites in the codebase.

### F9 behavioural impact — honest correction

**ORIGINAL CLAIM** (now retracted): "Dropping a career item with attached power-skills now correctly auto-creates the parent skills (was: silent failure → manual creation required)."

**HONEST CORRECTION**: This claim was overstated. The F9 fix is correct in isolation — the `if (filter(...))` always-truthy logic IS fixed at the F9 line. However, F9 fix in isolation does NOT actually deliver the claimed user-facing benefit, because **an upstream gate at the previous line throws before F9 is ever reached**.

The upstream gate (the bug that became F17 below) reads `game.settings.get('elysium', [newSkill.system.category])` to check magic-category enablement — but no such world settings exist (magic flags live per-actor at `actor.system[category]`). The gate throws on every reachable invocation, aborting the loop before F9's line runs.

So the actual user-facing flow requires BOTH F9 AND F17 fixes to deliver the benefit. F9 alone unblocks the downstream logic; F17 unblocks the upstream gate. Both are needed.

This honest correction was added when the F17 audit (per user direction) revealed the upstream gate during F9 post-install verification. The audit-then-fix methodology is producing a quality of self-correction that wouldn't have happened with the original CHANGELOG-write-then-ship pattern.

### F17 root-cause analysis — `game.settings.get('elysium', [category])` reads non-existent world settings

**MEDIUM-severity pre-existing logic bug** — same severity as F14 and F15. Surfaced during F9 post-install verification when the simulated career-drop test threw `"elysium.arcane" is not a registered game setting` before reaching the F9 line. Audit per user direction "F17 audit".

**Where**: `module/actor/actor-itemDrop.mjs` — two sites:
- **L295** (in `_dropPersonality`, career-drop power-loop gate) — **reachable**, real user-facing impact
- **L124** (in `_BRPonDropItemCreate`, general drop handler) — **dead legacy path** gated by `nItm.type === 'power'` which is never true in v1.0.0 (the 'power' item type was retired in v0.8.0 per the in-code comment at L121-123)

**The bug** (at both sites):
```js
if (!game.settings.get('elysium', [newSkill.system.category])) {
  ui.notifications.warn(...)
  continue
}
```

**Root cause**: Two issues compounded:
1. **The lookup itself is wrong**. The code reads from `game.settings` (world-level settings), but magic-category enablement is a **per-actor property** stored at `actor.system[category]` (`actor.system.arcane`, `.sorcery`, `.psychic`, `.mutation`, `.mysticism`, `.super` — values `"on"` or `""`). There are no `elysium.arcane`/`elysium.sorcery`/etc. world settings registered. `game.settings.get('elysium', 'arcane')` throws `"elysium.arcane" is not a registered game setting`.
2. **The array bracket wrapping** (`[category]`) is also suspect but is actually irrelevant — JavaScript coerces single-element arrays to their stringified element when used as object keys, so `[category]` ends up looking up the same (non-existent) setting as bare `category`.

**Latent since**: pre-v1.0.0 (the bugs are clearly carried over from the v0.x codebase, predating the v1.0.0 rebuild work).

**Why never caught**: The path requires (a) a career item with `system.powers` array entries, AND (b) those entries to resolve to real skills via the elysiumid API. In the existing test world the actor has no career items with attached powers, and the rc.1-rc.6 acceptance passes were API-level only — never simulated this specific drop flow. F9 verification via direct API invocation of `_dropPersonality` with synthetic fixtures finally exposed the throw, which surfaced F17.

### F17 fix at L295 — correct the per-actor flag lookup

Replace `game.settings.get('elysium', [newSkill.system.category])` with `actor.system[newSkill.system.category]`. The corrected lookup reads the actor's per-character magic-category flag.

Behavior change: actors with the relevant category flag enabled (e.g., `actor.system.arcane === "on"`) pass the gate and proceed to add the power-skill to `powerList`; actors without it warn and skip (the original semantic the code was clearly trying to express). 

The extended retirement comment in source (L295 area) documents:
- The original lookup bug (world setting vs per-actor flag)
- The dual nature of the bug (array-wrap + wrong-target compounded)
- Why F9 fix alone didn't unblock the user-facing flow
- The corrected lookup pattern

### F17 fix at L121-127 — retire legacy 'power' type dead code

The L124 site is gated by `nItm.type === 'power'`, but v0.8.0 retired the 'power' item type entirely — no template in v1.0.0 emits an item with `type='power'`. The in-code comment at L121-123 already documented this:

> "If a generic 'power' (legacy BRP type — no longer used in Elysium v0.8.0; left here as a safe-no-op fallback). The check requires the corresponding world-setting category to be enabled."

But:
1. It's not a "safe-no-op fallback" — if the path were ever reached, the broken settings.get throws (not no-ops)
2. The "world-setting category" the comment describes doesn't exist as a world setting (it's a per-actor flag)

Per Option B precedent (retire legacy dead code outright with audit-comment block; no band-aids), the 7-line block is retired. The locale key `Elysium.nopower` is preserved — still referenced by the sibling at the fixed L295 site.

### F17 fix runtime verification

Pre-fix probe (rebuilt rc.7 installed):
```js
// L295 invocation with arcane skill on arcane-enabled actor → throws
ElysiumActorItemDrop._dropPersonality({type: 'career', system: {powers: [...]}}, actor)
// → Error: "elysium.arcane" is not a registered game setting
// → F9 path NEVER reached
```

Post-fix expected behavior (will verify after rebuild ships):
```js
// L295 invocation with arcane skill on arcane-enabled actor → gate passes
// → reaches F9-fixed site → pushes to powerList
// → createEmbeddedDocuments called with the skill
```

### F17 sibling-pattern audit

Whole-codebase grep for `game\.settings\.get\([^)]*\[[^)]*\]\)` (array-wrapped settings.get):

| File | L | Status |
|---|---|---|
| `module/actor/actor-itemDrop.mjs` | 124 | F17 retirement (dead legacy path) |
| `module/actor/actor-itemDrop.mjs` | 295 | F17 fix (reachable site) |

Two hits, both in the same file. No other files exhibit this anti-pattern. No further sites need fixing.

### F17 ship contents

| File | Change |
|---|---|
| `module/actor/actor-itemDrop.mjs` | L295: `game.settings.get('elysium', [newSkill.system.category])` → `actor.system[newSkill.system.category]` (the correct per-actor lookup); ~20 lines of audit comment block above the fix. L121-127: 7-line legacy 'power' type block retired with ~30-line retirement comment block documenting the audit. Net file growth: 674 → 716 lines (+42 from comment blocks). |

No CSS, no template, no lang, no asset changes. Single JS file modified.

### F17 pre-flight gate

- JS parse OK on `actor-itemDrop.mjs`
- Real array-wrapped `game.settings.get` callers: 0 (both buggy sites retired/fixed)
- Fixed pattern `if (!actor.system[newSkill.system.category])` in place at L295
- F17 retirement marker present at L121
- F9 fix preserved: `.length > 0` patterns still count 3 (L286 + F9 site + L647)
- Locale key `Elysium.nopower` preserved: 1 real reference at fixed L295 site

### F17 behavioural impact (honest claim this time)

**For users with power-using careers AND actor magic-category enabled** (e.g., character has `arcane="on"` and is being dropped a career with arcane-using powers):
- The career drop now correctly auto-creates the parent skills (was: throw at L295, entire flow aborts, user manually creates skills as a workaround)
- This is the path that F9's original narrative INTENDED to describe — but couldn't deliver until F17 also fixed.

**For users with power-using careers but actor magic-category NOT enabled**:
- The gate now correctly warns with the `Elysium.nopower` notification and skips that specific power (the original intended semantic)
- Was: same throw, same flow abort, but no clear user signal about WHY

**For users without power-using careers**: no change.

**No regression possible**: the broken code's "always throw" behavior produced ZERO successful career-drop power-additions from this path. Fixing it can only ADD functionality. Nothing currently working stops working.

### Findings inventory at rc.7 — FINAL (with F17)

| ID | Severity | Status |
|---|---|---|
| F1-F8 | Various | ✓ All fixed in c3/c4 |
| **F9** | **Low** | ✓ **Fixed in rc.7** (`filter()`-truthy bug; partner-fix with F17) |
| F10 | High | ✓ Fixed in rc.2 |
| F11 | Low | ✓ Fixed in rc.4 |
| F12 | High | ✓ Fixed in rc.5 |
| F13 | High | ✓ Fixed in rc.6 |
| F14 | Medium | ✓ Fixed in rc.7 |
| F15 | Medium | ✓ Fixed in rc.7 |
| **F16** | **Medium** | ✓ **Fixed in rc.7 (legacy `.actor-roll` cluster + orphan zebra-stripe rule retired + chat-body styles unified per Option B)** |
| **F17** | **Medium** | ✓ **Fixed in rc.7 (per-actor magic-category lookup correction + legacy 'power' type dead-code retirement; F9 partner-fix that unblocks the user-facing flow)** |

**v1.0.0 ships with every documented finding F1-F17 fixed and zero deferrals.**

**v1.0.0 ships with zero documented deferrals.** Every documented finding F1-F16 is fixed in the v1.0.0 RC validation window. The v1.1.0 backlog at `docs/v1.1.0-scope-audit.md` retains its 12 candidates but contains no carried-over v1.0.0 findings.

### Methodology validation — Option C policy paid off again

Four consecutive RC hotfix cycles now follow the same recovery pattern:
1. rc.1→rc.2 (F10, sheet-render blocker)
2. rc.4→rc.5 (F12, multi-magic-discipline grid placement)
3. rc.5→rc.6 (F13, DOM-traversal anti-pattern)
4. **rc.6→rc.7 (F14+F15+F16, three medium-severity bugs surfaced by F13 fix + UI-event-level methodology)**

Each cycle: user-discovered bug → audit-first bounds scope → comprehensive fix → verification pass reveals downstream → repeat. The "block v1.0.0 final tag pending audit" decision has now produced 4 fixed findings (F13+F14+F15+F16) that naive shipping would have left latent. Naive shipping at rc.5 would have shipped F13+F14+F15+F16 all unfixed.

### Verification methodology for rc.7 post-install

1. **F16 (chat-card readability)**: trigger a damage roll on any weapon → chat-card weapon name visible with proper dark-theme contrast (text light, background dark, NOT light-on-light)
2. **F14 (weapon no source-skill)**: bare weapon → click skill-roll → user notification, no console throw
3. **F15 (XP-rolls / rollStats / item-description chat-cards)**: each posts successfully, no `DataModelValidationError`
4. **F13 regression**: every roll path from rc.6 verification still works
5. **F8/F10/F11/F12 regressions all preserved**
6. **Console error sweep**: zero new errors

---



## [1.0.0-rc.6] — Hotfix: F13 legacy DOM-traversal anti-pattern across 11 roll-handler sites

**HIGH-severity bug surfaced during rc.5 install live-verify.** The console-error sweep captured 66+ identical `TypeError: Cannot read properties of null (reading 'dataset')` exceptions at `module/apps/rollType.mjs:58`, all from clicks on skill rows in the user's test character sheet. Investigation revealed a systemic v0.x DOM-traversal anti-pattern surviving the V14 ApplicationV2 rebuild across 10 roll-handler sites in `rollType.mjs` plus 1 in `base-actor-sheet.mjs`.

Per the "Option C — block v1.0.0 final tag pending comprehensive UI-event surface audit" decision, rc.6 ships ONLY after a full audit (delivered as `docs/F13-audit.md`, 179 lines) bounded the scope. No partial fix shipped; one comprehensive fix.

### F13 root-cause analysis

V0.x templates emitted `<li class="item" data-item-id="...">` wrappers around interactive elements. Roll handlers in `rollType.mjs` traversed up via `event.target.closest('.item').dataset.itemId` to retrieve the item id. This pattern was carried unchanged through the entire P5-P12 rebuild.

V1.0.0 templates use two new patterns, neither of which emit the legacy `.item` wrapper:

**Pattern A — data on the clicked element itself**:
```html
<a data-action="skillRoll" data-skill-id="{{skill.id}}">Skill name</a>
```
Used in: `left-rail-skills.hbs`, `right-rail-senses.hbs`, `pers-trait-row.hbs` (partial).

**Pattern B — data on row wrapper, action on inner element**:
```html
<div class="elysium-allegiance-row" data-item-id="{{allegiance._id}}">
  <a data-action="allegianceRoll">...</a>
</div>
```
Used in: `allegiance-row`, `passion-row`, `reputation-row`, `weapon-row`, `hit-location-row`, `magic-skill-summary`, `divine-body`, `pers-trait-row` (partial), `character.dev.hbs` (dev-row).

For both patterns, `event.target.closest('.item')` returns null because no element matches `.item`. The next read `.dataset.itemId` throws `TypeError: Cannot read properties of null`. The exception is silently logged to console; from a user perspective, the click does nothing visible.

### Why this slipped past 5 RC validation passes

Same methodology gap as F12 but more severe: **every prior live-verify pass was API-level only.** The rc.1 bridge acceptance pass tested 66 API-method-call categories but never simulated a UI click. The rc.2/rc.3/rc.4/rc.5 regression checks reused that same API-level pattern. The bug existed since alpha.37 (≥17 alphas + 5 RCs = ~22 releases) but was never triggered.

It surfaced in rc.5 only because the live-verify pass added a console-error sweep (`read_console_messages` with `onlyErrors: true`) that captured the 66+ silent exceptions logged during the user's manual testing between rc.5 install and the verify call.

### F13 audit document

The full pre-fix audit lives at `docs/F13-audit.md` (179 lines, composed during Option C Phase 1 before any code changes). Sections:
- Inventory of all 14 `.closest()` sites in event handlers across the codebase
- Categorization: 10 BROKEN on V1.0.0, 4 still-functional (bio-section class IS emitted in `story-section.hbs:L42`), 2 in legacy-only contexts (`skillInline` magic-grid + NPCv2)
- Two-pattern analysis with template examples
- Proposed `resolveTargetItemId(event, detail, ...attrs)` helper with rationale
- Per-site fix prescriptions
- Testing complexity assessment (~8-10 manual UI click verifications)
- v1.1.0 acceptance methodology update documented

### The fix: a `resolveTargetItemId` helper

Added at the top of `module/apps/rollType.mjs`. ~30 LOC including documentation comment:

```js
function resolveTargetItemId(event, detail, ...attrs) {
  // Try direct dataset reads first (Pattern A)
  for (const attr of attrs) {
    if (detail?.[attr]) return detail[attr]
  }
  // Fallback: walk up the DOM to find a wrapper carrying any of the attrs
  const sel = attrs
    .map(a => `[data-${a.replace(/[A-Z]/g, m => '-' + m.toLowerCase())}]`)
    .join(', ')
  const wrapper = event.target.closest(sel)
  if (!wrapper) return null
  for (const attr of attrs) {
    if (wrapper.dataset[attr]) return wrapper.dataset[attr]
  }
  return null
}
```

Each call site declares its expected dataset attribute priority. The helper:
1. Checks `detail` (= clicked element's dataset) first
2. Falls back to walking up via attribute selector (not class selector — uses `[data-item-id], [data-skill-id]` which match wrappers regardless of class name)
3. Returns `null` instead of throwing on miss

### 11 sites updated

All in priority order they appear in source:

| Site | Handler | Helper call |
|---|---|---|
| `rollType.mjs` L111 | `_onSkillRoll` | `resolveTargetItemId(event, detail, 'skillId', 'itemId')` |
| `rollType.mjs` L134 | `_onAllegianceRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L155 | `_onPassionRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L177 | `_onReputationRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L200 | `_onPersTraitRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L220 | `_onDamageRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L236 | `_onImpactRoll` | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L251 | `_onWeaponRoll` (itemId) | `resolveTargetItemId(event, detail, 'itemId')` |
| `rollType.mjs` L252 | `_onWeaponRoll` (skillId) | `resolveTargetItemId(event, detail, 'skillId')` |
| `rollType.mjs` L299 | `_onArmor` (nap case) | `resolveTargetItemId(event, detail, 'itemId')` |
| `base-actor-sheet.mjs` L649 | `_onXPRolls` | inline equivalent — walk up to `[data-item-id]` with null-safe guard |

For `_onXPRolls` in `base-actor-sheet.mjs`, the helper from `rollType.mjs` is not imported (would create a cross-file dependency for a single site). Instead, the same null-safe `event.target.closest('[data-item-id]')` pattern is inlined with a `console.warn` on null.

### Sites intentionally NOT changed

| Site | Reason |
|---|---|
| `base-actor-sheet.mjs` L984/L1050/L1059/L1071 (bio-section) | `bio-section` class IS still emitted in `story-section.hbs:L42`; these handlers are FUNCTIONAL. Tracked as v1.1.0 c1 Item 7 (legacy class listeners pending migration to V14 action handlers). |
| `base-actor-sheet.mjs` L1011 (`skillInline` currentTarget.closest) | Triggered only from unlocked-mode magic-grid (`arcane-body.hbs:L193`, `mysticism-body.hbs:L111`) + NPCv2 — both of which emit `class="item skills-tab-grid"`. Functional in those contexts. Tracked as v1.1.0 magic-grid redesign + statistics-tab redesign work. |

### Ship contents

| File | Change |
|---|---|
| `module/apps/rollType.mjs` | +~30 LOC (`resolveTargetItemId` helper + docstring), 10 sites converted from legacy traversal to helper calls |
| `module/actor/sheets/base-actor-sheet.mjs` | 1 site converted: `_onXPRolls` legacy `.closest('.item')` → null-safe `.closest('[data-item-id]')` with `console.warn` guard |
| `system.json` | version bump rc.5 → rc.6 |
| `docs/F13-audit.md` | NEW (179 lines, the pre-fix audit document) |
| `CHANGELOG.md` | this rc.6 entry |
| `ROADMAP-v1.0.0.md` | rc.6 transition entry + v1.0.0-final-tag-readiness update |

**No CSS changes**. **No template changes**. **No lang changes**. **No new assets**. Pure JS code fix + new docs.

### Pre-flight sweep — clean

- JSON parses 5/5 (system.json + 3 lang + template.json)
- JS parse OK on both modified .mjs files
- Lang counts unchanged from rc.5 (en=1345, es=1349, fr=1349; gap 0)
- CSS brace balance unchanged across all 9 stylesheets (446/3/85/1/17/20/5/507/148)
- F13 fix verification: helper defined ×1; helper called from 10 distinct sites; 0 residual `.closest('.item')` real call sites in rollType.mjs (1 in docstring comment is fine; the docstring documents the historical pattern)
- bio-section legacy class listeners preserved (4 sites — still functional)
- skillInline legacy-context handler preserved (1 site — still functional)

### Behavioural impact

**For all users with a character sheet**:
- **Clicking any skill name in the left-rail or right-rail** → roll executes correctly (was: silent failure + console error)
- **Clicking allegiance/passion/reputation/personality-trait rows** → roll executes correctly (was: silent failure)
- **Clicking weapon damage/skill buttons** → rolls execute correctly (was: silent failure)
- **Clicking hit-location AP (when useAVRand is enabled)** → armor roll executes correctly (was: silent failure)
- **Clicking single-XP-rolls in dev tab** → XP gain executes correctly (was: silent failure)

**For users who set their world's `quickCombat` setting**:
- Shift+click on weapon roll still routes to QC path correctly (the pre-helper code structure is preserved; only the id-resolution line changed)

**For legacy contexts (NPCv2, statistics tab, unlocked-mode magic-grid)**:
- No change — the legacy `.item`-class wrappers used in those templates still match the helper's `[data-item-id]` selector via the attribute on the same wrapper.

### Findings inventory at rc.6

| ID | Severity | Status |
|---|---|---|
| F1-F8 | Various | ✓ All fixed in c3/c4 |
| F9 | Low | ⏸ Deferred to v1.1.0 |
| F10 | High | ✓ Fixed in rc.2 |
| F11 | Low | ✓ Fixed in rc.4 |
| F12 | High | ✓ Fixed in rc.5 |
| **F13** | **High** | ✓ **Fixed in rc.6 (this ship)** |

### v1.1.0 acceptance-pass methodology update

F12 + F13 together prove a systemic methodology gap: **bridge acceptance passes have been API-level only, never UI-event level.** The v1.0.0 RC validation period caught both via emergent real-user testing rather than methodical UI exercise. v1.1.0 c1 will add (per `docs/F13-audit.md` "v1.1.0 acceptance-pass methodology update" section):

1. **Click every action-handler** from the V1.0.0 sheet — at minimum once per registered action in `base-actor-sheet.mjs:actions{}` (~50 actions)
2. **Verify each action produces the expected output** (not just "doesn't throw") — check the chat-card creation, state change, etc.
3. **Test with multi-discipline characters** (F12 lesson) — at least 2 magic disciplines configured
4. **Console error sweep mandatory** at end of every pass — not just "0 errors during render" but "0 errors after exercising every action"

This is documented as a v1.1.0 c1 sub-task in `docs/v1.1.0-scope-audit.md` (no code change — acceptance-pass discipline).

### Verification methodology for rc.6 post-install

Live-verify must include actual UI clicks for each affected handler:

1. **skillRoll**: click a skill name in the left-rail (any standard skill) → chat-card appears
2. **allegianceRoll**: drag an allegiance item onto the actor, then click the total% → chat-card appears
3. **passionRoll**: drag a passion item, click name → chat-card appears
4. **reputationRoll**: drag a reputation item, click total → chat-card appears
5. **personalityRoll**: drag a personality-trait item, click primary side → chat-card appears
6. **weaponRoll + damageRoll**: drag a weapon item, click skill name → CB chat-card; click damage button → DM chat-card
7. **armorRoll** (nap variant): create a hit-location with apRnd > 0, click the AP cell when `useAVRand=true` → chat-card appears
8. **xpRolls** (single): mark a skill for improvement, navigate to dev tab, click single-XP-roll button → ElysiumCharDev.onXPGainSingle executes

Plus regression checks: F8, F10, F11, F12 all still fixed; console error sweep empty after the full pass.

### Next milestone

**v1.0.0-rc.6 is the candidate where every documented finding (F1-F12) is fixed AND F13 is closed.** The findings inventory is comprehensive at the limit of what the validation methodology can surface. If rc.6 holds clean through the validation window with the new UI-event-level methodology applied, the path to tagging v1.0.0 is straightforward.

The Option C decision (block v1.0.0 final tag pending comprehensive audit) paid off: the audit found the full scope (11 sites, not the 1 user-reported skillRoll), produced a clean fix (single helper + 11 call-site updates), and exposed the systemic methodology gap that needs to close in v1.1.0. The audit document survives as a v1.1.0 reference.

---

## [1.0.0-rc.5] — Hotfix: F12 consolidated-magic-tab grid placement (≥2 magic disciplines render in wrong area)

**HIGH-severity layout bug surfaced in user testing.** When an actor has ≥2 magic disciplines active (e.g., arcane + sorcery), the consolidated `magic` primary-tab content section was being placed into the wrong grid cell — auto-flowing into the 48px-wide `tabs` column at the far right edge of the sheet instead of the 550px-wide `content` middle column. Visual symptom: middle of sheet appears empty, magic-tab content fragment partially visible at bottom-right outside the sheet boundary.

Root cause is a single missing selector in `styles/elysium-sheets.css`. The fix is a one-line CSS addition. Pattern matches rc.1→rc.2 (F10 hotfix): single-finding emergent regression caught in real-user testing of the prior RC, isolated, fixed, shipped.

### F12 root-cause analysis

The `.window-content` of the character sheet uses CSS Grid layout (`styles/elysium-sheets.css` L31-55):

```css
.application.elysium.sheet.actor .window-content {
  display: grid;
  grid-template-columns: 280px 1fr 260px 48px;  /* leftRail / content / rightRail / tabs */
  grid-template-areas:
    "header header header tabs"
    "res res res tabs"
    "leftRail content rightRail tabs";
}
```

Every primary tab content part has explicit grid placement via a shared selector list at L83-95 (rc.4 pre-fix state):

```css
.application.elysium.sheet.actor [data-application-part="combat"],
.application.elysium.sheet.actor [data-application-part="items"],
.application.elysium.sheet.actor [data-application-part="pers"],
.application.elysium.sheet.actor [data-application-part="social"],
.application.elysium.sheet.actor [data-application-part="arcane"],
.application.elysium.sheet.actor [data-application-part="mutations"],
.application.elysium.sheet.actor [data-application-part="mysticism"],
.application.elysium.sheet.actor [data-application-part="sorcery"],
.application.elysium.sheet.actor [data-application-part="divine"],
.application.elysium.sheet.actor [data-application-part="super"],
.application.elysium.sheet.actor [data-application-part="statistics"],
.application.elysium.sheet.actor [data-application-part="background"],
.application.elysium.sheet.actor [data-application-part="dev"] {
  grid-column: 2 / 3;  /* content column */
  grid-row: 3 / -1;
  overflow-y: auto;
}
```

The list enumerates 13 tab content parts. **The `magic` part is missing.**

When alpha.37 introduced the consolidated magic-tab pattern (≥2 disciplines → single `'magic'` PART that wraps a discipline sub-tab strip + per-discipline body partials), the PART was registered in `character.mjs` (PARTS L77-80) and the discipline-detection logic was wired (`_activeMagicDisciplines` build at L122-127, `_preparePartContext` magic case at L176-218). **But the corresponding CSS grid-placement selector was never updated to include `magic` in the list above.**

Why this slipped past alpha.37 testing: the alpha.37 test character had exactly one magic discipline active, exercising only the single-tradition path (which uses the existing `arcane` / `divine` / `mysticism` / `sorcery` parts that ARE in the selector list). The ≥2-disciplines path was never visually validated. Bug latent for 17 alphas (alpha.37 → rc.4).

Why it slipped past the rc.1-rc.4 acceptance passes: the bridge acceptance pass at rc.1 used a freshly-created test character with no magic disciplines configured. Subsequent rc.2/rc.3/rc.4 spot-checks reused that same test actor without adding extra disciplines. The configuration that triggers the bug (`system.arcane != "" && system.sorcery != ""`, etc.) was never exercised in any in-bridge live-verify.

**Lesson**: bridge acceptance passes need at least one test character configured with each multi-discipline path the system supports. The acceptance-pass methodology will be augmented with a "multi-discipline magic" check for future RC validation.

### The fix

One line added to the selector list at `styles/elysium-sheets.css` L92 (between `divine` and `super`):

```css
.application.elysium.sheet.actor [data-application-part="magic"],
```

The magic part now matches the same `grid-column: 2 / 3; grid-row: 3 / -1; overflow-y: auto` rule that every other primary tab content part inherits.

### Live verification (during diagnosis, before commit)

Live-injected the new selector via `<style id="_F12FixTest">` while sheet was open and dimensions changed correctly:

| Element | Pre-fix | Post-fix |
|---|---|---|
| `section.actor.tab.magic` x position | 1747 (right edge) | 913 (centered) |
| `section.actor.tab.magic` width | 48px | 550px |
| `section.actor.tab.magic` height | 111px | 264px |
| `.elysium-magic-content` width | 38px | 550px |
| `.elysium-magic-discipline.active` width | 38px | 550px |
| `gridColumn` computed | `auto` | `2 / 3` |
| `gridRow` computed | `auto` | `3 / -1` |

Screenshot taken with the injected fix confirms visual correctness: sub-tab strip (ARCANE / SORCERY chips) renders correctly at top of content area; ARCANE SCHOOLS card with Abjuration listed; ARCANE spells card below. Same layout vocabulary as single-discipline magic tabs.

### Ship contents

| File | Change |
|---|---|
| `styles/elysium-sheets.css` | 1 line added (`[data-application-part="magic"]` selector at L92) |
| `system.json` | version bump rc.4 → rc.5 |
| `CHANGELOG.md` | this rc.5 entry |
| `ROADMAP-v1.0.0.md` | rc.5 transition entry |

**No code changes** (no .mjs touched). **No template changes**. **No new lang keys**. **No new assets**. The smallest possible RC bump: a 1-line CSS fix.

### Pre-flight sweep — clean

- JSON parses 5/5 (system.json + 3 lang + template.json)
- Lang counts unchanged from rc.4 (en=1345, es=1349, fr=1349; structural gap 0)
- CSS brace balance unchanged across all 9 stylesheets (446/3/85/1/17/20/5/507/148)
- F12 fix selector verified present in built CSS
- No .mjs changes (F8, F10, F11 fixes all preserved by inaction)

### Behavioural impact

**For users with ≥2 magic disciplines active** (the affected configuration):
- The consolidated magic tab now renders in the middle content area as designed
- Sub-tab strip switches between disciplines via clicks on the chips
- Each discipline body shows its arcane-schools / spells / forms / techniques / etc.

**For users with 0 or 1 magic disciplines**: no change. The single-discipline path (using `arcane` / `divine` / `mysticism` / `sorcery` parts directly) was never affected by F12 and continues to work as it did from rc.1 onward.

**For all users**: no other behavioural change. F8, F10, F11 fixes preserved.

### Findings inventory at rc.5

| ID | Severity | Status |
|---|---|---|
| F1-F8 | Various | ✓ All fixed in c3/c4 |
| F9 | Low | ⏸ Deferred to v1.1.0 |
| F10 | High | ✓ Fixed in rc.2 |
| F11 | Low | ✓ Fixed in rc.4 |
| **F12** | **High** | ✓ **Fixed in rc.5 (this ship)** |

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **Version reports correctly**: `game.system.version === '1.0.0-rc.5'`
2. **F12 fix applied — single-discipline still works**: set actor with arcane="on" only, open sheet, magic chip renders, click → arcane body in middle area
3. **F12 fix applied — multi-discipline now works**: set actor with arcane="on" + sorcery="on", open sheet, single "MAGIC" chip in rail, click → subtab strip + arcane body both in middle 550px content area
4. **F10 regression preserved**: skillcat without BRP-ID + render sheet → no throw
5. **F8 regression preserved**: fatigue increment with `'magical'` → recoveryType persists
6. **F11 regression preserved**: charSheetLogo setting still absent from Display Options menu
7. **Brand-art preserved**: `elysium-logo.webp` still serves 200 OK; old `char-sheet-logo.png` still 404
8. **Console health**: zero new errors

### Next milestone

**v1.0.0-rc.5 is the candidate**. Pattern matches the rc.1→rc.2 hotfix recovery: a real-user-discovered bug surfaces during RC validation, gets isolated to a single root cause, fixed minimally, shipped. Validation window continues; the surface for further surprises is narrower than at any prior RC.

The F12 finding does highlight that the bridge acceptance methodology needs augmentation for multi-discipline scenarios. This will be reflected in the v1.1.0 c1 audit document: the methodology improvement is to be tracked as a v1.1.0 sub-task (no system code change, just acceptance-pass discipline).

---

## [1.0.0-rc.4] — Brand-art ingestion + Gate 1 & Gate 2 resolution (P12 release-prep completion)

**The two outstanding P12 decision-gates close in this ship.** Per user direction with Q1=B + Q2=B answers, rc.4 ingests user-provided brand art (Path A on Gate 2), drops the auto-scene-creation dead pattern (Q1=B), retires the dead `charSheetLogo` setting (Q2=B), and documents the already-decided-by-inaction light-theme retirement (Gate 1).

### Gate 2 (logos) — user-provided brand art delivered (Path A)

The current `assets/char-sheet-logo.png` was a v0.x leftover: a 700×58 dark-crimson text image reading "BASIC ROLE PLAYING" — direct contradiction of the v1.0.0 identity rename ("Elysium BRP" → "Elysium"). It appeared in three public-facing places (Foundry package listing media thumbnail, default scene background, dead `charSheetLogo` setting default). The rc.3 plan named this as an external-input-gate awaiting user-provided art; in this ship the user delivered.

**New brand-art asset**: `assets/elysium-logo.webp` (512×512, WEBP q90, 19,330 bytes). The user-provided source (1254×1254 PNG, 97,270 bytes) was downsized to 512×512 — adequate resolution for Foundry's package listing thumbnail and any downstream display surface, while ~5× smaller in distribution. WEBP format matches the project's existing image-format choice (parchment.webp, dark_parchment.webp).

Design: gold "ELYSIUM" wordmark with serif typography against a hexagonal/diamond geometric motif evoking polyhedral dice — the visual identity of a tactical RPG system. Aligns with the project's bronze/crimson accent palette (the gold reads as the bronze-amber token family).

The new asset's only consumer is the `system.json` `media` field (Foundry package listing thumbnail). The two former consumers retire in this ship per Q1=B and Q2=B.

### Q1=B — Drop auto-scene-creation entirely

`module/setup/load.mjs` was a 9-line module that ran on every world's `ready` hook, checking if scenes were empty, and creating a "Default" scene with the old BRP banner as a 3000×3000 background image with 0.3868 zoom. This was a v0.x quirk that never worked well — using a banner image as a scene background is fundamentally incongruent.

**Resolution**: drop the entire module and unregister it from `system.json` esmodules. Users can create scenes themselves; Foundry handles empty-world states fine without our intervention.

**Changes**:
- `module/setup/load.mjs` DELETED
- `system.json` `esmodules` array: 3 entries → 2 (removed `"module/setup/load.mjs"`)

**Behavioural impact**: on fresh world creation, no "Default" scene auto-creates. GMs see the empty scene browser and create their first scene normally. This matches how Foundry's other major systems (DnD5e, Pathfinder 2e, etc.) behave.

### Q2=B — Retire dead `charSheetLogo` setting + unused `context.logo` line

Surfaced during the brand-art audit: `charSheetLogo` is a registered Foundry game-setting (with file-picker UI in `display-settings.hbs`, default value `'systems/elysium/assets/char-sheet-logo.png'`) that exposes a user-configurable logo image picker. The result is read in `character.mjs:362` (`context.logo = game.settings.get('elysium', 'charSheetLogo')`) and stashed into the sheet render context.

**No template ever consumes `{{logo}}`.** Grep across all 53 .hbs files: zero references to `{{logo}}` or `{{this.logo}}` or `{{context.logo}}`. The sheet rebuild during P7-P8 dropped the logo display from the sheet header but left the setting + context-set line as dead code.

This conflicts with an earlier CHANGELOG entry (~L6207) that claimed `charSheetLogo` was audited as "legitimate per-campaign theming hook" with "exactly 2 reads (truthy-check + apply-to-CSS-variable)". That alpha-era audit was either incorrect at the time or the code path was retired in a later cluster without updating the audit. Either way, the rc.4 finding is honest: zero active consumers.

**This becomes F11 (Low severity, dead-code retirement)**:

Retired in this ship:
- `module/settings/settings-display.mjs` L85-93 — the `charSheetLogo` setting registration block (replaced with F11 retirement comment documenting rationale)
- `module/actor/sheets/character.mjs` L362 — the `context.logo = ...` line (replaced with F11 retirement comment)
- `templates/settings/display-settings.hbs` L69-75 — the file-picker UI block in the display settings menu (replaced with F11 retirement Handlebars comment)
- `lang/en.json` — keys `Elysium.Settings.charSheetLogo` + `charSheetLogoHint` (orphan lang keys)
- `lang/es.json` — same 2 keys
- `lang/fr.json` — same 2 keys
- `assets/char-sheet-logo.png` — the BRP-era banner asset itself (no active references after the above retirements)

**Behavioural impact for users**: the "Character Sheet Logo" picker no longer appears in the Display Options settings menu. Users who had set a custom logo via this picker will not lose their custom image file (it's just in their world data; not consumed by anything anymore). On fresh worlds, no logo picker is shown.

### Gate 1 — Light theme: documented as already decided by inaction

Per the rc.3 entry, light theme was the second outstanding decision-gate. **Audit during rc.4 work confirms: there is no light theme infrastructure in v1.0.0.** Zero `--ely-*-light` variant tokens; zero `prefers-color-scheme: light` media queries; zero theme-toggle UI in any of 53 templates; zero theme-toggle logic in any of the 100+ .mjs files; zero theme setting in `register-settings.mjs`. The 9 `theme-light` references in `module/hooks/render-journal-entry-sheet.mjs` and `render-journal-entry-page-text-sheet.mjs` are **Foundry-API integration** for the journal-page parchment look on `css-adventure-entry`-flagged pages, not an Elysium light theme.

The P0 framing said "Default leans towards retire"; the entire P5-P12 journey shipped dark-only. **The decision was made by inaction across 24 alphas.** rc.4 documents this state explicitly in the v1.0.0 release notes draft.

No code changes for Gate 1 — there is nothing to retire because nothing was ever built.

### Updated release notes draft

`docs/v1.0.0-release-notes-draft.md` updated to:
- Replace "Light theme retired or kept" mention in deferred section with explicit "Light theme: not implemented (dark theme is the v1.0.0 vision)"
- Update brand-identity narrative to reflect the gold/bronze ELYSIUM wordmark
- Move Gate 1 + Gate 2 closures from "decision-gate pending" to "closed in rc.4"

### Ship contents

| File | Change |
|---|---|
| `assets/elysium-logo.webp` | **NEW** (19,330 bytes, 512×512 WEBP brand art, user-provided + downsized) |
| `assets/char-sheet-logo.png` | **DELETED** (BRP-era residue, 3,720 bytes) |
| `module/setup/load.mjs` | **DELETED** (auto-scene-creator, 9 LOC) |
| `system.json` | `media[0].url` + `thumbnail` retargeted to new logo; `esmodules` array: removed `module/setup/load.mjs` entry; version bump rc.3 → rc.4 |
| `module/settings/settings-display.mjs` | `charSheetLogo` setting block (9 LOC) retired with F11 retirement comment |
| `module/actor/sheets/character.mjs` | `context.logo = ...` line retired with F11 retirement comment |
| `templates/settings/display-settings.hbs` | file-picker UI block (8 LOC) retired with F11 retirement Handlebars comment |
| `lang/en.json` | 2 orphan keys removed (`charSheetLogo`, `charSheetLogoHint`); lang count 1347 → 1345 |
| `lang/es.json` | Same 2 keys removed; count 1351 → 1349 |
| `lang/fr.json` | Same 2 keys removed; count 1351 → 1349 |
| `docs/v1.0.0-release-notes-draft.md` | Updated Gate 1 + Gate 2 narrative |
| `CHANGELOG.md` | this rc.4 entry |
| `ROADMAP-v1.0.0.md` | rc.4 transition entry + Gate 1 & 2 closure documentation |

**LOC delta**: ~27 LOC of dead code retired; 7 lines of F11 retirement comments added; 2 lang keys × 3 langs retired (= 6 lang lines); 1 esmodule entry retired; 1 asset file deleted; 1 new asset file added.

### Pre-flight sweep — clean

- JSON parses 5/5 (system.json + 3 lang + template.json)
- Lang structural gap unchanged: 0 for both es and fr (now en=1345, es=1349, fr=1349)
- BRP residue final sweep: 0 user-facing lines (unchanged from rc.3)
- JS parse OK on the 2 modified .mjs files
- CSS brace balance unchanged across all 9 stylesheets (446/3/85/1/17/20/5/507/148)
- `module/setup/load.mjs` confirmed absent from disk and from `esmodules` array
- New `elysium-logo.webp` present at expected path (19,330 bytes)
- BRP-era `char-sheet-logo.png` confirmed absent from disk
- Asset count: 28 files (rc.3) → 28 files (rc.4: -1 char-sheet-logo +1 elysium-logo)
- 0 non-retirement-comment references to `charSheetLogo` across all .mjs / .hbs / .json

### Behavioural impact

**For users browsing the Foundry package listing**:
- New brand art shows in the package thumbnail (gold ELYSIUM wordmark on dark, instead of the old "BASIC ROLE PLAYING" red text image)

**For users creating a fresh world**:
- No "Default" scene auto-creates on first load. Empty scene browser; users create their first scene normally.

**For users opening the Display Options settings menu**:
- "Character Sheet Logo" picker is no longer present. The other 14 display settings (font, colors, background, etc.) remain unchanged.

**For users with existing worlds**:
- F10 fixes preserved (sheet renders OK with malformed items)
- F8 fix preserved (magical recovery type persists)
- Optional Rules hint text continues to read "Configure optional Elysium rules" (rc.3 fix preserved)
- Any custom `charSheetLogo` value users had set in their world data remains in their world's settings store but no longer has any UI to edit it or any code path consuming it. Inert data, not a corruption risk.

**For the system itself**:
- Smaller install (~3.6 KB removed BRP-banner − 19.3 KB added new logo = net +15.7 KB, an acceptable trade for proper brand identity)
- One fewer esmodule loaded at startup (marginal startup-time improvement, no measurable difference in practice)

### Findings inventory at rc.4

| ID | Severity | Status |
|---|---|---|
| F1-F8 | Various | ✓ All fixed in c3/c4 |
| F9 | Low | ⏸ Deferred to v1.1.0 (L300 logic bug) |
| F10 | High | ✓ Fixed in rc.2 |
| **F11** | **Low** | ✓ **Fixed in rc.4 (dead `charSheetLogo` setting + `context.logo` line + lang keys + file-picker UI + BRP-era asset all retired together)** |

### P12 phase-plan release-prep task tracking — COMPLETE

| Task | Status |
|---|---|
| Audit `.css` rules for token-purity | ✓ c4 (alpha.54) |
| Light theme: retire entirely or keep as overlay? | ✓ **rc.4: retired (decided by inaction across 24 alphas)** |
| Replace placeholder logos with finalized brand art | ✓ **rc.4 (user-provided art ingested)** |
| Final i18n string review for "BRP" residue | ✓ rc.3 |
| Final asset audit — delete unused | ✓ rc.3 + rc.4 (char-sheet-logo.png retired) |
| Final changelog entry: `[1.0.0]` consolidated release notes | ✓ rc.3 (pre-composed); rc.4 (Gate 1+2 narrative updated) |

**All 6 P12 release-prep tasks closed.** v1.0.0 is fully ready for the final tag when rc.X holds clean.

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **Version reports correctly**: `game.system.version === '1.0.0-rc.4'`
2. **New logo asset present**: fetch `systems/elysium/assets/elysium-logo.webp` → 200 OK
3. **Old logo asset retired**: fetch `systems/elysium/assets/char-sheet-logo.png` → 404
4. **Auto-scene-creator gone**: open Scenes browser on the test world → no "Default" auto-creation pattern; existing scenes preserved
5. **charSheetLogo setting retired**: open Display Options settings menu → "Character Sheet Logo" picker is NOT present
6. **F10 regression preserved**: create skillcat without BRP-ID metadata, render sheet → no throw
7. **F8 regression preserved**: increment fatigue with `'magical'` → `recoveryType === 'magical'`
8. **Console health**: zero new console errors during world ready + sheet render

### Next milestone

**v1.0.0-rc.4 is the candidate**, and it's the candidate where **every documented P12 task is closed**. If rc.4 holds clean in the validation window, the path to tagging v1.0.0 is straightforward: drop the `-rc.4` suffix, fold the consolidated release notes draft into the GitHub release page + Foundry package listing, publish.

If new F-class issues surface during validation → rc.5 (same hotfix pattern as rc.1→rc.2). But with all P12 documented tasks closed, the surface for surprises is narrower.

---

## [1.0.0-rc.3] — P12 release-prep completion: BRP residue sweep + unused asset retirement + consolidated release notes pre-composition

Per the P12 phase plan exit criteria, three documented release-prep tasks were folded into the v1.0.0 ship narrative but never executed during alpha.51-54 cluster shipping. rc.3 closes the gap during the rc validation window — addressing them now while waiting for rc.X to hold clean is more honest than tagging v1.0.0 with the documented tasks still pending.

### Task 1: BRP residue sweep — final i18n string review

Per P12 phase plan: *"Final i18n string review for BRP residue."* The 0.x system was "Elysium BRP" — a BRP-flavored fork. v1.0.0 dropped that identity to become "Elysium". Any user-facing string still saying "BRP" is residue from the rename.

**Audit methodology**: Distinguished between:
- **BRP-ID** (`BRP-ID`, `BRPID`) — legitimate cross-pack identity-system jargon, retained intentionally (it's the namespace name; renaming it would be invasive churn for no benefit)
- **BRP standalone** — residue from the v0.x identity

**Audit results**:
| Surface | BRP standalone | BRP-ID jargon |
|---|---|---|
| `lang/en.json` value strings | 1 | 0 |
| `lang/es.json` value strings | 1 | 0 |
| `lang/fr.json` value strings | 1 | 0 |
| `lang/*.json` key names | 0 | 0 |
| `template.json` | 0 | 0 |
| `.hbs` templates | 0 user-visible (3 historical comments in `npcV2.main.hbs` documenting v0.20.0 BRP-classic system removal — retained as honest historical record; 2 in `elysiumid-settings.hbs` are BRPID setting flag names, not user-facing) | (multiple, retained) |
| `system.json` description / title | 0 | 0 |

**Single residue string identified and fixed** in 3 languages:
- key: `Elysium.Settings.optionalRulesHint`
- en: `"Configure optional BRP rules"` → `"Configure optional Elysium rules"`
- es: `"Configurar reglas BRP opcionales"` → `"Configurar reglas Elysium opcionales"`
- fr: `"Configurer les règles optionnelles de BRP"` → `"Configurer les règles optionnelles d'Elysium"`

The setting page (toggles for sanity, resistance, skill bonus, fatigue, luck, reputation, etc.) configures **Elysium-specific rules** — not "BRP rules". The v0.x hint string had carried the legacy framing through 23 alphas of refactoring. Now caught and corrected.

**Verification**: post-fix re-grep returns 0 user-facing BRP-residue lines across all 3 lang files.

### Task 2: Final asset audit — retire unused files

Per P12 phase plan: *"Final asset audit — delete unused (parchment.webp, dark_parchment.webp, old logos)."* The plan flagged specific suspects, but the audit measured live usage rather than trusting the plan's speculation.

**Audit methodology**: For each of 32 files in `assets/`, search the entire corpus (389 files across `.mjs`, `.hbs`, `.css`, `.json`, `.md`) plus the compendium pack contents for any reference to the filename. Files with zero references retire; files with references stay.

**Audit results contradicted the P12 plan's named candidates**:
- `parchment.webp` — **7 active references**, used as decorative surface background. Kept.
- `dark_parchment.webp` — **3 active references**, used as decorative dark variant. Kept.
- `char-sheet-logo.png` — **5 active references**. Kept.

The P12 plan's speculation that parchment files would be unused was incorrect — they ended up retained as visual identity. Honest record: keep.

**4 genuinely unused assets retired** (total ~4.6 KB):
- `assets/Icons/cowled.svg` (1,017 bytes) — no references in code, templates, CSS, JSON, or compendium pack
- `assets/Icons/inverse-aura.svg` (1,717 bytes)
- `assets/eye-green.svg` (919 bytes)
- `assets/eye-red.svg` (992 bytes)

**Final asset count**: 32 → 28 files. All 28 remaining assets verified in active use.

### Task 3: Consolidated `[1.0.0]` release notes — pre-composition

Per P12 phase plan: *"Final changelog entry: `[1.0.0]` consolidated release notes."* This is the user-facing release-notes summary for the eventual v1.0.0 final tag — the document that goes on the GitHub release page, Foundry package listing, and announcement post. It summarizes 5 months of phased rebuild into release narrative.

Rather than ship this as a CHANGELOG entry (which would prematurely claim v1.0.0 status while we're still in rc.X validation), it ships as **`docs/v1.0.0-release-notes-draft.md`** (175 lines). The document is pre-composed and ready to fold into the GitHub release page when the final v1.0.0 tag ships.

**Document contents**:
- Project introduction (what Elysium is)
- "Headline features" section (identity rebuild, sheet architecture, chat-card system, generic dialogs, i18n, optional rules, combat surface, magic system × 4 schools, character creation, stat improvement, API surface)
- "What's NOT in 1.0.0" section (v1.1.0 deferred backlog — F9, 31 Category B sites, 214 color literals, 58 inline-style sites, stub-gap, API docs, combat tracker, statistics-tab redesign, bio CRUD migration, magic-grid redesign, wound-badge tiers)
- Compatibility & requirements
- Migration from v0.x (intentional architectural break, three paths documented)
- Credits + Distribution + Known issues + Looking forward to v1.1.0

**This document fixes the v1.0.0 ship-narrative ambiguity**: rather than scattering the release-narrative across 30+ alpha CHANGELOG entries, the user-facing summary is one document, pre-composed against the actual surface that v1.0.0 ships with.

### Ship contents

| File | Change |
|---|---|
| `lang/en.json` | 1 string corrected (`optionalRulesHint` BRP → Elysium) |
| `lang/es.json` | 1 string corrected (same) |
| `lang/fr.json` | 1 string corrected (same) |
| `assets/Icons/cowled.svg` | DELETED (orphan) |
| `assets/Icons/inverse-aura.svg` | DELETED (orphan) |
| `assets/eye-green.svg` | DELETED (orphan) |
| `assets/eye-red.svg` | DELETED (orphan) |
| `docs/v1.0.0-release-notes-draft.md` | NEW (175 lines, pre-composed release notes) |
| `system.json` | version bump rc.2 → rc.3 |
| `CHANGELOG.md` | this rc.3 entry |
| `ROADMAP-v1.0.0.md` | rc.3 transition entry |

**No code changes** (no .mjs touched). **No CSS changes**. **No template changes**. **No new lang keys** (3 existing values corrected in place).

### Pre-flight sweep — clean

- JSON parses 5/5 (system.json + 3 lang + template.json)
- Lang counts unchanged from rc.2 (en=1347, es=1351, fr=1351; structural gap 0)
- BRP residue final sweep: 0 user-facing BRP-residue lines across all 3 lang files
- Assets: 32 → 28 (4 orphans retired, all 28 remaining verified in-use)
- CSS brace balance unchanged across all stylesheets (446/3/85/1/17/20/5/507/148)
- F10 fix preserved (no .mjs changes in rc.3)

### Behavioural impact

**For users**:
- Optional Rules settings menu now reads "Configure optional Elysium rules" (was "Configure optional BRP rules"). Identical functionality, cleaner identity.
- No other user-visible change.

**For the system**:
- ~4.6 KB smaller download (4 unused SVGs removed)
- Otherwise identical to rc.2 (F10 fixes preserved, all P12 c1-c4 work intact)

**For module developers**:
- No API surface change. All `game.system.api.*` subsurfaces unchanged.

**For translators (future v1.1.0 work)**:
- The 1 corrected key (`optionalRulesHint`) means future stub-gap detection won't flag it as English-fallback any more (was previously: en="...BRP rules", es="...BRP opcionales", fr="...BRP" — all containing "BRP" but in different positions; not byte-equal so not detected as stub). All 3 langs now use proper localized strings without "BRP".

### Findings inventory at rc.3

| ID | Severity | Status |
|---|---|---|
| F1 | Medium | ✓ Fixed in c3 (verified live) |
| F2 | Medium | ✓ Fixed in c4 (verified live) |
| F6 | Low | ✓ Fixed in c3 |
| F7 | High | ✓ Fixed in c3 (verified live) |
| F8 | Medium | ✓ Fixed in c4 (verified live) |
| F9 | Low | ⏸ Deferred to v1.1.0 |
| F10 | High | ✓ Fixed in rc.2 (verified live with regression test) |

No new findings in rc.3.

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **BRP residue removal**: open Optional Rules settings menu → verify hint text reads "Configure optional Elysium rules" (or localized equivalent)
2. **Asset deletion safe**: no console errors about missing asset files (404s on the 4 deleted SVGs would surface as network errors)
3. **F10 regression unchanged**: create skillcat without BRP-ID metadata, render sheet → no throw (same test as rc.2)
4. **F8 regression unchanged**: increment fatigue with `'magical'` recovery → `recoveryType === 'magical'`
5. **Console health**: zero new console errors

### P12 phase plan tasks — now complete

Three exit-criteria tasks documented at P12 phase plan completion now closed:
- [x] Audit remaining `.css` rules for token-purity → c4 (alpha.54)
- [ ] Light theme: retire entirely or keep as token-overlay? → Open question, not yet decided (v1.1.0)
- [ ] Replace placeholder logos with finalized brand art → user-provided art still pending
- [x] Final i18n string review for "BRP" residue → rc.3 (this ship)
- [x] Final asset audit → rc.3 (this ship)
- [x] Final changelog entry: `[1.0.0]` consolidated release notes → rc.3 (pre-composed at `docs/v1.0.0-release-notes-draft.md`)

**4 of 6 P12 release-prep tasks closed.** The 2 remaining (light theme decision + brand-art logos) are decision-gates / external-input-gates rather than executable work; they can close either during rc.X validation window if decisions arrive, or fold into v1.0.0 final tag if explicitly waived, or defer to v1.1.0.

### Next milestone

**v1.0.0-rc.3 is the candidate.** Validation window continues. The decision-gates above (light theme + logos) can resolve in either direction without ship work:
- If light theme retired + placeholder logos kept → tag v1.0.0 as-is when validation clean
- If user provides brand-art → fold into rc.4 + tag v1.0.0
- If light theme decision deferred → tag v1.0.0 with "light theme: deferred" note in release notes

The release-narrative ambiguity from P12 phase plan is closed by this ship. The remaining v1.0.0 path is fully scoped.

---

## [1.0.0-rc.2] — Hotfix: F10 defensive sweep across sheet + drop-handler surface (rc.1 sheet-render blocker)

**Hotfix candidate.** rc.1 surfaced a release-blocker within minutes of install — `ElysiumCharacterSheet._prepareItems` throws on actors containing any item without BRP-ID metadata (`TypeError: Cannot read properties of undefined (reading 'elysiumidFlag')` at character.mjs:932). Character sheet cannot render. This is exactly what the Release Candidate window exists to surface, and the validation methodology delivered as designed.

### Finding F10: scope significantly larger than F2's accounting

The c3 acceptance pass found F1 (1 site in actor.mjs prepareData) and named F2 as "19 sibling sites in actor-itemDrop.mjs". c4 measured F2 live and found 22 sites. **rc.1 install discovered a far larger pattern**: 94 brittle `.flags.elysium.elysiumidFlag` accesses across 14 module files, of which 50 sites in 13 files are downstream consumers needing defensive guards.

**Root cause of the scoping miss**: c3's acceptance methodology measured prepareData crashes (which surfaced F1 in actor.mjs and would have surfaced F2 in actor-itemDrop.mjs had it been on the prepareData path) — but did NOT measure sheet rendering with malformed items. The c4 bridge acceptance pass also missed it because the test world used compendium-imported items which always have BRP-ID metadata. **The blocker pattern is: any user creates an item manually via the items tab without routing through the BRP-ID system (e.g. creating a skillcat from the actor sheet's items panel) → that item lacks metadata → sheet render throws.**

### Scope of F10 hotfix

**Category A — Downstream consumers patched (50 sites across 13 files):**

| File | Sites | Strategy |
|---|---|---|
| `module/actor/sheets/character.mjs` | 6 | Defensive guard on weapon skill1/skill2 filter (L872-873); early-skip-on-no-BRP-ID guard in skillcat processing (L932-940, the actual rc.1 crash site) |
| `module/actor/actor.mjs` | 2 NEW | Defensive guard on L587 (fromCompendium dup check); defensive guard on L650 (skillcat seed in actor create) |
| `module/actor/actor-itemDrop.mjs` | (already patched in c4) | 22 sites patched in c4; no new work here |
| `module/item/sheets/career.mjs` | 8 | Early-skip-on-no-BRP-ID guard at top of drop loop — makes all 8 subsequent reads safe-by-construction |
| `module/item/sheets/culture.mjs` | 6 | Early-skip guard (same pattern as career) |
| `module/item/sheets/personality.mjs` | 6 | Early-skip guard (same pattern as career) |
| `module/item/sheets/skill.mjs` | 2 | Early-skip guard (same pattern as career) |
| `module/item/sheets/super.mjs` | 2 | Early-skip guard (same pattern as career) |
| `module/apps/check.mjs` | 1 | Defensive guard on First-Aid BRP-ID equality check |
| `module/combat/damage.mjs` | 6 | NO FIX NEEDED — all 6 are string-literal flag paths inside `update()` calls. Foundry's update API handles path creation natively. Safe-by-API. |
| `module/actor/sheets/base-actor-sheet.mjs` | 3 | NO FIX NEEDED — same as damage.mjs, string-literal update paths |
| `module/casting/spell-learning.mjs` | 2 | NO FIX NEEDED — L63 already has upstream defensive `?.` chain + `&&` short-circuit |
| `module/apps/select-lists.mjs` | 2 | NO FIX NEEDED — both pull from `fromElysiumIDRegexBest` which guarantees BRP-ID metadata; safe-by-construction |
| `module/item/item.mjs` | 1 | NO FIX NEEDED — string-literal update path |

**Actual code-level brittle sites patched: 33 across 8 files.** The remaining 17 sites are safe-by-API (Foundry `update()` paths), safe-by-construction (downstream of BRP-ID resolution), or pre-existing defensive (already optional-chained).

**Category B — elysiumid internals reviewed, NOT patched (31 sites across 2 files):**

The BRP-ID system itself (`module/elysiumid/elysiumid.mjs`, `elysiumid-editor.mjs`) operates on items it produced or is in the process of writing flags to. Sample inspection (L118 of elysiumid.mjs): the `found` array comes from `fromElysiumIDRegexBest` which by contract only returns items with valid `elysiumidFlag.id`. Internal accesses are safe-by-construction (producer contract). **These sites remain brittle by design** — patching them would add defensive overhead to the system that owns the data. Documented for v1.1.0 review if any user-supplied path is discovered to reach them.

### Defensive patterns applied

Three pattern groups, matching c4's F2 vocabulary:

**Pattern A — Filter expression with downstream comparison (1 site in character.mjs L872-873)**:
```js
// Before:
skill1Select = skills.filter(nitm => nitm.flags.elysium.elysiumidFlag.id === itm.system.skill1)[0]
// After:
skill1Select = skills.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === itm.system.skill1)[0]
```

**Pattern B — Sheet processing block (character.mjs skillcat handler L932-940)**: early-skip with `continue` before any flag access. Same as the c4 Pattern C used in actor-itemDrop.mjs L546.

**Pattern C — Drop handler loop (career.mjs, culture.mjs, personality.mjs, skill.mjs, super.mjs)**: early-skip at top of `for (const item of dataList)` loop with user-facing warning notification. Items lacking BRP-ID can't be assigned to careers/cultures/personalities/super-skills because there's no resolution path — refusing the drop with a notification is the correct behavior.

**Pattern D — Direct comparison guard (apps/check.mjs L130, actor.mjs L587)**: optional-chain on the read side of an equality check.

### Why F10 wasn't caught earlier

The c3 cumulative acceptance pass was designed to surface prepareData crashes — and it succeeded at that (F1 in actor.mjs). But it explicitly used compendium-imported items, which have BRP-ID metadata by construction. **The acceptance pass methodology had a gap**: it didn't include a "user creates item manually via items tab" probe.

The c4 bridge acceptance pass had the same gap. The post-c4 live-verify cycle (V3 in the alpha.54 verification) DID exercise programmatic item create without BRP-ID — but only against the prepareData path (`actor.mjs` defensive guard from F1) — not against the sheet render path. The c4 V3 succeeded because actor.mjs was already patched; F10's sheet-side crash site was downstream.

**The rc.1 install was the first time** anyone rendered a character sheet for an actor with a programmatically-created item lacking BRP-ID metadata. The combination of conditions surfaced F10 immediately.

### Methodology improvement for future cycles

For future cumulative acceptance + Release Candidate validation:
1. **Add "manual item creation via UI" to acceptance probe sets** — this is distinct from compendium-import and from programmatic-create-with-BRP-ID
2. **Render character sheet AFTER each manual-creation probe** to catch sheet-render breaks
3. **Bridge tests should explicitly cover the sheet render path** with non-compendium items
4. **Audit-pattern grep** when applying defensive sweeps: don't trust the audit's named-site count; re-grep the entire codebase for the brittle pattern

### Ship contents

| File | Change |
|---|---|
| `module/actor/sheets/character.mjs` | 8 LOC defensive guard + early-skip (the rc.1 crash site fix) |
| `module/actor/actor.mjs` | 2 sites optional-chained (L587, L650) |
| `module/item/sheets/career.mjs` | 5 LOC early-skip guard at drop-loop top |
| `module/item/sheets/culture.mjs` | 5 LOC early-skip guard (same) |
| `module/item/sheets/personality.mjs` | 5 LOC early-skip guard (same) |
| `module/item/sheets/skill.mjs` | 5 LOC early-skip guard (same) |
| `module/item/sheets/super.mjs` | 5 LOC early-skip guard (same) |
| `module/apps/check.mjs` | 1 line optional-chain on First-Aid equality check |
| `system.json` | version bump rc.1 → rc.2 |
| `CHANGELOG.md` | this rc.2 hotfix entry |
| `ROADMAP-v1.0.0.md` | rc.2 hotfix entry + F10 finding documented |

**Total LOC delta**: ~36 lines added across 8 files. No CSS changes, no template changes, no lang changes, no compendium changes.

### Pre-flight sweep — clean

- `node --check` OK on all 8 modified .mjs files + spot-checks on the unmodified critical files (init, magic, elysium, fatigue-manager)
- JSON parses 5/5 (system.json + 3 lang + template.json)
- CSS brace balance unchanged (no CSS changes in rc.2)
- Lang counts unchanged from rc.1 (en=1347, es=1351, fr=1351)
- Final brittle-site count after F10: real code-level brittle accesses = 0 (excluding elysiumid internals which are safe-by-construction by producer contract)

### Behavioural impact

**Items WITH BRP-ID metadata** (compendium imports, programmatic creates that route through BRP-ID system): identical behavior. The optional-chain evaluates to the same value.

**Items WITHOUT BRP-ID metadata** (manual items-tab creation, programmatic creates without metadata):
- **Sheet render**: no longer throws; the skillcat is silently skipped from the displayed skills list (it remains an item on the actor but isn't categorized)
- **Drop on career/culture/personality/skill/super sheets**: rejected with a user-facing warning notification rather than throwing
- **Drop on actor (actor-itemDrop.mjs path)**: already handled in c4; no change
- **First-Aid skill resolution in check.mjs**: silently skipped (no first-aid bonus applied for skills lacking BRP-ID) rather than throwing

**No data corruption risk**: F10 patches are all read-side defensive guards. No item structure or actor data is modified by the patches.

### Findings inventory at rc.2

| ID | Severity | Status |
|---|---|---|
| F1 | Medium | ✓ Fixed in c3 (actor.mjs:177) |
| F2 | Medium | ✓ Fixed in c4 (22 sites in actor-itemDrop.mjs) |
| F6 | Low | ✓ Fixed in c3 (3 lang files) |
| F7 | High | ✓ Fixed in c3 (fatigue increment/decrement) |
| F8 | Medium | ✓ Fixed in c4 (helper vocab aligned to schema) |
| F9 | Low | ⏸ Deferred to v1.1.0 (L300 logic bug, behavioural change risk) |
| **F10** | **HIGH** | ✓ **Fixed in rc.2 (sheet render + drop-handler defensive sweep across 8 files)** |

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **Regression test for rc.1 blocker**: create a fresh character; programmatically create a skillcat without BRP-ID metadata; render the sheet → expect no error, expect skillcat to NOT appear in skills list
2. **Compendium-import path unchanged**: import a skillcat from compendium; render sheet → expect skillcat to appear in skills list with proper category
3. **Drop handler defensive paths**: drop a malformed skill onto career sheet → expect warning notification, expect graceful rejection
4. **F8 still works**: increment fatigue with `'magical'` recovery type → expect `recoveryType === 'magical'`
5. **Console health**: zero new console errors during above flows

### Next milestone after rc.2

**If rc.2 holds clean in validation window** → tag v1.0.0 (drop `-rc.2` suffix). If F10-class issues continue surfacing → rc.3 (or as needed). The validation window's purpose is exactly this — surfacing bugs that test-world acceptance methodology missed.

The rc.1→rc.2 transition is **not a sign of project failure** — it's the Release Candidate methodology delivering its intended value. Shipping rc.1 with the bug-then-rc.2-fix is far preferable to shipping v1.0.0 with the bug.

---

## [1.0.0-rc.1] — Release Candidate 1: v1.0.0 surface complete, alpha track closes

**Milestone ship.** v1.0.0 leaves the alpha track and enters Release Candidate. P5 through P12 (24 alphas across 5 months of phase-driven development) is complete. The v1.0.0 surface is stable and feature-complete for the planned 1.0.0 release.

### What rc.1 is

A **release-candidate** alpha — the system code is identical to alpha.54 except for the version string. The intent: validate at this candidate version with the wider audience (vs. test-world-only at alpha.54) before tagging the final v1.0.0. If issues surface during the rc.1 window, rc.2 / rc.3 / etc. address them; if rc.1 holds clean, v1.0.0 ships unchanged.

### Cumulative scope of v1.0.0 (the 24-alpha + rc.1 journey)

**Identity rebuild** (P5-P6): `system.id` renamed from BRP-era to `elysium`; i18n namespace migration (1346 keys); template structure rebuilt from scratch (53 registered partials); Foundry V14 ApplicationV2 + DataModelV2 architecture adopted; legacy `<form>`-based handlers retired.

**Sheet rebuild** (P7-P9): character + NPC sheet rebuilt as Handlebars + ApplicationV2; 23 item types operational each with their own sheet class; tab structure rebuilt (combat / items / social / pers / statistics / background / dev + magic family tabs activated automatically); Coinage card + Armor card + Gear card + Allegiance/Reputation/Passion rows + Personality Trait row all built as reusable partials.

**Chat-card system** (P10-P11): 11 distinct chat-card templates rebuilt onto a cluster-1 partial vocabulary (chat-card-shell, chat-card-participant-row, chat-card-success-pip, chat-card-tooltip-rows, chat-card-resolve-footer, chat-card-grouproll, chat-card-actor-list). Phase-D injection contract preserved. Audit-5 class hook lock list (~30 hooks) preserved verbatim through 23 alphas of refactoring.

**Generic dialogs** (P11 cluster 5): 10 dialog templates onto a shared dialog-row partial — selectPower, getValue, hitLocChoice, skillSelect, newWound, treatWound, difficulty, damageDiff, selectItem, npcTokenCreate.

**Polish + acceptance** (P12 — closed at alpha.54): mechanical CSS + attribute cleanup (data-handle-change retired, darkred retokenned, legacy.css orphan sweep -35%, brace-badge inline-style retired); inline-HTML ChatMessage.create migration (45 callsites across 19 module files → 3 archetypal partials chat-card-notice/roll/prompt); lang completion (412 translations for es/fr — structural gap 0); cumulative acceptance pass surfacing 4 latent bugs all fixed in-cluster; color literal retoken + actor-itemDrop defensive pass + fatigue recovery type vocab alignment.

**Final mechanical state at rc.1**:
- 23 item types (gear, skill, hit-location, personality, career, arcane, divine, mysticism, mutation, sorcery, super, failing, powerMod, armor, weapon, wound, allegiance, passion, ability, persTrait, reputation, skillcat, culture)
- 2 actor types (character, npc)
- 1347 i18n keys in en.json, 1351 in es.json + fr.json (structural gap 0)
- 53 registered template partials
- 9 CSS files in the styles/ pipeline + legacy.css for the long tail
- 113 + 10 (c4 additions) = 123 design tokens in the `--ely-*` namespace
- 22 API subsurfaces on `game.system.api.elysium.*`
- 35+ casting methods on `game.system.api.casting.*`
- ~30 audit-5-locked class hooks + 4 alpha.52 D6 attribute family names preserved verbatim through the entire rebuild

### Bridge-runnable acceptance pass results (post-c4, pre-rc.1)

Per `docs/v1.0.0-acceptance-manual-categories-bridge-pass.md`: a comprehensive functional-correctness pass across the 10 deferred-MANUAL categories (chat-card surface, 10 dialogs, engagement mechanics, charge+knockback, casting × 4 schools, stat improvement, stat advance, wear/wound, critical+luck, passive defense). **66 tests across 10 categories. 66/66 PASS. Zero new bugs surfaced. Zero console errors.**

The functional gate is clean. The human-play-through gate (UX, multi-user/GM-approval flows, visual judgment, gameplay gestalt) is **explicitly waived per user decision** in favor of validating these aspects during the rc.1 window with real users.

### Findings closed at rc.1

| ID | Severity | Cluster | Status |
|---|---|---|---|
| F1 | Medium | c3 (alpha.53) | ✓ Fixed — actor.mjs:177 defensive optional-chain |
| F2 | Medium | c4 (alpha.54) | ✓ Fixed — 22 brittle sites in actor-itemDrop.mjs patched |
| F6 | Low | c3 (alpha.53) | ✓ Fixed — Elysium.WhatCopiedClipboard added to en/es/fr |
| F7 | **High** | c3 (alpha.53) | ✓ Fixed — fatigue-manager increment/decrement reference undefined `current` |
| F8 | Medium | c4 (alpha.54) | ✓ Fixed — _worstRecoveryType vocab aligned to schema `['physical', 'magical']` |
| F9 | Low | c4 (alpha.54) | ⏸ Documented in-code at L300; deferred to v1.1.0 (logic bug, behavioural change risk needs impact analysis) |

### Out-of-scope work documented for v1.1.0

- **F9**: actor-itemDrop.mjs:L300 logic bug (filter result always truthy)
- **214 remaining color literals** in `styles/elysium.css` — true one-offs after c4 retoken
- **58 inline-style anti-pattern sites** in .mjs files — covering-stance (14), combat-card-buttons (8), combat-tab (8), outmanoeuvre (6), etc.
- **3 rgba + 7 hex literals** in `styles/elysium-sheets.css` — small island
- **API reference documentation** — bridge pass surfaced 22 elysium subsurfaces + 35+ casting methods; would benefit from systematic developer-facing docs
- **Stub-gap completion** for es/fr (167-223 strings byte-equal to en — most are the c2-deferred Chat.* stubs and TYPES.* labels)
- **Combat-tracker visual misalignment** (cluster-7 F1)
- **Manual play-through validation** — categories deferred from acceptance now run during rc.1 window with real users

### Distribution metadata for v1.0.0 release

| Field | Value |
|---|---|
| system.id | `elysium` |
| version | `1.0.0-rc.1` |
| title | Elysium |
| compatibility.minimum | Foundry V14 |
| compatibility.verified | V14.360 |
| compatibility.maximum | V14 |
| manifest URL | `https://github.com/Elysiumvtt/ElysiumBRP/releases/latest/download/system.json` |
| download URL | `https://github.com/Elysiumvtt/ElysiumBRP/releases/latest/download/system.zip` |
| compendium packs | 1 (alpha.3 unchanged) |
| authors | Elysium Project |

### Ship contents

| File | Change |
|---|---|
| `system.json` | version bump alpha.54 → rc.1 (single field change) |
| `CHANGELOG.md` | this rc.1 milestone entry |
| `ROADMAP-v1.0.0.md` | rc.1 transition entry + P12-tracker-closed reaffirmed |
| `docs/v1.0.0-acceptance-manual-categories-bridge-pass.md` | NEW — 225-line bridge acceptance pass results (delivered earlier) |

**No code changes** beyond the version string. **No template changes. No CSS changes. No JS changes. No lang changes.** The system code at rc.1 is byte-identical to alpha.54 except for the `system.json` version field.

### Pre-flight sweep — rc.1 readiness gate

All checks pass at the alpha.54 baseline; the version-only change preserves them:
- JSON parses on all 5 (system.json + 4 lang files including template.json)
- Lang structural gap 0 for both es and fr
- JS parse OK on critical .mjs files (actor.mjs, actor-itemDrop.mjs, fatigue-manager.mjs, magic.mjs, elysium.mjs, init.mjs)
- CSS brace balance preserved across all 9 stylesheets (elysium 446/446, tokens 3/3, chat 85/85, tracker 1/1, base 17/17, components 20/20, reset 5/5, sheets 507/507, legacy 148/148)
- 53 template partials registered in init.mjs
- 1 compendium pack declared and present (alpha.3)
- Compatibility metadata: V14 minimum / V14.360 verified / V14 maximum
- Distribution metadata: title / description / manifest URL / download URL / authors all set

### What rc.1 validation looks like

**During the rc.1 window** (between this ship and the v1.0.0 final tag):
- Wider distribution beyond the test world — actual GMs running sessions
- The deferred c3 MANUAL categories get validated in real play: combat flow, casting flows × 4 schools, stat improvement with GM-approval, wear/wound application, critical+luck save, passive defense
- UX issues (button placements, label clarity, timing, multi-actor sequencing) that bridge tests can't catch surface here
- Visual judgment issues across the dark-bone-crimson identity surface
- Any v1.0.0-rc.1 → v1.0.0-rc.2 hotfix patches address what surfaces

**If rc.1 holds clean for the validation window**: tag v1.0.0 (drop the `-rc.1` suffix, no other changes), publish release notes, distribute.

**If rc.1 surfaces blockers**: rc.2 with hotfixes, repeat the window.

### v1.0.0 design milestones (retrospective)

| Phase | Span | Key deliverable |
|---|---|---|
| P5 | alpha.24-alpha.27 | System identity rebuild — `elysium` system-id, i18n namespace migration |
| P6 | alpha.28-alpha.31 | DataModel architecture — V14 ApplicationV2 + DataModelV2 |
| P7 | alpha.32 | Sheet shell rebuild — character + NPC ApplicationV2 sheets |
| P8 | alpha.33-alpha.36 | Item sheet rebuild — all 23 item types as their own sheet classes |
| P9 | alpha.37-alpha.40 | Character tab content rebuild — combat / items / social / pers / statistics / background / dev / magic-family tabs |
| P10 | alpha.41-alpha.44 | Chat-card foundation — Phase D injection contract, archetype-1 partials |
| P11 | alpha.45-alpha.49 | Chat-card finalization — 11 templates onto partials, dialog system |
| Hotfix | alpha.50 | Character sheet scroll + FA icon fixes |
| P12 | alpha.51-alpha.54 | Polish + acceptance — CSS cleanup, inline-HTML migration, lang completion, color retoken, defensive sweeps |
| **rc.1** | this ship | Version transition; rc validation window opens |

### Audit-5 lock list state at rc.1

All ~30 class hooks preserved verbatim through 23 alphas of refactoring + the 4 alpha.52 D6 attribute family additions (`data-elysium-charge-action`, `-cr-action`, `-kb-action`, `-om-action`). Plus the alpha.51 lock addition (`.elysium-brace-badge`). The lock list is the canonical contract between templates and JS-imperative DOM access — preserved as an explicit cross-cutting invariant through every cluster ship.

### Behavioural impact of rc.1 ship

**Zero behavioural change** vs alpha.54 — the system code is byte-identical. The only delta is the `version` field in `system.json`.

### Compendium

Unchanged at alpha.3. The compendium has been independently versioned from the system since P6; the system version transition does not require a compendium re-pack.

### Next milestone: v1.0.0 final

Gate: validation window on rc.1 clean. If blockers surface → rc.2 (or rc.3 / etc. as needed). When the candidate holds clean: tag v1.0.0 (no `-rc.X` suffix), drop the candidate distinction, publish release notes.

After v1.0.0: **v1.1.0** scope opens. Documented v1.1.0 candidates (from c4 and earlier audits): F9 logic-bug fix, 214 long-tail color literal review, 58 inline-style site retirement, sheet-level CSS island cleanup, stub-gap completion for es/fr, API reference documentation, combat-tracker visual misalignment fix.

---

## [1.0.0-alpha.54] — P12 cluster 4 (CLOSES P12): color literal retoken + actor-itemDrop defensive sweep + fatigue recovery type vocab alignment

P12-c4 ships. **Final cluster of P12.** Three independent work items per `docs/p12-c4-audit.md` D1 Option B, all sub-items completed in-cluster:

1. **F1' — color literal retoken (D2)**: 58 high-frequency color literals in `styles/elysium.css` retokenned via 10 new design tokens. 21% reduction in raw color load (272 → 214 literals).
2. **F2 — actor-itemDrop defensive sweep (D4)**: 22 brittle `.flags.elysium.elysiumidFlag` accesses guarded with optional-chain or post-population writes. Closes the prepareData latent-bug discovery from c3.
3. **F8 — fatigue recovery type vocab alignment (D5)**: helper aligned to schema's `['physical', 'magical']` choices. Closes the silent-drop-of-magical-tag bug from c3 acceptance.

### Pre-cluster scope corrections from earlier audits

The c4 audit caught two measurement errors in prior audits:
- **F1' scope is ~2× larger than the c1 audit named**: c1 reported "130 rgba leaks" — but only counted rgba literals. Live measurement at alpha.53 found **272 color literals** (133 rgba + 139 hex) in elysium.css. Hex was never counted.
- **F2 count is 22, not 19**: c3 reported 19 brittle sites — but the regex undercounted multi-access lines that have both defensive AND brittle patterns on the same line (L393, L633). Live count is 22.

### F1' — color retoken methodology (D2 strategy B)

Audit D1 locked **Strategy B**: tokenize the top high-frequency color bases; long-tail literals stay as literals. A maximalist retoken (Strategy A) would have created 100+ new tokens for one-off values — bloating the token system without semantic benefit.

**10 new tokens added to `styles/elysium-tokens.css`** (~70 LOC including doc comments):

| Token | Value | Replaces literal | Occurrences | Semantic role |
|---|---|---|---|---|
| `--ely-accent-bronze-header` | `#5a3818` | `#5a3818` + harmonized `#5a2818` | 8 | Section header text (skill/magic/spec/spell/mysticism) |
| `--ely-accent-bronze-amber` | `#5a4a30` | `#5a4a30` | 4 | Muted secondary label color (addon costs, fieldset legends) |
| `--ely-accent-bronze-border` | `rgba(120, 70, 30, 0.3)` | `rgba(120, 70, 30, 0.3)` | 4 | Section card left/bottom rules |
| `--ely-accent-bronze-hover-bg` | `rgba(120, 50, 30, 0.10)` | `rgba(120, 50, 30, 0.10)` | 3 | Section header hover background |
| `--ely-accent-action-tint` | `rgba(136, 41, 41, 0.1)` | `rgba(136, 41, 41, 0.1)` | 2 | Remove-button base state background |
| `--ely-accent-action-tint-hover` | `rgba(136, 41, 41, 0.3)` | `rgba(136, 41, 41, 0.3)` | 3 | Remove-button hover state background |
| `--ely-accent-success-owned` | `#2a6a30` | `#2a6a30` | 3 | Tier-met / addon-owned indicator |
| `--ely-surface-tint-wisp` | `rgba(0, 0, 0, 0.03)` | `rgba(0, 0, 0, 0.03)` | 3 | Ultra-subtle row striping background |
| `--ely-surface-tint-subtle` | `rgba(0, 0, 0, 0.04)` | `rgba(0, 0, 0, 0.04)` | 3 | Subtle card background |
| `--ely-surface-border-shadow` | `rgba(0, 0, 0, 0.2)` | `rgba(0, 0, 0, 0.2)` | 6 | Input-wrapper card borders |

The accent-bronze cluster is organized in a new doc-commented section between the existing accent palette and the surface tints section. The new tokens follow the established `--ely-<category>-<HUE>[-<MOD>]` naming convention.

### F1' — design-identity harmonization (Q3 lock)

Per c4 audit Q3 Option A (recommended): retoken `#882929` ×9 to `var(--ely-accent-action)` (canonical project-crimson, `#8a2020`). Both hues were near-identical visually (off by 2/9/9 RGB units), but the codebase had drifted to having two project-crimson values. Now there's one canonical.

Visual delta: imperceptible (<2% perceived difference). All 9 sites continue to display as project-crimson.

### F1' — second-pass harmonization

After the primary 48-literal retoken, two more high-frequency near-matches were folded in:
- `#888` ×7 → `var(--ely-text-muted)` — `#888` (= `#888888`) is the rendered color for italic helper text, dashed-border placeholders, etc. `--ely-text-muted` is `#888880` (slight olive tint — imperceptible at UI sizes). Semantic alignment: both are "muted text".
- `#c44` ×3 → `var(--ely-accent-danger)` — `#c44` (= `#cc4444`) vs `--ely-accent-danger: #c44040`. Same near-identical visual relationship.

Together: 58 literals retokenned (48 from primary pass + 7 muted + 3 danger).

### F1' — long-tail accepted as literals

214 color literals remain in elysium.css after c4. The remaining landscape:
- 109 rgba (down from 133, -18%)
- 105 hex (down from 139, -24%)
- 193 distinct values, average 1.1 occurrences each — true one-offs

Per D3, these stay as literals. They're bespoke values used in single locations (specific gradient stops, single-rule colors). Tokenizing one-offs would bloat the token system without semantic benefit. The decision-cost of "should this be a token?" is documented in the c4 audit; per-rule context inspection during the c4 pass confirmed each remaining literal is genuinely a one-off.

### F2 — defensive sweep methodology (D4)

22 brittle sites in `module/actor/actor-itemDrop.mjs` patched per the c3 F1 defensive pattern (`itm.flags?.elysium?.elysiumidFlag?.id`). Sites grouped by access pattern:

**Pattern A — Filter expressions (11 sites)**: defensive guard added as upstream condition:
```js
// Before:
actor.items.filter(itm => itm.type === 'X' && itm.flags.elysium.elysiumidFlag.id === SOMETHING)
// After:
actor.items.filter(itm => itm.type === 'X' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === SOMETHING)
```
The inner brittle access is now safe-by-construction because the upstream `&&` short-circuits when the flag chain is missing. Sites: L62, L64, L68, L70, L106, L135, L155, L169, L183, L203, L300.

**Pattern B — Single reads on incoming drop (6 sites)**: optional-chain on direct read:
```js
// Before:
errMsg = nItm.name + "(" + nItm.flags.elysium.elysiumidFlag.id + "): " + ...
// After:
errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + ...
```
Sites: L101, L109, L138, L158, L172, L186, L206, L398 (right side of comparison).

**Pattern C — Iteration over collection (1 site, L546)**: explicit pre-filter on the loop:
```js
// Before:
for (let skillOpt of skillList) {
  selectOptions.push({ id: skillOpt.flags.elysium.elysiumidFlag.id, ... })
}
// After:
for (let skillOpt of skillList) {
  if (!skillOpt.flags?.elysium?.elysiumidFlag?.id) continue
  selectOptions.push({ id: skillOpt.flags.elysium.elysiumidFlag.id, ... })
}
```
The continue guard skips skills lacking BRP-ID metadata.

**Pattern D — Write to undefined (1 site, L580)**: explicit pre-population of flag structure:
```js
// Before:
newSkill.flags.elysium.elysiumidFlag.id = "i.skill." + ...   // throws if any intermediate is undefined
// After:
newSkill.flags = newSkill.flags || {}
newSkill.flags.elysium = newSkill.flags.elysium || {}
newSkill.flags.elysium.elysiumidFlag = newSkill.flags.elysium.elysiumidFlag || {}
newSkill.flags.elysium.elysiumidFlag.id = "i.skill." + ...
```
Can't optional-chain a write target; pre-create the intermediate dicts.

After all patches: **12 remaining `.flags.elysium.elysiumidFlag` direct accesses in the file**. Each is safe-by-construction (verified): inside a filter chain with upstream defensive guard, or after explicit structure-population for write targets. The pattern matches the pre-existing defensive sites at L398 and L647 that prior author had already added.

### F2 — new finding F9 surfaced during sweep (not fixed in c4)

While patching L300 defensively, a **pre-existing logic bug** was noticed:
```js
if (actor.items.filter(nitm => ...).length > 0) {   // probably what was intended
if (actor.items.filter(nitm => ...)) {                // what's actually written — always truthy
```

The `filter()` call returns an array. An array is always truthy in JS. The `if` condition is always `true`, so this code always takes the `continue` branch and never reaches `powerList.push`. This means **power-type items dropped through this path are never added to powerList**.

This is **F9**: pre-existing logic bug, separate from F2 scope. Adding `.length > 0` would fix it but is a behavioural change that needs testing (since the broken code path may have been broken long enough that other code now depends on it). **Documented but not fixed in c4.** Flagged in the in-code comment + this CHANGELOG entry. Routed for v1.1.0 or a future hotfix after impact analysis.

### F8 — recovery type helper vocab fix (D5)

`module/elysium/fatigue/fatigue-manager.mjs::_worstRecoveryType` aligned to the schema's `choices: ['physical', 'magical']` vocabulary (per c3 acceptance pass discovery + c4 audit D5 Option α):

```js
// Before (stale vocab from earlier design iteration):
const order = { asphyxiation: 0, physical: 1, bloodloss: 2 }

// After (schema-canonical):
const order = { physical: 1, magical: 2 }
if ((order[typeB] || 0) > (order[typeA] || 0)) return typeB
```

The `|| 0` defensive defaults handle any unrecognized values without throwing. This fixes the silent-drop of `'magical'` in the overcast path — overcast fatigue now correctly tags actors as `recoveryType: 'magical'` per the schema's design intent.

User impact: overcast caster fatigue is now distinguishable from physical fatigue in actor data. Recovery semantics that depend on `recoveryType` (if any downstream code branches on this) will now correctly differentiate. No visual change.

### Ship contents

| File | Change |
|---|---|
| `styles/elysium-tokens.css` | +10 new tokens (+70 LOC, in 2 new doc-commented sub-sections) |
| `styles/elysium.css` | 58 literal retokens; no structural changes; brace count 446/446 unchanged |
| `module/actor/actor-itemDrop.mjs` | 22 brittle sites patched (~40 LOC delta); 3 sites flagged with in-code comments for F9 routing + safe-by-construction documentation |
| `module/elysium/fatigue/fatigue-manager.mjs` | 5 LOC: `_worstRecoveryType` vocab aligned to schema |
| `docs/p12-c4-audit.md` | NEW (409 lines, c4 prep audit) |
| `system.json` | version bump alpha.53 → alpha.54 |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution log + P12 tracker closes |

### Pre-flight sweep — clean

- `node --check` OK on both modified .mjs files
- JSON parse OK on all 4 (system.json + 3 lang files)
- CSS brace balance: elysium 446/446 (unchanged), tokens 3/3 (unchanged — new content is INSIDE the existing `:root {}` block), chat 85/85 (unchanged), tracker 1/1 (unchanged)
- All 10 new tokens both defined AND referenced (0 dead tokens added)
- F2 final state: 12 remaining `.flags.elysium.elysiumidFlag` direct accesses, all safe-by-construction (verified individually)
- F8 helper vocab verified post-fix
- F1' color reduction: 272 → 214 literals (-21%)
- Lang counts unchanged from alpha.53 (en=1347, es=1351, fr=1351; structural gap 0)

### Behavioural impact

**F1' (color retoken)**:
- Visual delta: 58 sites now use tokens instead of literals; visually IDENTICAL because the tokens evaluate to the same color values
- 9 sites of `#882929` → `var(--ely-accent-action)`: visual delta of <2% (perceptually imperceptible) per Q3 harmonization
- 7 sites of `#888` → `var(--ely-text-muted: #888880)`: olive tint difference, imperceptible
- 3 sites of `#c44` → `var(--ely-accent-danger: #c44040)`: imperceptible
- No layout changes, no class hook changes

**F2 (defensive sweep)**:
- Items WITH BRP-ID metadata: identical behavior (the new optional-chain evaluates the same as the old brittle chain)
- Items WITHOUT BRP-ID metadata: were throwing `Cannot read properties of undefined`; now silently skip (filter excludes them; single reads return `undefined`; iterations `continue`)
- No change to compendium-imported items (they always have BRP-ID metadata)
- Programmatic item drops with malformed items no longer crash prepareData chain
- New finding F9 (logic bug at L300) documented but unchanged — bug-for-bug compatibility preserved pending impact analysis

**F8 (recovery type vocab)**:
- Magical fatigue from overcast now correctly tags actor as `recoveryType: 'magical'`
- All other fatigue paths (combat bleed, effort failure, manual, recovery) unchanged — they always passed `'physical'` and continue to
- No visual change in chat cards or sheets (recoveryType isn't visually surfaced anywhere in v1.0.0)

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **Color regression check** — open character sheet + 3 item sheets (skill, weapon, gear) → computed-style spot-check on retokenned selectors → confirm `border-left-color`, `background-color`, `color` resolve to expected RGB values
2. **F1' specific** — `.elysium-modifier-remove` background is `rgba(136, 41, 41, 0.1)` (now via `--ely-accent-action-tint`); `.elysium-skill-section` border resolves to `rgba(120, 70, 30, 0.3)` (now via `--ely-accent-bronze-border`)
3. **F2 specific** — create a malformed item without BRP-ID metadata, drop on actor, verify no console error and item-drop behavior is "skip" not "throw"
4. **F8 specific** — invoke overcast on a caster (push PP past limit) → verify `actor.system.fatigue.recoveryType === 'magical'` post-cast
5. **Console health** — zero new console errors during above flows

### Cluster-4 milestone — P12 CLOSES

P12 was originally a 3-cluster plan (per the prep audit). The c1 audit's F1 discovery (130-rgba leaks, later revised to 272 color literals at c4 baseline) drove the plan to grow to 4 clusters. After alpha.54:

- c1 (alpha.51) ✓ mechanical CSS + attribute cleanup — `data-handle-change` retired, `darkred` retokenned, brace-badge new file, 62 legacy.css orphans retired
- c2 (alpha.52) ✓ inline-HTML ChatMessage.create migration — 45 callsites onto 3 archetypal partials
- c3 (alpha.53) ✓ lang completion + cumulative acceptance — 412 translations, F1+F2+F6+F7 surfaced from acceptance pass
- c4 (alpha.54) ✓ THIS SHIP — color retoken + F2/F8 closure

**P12 polish + acceptance phase is complete.** v1.0.0 surface is stable for rc.1.

### Next: v1.0.0-rc.1

After alpha.54, the project moves to **v1.0.0-rc.1** (Release Candidate 1). Gate: human-run manual acceptance pass covering the deferred MANUAL categories from c3:
- Combat engagement mechanics, charge+knockback flow
- Arcane casting, divine/mysticism/sorcery casting
- Stat improvement GM-approval flow
- Wear/wound/temp-HP
- Critical + luck save dialog

If manual pass surfaces no blockers, rc.1 ships shortly after. If blockers surface, hotfix alpha (alpha.55 patch) before rc.1.

### Audit-5 lock list state

No new lock entries from c4 (it's CSS + JS bug-fix, not surface migration). The 10 new tokens are canonical color tokens; renaming them in future ships requires consumer-update sweep.

### Out-of-scope work documented but not addressed

- **F9** (L300 logic bug in actor-itemDrop.mjs) — pre-existing, documented in-code, routed for v1.1.0 or post-rc.1 hotfix after impact analysis
- **214 remaining color literals** in elysium.css — true one-offs per per-rule inspection; staying as literals; v1.1.0 polish could revisit
- **58 inline-style anti-pattern sites** in .mjs files (covering-stance, combat-card-buttons, combat-tab, outmanoeuvre) — flagged for v1.1.0 polish; not c4 scope
- **3 rgba + 7 hex literals in elysium-sheets.css** — small island, v1.1.0 polish candidate

---

## [1.0.0-alpha.53] — P12 cluster 3: lang completion (es/fr structural gap closed) + first cumulative acceptance pass

P12-c3 ships. Two parallel items per `docs/p12-c3-audit.md` D1 Option C: structural lang gap closed for es and fr (206 missing keys × 2 langs = 412 new translations) and the first cumulative behavioural acceptance pass since P5 opened (48 alphas of cumulative surface). Acceptance surfaced one latent prepareData bug (F1) which is fixed in this ship; 19 sibling sites are flagged for alpha.54 (F2).

### Lang completion

The 206-key structural gap that accumulated across P5-P12 in es and fr was closed in c3. Translations were applied directly using the domain glossaries in `docs/i18n-glossary-{es,fr}.md`. Approach per c3 audit D2: glossary-driven translation with Mythras-fr / RuneQuest-es conventions where they exist, neutral mechanical-rulebook register, all `{placeholder}` substitution tokens and HTML markup preserved verbatim.

**By-namespace coverage**: Fatigue (24 keys including 10 level labels per Mythras canon), Settings (22 hint+label pairs), Ancestry (17 including the Replace dialog warning text), Stats (15 including `{stat}`-placeholder messages), Gear (11), Luck (11), Arcane (10), Magic (9), Armor (8), Skill (8), Ability (6), Modifiers (6), Critical (5), Divine (5), Weapon (5), plus 47 misc.

**Convention preservation**: stat abbreviations (STR, CON, SIZ, INT, POW, DEX, CHA, EDU) preserved as-is in both target langs — universal across Spanish and French TTRPG editions of Mythras, RuneQuest, and Call of Cthulhu.

**Lang state at alpha.53**: en=1347 keys, es=1351 keys, fr=1351 keys. The 4-key delta is pre-existing legacy keys (`Elysium.beastiaryMode`, `beastiaryOff`, `beastiaryOn`, `gameModifiers`) — present in es/fr from prior version, not in en. Documented as pre-existing condition; not a c3 issue.

**Stub gap remaining**: per c3 audit Option C scope, the ~167 (es) / ~223 (fr) stub keys (keys present in target lang but byte-identical to en) were **deferred to a future cluster**. Of those stubs:
- ~27 are convention-correct as English-equal (21 empty-string ChaosiumCanvasInterface hint slots + 6 stat abbreviations)
- 86 are the Elysium.Chat.* stubs added in alpha.52 (c2 deliberately deferred to c3 per c2 Q1)
- ~110 are TYPES.* + ElysiumIDFlag.* + misc (translate-or-keep judgment per key)

Of the remaining 86 Chat.* stubs, the strongest case for inclusion was made in c3 audit Q2 (`proceed +chat` override path); the locked Option C scope was to handle structural gap first. The Chat.* stubs are tractable in any future ship.

### Acceptance pass

First cumulative end-to-end behavioural acceptance pass since P5 opened. The 16-category, 95-check checklist in `docs/v1.0.0-acceptance-checklist.md` was executed against alpha.52 via Chrome bridge automation (AUTO categories) with manual flags for combat/casting/dialog-driven categories.

**AUTO results (56 individual checks across 8 categories)**: **56 passes / 0 failures**.

| Category | Checks | Status |
|---|---|---|
| 1. Actor sheet rendering | 4/4 | ✓ |
| 2. Item sheet — 23 types | 22/22 creatable + 5/5 sheet instances | ✓ |
| 3. CRUD | 5/5 | ✓ |
| 5. Cluster-2 partials | 10/10 (8 variants + roll + prompt) | ✓ |
| 6. Real fatigue.setLevel chat post | 3/3 | ✓ |
| 15. Visual / CSS / token integrity | 4/4 | ✓ |
| 16. i18n acceptance | 4/4 | ✓ |

**MANUAL categories deferred** (7 of 16): combat engagement mechanics, charge+knockback flow, arcane casting flow, divine/mysticism/sorcery casting, stat improvement GM-approval, wear/wound/temp-HP, critical+luck save. These require a human running scripted play-through in the test world; they're flagged for the rc.1 polish window, NOT blocking alpha.53.

Full results in `docs/v1.0.0-acceptance-results.md`.

### F1 — defensive optional-chain in actor.mjs:173

Acceptance surfaced a latent prepareData bug: `module/actor/actor.mjs:173` accessed `itm.flags.elysium.elysiumidFlag.id` without defensive chains. When skillcat items were created programmatically (i.e., in the acceptance test's CRUD loop) without the BRP-ID metadata that comes from the compendium, the access threw `Cannot read properties of undefined (reading 'elysiumidFlag')` 209+ times during the acceptance run.

The `_safePrepareData` wrapper caught the error and prevented full prep failure — so this wasn't visible during normal world flow where items always have BRP-ID flags from the compendium — but each programmatic item create fired the error and the elysiumidFlag-keyed `skillcategory[]` lookup map was incomplete.

**Fix**: optional-chain guard at L173. Items without an elysiumidFlag.id skip the skillcategory map entry rather than throwing. Pattern aligns with two pre-existing defensive sites in actor-itemDrop.mjs (L393, L633) — proving prior author awareness of the risk on adjacent code paths. Per c3 audit Q5: JS bug (small) → hotfix in-cluster, alpha.53 absorbs.

### F2 — actor-itemDrop.mjs 19 sibling sites flagged for alpha.54

The same brittle pattern (`.flags.elysium.elysiumidFlag.id` without defensive chains) exists at 19 sibling sites in `module/actor/actor-itemDrop.mjs`. These are NOT in the prepareData chain (so didn't fire during acceptance), but they're a latent bug for programmatic item drops with malformed items. Per c3 audit Q5: JS bug (small batch) → flag for alpha.54. Not blocking c3 close.

### Cluster-3 lock list additions

No new class-hook locks. c3 is lang + testing, not surface migration. The acceptance checklist itself (`docs/v1.0.0-acceptance-checklist.md`) becomes the canonical pre-rc.1 verification document.

### Files changed by c3

- `lang/es.json`: +206 keys translated (final state: 1351 keys, structural gap to en = 0)
- `lang/fr.json`: +206 keys translated (final state: 1351 keys, structural gap to en = 0)
- `docs/p12-c3-audit.md`: 387 lines, the c3 prep audit + Options A/B/C/D
- `docs/v1.0.0-acceptance-checklist.md`: pre-existing 238-line checklist (built earlier in c3 prep session)
- `docs/v1.0.0-acceptance-results.md`: NEW, captures the c3 run results + F1/F2 routing
- `docs/i18n-glossary-es.md`: 50-term glossary (pre-existing from c3 prep)
- `docs/i18n-glossary-fr.md`: 50-term glossary (pre-existing from c3 prep)
- `module/actor/actor.mjs`: +5 LOC defensive guard at L173 (F1 fix)

### Supplementary acceptance pass — F6 + F7

A second auto-acceptance pass was run after F1/F2 to verify chat-card partials and the fatigue API surface in more depth. Two additional latent bugs surfaced, both hotfixed in-cluster per Q5:

#### F6 — `Elysium.WhatCopiedClipboard` missing key (severity: LOW)

`module/elysiumid/elysiumid-editor.mjs:49` references `'Elysium.WhatCopiedClipboard'` but the key was never added to any lang file. Surfaced during the L.1 key-resolution scan.

User impact: copying a BRPID to clipboard showed the literal string `"Elysium.WhatCopiedClipboard"` in the notification instead of a localised message.

**Hotfix**: added to all 3 lang files:
- en: `"Copied {what} to clipboard"`
- es: `"Copiado {what} al portapapeles"`
- fr: `"{what} copié dans le presse-papiers"`

#### F7 — `fatigue-manager.mjs::increment/decrement` reference undefined `current` (severity: HIGH)

Both `ElysiumFatigueManager.increment` and `decrement` reference a bare `current` variable that is never declared — `ReferenceError: current is not defined` at runtime.

The bug **predates alpha.52** (likely P9-era when the helper class was extracted). Never surfaced in earlier per-cluster smoke tests because:
- P11 tests used `setLevel` directly (which has its own `current` via the `data` parameter)
- The combat-tab Rest button (calling `fatigue.decrement(actor, 1)`) was untouched until alpha.52's c2 chat migration made the path reachable from new chat code
- The overcast magic path (`magic.mjs:62` calling `fatigueAPI.increment(actor, fatigueLevels, 'magical', 'overcast')`) also throws when a caster pushes PP past limit

Surfaced during Cat 15.5 (decrement test). Bridge returned:
```
ReferenceError: current is not defined
  at ElysiumFatigueManager.decrement (fatigue-manager.mjs:60:34)
```

User impact (alpha.52): combat-tab Rest button throws ReferenceError on click; overcast spell paths throw on PP-deficit fatigue application.

**Hotfix**: both methods now derive `current` from actor state defensively:
```js
static async increment (actor, amount = 1, recoveryType = 'physical', source = '') {
  const current = actor.system?.fatigue?.level ?? 0   // ← added
  // ...
}
static async decrement (actor, amount = 1) {
  const current = actor.system?.fatigue?.level ?? 0   // ← added
  // ...
}
```

F7 alone justifies the cumulative-acceptance methodology — it was reachable from real alpha.52 user actions and runtime-throwing. The per-cluster smokes in P9-P12 didn't catch it because they didn't exercise the helper methods' state-reading paths.

### Methodology correction — Foundry V14 CSS load mechanism

Initial Cat V.6 test reported "legacy.css not loaded". Investigation: V14 loads system CSS via `@import url(...) layer(system)` statements, **not** via `<link>` tags. The `document.styleSheets[].href.includes()` traversal only finds `<link>`-loaded sheets and misses the @import chain.

Corrected check walks the @import rules. All 9 expected sheets verified: elysium-tokens, elysium-reset, elysium-base, elysium-components, elysium-sheets, elysium.css, elysium-chat.css, elysium-tracker.css, legacy.css.

Useful for future acceptance passes — `document.styleSheets` traversal needs to walk @import rules to surface the full V14 cascade.

### Additional files changed (supplementary)

| File | Change |
|---|---|
| `lang/en.json` | +1 key (WhatCopiedClipboard hotfix) — 1346 → 1347 |
| `module/elysium/fatigue/fatigue-manager.mjs` | +2 LOC (F7 hotfix in `increment` + `decrement`) |
| `docs/v1.0.0-acceptance-results.md` | Appended supplementary section documenting F6 + F7 findings |

### Total acceptance findings — 4 (F1 + F2 + F6 + F7)

| ID | Severity | Routing | Status |
|---|---|---|---|
| F1 | Medium | In-cluster hotfix | Fixed in actor.mjs:173 |
| F2 | Medium (deferred) | alpha.54 | 19 sibling sites in actor-itemDrop.mjs |
| F6 | Low | In-cluster hotfix | Fixed in 3 lang files |
| F7 | **High** | In-cluster hotfix | Fixed in fatigue-manager.mjs |

The cumulative acceptance methodology has demonstrated concrete pre-rc.1 value. **F7 was high-impact runtime-reachable** and would have been a release-blocker had it shipped to v1.0.0-rc.1 without c3's acceptance pass.

---

## [1.0.0-alpha.52] — P12 cluster 2: inline-HTML ChatMessage.create migration (45 callsites onto 3 archetypal partials)

P12-c2 ships. The largest single P12 item per the prep audit's sizing: 45 inline-HTML `ChatMessage.create({content: '<div>...'})` callsites across 19 module files migrated onto 3 new archetypal chat-card partials. Hardcoded English strings (where present) lifted to a new `Elysium.Chat.*` i18n namespace. Helper functions that returned HTML strings (`fatigue-manager._formatChat`) refactored to return context objects per c2 audit D5. Per `docs/p12-c2-audit.md`.

### Cluster-2 scope adjustment from prep audit

The P12 prep audit estimated "44 callsites + ~5 partials." Live measurement at alpha.51 baseline (per c2 audit §1) found **45 inline-HTML callsites across 19 files**, not 44/19 — the prep audit undercounted by 1 because it ran fast over the 11 "unknown" callsites that needed manual inspection. Of those 11, 4 were genuinely already template-based (out of c2 scope: rollStats.html / XP-result.html / itemDescription.html / generic chat dispatcher) and 7 were inline-HTML disguised as variable-content (the inline string built into a `chatContent`/`html`/`content`/`message` variable one line above the call).

Per c2 audit §2, the 45 callsites collapse to **3 structural archetypes, not 5** as the prep audit hand-waved. Fewer partials with more flexible context contracts is cleaner than more partials with rigid signatures.

### Three new partials shipped

All three compose the cluster-1 `chat-card-shell` BEM marker class for chat-card scoping, register through `init.mjs` `loadTemplates` block, and use a `--{{variant}}` BEM modifier for accent token routing (Section D variant rules).

**`templates/chat/parts/chat-card-notice.hbs`** (Archetype A — Notice / status announcement). Covers ~25 of the 45 callsites: sustain-begin, sustain-break, sustain-upkeep, pow-loss, no-target, no-hit-locs, ongoing-damage, armor-wear, weapon-wear, covering-stance, passive-block-applied, ward-applied, temp HP, stat-cap-prompt, stat-dice-prompt, fatigue-update, change-range-resisted, change-range-summary, charge-no-knockback, knockback-stayed, knockback-prone, outmanoeuvre-engage, outmanoeuvre-withdraw, rest-fatigue, engagement-warning, cast-disrupt-result, sorcery damage error notices, magic forbidden notices, sustain disrupt result (notice on hold/break), guaranteed stat-advance, learn-card edge variants. Context contract: `variant` (required, accent token suffix); `title` (optional header); `icon` (optional FA name); `body` (required, rendered HTML); `cardType` (optional 2-letter code). 13 LOC partial.

**`templates/chat/parts/chat-card-roll.hbs`** (Archetype B — Roll outcome). Covers ~8 callsites: critical-card, stat-improvement-card, fatigue-roll, sorcery-damage-card, learn-card (default), spell-learning, charge-result (resolved), gamble stat-advance, sustain-disrupt-roll. Context contract: `variant`, `title` (required), `icon` (optional), `body` (required), `footer` (optional rendered HTML for cost lines / hint lines). 14 LOC partial.

**`templates/chat/parts/chat-card-prompt.hbs`** (Archetype C — Action prompt). Covers the 3 buttoned prompt callsites: charge-prompt (3 buttons: parry/evade/counter), change-range-prompt (4 buttons: resist-win/resist-lose/attack/allow), knockback-prompt (2 buttons: stayed/prone). Context contract: `variant`, `title` (required), `icon` (optional), `body` (required), `hint` (optional italic prompt above buttons), `actionAttr` (required — the `data-elysium-*-action` attribute NAME, preserved per audit-5 D6), `buttons` (required array — each entry `{action, label, tooltip, dataAttrs}`). The `actionAttr` parameter enables family-specific attribute names without unifying them (each module owns its own JS dispatch). 25 LOC partial.

### Variant accent system (BEM modifier + new Section D rules)

Each new partial accepts a `variant` context parameter that becomes a BEM modifier class on the outer `<div>`: `elysium-chat-notice--{{variant}}`. Variants align with the chat-card Section D vocabulary established in P11 c2-c4:
- `action` → `--ely-accent-action` (combat crimson — charge prompts, knockback prompts)
- `danger` → `--ely-accent-danger` (red — overcast, critical, ongoing damage, prone, forbidden)
- `success` → `--ely-accent-success` (green — stat increases, sustain holds, knockback stayed)
- `info` → `--ely-accent-info` (blue — neutral information, covering stance, passive block, ward)
- `bonus` → `--ely-accent-bonus` (gold — luck save, learn-card success, neutral noteworthy)
- `bonus-dark` → `--ely-accent-bonus-subtle` (muted gold — armor wear, weapon wear, charge parry)
- `fire` → `--ely-accent-fire` (orange — fatigue, engagement transition, learn-card fail, cast-disrupt-partial)
- `mind` → `--ely-accent-mind` (purple — POW loss, sustain notices, casting-related)

**New Section D rules in `styles/elysium-chat.css`**: 8 variant accent rules × 3 partials (action / danger / success / info / bonus / bonus-dark / fire / mind), each a `3px solid var(--ely-accent-*)` left border. Plus 5 structural rules for `__header`, `__body`, `__footer`, `__hint`, `__buttons` BEM elements — all token-driven via `--ely-font-weight-bold`, `--ely-space-1/2`, `--ely-border-width-1`, `--ely-border-subtle`, `--ely-font-size-2`. elysium-chat.css braces 70 → 85 (+15 new rules).

### 86 new i18n keys + 86 stubs in es.json / fr.json

A new `Elysium.Chat.*` namespace mounted in `lang/en.json` covering 13 message families: sustain (6 keys), POW loss (3), cast-disrupt / no-targets (2), charge (16 — prompt + bonuses + buttons + resolved states), knockback (4), change-range (10), outmanoeuvre (2), armor wear (4), weapon wear (2), engagement warning (8), passive block / ward (3), stat improvement / cap / advance (8), creation (2), critical (1), fatigue (3), cast-disrupt (1), temp HP (1), magic (2). Total: 86 keys.

Per c2 audit Q1 lock: stubs added to `es.json` and `fr.json` with English values for c3 lang-completion sweep. Final lang parity: en=1346, es-gap=206, fr-gap=206 (gap unchanged from alpha.51 because 86 new keys exist in all three files; gap is structural for the 206 still-untranslated keys from P11).

### Helper refactor (D5)

`module/elysium/fatigue/fatigue-manager.mjs::_formatChat()` was a sync HTML-builder helper returning a `<div class="elysium-fatigue-update">...</div>` string. Per c2 audit D5, refactored to return a **context object** consumed by the caller via `renderTemplate('.../chat-card-notice.hbs', ctx)`. The signature change is internal to the module — `_formatChat` is private (`_` prefix). Two callsites updated: `setLevel` (the fatigue-update notice) and the call site that consumed the returned string. The `effortRoll` callsite — an Archetype B roll card — built its HTML directly inline; refactored to use `chat-card-roll.hbs` with the same context-construction pattern.

The other HTML-builder helpers surveyed during c2 turned out NOT to need refactoring — the assumption that other `_formatX`-style helpers exist was wrong. Only `_formatChat` matched the pattern.

### 45 callsite migrations — per file summary

| File | Count | Archetype |
|---|---|---|
| `module/casting/divine-cast.mjs` | 1 | A |
| `module/casting/sustain.mjs` | 4 | 3×A + 1×B |
| `module/casting/sorcery-cast.mjs` | 3 | 2×A + 1×B |
| `module/casting/spell-learning.mjs` | 1 | B |
| `module/elysium/actor/stat-improvement.mjs` | 3 | 1×B + 2×A (edge — caller-built buttons per D4) |
| `module/elysium/combat/combat-extension.mjs` | 1 | A |
| `module/elysium/creation/creation.mjs` | 2 | 1×B + 1×A |
| `module/elysium/critical/critical-roller.mjs` | 2 | 1×B + 1×A |
| `module/elysium/fatigue/fatigue-manager.mjs` | 2 | 1×A (via refactored helper) + 1×B |
| `module/elysium/hooks/chat-card.mjs` | 1 | A (edge — caller-built body) |
| `module/elysium/hooks/item.mjs` | 3 | 3×A (edge — caller-built button bodies preserve `.elysium-disrupt-btn`/`.elysium-cast-disrupt-btn` JS hooks) |
| `module/elysium/magic/magic.mjs` | 2 | 2×A |
| `module/elysium/mechanics/armor-wear.mjs` | 1 | A |
| `module/elysium/mechanics/charge-ui.mjs` | 6 | 1×C + 1×B + 1×C + 3×A |
| `module/elysium/mechanics/covering-stance.mjs` | 3 | 3×A |
| `module/elysium/mechanics/engagement-ui.mjs` | 3 | 1×C + 2×A |
| `module/elysium/mechanics/outmanoeuvre.mjs` | 3 | 1×A (edge — caller-built table+buttons body) + 2×A |
| `module/elysium/mechanics/weapon-wear.mjs` | 1 | A |
| `module/elysium/sheets/actor/combat-tab.mjs` | 2 | 1×A + 1×A (edge — caller-built `<ul>` body with per-row tinted spans) |
| **TOTAL** | **45** | **~30×A + ~9×B + ~5×C + ~7 edge cases per D4** |

### Edge cases per D4 (~7 callsites)

Per c2 audit D4, callsites whose body has bespoke shapes that don't fit the 3 archetypes cleanly stay caller-built (outer shell from partial, body from caller). These include:

1. **`stat-improvement.mjs::postCapApprovalCard`** — preserves `.elysium-cap-btn` / `.elysium-cap-approve` / `.elysium-cap-decline` class hooks (read by `chat-card.mjs::wireCapOverrideButtons:200`) plus the `.elysium-stat-cap-card` parent class probe for card-type routing. Caller-built button body inside notice partial.
2. **`stat-improvement.mjs::postExpDiceApprovalCard`** — same pattern; preserves additional `.elysium-stat-dice-card` parent class for card-type discrimination.
3. **`item.mjs` sustain-disrupt buttons** — preserves `.elysium-disrupt-btn` class hooks (read by chat-card.mjs binding).
4. **`item.mjs` cast-disrupt button** — preserves `.elysium-cast-disrupt-btn` class hook.
5. **`hooks/chat-card.mjs:190` cast-disrupt-result** — preserves `.elysium-disrupt-success` / `-fail` / `-partial` inner span classes (styled in elysium.css).
6. **`combat-tab.mjs::postEngagementWarningCard`** — preserves per-row inline-tinted spans (held-at-bay red, encroached orange, normal green) that are state-specific markers; retoken to variant classes deferred to P12-c4 since they're inside a caller-built body.
7. **`outmanoeuvre.mjs` main card** — preserves the `<table>` body with per-foe state badges; `data-elysium-om-action` attribute hooks preserved verbatim.

All 7 edge cases are clearly documented inline with `// Per c2 audit D4: edge case — ...` comments explaining why they stay caller-built.

### D6 audit-5 lock list additions

Four `data-elysium-*-action` attribute family names locked to the audit-5 list (preserved verbatim, JS-imperative hooks that the module's own event listener reads):
- `data-elysium-charge-action` (charge-ui dispatch: `resolveCharge`)
- `data-elysium-cr-action` (engagement-ui dispatch: `resolveChangeRange`)
- `data-elysium-kb-action` (charge-ui dispatch: `resolveKnockback`)
- `data-elysium-om-action` (outmanoeuvre dispatch: `resolveOutmanoeuvreFollowUp`)

The three partial paths also lock to the audit-5 list:
- `systems/elysium/templates/chat/parts/chat-card-notice.hbs`
- `systems/elysium/templates/chat/parts/chat-card-roll.hbs`
- `systems/elysium/templates/chat/parts/chat-card-prompt.hbs`

### F1 (130-rgba) deferred per Q2 lock

Per c2 audit Q2 lock + c1 audit F1 routing: the 10 already-styled c2-marker-class rules in `styles/elysium.css` are NOT retokenned in c2 (they sit in F1 territory — `styles/elysium.css` 130-rgba leakage scoped to c4). The migrated callsites continue to render via the existing legacy rules + the new Section D BEM-modifier accent border. Both styling paths coexist cleanly; c4 will retoken the F1 territory as a coordinated sweep.

### Files changed

| File | Change |
|---|---|
| `templates/chat/parts/chat-card-notice.hbs` | **NEW** — 13 LOC Archetype A partial |
| `templates/chat/parts/chat-card-roll.hbs` | **NEW** — 14 LOC Archetype B partial |
| `templates/chat/parts/chat-card-prompt.hbs` | **NEW** — 25 LOC Archetype C partial |
| `styles/elysium-chat.css` | +5 LOC sub-section header + 8 variant accent rules + 5 structural BEM rules (braces 70 → 85, +15) |
| `module/hooks/init.mjs` | +5 LOC (3 new partial paths registered with comment) |
| `lang/en.json` | +86 new `Elysium.Chat.*` keys |
| `lang/es.json`, `lang/fr.json` | +86 English stubs (c3 will translate) |
| 19 module/.mjs files | 45 callsites refactored from inline-HTML to context-building + renderTemplate |
| `system.json` | version bump + audit doc reference |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution log + progress tracker |

### Pre-flight sweep — clean

- JS parse: `node --check` on all 20 modified .mjs files → OK
- JSON parse: system.json + lang/en.json + lang/es.json + lang/fr.json → OK
- CSS brace balance: elysium-chat.css 85/85; all other CSS files unchanged from alpha.51 baseline
- Handlebars block balance on 3 new partials: 5/5, 3/3, 6/6 all BALANCED
- Handlebars compile + smoke render on all 3 new partials with realistic context shapes → OK
- i18n key resolution: all 51 `Elysium.Chat.*` keys referenced from migrated module/ code present in en.json (86 keys total; 35 stubs reserved for follow-up callsites or finer-grained lift)
- Inline-HTML callsite scan: 0 remaining (was 45)
- Class-hook lock list: all audit-5 entries plus the 4 new D6 entries preserved
- No regression to lang parity (en=1346, es-gap=206, fr-gap=206 — both languages got the 86 new stubs)

### Behavioural impact

Zero functional regression expected:
- All 45 callsites now render via Handlebars `renderTemplate` instead of template literal interpolation; the resulting HTML is structurally similar with the same payload data
- All JS-imperative class hooks preserved verbatim (audit-5 enforcement)
- All `data-elysium-*-action` button attributes preserved verbatim — the JS dispatch in each module continues to read the same attribute names
- The `_formatChat` refactor doesn't change the called functions' signatures (they're private, no external consumers)
- Foundry's `ChatMessage.create` payload contract is unchanged

Visual changes:
- Each migrated card now displays a 3px-left-border accent in the assigned variant color (consistency with P11 c2-c4 cards)
- Inline-style anti-pattern retired at all 45 migration target callsites (still 31 inline-style declarations remain in OTHER chat-card code paths — button-builder helpers, dialog form HTML — flagged as P12-c4 candidates)

### Cluster-2 milestone

After alpha.52, **the inline-HTML-in-JS anti-pattern is retired across all 45 cluster-scope callsites**. New chat surfaces should compose chat-card-notice / chat-card-roll / chat-card-prompt rather than emit inline HTML. The three partials are the audit-5-locked vocabulary for non-card-typed chat output going forward.

### Phase plan unchanged

P12 stays at the post-c1 plan of 4 clusters: c1 ✓ (alpha.51), c2 ✓ (this ship, alpha.52), c3 (lang completion + acceptance testing, alpha.53), c4 (F1 130-rgba scoping audit + retoken, alpha.54). No further phase growth from c2.

### Verification for post-install

Live-verify checklist (Chrome bridge):
1. **Existing chat output** — open any existing P11 chat card (combat roll, opposed roll, group roll, etc.); should render identically to alpha.51 (no c2 changes to P11 cards)
2. **Sustain-begin notice** — cast a sustainable spell; chat should show mind-purple-accented notice card with infinity icon
3. **Charge prompt** — initiate a charge in combat; chat should show action-crimson-accented prompt with 3 buttons (Parry/Evade/Counter), each with `data-elysium-charge-action`
4. **Change-range prompt** — initiate change-range; fire-orange-accented prompt with 4 buttons, each with `data-elysium-cr-action`
5. **Stat improvement roll** — roll improvement on a character stat; success → green-success card; fail → red-danger card; both with dice icon
6. **Critical card** — roll critical damage; red-danger card with skull-crossbones icon
7. **Fatigue level change** — increment fatigue via API; orange-fire-accented update notice with face-tired icon
8. **Knockback prompt** — apply charge knockback; action-accented prompt with stayed/prone buttons
9. **Click each prompt button** — verify the corresponding resolver fires (charge resolution, change-range outcome, knockback prone-or-not)
10. **No console errors** during any of the above

---

## [1.0.0-alpha.51] — P12 cluster 1: mechanical CSS + attribute cleanup

P12 opens. Cluster 1 covers the prep-audit-scoped mechanical work: vestigial attribute retirement, danger-color retoken, island rgba + px cleanup, brace-badge inline-style retirement (cluster-7 F3 routed here), and the legacy.css orphan sweep. CSS + attribute changes only — no JS logic changes, no template structural changes, no Handlebars rebuilds, no i18n additions. Per `docs/p12-c1-audit.md`.

### Two audit docs landed before code

Per project rule 2, both `docs/p12-prep-audit.md` (411 lines — Option B three-cluster split + D2-D6 phase-level decisions) and `docs/p12-c1-audit.md` (424 lines — per-item itemisation + 7 open questions) shipped to disk before any code work. Cluster 1 absorbed Option α (F1 deferred to a future P12-c4) per `docs/p12-c1-audit.md` Q1.

### Critical scope discovery — surfaced by alpha.50 baseline measurement

The cluster-6 island audit measured "1 rgba color leak in v1.0.0 islands." Accurate within scope. The corresponding full-tree measurement at alpha.50 baseline finds **130 rgba/rgb color literals in `styles/elysium.css`** — the cluster-6 scope addressed ~1% of the actual color-token leakage. The 130 leaks are in non-island v1.0.0 rules that don't carry an island marker but ARE part of v1.0.0 territory (sheet rules, header rules, tab rules, accent rules).

Per c1 audit Q1 Option α: F1 stays outside c1 scope. F1 becomes its own scoping audit (likely P12-c4). The phase plan grows from 3 to 4+ clusters. Documented honestly here rather than absorbed silently into c1's diff.

### Five cluster-1 items

**1.A — `data-handle-change` attribute retirement** (38 live occurrences across 14 templates retired, 0 remain). The attribute had zero JS consumers in `module/` — confirmed by full-tree grep. It was a vestigial V12-era decorator preserved verbatim across P10+P11 per cluster-5 c5-4 ("await P12 sweep"). Python sweep handled 3 syntactic patterns: standard `data-handle-change name="..."` (most common), name-first `name="..." data-handle-change data-...` (one item-sheet edge case), and close-bracket-trailing `name="..." data-handle-change>` (two hit-location-sheet cases). The 14 files touched: `weapon.detail.hbs` (8 removals), `skill.detail.hbs` (7), `hit-location.detail.hbs` (3), `armor.detail.hbs` (3), `dialog-row.hbs` (2 + comment-block updated to a historical-note style), `skillcat`/`gear`/`divine`/`career.wealth`/`npcV2.main` (2 each), `mysticism`/`mutation`/`ability`/`difficulty` (1 each). The `dialog-row.hbs` partial's class-invariants comment block (lines 7-9) — which had explicitly flagged this attribute for P12 sweep — was updated to a "retired in alpha.51" historical note. Handlebars block balance verified across all 14 templates.

**1.B — `darkred` retoken to `--ely-accent-danger`**. Rule body `color: var(--ely-legacy-colour-secondary)` (currently `rgb(68,7,4)`, a deep maroon) retokenned to `color: var(--ely-accent-danger)` (`#c44040`). Class name `.darkred` preserved in templates (`elysiumid-editor.hbs:52` and `:74`) per c1 audit D2 — renaming the class is template-surface churn for no functional benefit; the class IS the design intent (a danger-tinted warning-triangle icon). Multi-line code comment added to the rule documenting that the literal-color name is historical from BRP era. Visual delta: warning triangles shift from deep maroon to saturated medium red — a stronger warning signal, appropriate for the use case.

**Correction to HANDOFF-state.md**: that doc specified `--ely-text-danger` as the retoken target. No such token exists in `styles/elysium-tokens.css`. The correct target is `--ely-accent-danger`.

**1.C — Island cleanup** (1 rgba + 19 of 36 px literals retokened).

The TCD selected-tier-cost `rgba(255, 255, 255, 0.18)` retokenned to `var(--ely-overlay-subtle)`. **New token added** to `elysium-tokens.css` (Surface section, after `--ely-surface-overlay`) capturing the "translucent-white wash for selected-state emphasis" pattern as a reusable semantic. Defined as `rgba(255, 255, 255, 0.18)` with a documentation block explaining its purpose. Per c1 audit Q2 option 2.

Of the 36 island px literals catalogued in the c1 audit appendix, **19 retoken, 18 stay as documented layout constants**. Retokens applied: 14× `1px solid var(--ely-border-X)` → `var(--ely-border-width-1) solid var(--ely-border-X)`; 1× `3px solid var(--ely-border-X)` → `var(--ely-border-width-3)`; 1× `1px solid var(--ely-accent-info)` → border-width-1; 1× `1px dashed var(--ely-border-subtle)` → border-width-1; 1× `3px solid var(--ely-accent-info)` → border-width-3; 1× `border-radius: 9px;` → `var(--ely-radius-3)` (8px; 1px delta accepted per c1 audit Q4 with live-verify required post-install). The 18 literals staying are: 2px gap declarations (4×), 22px icon dimensions (2×), 24px min-width (1×), 10px font-size (2×), 1px translateY sub-pixel nudge (1×), 3px margin-right (1×), 2px margin-top (1×), `padding: 1px 7px` (1×), 100px/80px/110px flex-basis layout constants (3×), and mixed `2px var(--ely-space-2)` / `3px var(--ely-space-1)` paddings (2×). Each retained literal is documented as an intentional layout constant — the audit explicitly flagged these as not-token-mappable without visual regression.

**1.D — Brace-badge inline-style retirement** (cluster-7 F3 routed here per cluster-7 Option B).

`module/elysium/hooks/render-combat-tracker.mjs:23` had `badge.style.cssText = 'margin-left:6px;color:#0066aa;'`. The `.elysium-brace-badge` class had zero CSS rules anywhere — identical anti-pattern to the cluster-3 hitloc-tag retirement. Three changes:

1. **New file `styles/elysium-tracker.css`** (39 LOC including extensive doc comments). Per c1 audit Q3 option 2, the file is created as a foundation reserving the surface for a future v1.1.0 combat-tracker restyle. Scope today: one rule. Scope reserved: the broader cluster-7 F1 visual misalignment work when/if v1.1.0 picks it up. File registered in `system.json` `styles` array as the 10th entry, positioned alongside `elysium-chat.css` (sibling Elysium application surfaces). The doc comment explicitly notes the cluster-7 F2 finding (`.application.elysium` doesn't reach the sidebar tracker — a scoping marker would need to be added for these rules to cascade) and the F4 finding (Foundry V14 API contract classes are not renameable).

2. **Rule body**: `.elysium-brace-badge { margin-left: var(--ely-space-1); color: var(--ely-accent-info); }`. The hardcoded `#0066aa` retokens to `--ely-accent-info` per c1 audit D4; the hardcoded `6px` margin retokens to `var(--ely-space-1)` matching the chat-card chip spacing pattern from cluster-3.

3. **JS change**: deletion of line 23 in `render-combat-tracker.mjs` (the inline-style cssText assignment). The class assignment, tooltip dataset, and DOM append all remain unchanged.

**Lock list addition**: `.elysium-brace-badge` is now an audit-locked JS-imperative class (used as a double-injection guard at `render-combat-tracker.mjs:18`). Updated in §7 of c1 audit; locked.

**1.E — Legacy CSS orphaning sweep** (62 rule blocks retired, legacy.css 1626 → 1052 LOC, -574 LOC -35%).

Per c1 audit D6: retire only true orphans (zero consumers across templates + module + non-legacy CSS). Audit estimate was ~55-90 LOC retirement; actual delta is **much larger** — most legacy rules carry 4-15 LOC of property declarations, not 1 LOC. The audit's per-rule LOC estimate undershot.

**Methodology** per c1 audit Q5 (automated re-grep):
1. Build orphan candidate list from `.elysium`-prefixed selectors in legacy.css (184 distinct classes)
2. Re-verify each candidate against templates + module + all non-legacy CSS (catches false-positives the bulk analysis might miss). At post-1.A baseline: 61 true orphans.
3. Categorise into full-block deletion (62 blocks — some orphans appear in 2 blocks each) vs selector-trim (2 borderline cases).
4. Delete from largest file offset first to preserve earlier offsets during multi-deletion pass.
5. Trim leading/trailing whitespace so adjacent surviving blocks don't drift.
6. Final newline-collapse: any 3+ consecutive newlines collapsed to 2.

**Two stragglers caught by post-sweep verification** (not in the top-level block analysis):
- `.editor-container` was a **nested rule** (modern CSS nesting) inside `.elysium .tab .story .editor { ... }` — trimmed from the parent block, leaving the parent intact.
- `.elysium .items-list .item-list { list-style: none; margin: 0; padding: 0; }` — the parent class `.items-list` is orphan, so the rule is functionally dead (it never matches any DOM). The descendant `.item-list` IS consumed by templates (super.detail.hbs, career.powers.hbs, personality.detail.hbs) and currently renders with browser default `<ol>` styling. The rule was retired entirely; `.item-list` rendering is whatever the browser default is, which is the current behaviour (no regression). Documented as a pre-existing edge case — if `.item-list` lists are rendering oddly, that's a pre-existing condition the audit didn't catch and a candidate for v1.1.0 review.

**One selector-trim deferred**: `.elysium .sheet-body, .elysium .sheet-body .tab, .elysium .sheet-body .tab .editor { height: 100%; }` — all 3 selectors are dependent on the `.sheet-body` parent which is orphan, so the descendant selectors only match inside an element that doesn't exist. The entire block was retired (functionally dead).

**Final consumer re-verification**: full corpus grep at post-1.E baseline confirmed all 62 retired class names are absent from `templates/`, `module/`, and all CSS files. Clean.

### Files changed

| File | Change |
|---|---|
| 14 templates (per 1.A list) | 37 `data-handle-change` attribute removals + 1 comment-block update in dialog-row.hbs |
| `css/legacy.css` | `.darkred` rule body retoken + 62 orphan rule blocks deleted + 1 nested rule trim + final whitespace collapse (1626 → 1052 LOC, 220 → 148 rule blocks, all braces balanced 148/148) |
| `styles/elysium.css` | 1 rgba retoken + 19 px literal retokens (130 → 129 rgba; 36 → 18 island px) |
| `styles/elysium-tokens.css` | +1 new token `--ely-overlay-subtle` with full doc comment |
| `styles/elysium-tracker.css` | **NEW FILE** — 39 LOC, foundation file for future v1.1.0 tracker restyle, current scope = brace-badge rule only |
| `module/elysium/hooks/render-combat-tracker.mjs` | -1 LOC (deleted inline-style cssText assignment) |
| `system.json` | version bump + styles array +1 entry (`styles/elysium-tracker.css`, positioned alongside elysium-chat.css) |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | P12-c1 execution log entry + phase row update reflecting cluster-1 ship |

### Pre-flight sweep — clean

- JS parse: `node --check render-combat-tracker.mjs` → OK
- JSON parse: system.json → version=1.0.0-alpha.51, styles=10 entries
- CSS brace balance: legacy.css 148/148; elysium.css 446/446; elysium-tokens.css 3/3; elysium-tracker.css 1/1
- Handlebars block balance: clean across all 14 modified templates
- `data-handle-change` live count: 0 (was 38)
- elysium.css rgba count: 129 (was 130 — TCD retoken accounted for)
- Token existence: all 58 distinct `--ely-*` tokens referenced in modified CSS are defined (including the new `--ely-overlay-subtle`)
- Class-consumer re-verification: all 62 retired class names absent from templates + module + CSS
- i18n: no new keys (cluster-1 is CSS + attribute only); lang parity gap unchanged at es=202 / fr=202 from alpha.50

### Lock list state

Added in alpha.51:
- `.elysium-brace-badge` (JS-imperative — double-injection guard at `render-combat-tracker.mjs:18`)

Unchanged from alpha.50:
- All audit-5 class-hook locks from clusters 1-5 (chat-card mount-point, hitloc tag, skillSelect family, etc.)
- All Foundry V14 API contract classes on the combat tracker (per cluster-7 F4)

### Cluster-1 milestone

The phase audit's Option B sequencing has c1 as the smallest of the three planned clusters; the actual c1 diff is larger than predicted because of the legacy.css orphan sweep's actual LOC payoff (62 blocks × ~9 LOC average = ~560 LOC retired vs the audit's ~55-90 LOC estimate). The other items came in on or under estimate.

After alpha.51, P12 has c2 (44 inline-HTML `ChatMessage.create` callsite migration — the largest single P12 item) and c3 (lang completion + acceptance) ahead. The newly-discovered F1 (130 rgba leaks in `styles/elysium.css`) becomes a likely P12-c4, scoped via its own audit before that cluster ships.

### Verification for post-install

Visual spot-checks required:
1. **TCD**: open a Tier Choice Dialog, select a tier — the tier-cost pill should still show subtle translucent-white emphasis (no visual delta vs alpha.50 — same color, just via token now)
2. **`.darkred`**: open the BRP-ID editor (Elysium ID feature) — the warning triangles should render in a saturated medium red (`#c44040`), brighter than the previous deep maroon (`rgb(68,7,4)`)
3. **Brace-badge**: in an active combat, set `flags.elysium.braced=true` on a combatant — the shield badge should appear next to the name in `--ely-accent-info` blue (`#5a7aa0`), with `var(--ely-space-1)` left margin
4. **Manipulation island 9px → 8px**: the visual delta is 1px on a single border-radius — observe and confirm acceptable; if objectionable, revert in a follow-up
5. **Item sheets** (any of the 14 touched): open + edit a field, verify form submission still works (data-handle-change retirement should be transparent — V14 form data extraction never read the attribute)
6. **Sheet rendering**: spot-render any sheet to verify the 62 retired legacy rules weren't load-bearing on any visible surface — the spot-check confirms zero consumers anywhere, so this is belt-and-suspenders

---

## [1.0.0-alpha.50] — Hotfix: character sheet scrolling + sheet header icon rendering

Two unrelated user-impact regressions surfaced during the P11 cluster 6 island-harmonisation audit and ship together as a focused CSS-only hotfix. Both fixes were live-verified in the browser at https://elysiumvtt.com/game before this ship: the user injected each rule via dev tools, confirmed the behaviour change, and removed them. No JS, no template, no token, no i18n changes.

### Fix 1 — Character sheet now scrolls at small viewports

`styles/elysium-sheets.css:46`. The actor sheet grid container `.application.elysium.sheet.actor .window-content` was set to `overflow: visible` to let absolutely-positioned "pill" elements (`.elysium-stat-tile-total` badges, the `.elysium-header-strip-top` negative-margin element) render outside their grid cells. The side effect: when the sheet content exceeded viewport height — reliably reproducible at 1920×1080 with the standard resources strip + left/right rails + tabs — no scrollbar appeared and content below the fold was unreachable.

Root cause: those pills are absolutely positioned children of `position: relative` parents, so they render correctly regardless of the `.window-content` overflow value. The `overflow: visible` was load-bearing on a misconception.

Fix: `overflow-y: auto; overflow-x: hidden` on `.window-content`. Scrollbar appears when needed; pills still escape grid cells via their own positioning. Verified live: scroll behaves correctly at 1920×1080, and stat-tile totals + header-strip pills render identically by getComputedStyle comparison.

### Fix 2 — Sheet header icons restored

`styles/elysium-reset.css` — new rule inserted after line 93. All sheet window-header controls (close X, copy UUID, edit BRP-ID, toggle controls) rendered as empty rectangles instead of FontAwesome glyphs.

Root cause: `styles/elysium-reset.css:86–93` sets `.application.elysium { font-family: var(--ely-font-family-body); ... }` to establish body typography. Foundry V14 ships FontAwesome 7 Pro with the base rule `.fa, .fa-solid, .fa-regular, ... { font-family: "Font Awesome 7 Pro"; }` at specificity `(0,0,1,0)`. The Elysium rule's specificity is `(0,0,2,0)` — it wins on descendant FA-classed elements, overriding the font-family and leaving FA's `::before` glyph code points pointing at a font that doesn't contain them. Empty rectangles.

Fix: add a matching-specificity `(0,0,2,0)` rule that re-asserts the FA font-family on FA-classed descendants of `.application.elysium`:

```css
.application.elysium .fa,
.application.elysium .fas,
.application.elysium .fa-solid,
.application.elysium .fa-regular,
.application.elysium .far,
.application.elysium .fa-light,
.application.elysium .fa-thin,
.application.elysium .fa-duotone,
.application.elysium .fa-brands,
.application.elysium .fab {
  font-family: "Font Awesome 7 Pro", "Font Awesome 5 Pro", FontAwesome;
}
```

Selector list covers FA7's six weight classes (`solid`, `regular`, `light`, `thin`, `duotone`, `brands`), the umbrella `.fa`, and the FA4-era short aliases (`.fas`, `.far`, `.fab`) that some Foundry core templates still emit. Fallback font stack covers FA5 systems and the FA4-era family name for legacy completeness.

Verified live: all 4 sheet header icons (fingerprint, ellipsis-vertical, passport, xmark) render correctly across multiple sheet types after the rule is applied; empty rectangles return when the rule is removed.

### Why a hotfix and not bundled into P12

Both regressions are visible from the first sheet a user opens after installing the system. Bundling them with P12 polish work (which has its own audit-then-stop cycle ahead) would leave the live install broken for an open-ended window. Single-cluster CSS-only delta keeps the diff auditable and the risk surface minimal.

### Files changed

- `styles/elysium-sheets.css` (1 declaration replaced, 1 comment block expanded)
- `styles/elysium-reset.css` (new rule + comment block appended after line 93; file 94 → 113 lines)
- `system.json` (version bump)
- `CHANGELOG.md` (this entry)
- `ROADMAP-v1.0.0.md` (P11 execution log + progress tracker)

No template, helper, token, partial, JS, JSON, or i18n changes.

### Lock list — unchanged

CSS-only delta. All P11 audit-5 hook locks remain in force. No class-hook renames, no data-attribute changes, no template surface changes.

---

## [1.0.0-alpha.49] — P11 cluster 5: generic dialogs (10 templates onto shared dialog-row partial)

P11 cluster 5 prep audit (`docs/p11-cluster5-audit.md`, 441 lines) shipped first; all 11 decisions (c5-1 through c5-11) plus 6 open questions locked per user "proceed with recommended". Rebuilds all 10 generic dialog templates in `templates/dialog/` (`selectPower`, `getValue`, `hitLocChoice`, `npcTokenCreate`, `selectItem`, `skillSelect`, `newWound`, `treatWound`, `damageDiff`, `difficulty`) onto v1.0.0 markup with a new shared `dialog-row.hbs` partial.

After alpha.49, **all 21 of 21 user-facing chat-card + dialog templates** are on v1.0.0. P11 ships closer to completion; remaining optional work is clusters 6 (island harmonisation) and 7 (combat-tracker cosmetic restyle).

### Three structural archetypes consolidated

The 10 dialogs collapse to three recurring shapes:

1. **Label + select dropdown** — 5 of 10 dialogs (selectPower, hitLocChoice, npcTokenCreate, and sub-rows in damageDiff/difficulty)
2. **Label + numeric/text input** — 4 of 10 (getValue, newWound, treatWound, parts of damageDiff/difficulty)
3. **Iterated list** — 2 (selectItem with radios, skillSelect with click-to-toggle squares)

Cluster 5 introduces one shared `dialog-row.hbs` partial (42 LOC) that handles BOTH select and input variants via a `kind` discriminator. 9 of 10 dialogs compose this partial (everything except skillSelect, which is the iterated audit-5-locked surface). The partial is shared across all dialog surfaces — it's NOT a cluster-1 chat-card partial because chat-card partials assume `chatCard` arrays / per-participant rows, neither of which dialogs have.

### Partial signature design discovery during coding

The prep audit (c5-2) proposed passing a `field` object to `dialog-row.hbs` with `field.kind`, `field.label`, etc. **Discovered during coding**: Handlebars partial-call syntax does NOT support inline object construction — there's no built-in way to pass `field={kind: "select", ...}` as a partial-call argument unless an `object` helper is registered (which Elysium doesn't have).

**Resolution**: flatten the signature. The partial takes top-level args directly (`kind`, `label`, `name`, `options`, etc.) instead of nesting them under a `field` namespace. This is cleaner and matches the cluster-4 `chat-card-actor-list.hbs` pattern (which also uses flat top-level args). Documented in the partial's context-contract comment for future cluster work.

### Files added (1)

- `templates/dialog/parts/dialog-row.hbs` (42 LOC) — shared row partial. Single label slot + (select|input) variant slot, both gated by the `kind` discriminator. Supports optional `tooltip`, `selected`, `value`, `inputType`, `dtype`, `placeholder`, and `labelLiteral` args. Registered in `module/hooks/init.mjs` `loadTemplates` block.

### Files modified — 10 dialog templates rewritten

| Template | Legacy LOC | Rebuilt LOC | Δ |
|---|---|---|---|
| `selectPower.hbs` | 9 | 9 | 0 |
| `getValue.hbs` | 10 | 11 | +1 |
| `hitLocChoice.hbs` | 10 | 11 | +1 |
| `npcTokenCreate.hbs` | 10 | 15 | +5 |
| `selectItem.hbs` | 12 | 16 | +4 |
| `skillSelect.hbs` | 16 | 32 | +16 (audit-5 lock comment block) |
| `newWound.hbs` | 19 | 18 | -1 |
| `treatWound.hbs` | 31 | 23 | -8 |
| `damageDiff.hbs` | 37 | 37 | 0 |
| `difficulty.hbs` | 72 | 53 | **-19** |
| **Total** | **226** | **225** | **-1** |

Plus +42 LOC partial = **+41 LOC net** across templates.

Cluster 5 is template-LOC-positive (like cluster 4) but represents the architectural win: 9 of 10 dialogs now share a single row pattern via composition, removing 30+ duplicated `flexrow > label + select/input` blocks across the codebase. **The win is consistency and maintainability, not raw LOC.** Future dialog work has a single point of customization (`dialog-row.hbs`).

`difficulty.hbs` is the standout — collapses from 72 LOC to 53 LOC (-19, -26%) because it had 5 instances of the row pattern repeated inline; each collapses to a single partial-call.

`skillSelect.hbs` grew from 16 to 32 LOC because of the audit-5 lock documentation block — the markup itself is 20 LOC (similar to legacy), but the comment documenting which 6 class/attr hooks are JS-imperative-locked is essential maintenance documentation.

### Second P11 legacy CSS rule retirement — `.elysium .selectList`

Cluster 4 retired `.elysium .XPCheck` (first P11 retirement). Cluster 5 retires `.elysium .selectList` from `css/legacy.css` (lines 1416-1420, 5 lines + 1 brace pair). The class was only consumed by the legacy `skillSelect.hbs` template being rebuilt; pre-flight grep confirmed zero remaining consumers across `templates/`, `module/`, other CSS files (the only remaining reference is a comment inside the rebuilt `skillSelect.hbs` documenting the retirement). `css/legacy.css` brace count: 221 → 220; LOC: 1636 → 1631.

This continues the **eager retirement pattern** when a rule has zero consumers post-rebuild, established in cluster 4. The P11 prep audit (c11-13) reserved CSS retirements for the P12 final sweep, but isolated rules with sole consumers being rebuilt are safe to retire as part of the cluster work itself.

### Markup-side class drops (no CSS rules to retire)

Cluster 5 drops these pure-semantic-marker classes from the rebuilt dialog markup (they had NO CSS rules; were class hooks with zero styling):
- `resource-label-diff` — replaced by `.elysium-dialog__row > label` cascade
- `diff-number-input` — replaced by `.elysium-dialog__row > input` cascade
- `radioList` — replaced by `.elysium-dialog__body` + per-row classes
- `item-view` — generic semantic marker, dropped
- `font14` on dialog-only paths — chat-card usage retired in c4; remaining actor-sheet consumers unchanged (rule preserved in `legacy.css:501`)
- `stat-name centre` combo on dialog-only paths — actor-sheet uses of `stat-name` remain at `legacy.css:299`

These markup drops are not CSS-rule retirements (nothing to remove from CSS files); they're just markup cleanup that gets the dialogs onto the consistent v1.0.0 BEM-element pattern.

### Cosmetic class drops on skillSelect (with audit-5 hooks preserved verbatim)

skillSelect.hbs retired these COSMETIC classes from markup: `selectList`, `new-row`, `centre`, `bold`, `charname`, `skill-opt-label`, `font14`. None had JS consumers (verified by grep).

**All 6 audit-5 JS-imperative hooks preserved verbatim** — verified live in smoke test:
- `.skill-select` (section wrapper, `event.currentTarget.closest('.skill-select')` at `skill-selection.mjs:17`)
- `.count` (live counter span, `form.querySelector('.count')` at line 18)
- `.select.rollable` (click handler binding, `querySelectorAll('.select.rollable')` at line 6)
- `.mediumIcon` (ancestor-closest from click target, `event.currentTarget.closest('.mediumIcon')` at line 10)
- `data-set="{{key}}"` (read via `chosen.dataset.set` at line 11)
- `.item-{{key}}` (toggle-target for innerHTML swap, `form.querySelector('.item-' + choice)` at line 19)

### Files modified — CSS

- `styles/elysium-chat.css`: +52 LOC (new Section B1c sub-block with 6 dialog-specific rules: `__title`, `__row`, `__row > label/select/input`, `__counter`, `__select-row`, `__radio-row`). Brace count 63 → 70 (+7 from the new rule blocks).
- `css/legacy.css`: -5 LOC (`.elysium .selectList` retirement). Brace count 221 → 220.

### Files modified — i18n + JS

- `lang/en.json`: +1 LOC. Added `Elysium.flatModHint` translation key. **Latent bug fix**: the legacy `difficulty.hbs` referenced `{{localize 'Elysium.flatModHint'}}` on the flatMod input's tooltip attribute, but the key was never defined in `lang/en.json`. The legacy tooltip rendered as the literal string `"Elysium.flatModHint"` rather than a localized phrase (Foundry's `localize` helper returns the key string unchanged when no translation is found). Cluster 5's i18n sweep caught this missing key during pre-flight; added the translation as part of the cluster ship. en-key count: 1259 → 1260.
- `module/hooks/init.mjs`: +2 LOC (partial path + comment for `dialog-row.hbs` registration).

Zero ApplicationV2/Dialog/DialogV2 dispatch-layer changes — template-only scope per c5-8.

### Files modified — summary

| File | Change |
|---|---|
| `templates/dialog/parts/dialog-row.hbs` | ADDED (42 LOC) |
| 10 × `templates/dialog/*.hbs` | rewritten (226 → 225 LOC, -1) |
| `styles/elysium-chat.css` | +52 LOC (Section B1c dialog rules) |
| `css/legacy.css` | -5 LOC (`.elysium .selectList` retirement) |
| `lang/en.json` | +1 LOC (`Elysium.flatModHint` latent-bug-fix translation) |
| `module/hooks/init.mjs` | +2 LOC (partial registration) |
| `system.json` | version bump alpha.48 → alpha.49 |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution-log entry + progress-tracker update |

**Net change**: +91 LOC (42 partial + 52 CSS + 1 i18n + 2 init = +97 added; legacy CSS -5; templates -1 = +91 net excluding documentation).

### Class hook preservation (audit-5 lock)

- `.skill-select`, `.count`, `.select.rollable`, `.mediumIcon`, `data-set` attribute, `.item-{{key}}` — all 6 JS hooks on skillSelect preserved verbatim. Confirmed by smoke fixture (10 checks specific to skillSelect).
- `name="..."` attributes on every form field — preserved exactly to match the Foundry form-data extraction the dispatch JS depends on. All 10 dialogs verified via smoke (form fields named the same as legacy: `selectPower`, `myValue`, `hitLoc`, `statCreate`, `selectItem`, `damage`, `woundLoc`, `treatWound`, `healType`, `woundId`, `success`, `range`, `hands`, `level`, `addStat`, `difficulty`, `diffVal`, `resistance`, `flatMod`, `wound`).
- `data-handle-change` attribute — preserved on every select/input across all 10 dialogs (vestigial decorator with zero JS consumers, per §1 audit finding; flagged for P12 attribute-cleanup sweep per c5-4 lock).
- `data-dtype="Number"` preserved where present (getValue, damageDiff level row).

### Behavioural impact

Zero behavioural change. The 10 dialogs render structurally-equivalent DOM modulo:
- The new `elysium-dialog` marker class on the form/section wrapper
- The new `__title`, `__row`, `__counter`, `__select-row`, `__radio-row` BEM-element classes (replacing the legacy `flexcol`/`flexrow`/`resource-label-diff`/`diff-label`/etc. mixed-purpose classes)
- Section B token-driven CSS (flex layout, padding, label width, font sizing) for the new BEM classes
- The `.elysium .selectList` retired grid styling on skillSelect (replaced by `.elysium-dialog__select-row` with `grid-template-columns: 30px 1fr` instead of legacy `30px 250px`; the `1fr` is responsive whereas the legacy `250px` was fixed)
- The `flatModHint` tooltip on difficulty.hbs now renders the localized translation instead of the literal key string (latent-bug fix)

The 9 dispatch JS files (selectPower→npcV2.mjs, getValue→culture.mjs, hitLocChoice→actor-itemDrop.mjs, npcTokenCreate→create-token.mjs, selectItem→actor-itemDrop.mjs, skillSelect→skill-selection.mjs, newWound/treatWound→damage.mjs, damageDiff→combat-roll.mjs, difficulty→check.mjs) all continue to work unchanged — form field names + skillSelect JS hooks are preserved exactly.

### Lang impact

+1 i18n key (`Elysium.flatModHint`) — latent-bug fix for a legacy reference that resolved to an empty/key-string fallback. en-key count: 1259 → 1260. Spanish + French parity gaps widen by 1 each (es-gap: 205 → 206, fr-gap: 205 → 206); these will be addressed in P12 lang-completion sweep alongside other latent gaps.

### Pre-flight checks performed

1. JS parse: `node --check module/hooks/init.mjs` — OK.
2. JSON parse: `system.json` valid; `lang/{en,es,fr}.json` valid (en grows by 1 key).
3. CSS brace balance: `styles/elysium-chat.css` 63 → 70 (+7 from 6 new dialog rule blocks; the title rule re-uses the existing __title block style); `css/legacy.css` 221 → 220 (-1 from `.selectList` retirement). All other CSS files unchanged.
4. Handlebars block balance: dialog-row partial 7/7, all 10 dialogs balanced (0/0 to 8/8 blocks per template).
5. Handlebars mustache balance: all 10 dialogs + 1 partial balanced.
6. i18n key existence: 22 distinct keys across cluster-5 templates; 1 was missing pre-cluster-5 (`Elysium.flatModHint`); added; **all 22 now resolve**.
7. Design-token existence: 36 distinct `--ely-*` tokens consumed in `elysium-chat.css`; all defined. No new tokens introduced.
8. Legacy CSS retirement: `.elysium .selectList` retired (5 lines, 1 brace pair); pre-flight grep confirmed zero remaining consumers in functional code.
9. Lang parity: en=1260, es-gap=206, fr-gap=206.

### Smoke methodology + results

**15 end-to-end fixtures** rendered through real Handlebars compile + render with partial registration:

- **selectPower** (1) — single select with options
- **getValue** (1) — numeric input with Number dtype
- **hitLocChoice** (1) — title + select with pre-selected value
- **npcTokenCreate** (2) — askStats true / false
- **selectItem** (1) — 3-item radio list with auto-checked first
- **skillSelect** (1) — audit-5 hook verification with 3 selectOptions and picks=2
- **newWound** (2) — getDam+getLoc / getDam only
- **treatWound** (1) — full (all 3 sections)
- **damageDiff** (1) — all 4 rows shown
- **difficulty** (4) — NO card, RE card (with addStat + resistance), PP card (with resistance + vsPOW label), useDiffValue toggle

**112 distinct audit-5 contract checks all green** across the 15 fixtures:

- Universal checks per fixture: no `.selectList` class, no `resource-label-diff`, no `diff-number-input`
- Per-fixture: `<form class="elysium elysium-dialog">` or `<section class="elysium elysium-dialog">` wrapper present
- `data-handle-change` preserved on every select/input
- `name="..."` attributes match the legacy values exactly (form-data extraction will continue to work)
- New BEM-element classes correctly applied: `__title`, `__row`, `__counter`, `__select-row`, `__radio-row`
- skillSelect 6 audit-5 hooks ALL preserved (`.skill-select`, `.count`, `.select.rollable`, `.mediumIcon`, `data-set` attribute, `.item-X`)
- skillSelect 7 cosmetic classes ALL retired from markup (`selectList`, `new-row`, `charname`, `skill-opt-label`, etc.)
- Conditional rendering verified: askStats true vs false, getDam+getLoc combos, RE vs PP vs NO cardType branching, useDiffValue toggle between input and select
- RE-vs-PP label variation in difficulty.hbs (resistance row uses different label per cardType)
- difficulty.hbs flatMod tooltip references `Elysium.flatModHint` (now resolves to a translation)

**Live smoke deferred** to post-ship verification: trigger each dialog through actual game actions:
- Cast a spell → selectPower
- Roll a difficulty → difficulty (with various cardTypes)
- Damage roll → damageDiff
- Wound application → newWound + treatWound
- First-aid → difficulty with firstAid flag
- Skill selection during character creation → skillSelect
- NPC token creation → npcTokenCreate
- Hit-location selection → hitLocChoice
- Item drop → selectItem
- Numeric prompt → getValue

### Cluster 5 LOC summary

- 1 partial added: +42 LOC
- 10 templates rewritten: 226 → 225 LOC (-1)
- `styles/elysium-chat.css`: +52 LOC (6 new dialog rules + Section B1c sub-block)
- `css/legacy.css`: -5 LOC (`.elysium .selectList` retirement)
- `lang/en.json`: +1 LOC (latent-bug-fix key)
- `module/hooks/init.mjs`: +2 LOC (partial registration)
- `system.json`: 1 LOC modified
- Documentation: cluster-5 audit (441 LOC) + this changelog entry

**Net non-documentation change**: +91 LOC. The win isn't LOC reduction (cluster 5 is template-LOC-positive); the wins are:
1. **Consistency** — 9 of 10 dialogs share a single row pattern via composition
2. **Architectural** — first introduction of a `templates/dialog/parts/` directory and a dialog-row partial vocabulary
3. **Second P11 legacy CSS retirement** (`.elysium .selectList`) continuing the cluster-4 eager-retirement pattern
4. **Latent-bug fix** — `Elysium.flatModHint` translation added, fixing a tooltip that had been rendering the raw key string in difficulty.hbs since whenever this key was first referenced
5. **All audit-5 hooks preserved verbatim** — skillSelect's 6 JS-imperative class/attr hooks survive the rebuild intact
6. **5 retired cosmetic classes from skillSelect** (`selectList`, `new-row`, `charname`, `skill-opt-label`, `font14`, plus `centre` + `bold`)
7. **All 21 user-facing chat-card + dialog templates** now on v1.0.0

### Milestone — generic dialog scope closes

Cumulative across P11 clusters 1-5:
- 11 chat-card templates on v1.0.0 (clusters 1-4)
- 10 generic dialog templates on v1.0.0 (cluster 5)
- **21 of 21 user-facing chat+dialog templates** (100%)
- 8 shared partials built: 5 cluster-1 (chat-card-shell, participant-row, success-pip, tooltip-rows, resolve-footer), 1 cluster-2 (chat-card-grouproll), 1 cluster-4 (chat-card-actor-list), 1 cluster-5 (dialog-row)
- 2 Handlebars patterns introduced: partial-block via `@partial-block` (cluster 4); flat-args partials (cluster 5)
- 2 legacy CSS rules retired: `.elysium .XPCheck` (cluster 4), `.elysium .selectList` (cluster 5)
- 3 latent bugs fixed: `flgs`→`flags` typo in `combined-card.mjs` (cluster 2), empty `[]` healing bracket in roll-result (cluster 3), missing `Elysium.flatModHint` translation (cluster 5)
- All 15 chat-card types have populated Section D accent rules

### Next

Per cluster-5 open-question #6, after cluster 5 ships the options are:
- **Optional cluster 6** — Island harmonisation evaluation. Are the 4 v1.0.0 islands (cast-card, manipulation, csb, tcd) retokened in cluster 1 still well-aligned after all the cluster-1-5 work, or do they need a re-sweep? Audit-only effort.
- **Optional cluster 7** — Combat-tracker cosmetic restyle. Visual polish for the combat tracker sidebar tab.
- **Jump to P12** — Polish + acceptance. Lang-completion sweep, attribute cleanup (`data-handle-change` retirement), `darkred` → `--ely-text-danger` retoken, additional legacy CSS retirements based on a full orphaning audit.

Recommendation: ship cluster 5 first, then assess. The optional clusters are low-risk audits; if they find work, that's ~1-2 days of cluster work; if they find nothing, jump to P12.

---

## [1.0.0-alpha.48] — P11 cluster 4: chat micro-cards (XP / rollStats / itemDescription) · CLOSES chat-card scope

P11 cluster 4 prep audit (`docs/p11-cluster4-audit.md`, 336 lines) shipped first; all 8 decisions (c4-1 through c4-8) plus 6 open questions locked per user "proceed with recommended". Rebuilds the 3 chat micro-cards (`XP-result.html`, `rollStats.html`, `itemDescription.html`). After alpha.48, **11 of 11 chat-card templates** are on v1.0.0 (100%). **P11 chat-card scope closes**; remaining P11 work is cluster 5 (10 generic dialogs in `templates/dialog/`).

### First legacy CSS rule retirement of P11

Cluster 4 retires `.elysium .XPCheck` from `css/legacy.css` (4 lines, 1 brace pair). The class was only consumed by the legacy `XP-result.html` and `rollStats.html` templates being rebuilt in this cluster; pre-flight grep confirmed zero remaining consumers across `templates/`, `module/`, and other CSS files. The P11 prep audit (c11-13) reserved CSS-file rule retirements for the P12 final sweep, but `.XPCheck` is so isolated that holding it until P12 just clutters legacy.css with dead code. **Recommendation in c4-5 was eager retirement, locked by user.** `css/legacy.css` brace count: 222 → 221.

This is the precedent for cluster 5 to retire dialog-only legacy CSS rules where they're similarly isolated.

### Cluster-4 cards diverge from the cluster-1 partial vocabulary

Cluster 4's 3 templates share NONE of the structural traits the cluster-1/2/3 cards share:
- No `chatCard` array (XP-result uses `success`; rollStats uses `results`; itemDescription has just `label` + `description`)
- No participant portrait pattern — XP-result and rollStats show ONE actor portrait at the top
- No pip strip — XP-result shows certificate/skull per row; rollStats shows none; itemDescription shows none
- No tooltip block — these are flat results
- No buttons — read-only

The cluster-1 partials (chat-card-shell, chat-card-participant-row, chat-card-success-pip, chat-card-tooltip-rows, chat-card-resolve-footer) don't compose into these cards. Cluster 4 needs its own approach.

### New shared partial — `chat-card-actor-list.hbs` (39 LOC)

The XP-result and rollStats templates are **near-identical** (same outer shell of form/title-header/portrait/iterated-rows; only the per-row content differs). Cluster 4 introduces a third shared chat partial using **Handlebars partial-block syntax** to capture this symmetry:

```hbs
{{#> "systems/elysium/templates/chat/parts/chat-card-actor-list.hbs"
     cardType="XP" titleKey="Elysium.xpRoll" actorImg=actrImage actorName=actrName}}
  {{#each success as |line key|}}
    <div class="elysium-chat-card__row">...per-row content...</div>
  {{/each}}
{{/"systems/elysium/templates/chat/parts/chat-card-actor-list.hbs"}}
```

The partial wraps `<form class="elysium elysium-chat-card" data-card-type=...>` + `<div class="elysium-chat-card__title">` + portrait img + body container with `{{> @partial-block}}`. The caller passes per-row iteration as the partial-block. Handlebars 4+ supports this; **verified live in Foundry's Handlebars before coding** by testing the partial-block syntax in the test world's console.

**Handlebars close-tag quirk**: the close tag for a partial-block must repeat the full path string of the open tag — `{{/"systems/elysium/templates/chat/parts/chat-card-actor-list.hbs"}}`. The short forms `{{/}}` (parse error: "Expecting 'ID'") and `{{/chat-card-actor-list}}` (parse error: "path doesn't match") both fail. Discovered during smoke run and corrected; documented here for future cluster-5+ work that might use partial-blocks.

itemDescription is 5 LOC — small enough that partial composition adds more overhead than it saves. Rebuilt standalone with the new marker class + `__title` and `__body` BEM elements:

```hbs
<form class="elysium gr-card elysium-chat-card" data-card-type="ID">
  <div class="elysium-chat-card__title">{{label}}</div>
  <div class="elysium-chat-card__body">{{{description}}}</div>
</form>
```

The triple-stash `{{{description}}}` preserves embedded HTML (rich item descriptions with `<strong>`, `<ul>`, `<em>`, `<a>`, embedded images, etc.). Smoke verified HTML preservation by rendering a fixture with `<p><strong>Curse:</strong> ...</p><ul><li>...</li></ul><em>...</em>` and confirming all tags pass through.

### Files added (1)

- `templates/chat/parts/chat-card-actor-list.hbs` (39 LOC) — actor-list shared shell for XP-result + rollStats. Uses `{{> @partial-block}}` body slot. Registered in `module/hooks/init.mjs` `loadTemplates` block.

### Files modified — 3 templates rewritten

- `templates/chat/XP-result.html`: **18 → 19 LOC** (compose actor-list partial; close-tag full-path string adds a line)
- `templates/chat/rollStats.html`: **12 → 13 LOC** (compose actor-list partial)
- `templates/chat/itemDescription.html`: **5 → 11 LOC** (standalone; +6 LOC from doc-comment + new BEM `__title`/`__body` markup)

Net templates change: 35 → 43 LOC (+8 LOC). Cluster 4 is net-positive on templates because the cluster-4 templates were already so small that adding the marker class + doc comments adds overhead. The win isn't LOC reduction — it's:

1. **Consistency** — all 11 chat-card templates now use the v1.0.0 `elysium-chat-card` scoping marker, `data-card-type` attribute, and `__title`/`__body`/`__row` BEM-element classes.
2. **Latent cleanup** — 4 inline-style declarations retired (2 × `display: block`, 2 × `padding-left: 10px`), replaced by token-driven CSS rules.
3. **First P11 legacy CSS retirement** — `.elysium .XPCheck` removed (4 lines + 1 brace pair, `css/legacy.css` 1640 → 1636).

### Section D card-type accents — 3 new entries

Populated Section D entries for the 3 new card types:

- `[data-card-type="XP"]` XP-result → `var(--ely-accent-success)` (green — improvement/progress)
- `[data-card-type="RS"]` rollStats → `var(--ely-accent-info)` (blue — character-creation utility)
- `[data-card-type="ID"]` itemDescription → `var(--ely-accent-bonus)` (gold — neutral content)

After cluster 4, **all 15 card types** (CB/OP/GR/CO/NO/RE/PP/CM/IM/DM/AR/QC/XP/RS/ID) have populated Section D rules. Section D is now feature-complete.

### Section B additions — `__row` and `__body` rules

Two new BEM-element rules in Section B (alongside the existing `__title`):

```css
.elysium-chat-card__row {
  padding-left: var(--ely-space-2);
  line-height: 1.5;
}

.elysium-chat-card__body {
  padding: var(--ely-space-1) 0;
}
```

`__row` replaces the legacy `style="padding-left: 10px"` inline on every `flavour-result` div (in XP-result and rollStats). `__body` is the slot for itemDescription's rich-text content and the chat-card-actor-list partial's body container. Both are token-driven.

### Files modified — summary

| File | Change |
|---|---|
| `templates/chat/parts/chat-card-actor-list.hbs` | ADDED (39 LOC) |
| `templates/chat/XP-result.html` | 18 → 19 LOC (compose partial-block) |
| `templates/chat/rollStats.html` | 12 → 13 LOC (compose partial-block) |
| `templates/chat/itemDescription.html` | 5 → 11 LOC (standalone v1.0.0 markup) |
| `styles/elysium-chat.css` | +25 LOC (3 Section D accents + `__row` + `__body` rules) |
| `css/legacy.css` | -5 LOC (.elysium .XPCheck retirement) |
| `module/hooks/init.mjs` | +2 LOC (partial registration) |
| `system.json` | version bump alpha.47 → alpha.48 |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution-log entry + progress-tracker line update |

**Net change**: +60 LOC (partial 39 + CSS +25 + init +2 + templates +8 = +74 added; legacy CSS -5; chnglog/roadmap not counted = +60 net excluding documentation).

### Class hook preservation (audit-5 lock)

- `open-actor` — Foundry built-in click handler that opens the actor sheet on portrait click. Preserved on the `<img>` element in `chat-card-actor-list.hbs`. The only audit-5 JS hook on cluster-4 surfaces.
- `gr-card` — preserved on `itemDescription.html` for hook-contract uniformity (Phase D filters on `rollType === 'CM'` so this card never triggers injection, but the class signals "this is an Elysium chat card surface").
- Foundry CSS-only hooks (`result-success`, `result-fail` for the XP-result icons) — preserved verbatim.

The legacy class hooks `XPCheck`, `flavour-result`, `font14` are NOT preserved on the new cluster-4 markup:
- `XPCheck` — retired from legacy.css and dropped from markup. Single rule, no replacement needed (the marker rule + `__title` already provides the header look).
- `flavour-result` — had no CSS rule (purely a semantic-marker class); dropped silently from markup.
- `font14` — markup-side drop only; the CSS rule in legacy.css stays because it has actor-sheet consumers (`.elysium .character .font14` at line 505). Cluster-4 chat cards inherit font sizing from the marker rule's `--ely-font-size-1` instead.

### Behavioural impact

Zero behavioural change. The 3 cards render structurally-equivalent DOM modulo:
- The new `elysium-chat-card` marker class
- The new `data-card-type` attribute
- Section D border-left accent (green/blue/gold)
- Token-driven background + typography (dark theme via the marker rule)
- The retired legacy `XPCheck` background-and-border styling (was `rgba(0,0,0,0.25)` background + `1px solid black` border + `3px` radius + `5px` left-padding; now the marker rule's `var(--ely-surface-card)` background + token typography do equivalent work in a way that integrates with the rest of the v1.0.0 chat card visual identity).

The XP-tick subsystem (`module/apps/charDev.mjs:144`), the character-creation roll-stats button (`module/actor/sheets/base-actor-sheet.mjs:316`), and the item-sheet "Post to Chat" feature (`module/apps/utilities.mjs:237`) all continue to work unchanged — the chat-data shapes they emit are identical; only the template markup changed.

### Lang impact

Zero new i18n keys. Two keys consumed (`Elysium.xpRoll`, `Elysium.rollStats`), both already resolved in `lang/en.json`. Pre-existing 205-key parity gap unchanged.

### Pre-flight checks performed

1. JS parse: `node --check module/hooks/init.mjs` — OK.
2. JSON parse: `system.json` valid; `lang/{en,es,fr}.json` valid.
3. CSS brace balance: `styles/elysium-chat.css` 58 → 63 (+5: 3 Section D rule blocks + `__row` + `__body`); `css/legacy.css` 222 → 221 (-1: `.elysium .XPCheck` retirement).
4. Handlebars block balance: new partial 2/2; XP-result 3/3; rollStats 2/2; itemDescription 0/0.
5. Handlebars mustache balance: 10/10, 12/12, 9/9, 4/4 across the 4 cluster-4-touched templates.
6. i18n key existence: 2 distinct `Elysium.X` literals, both resolve.
7. Design-token existence: 36 distinct tokens consumed in `elysium-chat.css`, all defined. 3 new Section D token consumers (success/info/bonus) all defined.
8. Legacy CSS retirement: 1 rule retired (`.elysium .XPCheck`), pre-flight grep confirmed zero consumers in `templates/` and `module/`.
9. Lang parity: unchanged at en=1259, es=1058 (gap: 205), fr=1058 (gap: 205).

### Smoke methodology + results

**5 end-to-end fixtures** rendered through real Handlebars compile + render with partial registration:

- **XP-result success-on-some** (3 skills, 2 succeed +improvVal=3, 1 fails) — verifies cert+skull icon switching, +N display on level=1
- **XP-result all-fail** (1 skill, level=0) — verifies the fail branch alone
- **rollStats 7 stats** — verifies the 7-row iteration and stat formula rendering
- **itemDescription plain text** — verifies the basic title+description render
- **itemDescription HTML content** (description with `<p>`, `<strong>`, `<ul>`, `<li>`, `<em>` tags) — verifies the triple-stash preserves embedded HTML for rich descriptions

**53 distinct audit-5 contract checks all green** across the 5 fixtures:

- `elysium-chat-card` marker class present on every card
- `data-card-type` attribute correctly set per card (XP/RS/ID)
- `open-actor` class preserved on XP-result + rollStats portrait imgs
- No `.cardbutton` on any card (read-only)
- No `.chat-dice` on any card (no bottom summary)
- `__title` class on every header; `__row` class on iterated rows; `__body` class on itemDescription body
- Legacy `XPCheck` class absent from rebuilt markup (retirement verified live)
- Inline `padding-left: 10px` absent (retirement verified)
- Inline `display: block` absent (retirement verified)
- XP-result success fixture has exactly 2 fa-certificate icons (one per level=1 entry) and 1 fa-skull icon (for the level=0 entry)
- XP-result `+3` improvVal renders next to level=1 entries
- rollStats has exactly 7 `__row` divs (one per stat)
- itemDescription `gr-card` class preserved (hook-contract uniformity)
- itemDescription HTML content renders all 5 tag types through triple-stash

**Live smoke deferred** to post-ship verification: post one of each card type in the test world via JS console or by triggering the actual game actions (skill check with XP-tick enabled, "Roll Stats" button on a new character sheet, "Post Description" on any item sheet).

### Cluster 4 LOC summary

- 1 partial added: +39 LOC
- 3 templates rewritten: 35 → 43 LOC (+8 LOC)
- `styles/elysium-chat.css`: +25 LOC (3 Section D + `__row` + `__body`)
- `css/legacy.css`: -5 LOC (`.elysium .XPCheck` retirement)
- `module/hooks/init.mjs`: +2 LOC (partial registration + comment)
- `system.json`: 1 LOC modified
- Documentation: cluster-4 audit (336 LOC) + this changelog entry

**Net non-documentation change**: +69 LOC. Cluster 4 is the smallest cluster in P11 by LOC but represents an important milestone:
- 100% of the legacy chat-card templates are now on v1.0.0
- All 15 chat-card types have Section D accents
- First legacy CSS rule retirement in P11
- Three new BEM-element classes (`__title`, `__row`, `__body`) form a small reusable shared vocabulary for v1.0.0 chat surfaces

### Milestone — P11 chat-card scope closes (all 11 templates)

After alpha.48, the 11 legacy chat-card templates are all rebuilt on v1.0.0:

| Cluster | Alpha | Templates |
|---|---|---|
| 1 (foundation) | alpha.45 | 5 partials + chat CSS + 4 island retoken (no templates rebuilt) |
| 2 (group-roll quartet) | alpha.46 | roll-combat, roll-opposed, roll-combined, roll-cooperative |
| 3 (singleton-roll) | alpha.47 | roll-result, roll-damage, roll-armor, quick-combat |
| 4 (chat micro-cards) | alpha.48 | XP-result, rollStats, itemDescription |

Cumulative across P11 clusters 1-4: 11/11 chat templates on v1.0.0; 7 shared partials built (5 from c1 + grouproll from c2 + actor-list from c4); 1 new partial concept (Handlebars partial-block via @partial-block) introduced; 5 legacy CSS rules retired across clusters 2+4 (the c2 `flgs` → `flags` typo JS fix in `combined-card.mjs` is a behavioral fix not a CSS retirement; the c4 `.XPCheck` retirement is the first CSS-rule retirement); 2 latent bugs fixed (`flgs` typo + empty `[]` healing bracket).

### Next

**Cluster 5** — Generic dialogs in `templates/dialog/`. 10 files. Different surface from chat cards: ApplicationV2-rendered modals, not chat messages. The cluster-1 partials (shell/participant-row/etc.) don't apply; cluster-1's `.elysium-dialog` scoping marker (shipped in alpha.45) is the entry point. Cluster 5 audit will assess each dialog template for its shape (some are simple confirmation prompts; some have complex layouts like the combat-targeting dialog). Ships as alpha.49.

After cluster 5, P11 has the optional clusters 6 (island harmonisation) and 7 (combat-tracker cosmetic restyle). Then P12 (polish + acceptance).

---

## [1.0.0-alpha.47] — P11 cluster 3: singleton-roll cards (result / damage / armor / quick-combat) via composition

P11 cluster 3 prep audit (`docs/p11-cluster3-audit.md`, 412 lines) shipped first; all 13 decisions (c3-1 through c3-13) plus 5 open questions locked per user "proceed with recommended". Rebuilds the 4 singleton-roll chat cards (`roll-result.html`, `roll-damage.html`, `roll-armor.html`, `quick-combat.html`) onto cluster-1 partials through DIRECT COMPOSITION (Option B), rather than building a new umbrella partial like cluster 2's grouproll. After alpha.47, **8 of the 11 legacy chat-card templates** (73%) are on v1.0.0.

### Cluster-1 partials already covered all cluster-3 needs — zero extensions required

The prep audit (§3 decisions c3-6, c3-7) anticipated two cluster-1 partial extensions: a `healingAnnotation` parameter on `chat-card-success-pip.hbs` and a `flatValueLabel` extension on `chat-card-participant-row.hbs`'s `flat-value` resultMode. **On closer inspection during coding, both were already implemented in cluster 1**:

- `chat-card-success-pip.hbs` (alpha.45) ships with a `healing` parameter and `{{#if healing}} [{{healing}}]{{/if}}` annotation in levels 4/3/2/0 (correctly omitted on level-1 per legacy convention).
- `chat-card-participant-row.hbs` (alpha.45) ships with a `flat-value` resultMode that already builds the spec/critical label from `entry.resultLevel` + `entry.specLabel` (line 81 of the partial): `{{entry.rollVal}}{{#if (eq entry.resultLevel "4")}} {{localize 'Elysium.critical'}}-{{entry.specLabel}}{{/if}}{{#if (eq entry.resultLevel "3")}} {{entry.specLabel}}{{/if}}`.
- The pip-strip resultMode also already renders the malfunction marker as a sibling and the hit-location tag (with `elysium-chat-chip` class) when `showHitLocTag=true`.

This means the cluster-1 work was MORE thorough than the cluster-3 prep audit captured. **The 4 cluster-3 templates compose the cluster-1 partials directly with no partial signature changes.** The c3-6 and c3-7 "extensions" become no-ops; the decisions stand as documentation that the cluster-3 wrappers don't need to do anything special for these features.

### Latent bug fixed by composition — empty `[]` healing brackets

The legacy `roll-result.html` template referenced `healing` as a bare variable inside `{{#each chatCard as |c key|}}` (lines 28/32/36/44). Handlebars resolves bare names against the current context first; for an entry alias `c`, bare `{{healing}}` should equal `{{c.healing}}`. BUT the legacy template used `{{healing}}` directly (not `{{c.healing}}`), which in some Handlebars versions falls through to the outer context. The outer chatMsgData object NEVER had a top-level `healing` field (it's only present per-participant under `chatCard[0].healing`).

When `config.healing` is undefined (the common case — `config.healing` is set only when `config.firstAid` is true), the legacy `{{#unless (eq healing 0)}} [{{healing}}]{{/unless}}` evaluated `(eq undefined 0)` → false → `{{#unless false}}` → render body → `[{{undefined}}]` → empty bracket text `[]`.

End-user symptom: every non-firstAid result card showed an empty `[]` next to the rollVal. Subtle visual noise, easy to miss.

The cluster-1 partial uses `{{#if healing}}` which evaluates `undefined` as falsy AND `0` as falsy (both correctly suppressed). Only truthy non-zero values render the bracket. **Cluster 3's composition silently fixes this latent rendering bug.**

### Files modified — 4 singleton-roll templates rewritten as thin wrappers

- `templates/chat/roll-result.html`: **87 → 52 LOC** (-35 LOC, -40%) — 4-way title branch (CM/RE/PP/NO from rollType+cardType), pip-strip via participant-row partial (healing + malfunction + hitloc all auto-rendered by cluster-1 wiring), attribute-resistance tooltip via tooltip-rows partial. `data-card-type` uses rollType=CM as the priority signal (Phase D filters on rollType==='CM') with fallback to cardType.
- `templates/chat/roll-damage.html`: **32 → 28 LOC** (-4 LOC, -13%) — 2-way title branch (IM/DM from rollType), flat-value mode via participant-row partial (auto spec/critical label append), damage tooltip via tooltip-rows partial. `data-card-type="{{rollType}}"` — JS emits cardType=NO for damage rolls but rollType distinguishes IM vs DM. Net LOC saving smaller than other cards because legacy roll-damage was already small.
- `templates/chat/roll-armor.html`: **27 → 20 LOC** (-7 LOC, -26%) — single title, flat-value via participant-row, armor tooltip via tooltip-rows. `data-card-type="AR"` (static).
- `templates/chat/quick-combat.html`: **71 → 35 LOC** (-36 LOC, -51%) — single title, pip-strip via participant-row (auto malfunction via partial), attribute-resistance tooltip via tooltip-rows (handles dmgCritForm/dmgSpecForm/dmgNormForm rows via the `{{#if entry.dmgCritForm}}` branch). Per-participant footer damage row preserved verbatim with `quick-combat centre` class hooks (legacy CSS at `css/legacy.css:1467` + `:399`). `data-card-type="QC"` (static).

**Net template change**: 217 → 135 LOC (-82 LOC, -38%). Closer to the prep-audit's -72 LOC projection than the cluster-2 quartet's actual -243 because cluster 3 is composition-not-inlining, so each wrapper stays around 20-50 LOC rather than collapsing to 12-18.

### Section D card-type accents — 8 new rules

Populated 8 placeholders in `styles/elysium-chat.css` Section D for the remaining cluster-3 card types, with token-driven 3px left borders:

- `[data-card-type="NO"]` Normal roll → `var(--ely-accent-bonus)` (gold)
- `[data-card-type="RE"]` Resistance → `var(--ely-accent-mind)` (purple — willpower/mind family)
- `[data-card-type="PP"]` POW vs POW → `var(--ely-accent-mind)` (purple — same family as RE)
- `[data-card-type="CM"]` Combat-Manoeuvre → `var(--ely-accent-action)` (crimson — matches CB)
- `[data-card-type="IM"]` Impact → `var(--ely-accent-fire)` (orange-red — damage family)
- `[data-card-type="DM"]` Damage → `var(--ely-accent-fire)` (orange-red — same family as IM)
- `[data-card-type="AR"]` Armor → `var(--ely-accent-bonus)` (gold — defensive)
- `[data-card-type="QC"]` Quick-Combat → `var(--ely-accent-action)` (crimson — matches CM)

After alpha.47, all 12 card-type placeholders in Section D are populated. Net +27 LOC across 8 new selectors.

### Hit-location tag retoken (c3-5)

The legacy `roll-result.html` had a hardcoded inline style on the hit-location tag:

```
<span class="elysium-hitloc-tag" ... style="margin-left:6px;padding:1px 6px;border-radius:3px;background:#604030;color:#fff;font-size:11px;">
```

The cluster-1 partial (`chat-card-participant-row.hbs` line 64) already shipped with the retokened markup:

```
<span class="elysium-hitloc-tag elysium-chat-chip" data-hit-loc-id="{{entry.hitLocationId}}">→ {{entry.hitLocationName}}</span>
```

The `.elysium-chat-chip` base class (token-driven: surface-raised background, text-decorative color, border-subtle border, radius-0 corners, font-size-0, font-weight-medium, padding 1px var(--ely-space-1)) replaces all 5 inline-style declarations with token-driven CSS. The audit-5-locked `data-hit-loc-id` attribute and `.elysium-hitloc-tag` JS-imperative class are both preserved verbatim — `applyHitLocationVisibility(root)` in `chat-card.mjs:35` continues to gate visibility via `querySelectorAll('.elysium-hitloc-tag')`.

### Class hook preservation (audit-5 lock)

- `form.elysium.gr-card` — preserved on all 4 wrappers. Phase D injection (`combat-card-buttons.mjs:94`) targets `rollType === 'CM'` cards specifically; only `roll-result.html` rendered with rollType=CM gets Phase D buttons. The other 3 cards never trigger injection, but they preserve the class for hook-contract uniformity.
- `.cardbutton` — NOT USED in cluster 3 (no buttons on singleton cards).
- `.owner-only` + `data-partic-id` + `data-partic-type` — preserved on all 4 cards via cluster-1 tooltip-rows partial.
- `.elysium-hitloc-tag` + `data-hit-loc-id` — preserved on roll-result via cluster-1 participant-row partial's `showHitLocTag=true` path.
- `.elysium-chat-card` — new c11-1 scoping marker on all 4 cards.
- `pending`/`roll-succ`/`roll-fail`/`roll-fumb`/`result-success`/`result-fail`/`result-yellow` — pip class hooks preserved on roll-result + quick-combat via cluster-1 success-pip partial.
- `data-action="expandRoll"` — Foundry built-in expand-tooltip handler preserved on the `.dice-roll` wrapper.

### Files modified — summary

| File | Change |
|---|---|
| `templates/chat/roll-result.html` | 87 → 52 LOC (composition) |
| `templates/chat/roll-damage.html` | 32 → 28 LOC (composition) |
| `templates/chat/roll-armor.html` | 27 → 20 LOC (composition) |
| `templates/chat/quick-combat.html` | 71 → 35 LOC (composition) |
| `styles/elysium-chat.css` | +27 LOC (Section D NO/RE/PP/CM/IM/DM/AR/QC accents) |
| `system.json` | version bump alpha.46 → alpha.47 |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution-log entry + progress-tracker line update |

Zero cluster-1 partial extensions needed (the foundation work was sufficient). Zero JS changes. Zero new i18n keys.

### Behavioural impact

Zero on the surface, with one positive side-effect:

- The 4 cards render structurally-equivalent DOM to the legacy templates modulo the new `elysium-chat-card` marker class, the `data-card-type` attribute, and the hit-location tag's retokened chip styling.
- Phase D combat-card-button injection continues working on roll-result rendered with rollType=CM: `form.elysium.gr-card` mount-point selector preserved verbatim.
- **Latent bug fixed**: roll-result no longer renders empty `[]` healing brackets when `config.healing` is undefined (the common non-first-aid case).
- Hit-location tag now uses token-driven styling instead of hardcoded `#604030`/`#fff`/etc. Visually it shifts from a brown-on-white parchment chip to a dark surface-raised chip with bone-decorative text — consistent with the dark theme identity established in cluster 1.

### Lang impact

Zero new i18n keys. The 10 distinct `Elysium.X` literals consumed across cluster-3 templates (`Elysium.card.NO`, `Elysium.card.RE`, `Elysium.card.PP`, `Elysium.card.CM`, `Elysium.card.IM`, `Elysium.card.DM`, `Elysium.card.AR`, `Elysium.card.QC`, `Elysium.damagesAbbr`, `Elysium.damagesAbbrHint`) all resolve in `lang/en.json`. The remaining ~15 keys referenced by the cluster-1 partials (Elysium.malfunction, Elysium.rawScore, Elysium.targetScore, Elysium.flatMod, Elysium.healing, Elysium.diceRoll, Elysium.description, Elysium.impact, Elysium.dice, Elysium.armor, Elysium.critical, Elysium.special, Elysium.normal, Elysium.difficulty, Elysium.resistVal, Elysium.remove, Elysium.grTag) also already resolve (verified during cluster 1's i18n sweep).

### Pre-flight checks performed

1. JS parse: `node --check module/hooks/init.mjs` — OK (no JS changes in cluster 3 except version string in system.json).
2. JSON parse: `system.json` valid; `lang/{en,es,fr}.json` valid.
3. CSS brace balance: `styles/elysium-chat.css` 58/58 unchanged (8 new selector blocks added 16 braces; 8 commented placeholders with `{ }` chars removed 16 braces; net zero delta — same trick as cluster 2's Section D rule additions).
4. Handlebars block balance: 4 wrappers all balanced (roll-result 3/3, roll-damage 2/2, roll-armor 1/1, quick-combat 2/2).
5. Handlebars mustache balance: all 4 wrappers balanced (18/18, 11/11, 6/6, 14/14).
6. i18n key existence: 10 distinct keys across cluster-3 templates, all resolve.
7. Design-token existence: 36 distinct `--ely-*` tokens consumed in `elysium-chat.css`; all defined in `elysium-tokens.css`. The 7 new token consumers for Section D (action/danger/info/success/bonus/mind/fire) are all defined.
8. Legacy CSS retirement: ZERO rule blocks retired in c3 (only the inline-style attribute on hitloc-tag, which is markup not CSS-file).
9. Lang parity: unchanged at en=1259, es=1058 (gap: 205), fr=1058 (gap: 205).

### Smoke methodology + results

**16 end-to-end fixtures** rendered through real Handlebars compile + render:

- **roll-result**: NO+level4, NO+level1, RE, PP, CM+hitloc, CM+malfunction, NO+healing=5, NO+no-healing-field (8 fixtures)
- **roll-damage**: DM+level4 (critical+specLabel), DM+level3 (special+specLabel), DM+level2 (plain), IM (4 fixtures)
- **roll-armor**: single fixture (no variation)
- **quick-combat**: QC+critical (with damage footer), QC+success (with damage footer), QC+failure (no damage footer) (3 fixtures)

**113 distinct assertions** across the fixtures, all green:

- Phase D mount-point `<form class="elysium gr-card elysium-chat-card">` present on every card
- `data-card-type` attribute correct per card (dynamic from rollType for damage/result-CM; static for armor/QC; rollType-or-cardType priority for result)
- No `.cardbutton` on any singleton card (correct — read-only result cards)
- No `.chat-dice` on any singleton card (correct — no bottom summary)
- `.owner-only` tooltip block per card with correct `data-partic-id` + `data-partic-type`
- Hit-loc tag carries chip class + has NO inline `style="..."` on CM-with-hitloc fixtures
- `data-hit-loc-id="h1"` preserved on hit-loc tag
- Malfunction marker renders inline on CM-with-malfunction fixtures
- Healing bracket `[5]` renders correctly when healing=5; NO empty `[]` when healing field is missing (latent-bug-fix verification)
- Damage cards show "Elysium.critical" + specLabel on level 4; specLabel only on level 3; plain rollVal on level ≤ 2
- Quick-combat critical fixture shows the per-participant footer `quick-combat centre` div with `14/9[Bleed]/5` damage tuple
- Quick-combat tooltip shows the 3 damage form rows (`2d8+4` etc.)
- Quick-combat failure fixture has NO footer damage row (the `{{#if (gt c.resultLevel 1)}}` gate works)

**Live smoke deferred** to post-ship verification: post a CM-rollType roll-result card and verify Phase D injection fires, hitloc tag renders with chip styling, hitloc visibility setting still respected. Offline-render confirmed the mount-point selector + class hooks are present on every rendered card.

### Cluster 3 LOC summary

- 4 templates rewritten: 217 → 135 LOC (-82 LOC, -38%)
- `styles/elysium-chat.css`: +27 LOC (8 new Section D rules)
- `system.json`: 1 LOC modified
- `CHANGELOG.md`: this entry
- `ROADMAP-v1.0.0.md`: execution-log entry + progress-tracker line update

**Net non-changelog change**: -54 LOC across all files. Plus one latent-bug fix and 8 new card-type accents finalizing Section D for the 12 chat-card types.

### Next

**Cluster 4** — Chat micro-cards: `XP-result.html`, `rollStats.html`, `itemDescription.html`. Per cluster-3 audit open-question #5, these have very different shapes from the cluster-1/2/3 cards (no participants, no pip strips, no chatCard array). They'll likely be rebuilt as their own small templates rather than composing cluster-1 partials. Ships as alpha.48 after cluster 4 prep audit.

---

## [1.0.0-alpha.46] — P11 cluster 2: group-roll quartet onto shared partial + latent-bug fix

P11 cluster 2 prep audit (`docs/p11-cluster2-audit.md`, 288 lines) shipped first; all 12 decisions (c2-1 through c2-12) plus 4 open questions locked per user "proceed with recommended". Rebuilds the 4 group-roll chat cards (`roll-combat.html`, `roll-opposed.html`, `roll-combined.html`, `roll-cooperative.html`) onto a single shared `chat-card-grouproll.hbs` partial driven by per-card context flags. After alpha.46, **4 of the 11 legacy chat-card templates** (36%) are on v1.0.0.

### Discovered + fixed latent bug — combined-card GRClose `flgs` typo

`module/cards/combined-card.mjs:104` had `'flgs.elysium.successLevel': -1` — a one-character typo (`flgs` for `flags`). The handler is invoked when a player Closes a combined-roll card without resolving it; the intent is to write `-1` to `flags.elysium.successLevel` so the chat-card template's `{{#unless (eq successLevel -1)}}` gate hides the (now-stale) bottom-row summary. Instead, the typo wrote a junk `flgs` top-level flag tree (`flgs: {elysium: {successLevel: -1}}`) while the real `flags.elysium.successLevel` retained whatever fractional value it last held. End-user symptom: force-closing a combined card left the partial-success summary visible despite the chatCard being cleared. One-character fix at the same site (`flgs` → `flags`). Per Rule 1 (no band-aids; fix root causes), absorbed into cluster 2 alongside the markup work rather than deferred to a standalone hotfix — same pattern as alpha.42's itemToggle latent-bug discovery during cluster-4 ship.

### New shared partial — `chat-card-grouproll.hbs` (151 LOC)

The unified group-roll body partial. The 4 group-roll cards reduce to thin per-card wrappers that build a 5-dimensional context (title key / resolve preset / crown flag / pip-value-source / resolve-class) plus a 3-mode bottom-summary flag (`'none'` / `'text-summary'` / `'pip-strip'`) and include the partial. The partial iterates `chatCard` array, inlines the participant strip (per-iteration variation on crown + pip-value-source needs computed booleans that Handlebars partial parameters can't express without adding new `and`/`not` helpers; inlining keeps the cluster-1 partial signatures stable for cluster 3+ consumers and confines the variation to one place), and renders the optional bottom summary.

**Inlined vs cluster-1-partial-composed (c2-2 decision)**: The 5 cluster-1 partials (chat-card-shell, participant-row, success-pip, tooltip-rows, resolve-footer) remain available — cluster 3+ templates whose per-card variation fits their fixed signatures will compose them directly. Cluster 2's grouproll partial INLINES the participant-row + success-pip + tooltip-rows markup because its per-card variation crosses 5 dimensions and would force ugly aliasField/and/not helper additions to compose cleanly. Trade-off: ~150 LOC partial vs ~70 LOC if composed; in exchange the 5 cluster-1 partials keep their pristine signatures and Handlebars helpers stay at the existing 10-helper count.

**Audit-5 class hooks preserved verbatim** on every rendered output: `form.elysium.gr-card` (Phase D mount-point selector — combat-card-buttons.mjs:94), `.cardbutton`, `data-preset` values (`resolve-cb-card`/`resolve-op-card`/`resolve-gr-card`/`resolve-co-card`/`close-card`/`remove-gr-roll`), `.owner-only` + `data-partic-id` + `data-partic-type` on per-participant tooltip blocks, `.gm-visible-only` on combat/opposed resolve buttons + per-row remove buttons, `data-rank` on remove buttons, legacy `data-particType` (camelCase per c11-3a) on combined/cooperative resolve buttons, `pending`/`roll-succ`/`roll-fail`/`roll-fumb`/`result-success`/`result-fail`/`result-yellow` pip class hooks, `actor-roll`/`dice-roll`/`roll-details`/`header`/`name`/`tag`/`roll-truncate`/`dice-tooltip`/`gr-list`/`open-actor` legacy layout classes, `rollHidden`/`bottom-line` tooltip-row classes, `chat-dice` bottom-summary class.

### 4 group-roll templates rewritten as thin wrappers

- `roll-combat.html`: **75 → 18 LOC** (-57 LOC, -76%) — wrapper sets cardType="CB", showCrown=true, pipValueSource="rollResult", bottomSummaryMode="none"; resolve class gm-visible-only.
- `roll-opposed.html`: **75 → 18 LOC** (-57 LOC, -76%) — wrapper identical to combat except cardType="OP" and data-preset="resolve-op-card".
- `roll-combined.html`: **88 → 28 LOC** (-60 LOC, -68%) — wrapper sets cardType="GR", showCrown=false, pipValueSource="none" (combined cards share ONE rollResult across all participants; showing per-row would just repeat the same number), bottomSummaryMode="text-summary" (legacy h3 with fractional successLevel → "Elysium.resultLevel.1"/"Elysium.resultLevel.2"/"Elysium.partial" branching); resolve class owner-only with data-partic-id + data-particType.
- `roll-cooperative.html`: **97 → 28 LOC** (-69 LOC, -71%) — wrapper sets cardType="CO", showCrown=false, pipValueSource="rollVal" (each participant rolls separately; per-row shows their own roll), bottomSummaryMode="pip-strip" (h3 with pip-style markup driven by successLevel ∈ 0..4 integer, successLabel, successRoll); resolve class owner-only.

**Net**: 4 templates 335 → 92 LOC (-243 LOC -73%); plus new partial +151 LOC = **-92 LOC net template change** for the cluster.

### Section D card-type accents (c2-8)

Populated 4 placeholders in `styles/elysium-chat.css` Section D with 3px left-border accents in the token color matching each card's semantic flavour:

- `[data-card-type="CB"]` Combat → `var(--ely-accent-action)` (crimson — combat is aggressive)
- `[data-card-type="OP"]` Opposed → `var(--ely-accent-danger)` (bright red — opposed is adversarial)
- `[data-card-type="GR"]` Combined → `var(--ely-accent-info)` (desaturated blue — combined is cooperative-but-mechanical)
- `[data-card-type="CO"]` Cooperative → `var(--ely-accent-success)` (green — cooperative is collaborative)

7 remaining card-type placeholders (NO / RE / PP / CM / IM / DM / AR / QC) stay commented for cluster 3 to populate. Section D net: +24 LOC.

### Files modified — summary

| File | Change |
|---|---|
| `templates/chat/parts/chat-card-grouproll.hbs` | ADDED (151 LOC) |
| `templates/chat/roll-combat.html` | 75 → 18 LOC (thin wrapper) |
| `templates/chat/roll-opposed.html` | 75 → 18 LOC (thin wrapper) |
| `templates/chat/roll-combined.html` | 88 → 28 LOC (thin wrapper) |
| `templates/chat/roll-cooperative.html` | 97 → 28 LOC (thin wrapper) |
| `styles/elysium-chat.css` | +24 LOC (Section D CB/OP/GR/CO accents) |
| `module/hooks/init.mjs` | +2 LOC (1 partial path + 1 comment line) |
| `module/cards/combined-card.mjs` | -1 char (`flgs` → `flags` typo fix) |
| `system.json` | version bump alpha.45 → alpha.46 |
| `CHANGELOG.md` | this entry |
| `ROADMAP-v1.0.0.md` | execution-log entry + progress-tracker line update |

### Behavioural impact

Zero, with one positive side-effect:

- The 4 cards render identical DOM to alpha.45 modulo the new `elysium-chat-card` marker class and the new `data-card-type` attribute. Pip strip / crown / per-row remove / tooltip / resolve+close buttons all carry the same class hooks + dataset attributes.
- Phase D combat-card-button injection continues working: `form.elysium.gr-card` mount-point selector preserved on all 4 wrappers. Verified at smoke time across both pending and closed states.
- **One behavioural fix**: the `flgs` typo fix means force-closing a combined-roll card now correctly hides the bottom-row summary (the `successLevel === -1` sentinel finally reaches its consumer).

### Lang impact

Zero new i18n keys. All consumed keys (`Elysium.card.CB`, `Elysium.card.OP`, `Elysium.card.GR`, `Elysium.card.CO`, `Elysium.remove`, `Elysium.grTag`, `Elysium.difficulty`, `Elysium.resolveCard`, `Elysium.closeCard`, `Elysium.malfunction`, `Elysium.partial`, `Elysium.resultLevel.0` / `.1` / `.2` / `.3` / `.4`, `Elysium.rawScore`, `Elysium.flatMod`, `Elysium.origResult`, `Elysium.diceRoll`) verified resolved in `en.json`. Pre-existing 205-key en→es/fr parity gap unchanged.

### Pre-flight checks performed

1. JS parse: `node --check module/hooks/init.mjs` + `node --check module/cards/combined-card.mjs` — both OK.
2. JSON parse: `system.json` valid; `lang/{en,es,fr}.json` valid.
3. CSS brace balance: `styles/elysium-chat.css` 58/58 (unchanged — the 4 new Section D rule-blocks (+8 braces) replaced 4 commented placeholders that already contained `{ }` characters inside their comments (-8 braces); zero net change in raw brace count); other CSS files untouched.
4. Handlebars block balance: new partial 29/29 block opens/closes; 4 wrappers each 1/1.
5. Handlebars mustache balance: new partial 130/130; 4 wrappers 7/7/9/9.
6. i18n key existence: 16 distinct `Elysium.X` literals across cluster-2-touched templates, all resolve in `en.json`.
7. Design-token existence: 4 new token consumers added (`--ely-accent-action`/`-danger`/`-info`/`-success` — all defined).
8. Legacy CSS retirement: ZERO rules retired (orphaning-candidates list documented below; deletion is P12 per c11-13).
9. Lang parity: unchanged at en=1259, es=1058, fr=1058 (205-key gap is pre-existing).

### Smoke methodology + results

**End-to-end Handlebars compile + render**: all 4 cards × {pending, closed} = 8 fixture renders. 73 distinct audit-5 contract checks pass across the cluster. Verified:

- Phase D mount-point `<form class="elysium gr-card...` present on all 4 cards
- `elysium-chat-card` scoping marker present
- `data-card-type` attribute set correctly per card
- Title localize keys correct
- Resolve preset correct (`resolve-cb-card` / `-op-card` / `-gr-card` / `-co-card`)
- Close-card preset present in pending state, absent in closed
- Per-row remove button present in pending with `data-rank` + `remove-gr-roll`
- Resolve-button class `gm-visible-only` on cb/op, `owner-only` on gr/co
- `data-partic-id` + `data-particType` on owner-only resolve buttons
- Crown indicator (fa-crown) present on cb/op closed first entry only, absent on gr/co
- `.owner-only` tooltip block per participant present in closed state with `data-partic-id` + `data-partic-type`
- Combined card text-summary h3 with `Elysium.partial` label on partial successLevel
- Cooperative card pip-strip h3 with `successLabel` + per-resultLevel pip count

**Edge case fixtures**: `combined_forceclosed` (successLevel=-1) correctly suppresses the bottom h3 — verified the legacy bug-fix flow works end-to-end now that the `flgs` typo is fixed and the template's `{{#unless (eq successLevel -1)}}` gate finally has access to the right sentinel.

**Open question (open #3 in cluster-2 audit)** — live Phase D smoke deferred to post-ship verification. Offline-render confirmed the mount-point selector `form.elysium.gr-card` is present on every rendered card; live confirmation that Phase D button injection (`combat-card-buttons.mjs:injectCombatCardButtons`) appends the GM-action panel correctly requires posting an actual weapon combat-roll card in the test world.

### Orphaning-candidates list (for P12)

The following `css/legacy.css` rules now have ONE remaining consumer set — the 7 chat templates still in cluster 3+/4 scope (roll-result, roll-damage, roll-armor, quick-combat, XP-result, rollStats, itemDescription). After cluster 3 and 4 land, these rules become fully orphaned and can be retired in P12's final legacy-CSS sweep:

- `.elysium .actor-roll` (lines 1260-1269) — replaced by `.elysium-chat-card .actor-roll` in cluster 1 Section B2
- `.elysium .actor-roll .roll-details` (1271-1275) — replaced
- `.elysium .actor-roll .roll-details .header` (1277-1285) — replaced
- `.elysium .actor-roll .roll-details .header .name` (1287-1294) — replaced
- `.elysium .actor-roll .roll-details .header .a` (1296-1299) — replaced
- `.elysium .actor-roll span.pending` (1301-1312) — replaced by `.elysium-chat-card span.pending` etc.
- `.elysium .rollHidden` (1314-1317) — replaced by `.elysium-chat-card .rollHidden`
- `.elysium .gr-list` (1319-1326) — replaced by `.elysium-chat-card ol.gr-list`
- `.elysium .chat-dice` and friends (1328+) — replaced by `.elysium-chat-card .chat-dice`
- `.elysium .dice-roll .dice-tooltip` (1472, 1475) — replaced by `.elysium-chat-card .dice-roll .dice-tooltip`
- `.elysium ol.gr-list li:nth-child(odd)` (1572) — orphans after cluster 3 finishes (currently only striping legacy templates)

**Important**: these rules stay in `css/legacy.css` through P11. They have higher specificity than the v1.0.0 marker-scoped rules due to the additional `.elysium` ancestor, but the cluster-2 markup includes `elysium` AND `elysium-chat-card` on the form, so both rulesets apply — the cluster-1 token-driven properties win on properties they set (color, background, padding, font-size etc.), and the legacy rules win on properties they set that cluster-1 doesn't override (which is essentially nothing — cluster-1 Section B overrides all the visible properties). Net effect: the rebuilt cards render in the v1.0.0 dark theme while legacy templates (clusters 3+4 scope) keep their current parchment look until those clusters land.

### Cluster 2 LOC summary

- 1 partial added: +151 LOC
- 4 templates rewritten: 335 → 92 LOC (-243 LOC)
- `styles/elysium-chat.css`: +24 LOC (4 new Section D rules)
- `module/hooks/init.mjs`: +2 LOC (partial path + comment)
- `module/cards/combined-card.mjs`: -1 char (typo fix)
- `system.json`: 1 LOC modified
- `CHANGELOG.md`: this entry

**Net template change**: 92 LOC delivered as templates that previously took 335 LOC, with the difference (243 LOC) absorbed by 151 LOC of partial and 24 LOC of CSS — overall **-68 LOC net** across all files. Plus one latent-bug fix and 4 visible card-type accents.

### Next

**Cluster 3** — Singleton-roll cards (`roll-result.html`, `roll-damage.html`, `roll-armor.html`, `quick-combat.html`). These have less internal variation than the group-roll quartet (each card has a fixed shape; no per-participant pip-value-source switching). They reuse the cluster-1 partials more directly via composition rather than needing a new umbrella partial like grouproll. Ships as alpha.47 after cluster 3 prep audit.

---

## [1.0.0-alpha.45] — P11 cluster 1: chat-card foundation (partials + chat CSS + 4-island retoken)

### Note on alpha.44 changelog correction

The alpha.44 "Next" paragraph drifted from `ROADMAP-v1.0.0.md §P11–P12`. The canonical phase plan (locked in P0) is:

- **P11** — Chat cards + dialogs rebuild
- **P12** — Polish + acceptance (light theme finalisation, lang-parity sweep, legacy CSS final retirement, DataModel cleanup, statistics tab fold, weapon DataModel/template alignment, plus the rest of the P10-deferred items captured in the cluster 5/6 changelogs)

The alpha.44 paragraph's swap of P11 and P12 scope was a writing-error, not an architectural change. Cast-card rebuild that the alpha.44 paragraph put under P12 is correctly P11 work and lands in this alpha.45 ship per the P11 prep audit (audit-0 decision).

### P11 opens — prep audit + cluster 1 audit

P11 prep audit (`docs/p11-prep-audit.md`, 711 lines) shipped first; all 14 decisions (audit-0 through c11-14) plus 7 open questions locked per user "proceed with recommended". Locks the phase scope (chat cards + dialogs across `templates/chat/`, `templates/dialog/`, `templates/casting/`, `templates/combat/`), the audit-5 class-hook contract for the rebuild (`.cardbutton` for Phase D click delegation, `form.elysium.gr-card` as the Phase D button-injection mount-point, `.owner-only`/`.gm-visible-only` visibility gates, `[data-cast-action]` family, `.elysium-disrupt-btn` / `.elysium-cast-disrupt-btn` / `.elysium-cap-btn` cast-card click hooks), the 7-cluster plan (C1 foundation; C2 group-roll quartet; C3 singleton rolls; C4 chat micro-cards; C5 generic dialogs; optional C6 island harmonisation; optional C7 combat-tracker cosmetic restyle), and the scope-cut of inline-HTML chat content (51 `ChatMessage.create({content:...})` callsites in `module/elysium/mechanics/` and `module/casting/`) as out-of-scope for P11.

P11 cluster 1 audit (`docs/p11-cluster1-audit.md`, 480 lines) shipped second; all 11 decisions (c1-1 through c1-11) plus 4 open questions locked per user "proceed with recommended". Key picks:
- **c1-1 / c1-2**: Adopt `.elysium-chat-card` and `.elysium-dialog` as scoping markers; layer alongside legacy class sets (`elysium gr-card`) per audit-5 pattern.
- **c1-3**: 5 new shared chat partials with locked context contracts; pre-registered in `module/hooks/init.mjs`'s existing `loadTemplates` block.
- **c1-4**: Build out `styles/elysium-chat.css` from 25-LOC placeholder to ~600 LOC across 6 sections (A marker rules / B partial styles / C chip+badge / D card-type accents placeholders / E island compat hooks). Section D placeholders only in c1; populated by C2-C4 as each card lands.
- **c1-5 through c1-8**: Retoken the 4 v1.0.0 islands (cast-card, manipulation-dialog, custom-spell-builder, tier-choice-dialog) onto design tokens. Cast-card light-parchment gradient REPLACED with `var(--ely-surface-card)` to align with the locked dark theme. Per-tradition border tints (arcane/divine/sorcery/mysticism) mapped to `--ely-accent-mind/bonus/fire/cold` respectively.
- **c1-9 — REVISION FROM PREP AUDIT c11-12**: The prep audit recommended swapping `.elysium-damage-*` class colors to design tokens. On closer inspection in c1 the token file lacks `-subtle` variants for the damage-accent family (only `success`/`bonus`/`danger`/`info` have subtle variants), and the data layer's emitted damage-type taxonomy (14 types from `select-lists.mjs:getSorceryDamageTypeOptions`) doesn't align with either the CSS family (10 types, including a name collision: data emits `corrosive`, CSS has `acid`) or the token family (9 types using different names). **Cluster 1 leaves all 10 `.elysium-damage-*` rules unchanged**; damage-type taxonomy alignment becomes a P12 work item.
- **c1-10**: Apply the alpha.44 CHANGELOG correction in this alpha.45 entry's preamble (above).

### Files added (5 shared chat partials)

All five live under `templates/chat/parts/`. Each has a locked context contract documented in its file header. All five preserve the audit-5 class-hook contract verbatim (`form.elysium.gr-card` mount-point, `.cardbutton` click binding, `.owner-only` / `.gm-visible-only` / `data-partic-id` / `data-particType` / `data-preset` / `data-rank` all carried through verbatim from legacy markup):

- **`chat-card-shell.hbs`** (38 LOC) — Outer `<form class="elysium gr-card elysium-chat-card" data-card-type="X">` wrapper with title slot, body slot, optional resolve footer. Used by clusters 2-4.
- **`chat-card-participant-row.hbs`** (60 LOC) — Per-participant portrait + label + result annotation strip. Three `resultMode` switches: `'pip-strip'` (combat/opposed/cooperative/result), `'flat-value'` (damage/armor), `'closed-or-diff'` (group-roll cards switching shape between pending and closed states). Surfaces hitloc tag for cards that opt in via `showHitLocTag`. Used by clusters 2-3.
- **`chat-card-success-pip.hbs`** (24 LOC) — 0-3 pip strip driven by `resultLevel` (0=fumble, 1=fail, 2=success, 3=special, 4=critical). Preserves the legacy `pending`/`roll-succ`/`roll-fail`/`roll-fumb`/`result-success`/`result-fail`/`result-yellow` class hooks (no JS reads them but legacy CSS still does until P12). Standalone partial because reused both inside participant-row AND inside the chat-dice closed-state summary at the bottom of combined/cooperative cards.
- **`chat-card-tooltip-rows.hbs`** (54 LOC) — Owner-gated hidden detail block (the expand-on-click tooltip). Four `rollMode` switches: `'attribute-difficulty'` (group-roll closed cards), `'attribute-resistance'` (RE/PP/result), `'damage'` (roll-damage), `'armor'` (roll-armor). Preserves the `.owner-only` + `data-partic-id` + `data-partic-type` audit-5 hooks plus `data-action="expandRoll"` parent on the wrapping `.dice-roll`. Used by clusters 2-3.
- **`chat-card-resolve-footer.hbs`** (15 LOC) — GM-only resolve+close button pair. Two button-class modes: `'gm-visible-only'` (combat/opposed cards — only GM can resolve) and `'owner-only'` (combined/cooperative — the initiator's owner OR GM can resolve). Preserves the `.cardbutton` + `data-preset` + the legacy camelCase `data-particType` audit-5 hooks. Used by cluster 2.

Registered in `module/hooks/init.mjs:130` `loadTemplates` block at the end of the existing P9/P10 item-parts block.

### Files modified — `styles/elysium-chat.css` build-out (25 → 457 LOC)

Six-section structure per c1-4:

- **Section A — Marker rules** (~50 LOC): `.elysium-chat-card` and `.elysium-dialog` root rules. Token-driven typography (font family, size, line-height, color) + dark-themed surface (`--ely-surface-card`), token-driven border + radius + padding. Strict — no token fallbacks (every consumer is in v1.0.0 territory). Cascades into island content via inheritance.
- **Section B — Shared chat partials** (~200 LOC):
  - B1: `.elysium-chat-card__title` typography (uppercase, decorative-text color, border-subtle bottom divider).
  - B2: Participant-row layout scoped under `.elysium-chat-card` — `ol.gr-list` reset, `.actor-roll` flex strip, `.open-actor` img with bordered hover, `.roll-details` flex column, `.header .name .tag` ellipsis truncation. All token-driven.
  - B3: `span.pending` base + `.roll-succ` / `.roll-fail` / `.roll-fumb` outcome variants. `.result-success` / `.result-fail` / `.result-yellow` icon-color modifiers mapped to `--ely-accent-success/danger/bonus`.
  - B4: `.dice-tooltip` styling (hidden by default, `.expanded` reveal). `.rollHidden` row spacing. Scoped under `.elysium-chat-card` so legacy chat-tooltip styling for non-v1.0.0 chat surfaces (system-message PF1e-style cards) is untouched.
  - B5: `.cardbutton` token-driven button styling (hover → action accent; pressed → action-active; disabled → action-disabled with opacity). Inline-anchor variant for the per-row remove (X) button — transparent background, danger color on hover.
- **Section C — Chip + badge components** (~80 LOC): `.elysium-chat-chip` base + `--accent` / `--danger` / `--success` / `--info` BEM modifiers consuming the design tokens' `-subtle` variants. `.elysium-chat-badge` counter-style component. `.elysium-hitloc-tag.elysium-chat-chip` selector reserved for c3 migration of `roll-result.html`'s inline-styled hitloc tag.
- **Section D — Card-type accents** (~15 LOC commented placeholders): One commented selector line per card type code (CB / OP / GR / CO / NO / RE / PP / CM / IM / DM / AR / QC) ready for cluster 2-4 to populate.
- **Section E — Island compatibility hooks** (~40 LOC): Suppresses the generic `__title` rule on the 4 islands (each has its own header layout). Zeroes the marker-rule padding on island roots (islands manage their own padding via inner sections). Documents that the tradition-tinted border rules in `styles/elysium.css` win specificity over the bare marker-rule border.

Brace count: 58 opens / 58 closes. Zero hardcoded color literals in the file.

### Files modified — `styles/elysium.css` 4-island retoken (-32 LOC net, +49 token references)

Each island's CSS block re-expressed in terms of design tokens:

- **Cast-card** (`.elysium-cast-card` + 30+ child rules across lines 1327-1605 and 1962-2533 and 2680-2685):
  - Light-parchment background gradient `rgba(245, 235, 215, 0.4)` REPLACED with solid `var(--ely-surface-card)`. The cast-card now matches the dark-theme identity instead of the v0.x parchment aesthetic.
  - Border `rgba(120, 70, 30, 0.4)` → `var(--ely-border-decorative)`.
  - Tradition borders: `rgba(94, 52, 112, 0.55)` arcane → `var(--ely-accent-mind)`; `rgba(170, 122, 26, 0.55)` divine → `var(--ely-accent-bonus)`; `rgba(168, 60, 26, 0.55)` sorcery → `var(--ely-accent-fire)`; `rgba(31, 94, 110, 0.55)` mysticism → `var(--ely-accent-cold)`.
  - Spellname color: `var(--ely-legacy-colour-primary, #4a1818)` → `var(--ely-accent-action)` (crimson).
  - Tradition label color: `var(--ely-legacy-colour-secondary, #5a3818)` → `var(--ely-text-decorative)` (bone trim).
  - Body-text muted colors `rgba(0, 0, 0, 0.5)`/`0.6`/`0.7`/`0.75` → `var(--ely-text-muted)` / `var(--ely-text-body)`.
  - Attempt outcomes: `#2a7a2a` success → `var(--ely-accent-success)`; `#1a5e1a` critical → `var(--ely-accent-success-hover)` (weakest substitution per c1-5; flagged for P12 token augmentation `--ely-accent-success-strong`); `#888` failure → `var(--ely-text-muted)`; `#8a1818` fumble → `var(--ely-accent-danger)`.
  - Success banner / fail banner re-expressed via `--ely-accent-success-subtle` / `--ely-accent-danger-subtle`.
  - Cast buttons (primary/danger/secondary): action-accent mind/danger/surface-raised tokens.
  - Tableresult severity classes (minor/moderate/serious/severe/catastrophic): mapped to bonus/bonus-hover/fire/danger/danger-hover left-border colors.
  - Spent-notice + sustain-notice + disrupt buttons + healing label + cast-disrupt block + disrupt-success/fail/partial indicators: all retokened to surface-sunken / danger / success / bonus tokens.
  - Damage-type wrapper (`.elysium-cast-damage-type-tag`) shape retokened; the 10 `.elysium-damage-{type}` rules **intentionally preserved with hardcoded colors** per c1-9 (deferred to P12).
- **Manipulation-dialog** (~50 rules under `.elysium-manip-*`):
  - Color base from `#2a1d10` body text → `var(--ely-text-body)`.
  - Headers, stepper buttons, PP-commit info row, totals, primary/cancel/neutral buttons, reactive tag, ap-line, warning all retokened.
  - Primary button changed from parchment-warm gradient (`linear-gradient(180deg, #a86d3a 0%, #8a5524 100%)`) to flat `var(--ely-accent-bonus)` background with `var(--ely-surface-base)` text.
- **Custom-spell-builder** (~15 `.csb-*` rules scoped under `.elysium-custom-spell-builder`):
  - Section card background `rgba(248, 244, 230, 0.4)` (light parchment) → `var(--ely-surface-sunken)` (dark).
  - Section h3 text `#4a3a20` → `var(--ely-text-decorative)`.
  - Toggle buttons base / hover / selected mapped to surface-raised / bonus-subtle / bonus tokens.
  - Footer primary "Proceed" button from `#6a8b3a` (olive green) → `var(--ely-accent-success)` (Elysium dark-theme green).
- **Tier-choice-dialog** (~15 `.tcd-*` rules scoped under `.elysium-tier-choice-dialog`):
  - Tier-card base / hover / selected mapped to surface-raised / bonus-subtle / bonus tokens.
  - Tier cost badge mapped to surface-sunken.
  - Primary "Cast" button from `#6a8b3a` (olive green) → `var(--ely-accent-success)`.

Total: 80+ hardcoded color literal substitutions. Zero rules added or removed; zero rules retired (orphaning is c2-c5 work, deletion is P12 per c11-13).

### Files modified — template root-class additions

Four single-class additions on root elements:

- `templates/chat/cast-card.hbs:33` — `<div class="elysium-cast-card elysium-chat-card" data-tradition="{{tradition}}">`
- `templates/casting/manipulation-dialog.hbs:17` — `<section class="elysium-manip-dialog elysium-dialog">`
- `templates/casting/custom-spell-builder.hbs:12` — `<div class="elysium-custom-spell-builder elysium-dialog">`
- `templates/casting/tier-choice-dialog.hbs:11` — `<div class="elysium-tier-choice-dialog elysium-dialog">`

Layered-class pattern per audit-5 lock: island root keeps its existing scope class (Phase D injection still targets `.elysium-cast-card` etc.) AND adopts the shared marker for chat/dialog typography inheritance.

### Files modified — `module/hooks/init.mjs` partial registration

Five lines added to the `loadTemplates(...)` array at line 184 (end of existing P9/P10 item-parts block). Foundry's `foundry.applications.handlebars.loadTemplates` is async-but-synchronous-feeling: the promise resolves well before any sheet/chat render in normal boot order. Existing `.catch(err => console.error(...))` handler covers any registration failures.

### Lang impact

Zero new i18n keys. The 5 partials reference 5 existing keys (`Elysium.remove`, `Elysium.grTag`, `Elysium.difficulty`, `Elysium.resolveCard`, `Elysium.closeCard`, plus the column labels in tooltip-rows: `Elysium.rawScore` etc.), all of which already resolve in `lang/en.json`. Spanish/French parity unaffected (zero new keys means zero new gaps).

### Behavioural impact

Zero. No JS logic changes outside `init.mjs`'s 5-line partial registration append. No sheet/cast/combat handlers touched. No DataModel changes. The 4 island templates' rendering pipelines (`ApplicationV2` with `actions` maps for the casting dialogs; the chat-emit pipeline in `cast-shared.mjs` for cast-card) are untouched — they continue to produce identical DOM apart from the one extra class on their root element. Phase D button injection (`form.elysium.gr-card` mount-point selector) is verified untouched on cast-card markup (cast-card never used that markup wrapper; it has its own `<div class="elysium-cast-card">` root which Phase D injection doesn't target). Cluster 2 will be the first ship that exercises the new partials on Phase D-targeted templates.

### Pre-flight checks performed

1. JS parse: `node --check module/hooks/init.mjs` — pass.
2. JSON parse: `system.json` valid; `lang/{en,es,fr}.json` valid.
3. CSS brace balance: `styles/elysium-chat.css` 58/58 open/close; `styles/elysium.css` 446/446 open/close (was 444/444 — net +2 from cast-card root rule additions, balanced).
4. Handlebars block balance: 5 new partials all balanced (verified open `{{#`/`{{^` count equals close `{{/` count per file).
5. Handlebars mustache balance: 5 new partials all balanced (`{{` count equals `}}` count per file).
6. i18n key existence: zero new `localize` calls; existing references verified against `lang/en.json` (all 7 distinct keys resolve).
7. Design-token existence: every `var(--ely-*)` reference in new + retokened CSS verified against `styles/elysium-tokens.css` (40 distinct tokens consumed; all defined).
8. Legacy CSS retirement: zero rules retired (c1 lays foundation; orphaning is c2-c5 work; deletion is P12).
9. Lang parity: unchanged (zero new keys means zero new drift; pre-existing 205-key en→es/fr gap remains a P12 item).

### Smoke methodology

Offline-render fixtures + 1 live cast roll per c1-11. Cast-card fixtures covering all 5 states (in-progress / completed-normal / completed-corrupted / abandoned-fumble / abandoned-wildmagic) render successfully via the offline pattern:

```js
const tpl = await foundry.applications.handlebars.getTemplate('systems/elysium/templates/chat/cast-card.hbs')
const html = tpl(fixtureCtx)  // verify HTML shape
```

ApplicationV2 dialogs (manipulation-dialog, custom-spell-builder, tier-choice-dialog) smoke-tested via direct constructor + render (their `_prepareContext` shape is unchanged).

### Cluster 1 LOC summary

- 5 partials: 191 LOC (added)
- `styles/elysium-chat.css`: +432 LOC (25 → 457)
- `styles/elysium.css`: +32 LOC net (2949 → 2981 — retoken substitutions + cast-card root rule restructure)
- 4 template root-class additions: 4 LOC each = +4 LOC distributed
- `module/hooks/init.mjs`: +6 LOC (5 partial paths + 1 comment line)
- `system.json`: 1 LOC modified (version string)
- `CHANGELOG.md`: this entry (~180 LOC appended)

Net: ~+665 LOC across the cluster. ~80 hardcoded color literal substitutions completed. 5 audit-5-locked imperative class hooks (`.cardbutton`, `.owner-only`, `.gm-visible-only`, `form.elysium.gr-card`, the cast-card click family) verified preserved on every touched markup.

### Next

**Cluster 2** — Group-roll quartet (`roll-combat.html`, `roll-opposed.html`, `roll-combined.html`, `roll-cooperative.html`) consumed against the new partial vocabulary. One shared `chat-card-grouproll.hbs` partial driven by per-card context flags per c11-5 (option A). Expected LOC reduction: ~340 → ~150 across the 4 cards. Ships as alpha.46 after cluster 2 prep audit.

---

## [1.0.0-alpha.44] — P10 cluster 6: career sheet · CLOSES P10

P10 cluster 6 prep audit (`docs/p10-cluster6-audit.md`, 203 lines) shipped first; all 13 decisions locked per user "proceed". Migrates the final remaining legacy item sheet (career) onto v1.0.0. After alpha.44, **23 of 23 item types** are on v1.0.0 (**100%**). P10 closes.

### Career — full migration onto ElysiumDragDropItemSheet

Career was the only item type that had NOT been touched in any cluster — still extending the legacy `ElysiumItemSheetV2` base directly, carrying ~248 LOC of duplicated drag/drop + collection-management boilerplate that has lived on the cluster-3b `ElysiumDragDropItemSheet` since alpha.41. Cluster 6 folds career in.

The legacy career.mjs structure was: 8 drag/drop methods (`_canDragStart`/`_canDragDrop`/`_onDragStart`/`_onDragOver`/`_onDropItem`/`_onDropFolder`/`get dragDrop`/`#createDragDropHandlers`) totaling 64 LOC; 4 collection-management methods (`_onItemDelete`/`_onGroupItemDelete`/`_onItemView`/`_onGroupControl`) totaling ~73 LOC; plus the constructor `this.#dragDrop = this.#createDragDropHandlers()` line. All hoisted by extending `ElysiumDragDropItemSheet` (per c6-1).

Career's listener bindings in legacy used `.closest('.item')` selectors (NOT widened during cluster 3b because career was untouched). The cluster-3b base uses widened `.closest('[data-item-id]')` and `.closest('[data-group]')` selectors — career's listeners now inherit those automatically, gaining forward-compatibility with v1.0.0 row markup without needing the legacy `.item` class on row wrappers.

### Three drop-target routing (`_onDrop` override)

Career is unique in the system: 3 distinct drop targets routed via class hooks on the drop zone element:

- `.optional-skills` → group skills (per-group via `data-group=N`)
- `.main-powers`     → powers collection (powers-type items only)
- (else)             → main skills collection (with remove-from-groups for non-generic skills)

The 3-target routing logic preserved verbatim from legacy (c6-9). Override of `_onDrop(event, type='skill', collectionName='skills')` checks `event.currentTarget.classList` for the routing class, sets `type='power'`/`collectionName='powers'` when `.main-powers` matched. The same dup-detection + non-generic-skill handling preserved (specialism-chosen and `!specialism && !group` skills route uniquely; otherwise allow many copies, e.g. generic specialism templates).

### `_onPowersDelete` sub-class addition

The base class knows about main collection (default `skills`) and groups, but not a third collection. Career's powers list uses class hook `.item-power-delete` to differentiate from `.item-delete` (which deletes from the main skills collection). Sub-class extends `_onRender`:

```js
_onRender(context, options) {
  super._onRender(context, options)  // base binds .item-delete, .item-view, .group-item-delete, .group-control
  this.element.querySelectorAll('.item-power-delete')
    .forEach(n => n.addEventListener('click', this._onPowersDelete.bind(this)))
}
```

`_onPowersDelete` uses the widened `[data-item-id]` selector pattern (NOT legacy `.closest('.item')`) per c6-10. ~15 LOC sub-class addition.

Alternative considered (and rejected per c6-7): route powers delete through `_onItemDelete` with a `data-collection="powers"` attribute. This would require changing the base class to read `data-collection`; the 3-LOC sub-class extension is cleaner given career is the only multi-collection drop sheet in the system.

### PARTS migration to v1.0.0 shell partials (c6-3)

- `item.header.hbs` → `parts/item-shell-header.hbs`
- `global/parts/tab-navigation.hbs` → `parts/item-shell-tabs.hbs`
- `item.description.hbs` → `parts/item-shell-description.hbs`
- `item.gmnotes.hbs` → `parts/item-shell-gmnotes.hbs`

`_preparePartContext` dropped — the v1.0.0 shell partials build their own enriched HTML from `system.description`/`system.gmDescription`. Removes ~30 LOC vs legacy.

### TAB_ORDER and sheet size (c6-2, c6-4)

`TAB_ORDER = ['header', 'tabs', 'skills', 'powers', 'wealth', 'description', 'gmNotes']` — preserves the 3 content tabs per c6-2 (don't restructure UX during a migration ship; skills/powers/wealth have distinct drop-target semantics that don't consolidate cleanly).

Sheet size widened 520×520 → 560×720 per c6-4 — matches personality/culture (same skill-list pattern). 520 wide was too narrow for skill rows + delete controls; 720 tall accommodates both skills AND powers lists without forcing scroll.

### Header chips (c6-5)

3 chips: **Min Wealth** / **Max Wealth** / **Tier**. Tier surfaces the v0.19+ Elysium-fork `system.elysium.tier` field that legacy never exposed on the sheet — useful at-a-glance for character creators. Tier values resolved through new `Elysium.careerTier.*` nested i18n namespace (`basic` / `journeyman` / `master`).

### Templates rewritten (3 files)

**career.skills.hbs** (66 lines): mirror of personality.detail.hbs pattern (c6-6). Section card for main skills + section card for groups. All skill rows use the cluster-3b `item-skill-row.hbs` partial (built explicitly for personality/culture/skill/career reuse). Add-group / remove-group controls preserved with widened class hooks (`group-control add-group` etc.); the cluster-3b base binds these in `_onRender`.

**career.powers.hbs** (33 lines): single section card with main powers drop zone. Power rows are simpler than skill rows (just name + delete control — no variable/group/bonus formatting), so inline markup is fine for the single consumer (c6-7 — no new shared partial). PRESERVES `.main-powers` class hook on the drop zone — that's the routing contract `_onDrop` checks to distinguish powers drops from skills drops. Each row carries `data-item-id` + `data-elysiumid` so the widened delete listener works.

**career.wealth.hbs** (33 lines): single section card with min/max wealth selects via the cluster-1 `item-field-row.hbs` partial. Replaces legacy `hitlocgrid` + `wealth-display` markup.

### Form handler `myCareerHandler` (c6-11)

Preserved + adds powers-array rehydration (defensive: form submits don't preserve array shape; matches the existing groups-array rehydration pattern). The `groups` arrays were already rehydrated; powers wasn't, relying on the fragile assumption that no form field submits `system.powers`. Adding `if (system.powers === undefined) formData.object['system.powers'] = ...duplicate(this.item.system.powers)` makes this defense explicit.

### Legacy CSS retirement (c6-12)

4 career-only legacy CSS blocks (21 lines) deleted from `css/legacy.css`:
- `.elysium .horizontalboxed` (4 lines, line 1033)
- `.elysium .group-label` (4 lines, line 1043)
- `.elysium .wealth-display` (5 lines, line 1064)
- `.elysium .optGroup` (4 lines, line 1459)

Total: `css/legacy.css` 1661 → 1640 lines, 222/222 brace pairs maintained. Pre-flight grep confirmed zero remaining non-legacy consumers (`.wealth-display` had a doc-comment-only match in the new career.wealth.hbs template — not a class attribute).

**PRESERVED** (per c6-12 lock): `.main-powers` is a routing-contract class for `_onDrop` (not styled, just functional). Class hook stays on the powers drop zone div.

### No CSS additions

All required v1.0.0 styling already exists from clusters 1+3b (section cards, item-field-row/grid, item-skill-row, droppable). No new design tokens, no new CSS classes.

### i18n additions

3 new keys × 3 langs = 9 entries:
- `Elysium.careerTier.basic` (Basic / Básico / Basique)
- `Elysium.careerTier.journeyman` (Journeyman / Oficial / Compagnon)
- `Elysium.careerTier.master` (Master / Maestro / Maître)

All 13 other static i18n keys referenced by career templates already exist in en.json (verified: `tier`, `wealth`, `skills`, `powers`, `minWealth`, `maxWealth`, `optionSkills`, `choose`, `addGroup`, `deleteGroup`, `deleteItem`, `invalid`, `dupItem`).

### Sheet-class LOC reduction

| File | alpha.43 | alpha.44 | Δ |
|---|---|---|---|
| career.mjs | 416 | 243 | **−173 (−42%)** |
| career.skills.hbs | 79 | 66 | -13 (-16%) |
| career.powers.hbs | 20 | 33 | +13 (+65%) |
| career.wealth.hbs | 21 | 33 | +12 (+57%) |

Sheet reduction: -173 LOC (less than audit's -237 projection because the `_prepareContext` resolution loops for perSkill/grpSkill/perPower stayed inline — folding them into a base helper would have been over-abstraction for one consumer with 3 collections). Cumulative cluster 1+2+3a+3b+4+5+6: **-1574 LOC net** across **22 sheet rebuilds**.

Templates: net ~+12 lines across the 3 surfaces. Skills template shrank via partial reuse; powers + wealth templates grew slightly because v1.0.0 vertical field-row structure adds proper labels + section cards at the cost of line count vs the legacy compact `hitlocgrid` markup. Readability + maintainability over density (same trade-off as cluster 5's weapon template).

### Final P10 milestone

After alpha.44, **23/23 item types are on v1.0.0 (100%)**:

| Cluster | Alpha | Item types | Status |
|---|---|---|---|
| 1 | .38 | gear | ✓ |
| 2 | .39 | reputation, failing, wound, passion, powerMod, mutation, persTrait, allegiance | ✓ |
| 3a | .40 | ability, hit-location, skillcat, mysticism, divine, armor | ✓ |
| 3b | .41 | super, personality, culture | ✓ |
| 4 | .42 | arcane, sorcery | ✓ |
| 5 | .43 | skill, weapon | ✓ |
| 6 | .44 | career | ✓ **CLOSES P10** |

**Shared infrastructure built across P10**:
- 9 shared partials (5 shell from cluster 1: `item-shell-header`/`-header-specialism`/`-tabs`/`-description`/`-gmnotes`/`-effects`; 4 utility from clusters 1+3b+4: `item-field-row`/`item-field-grid`/`item-skill-row`/`item-toggle-row`/`item-ap-grid`/`item-tier-effect-row`)
- 1 intermediate base class (`ElysiumDragDropItemSheet`) — drag/drop boilerplate hoisted once, consumed by super/personality/culture/skill/career
- 1 latent bug fix (alpha.42 itemToggle dual-shape path support — divine flag chips that were silently failing since alpha.40)

**Cumulative impact**:
- 22 sheet rebuilds, -1574 net LOC, -1401 LOC pre-cluster-6 baseline now -1574
- ~250 lines of legacy CSS retired (cluster 4: 171, cluster 5: 54, cluster 6: 21; PRE-cluster-4 retirements not tallied here)
- 3 lang files: ~95 new keys across all P10 clusters
- Full i18n parity across all P10-added keys (no en-only entries introduced by P10)

### Cluster isolation

Zero — there is no remaining legacy item type. Every sheet now uses v1.0.0 shells + shared partials. Sheet-extension `injectWeaponFields` continues to function unchanged (weapon's `.tab.details` contract preserved).

### Sweep

- CSS: `styles/elysium-sheets.css` 514/514 (unchanged); `css/legacy.css` 222/222 (post 4-block retirement)
- Handlebars: `career.skills.hbs` 30/30 mustaches + 8/8 block pairs; `career.powers.hbs` 13/13 + 3/3; `career.wealth.hbs` 19/19 + 5/5
- JS: `career.mjs` `node --check` OK
- i18n: 13 static keys + 1 nested namespace (careerTier with 3 entries) referenced, 0 missing in en.json
- Lang parity for cluster 6: en/es/fr all gained 3 new careerTier.* entries; pre-existing 35-key en-only gap from before cluster 5 unchanged (P12 polish)

System `1.0.0-alpha.43` → `1.0.0-alpha.44`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke checklist for alpha.44 (per c6-13)

a. Game ready, version=1.0.0-alpha.44
b. Career sheet opens; v1.0.0 header renders with 3 chips (Min Wealth / Max Wealth / Tier)
c. Skills tab: main skill drop adds to `system.skills`; group skill drop adds to that group's `skills` array; group skill drop into MAIN removes from any group
d. Powers tab: power-type item drop adds to `system.powers`; non-power-type drop rejected
e. Wealth tab: min/max selects round-trip via `item.update()`
f. add-group / remove-group buttons add and remove `groups[]` entries
g. Item-delete / group-item-delete / item-power-delete each remove only the right row
h. Console clean of system errors after full sheet interaction
i. Cluster 1-5 regression: open one of each (gear/armor/personality/sorcery/skill/weapon) — all render identically to alpha.43

### Next

**P10 closes**. P11 (legacy.css final retirement sweep — any remaining orphan blocks) and P12 (polish: cast-card rebuild, statistics tab fold, DataModel cleanup, lang-parity gap, weapon DataModel/template alignment for the dead-code branches found in cluster 5 smoke, etc.) become the next phases.

---

## [1.0.0-alpha.43] — P10 cluster 5: skill body + weapon

P10 cluster 5 prep audit (`docs/p10-cluster5-audit.md`, 262 lines) shipped first; all 13 decisions locked per user "proceed with recommended". Migrates the last two non-spell legacy item sheets (skill + weapon) onto v1.0.0. After alpha.43, **22 of 23 item types** are on v1.0.0 (95%); only career remains (cluster 6 → alpha.44).

### Skill — full migration onto ElysiumDragDropItemSheet

Skill rebuilt to extend cluster-3b's `ElysiumDragDropItemSheet` (the intermediate base class explicitly built for this reuse in alpha.41). Removes ~62 LOC of bit-identical drag/drop boilerplate that lived inline; inherits the 8 drag/drop methods + 4 collection-management methods + the imperative listener wiring in `_onRender`. Three targeted overrides preserve skill-unique behaviour:

- **`_onDrop`** — routes drops to `system.groupSkills` (not the personality/culture base default `skills`); enforces the rule that group-typed skills cannot be nested into another group container (warns `Elysium.stopGroupSkill`); preserves duplicate detection across the collection.
- **`_onItemDelete`** — delegates to `super._onItemDelete(event, 'groupSkills')` to override the default collection name.
- **`_onItemView`** — resolves the dropped row via `data-elysiumid` (the canonical skill identifier) rather than the base class default uuid path.

Header part stays on the v1.0.0 specialism-aware partial (`parts/item-shell-header-specialism.hbs`) — already swapped in cluster 3b (c3b-4); preserves main/spec name split when `system.specialism` is true.

Form handler `mySkillHandler` preserved unchanged from legacy — composes `item.name` from `mainName + (specName)` when specialism is true, and rehydrates the `groupSkills` array across form submits.

### Skill — detail template (two display modes)

Two display modes driven by `system.group`:

- **Single-skill mode** (`group=false`): metadata section (Skill Group / Category / optional weapon subtype / Subgroup) + options chip row + variable-formula grid (only when `system.variable=true`) + score breakdown (base + xp + career + personal + personality + culture + effects + total). Score breakdown sums into a new helper `totalScore` on context (vestigial sheet-side; P12 to move into DataModel getter).
- **Group-container mode** (`group=true`): options chip row + dropped-skills list with `.droppable` zone. List uses the cluster-3b `item-skill-row.hbs` partial (built explicitly for personality + culture + future career + skill reuse). No inline skill row markup.

Header chips per c5-3: 3 chips (Skill Group / Category / Subgroup). Flag chips: 5–7 toggles depending on mode — `noXP`, `specialism`, `variable`, `group`, `combat` always; `basic` only when not a group container; `chosen` only when specialism is true.

### Weapon — v1.0.0 shell rebuild

Weapon (the densest item template in the system — 67 DataModel fields) rebuilt on the standard `ElysiumItemSheetV2` base with active-effects PART. No intermediate base class added per c5-2 — the 3 LOC × 3 sheets of `ElysiumActiveEffectSheet.activateListeners(this)` doesn't justify a base class hoist.

Detail body restructured per c5-4 into 5 logical section cards (replacing the legacy dense 8-column grids):

1. **Damage** — dmg1 / dmg2 / dmg3 formula inputs + range bands (reach select + close/effective/long numeric)
2. **Type & Skills** — weaponType, damageBonus, skill1, skill2, attack, special
3. **Combat Profile** — hands (or crew for artillery), ap/hp (varies by weaponType: shield/artillery/melee), STR/DEX requirements (skipped for artillery), radius (explosives only), ammo block (only when `isAmmo`: firearm/energy/artillery/missile/heavy), malfunction, price, encumbrance, Mythras Size + Force selects, PP store current+max, plus an inline `isMelee` toggle chip
4. **Damage Flags** — 16-chip toggle row: parry + 15 damage type flags (acid, burst, choke, cold, constrict, disease, emp, entangle, explosive, fire, pierce, poison, sonic, stun, spclDmg). First consumer of `item-toggle-row.hbs` with **flat property paths** (`system.<flag>`); the alpha.42 itemToggle fix is forward-compatible since `data-property-path` is read verbatim with no path-shape assumption.
5. **Owner-only** — actual ENC + equip status + hpCurr + ammoCurr + quantity (+ npcVal when NPC-owned)

Active-effects PART continues to render separately (audit-5 lock preserved): `ElysiumActiveEffectSheet.activateListeners` bound in `_onRender`; legacy `active-effect-change-edit` class hook flows through `parts/item-shell-effects.hbs`.

Sheet-extension `injectWeaponFields` (engagement-info badge + weapon HP + Wielded Modifiers fieldset) continues to work unchanged — selector contract `.tab.details` preserved on the root section per c5-8.

Header chips per c5-4: 4 chips (Weapon Type / Size / Reach / Damage). The `meleeChip` array is built separately because `isMelee` lives under `system.elysium` (nested path) while the 15 damage flags live at flat `system.<flag>` — the template renders the melee chip inline as a single-chip toggle row inside the Combat Profile section.

### `_onItemToggle` allow-list extension (c5-1)

The base `_onItemToggle` allow-list now includes `isMelee` (both GM-only short-circuit list AND the writable allow-list). This is the first cluster-5 itemToggle property; all 15 weapon damage flags were already in the alpha.40 allow-list.

### Legacy CSS retirement (c5-6)

6 orphan CSS blocks (54 lines) deleted from `css/legacy.css` after the rebuild:

- `.elysium .skill-scores` (9 lines)
- `.elysium .skill-display` (5 lines)
- `.elysium .weapon-display` (4 lines)
- `.elysium .weapon-scores` (12 lines)
- `.elysium .weapon-main-scores` (9 lines)
- `.elysium .weapon-2main-scores` (9 lines)

Total: `css/legacy.css` 1714 → 1660 lines (226/226 brace balance maintained). Pre-flight grep confirmed zero remaining `.hbs`/`.mjs` consumers in non-legacy code:

- `.weapon-input` PRESERVED — still consumed by `templates/global/parts/active-effects.html` + `templates/item/item.active-effects.hbs` (active-effects-list rendering; unrelated to weapon-specific UI).
- `.skill-cat` PRESERVED — still consumed by `templates/actor/npcV2.main.hbs` (NPC sheet toggles); also note `.elysium-skill-cat` is a different prefixed class on the left-rail-skills actor partial.
- `.skill-display` consumer was only a doc-comment reference in `item-field-row.hbs`; retired.

### CSS additions (`styles/elysium-sheets.css`)

- `.elysium-item-readonly-value.elysium-item-readonly-emphasis` — gold accent + bold weight variant for total/aggregated read-only values (skill total score row). Uses `--ely-accent-bonus` + `--ely-font-weight-bold` (existing tokens).

No new design tokens. No new shared partials — cluster 1+3b+4 partials cover everything in cluster 5.

### i18n additions (41 new keys × 3 langs = 123 entries)

Weapon section labels: `weaponTypeAndSkillsSection`, `weaponCombatProfileSection`, `weaponFlagsSection`, `weaponOwnerSection` (4). Weapon field labels + hints: `weaponType`, `weaponSubtype`, `dmg1Hint`, `dmg2`, `dmg2Hint`, `dmg3`, `dmg3Hint`, `reach`, `reachHint`, `rangeClose`, `rangeCloseHint`, `rangeEffective`, `rangeEffectiveHint`, `rangeLong`, `rangeLongHint`, `skillPrimary`, `skillSecondary`, `specialAttack`, `ammoCapacity`, `ammoType`, `size`, `sizeHint`, `force`, `forceHint`, `encHint`, `meleeWeaponHint` (26). Skill section labels + field labels + hints: `skillMetadataSection`, `skillGroup`, `skillGroupHint`, `subgroup`, `subgroupHint`, `combiner`, `rule1Characteristic`, `rule1Multiplier`, `rule2Characteristic`, `rule2Multiplier`, `groupSkillsDropHint` (11). Note: 35 pre-existing pre-cluster-5 keys (e.g. `AP`, `Ability`, `Ancestry`, `Arcane`, `Armor`) remain missing in es/fr — this is a long-standing gap NOT introduced by cluster 5; P12 polish item.

### Sheet-class LOC reduction

| Type | alpha.42 | alpha.43 | Δ |
|---|---|---|---|
| weapon.mjs (sheet) | 191 | 185 | -6 (-3%) |
| weapon.detail.hbs (template) | 341 | 432 | +91 (+27%) |
| skill.mjs (sheet) | 343 | 219 | -124 (-36%) |
| skill.detail.hbs (template) | 223 | 240 | +17 (+8%) |

Weapon template grew because the legacy dense 8-column grids were highly compact at the cost of readability and maintainability; the v1.0.0 vertical field-row structure is 2-3× more verbose per field but adds proper labels, tooltips, accessibility, and removes the conditional rendering complexity that bloated the legacy template. Skill sheet shrank significantly via base-class hoist (8 drag/drop methods + 4 collection methods + form-handler boilerplate). Cumulative cluster 1+2+3a+3b+4+5: **-1401 LOC net** across 21 sheet rebuilds.

### Cluster isolation

Career remains on the legacy stack — UNTOUCHED. All other 21 cluster-rebuilt sheets continue to render identically.

### Sweep

- CSS: `styles/elysium-sheets.css` 514/514 brace pairs (+1 new for emphasis variant); `css/legacy.css` 226/226 (post-retirement)
- Handlebars: `weapon.detail.hbs` 297/297 mustaches + 83/83 block pairs; `skill.detail.hbs` 156/156 mustaches + 43/43 block pairs
- JS: `weapon.mjs`, `skill.mjs`, `base-item-sheet.mjs` all `node --check` OK
- i18n: 84 cluster-5 keys referenced; 0 missing in en.json
- Lang parity: en 797 / es 762 / fr 762 (35 pre-existing gaps unchanged by cluster 5)

System `1.0.0-alpha.42` → `1.0.0-alpha.43`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke checklist for alpha.43 (per c5-13)

Tests in order (each must pass before next):

a. Game loads cleanly with no system errors logged
b. Skill sheet opens; v1.0.0 header chips render (3 chips: Skill Group / Category / Subgroup); options chip row works (clicking flips DataModel field)
c. Skill in `group=true` mode shows the group-skills list with droppable zone, NOT the score grid; in `specialism=true` shows main+spec name split in header
d. Skill drag/drop: drag a skill onto a group-skill's drop zone; the skill appears in the group list with elysiumid+uuid
e. Skill form-handler still composes `item.name` correctly when toggling specialism on/off
f. Skill score breakdown renders for owned-by-character skill (7 contributions + total)
g. Weapon sheet opens; v1.0.0 header chips render (4 chips: Weapon Type / Size / Reach / Damage); damage-flag chips work
h. Weapon damage formulas (dmg1/dmg2/dmg3) render + save
i. Weapon's Wielded Modifiers fieldset still injects (sheet-extension `injectWeaponFields` ran)
j. Weapon's engagement-info badge appears when actor is engaged (only if test world has combat state)
k. Console clean of system-level errors after the above
l. Close+reopen sheets doesn't accumulate event listeners (no double-click bugs)
m. After legacy.css retirement: no broken styling on other surviving templates (gear / armor / passion / reputation / etc.)
n. Each cluster-3a/3b/4 sheet's chip zone still has its v1.0.0 header (regression check from alpha.42 fix #2)

### Next

Cluster 6 — career (alpha.44). After cluster 6: 23/23 item types on v1.0.0 (100%). career.mjs is 416 LOC + has the only career-specific powers/skills/wealth sub-templates remaining.

---

## [1.0.0-alpha.42] — P10 cluster 4: arcane + sorcery spell sheets

Fifth P10 ship. Migrates the 2 remaining spell item types (arcane + sorcery) onto v1.0.0, introduces 3 new shared partials (item-toggle-row, item-ap-grid, item-tier-effect-row), retires ~171 lines of orphan legacy spell CSS, and fixes a **latent alpha.40 bug** in the itemToggle handler that was writing divine's spell flags to the wrong storage path. After this ship, **20 of 23 item types** are on v1.0.0 (87%); 3 remain on legacy paths (skill body, weapon, career — clusters 5 + 6).

### Cluster 4 scope

- **arcane** — F/T compendium-driven row dropdowns (Forms + Techniques) preserved unchanged including the v0.10.0 add/remove static action handlers and the v0.10.9 precomputed-`selected` workaround for cached templates. Cast profile fields (school, requiredSL, basePP, apCost, saveSkill) migrated to `item-field-row` partials. 2 flag chips (isRitual, isPermanent) via the new `item-toggle-row` partial.
- **sorcery** — essence selector (12 + empty), baseTier/maxTier, flat power cost, 14-entry damage type select (cross-tradition palette), saveSkill, range, per-tier AP cost grid (5 cells), per-tier effect rows (each with damage dice + locations sub-row), 4 flag chips, conditional Maintain PP/round row when isSustained.

### Latent bug fix #1 — `_onItemToggle` storage path

Cluster 4 smoke surfaced that divine's `isRitual` / `isReactive` / `isDamageSpell` chips added in alpha.40 were writing to the wrong storage path. The chips emit `data-property="isRitual"`, which `_onItemToggle` translated to `checkProp = { 'system.isRitual': !this.item.system.isRitual }` — a flat path with no DataModel field at that location. The actual DataModel field is `system.elysium.isRitual` (nested). Result: clicking a divine flag chip silently wrote `undefined` to a junk path; the actual flag never flipped; the UI never reflected the change.

Fix: `_onItemToggle` now reads an optional `data-property-path` attribute. When present, that value is used verbatim as the full storage path. When absent, falls back to `system.${property}` (legacy behavior preserved for all the flat-field flags). Reading the current value now uses `foundry.utils.getProperty(this.item, path)` so the toggle correctly inverts the actual stored value, not a junk lookup. Property-name allow-list lookup unchanged (permissions live on the property name, not the path).

All spell-flag chips in cluster 4 (divine retroactively, arcane new, sorcery new) now pass explicit `data-property-path="system.elysium.<name>"`. The shared `item-toggle-row` partial accepts an optional `propertyPath` per chip and emits the attribute when present.

### Latent bug fix #2 — `_configureRenderOptions` dropping header + tabs parts

Cluster 4 smoke also surfaced that **all cluster-3a + 3b sheets had been silently missing their v1.0.0 item-shell-header and tab navigation**. The cluster-2 base hoist's `_configureRenderOptions` uses `TAB_ORDER` verbatim as `options.parts`. Cluster 1+2 sheets declared the FULL parts list as TAB_ORDER (e.g. `['header', 'tabs', 'details', 'description']`). Cluster 3a adopted a shorter "content-only" convention (`['details', 'description', 'gmNotes']`), and cluster 3b + cluster 4 followed cluster 3a. The header and tab navigation parts were silently dropped from `options.parts`, so the v1.0.0 item-shell-header partial (and the tab strip) never rendered for those sheets — the only visible header was Foundry's generic window-header. The item-header-chip context was being built correctly in `_prepareContext` for all those sheets, but the partial that consumed it was never invoked.

Concretely affected (before this fix): ability, hit-location, skillcat, mysticism, divine, armor (cluster 3a) + super, personality, culture (cluster 3b) + arcane, sorcery (cluster 4 new). 11 sheets total. The bug was latent since alpha.40 and survived cluster 3a/3b smoke because that smoke checked rendered tab strips and detail bodies, not the item-shell-header chip zone specifically.

**Initial fix attempt failed.** First approach tried to add resilience in the base `_configureRenderOptions`: after `super._configureRenderOptions(options)`, programmatically prepend `header` + `tabs` to `options.parts` when present in `PARTS` but absent from `TAB_ORDER`. Smoke caught that this approach triggers an infinite render loop. V14's `ApplicationV2._configureRenderOptions` runs `this._configureRenderParts(options)` and stores the result in private `#partDescriptors`. If `options.parts` is then overwritten with a list that includes parts marked `root: true` in their descriptors, V14 detects the root part inclusion and treats it as "re-render everything" — re-entering `_configureRenderOptions` and looping. The legacy cluster-1+2 per-sub-class `_configureRenderOptions` overrides worked because they ran on the FIRST render path before V14 had built its descriptor cache; running the same override from the base hoist (after V14's super has already locked in descriptors) crashes.

**Landed fix**: per-sheet TAB_ORDER updates. All 10 cluster-3a/3b/4 tabbed sheets had their `TAB_ORDER` declarations extended from the short content-only form to the full V14 form: `['header', 'tabs', 'details', 'description', 'gmNotes']` (and `['header', 'tabs', 'details', 'effects', 'description', 'gmNotes']` for armor with its preserved effects PART). hit-location stays `TAB_ORDER = null` (single-page, base hoist handles via the alt branch). Sheets updated: ability, skillcat, mysticism, divine, armor, super, personality, culture, arcane, sorcery — bit-identical 1-line edit each. The cluster-2 base `_configureRenderOptions` is preserved unchanged (no resilience layer). This matches the working cluster-1+2 convention exactly, avoiding any V14 lifecycle surgery.

Trade-off: future sheet authors must remember to include the full parts list in TAB_ORDER (not just content parts). This is the documented cluster-1+2 convention from alpha.39; the cluster-3a "shorter is cleaner" deviation was the latent bug. P12 polish item to consider: add a `node --check`-style lint that catches sheets with `TAB_ORDER` that omits `header` or `tabs` when `PARTS` declares them.



3 new shared partials registered in `init.mjs:2a`:

1. **`item-toggle-row.hbs`** — renders a flex row of `.elysium-item-toggle` chips. Takes a `chips` array of `{property, propertyPath?, active, label, tooltip?}`. Replaces the inline flag-block markup in divine (cluster 3a's `.elysium-divine-flag-row`), arcane (was native checkboxes), sorcery (was native checkboxes), and the inline specialism+chosen markup in super.
2. **`item-ap-grid.hbs`** — renders a 5-cell T1-T5 AP cost grid. Takes `apCostByTierList` + `isGM`. Replaces the inline cluster-3a divine AP grid markup (`.elysium-divine-ap-*` classes) and sorcery's legacy `.elysium-tier-grid` markup.
3. **`item-tier-effect-row.hbs`** — renders one per-tier effect row (header + cost + textarea + optional damage/locations sub-row when `showDamageLocations=true`). Replaces the inline cluster-3a divine tier-effect markup (`.elysium-divine-tier-effect-*` classes) and sorcery's legacy `.elysium-tier-effect-*` markup.

**Divine migrated to use all 3 new partials.** The `flagChips` array is built in `_prepareContext` with explicit `propertyPath` per chip. The AP grid and tier-effect blocks become 4-line partial calls each. **Super migrated from `.elysium-divine-flag-row` to `.elysium-item-toggle-row`** (1-line class rename — chips remain inline because of the conditional `{{#if specialism}}` around the chosen chip).

### Select-list helpers

- **`getSpellDamageTypeOptions()` renamed to `getDivineDamageTypeOptions()`** — same 5-option divine-flavored set (none/radiant/lightning/fire/sonic). Divine callsite updated (1 line).
- **NEW `getSorceryDamageTypeOptions()`** — full 14-entry cross-tradition palette (slashing/piercing/bludgeoning/force/fire/cold/lightning/corrosive/sonic/poison/necrotic/psychic/radiant/distortion + none). Cluster 5's weapon damage chips will reuse.
- **NEW `getSorceryEssenceOptions()`** — 12 essences + empty. Composes the "(<forbidden>)" suffix helper-side for death/blight/void so the per-essence i18n keys stay clean (12 essence labels + 1 reusable `Elysium.forbidden` suffix key, vs 24 keys if forbidden was per-language baked into the essence name).

### Long-term cleanups (no band-aids)

1. **`_onItemToggle` storage-path bug fix** — see above; pre-existing alpha.40 bug surfaced + fixed.
2. **Arcane v0.10.0-era debug logging retired** — 4 diagnostic `console.log` blocks removed from `_onFTAdd`, `_onFTRemove`, `_onRender`. One defensive `console.warn` retained for invalid ftKind path (the "shouldn't happen but log if it does" guard).
3. **Hardcoded English purge across spell items** — ~30 tooltip / placeholder / label strings migrated to i18n keys with proper en/es/fr translations.
4. **Culture vestigial CSS class retired** — `.elysium-divine-flag-row` class (cluster 3a name vestige) → `.elysium-item-toggle-row` (cluster 4 shared). Caught super.detail.hbs still using the old name during pre-flight orphan check; migrated.

### Damage-type accent palette extension

6 new family-grouped accent tokens added to `styles/elysium-tokens.css`:

- `--ely-accent-physical: #9aa3b1` (steel grey — slashing/piercing/bludgeoning/force)
- `--ely-accent-cold:     #7ac1e6` (icy blue — cold)
- `--ely-accent-corrosive:#a8d04a` (acid green — corrosive)
- `--ely-accent-poison:   #5e8c3a` (sickly green — poison)
- `--ely-accent-mind:     #7e5fb3` (dark purple — necrotic/psychic)
- `--ely-accent-distortion:#b59ccc`(pale violet — distortion)

Plus 4 existing reused: gold (radiant), electric (lightning), fire, air (sonic).

10-token palette covers all 14 sorcery damage types. Cluster 5 weapon damage chips will reuse the same palette.

### Legacy CSS retirement

After alpha.42 ships, 25 orphan CSS blocks (171 lines) deleted from `styles/elysium.css`:

- `.elysium-spell-sheet`, `.elysium-spell-tags`, `.elysium-spell-tag`+`.form`+`.technique`, `.elysium-spell-flags`, `.elysium-spell-sheet hr`
- `.elysium-spell-section`, `.elysium-spell-section-title`, `.elysium-spell-section-hint`
- `.elysium-tier-grid`, `.elysium-tier-cell`, `.elysium-tier-label`, `.elysium-tier-cell input[type="number"]`
- `.elysium-tier-effect-row`, `.elysium-tier-effect-header`, `.elysium-tier-effect-tier`, `.elysium-tier-effect-cost`, `.elysium-tier-effect-text`, `.elysium-tier-effect-readonly`
- `.elysium-ft-rows`, `.elysium-ft-row`, `.elysium-ft-select`, `.elysium-ft-add`, `.elysium-ft-remove`

Pre-flight grep confirmed zero remaining `.hbs` + `.mjs` consumers (only doc-comment refs in mysticism.detail.hbs which explicitly cite "migrated from" these classes — not load-bearing).

`.elysium-cast-damage-type-tag` and `.elysium-damage-{type}` family **preserved** — they remain live consumers in `templates/chat/cast-card.hbs` and `module/casting/sorcery-cast.mjs`. Cast-card markup rebuild is P12 work.

### i18n additions (61 new keys × 3 langs = 183 entries)

Arcane tooltips/placeholders (9): `requiredSLHint`, `basePPHint`, `apCostHint`, `saveSkillSpellHint`, `damageFlavourHint`, `formsHint`, `techniquesHint`, `schoolPlaceholder`, `damageFlavourPlaceholder`.

Sorcery tooltips/labels (~16): `essenceHint`, `baseTierSorceryHint`, `powerCostSorceryHint`, `damageTypeSorceryHint`, `effectsByTierSorceryHint`, `damageDiceHint`, `locationsHint`, `damageDicePlaceholder`, `noTierEffect`, `tierDamageReadonly`, `forbidden`, `forbiddenHint`, `sustained`, `casterChoosesLocation`, `casterChoosesLocationHint`, `maintainPP`, `maintainPPHint`, `locations`.

Damage type labels (10): `damageSlashing`, `damagePiercing`, `damageBludgeoning`, `damageForce`, `damageCold`, `damageCorrosive`, `damagePoison`, `damageNecrotic`, `damagePsychic`, `damageDistortion`.

Essence labels (13): `essence`, `essenceElemental`, `essenceVitality`, `essenceDeath`, `essenceWard`, `essenceLight`, `essenceShadow`, `essenceMind`, `essencePresence`, `essenceSoul`, `essenceWild`, `essenceBlight`, `essenceVoid`.

Arcane labels (8): `arcaneSchool`, `arcaneRequiredSL`, `arcaneBasePP`, `arcaneForms`, `arcaneTechniques`, `arcaneFormsAdd`, `arcaneTechniquesAdd`, `arcaneNotInCompendium`.

Spell flag chips + util (3): `isRitual`, `isPermanent`, `powerPointCost`.

### Sweep

- `node --check` on all touched .mjs: 6/6 OK (arcane + sorcery + divine + base + select-lists + init).
- Handlebars balance: 7/7 (3 detail templates + 4 partials touched/new).
- JSON parse: system.json + 3 lang files OK.
- CSS brace balance: `elysium-sheets.css` 506/506 (was 468/468; +38 new blocks); `elysium.css` 446/446 (was 476/476; -30 retired); `elysium-tokens.css` 3/3 (unchanged).
- i18n key existence: 48 template + 135 JS literal refs, 0 missing.
- Design-token existence: 24 cluster-4 CSS token refs, 0 missing.
- Lang parity: 65 new cluster-4 keys × 3 langs = 195 entries, 0 missing.

### Sheet-class LOC reduction

| Type | alpha.41 | alpha.42 | Δ |
|---|--:|--:|--:|
| arcane | 302 | 201 | -101 |
| sorcery | 192 | 178 | -14 |
| **subtotal sheets** | **494** | **379** | **-115** |
| + 3 new partials (item-toggle-row, item-ap-grid, item-tier-effect-row) | — | ~150 | +150 |
| + select-lists additions (~50 lines of helpers + i18n routing) | — | ~50 | +50 |
| − legacy elysium.css retirement | — | — | -171 |
| **net effect** | **494** | **408** | **-86 LOC** |

Less aggressive than the audit's -270 estimate. Reality check:
- Sorcery's `_prepareContext` body grew substantially (~40 LOC of flagChips + essence/damage/save name resolution) to feed the new partials. Audit underestimated this.
- The 3 new partials cost more than the audit's ~80-line estimate because of full doc-comments per partial.
- Audit assumed both sheets would drop their full _getTabs / _configureRenderOptions blocks; sorcery already had them hoisted from cluster 2 (audit miscounted).

Real win is duplication elimination: per-tier effect markup, AP grid markup, and flag-row markup now live in single shared partials across divine + arcane + sorcery (and future career in cluster 6 can reuse).

### Version

System `1.0.0-alpha.41` → `1.0.0-alpha.42`. Compendium unchanged at `1.0.0-alpha.3`.

### Cluster 4 smoke test plan

a. **arcane (no specialism)** — open an arcane item. Verify: 4 header chips (School, RequiredSL, BasePP, APCost); 8 field rows (school/requiredSL/basePP/apCost/saveSkill/range/duration/damage); F/T row dropdowns render with current stored values; "+ Forms" / "+ Techniques" buttons present and clicking them appends an empty row.

b. **arcane F/T add/remove round-trip** — click "+ Forms": verify a new empty `<select>` row appears with current stored forms preserved + an empty placeholder option. Click trash on a form: verify it's removed from `system.elysium.forms[]`. Same for techniques. Stored values not in the compendium render with "(not in compendium)" label.

c. **arcane flag chips fix** — click "Ritual" chip on arcane: verify the chip flips to `--active` AND `system.elysium.isRitual` flips to `true`. Click again: verify it flips back. Same for isPermanent. Critically: verify `system.isRitual` (junk flat path) is NOT created.

d. **divine flag chips retroactive fix** — open divine. Click "Ritual" chip: verify `system.elysium.isRitual` flips end-to-end. Pre-alpha.42 this was silently broken; post-alpha.42 it works.

e. **sorcery (with isSustained off)** — open a sorcery item. Verify: 3 header chips (Essence, Tier band, Power Cost); 7 main field rows; AP cost grid (5 cells T1-T5); per-tier effect rows render only for active tiers (baseTier to maxTier); each effect row has damage dice + locations sub-row; 4 flag chips render; Maintain PP/round row NOT rendered.

f. **sorcery isSustained toggle** — click "Sustained" chip: verify chip activates, `system.elysium.isSustained = true`, and the Maintain PP/round row appears in the next render cycle.

g. **sorcery essence forbidden display** — set essence to "death": verify the readonly view (or chip readout if any) shows the forbidden badge. Player view also shows "Death (forbidden)" in the select label (composed helper-side).

h. **sorcery damage type tag** — set damage type to "corrosive": verify the readonly tag shows `--ely-accent-corrosive` (acid green) background. Test 3-4 other types across the family palette.

i. **sorcery legacy field preservation** — verify `mySorceryHandler` still preserves `var`/`maxLvl`/`currLvl`/`memLvl` when the template doesn't expose them.

j. **divine partial migration regression** — divine should render identically to alpha.41 with: same header chips, same AP grid (now via partial), same effects-by-tier rows (now via partial), same 3 flag chips (now via partial). Cluster-3a behavior preserved end-to-end.

k. **8-sheet regression sample** — open one of each: ability, hit-loc, skillcat, mysticism, armor (cluster 3a) + super, personality, culture (cluster 3b). All render identically to pre-alpha.42.

l. **Legacy CSS retirement check** — open weapon + career + skill (still-legacy). Verify they still render correctly (their styling comes from elysium.css blocks that were NOT retired).

m. **Console clean** — no missing-i18n / missing-CSS-token / Handlebars compile errors / `_onItemToggle` invalid-path warnings.

---

Fourth P10 ship. Migrates the 3 drag/drop sheets deferred from cluster 3a (super, personality, culture) onto v1.0.0, and introduces an intermediate base class that hoists the drag/drop boilerplate shared with cluster 5's skill sheet. After this ship, **18 of 23 item types** are on v1.0.0 (78%); 5 remain on legacy paths (skill, weapon, arcane, sorcery, career).

### Cluster 3b scope

Three item types:
- **super** — specialism-aware header (mainName + specName synthesized into item.name); 4-field numeric grid + 2 toggle chips + (when owned) powerMod drop list with embedded sub-item lifecycle
- **personality** — main skill list + optional skill groups; drop adds skill references; add/remove group buttons
- **culture** — personality++ with stat-formula grid + per-skill cultural bonus prompted via dialog

### New intermediate base class — `ElysiumDragDropItemSheet`

`module/item/sheets/base-dragdrop-item-sheet.mjs` (207 lines, ~140 code-only). Sits between `ElysiumItemSheetV2` and the 3 cluster-3b sheets. Hoists:

- **8 drag/drop boilerplate methods** — `_canDragStart`, `_canDragDrop`, `_onDragStart`, `_onDragOver`, `_onDropItem`, `_onDropFolder`, `get dragDrop`, `#createDragDropHandlers` — all bit-identical across super, personality, culture (and skill in cluster 5). Constructor wires `#createDragDropHandlers` automatically.
- **4 collection-management methods** with personality/culture-flavor defaults — `_onItemDelete`, `_onItemView`, `_onGroupItemDelete`, `_onGroupControl`. Super overrides 2 (`_onItemDelete` to also `await oldItem.delete()` the embedded sub-item; `_onItemView` to resolve via uuid not elysiumid).
- **Default `_onRender`** that wires the 4 imperative listeners on legacy class hooks (`.item-delete`, `.item-view`, `.group-item-delete`, `.group-control`) — audit-5 lock preserved through cluster 3b; V14-actions migration deferred to P12.

Sub-classes that need drag/drop now just declare `dragDrop: [...]` in `DEFAULT_OPTIONS` and override `_onDrop` with type-specific semantics. Everything else inherits.

### Two new shared partials

Both registered in `init.mjs:2a`:

- **`templates/item/parts/item-shell-header-specialism.hbs`** (~80 lines) — variant of `item-shell-header.hbs` for items whose `system.specialism` flag splits the displayed name into two inputs (mainName + specName joined by a separator). When specialism is false, renders identically to the standard header. **Consumers**: super (cluster 3b), skill (cluster 3b PARTS swap per c3b-4; full rebuild deferred to cluster 5).

- **`templates/item/parts/item-skill-row.hbs`** (~50 lines) — single skill row in a collection list. Renders skill name + modifier badge (var/grp/N%) + optional cultural bonus span (positive green / negative red) + delete control. Caller passes `skill`, `isGM`, `showBonus`, `deleteClass`. **Consumers**: personality (4 inline copies replaced), culture (4 inline copies replaced), future career (cluster 6). 

### Orphan retirement (c3b-6)

`templates/item/skill.header.hbs` (17 lines) — retired in this ship. Its two consumers (super, skill) both swap to the new `item-shell-header-specialism.hbs` partial. Pre-flight grep confirmed zero remaining `.hbs`/`.mjs`/`.json` references before deletion (only doc-comments cite the retirement). Same orphan-retirement pattern as P9 cluster 1's `character.skills.hbs` deletion (alpha.30).

### Skill PARTS.header swap (c3b-4)

`module/item/sheets/skill.mjs` line 24: `PARTS.header` swapped from legacy `skill.header.hbs` to the new `item-shell-header-specialism.hbs`. The new partial is a strict structural superset of the legacy — same `mainName`/`specName` inputs when specialism, single mainName otherwise. Skill's detail body remains on legacy paths until cluster 5 finishes the migration. One-line change; cleanest path to retire the orphan without leaving two parallel implementations alive.

### Long-term cleanups (no band-aids)

1. **`.closest('.item')` widening (c3b-5)** — same buried-bug pattern as alpha.33/.34 fixes. The 4 imperative listeners (super: 3 lookups; personality + culture: 7 lookups) all relied on a legacy `.item` class on the row wrapper. v1.0.0 markup uses BEM classes; the `.item` class was a load-bearing legacy hook. Cluster 3b widens every lookup to `closest('[data-item-id]')` (and `closest('[data-group]')` for group-row lookups). The `data-item-id` and `data-group` attributes are the durable contract — they survive any future BEM-class refactor. Skill's lookups stay on the legacy pattern in this ship (cluster 5 widens them when migrating skill's body).

2. **`Cultural Bonus: ` hardcoded English string (c3b-culture-2)** — replaced with `Elysium.culturalBonus` i18n key (added in alpha.40 specifically for this consumer). Now properly localized en/es/fr.

3. **Stat-formula `newrow` flag gymnastics (c3b-culture-3)** — legacy culture template iterated 8 stats flat and branched on a `newrow` flag set in `_prepareContext` to decide whether to insert a line break. Cluster 3b's `_prepareContext` builds an explicit `statPairs[][]` structure (4 pairs × 2 stats). Template loops `{{#each statPairs}}` then `{{#each pair}}` — no flag-based template branching, cleaner data shape.

4. **Culture dialog title fix** — legacy `culture.mjs:211` passed the literal string `'test'` as the skill name to the `enterValue` cultural-bonus dialog (so every dialog title read "Cultural Bonus: test"). Cluster 3b passes `item.name`, so the dialog now shows the actual dropped skill's name.

### itemToggle action wiring (cluster 3b additions)

Super's 2 toggle chips (specialism, chosen) were already in the GM-only + writable allow-lists. No changes needed.

### Drop semantics distinction preserved

Three different drop semantics across the 3 sheets:
- **super**: drops CREATE an embedded actor sub-item (`Item.create(...)` then store new uuid). Delete cleans up the embedded item.
- **personality**: drops store REFERENCES (uuid + elysiumid) to existing skills. Delete splices the collection only.
- **culture**: drops store REFERENCES with an additional `bonus` prompted via `ElysiumDialog.input`. Cancelling the dialog or entering 0 skips the drop entirely.

Each sub-class overrides `_onDrop` with the appropriate flavor. Form handlers preserve the existing groups-skill-rehydration logic on submit.

### Design tokens (P10 cluster 3b)

No new tokens added — all CSS references canonical existing tokens (`--ely-surface-card`, `--ely-surface-raised`, `--ely-surface-base`, `--ely-border-subtle`, `--ely-border-decorative`, `--ely-text-body`, `--ely-text-decorative`, `--ely-text-link`, `--ely-text-muted`, `--ely-accent-success`, `--ely-accent-danger`, `--ely-font-size-2`/`-3`/`-4`, `--ely-space-1`/`-2`, `--ely-radius-1`). Caught one reference to non-existent `--ely-surface-elevated` during pre-flight; corrected to `--ely-surface-raised` (canonical "raised surface" token). Cluster-3a's added design-token-existence sweep caught it before ship.

### i18n additions

3 new keys added to `lang/en.json` + `lang/es.json` + `lang/fr.json`:
- `Elysium.specName` — "specify" / "especificar" / "spécifier" (placeholder for the spec-name input on specialism-aware header)
- `Elysium.skillCount` — "Skill Count" / "Número de Habilidades" / "Nombre de Compétences" (header chip on personality + culture)
- `Elysium.statFormulaCount` — "Stat Formulas" / "Fórmulas de Características" / "Formules de Caractéristiques" (header chip on culture)

### CSS additions (+170 lines, +34 brace pairs)

In `styles/elysium-sheets.css`:
- Specialism header pair (`.elysium-item-header-name-pair`, separator, main/spec width variants)
- Shared skill-row (`.elysium-item-skill-row` + name/modifier/bonus/controls/delete sub-elements; positive + negative bonus color variants)
- Skill list container + optional skill group container
- Group controls (label, options input, add/remove buttons with success/danger hover)
- Culture stat-formula 2-column pair grid (7-cell row template: label/dice/bonus/spacer/label/dice/bonus)

### Sweep

- CSS brace balance: 468/468 (alpha.40 was 434/434; +34 new blocks).
- Cluster 3b Handlebars balance: 5/5 (3 detail templates + 2 partials).
- `node --check` on all touched .mjs: 6/6 OK (base-dragdrop + 3 sheets + skill + init).
- JSON parse: system.json + 3 lang files OK.
- i18n key existence: 29 cluster-3b template refs + 10 cluster-3b JS literal refs, 0 missing.
- Design-token existence: 17 cluster-3b CSS refs, 0 missing.
- Pre-flight caught: `--ely-surface-elevated` typo → fixed to canonical `--ely-surface-raised`.

### Sheet-class LOC reduction

| Type | alpha.40 | alpha.41 | Δ |
|---|--:|--:|--:|
| super | 278 | 172 | -106 |
| personality | 354 | 198 | -156 |
| culture | 397 | 257 | -140 |
| **subtotal sheets** | **1029** | **627** | **-402** |
| + base-dragdrop-item-sheet.mjs | — | 207 | +207 |
| **net** | **1029** | **834** | **-195 (-19%)** |

LOC reduction less aggressive than cluster 3a's -42% because the 3 sheets share less mechanical structure (3 different `_onDrop` flavors, 2 different `_onItemDelete` flavors, 2 different `_onItemView` flavors). The win is in elimination of duplication: 248 LOC of bit-identical drag/drop boilerplate × 3 sheets folded into 1 base class. Cluster 5's skill migration will amortize the base-class cost further (another ~62 LOC of identical boilerplate folded in).

### Version

System `1.0.0-alpha.40` → `1.0.0-alpha.41`. Compendium unchanged at `1.0.0-alpha.3`.

### Cluster 3b smoke test plan

a. **super** — open existing super (or create one). Verify: specialism-aware header (toggle specialism on/off — name input pair appears/disappears); chip strip (Range, Duration, Power Cost + Level when owned); custom form handler synthesizes `item.name = mainName + ' (' + specName + ')'` when specialism, otherwise just `mainName`; powerMod drop list renders with item-view + item-delete controls; drop a powerMod item from sidebar — creates embedded sub-item on actor; delete from drop list — removes from collection AND deletes embedded item.

b. **personality** — open existing personality. Verify: main skill list renders; drop a skill from sidebar — appears in main list (one item-skill-row); add optional skill group (clicking +); drop into the group's droppable — appears in group; delete from main list (trash icon) — removes from collection; delete from group (trash icon) — removes from group's skills array; remove group (clicking -) — group disappears; clicking a skill row's name opens the source skill's sheet via elysiumid lookup.

c. **culture** — open existing culture. Verify: stat-formula 2-column grid renders 4 rows × 2 stat pairs (str/siz, con/int, pow/cha, dex/edu); editing a formula field persists to `system.stats.<key>.formula`; drop a skill — ElysiumDialog prompt appears with skill name in title ("Cultural Bonus: \<name\>"); enter a numeric value, confirm — skill row appears with positive/negative bonus span; enter 0 or cancel — drop is skipped; bonus colors render green/red per sign.

d. **skill PARTS.header swap** — open existing skill. Verify: header renders the new specialism partial (image left, name input right, type label below, no chips yet — skill chip plan is cluster 5). Skill detail body still uses legacy styling. No console errors.

e. **8-sheet regression sample** — open ability, hit-location, skillcat, mysticism, divine, armor (cluster 3a sheets) + weapon, arcane, sorcery, career (still on legacy paths). Each should render identically to alpha.40. No console errors.

f. **Active-effects regression** — open a wound and an armor. Verify the active-effects PART still functions (audit-5 hook preserved).

g. **Console clean** — no missing-i18n-key warnings, no missing-CSS-token errors, no Handlebars compile errors, no `closest('.item')` returning null errors on the rebuilt sheets.

---

Third P10 ship. Migrates the six standalone (no drag/drop) cluster-3 sheets onto the v1.0.0 shell + hoisted base. After this ship, **15 of 23 item types** are on v1.0.0 (65%); 8 remain on legacy paths (super, personality, culture in cluster 3b — alpha.41; weapon, arcane, sorcery, skill, career in clusters 4-6).

### Cluster 3a scope

Six item types:
- **ability** — tabbed, percentile/static branch; ProseMirror migration for `effectText` + `prerequisitesText`
- **hit-location** — single-page mode (TAB_ORDER = null); preserves custom form-handler that synthesizes `name` from `displayName + bodyPlan`
- **skillcat** — tabbed; replaces 8 redundant per-stat `advStatOptions*` / `skillCatName*` context fields with one shared `advStatOptions` + a single looped `statRows[]` data structure
- **mysticism** — tabbed, wide-tier 720×720; flat 8-field GM/player split; replaces `elysium-spell-sheet` legacy classes with v1.0.0 partials
- **divine** — tabbed, wide-tier 720×720; preserves per-tier AP-cost + effect-text computation; new `elysium-item-toggle` chips for ritual/reactive/damageSpell flags; damage-type colored tag
- **armor** — tabbed, wide-tier 720×720; effects PART preserved (audit-5 lock); detail body split into 4 sub-grids (Protection / Encumbrance / Penalties / Power)

### Long-term cleanups (no band-aids)

Bugs pre-existing in cluster 3a sheets, fixed during rebuild (NOT as patches; properly resolved during proper migration):

1. **armor.detail.hbs** lines 81/83: player branch used `physMod`/`stealthMod` (camelCase) vs DataModel field names `physmod`/`stealthmod` (lowercase). Player view rendered values as blank. Fixed via correct casing on rewrite.

2. **skillcat.mjs**: 8 `advStatOptions*` per-stat context fields, each calling `getAdvSkillCatOptions()` with no args (all identical), but template only ever referenced `advStatOptionsCon`. Plus 8 redundant `skillCatName*` context fields. Collapsed both into one shared `advStatOptions` + looped `statRows[]` data structure (-7 dead context lines; cleaner mental model).

3. **hit-location.detail.hbs** line 90 referenced missing `Elysium.severedHint`. Added across all 3 lang files.

4. **hit-location.detail.hbs** lines 85, 87, 93: injured / incapacitated / unconscious toggle chips were missing `data-action="itemToggle"` and were non-functional. Fixed: all 5 condition chips now have proper action attribute. itemToggle allow-list extended to include `injured` / `incapacitated` / `unconscious` (player-writable for combat status flips on their own location).

5. **hit-location.detail.hbs** lines 30, 43, 51: hardcoded English tooltips ("Mythras body-part designation…", "Laterality: left or right…", "Enumeration index…"). Replaced with i18n keys `Elysium.bodyPartHint`, `Elysium.bodySideHint`, `Elysium.bodyIndexHint` (added to all 3 langs).

6. **divine.detail.hbs**: 9+ hardcoded English labels ("Base Tier", "Max Tier", "Damage Type", "Effects by Tier", "AP Cost by Tier", option labels for damage types and save skills) and 3 hardcoded tooltips. All migrated to properly-named i18n keys; same shared keys reused by mysticism's saveSkill list.

7. **mysticism.detail.hbs**: 4 hardcoded English option labels in `saveSkill` select ("Evade", "Willpower", "Endurance", "Brawn"). Migrated to use new `ElysiumSelectLists.getSpellSaveSkillOptions()` helper, which emits `{value: localizedLabel}` against the new `Elysium.saveSkill*` keys. Same pattern applied to divine. Same helper consumed by both → single source of truth.

### Hit-location single-page conversion

Per c3-hitloc-1: hit-location had only one content tab (no description, no gmNotes), so the tab strip was degenerate (1 chip). Migrated to single-page mode using `TAB_ORDER = null` + `PARTS = {header, details}`. Same single-page pattern as cluster 2's 6 simple types. Eliminates the vestigial tab strip; saves vertical space.

### itemToggle allow-list extension

Per c3-divine-4 + the c3-hitloc-3 bug fix:
- GM-only list (`_onItemToggle` line 248 set): added `isRitual`, `isReactive`, `isDamageSpell` (divine spell authoring data; should not be flipped by players).
- Writable list (line 253 set): added `isRitual`, `isReactive`, `isDamageSpell` (so the GM-only branch lets them through to the actual update), plus `injured`, `incapacitated`, `unconscious` (player-writable combat status flips on owned hit-location).

### Design tokens (P10 cluster 3a additions)

Added 4 damage-type accent tokens to `styles/elysium-tokens.css`:
- `--ely-accent-gold` (radiant: #c8a14b)
- `--ely-accent-electric` (lightning: #6a90ff)
- `--ely-accent-fire` (fire: #d8542c)
- `--ely-accent-air` (sonic: #8aa6c2)

Used by `.elysium-damage-tag--<type>` variants on the divine player-mode display. Future damage-type surfaces (weapon damage chips in cluster 5, arcane spell cards in cluster 4) can reuse the same palette.

### ElysiumSelectLists additions

- `getSpellSaveSkillOptions()` — returns `{'': '—', 'evade': ..., 'willpower': ..., 'endurance': ..., 'brawn': ...}` with localized labels (shared by mysticism + divine).
- `getSpellDamageTypeOptions()` — returns `{'': '— (none / healing)', 'radiant': ..., 'lightning': ..., 'fire': ..., 'sonic': ...}` (used by divine; reusable for any future damage-type spell surface).

### CSS additions (+72 lines, +17 brace pairs)

In `styles/elysium-sheets.css`:
- `.elysium-item-condition-row` — horizontal toggle-chip cluster (hit-location conditions).
- `.elysium-divine-ap-grid` + `.elysium-divine-ap-cell` + `.elysium-divine-ap-label` — T1-T5 AP-cost grid.
- `.elysium-divine-tier-effect` + sub-elements — per-tier effect block (active baseTier..maxTier rows).
- `.elysium-divine-flag-row` — 3-chip horizontal cluster for ritual/reactive/damageSpell toggles.
- `.elysium-damage-tag` base + 4 `--radiant|lightning|fire|sonic` variants.

### Mid-development design-system cleanup

While writing cluster-3a CSS I caught references to 4 non-existent design tokens (`--ely-text-default`, `--ely-text-on-accent`, `--ely-font-size-default`, `--ely-font-size-small`) being used in PRE-EXISTING parts of the stylesheet. These silently fall through to inherited values at runtime. New cluster-3a code uses the canonical scale: `--ely-text-body`, `--ely-text-inverse`, `--ely-font-size-3` (default 14px), `--ely-font-size-2` (small 12px). The pre-existing references are tech debt for a later cluster; documenting here so future audits catch them. Adding a NEW pre-flight check: cluster 3+ CSS must reference only tokens defined in `elysium-tokens.css` (no implicit fallbacks).

### i18n additions

38 new keys added to `lang/en.json` + `lang/es.json` + `lang/fr.json` (proper translations for all 3):
- Hit-location: `severedHint`, `bodyPartHint`, `bodySideHint`, `bodyIndexHint`, `bodyPart`, `bodySide`, `bodyIndex`
- Divine: `baseTier`, `maxTier`, `damageType`, `effectsByTier`, `apCostByTier`, `domain`, `tierHint`, `baseTierHint`, `maxTierHint`, `tier`, `apCost`, `apShort`, `powerCost`, `saveSkill`, `ritual`, `reactive`, `damageSpell`
- Shared save-skill: `saveSkillNone`, `saveSkillEvade`, `saveSkillWillpower`, `saveSkillEndurance`, `saveSkillBrawn`
- Damage-type: `damageRadiant`, `damageLightning`, `damageFire`, `damageSonic`, `damageNone`
- Armor sub-grids: `protection`, `penalties`, `power`, `encumbrance`
- Mysticism + general: `discipline`, `category`, `effectText`, `prerequisitesText`, `culturalBonus` (used by cluster 3b)

### Mid-smoke polish — `Elysium.apShort` flat key

Caught during divine smoke: the per-tier effect-row cost label rendered as "(1 AP Cost)" because I used `Elysium.apCost` ("AP Cost") inline next to the cost number. Grammatically awkward in context — the surrounding section is already titled "AP Cost by Tier", so the per-row label just needs the abbreviation. Pre-existing `Elysium.AP.Label` ("AP") exists in en.json but is missing from es.json and fr.json (the Mysticism + Divine + AP nested namespaces each have 0 keys in the non-English langs — pre-existing parity debt). Adding to that namespace would compound the gap. Per cluster-3a "always flat for new keys" decision: added `Elysium.apShort` to all 3 lang files with proper translations (en "AP" / es "PA" / fr "PA") and switched the divine per-tier-cost label to use it. Section header `Elysium.apCostByTier` ("AP Cost by Tier") preserved — the row label and section header are now distinct keys, each used in the appropriate place.

### Sweep

- CSS brace balance: 434/434 (alpha.39 was 417/417; +17 new blocks).
- Cluster 3a Handlebars balance: 6/6 templates balanced.
- `node --check` on all touched .mjs: 8/8 OK (6 sheets + base + select-lists).
- JSON parse: system.json + 3 lang files OK.
- **NEW pre-flight: i18n key existence sweep**: 88 cluster-3a template refs + 121 cluster-3a JS refs (literals only; dynamic prefixes excluded). 0 missing in cluster-3a touched files.
- **NEW pre-flight: design-token existence sweep**: 0 cluster-3a CSS references to non-existent tokens.

### Sheet-class LOC reduction

| Type | alpha.39 | alpha.40 | Δ |
|---|--:|--:|--:|
| ability | 124 | 72 | -52 |
| hit-location | 102 | 70 | -32 |
| skillcat | 143 | 68 | -75 |
| mysticism | 135 | 60 | -75 |
| divine | 170 | 121 | -49 |
| armor | 145 | 84 | -61 |
| **total** | **819** | **475** | **-344 (-42%)** |

Combined with cluster 2's -646 LOC (-55%) reduction: cumulative -990 LOC across 14 sheets so far. Hoisted base is delivering.

### Version

System `1.0.0-alpha.39` → `1.0.0-alpha.40`. Compendium unchanged at `1.0.0-alpha.3`.

### Cluster 3a smoke test plan

a. **ability** — open the existing ability item (or create one). Verify: percentile/static branch works (toggle changes header chip + reveals/hides Base/XP/Total panel); ProseMirror effectText + prerequisitesText edit + persist; header chips render (Type, Category, Total when percentile+owned).

b. **hit-location** — open existing hit-location. Verify: single-page mode (no tab strip), all 11 GM fields render, owner-only HP adj + condition row, 5 condition chips toggle on click (including the previously-broken injured / incapacitated / unconscious), severed/dead conditional swap works based on locType.

c. **skillcat** — open existing skillcat. Verify: 8 stat-attrib selects all render with proper localized labels; selection changes persist for any stat (not just CON); owner-only modifiers block shows bonus/manual/total.

d. **mysticism** — open existing mysticism. Verify: 8 fields render; GM-edit / player-readonly split correct; saveSkill select uses localized labels via new helper; header chips render (Discipline, Tier, Power Cost); wider 720×720 width.

e. **divine** — open existing divine. Verify: 8 top-level fields; AP-cost T1-T5 grid renders + persists per-tier; effects-by-tier section shows active tier rows only (baseTier..maxTier); 3 toggle chips (ritual, reactive, damageSpell) flip on click; damage-type tag colors render per type (player mode); custom form handler syncs name to category.

f. **armor** — open existing armor. Verify: 4 sub-grids labeled (Protection, Encumbrance, Penalties, Power); **physmod/stealthmod player display now shows actual values** (bug fix); effects PART tab works (audit-5 hook preserved — trash icon, add-change, inline edit selects/inputs).

g. **8-sheet regression sample** — open weapon, super, personality, culture, arcane, sorcery, skill, career (a sampling of clusters 3b/4/5/6 types). Each should render identically to alpha.39 via legacy paths.

h. **Console clean** — no missing-i18n-key warnings, no missing-CSS-token errors, no Handlebars compile errors.

---

Second of six P10 clusters. Migrates the 8 simplest item types onto the v1.0.0 shell, hoists the tab-lifecycle methods into `base-item-sheet.mjs`, and cleans up gear from cluster 1 to use the hoisted pattern. After this ship, 9 of 23 item types are on v1.0.0 (39%); 14 remain on legacy paths through clusters 3-6.

### Audit-then-stop discipline

`docs/p10-cluster2-audit.md` (471 lines) shipped first. 5 open questions locked per user "confirm":
- **c2-1**: Dedicated single-page partial variants (Option B).
- **c2-2**: Per-type header chip table.
- **c2-3**: Hoist tab-lifecycle methods now; migrate gear + 8 cluster-2 sheets in this ship.
- **c2-4**: All 8 types → 560×640.
- **c2-5**: `shortDesc` field on failing + powerMod stays as inline single-line input, distinct from long-form ProseMirror description.

### Base sheet hoist

`module/item/sheets/base-item-sheet.mjs` 122 → 280 lines. Adds:

- **`static TAB_ORDER`** — sub-class declaration of part order (e.g. `['header', 'tabs', 'details', 'effects', 'description']`). When null, sheet renders single-page (no tabs strip, no description / gmNotes / effects PARTs).
- **`_configureRenderOptions(options)`** — emits TAB_ORDER + auto-appends `gmNotes` for GMs when `PARTS.gmNotes` exists. Single-page mode emits just `['header', 'details']`.
- **`_getTabs(parts)`** — builds the tabs context map for tabbed sheets; returns `{}` for single-page. Recognizes the `benefits` case (allegiance) alongside the standard details/effects/description/gmNotes.
- **`_preparePartContext(partId, context)`** — default handling for the 6 standard parts (details, effects, description, gmNotes, benefits). Single-page sheets auto-enrich description + gmDescription on the `details` part (so the inlined `item-singlepage-description` partial receives `enrichedDescription` / `enrichedGMDescription` at render time).
- **`_enrichField(fieldName)`** — helper for `TextEditor.enrichHTML` calls; deduplicates the 4-arg invocation that was previously copied across 8+ sheets.

Sub-classes now express their shape declaratively (TAB_ORDER + PARTS + per-type chips) instead of duplicating tab-construction logic.

### 2 new single-page partials

Both in `templates/item/parts/`, registered in `init.mjs:2a` with a `P10 cluster 2 (alpha.39)` comment.

- **`item-singlepage-description.hbs`** (~40 lines): inline description + GM-only inline notes block, rendered directly inside a single-page detail template. No `section.tab` wrapper — always visible. GM notes block has a subtle dashed accent border + accent-color label so GMs can distinguish their private notes from the player-visible description.
- **`item-singlepage-effects.hbs`** (~65 lines): inline effects display for single-page sheets (wound, primarily). Same effect-change-row structure as `item-shell-effects.hbs` — `active-effect-change-edit` legacy class hook preserved per audit-5 lock for `ElysiumActiveEffectSheet.activateListeners`.

### 9 template rewrites

All 8 cluster-2 detail templates rewritten using v1.0.0 partials (`item-field-grid`, `item-field-row`, single-page wrappers) + allegiance's `benefits.hbs` restyled. Each uses Handlebars `@partial-block` with full-path-as-closer syntax (alpha.38 lesson).

| Template | Mode | Notes |
|---|---|---|
| reputation.detail.hbs | single-page | Owner-only Base score; empty-message when unowned |
| failing.detail.hbs | single-page | CPC mod (GM-editable/player-readonly); shortDesc inline input |
| wound.detail.hbs | single-page | Damage value + treated/untreated toggle; inlined effects display |
| passion.detail.hbs | single-page | Owner-only Base/XP/Total + improve checkbox |
| powerMod.detail.hbs | single-page | CPC mod + perLvl toggle + shortDesc + description |
| mutation.detail.hbs | single-page | Impact select (GM)/label (player) + minorOnly toggle + minor/major chip |
| persTrait.detail.hbs | tabbed | Opposed-trait + basic toggle + owner-only scores + improve+oppimprove |
| allegiance.detail.hbs | tabbed | Opposed-allegiance + owner-only points + title + conditional `isOr`/`isAnd` allies/apoth chain + enemy + check |
| allegiance.benefits.hbs | tabbed | ProseMirror restyle on the separate Benefits tab |

All 6 itemToggle properties preserved verbatim (`treated`, `improve`, `oppimprove`, `basic`, `minorOnly`, `minor`, `perLvl`, `allegAllied`, `allegApoth`, `allegEnemy`). All `name="system.X"` form paths preserved verbatim. The `isOr` / `isAnd` Handlebars helpers (registered in `handlebar-helper.mjs:4-10`) continue to work in the new allegiance template unchanged.

### 9 sheet class updates

| Sheet | LOC: before → after | Mode | Header chips |
|---|---|---|---|
| gear.mjs (cluster-1 cleanup) | 187 → 102 | tabbed | unchanged (Actual ENC + Price + Status when owned, ENC + Price when not) |
| reputation.mjs | 124 → 45 | single-page | Base when owned |
| failing.mjs | 124 → 44 | single-page | CPC mod (always) |
| wound.mjs | 107 → 65 | single-page | Damage + treated/untreated when owned |
| passion.mjs | 125 → 48 | single-page | Base + XP + Total when owned |
| powerMod.mjs | 122 → 43 | single-page | CPC mod (always) |
| mutation.mjs | 130 → 65 | single-page | Impact + minor/major when owned |
| persTrait.mjs | 122 → 60 | tabbed | Opposed-trait + Total + Opposed Total when owned |
| allegiance.mjs | 137 → 60 | tabbed | Opposed-allegiance + Title + Total when owned |

Total cluster 2 + gear sheet-class LOC: 1178 → 532 = **−646 LOC** (-55%). Of that, ~160 LOC moved into the base hoist; the rest is eliminated duplication.

All chip values stringify numerics (cluster-1 lesson — Handlebars `{{#if 0}}` is falsy) and emit em-dash placeholders when underlying string fields are empty (default state on freshly-created items).

### CSS additions

`styles/elysium-sheets.css` 2928 → 3033 (+105 lines, +12 brace pairs):

- Single-page sheet layout (`.elysium-item-singlepage` flex column with gap)
- Single-page section divider (`.elysium-item-singlepage-section` with top border between detail / description / gmnotes / effects blocks)
- Single-page section label (uppercase decorative-color heading per block)
- GM-notes call-out variant (dashed accent border + accent-color label so GMs see their private notes are private)
- Item toggle utility (`.elysium-item-toggle` + `--active` modifier; replaces legacy `toggle-active` pattern used in cluster-2 templates and clusters 3-6)
- Improve-checkbox styling (square/check icon container with bonus-accent on checked state; replaces inline `itemIcon` pattern from 4 cluster-2 templates)

All tokens resolve against `elysium-tokens.css`. Only `--ely-hp-pct` flagged in sweep (intentional runtime property).

### Cluster isolation preserved

The 14 non-cluster-2-non-gear item types (ability, allegiance \[oh wait, that's cluster-2; nm\], arcane, armor, career, culture, divine, hit-location, mysticism, personality, skill, skillcat, sorcery, super, weapon) continue to render against their legacy paths. **No legacy template path edited or deleted.** Each subsequent cluster swaps its types over.

### Mid-smoke fixes — i18n key audit + sed escape bug + doc-comment cleanup

Mid-smoke discovery: my cluster-2 work referenced 5 i18n keys that don't exist in any lang file. Pre-flight key existence check was missing from the alpha.38/alpha.39 sweep checklist; adding it for cluster 3+:

1. **`Elysium.itemName`** (used as placeholder in `item-shell-header.hbs` from cluster 1) — fix: use existing `Elysium.name` ("Name") instead. No new key needed.

2. **`Elysium.noActiveEffects`** (empty-state message in both `item-shell-effects.hbs` and `item-singlepage-effects.hbs`) — added `Elysium.noActiveEffects = "No active effects"` to all 3 lang files.

3. **`Elysium.unownedItemHint`** (empty-message on unowned reputation + passion single-page sheets) — added a properly explanatory string: *"This item must be added to a character before its scores can be set."*

4. **`Elysium.yes`** (perLvl chip text on powerMod) — added; `Elysium.no` already existed.

5. **`Elysium.shortDesc`** (used as inline-input label on failing + powerMod): the deeper miss. Inspection of `templates/actor/parts/failing-row.hbs` reveals `shortDesc` is a **display-name override** — the actor super-tab row renders `system.shortDesc` when set, falling back to `item.name` when empty. The legacy item-side template labeled this confusingly with `Elysium.description` (creating two "Description" labels on the same sheet). My first fix introduced `Elysium.summary` as a stopgap label. Per long-term-clean policy, replaced with semantically-correct `Elysium.displayName = "Display Name"` (Spanish: "Nombre Visible"; French: "Nom Affiché"). Both `failing.mjs` and `powerMod.mjs` DataModels now have doc-comments explicitly stating the field's display-override role and pointing at the actor-side consumer.

### Mid-smoke fix — sed escape bug

A regex `re.sub` in my mid-smoke patch introduced backslash-escaped quotes in the `name` attribute of the shortDesc `<input>` in both failing + powerMod templates: `name=\"system.shortDesc\"`. The malformed attribute would have caused form submissions to silently lose changes to the field. Caught by a follow-up grep audit before final ship. Fixed both templates; pre-flight Handlebars-balance sweep confirms templates still parse correctly.

### Mid-smoke cleanup — doc-comment examples

Three cluster-1 utility partials (`item-field-row.hbs`, `item-field-grid.hbs`, `item-section-card.hbs`) had doc-comment usage examples showing the wrong `{{/inline}}` close syntax (alpha.38 lesson). Future template authors copying the examples would have re-hit the same mid-smoke iteration cost. Updated all three to show the correct `{{/full/path}}` close syntax, with an explicit NOTE pointing to the alpha.38 lesson. Doc-comment example keys also updated to reference existing i18n keys (`Elysium.details`, `Elysium.enc`) rather than the previously-fictional `Elysium.gearStats` / `Elysium.encHint`.

### Sweep

- CSS brace balance: 417/417 (alpha.38 was 405/405; +12 new blocks).
- Handlebars block balance: all 11 touched templates balanced (2 new partials + 8 cluster-2 details + allegiance.benefits).
- `node --check`: 11 .mjs files OK (base + 9 sheets + init.mjs).
- `system.json`: parses.
- Token sweep: only `--ely-hp-pct` flagged (unchanged from alpha.38).

### Version

System `1.0.0-alpha.38` → `1.0.0-alpha.39`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

After install, in order:

a. **Gear regression** (cluster-1 validator on hoisted base) — open the existing Smoke Test Gear and Owned Test Gear from alpha.38 smoke. Verify identical behavior: 3-zone header, chips render correctly, tab strip switches Details ↔ Effects, all `name="system.X"` form paths persist. The hoist should be invisible to consumers.

b. **Each of the 6 single-page items**: create one each in the world; open the sheet. Verify:
   - 560×640 width, new 3-zone header, type-appropriate chips.
   - NO tabs strip rendered (visual confirmation single-page mode active).
   - Detail body present with field grid + rows.
   - Description block inline below detail (ProseMirror in edit mode for GMs).
   - GM-notes block inline below description WHEN viewing as GM, with dashed accent border.
   - Wound: effects display inline below detail; `active-effect-change-edit` legacy class hook preserved; click add-effect button creates a change row; trash icon removes; value edits persist.

c. **persTrait + allegiance** (tabbed): open each. Verify tabs strip renders (persTrait: Details / Description / GM Notes; allegiance: Details / Benefits / Description / GM Notes); chips per c2-2 table; itemToggle actions still flip state; allegiance's `isOr`/`isAnd` conditional blocks still gate the allegAllied/allegApoth chain correctly.

d. **22-sheet regression sample**: open weapon, armor, skill, super, arcane, sorcery (a sampling of cluster-3-6 types). Each should render identically to alpha.38 via legacy paths.

e. Console clean across all opens.

After alpha.39 smoke passes: cluster 3 (9 mid-tier types).

---



First of six P10 clusters. Ships the v1.0.0 item-sheet shell scaffold (5 shared shell partials + 4 utility partials) and rebuilds **gear** as the validator against the new scaffold. The other 22 item types are untouched — they continue rendering against their legacy paths, which are kept alive at their old paths so no existing item sheet regresses.

### Audit locks honored

- **audit-1** Shell-first sequencing: cluster 1 ships the shared scaffold + a single validator (gear) before any type-specific detail rebuild.
- **audit-2** Per-item tab decision deferred to per-cluster prep; gear keeps tabs.
- **audit-3** Sheet width: gear bumps from 520×600 to 560×640 (the v1.0.0 baseline). Wide variant 720×720 stays reserved for clusters that will use it (weapon/arcane/etc.).
- **audit-5** Active-effects restyle-only: the legacy `active-effect-change-edit` class hook is PRESERVED on each change row so `ElysiumActiveEffectSheet.activateListeners` keeps binding its click/blur handlers. v1.0.0 styling layers `elysium-effect-change-row` on top. Migration to V14 action handlers stays deferred to P12.
- **audit-6** 3-zone header (image / name+type / chips) shipped as the new design language.
- **c1-1** Header partial usable on single-page sheets (no tabs strip) — confirmed: header always renders, tabs strip is an independent PART.
- **c1-2** Gear's header chips: 3 when owned (Actual ENC, Price, Status), 2 when not (ENC base, Price).
- **c1-3** Sheet-width tokens deferred to P12; cluster 1 uses literal numeric values in `DEFAULT_OPTIONS.position` (Foundry V14 position values are numeric and resolved before any CSS rule applies).
- **c1-4 / c1-5** Hoisting of `_getTabs` / `_preparePartContext` / `_configureRenderOptions` / ProseMirror `enrichHTML` calls into the base sheet — deferred to cluster 2 once we have 2+ data points.

### 9 new shared partials

All registered in `module/hooks/init.mjs:2a` `loadTemplates([...])` with a `P10 cluster 1 (alpha.38)` comment.

Shell partials (5):
- **`templates/item/parts/item-shell-header.hbs`** (~45 lines): 3-zone header (image / name+type / chips). Reads `context.itemHeaderChips = [{label, value?, icon?, tooltip?}, ...]` populated by each sheet class. Empty/absent chips array → chips zone collapses cleanly. Replaces legacy `templates/item/item.header.hbs`.
- **`templates/item/parts/item-shell-tabs.hbs`** (~17 lines): horizontal tab strip with the `tabs` ancestor class required by Foundry V14's `changeTab` selector resolution (alpha.18/alpha.37 lesson). Chip active state uses bare `.active` class so the framework's toggle drives styling automatically (alpha.37 lesson). Replaces legacy `templates/global/parts/tab-navigation.hbs`.
- **`templates/item/parts/item-shell-description.hbs`** (~17 lines): description tab with ProseMirror in editable mode and enriched HTML in read mode. Drops the redundant inline "Description:" label — the tab chip names this content. Replaces legacy `templates/item/item.description.hbs`.
- **`templates/item/parts/item-shell-gmnotes.hbs`** (~17 lines): same shape as description but for `system.gmDescription`. Sheet classes continue to gate the `gmNotes` PART on `game.user.isGM`. Replaces legacy `templates/item/item.gmnotes.hbs`.
- **`templates/item/parts/item-shell-effects.hbs`** (~80 lines): active-effects tab with the legacy class hook `active-effect-change-edit` PRESERVED on each change row (audit-5 lock). The v1.0.0 markup layers `elysium-effect-change-row`, `elysium-effect-change-name`, `elysium-effect-change-value`, `elysium-effect-change-delete`, `elysium-item-effects-add-grid`, etc. on top. JS listeners in `ElysiumActiveEffectSheet.activateListeners` keep firing because they target the legacy class. Replaces legacy `templates/item/item.active-effects.hbs`.

Utility partials (4):
- **`templates/item/parts/item-field-row.hbs`**: label + input/display pair, the most-common pattern across item templates (replaces 172 `skill-display` + 71 `stat-input` legacy refs in aggregate). Uses Handlebars `@partial-block` so callers inject any markup (input, select, prose-mirror, read-only display, etc.).
- **`templates/item/parts/item-field-grid.hbs`**: grid wrapper for grouping field-rows. Defaults to 2-column; caller passes `cols=3` etc. for other layouts.
- **`templates/item/parts/item-chip.hbs`**: small read-only value pill with optional `variant` modifier (`positive`/`negative`/etc.). Replaces legacy `boxed centre` pattern (79 + 147 refs).
- **`templates/item/parts/item-section-card.hbs`**: section card with header + body; aliases the actor-sheet pattern via the existing `tab-section-card-header.hbs` partial from P9.

### `@partial-block` adoption

Cluster 1 is the first cluster anywhere in this rebuild to use Handlebars' `@partial-block` mechanism for content injection into wrapper partials. Verified at smoke-prep time: Foundry V14's bundled Handlebars supports the full-path-as-partial-name form (e.g. `{{#> "systems/elysium/templates/item/parts/item-field-row.hbs"}}...{{/systems/elysium/templates/item/parts/item-field-row.hbs}}`). The closing tag must match the opening path verbatim — `{{/inline}}` does NOT work (Handlebars throws "X doesn't match inline"). The gear detail template uses this pattern in 9 places.

### Gear rebuild

- **`module/item/sheets/gear.mjs`** changes:
  - `DEFAULT_OPTIONS.position` 520×600 → 560×640.
  - All 5 PARTS swapped to the new shell partial paths.
  - `_prepareContext` adds `context.itemHeaderChips` per c1-2 lock — 3 chips when owned, 2 when not. **Chip-value normalization**: numeric values (ENC) are stringified to avoid Handlebars' `{{#if chip.value}}` falsy-checking literal `0` and suppressing the chip-value span; localized labels (`Price`, `Status`) fall back to an em-dash placeholder when the underlying system field is empty (default state on freshly-created items), to avoid `localize("Elysium.")` returning the literal key back.
  - No changes to `_preparePartContext` or `_getTabs` — they still work against the new partials because the partial contracts (context fields, tab activation classes) are identical.
- **`templates/item/gear.detail.hbs`** (39 → 67 lines): rewritten from inline `armor-scores` grid to 2 invocations of `item-field-grid` + 7 invocations of `item-field-row` (4 always-shown + 3 owner-only). All 7 `name="system.X"` form attribute paths preserved verbatim.

### CSS additions

`styles/elysium-sheets.css` 2569 → 2928 (+359 lines, +45 brace pairs). 8 logical sections all scoped to `.application.elysium`:

- Sheet-level tab-content padding (`.elysium-item-tab-content`)
- 3-zone header (image, text block, name, type label, chips zone, chip styling)
- Horizontal tabs strip with `justify-content: flex-start` override for Foundry's `.tabs { justify-content: space-evenly }` framework rule (alpha.37 lesson)
- Field row + field grid utilities (`.elysium-item-field-grid` with `--N-col` modifiers, `.elysium-item-field-row` with right-aligned uppercase label + value column, `.elysium-item-readonly-value` for the centered-value-pill display)
- Item chip utility with `--positive` / `--negative` variants
- Description tab readonly mode
- Effects tab (add grid, effect-change rows preserving legacy class hook, change-row internals, divider, section label, empty-message utility)

All tokens resolve against `elysium-tokens.css`. Only `--ely-hp-pct` flagged in the token sweep (intentional runtime property from cluster 2 of P9).

### Legacy paths preserved

The 22 item types NOT rebuilt in cluster 1 continue to render against their legacy paths:
- `templates/item/item.header.hbs`
- `templates/global/parts/tab-navigation.hbs`
- `templates/item/item.description.hbs`
- `templates/item/item.gmnotes.hbs`
- `templates/item/item.active-effects.hbs`

These files are UNTOUCHED. Each subsequent cluster swaps its item types over to the new shell partials.

### Action handlers — zero new

All 6 item-sheet actions already registered (`onEditImage`, `editBRPid`, `itemToggle`, `addItemEffect`, `openActiveEffect`, `ftAdd`/`ftRemove`). Cluster 1 ships zero new handlers. The `tab` sub-action is native Foundry V14 and continues to work via the framework's delegate.

### Sweep

- CSS brace balance: 405/405 (alpha.37 was 360/360; +45 new blocks).
- Handlebars block balance: all 10 touched templates balanced (9 new partials + gear.detail.hbs).
- `node --check`: init.mjs OK; gear.mjs OK.
- `system.json`: parses.
- Token sweep: only `--ely-hp-pct` flagged.

### Version

System `1.0.0-alpha.37` → `1.0.0-alpha.38`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

After install:

a. Open a Gear item from the items directory (create one if needed).
- Sheet is 560×640 (40px wider than legacy).
- Header shows: image (64×64) on the left; on the right, name input + type label + 2-3 header chips (ENC, Price, and Status if the gear is on an actor).
- Tab strip is horizontal at the top below the header: Details / Effects / Description / GM Notes (last only when GM).
- Click each tab — content swaps, active chip styling toggles via framework's `.active` class.
- Details tab: 2-column grid with ENC, Price, pSCurr, pSMax. If gear is owned by an actor, a second grid below shows Quantity, Actual ENC (read-only), Status.
- All inputs preserve `name="system.X"` paths — change a value, blur, verify it persists via `submitOnChange: true`.
- Effects tab (as GM): add-effect grid renders. Click an add button → new effect change row appears with the legacy `active-effect-change-edit` class. Edit value → persists. Click trash icon → row removes. Listeners fire through preserved legacy class hooks.
- Description tab: ProseMirror renders, edits save.
- GM Notes tab (as GM): same as Description for `system.gmDescription`.
- ElysiumID fingerprint button in the window frame: clickable, opens ElysiumID editor.

b. Open a WEAPON item (cluster-1 NOT rebuilt). Verify it still renders identically to pre-alpha.38 — no regression on the 22 non-rebuilt sheets.

c. Open an ARMOR item — same regression check.

d. Spot-check console clean (no `console.error`) across all opened item sheets.

After alpha.38 smoke passes: cluster 2 (8 simple types).

---



Second and final cluster 5 alpha. Adds the smart-consolidation behavior promised by the P9 prep audit (Q14) and locked again in the cluster 5 audit: when ≥2 magic disciplines are active on an actor, the four discipline gutter chips collapse into a single `Magic` chip whose content surface holds a sub-tab strip (one chip per active discipline) over the currently-active discipline's body. When exactly one discipline is active, the gutter behaves identically to alpha.36 (direct chip). When zero, no magic chip at all. Mutations and Super never participate in consolidation — they remain direct chips regardless of count.

**With alpha.37, P9 is complete: 5 clusters across 8 alphas — `.30 .31 .32 .33 .34 .35 .36 .37`.**

### Audit decisions implemented (cluster 5 alpha B locks)

- **magic-cluster5-1**: Consolidated Magic chip icon = `fa-wand-sparkles`.
- **magic-cluster5-3**: Sub-tab default = alphabetic-first active discipline.
- **magic-cluster5-4**: Consolidated chip tooltip = `Magic — <DisciplineLabel>, <DisciplineLabel>` using the settings-driven labels (`context.arcaneLabel` etc.) of the active disciplines.
- **magic-cluster5-5**: Two-alpha ship sequence — A then B — held to.

### Architectural pattern

- Sub-tab switching uses Foundry V14's native `data-action="tab"` mechanism with a SECOND named tab group, `tabGroups['magic']`, alongside the existing `tabGroups['primary']`. No new action handler registered — the framework writes the group state and re-renders.
- The 4 discipline-body partials from alpha.36 (`magic/arcane-body.hbs`, `magic/divine-body.hbs`, `magic/mysticism-body.hbs`, `magic/sorcery-body.hbs`) are dual-use: single-tradition wrappers (`character.<discipline>.hbs`) and the consolidated wrapper (`character.magic.hbs`) both invoke them. One source of truth per discipline; two consuming surfaces.
- `tabGroups['magic']` persists across re-renders within a sheet instance (same as `tabGroups['primary']`); reopening the sheet resets to the alphabetic default. Foundry doesn't persist tab-group state across sessions and that's acceptable per the audit.

### 2 new templates

- **`templates/actor/character.magic.hbs`** (60 lines): `<section class="actor tab magic ...">` wrapper + sub-tab strip partial invocation + `.elysium-magic-content` container that emits ONE `<section class="tab elysium-magic-discipline" data-group="magic" data-tab="<discipline>">` per active discipline via four explicit `{{#if hasMagic<X>}}` blocks (NOT `{{#each}}`). The section matching `context.magicActiveDiscipline` gets the `active` class; the others stay hidden via Foundry V14's framework rule `section.tab { display: none }` → `section.tab.active { display: block }`. Sub-tab switching is therefore a pure CSS class flip handled by `changeTab` — no PART re-render, no custom action handler. **Critical design choice — no `{{#each}}`**: the discipline-body partials gate their internal locked/unlocked branches on `{{#if system.lock}}` and read top-level context fields like `elysiumArcaneTab.*`. An `{{#each activeMagicDisciplines}}` loop shifts Handlebars context to each iteration value (a string like `'arcane'`), so `system.lock` and the tab-namespaced fields don't resolve and the body silently falls through to the unlocked branch. Keeping per-discipline emissions in explicit if-blocks preserves top-level context throughout, which preserves the dual-use contract: same partial, same context shape, both wrappers. **This mirrors how the PRIMARY tab group works**: every primary tab's content section is in the DOM at all times; `.active` toggles visibility.
- **`templates/actor/parts/magic-subtab-strip.hbs`** (23 lines): `<nav class="tabs elysium-magic-subtabs" data-group="magic">` with one chip per `magicSubTabs` entry. Each chip has `data-action="tab" data-group="magic" data-tab="{{sub.id}}"`. Active chip gets the bare `active` class (NOT a BEM modifier) so Foundry V14's framework toggle — which writes `.active` on the matched chip in `changeTab` — drives the visual state automatically; no PART re-render needed for the chip styling to follow the click. Display-font label + icon. **The `tabs` class on the outer nav is required**: Foundry V14's `changeTab` looks up the chip via `this._content.querySelector('.tabs [data-group="..."][data-tab="..."]')`, so without a `.tabs` ancestor the framework can't find the chip and the click fails with "No matching tab element found." Same lesson as alpha.18 reapplied to the sub-tab group.

Both registered: `character.magic.hbs` as a PART entry (`PARTS.magic`), `magic-subtab-strip.hbs` in `init.mjs:2a` `loadTemplates` array.

### 4 surgical edits to `module/actor/sheets/character.mjs`

1. **`PARTS.magic`** added (template `systems/elysium/templates/actor/character.magic.hbs`, scrollable: `['']`), placed immediately after `PARTS.divine`.
2. **`TAB_ICONS.magic = 'fas fa-wand-sparkles'`** added to the icon map inside `_getTabs`.
3. **`_configureRenderOptions` magic-discipline block rewritten**: the 4 individual `if (this.actor.system.<discipline> != "") options.parts.push('<discipline>')` blocks replaced with a collection step that builds `const activeMagic = []` for arcane / divine / mysticism / sorcery only, then a length-driven push: `length === 1` → that discipline, `length >= 2` → `'magic'`, length 0 → nothing. The active list is stashed as `this._activeMagicDisciplines` so `_getTabs` and `_preparePartContext` can read it. Mutations and Super remain as independent direct chips unchanged.
4. **`_getTabs` switch** gained a `case 'magic'` arm that sets `tab.id = 'magic'`, `tab.label = 'Magic'`, and a tooltip built from the active disciplines' settings-driven labels: `Magic — Arcane, Divine`. Icon from `TAB_ICONS.magic`.
5. **`_preparePartContext` switch** gained a `case 'magic'` arm that: sets `context.tab`; defaults `this.tabGroups['magic']` to `activeMagic[0]` if unset OR if the stored value is stale (discipline no longer active — falls back to alphabetic-first); builds `context.magicSubTabs[]` as `{id, label, icon, active}` per active discipline; sets `context.magicActiveDiscipline` to the currently-active sub-tab id; sets `context.activeMagicDisciplines` to the list; sets four boolean flags `context.hasMagicArcane` / `hasMagicDivine` / `hasMagicMysticism` / `hasMagicSorcery` so the consolidated wrapper can gate each `<section>` emission without an `includes` Handlebars helper while preserving top-level context for the discipline-body partials.

The push order in `_configureRenderOptions` (`arcane → divine → mysticism → sorcery`) is itself alphabetic, so `activeMagic[0]` is naturally the alphabetic-first active discipline. No separate sort step needed.

### CSS additions

`styles/elysium-sheets.css` 2491 → 2564 (+73). Four rule blocks scoped to `.application.elysium`:

- **`.elysium-magic-subtabs`**: horizontal flex strip with `surface-base` background, subtle border, padding, `space-1` chip gap, `space-2` margin-bottom separating the strip from the discipline body. **Explicit `justify-content: flex-start`** to override Foundry V14's framework `.tabs` rule which forces `space-evenly` and would spread the chips across the full content width (same override pattern as alpha.19 used on the primary tab strip).
- **`.elysium-magic-subtab-chip`**: BoucherieBlock display font, uppercase, muted color, transparent background. Hover lifts to `surface-card` bg with `text-body` color.
- **`.elysium-magic-subtab-chip.active`**: `surface-card` bg, `text-decorative` color, `inset 0 -2px 0 0 var(--ely-accent-action)` underline indicator. Active hover doesn't dim — keeps the underline + decorative color stable. Uses the bare `.active` class so Foundry V14's framework `changeTab` toggle drives the styling without a re-render.
- **`.elysium-magic-content`**: flex column with `space-2` gap between the discipline body's section cards.

All tokens resolve against `elysium-tokens.css` (verified pre-flight).

### `init.mjs:2a` registration

`magic-subtab-strip.hbs` added to the `foundry.applications.handlebars.loadTemplates([...])` array, immediately after the alpha.36 super-row/failing-row entries, with a `// Cluster 5 (alpha.37)` comment.

### Action handlers

Zero new action handlers needed — the sub-tab switching is fully native Foundry V14 `tab` action behavior. All 11 magic action handlers from alpha.36 continue to work for whichever discipline body is currently rendered.

### What stays unchanged

- The 4 alpha.36 single-tradition wrappers (`character.arcane.hbs`, `character.divine.hbs`, `character.mysticism.hbs`, `character.sorcery.hbs`) — they continue to be the entry point in the 1-discipline-active case. When ≥2 are active, they're simply not pushed into `options.parts`; the consolidated `magic` wrapper renders instead and invokes the same body partials.
- All 8 alpha.36 partials (the 4 discipline bodies + magic-skill-summary + spell-row + super-row + failing-row).
- Super and Mutations gutter chips (always direct; never consolidated).

### Sweep

- CSS brace balance: 360/360 (alpha.36 was 352/352; +8 new blocks across `.elysium-magic-subtabs`, `.elysium-magic-subtab-chip` + 3 variants, `.elysium-magic-subtab-chip-label`, `.elysium-magic-subtab-chip.active` + hover, `.elysium-magic-content`).
- Handlebars block balance: both new templates balanced.
- `node --check`: `init.mjs` OK; `character.mjs` OK.
- `system.json`: parses.
- Token sweep: only `--ely-hp-pct` flagged (documented runtime property from cluster 2).

### Version

System `1.0.0-alpha.36` → `1.0.0-alpha.37`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

Test setup: current actor has `system.arcane = 'on'` from alpha.36 (Evocation school skill + Firebolt arcane spell). To exercise alpha.37's consolidation, activate a second discipline by adding a divine-tagged skill:

```js
await game.actors.contents[0].createEmbeddedDocuments('Item', [{
  name: 'Channeling',
  type: 'skill',
  system: {
    base: 0, career: 15, culture: 5, personal: 5,
    elysium: { skillCategory: 'magic', skillSubgroup: 'divine' }
  }
}]);
```

The skillSubgroup auto-flips `system.divine = 'on'` via `_prepareCharacterData` in `module/actor/actor.mjs:84-95`.

Then verify:
- **Single-discipline regression**: before the divine skill is added, the gutter shows a direct Arcane chip and the arcane tab renders identically to alpha.36.
- **Consolidation activates**: after the divine skill is added, the gutter loses the per-discipline chips and shows ONE `Magic` chip with `fa-wand-sparkles` icon, tooltip `Magic — Arcane, Divine` (or settings-driven labels).
- **Sub-tab strip renders**: clicking the Magic chip opens a content surface whose first child is the sub-tab strip with 2 chips (Arcane and Divine).
- **Alphabetic default**: arcane sub-tab is active by default.
- **Sub-tab switching**: clicking the Divine sub-tab updates `tabGroups['magic']` and the body switches to the divine-body partial output (Channeling skill / Faith allegiances / divine spells sections).
- **Reversibility**: deleting the Channeling skill reverts to the direct Arcane chip in the gutter.
- **Regression**: all 17 PARTS (16 from alpha.36 + new `magic`) render error-free across the four scenarios (0/1/2/3+ disciplines).

After alpha.37 smoke passes: P9 is complete. Next phase is P10 (item sheet rebuild).

---



First of two cluster 5 alphas. Pure content rebuild + restyle of the 4 magic disciplines (arcane / divine / mysticism / sorcery) plus the super tab. No behavior change in this alpha — multi-discipline characters still see N separate gutter chips, same as today. Smart consolidation lands in alpha B (alpha.37).

### Audit decisions implemented

- **magic-cluster5-1**: Consolidated Magic chip icon = `fa-wand-sparkles` (locked but used in alpha B).
- **magic-cluster5-3**: Sub-tab default = alphabetic (locked but used in alpha B).
- **magic-cluster5-4**: Consolidated chip tooltip lists active disciplines (locked but used in alpha B).
- **magic-cluster5-5**: Two-alpha ship sequence — A then B.
- **Critical mid-ship discovery**: arcane and mysticism BOTH have a second branch when `system.lock === false` — a magic-development grid with editable inputs for spell stat distribution during character creation. Same conservative pattern applied as cluster 4 (statistics tab): **preserve the unlocked dev-grid as-is**, restyle deferred to P12. Filed as a new P12 cleanup item alongside the statistics tab redesign.

### 8 new shared partials

All registered in `module/hooks/init.mjs:2a`:

- **`templates/actor/parts/magic/magic-skill-summary.hbs`**: One casting/school/form/technique/focus/channeling/essence skill row. Reused across all 4 magic disciplines.
- **`templates/actor/parts/magic/spell-row.hbs`**: Generic spell row with parameterised columns (showLevel / showCost / showCastButton / showMemToggle). Used for divine and as a template for discipline-specific overrides.
- **`templates/actor/parts/magic/arcane-body.hbs`**: Full arcane content (schools / forms / techniques / spells / sustains) with the lock-state branch preserved.
- **`templates/actor/parts/magic/divine-body.hbs`**: Channeling skill / Faith allegiances / divine spells.
- **`templates/actor/parts/magic/mysticism-body.hbs`**: Focus skill / mysticism feats with lock-state branch preserved.
- **`templates/actor/parts/magic/sorcery-body.hbs`**: Essence skills / sorcery spells. No lock branch (sorcery doesn't have a dev grid).
- **`templates/actor/parts/super-row.hbs`**: One superpower row.
- **`templates/actor/parts/failing-row.hbs`**: One failing/weakness row.

The 4 discipline-body partials are designed to work BOTH as content for single-tradition tab wrappers AND as nested content in the alpha.37 consolidated wrapper. One source of truth per discipline; two consuming surfaces.

### Revised `tab-section-card-header.hbs`

Added optional `countLabel` parameter so the partial emits a `(N)` count badge next to the title when set. Used heavily by the magic tabs which all have count badges per section. Backward-compatible: omitting `countLabel` skips emission.

### Tab template rebuilds

- **`character.arcane.hbs`** (233 → 5 lines): thin wrapper delegating to arcane-body partial.
- **`character.divine.hbs`** (122 → 5 lines): thin wrapper.
- **`character.mysticism.hbs`** (151 → 5 lines): thin wrapper.
- **`character.sorcery.hbs`** (66 → 5 lines): thin wrapper.
- **`character.super.hbs`** (42 → 53 lines): full rebuild with two section cards (Powers / Failings), using the new super-row and failing-row partials. NOT a thin wrapper because super doesn't participate in consolidation.

Net template line count drops from 614 → 73 (lines moved into shared partials).

### Action handlers preserved

All 11 magic-related action handlers already registered: viewDoc, createDoc, itemToggle, skillRoll, castArcane, castDivine, castMysticism, castSorcery, castCustomSpell, dropSustain, impactRoll. No `.mjs` changes other than the `init.mjs:2a` registration array.

### CSS additions

`styles/elysium-sheets.css` 2141 → 2491 lines (+350). Eleven logical sections:

- Count badge utility (`.elysium-tab-section-card-count`) — also reusable beyond magic.
- Magic skill summary row + improve-checkbox placeholder slot.
- Spell list shared chrome (header + row + cast button + memorise toggle).
- Arcane-specific grid override (7-column wide row).
- Divine faith row with name + sub-title + percentage chip.
- Mysticism-specific grid override (impact-rollable cell included).
- Sorcery-specific grid override.
- Arcane sustained-spells card with bonus-accent left border (visually distinguishing active sustains from static spell entries).
- Empty-message utility for the various "No spells/feats/etc yet" placeholders.
- Super tab row grid.
- Failing row grid.

Token sweep clean except documented `--ely-hp-pct` runtime property.

### Legacy classes retired

Per-tab: `elysium-magic-section`/`elysium-magic-section-header`/`elysium-magic-section-body`/`elysium-magic-section-title`/`elysium-magic-section-count`/`elysium-magic-add`/`elysium-magic-cast-custom`/`elysium-skill-row`/`elysium-cast-btn-inline`/`elysium-sustains`/`elysium-sustain-*`/`elysium-faith-row`/`elysium-faith-title`/`elysium-mysticism-feat-*`/`elysium-divine-spell-*`/`magic-listitem`/`magic-list-header`/`super-listitem`/`failing-listitem`/`sorcery-listitem`/`skill-listitem`/`skill-list`/`item-edit`/`item-name`/`gr-list`/`bold`/`centre`/`truncate`. ~30 distinct legacy class patterns superseded.

The development-grid classes (`stats-list`, `skills-tab-grid`, `skill-cell*`, etc.) are RETAINED on the unlocked branches of arcane and mysticism per the same "preserve until P12 redesign" decision used for the statistics tab.

### Out of scope (deferred to P12)

- Smart consolidation behavior — alpha B (alpha.37) work
- Magic-development-grid restyle (arcane + mysticism unlocked branches) — alongside statistics-tab redesign
- Arcane custom-spell builder internal structure — restyle in-place was the original audit decision; alpha.36 preserves the existing dialog launched via `castCustomSpell` action

### Sweep

- CSS brace balance: 352/352.
- Handlebars block balance: all 14 touched templates balanced.
- `node --check`: init.mjs OK.
- JSON parse: system.json OK.
- Token sweep: only `--ely-hp-pct` flagged.

### Version

System `1.0.0-alpha.35` → `1.0.0-alpha.36`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

Test setup: the current test actor has zero magic disciplines active. Before alpha.36 smoke, enable one tradition (recommend arcane since it's the most complex):

```js
await game.actors.contents[0].update({'system.arcane': 'gold'});
```

Then verify:
- Arcane tab renders 4 section cards when locked (Schools, Forms, Techniques, Arcane spells) plus sustains card if any active sustains.
- Arcane tab renders the dev-grid when `system.lock === false` (legacy chrome preserved).
- Divine / mysticism / sorcery render their respective sections (will need empty-state if no skills/spells of those disciplines yet).
- Super tab renders Powers + Failings cards.
- All cast buttons fire their respective `cast*` actions.
- All viewDoc clicks open item sheets (regression check post alpha.34).
- All 16 PARTS still render error-free.

After alpha.36 smoke passes: alpha.37 (smart consolidation behavior) closes P9.

---

## [1.0.0-alpha.35] — P9 cluster 4: background tab rebuild (statistics deferred to P12)

Cluster 4 ships as background-only per the cluster 4 audit recommendation D. The statistics-tab retirement that was originally planned for this cluster is deferred to P12 because the legacy statistics tab is much richer than the P9 prep audit anticipated — it's the primary editing surface for character creation (base + culture inputs per stat), not the "drill-down view" the audit described. Folding it correctly needs a deliberate design pass with mockups, not a mid-ship pivot.

### Audit decision

- **Main question**: option D locked — defer statistics retirement to P12. Cluster 4 = background-only. Legacy statistics template continues to render against legacy CSS until P12 polish phase.
- **background-cluster4-1**: `addNewSection` and related bio handlers are wired via inline class-based listeners in `character.mjs:1063-1066`, NOT V14 action handlers. The legacy template's `data-action="storyUp"/storyDown"/storyDelete"` attributes are dead-wired (they were dead in legacy too — never registered). Pragmatic decision: alpha.35 PRESERVES the legacy class names (`bio-section`, `bio-section-title`, `bio-section-value`, `addNewSection`, `move-section-up`, `move-section-down`, `delete-section`) on the rebuilt markup so all existing behavior keeps working. v1.0.0 classes are LAYERED on for styling. Migrating bio CRUD to V14 action handlers is filed as a P12 cleanup item.
- **background-cluster4-2**: ProseMirror toolbar kept as Foundry default. Restyling the toolbar component is out of scope.

### Single new shared partial

- **`story-section.hbs`**: encapsulates one story section. Title row (input when editable, plain text when locked) + body (ProseMirror when editable, enriched HTML otherwise) + reorder/delete controls (omitted on first/last as appropriate). Retains all legacy class names alongside new v1.0.0 classes — this is intentional and documented in the partial header.

Registered in `module/hooks/init.mjs:2a` `loadTemplates` array.

### Tab rebuild

- **`character.background.hbs`** (31 → 24 lines): outer section with an "Add Section" button (when unlocked) and a `.elysium-story-list` flex column of story-section partial invocations. Iterator-supplied `index` passed explicitly to each partial so the partial's nested context has access to it (Handlebars partials don't inherit `@index` automatically).

### CSS additions

`styles/elysium-sheets.css` 1996 → 2141 lines (+145). Six logical rule blocks:

- **`.elysium-story-add-wrap` / `.elysium-story-add-btn`**: top-of-tab Add Section button with plus icon, accent-action hover state.
- **`.elysium-story-list`**: flex column container with section gap.
- **`.elysium-story-section`**: card chrome (surface-card bg, subtle border, radius-2, padded).
- **`.elysium-story-section-header`**: title-row layout with header divider.
- **`.elysium-story-section-title` + `.elysium-story-section-title-input`**: display vs editable title treatment — display title uses BoucherieBlock display font in bone color; editable input has focus state with accent-action border.
- **`.elysium-story-section-controls`** + control-btn: reorder + delete buttons; delete hover uses `--ely-accent-danger` for clear destructive affordance.
- **`.elysium-story-section-body`**: ProseMirror container chrome (surface-base bg, subtle border, min-height 100px on the prose-mirror element).

All scoped to `.application.elysium`. Token sweep clean except documented `--ely-hp-pct` runtime property.

### Legacy classes retired (visual only — kept on markup for behavior)

`bio-control`, `bio-section`, `bio-section-value`, `bio-section-title`, `section-header`, `story-subtitle`, `flexrow-elysium`, `header-buttons`, `move-section-up`, `move-section-down`, `delete-section`, `story`, `addNewSection`. **These classes are RETAINED on the rebuilt markup** because the form handler and inline click listeners depend on them, but they no longer drive any visual styling — the v1.0.0 classes take over.

### Out of scope (deferred to P12)

- Bio CRUD migration to V14 action handlers (low-risk cleanup; preserves alpha.35 ship velocity)
- Statistics tab rebuild (the larger, design-first decision)
- ProseMirror toolbar restyling

### Sweep

- CSS brace balance: 298/298.
- Handlebars block balance: both touched templates balanced.
- `node --check`: init.mjs OK.
- JSON parse: system.json OK.
- Token sweep: only `--ely-hp-pct` flagged (intentional).

### Version

System `1.0.0-alpha.34` → `1.0.0-alpha.35`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

Background tab is a high-risk smoke surface per side finding #5 — TWO ProseMirror editors per section + Foundry's prose-mirror toolbar can wedge the bridge. Offline-render only:

- Background tab renders with N section cards (matching `actor.system.stories.length`).
- Add Section button is present when sheet editable, absent when locked.
- Section header shows title input when editable, plain title when locked.
- First section omits "move up" control; last section omits "move down" control.
- All legacy classes still present on markup (form handler + listener compatibility check).
- v1.0.0 classes layered on top.

Action-handler smoke per the alpha.33/.34 lesson:
- `addNewSection` click → invokes `createBioSection` → adds new `{title:'', value:null}` entry to `actor.system.stories[]`.
- `move-section-up`/`down` listeners attached when section count > 1.
- `delete-section` dblclick listeners attached.

After cluster 4 closes: cluster 5 (magic family + smart consolidation) is the final P9 cluster.

---

## [1.0.0-alpha.34] — Two-issue hotfix from alpha.33 user-reported smoke

User reported two issues post-alpha.33 install:

1. **Armor sheet wouldn't open from items tab** — console warning `Could not find document class` at `base-actor-sheet.mjs:534`.
2. **Defenses card grew unboundedly on vertical window expand**, pushing the Rest button past the visible card area.

### Issue 1 — Buried viewDoc / deleteDoc bug

Same root cause as the alpha.33 `_onItemToggle` fix, but in `_getEmbeddedDocument`. The legacy lookup used `target.closest('li[data-document-class]')` because every legacy row was `<li class="item">`. All v1.0.0 row partials use `<div data-item-id data-document-class>` instead. The `closest('li[...]')` selector returned null, the fallback `docRow = target` aimed at the anchor element which has no `data-document-class`, and the code fell through to the `console.warn('Could not find document class')` branch.

This silently broke **every** `viewDoc` and `deleteDoc` click on the new row partials, across clusters 1, 2, and 3. The bug was latent through three ships because structural smoke verified markup presence but not click behavior. User noticed when actually trying to open an armor sheet.

**Fix**: widen the lookup to `target.closest('[data-document-class]')`. Compatible with both legacy `<li class="item" data-document-class>` and new `<div data-document-class>` rows. One-line change.

Surfaces unblocked by this fix:
- **Cluster 1**: viewDoc on mutations, dev improve-list items
- **Cluster 2**: viewDoc on weapons, hit-locations, wounds (already worked because hit-location-row.hbs uses an explicit `data-item-id` on the row div, and `_viewWound` uses a separate path — but `_viewDoc` was broken on weapon names)
- **Cluster 3**: viewDoc on armor, gear, allegiances, reputations, passions, pers-traits — all the surfaces the user actually clicked
- **Defenses card armor layers**: the `<a class="elysium-armor-layer-name" data-action="viewDoc" data-item-id="..." data-document-class="Item">` inside the right-rail-defenses partial — also broken since P8 alpha.14, technically, but invisible until armor was present on the actor

### Issue 2 — Defenses card unbounded height

The defenses-card lives in `grid-column: 3 / 4` of the right rail with auto-flow rows. Its hit-location list (`.elysium-hitloc-list`) was a flex column with no height constraint, so it grew to fit all hit-locations naturally. On window expand, the card consumed the new vertical space, dragging the Rest button down with it — and on character sheets with 7+ hit-locations, the Rest button could end up below the visible card area entirely.

**Fix**: cap `.elysium-hitloc-list` with `min-height: 80px; max-height: 320px; overflow-y: auto`. The list now scrolls internally past ~320px instead of pushing the Rest button. min-height keeps the list usable on short windows.

This is a per-card height cap rather than a deeper grid restructure because the right rail's grid is shared by 4 cards (defenses + conditions + senses + effects); imposing a global rail-height constraint would require markup changes (a wrapping `.elysium-right-rail` element). The 320px cap solves the immediate complaint without touching the rail structure. If future cards develop similar growth issues, the wrapping-rail refactor becomes worth it.

### Files touched

- `module/actor/sheets/base-actor-sheet.mjs` — one method updated (`_getEmbeddedDocument`)
- `styles/elysium-sheets.css` — one rule updated (`.elysium-hitloc-list`)

### Sweep

- `node --check`: OK.
- CSS brace balance: 281/281.
- `system.json` parses.

### Version

System `1.0.0-alpha.33` → `1.0.0-alpha.34`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

- Click any armor / gear / weapon / allegiance / passion / persTrait name → its item sheet should now open.
- Expand the character sheet window vertically → the Rest button stays at the bottom of the defenses card; the hit-location list scrolls internally if it exceeds ~320px of content.

---

## [1.0.0-alpha.33] — P9 cluster 3: items + social + pers tabs + coinage tracker + itemToggle hotfix

Three tabs rebuilt in a single coordinated ship per the cluster 3 audit. Plus a small DataModel addition for the coinage tracker, plus a buried bug fix that has been blocking cluster 2 since alpha.32 (caught during cluster 3 partial design).

### Audit decisions implemented

Prep audit (`docs/p9-cluster3-audit.md`) plus user direction:

1. **items-cluster3-1 (revised)**: Coinage tracker as a small card at the top of items tab with PP/GP/SP/CP number inputs. Backed by new `system.coins.{pp,gp,sp,cp}` DataModel fields. Visible on both character and NPC sheets per user direction.
2. **items-cluster3-2**: Armor group expand/collapse preserves `hitloc.system.hide` write semantics. No schema churn, matches no-migration project rule.
3. **pers-cluster3-1**: Side-by-side chips restyled (option B). The scale-bar option (A) was deferred per user "unsure" feedback; can be revisited as a P12 polish iteration without disrupting data shape.
4. **pers-cluster3-2**: Dissolved by choosing option B (only applied if option A was picked).
5. **social-cluster3-1**: Opposed-allegiance name inline when set, hidden when empty.

### DataModel additions

`system.coins` SchemaField added bit-identically to **both** `CharacterDataModel` and `NPCDataModel`. Top-level (not under the `system.elysium.*` partition) because coins are generic TTRPG state, not Elysium-fork-specific. Four `NumberField({integer:true, initial:0, min:0})` for pp/gp/sp/cp.

Both DataModels declare the field in the shared "base" section right next to `wealthValue`, matching the "bit-identical 11 base-template fields" pattern from P5.

Fresh-world rule applies: existing actors will get `system.coins` initialized to `{pp:0, gp:0, sp:0, cp:0}` on first sheet open via DataModel default-value merging. No migration code; per project rule.

### Buried `itemToggle` bug uncovered + fixed

While designing the `improve-checkbox.hbs` partial for cluster 3, discovered that `_onItemToggle` in `base-actor-sheet.mjs:452` uses `target.closest("li")` to find the parent item. This worked in legacy because every row was `<li class="item">`. But cluster 2's rebuilt weapon-row, hit-location-row, etc. all use `<div data-item-id="...">` instead — so the `closest("li")` lookup returned null and `_onItemToggle` would silently no-op on:

- Combat tab weapon equip toggle (`itemToggle` with `data-property="equipStatus"`)
- Hit-location dead/severed/unconscious status flips
- Items tab armor + gear equip toggles
- Social/pers improve checkboxes (cluster 3)

Cluster 2's smoke verified the markup was present but didn't click-test, so the bug shipped silent. **Fix**: widen the lookup to `target.closest("[data-item-id]")`. Compatible with both legacy `<li>` rows and new `<div>` rows. One line change. Side benefit: cluster 2's equip toggle starts working alongside cluster 3.

### New shared partials (8)

All registered in `module/hooks/init.mjs:2a` `loadTemplates` array:

- **`coinage-card.hbs`** — 4-cell grid of PP/GP/SP/CP labeled inputs. Color-coded labels (platinum bright-white, gold accent-bonus, silver muted-grey, copper subtle-bronze). Caller provides card chrome; this partial is just the inner grid.
- **`armor-group-header.hbs`** — Per-hit-loc group header showing location name + summary AV/PP/enc/skillmod cells + expand/collapse chevron. Toggle writes `hitloc.system.hide` via `armorLocToggle`.
- **`armor-row.hbs`** — Per-armor row with name + AV + ppCurr/ppMax store + pSCurr/pSMax store + encumbrance + slash-delimited skillmod quad + hit-loc name + equip toggle.
- **`gear-row.hbs`** — Name (with optional sparkle for hasEffects) + quantity input + encumbrance + PP store + equip toggle.
- **`allegiance-row.hbs`** — Name + optional title sub-line + total% + rank chip + enemy skull marker + opposed-allegiance inline-when-set + improve checkbox.
- **`reputation-row.hbs`** — Name + total% (rollable when locked, editable base input when unlocked).
- **`passion-row.hbs`** — Name + total% + improve checkbox. Deferred from cluster 1 per the alpha.30 scope tightening.
- **`pers-trait-row.hbs`** — Side-by-side opposed-pair: [improve] name + total% chip | balance icon | opposed total% chip + opposed name [opp improve]. Option B layout per audit.

### Revised `improve-checkbox.hbs`

Added `property` parameter so the partial emits `data-property="improve"` (or `oppimprove`, etc.) for the `itemToggle` handler to read. Without this, the handler couldn't tell which boolean to flip. Backward-compatible: omitting `property` skips emission (suitable for skill/stat-specific handlers that don't use the item-property mechanism).

### Tab rebuilds

- **`character.items.hbs`** (127 → 95 lines): three section cards (Coinage / Armor / Gear). Armor card preserves the hit-loc-grouped interleaved-list pattern: iterates `armors[]`, dispatches by `system.list` (0 → group header, 1 → per-armor row). Per-armor rows respect `system.hide` (set transiently in context-prep from the parent hit-loc's hide flag).
- **`character.social.hbs`** (62 → 51 lines): two section cards (Allegiances always-on, Reputations gated on `useReputation > 0` setting).
- **`character.pers.hbs`** (54 → 47 lines): two section cards (Personality Traits, Passions). `passions[]` is `passionsGeneral` (arcane filtered out by context-prep, surfaced on the arcane tab in cluster 5).

### Action handlers preserved

5 distinct actions across the three tabs, all already registered:
- viewDoc, createDoc, itemToggle (universal)
- armorLocToggle (items group toggle)
- allegianceRoll, reputationRoll, passionRoll, personalityRoll

### CSS additions

`styles/elysium-sheets.css` 1597 → 1996 lines (+399). 7 logical sections of new rules:

- **Coinage card**: 4-column grid with color-coded tier labels.
- **Armor group header + per-armor row**: 2-tier grid with shared visual language.
- **Gear row**: 5-column grid with quantity input.
- **Allegiance row**: 4-column grid (identity / total / meta / improve).
- **Reputation row**: 2-column grid.
- **Passion row**: 3-column grid (mirrors allegiance simplified).
- **Pers-trait row**: 5-column grid with side-by-side chip layout (option B).
- **`.elysium-row-subtitle` utility**: small muted sub-line for "name + sub-line" patterns. Used by allegiance title; reusable in clusters 4–5.

All scoped to `.application.elysium`. Pre-flight token check: every `--ely-*` reference resolves except the documented runtime input `--ely-hp-pct` (carried from cluster 2).

### Legacy classes retired

~62 distinct legacy classes across the three tabs no longer have markup consumers: `armor-tab-grid`, `gear-tab-grid`, `magic-listitem`, `trait-listitem`, `passion-name`, `persTrait-name`, `allegiance-name`, `new-row`, `bold`, `darkred`, `right`, `truncate`, etc.

### Sweep results

- **CSS brace balance**: 281/281.
- **Handlebars block balance**: all 12 touched templates balanced.
- **`node --check`**: 4 modified .mjs files pass (init.mjs, character.mjs DataModel, npc.mjs DataModel, base-actor-sheet.mjs).
- **JSON parse**: system.json OK.
- **Token sweep**: only `--ely-hp-pct` flagged (intentional, carried from cluster 2).

### Version

System `1.0.0-alpha.32` → `1.0.0-alpha.33`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

Offline-render pattern (default since alpha.31):

- **Items tab**: 3 section cards (Coinage, Armor, Gear). Coinage grid renders 4 labeled inputs. Armor card renders hit-loc group headers + per-armor rows respecting collapse state. Gear card renders flat list with quantity inputs.
- **Social tab**: 2 cards (Allegiances always present, Reputations only when `useReputation > 0`). Allegiance rows show name + title sub-line (when set) + total + rank chip + enemy marker (when flag set) + opposed name (when set) + improve.
- **Pers tab**: 2 cards (Personality Traits, Passions). Trait rows show side-by-side opposed-pair chips; passion rows show name + total + improve.
- **Coinage data binding**: changing input value updates `system.coins.pp/gp/sp/cp` and survives a reload.
- **itemToggle hotfix verification**: clicking an equip toggle on a weapon (cluster 2 surface) actually flips the equipStatus now (was silent-failing pre-alpha.33).
- **Regression**: all 16 PARTS still render with no errors. Cluster 1 + cluster 2 surfaces untouched and stable.
- **DataModel**: opening an existing character on first alpha.33 install should initialize `system.coins` to `{0,0,0,0}` without console errors.

If smoke passes, cluster 4 (background + statistics drill-down) opens. Cluster 5 (magic family + smart consolidation) follows.

---

## [1.0.0-alpha.32] — P9 cluster 2: combat tab rebuild

Combat tab rebuilt against the new design language. Three section cards stacked (Weapons / Hit Locations / Healing Actions), five new shared partials, ~366 lines of new CSS.

### Approach

Prep audit (`docs/p9-cluster2-audit.md`) shipped separately and locked the 5 design decisions. This alpha implements those decisions:

1. Drop the planned "Active Wounds" detail card (audit revision over original combat-2 lock) — wounds carry no narrative metadata, so the inline badges convey everything; treatment reachable via existing badge click → viewWound handler.
2. Auto-expand weapons with PP store, item HP, or ammo > 0 on first render (server-side `--auto-expanded` class on row; client-side toggle deferred).
3. HP progress bar with 2-tier threshold: gold ≥50%, crimson <50%.
4. Untreated wound pulse animation, 2-second cycle, wrapped in `@media (prefers-reduced-motion: no-preference)`.
5. `hasEffects` weapons get a sparkle icon (`fa-sparkles` in `--ely-accent-bonus` gold) next to the name, replacing the legacy bold-italic name treatment.

### New shared partials in `templates/actor/parts/`

All five registered in `module/hooks/init.mjs:2a` `loadTemplates` array per the alpha.31 lesson:

- **`weapon-row.hbs`** — Primary 8-column row + expandable 5-column detail sub-row. Auto-expands when `pSMax`, `hp`, or `ammo` > 0 via the `--auto-expanded` modifier. Equip toggle gets pill background when status is `'equipped'`.
- **`hit-location-row.hbs`** — Per-location row with add-wound button, name, range chip, HP progress, AP value (rollable when `useAVRand`), status icons (dead/severed/unconscious), inline wound badges. General-type locations (`locType=='general'`) render as a centered subheader strip with name only.
- **`wound-badge.hbs`** — Crimson chip showing wound severity. Untreated wounds get `--untreated` modifier for pulse animation.
- **`chip-range.hbs`** — Renders "1–3" or "11" (collapses when low==high), or nothing when low is null/0. Generic; reusable for damage range, spell range in cluster 5.
- **`hp-progress.hbs`** — Mini progress bar with overlaid `N/M` label. Fill color switches gold→crimson at 50%. Takes pre-computed `pct` argument (caller uses `percentOf` helper) because partial-invocation can't compute it inline easily without a wrapping helper.

### Tab rebuild

`character.combat.hbs` (160 → 113 lines): three section cards using the cluster 1 scaffold. Weapons section has the add-button via `tab-section-card-header.hbs`; hit locations card has no add button (hit locations come from ancestry drop, not user-created via this tab); healing card uses two `.button-primary` chips (reusing the existing `button-primary` rule from `elysium-components.css`).

Each row uses the five shared partials; the parent template is now thin orchestration only.

Action handlers preserved: `viewDoc`, `createDoc`, `weaponRoll`, `damageRoll`, `armorRoll`, `addDamage`, `viewWound`, `healing`, `itemToggle`. Verified all 9 exist in `base-actor-sheet.mjs:DEFAULT_OPTIONS.actions`. **No `.mjs` changes for combat tab itself**; only the `init.mjs:2a` array gained 5 new lines for partial registration.

### Legacy classes retired in combat tab

27 distinct legacy classes from `css/legacy.css`: `weapon-tab-grid`, `hitloc-tab-grid`, `gr-list`, `diff-label`, `centre`, `font14`, `weapon-name`, `damage-name`, `combat-input-small`, `hitloc-name`, `wound-name`, `wound-item`, `untreated`, `mediumIcon`, `largeIcon`, `item-control`, `rollable`, `inline-edit`, `italics`, `bold`, and several others. Net effect on `legacy.css` retirement readiness: cluster 2 eliminates roughly 35–40 legacy rule blocks from active use (final count comes at P9 close).

### CSS additions

`styles/elysium-sheets.css` 1231 → 1597 lines (+366). New rule blocks:

- **Weapon row** (12 rules): row container, equipped modifier, primary grid header + body, name + sparkle decoration, generic cells, equip-toggle with pill state, expand toggle with auto-expanded rotation, detail sub-row (display:none → grid via modifier), detail cells with label/value/max trio, inline-edit input chrome.
- **Hit-location row** (9 rules): row container, general-type subheader variant, add-wound button, name, ap/range/status/wounds container groupings, status-flag icon.
- **Chip-range variant** (1 rule): tabular-nums override + slightly different border/background to distinguish from generic chips.
- **HP progress bar** (5 rules): container with overflow:hidden, fill driven by `--ely-hp-pct` custom property, --low modifier swaps fill color, label with z-index overlay + text-shadow for contrast over the fill, empty-state dash.
- **Wound badge** (3 rules): pill chip with crimson-subtle bg, hover scale, untreated pulse animation inside `@media (prefers-reduced-motion: no-preference)` per cluster 2 audit decision.
- **Healing actions** (3 rules): horizontal row container, button wrapper, larger icon size override.

All new rules scoped to `.application.elysium`. Reuse: existing `.button-primary` from `elysium-components.css` for healing-action chips (no redefinition).

### Token audit

Pre-flight check passed. Every `--ely-*` reference in the new CSS resolves against `elysium-tokens.css` definitions. One non-resolution flagged by the sweep: `--ely-hp-pct` — this is intentional, it's a CSS custom property set inline via the `style="--ely-hp-pct: {{pct}}%;"` attribute on each `.elysium-hp-progress` element (used as the fill width). Not a token-table token; runtime input. Documented as a non-issue.

### Sweep results

- **CSS brace balance**: 214/214 open/close.
- **Handlebars block balance**: all 6 touched templates clean (#each, #if, #unless paired correctly).
- **`node --check module/hooks/init.mjs`**: OK.
- **`system.json` parse**: OK.
- **All action handlers exist**: verified against `base-actor-sheet.mjs`.
- **All required data context fields exist**: verified against `character.mjs:_prepareContext`.

### Version

System `1.0.0-alpha.31` → `1.0.0-alpha.32`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

Offline-render pattern (the alpha.31 working approach):
- Combat part renders without partial-lookup errors → all 5 new partials registered.
- Weapons card shows N weapon rows (matches actor's weapon count); each row has a name + chance + damage + range + attacks + hands + equip toggle + expand toggle.
- Hit-locations card shows N rows; each has add-wound button + name + range chip + HP bar + AP value + status block + wounds block.
- Healing card shows two action chips.
- Legacy classes (`.weapon-tab-grid`, `.hitloc-tab-grid`, `.gr-list`, etc.) return 0 in combat-tab HTML.
- Stat tile improve checkboxes still render correctly (no class-name regression).
- All other tab parts still render (no cross-tab class bleed).

Optional live-render check (post-structural-smoke): wound pulse animation visible on untreated wound; HP fill bar fills with gold at full HP, transitions to crimson below 50%; sparkle icon appears next to weapon name when `hasEffects=true`.

If smoke passes, P9 cluster 3 (items + social + pers) opens. If anything regresses, fix-forward on alpha.33.

---

## [1.0.0-alpha.31] — Hotfix to alpha.30: register shared partials at init

Live smoke against alpha.30 caught a render-blocking bug on the mutations tab:

```
Failed to render Application "ElysiumCharacterSheet-Actor-...":
Failed to render template part "mutations":
The partial systems/elysium/templates/actor/parts/tab-section-card-header.hbs could not be found
```

### Diagnosis

Bridge introspection of `Handlebars.partials` showed that Foundry V14's ApplicationV2 auto-registers a Handlebars partial for every template referenced in a sheet's static `PARTS = {...}` block (one of the framework's nice-but-undocumented behaviors). The 9 P8 shell parts plus the 13 P9 tab content templates were all registered. The 3 new SHARED sub-partials introduced in alpha.30 (`tab-section-card-header.hbs`, `improve-checkbox.hbs`, `section-card-header-button.hbs`) are NOT in PARTS — they're invoked via `{{> "..."}}` from inside the tab templates — so Foundry never auto-registers them, so the partial lookup fails at first render.

This is the lesson cluster 1 was meant to surface: the scaffold pattern requires explicit registration. Cost: one hotfix.

### Fix

Added a new section 2a to `module/hooks/init.mjs`, right after `registerSettings()` and `handlebarsHelper()`. Calls `foundry.applications.handlebars.loadTemplates([...])` with the three shared partial paths. Fire-and-forget (no await) — `loadTemplates` resolves well before any sheet render in normal Foundry boot order (init → ready → user opens sheet), and a `.catch` surfaces any registration errors to the console rather than swallowing them.

Future shared partials introduced in P9 cluster 2+ get added to this array.

### Why this is correct (vs alternatives)

- **Inlining the card-header markup into each tab** would have worked but defeats the audit's shared-sub-component plan (cluster 2+ will have 5+ more shared partials).
- **Adding the partials to `PARTS`** is wrong — `PARTS` are top-level render parts, each becomes a `<section data-application-part="...">` in the rendered DOM. Spurious empty render parts would result.
- **`Handlebars.registerPartial` directly** works but requires also fetching the template file first; `loadTemplates` does fetch + compile + register in one call.

### Version

System `1.0.0-alpha.30` → `1.0.0-alpha.31`. Compendium unchanged at `1.0.0-alpha.3`.

### Files touched

- `module/hooks/init.mjs` — added section 2a (21 new lines + comment block)
- `system.json` — version bump only

No template or CSS changes from alpha.30. Three new shared partials and two rebuilt tab templates stay as alpha.30 shipped them.

### Sweep

- `node --check module/hooks/init.mjs`: OK
- `system.json` parses: OK

### Smoke required at install

Re-run the alpha.30 smoke list (mutations + dev tab render + check) — this time without the partial-lookup error blocking the render.

---

## [1.0.0-alpha.30] — P9 cluster 1: shared scaffold + mutations + dev tab rebuild

P9 opens. Cluster 1 of the rebuild plan: establish the shared tab-content scaffold and validate it against the two smallest tabs (mutations, dev). Also opportunistic cleanup of three orphaned legacy partials.

### Approach

Prep audit (`docs/p9-prep-audit.md`) shipped separately and locked the cluster sequencing + 12 design decisions. This alpha implements cluster 1 of that plan against the locked decisions.

Per the audit's NPC adaptation pattern (decision Q4), every new shared partial includes an "NPC adaptation note" in its file-level comment documenting what an NPC sheet would need to differ; no NPC code in this ship.

### New shared partials in `templates/actor/parts/`

- **`tab-section-card-header.hbs`** — Reusable header chrome for tab-content section cards. Mirrors the existing `.elysium-rail-card-header` pattern. Renders title + optional add-button. Used by mutations + dev in this ship; will be used by every cluster 2+ tab.
- **`improve-checkbox.hbs`** — Generic 18×18 square improve toggle. Distinct from the existing `.elysium-stat-tile-improve` (which is wired to header stat tiles); this partial is for skills, passions, traits, allegiances, etc. NPC adaptation note: pass `editable=false` for read-only render.
- **`section-card-header-button.hbs`** — Generic icon button for section-card headers when multiple buttons are needed (sort + filter + add) or when the button needs custom data-* attributes beyond what `tab-section-card-header.hbs` provides. Not consumed in this ship; ready for cluster 2 (combat sort controls, items filter).

Note: `item-row-passion.hbs` was listed in the audit's cluster 1 scope but **deferred to cluster 3** (pers ship) where it gets immediately validated against a real consuming tab. Shipping a row partial in cluster 1 without a consumer would leave it untested at smoke time.

### Tab rebuilds

- **`character.mutations.hbs`** (21 → 47 lines) — Rebuilt against the new scaffold. One section card holding the mutations list; each row uses `.elysium-mutation-row` grid layout with name + adv/dis chip + minor/major chip. Add-button in card header via `tab-section-card-header.hbs`. Actions preserved: `viewDoc`, `createDoc`. No data-model changes; consumes existing `context.mutations[]` and `context.mutationLabel`.

- **`character.dev.hbs`** (41 → 95 lines) — Rebuilt against the new scaffold. Two section cards: "All-items batch controls" (the wide grid with fixed/formula XP roll buttons + conditional POW improve buttons) and "Per-item improvement" (the list of items marked for improvement). Each `.elysium-dev-row` shows name + type + score + per-item XP roll buttons. Actions preserved: `xpRolls`, `powImprove`, `viewDoc`. Tab remains gated on the `development` setting per existing `_configureRenderOptions` logic; no change to gating.

The legacy class system being retired in these two tabs: `magic-list`, `mutation-listitem`, `gr-list`, `dev-header`, `dev-list`, `dev-listitem`, `diff-label`, `item`, `item-edit`, `item-control`, `rollable`, `centre`, `improvtab`, `largeIcon`, `left`. Replaced with `.elysium-tab-section-card-*`, `.elysium-mutation-row*`, `.elysium-dev-row*`, `.elysium-dev-header-bar`, `.elysium-dev-action`, `.elysium-field-label`, `.elysium-rollable`, `.elysium-chip*`. Roughly 15 legacy classes eliminated from these two tabs.

### Deleted orphaned legacy partials

Pre-flight grep confirmed zero live references (no `{{> ...}}` includes, no `loadTemplates` paths, no `system.json` references) for all three:

- **`templates/actor/character.skills.hbs`** (293 lines) — superseded by `parts/left-rail-skills.hbs` since P8 alpha.14.
- **`templates/actor/character.header.hbs`** (303 lines) — superseded by `parts/header-card.hbs` since P8 alpha.14.
- **`templates/actor/character.effects.hbs`** (27 lines) — superseded by `parts/right-rail-effects.hbs` since P8 alpha.14.

Net: 623 lines of dead template code retired.

### CSS additions

`styles/elysium-sheets.css` 957 → 1231 lines (+274). New rule blocks (16 total):

- **Tab section card chrome** (5 rules): `.elysium-tab-section-card`, `.elysium-tab-section-card-header`, `.elysium-tab-section-card-title`, `.elysium-tab-section-card-action` (+ hover), `.elysium-tab-section-card-body`.
- **Generic item-row foundation** (3 rules): `.elysium-item-row` (+ hover), `.elysium-item-row-name`, `.elysium-item-row-cell`. Cluster 2+ tabs will decorate this with per-variant rules.
- **`.elysium-rollable` decorator** (2 rules including hover) — hover affordance for clickable name cells. Replaces `.rollable` from legacy.css.
- **Generic improve checkbox** (3 rules): `.elysium-improve-checkbox` (+ hover, readonly variant). Distinct from `.elysium-stat-tile-improve` because layout contexts differ.
- **Mutations tab specifics** (2 rules): `.elysium-mutation-row` (+ hover), `.elysium-mutation-row-name` (+ hover).
- **Chip pattern** (3 rules): `.elysium-chip` base + `.elysium-chip--positive` + `.elysium-chip--negative`. Used in mutations for adv/dis and minor/major; will be reused in cluster 2+ for weapon range, spell school, etc.
- **Dev tab specifics** (4 rules): `.elysium-dev-header-bar`, `.elysium-dev-row` (+ hover), `.elysium-dev-row-name` (+ hover), `.elysium-dev-row-cell`, `.elysium-dev-action` (+ hover).
- **`.elysium-field-label`** — generic small-uppercase-muted column-header label for batch-control grids. Distinct from `.elysium-tab-section-card-title` because these are sub-row labels, not card titles.

All new rules scoped to `.application.elysium` per project markup convention.

### Token audit

Every `--ely-*` reference in `elysium-sheets.css` resolved against `elysium-tokens.css` definitions. Three tokens flagged during audit and corrected before ship:
- `--ely-text-primary` → `--ely-text-body` (12 references)
- `--ely-text-secondary` → `--ely-text-body-strong` (6 references)
- `--ely-accent-malus` → `--ely-accent-danger` (3 references, mutations dis-chip + chip base)

### Sweep results

- **CSS brace balance**: 160/160 open/close.
- **System.json parse**: OK.
- **Templates rendered without errors**: TO VERIFY in live smoke. Pre-ship sanity: handlebars-style syntax balanced, every `{{#each}}` has `{{/each}}`, every `{{#if}}` has `{{/if}}`, every `<section>` has `</section>`.
- **No `.mjs` changes** in this ship; no `node --check` needed.
- **Orphan-reference grep**: zero matches for the three deleted partials anywhere in source.

### Version

System `1.0.0-alpha.29` → `1.0.0-alpha.30`. Compendium unchanged at `1.0.0-alpha.3`.

### Smoke required at install

- Mutations tab: with a character that has mutations (compendium has 20 mutations in the mutations pack — drop one onto a test character). Confirm: card renders, each mutation row shows name + adv/dis chip + major/minor chip, click name opens item sheet, add-button opens createDoc dialog.
- Dev tab (only visible when `development` setting is on): confirm both section cards render, fixed/formula buttons fire `xpRolls`, POW improve buttons appear only when `stats.pow.improve` is true.
- All other tabs (combat, items, social, pers, statistics, background, arcane/divine/mysticism/sorcery/super if active): confirm they still render against their legacy templates without regression (they're untouched in this ship; verifying no cross-tab CSS leak from the new rules).
- Header card stat tiles: confirm `.elysium-stat-tile-improve` checkboxes still render (new `.elysium-improve-checkbox` rule shouldn't bleed into them since the class names are distinct).
- Resize handle: still functional.

If smoke pass, P9 cluster 2 (combat tab rebuild) opens. If any regression, fix-forward on alpha.31.

---

## [1.0.0-alpha.29] — Improve checkbox: empty box when unchecked (no FA square icon)

User feedback: the improve checkbox shows a square-within-a-square because the template rendered `<i class="fa-regular fa-square">` inside an element that already has a CSS border drawing a square. Two squares.

### Fix

Template change: only render the icon when checked (`fa-solid fa-check`). When unchecked, render an empty `<a>` — the CSS border draws the unchecked-square appearance on its own.

Before: `<i class="{{#if stat.improve}}fa-solid fa-check{{else}}fa-regular fa-square{{/if}}"></i>`
After:  `{{#if stat.improve}}<i class="fa-solid fa-check"></i>{{/if}}`

### Version

System `1.0.0-alpha.28` → `1.0.0-alpha.29`. Compendium unchanged.

---



User feedback on alpha.27: stats grid sits at the top of the right-side header area; should be vertically centered between top and bottom.

### Diagnosis

Investigated via Chrome bridge. Despite alpha.26's CSS specifying `grid-template-rows: auto auto; grid-template-areas: "portrait meta strip" / "stats stats stats"` on `.elysium-header-card`, the stats grid's parent is actually `.elysium-header-strip` (NOT `.elysium-header-card`) — because the template embedded the stats markup INSIDE the strip back in alpha.24. The `grid-area: stats` rule applied to `.elysium-stats-grid` was orphaned (the strip is a flex container, not a grid). The intended row-2 layout never took effect; stats was always rendering as the second flex child of the strip.

In practice this produced the right VISUAL placement (right side of header, below the protruding Public/GM+Difficulty pills) just by accident of the strip's flex column layout. User screenshot confirmed: stats appeared at the top of the strip's available vertical space, with empty space below it.

### Fix

Simplified the header card grid to a single row (`grid-template-areas: "portrait meta strip"`) since stats is inside the strip anyway — removed the phantom row 2. Strip itself now has `height: 100%` to fill the header card's full row height. Stats grid gets `margin-top: auto; margin-bottom: auto` which, in a flex column, gives equal vertical space above and below the element — centering it within the strip's free space (the protruding sub-row at top is pinned via its own negative margin-top and is unaffected).

### Net effect

- Public/GM + Difficulty: protruding above header card top (unchanged)
- Stats grid: vertically centered within the remaining strip space
- Portrait, meta, other content: unchanged

### Version

System `1.0.0-alpha.27` → `1.0.0-alpha.28`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.26's tab strip protrusion attempt (`margin-right: -22px; position: relative; z-index: 5`) made the strip overlap the area where Foundry's resize handle sits at the bottom-right corner of the application. Even though the strip's bottom (y=887) and the handle's top (y=887) were technically adjacent rather than overlapping, the strip's protruding right edge (x=1209) extended past the handle's x range (1187-1198), and its z-index:5 + relative position created a new stacking context that captured pointer events targeted at the resize handle.

Live diagnosis via Chrome bridge: handle present and styled correctly (`position: absolute, 11×11 at x=1187 y=887, pointer-events: auto, z-index: auto`), but tab strip ate the clicks.

### Fix

Reverted the tab strip protrusion:
- Removed `margin-right: -22px`, `position: relative`, `z-index: 5`
- Added `padding-bottom: 20px` to leave the bottom-right corner of the column free for the resize handle
- Tab chips back to the alpha.20 styling: 32×32 in-gutter chips, transparent background, no folder-tab shape, no drop-shadow, no translate-on-hover

### Honest acknowledgment on tab protrusion

Three attempts at making the tabs visually escape the application's right edge (alpha.21, alpha.22, alpha.26) have either failed visually, broken the resize handle, or both. The mechanics:

1. `window-content { overflow: visible }` alone — tabs stay inside the application's outer chrome which clips them
2. `.application { overflow: visible }` — escapes the chrome but breaks resize handle anchoring
3. `margin-right: -Npx` on the tab strip — escapes window-content but the strip's pointer-event area overlaps the resize handle

Defeating Foundry's outer application chrome (the rounded border around the whole window) without breaking the resize handle requires more investigation than this iteration can do. **Decision: accept in-gutter tab styling for P8.** Real tab protrusion past the application border is a P9+ refinement contingent on understanding Foundry V14's application rendering more deeply.

### Version

System `1.0.0-alpha.26` → `1.0.0-alpha.27`. Compendium unchanged at `1.0.0-alpha.3`.

---



User feedback on alpha.25:
- Name is squished (the meta column lost width to the 720px stats grid)
- Move and Luck should be moved under EXP Dice (in meta block, not header strip)
- Tabs still don't protrude past the window
- Portrait should fill space while maintaining aspect ratio

### Header card: 2-row internal grid

`.elysium-header-card` switched from `grid-template-columns: auto 1fr auto` to a 2-row grid:

```
grid-template-rows: auto auto;
grid-template-areas:
  "portrait meta strip"
  "stats    stats stats";
```

Stats grid now spans the FULL header card width in its own dedicated bottom row. No more competition with the meta block. Name input gets back its full meta-column width.

### Move + Luck chips → meta block

In the template, Move and Luck chips moved from `.elysium-header-strip` (where they were paired with the protruding Public/GM + Difficulty) into a new `.elysium-header-meta-chips` container inside `.elysium-header-meta`, sitting right below EXP Dice. CSS: simple flex row with `gap: var(--ely-space-2); margin-top: var(--ely-space-1)`.

The header strip column now contains ONLY the protruding Public/GM + Difficulty top sub-row (the second sub-row that held Move/Luck is gone).

### Stats grid width: 100%

Constrained-width `width: 720px` removed. Now `width: 100%` since stats has its own dedicated row spanning the full header card width. Tiles auto-size — at ~800-1000px header width / 7 tiles, each tile is ~110-130px. Comfortable for one-line derived labels (`Damage Mod`, `Healing Rate`, etc., already had `white-space: nowrap` from alpha.25).

### Portrait: grows with aspect ratio

`max-height` raised from 160px → 220px. `aspect-ratio: 1 / 1` added as a fallback for images without intrinsic dimensions. Container changed from `align-items: stretch` to `align-items: center; justify-content: center` so the portrait stays centered if the row is taller than the max-height (rather than stretching the image).

### Tab strip protrusion attempt #3

Previous attempts (alpha.21, alpha.22) either failed visually or broke the resize handle. This attempt:

- `.elysium-tabs-strip { margin-right: -22px; position: relative; z-index: 5 }` — shifts the strip right past the window-content's right edge. Since window-content has `overflow: visible`, the strip can extend past. No application-level overflow override (which was the resize handle regression in alpha.21).
- Tab chips become folder-tab shape: `width: 100%` (fills the 48px strip width), `border-radius: 0 var(--ely-radius-3) var(--ely-radius-3) 0` (flat left, rounded right), `border-left: none` (attaches flush to sheet body), `box-shadow: 2px 1px 3px rgba(0,0,0,0.25)` (physical tab feel).
- Hover: `transform: translateX(2px)` (slight pull-out)
- Active: `transform: translateX(3px)` + deeper shadow + crimson fill (looks selected)

If this still doesn't visually escape Foundry's outer chrome (the rounded application border), the protrusion effect will be partial — chips will look like docked tabs rather than free-floating folder tabs. Acknowledged honestly. If that's still wrong I'll need to investigate Foundry's actual app chrome rendering before another attempt.

### Version

System `1.0.0-alpha.25` → `1.0.0-alpha.26`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.24 successfully embedded the stats grid below Move/Luck (no more vertical gap), but tiles were squished to 380px total width because I constrained them to leave room for the meta block. Reality: the meta block (Ancestry / Career / EXP Dice) only uses ~400px of the available ~700-800px in its column, leaving tons of empty space.

### Fix: widen stats grid to 720px

- `.elysium-stats-grid { width: 720px }` (up from 380px) — 7 tiles × ~100px + gaps. The header strip column grows wider in the header card grid; meta block compresses slightly but its text is short anyway.
- `gap` between tiles: `4px` → `var(--ely-space-2)` for a bit more breathing room
- Tile padding-top: 22px → 26px; bottom: --ely-space-1 → --ely-space-2
- Pill: 42×32 → 50×36, top: -14 → -16 (pill slightly larger, protrudes a touch more)

### Derived labels: one line

`.elysium-stat-tile-derived-label { white-space: nowrap }` — `Damage Mod`, `Healing Rate`, `XP Bonus`, `Init Bonus` no longer wrap to 2 lines. Width is sufficient for all four at the wider tile size.

### Typography scale-up

- Stat name (`Strength`, `Constitution`, etc.): font-size-1 → font-size-2, restored full `--ely-letter-spacing-wide`
- Derived label: 9px custom → font-size-1, slight letter-spacing
- Derived value: font-size-2 → font-size-2 (unchanged in token; reads bigger relative to label now)
- Improve checkbox: 16×16 → 18×18 (still square, slightly more clickable)

### Version

System `1.0.0-alpha.24` → `1.0.0-alpha.25`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.23 placed the stats card right-aligned in its own grid row, below the header. User confirmed the placement was wrong: stats should sit **directly below Move/Luck**, not in a separate row. The grid gap between row 1 (header) and row 2 (stats) was creating the visible vertical separation.

### Fix: stats grid moves into `header-card.hbs`

The 7-tile stats grid markup (the `{{#each system.stats}}` loop with pills, names, improve checkboxes, dividers, derived stats) is now embedded directly into `header-card.hbs`, inside `.elysium-header-strip`, immediately below the Move/Luck chip-group. No more "stats card" as a separate PART.

### Code changes

- `header-card.hbs` — stats grid markup added after `.elysium-header-chip-group` (Move/Luck chips). Uses square checkbox (`fa-regular fa-square` / `fa-solid fa-check`) per user spec.
- `character.mjs:PARTS` — `stats: {template: ...}` line removed (commented). The standalone `stats-card.hbs` file is left in place but unused.
- `character.mjs:_configureRenderOptions` — `'stats'` removed from `options.parts` array.
- `character.mjs:_prepareContext` / `_getTabs` — `case 'stats'` arms left in place harmlessly (won't be hit since stats isn't a part anymore).

### CSS changes

- `.window-content` grid: removed the `stats` row. Now 3 rows: `header / res / row3` with areas `"header...tabs" / "res...tabs" / "leftRail content rightRail tabs"`.
- All `grid-row: 4 / -1` references (left rail, tab content parts) updated to `grid-row: 3 / -1`.
- `.elysium-stats-card` rule removed from the shared card-chrome group (no longer rendered).
- `.elysium-stats-card { grid-area: stats; ... }` rule removed entirely.
- `.elysium-stats-grid`: now includes `padding-top: 14px` for protruding-pill clearance (was on the card before). Width constrained to `380px` so the header strip column doesn't push out the meta block (7 tiles × ~50px + gaps = ~374px).

### Result

Stats sits inside the header card, right column, directly below Move/Luck chips. The header card grows taller (was ~200px, now ~280-300px) to accommodate the extra content. Portrait is allowed to grow taller via its `max-height: 160px` rule.

The grid gap that was visible between rows in alpha.23 is gone — stats flows continuously below Move/Luck inside the same card.

### Version

System `1.0.0-alpha.23` → `1.0.0-alpha.24`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.22 attempted to put the stats card to the **right of** the header card (sharing the header row, 60/40 split). Two issues:

1. I misread the user's intent. They wanted stats UNDER Move/Luck (vertically below the chips on the right side of the sheet), not BESIDE the header card.
2. My alpha.22 grid change removed the "stats" row from `window-content` but I left `.elysium-left-rail { grid-row: 4 / -1 }` and `.elysium-tabs-strip { grid-row: 1 / -1 }` referencing the old 4-row grid. With only 3 rows, those refs broke and the whole sheet rendered nearly empty.

### What alpha.23 does

Reverts to alpha.20's window-content grid (4 rows: header / stats / res / row 4) so all the row references work. Then:

- **Stats card right-aligned in its row** via `justify-self: end; width: 50%`. Stats no longer spans the full row — it occupies the right half, vertically aligned under the Move/Luck chips that live in the header card above.
- **Window-content `overflow: visible`** retained so protruding pills can escape grid cells.
- **`.application` overflow stays at Foundry default** (no resize-handle regression).

### Kept from alpha.21 (the parts that worked)

- Public/GM + Difficulty `.elysium-header-strip-top { margin-top: -28px }` protrusion above header card top edge
- Drop-shadow on chips inside the protruding sub-row
- Stat pill protrusion above each tile body via `position: absolute; top: -14px`

### Stat tile sized for the narrower column

7 tiles fit in ~50% of the row (~430px), so ~58px per tile. Sizes shrunk vs alpha.20:
- Pill: 42×32 (was 56×40), font-size-4
- Tile padding-top: 22px (was 28px), horizontal 2px (was --ely-space-1)
- Stat name: font-size-1 (was font-size-2), letter-spacing 0.02em (was --ely-letter-spacing-wide), `overflow: hidden; text-overflow: ellipsis` for long names
- Improve checkbox: **16×16 small square** with 3px radius (was 28×28 circle) — conserves vertical space per user request
- Derived label: 9px custom (token didn't go that small)
- Derived value: font-size-2 (was font-size-3)

### NOT changed

- Tab strip stays in alpha.20 styling (in-gutter 32×32 chips). The alpha.21 attempt to make them protrude past the application window didn't visually escape and was reverted.

### Version

System `1.0.0-alpha.22` → `1.0.0-alpha.23`. Compendium unchanged at `1.0.0-alpha.3`.

---



User feedback on alpha.21:
- Public/GM + Difficulty protrusion above header looks good — KEEP
- Stat pill protrusion above tile looks good — KEEP
- Application-level `overflow: visible` broke the resize handle position — REVERT
- Tab strip protrusion didn't actually protrude past the application window — REVERT to alpha.20 styling (in-gutter chips)
- **Move the stats card up INTO the header zone, bottom-right aligned, alongside the header**
- **Improvement circles too big** — switch to small squares to conserve vertical space (couldn't make them overlap the pill bottom edge cleanly)

### Window-content grid restructure

The "stats" row in the window-content grid is gone. Header card and stats card both occupy `grid-area: header` now, with explicit width constraints so they sit side-by-side without overlapping:

```
grid-template-rows: auto auto 1fr;
grid-template-areas:
  "header   header   header   tabs"
  "res      res      res      tabs"
  "leftRail content  rightRail tabs";
```

- `.elysium-header-card { grid-area: header; justify-self: start; width: calc(60% - var(--ely-space-2)); }`
- `.elysium-stats-card { grid-area: header; justify-self: end; align-self: end; width: calc(40% - var(--ely-space-2)); }`

Stats sits at the bottom-right of the header zone, aligned to the bottom so its protruding pills don't clash with the protruding Public/GM + Difficulty chips above the header card.

`window-content` retains `overflow: visible` so protruding pills still escape the grid cell boundaries. **`.application.elysium.sheet.actor` is NOT given `overflow: visible`** — that was the alpha.21 regression that misplaced the resize handle.

### Stats card resized for narrow column

7 tiles in a ~40%-width container means each tile is ~50-60px wide (vs ~125px in alpha.20). All values shrunk:
- Pill: 56×40 → 42×34, font-size-5 → font-size-4
- Tile padding: 28px top → 24px top; horizontal 4px → 2px
- Stat name: font-size-2 → font-size-1, letter-spacing tightened, `overflow: hidden; text-overflow: ellipsis` so longer words ("Constitution", "Intelligence") gracefully truncate if needed
- Improve checkbox: 28×28 CIRCLE → 16×16 SQUARE (with subtle 3px radius), border-decorative bone color
- Divider: same proportions
- Derived label: font-size-1 → 9px (custom — tokens didn't go that small), tightened letter-spacing
- Derived value: font-size-3 → font-size-2

Stats card itself gets `padding-top: calc(var(--ely-space-3) + 16px)` so the protruding pills have clearance above the tile row.

### Reverted from alpha.21

- `.application.elysium.sheet.actor { overflow: visible }` REMOVED (was the resize handle bug)
- Tab strip protrusion attempt REMOVED: chips back to alpha.20 styling (32×32 squares inside the 48px gutter column, no protrusion). The "protrude past the window" effect would have required breaking Foundry's resize handle anchoring; the cost wasn't worth it.

### Kept from alpha.21

- Public/GM + Difficulty protrusion above header card (negative margin-top + relative z-index)
- Drop shadow on protruding chips
- Stat pill protrusion above tile body (absolute positioning + tile padding-top)

### Move/Luck chips

Stay in the header strip's bottom sub-row (the chip-group), which now appears below the protruding Public/GM + Difficulty cluster, inside the header card. The header card width is 60% of the header area, so Move + Luck have room.

### Version

System `1.0.0-alpha.21` → `1.0.0-alpha.22`. Compendium unchanged at `1.0.0-alpha.3`.

---



User shared a Tidy 5e Sheet reference showing tab handles protruding past the right edge of the sheet panel. Asked whether the same trick could apply to the stat-tile pills (top-protrude) and the header toggle pills (Public/GM + Difficulty). Yes — all three are the same overflow-permitted-edge technique.

### Window-content overflow + grid retains 4-col

`.application.elysium.sheet.actor .window-content` switched `overflow: hidden` → `overflow: visible` and added `position: relative`. `.application.elysium.sheet.actor` (the outer wrapper) also gets `overflow: visible` so children can extend past its rounded panel edges. Grid retains 4 columns but column 4 narrowed from `48px` → `36px` since the chip is now full-width inside that gutter and looks like a folder tab rather than a 32×32 button with margin.

### Tab strip: protruding handles

`.elysium-tabs-strip` styling reworked:
- Chips now `width: 100%` (fills the 36px gutter) and `height: 36px` (was 32×32 square)
- `border-radius: 0 var(--ely-radius-3) var(--ely-radius-3) 0` — flat left edge (attaches to card body), rounded right edge (protrudes outward like a folder tab)
- `border-left: none` so the chip body visually flows out of the card chrome to its left
- `box-shadow: 2px 1px 3px rgba(0, 0, 0, 0.25)` — physical drop-shadow on the protruding edge
- Hover: `transform: translateX(2px)` — subtle pull-out animation
- Active: `transform: translateX(3px)` + deeper shadow + crimson fill — protrudes further when selected

`align-items` changed from `center` to `stretch` so chips fill the gutter width. `padding` changed from `var(--ely-space-2) var(--ely-space-1)` to `var(--ely-space-2) 0` so chips reach edge-to-edge horizontally.

### Stat tile: protruding crimson pill

The pill (stat total) now protrudes ABOVE the tile body, matching the user's latest reference image where the crimson modifier pill is bigger than the tile and overhangs its top edge.

- `.elysium-stats-grid` gets `padding-top: 20px` so the row has clearance for the protruding pills
- `.elysium-stat-tile` switched back to **visible** body: `background: var(--ely-surface-raised); border: 1px solid --ely-border-subtle; border-radius: --ely-radius-3` — so the pill has something to visually protrude from
- `.elysium-stat-tile` gets `position: relative` and `padding-top: 28px` (extra room at top for the pill to sit half-inside)
- `.elysium-stat-tile-total` (the pill) becomes `position: absolute; top: -20px; left: 50%; transform: translateX(-50%)` — anchored to the tile's top edge with the pill centered horizontally and protruding 20px above
- Pill size grew slightly: `min-width: 56px; height: 44px` (was 40px), `box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4)` for physical-pill feel, `z-index: 1` so it sits above the tile body
- Hover transform updated to `translateX(-50%) translateY(-2px)` (keeps the horizontal centering while lifting on hover)
- `.elysium-stat-tile-improve` hover changed `background: var(--ely-surface-raised)` → `background: var(--ely-surface-base)` since the tile body is now `--ely-surface-raised`; need contrast on hover

### Header: Public/GM + Difficulty protruding above card top

User asked for the Public/GM toggle and difficulty 7-strip to protrude above the header card's top edge. Implemented via a new wrapper `<div class="elysium-header-strip-top">` that contains both groups, with `margin-top: -28px; position: relative; z-index: 2`. The Move and Luck chip group stays inside the card at normal flow position.

`.elysium-header-strip` changed `flex-direction: row` → `flex-direction: column` so the top sub-row and bottom chip group stack vertically. The top sub-row uses `inline-flex` for horizontal layout of its two groups (visibility + difficulty).

Chips inside the protruding strip get a drop-shadow rule:
```
.elysium-header-strip-top .elysium-chip { box-shadow: 0 2px 4px rgba(0, 0, 0, 0.35); }
.elysium-header-strip-top .elysium-chip.is-active { box-shadow: 0 3px 6px rgba(0, 0, 0, 0.45); }
```

### Risk: overflow:visible side effects

Setting `overflow: visible` on the outer `.application` wrapper could theoretically interfere with Foundry's window resize handle (which is positioned at bottom-right) or tooltips. Both are typically `position: fixed` or use their own stacking contexts, so they should be unaffected. If issues surface in smoke, the fix is to scope `overflow: visible` narrower or use clip-path on just the right edge.

### Template

`header-card.hbs`: roll-visibility and difficulty-strip wrapped in `<div class="elysium-header-strip-top">`; chip-group (Move + Luck) stays as a sibling. Comment updated to explain the protrusion intent.

### Version

System `1.0.0-alpha.20` → `1.0.0-alpha.21`. Compendium unchanged at `1.0.0-alpha.3`.

---



User clarified the intended visual mapping for stat tiles:

> For the stat scores our equivalent would be the +1 in the reference for Strength would be the actual stat 12 and where it has the actual stat in the small circle would be our check box for improvement.

Plus: spell out the full stat name (Strength, Constitution, ...) rather than the abbreviation.

### Mapping

| D&D Beyond reference         | Elysium tile equivalent             |
|------------------------------|--------------------------------------|
| Modifier pill (`+1`)         | Stat total (`12`) — focal crimson pill |
| Stat name (`Strength`)       | Full stat name (`Strength`) — small caps, bone |
| Score in small circle (`12`) | Improvement checkbox in circular frame |

### Template (`stats-card.hbs`)

New layout per tile, top-to-bottom:
- `.elysium-stat-tile-total` — crimson rounded pill with `{{stat.total}}` (was previously second in the stack)
- `.elysium-stat-tile-name` — `{{stat.label}}` (full localized stat name; was `{{stat.labelShort}}` for abbreviations)
- `.elysium-stat-tile-improve` — `<a>` styled as circular frame containing either `fa-regular fa-circle` (empty) or `fa-solid fa-check` (marked)
- `.elysium-stat-tile-divider` — narrow horizontal rule
- Derived label + value (or `—` for SIZ/POW/CHA)

The old `.elysium-stat-tile-totalrow` wrapper and `.elysium-stat-tile-base` (raw base value `(0)`) are gone — they no longer fit the visual.

### CSS (`elysium-sheets.css`)

Stat tile: `background: transparent; border: none` — tiles flow as a visually unified row inside the card chrome around them, matching how the reference's tiles share a single ABILITIES card with no per-tile boxes. Grid gap tightened from `--ely-space-2` to `--ely-space-1`.

Pill: `min-width: 56px; height: 40px; border-radius: --ely-radius-2`. Crimson background (`--ely-accent-action`), bone border (`--ely-border-decorative`), white bold text. Hover lifts `translateY(-1px)` and brightens.

Name: `font-family: --ely-font-family-display; text-transform: uppercase; letter-spacing: --ely-letter-spacing-wide; line-height: 1.1`. Full word fits on one line at the ~125px tile width for all 7 stats (Constitution/Intelligence are the widest at 12 chars).

Improve circle: 28×28px, `border-radius: --ely-radius-full`, bone border. Empty state shows `fa-regular fa-circle` (subtle); marked state shows `fa-solid fa-check` (filled). Hover background `--ely-surface-raised` with gold accent color.

### Version

System `1.0.0-alpha.19` → `1.0.0-alpha.20`. Compendium unchanged at `1.0.0-alpha.3`.

---



User reviewed alpha.18 against the D&D Beyond reference and identified four refinements: stat tile visual aesthetic, Init pairing location, EXP-Dice placement, header strip layout, and tab strip spacing.

### Stat tile visual: crimson rounded pill for the total

alpha.18 stat tile rendered the stat total as plain bold text. The reference image shows the modifier value in a rounded crimson square — a focal element. **Redesign**: stat total is now a crimson rounded pill (`--ely-accent-action` background, `--ely-text-inverse` color, 52px min-width × 40px height, `--ely-radius-2`). Captures the reference's visual language while honoring Mythras semantics (the percentage score itself is the focal element since Mythras has no separate modifier/score split). Hover state lifts the pill `translateY(-1px)` and brightens to `--ely-accent-action-hover`. Tile structure unchanged: name → pill total → base value `(X)` → divider → derived label → derived value.

### Init pairing moved CHA → DEX

The Init Bonus pairing was incorrectly placed under CHA in `stats-card.hbs`. Initiative in Elysium is DEX+INT, so it belongs under DEX (or INT — choosing DEX since INT is taken by XP Bonus). **Fix**: in the `{{#if (eq key)}}` chain, the `cha` branch is replaced with `dex`; CHA now shows dashes. SIZ/POW remain dashes.

### Init chip removed from header strip

Since Init Bonus now lives in the stats card under DEX, the redundant Init chip in the header strip is removed. The chip group now contains only Move and Luck.

### EXP-Dice line added below career

alpha.18 removed the visual EXP-Dice badge from the portrait (correct — too noisy on fresh actors) but didn't preserve the information anywhere. **Add back**: a text line below career in the meta block: `EXP Dice: 0d4 (N available)` where the available count is shown in `--ely-accent-bonus` gold italic only when > 0. Uses existing `context.expDiceDisplay` and `context.expDiceAvailable` already populated.

### Header strip layout: vertical → horizontal flat row

alpha.18 header strip stacked the three groups (Public/GM, difficulty chips, Move/Luck chips) vertically with `flex-direction: column`. The reference image shows the right side of the header as a single horizontal row of pill-toggles. **Fix**: changed strip to `flex-direction: row; flex-wrap: wrap; justify-content: flex-end`. The three groups now sit side-by-side, wrapping to a second line if width forces it.

### Tab strip: Foundry V14 default `.tabs` override

alpha.18 fix added `tabs` class to the strip nav so `changeTab` could find chips. Side effect: Foundry V14's framework `.tabs` styles applied `justify-content: space-evenly` to the strip, distributing the 6 chips across the full 940px column height. Result: chips were spaced ~137px apart, looking like an "oddly spaced down the sheet" column. **Fix**: explicit `justify-content: flex-start` override on `.elysium-tabs-strip`, plus `align-items: center` and `background: transparent; border: none` for defensiveness. Chips now cluster tight at the top of the column with the documented 4px gap between them.

### Version

System `1.0.0-alpha.18` → `1.0.0-alpha.19`. Compendium unchanged at `1.0.0-alpha.3`.

---



User compared alpha.17 against the D&D Beyond reference image and identified five issues. This ship addresses all of them.

### Bug: Tab clicks fail with "No matching tab element found"

**Root cause**: Foundry V14's `changeTab(tab, group)` looks for the active chip with selector `this._content.querySelector('.tabs [data-group="${group}"][data-tab="${tab}"]')` — note the **`.tabs` ancestor requirement**. My `tabs-strip.hbs` wrapped the chips in `<nav class="elysium-tabs-strip elysium-tabs-vertical">` without the `tabs` class. The selector failed; clicking any tab threw the error. (Tab content sections — the OTHER half of the toggle — use selector `.tab[data-group="${group}"]` with `.tab` as a class, and those were already correct since legacy content templates emit `<section class="actor tab combat">`.)

**Fix**: added `tabs` to the `<nav>` outer class list. Now reads `<nav class="tabs elysium-tabs-strip elysium-tabs-vertical">`. One-word change in `templates/actor/parts/tabs-strip.hbs`. Foundry's tab toggle now finds the chip, applies `.active` class to it, and applies `.active` to the matching content section. Foundry's default CSS handles `.tab:not(.active) { display: none }` visibility.

### Bug: Overall HP shown in Defenses card

Mythras / Elysium uses per-hit-location HP exclusively; an "overall HP" summary is misleading. **Fix**: removed the `<div class="elysium-defenses-overall-hp">` block from `right-rail-defenses.hbs` and the associated CSS rules. Temp HP input remains; per-hit-location rows remain. Context variable `overallHP` is still computed in `_prepareContext` but no longer rendered (harmless; will be culled when other consumers confirm none).

### Design: Stats card → horizontal row of tiles

alpha.17 rendered stats as 7 horizontal rows of `(name + value + base + improve-checkbox + derived-label + derived-value)` — too wide, too sparse, didn't match reference. **Redesign**: now a horizontal grid of 7 tiles. Each tile stacks vertically:
- Stat name (top, display font, bone color, uppercase small-caps)
- Large total + improve-checkbox (corner)
- Base value `(X)` below total
- Horizontal divider
- Derived stat label (or "—") at bottom
- Derived stat value (or "—")

CSS: `grid-template-columns: repeat(7, 1fr)` on the stats grid, tiles styled with `--ely-surface-raised` bg + `--ely-border-subtle` border + `--ely-radius-3` corners. New class hierarchy: `.elysium-stat-tile`, `.elysium-stat-tile-name`, `.elysium-stat-tile-totalrow`, `.elysium-stat-tile-total`, `.elysium-stat-tile-improve`, `.elysium-stat-tile-base`, `.elysium-stat-tile-divider`, `.elysium-stat-tile-derived-label`, `.elysium-stat-tile-derived-value`. Old `.elysium-stat-row` / `.elysium-stat-block` / `.elysium-derived-block` rules deleted (~75 lines removed). Pairings preserved: STR→Damage Mod, CON→Healing Rate, INT→XP Bonus, CHA→Init Bonus; SIZ/POW/DEX show "—".

### Design: Portrait fills header height

alpha.17 portrait was 80×80 fixed inside a 96-px column. **Redesign**: portrait container `display: flex; align-items: stretch`, image `height: 100%; width: auto; max-height: 160px; object-fit: cover` — fills the header card's row height with aspect ratio preserved. Header card grid changed from `96px 1fr auto` to `auto 1fr auto` so the portrait column sizes to its content. `align-items: center` → `align-items: stretch` so the portrait can fill vertical space.

### Design: EXP-Dice badge removed from portrait

The crimson "0" badge in the portrait's bottom-right corner was visually noisy on a fresh actor. Removed entirely from `header-card.hbs`. Associated CSS rules (`.elysium-exp-dice-badge`, `.elysium-exp-dice-count`) deleted (~16 lines removed). EXP-Dice availability is still readable via `actor.system.elysium.expDice`; future surface for it (proper EXP-spending UI) is a P9+ concern.

### Design: Tab strip transparent background

alpha.17 tab strip had the shared card chrome (bg + border + radius + padding), making it look like a docked panel. **Redesign**: removed `.elysium-tabs-strip` from the shared card-chrome rule group. Tab strip now renders with NO background, NO border — just the chips floating on the parent's surface, which creates the illusion of tab handles attached to the right edge of the content area.

### Verification

- All .mjs files pass `node --check`
- CSS brace balance: 121/121
- Stats grid template: `repeat(7, 1fr)` — 7 tiles in horizontal row
- Tab strip nav now has class `tabs elysium-tabs-strip elysium-tabs-vertical`

### Version

System `1.0.0-alpha.17` → `1.0.0-alpha.18`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.16 visual review showed the LUCK chip rendering as `/0` (empty value, slash, max).

### Root cause

The header-card context-prep was reading `actor.flags.elysium.derived.luckPoints` as the source. Examination of `module/elysium/actor/actor-extension.mjs:101–115` shows that the canonical location for the **runtime pool with both `value` and `max`** is `actor.system.luckPoints` — the flags-side derived value only carries `.max` (it's a per-prep computation, not the live state). The actor pipeline mirrors `derived.luckPoints.max` into `system.luckPoints.{value, max}` with preserve-value-in-play logic. My code was reading the wrong source, getting `undefined` for `value`, and rendering as empty string.

### Fix

`module/actor/sheets/character.mjs` luck-points block: read from `this.actor.system.luckPoints` instead of `derived.luckPoints`. Both keys default to 0 if missing.

### Version

System `1.0.0-alpha.16` → `1.0.0-alpha.17`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.15 live render verified structurally clean. First visual review caught two issues:

### Fixes

**`templates/actor/parts/header-card.hbs`**:
- Ancestry label used `{{localize 'Elysium.ancestry'}}` but `Elysium.ancestry` is not a string in `en.json` — it's a container OBJECT (`Elysium.Ancestry` with capital A is a settings/dialog namespace). `localize` returns the literal key when it hits a non-string, so the rendered output was `Elysium.ancestry: —`. Fixed to use `{{ancestryColumnLabel}}` — the existing context variable that resolves to "Ancestry" / "Race" / "Species" / "Cultural" based on the `ancestryLabel` system setting.
- Career label used `{{localize 'Elysium.career'}}` which IS valid but for consistency with the ancestry fix, switched to literal `Career: —` (`Elysium.career` returns "Career" so the visual was already correct, but now both labels follow the same pattern).
- Init/Move/Luck chips wrapped in a new `<div class="elysium-header-chip-group">` so they render as a horizontal row instead of stacking vertically with the Public/GM toggle and difficulty strip. The outer header strip still uses `flex-direction: column` to stack the three logical rows (visibility / difficulty / chips), but the chip group inside is `inline-flex` for horizontal layout.

**`styles/elysium-sheets.css`**:
- New rule `.elysium-header-chip-group { display: inline-flex; gap: var(--ely-space-2); }` supports the horizontal chip row.

### Other observations (NOT fixed in this patch, planned for P9)

The legacy combat-tab content (weapon table, hit-location table, healing bed button, "Active Conditions: No active conditions" stub) renders in the center column because Combat is the default tab and tab content templates are unchanged per P8 design. P9 rebuilds each tab against the new shell. The new right-rail Conditions card correctly stays hidden when empty (the alpha.15 fix is working).

### Version

System `1.0.0-alpha.15` → `1.0.0-alpha.16`. Compendium unchanged at `1.0.0-alpha.3`.

---



alpha.14 live smoke caught one render error: when an actor has no conditions, the `right-rail-conditions.hbs` template was wrapped in `{{#if conditions.length}}...{{/if}}` around its entire outer `<section>`, producing zero HTML elements. Foundry V14's ApplicationV2 requires every PART to render exactly one root element, raising `Template part "rightRailConditions" must render a single HTML element.`

### Fix

`templates/actor/parts/right-rail-conditions.hbs`: outer `<section>` now always renders. The `{{#if conditions.length}}` block was moved INSIDE the section to gate header + list content. When empty, the section gets the `elysium-card-hidden` class which sets `display: none`. Visual behavior unchanged (empty Conditions card is hidden); the part now produces a stable single-root.

`styles/elysium-sheets.css`: new rule `.application.elysium .elysium-card-hidden { display: none; }` to support the hidden-when-empty pattern. CSS rule count: 123 → 124.

Other shell parts (defenses, senses, effects, header, stats, resources, leftRail, tabs) inspected — all already render a single outer element unconditionally; no other parts have this issue.

### Verification

- All other parts use literal outer elements (`<section>`, `<aside>`, `<nav>`) with no top-level conditionals — verified by template scan
- Conditions template: outer `<section class="elysium-rail-card elysium-conditions-card">` always present, with `elysium-card-hidden` class conditional via `{{#unless}}`

### Version

System `1.0.0-alpha.14` → `1.0.0-alpha.15`. Compendium unchanged at `1.0.0-alpha.3`.

---



Fourteenth alpha. **Combined ship of P7.5 + P8** per user decision (single alpha, scope-coupled because P8 templates use the new vocabulary). Compendium bumps to **alpha.3**.

### P7.5 — Career rename codemod

System-wide rename `profession` → `career`. The new term "Profession" is reserved for a future specialized-crafting subsystem (not built in this phase).

- **System source**: 169 `profession*` words removed across 28 files via case-aware regex codemod with CamelCase composite support (handles `ProfessionDataModel`, `ElysiumProfessionSheet`, `_deleteProfession`, `professionId`, etc.). 25 unit tests passing including negative cases (`confessional`, `professed` unchanged).
- **File renames**:
  - `module/data/item/profession.mjs` → `career.mjs` (class `ProfessionDataModel` → `CareerDataModel`)
  - `module/item/sheets/profession.mjs` → `career.mjs` (class `ElysiumProfessionSheet` → `ElysiumCareerSheet`)
  - `templates/item/profession.{wealth,skills,powers}.hbs` → `career.*.hbs`
- **Item type**: `'profession'` → `'career'` in `system.json` `documentTypes.Item` and `CONFIG.Item.dataModels` registration in `init.mjs`.
- **Schema field**: `professionalSkills` → `careerSkills` (career and culture DataModels).
- **Labels**: "Professional Skills" bucket → "Career Skills" (in Skills tab template and elsewhere).
- **Lang files**: en/es/fr all updated; one ALL-CAPS phrase in `character.skills.hbs` and one French translation quality issue (`professionnels` → `professions de carrière` → manual fix to `Points de compétence de carrière`) caught after first pass.
- **Compendium**:
  - 167 doc-level changes across 7 .db files (skills, abilities, abilities-mysticism, ancestries, arcane-knowledge, professions) using content-aware codemod that only touches JSON keys and type-values — NOT prose in `description` / `gmDescription` / `biography` / `notes` / `mods` fields
  - `packs/professions.db` → `packs/careers.db` (pack file renamed)
  - `module.json`: pack registration block — `"name": "professions"` → `"careers"`, `"label": "Professions"` → `"Careers"`, `"path": "packs/professions.db"` → `"packs/careers.db"`
  - Compendium version bumped 1.0.0-alpha.2 → 1.0.0-alpha.3

### P8 — Actor sheet shell rebuild

Three-rail layout with vertical tab strip on the right edge. Tab CONTENT unchanged in P8 (old `character.<tab>.hbs` templates render unchanged in the new tab containers; P9 rebuilds each tab).

**Layout (1200×900, resizable)**:
```
HEADER CARD (portrait + name/ancestry/career + header strip)  | TABS
STATS CARD (7 stats with derived pairings)                     | (vertical
RESOURCES CARD (AP pools + PP)                                 |  icon rail
LEFT RAIL | TAB CONTENT | RIGHT RAIL                           |  spans
(skills)  |             | (defenses/conditions/senses/effects) |  all rows)
```

**9 new templates** in `templates/actor/parts/`:
- `header-card.hbs` — portrait (80×80) with EXP-Dice count badge, name + ancestry + career, header strip with Public/GM toggle, 7-button difficulty strip (VE/E/R/A/D/F/I), Initiative Bonus chip, Movement Base chip, Luck Points chip; lock toggle; NPC badge slot
- `stats-card.hbs` — 7 stat rows (STR/CON/INT/SIZ/POW/DEX/CHA) with name+total+base+improve-checkbox paired with derived stat (STR→Damage Mod, CON→Healing Rate, INT→XP Bonus, CHA→Init Bonus; SIZ/POW/DEX empty dashes since AP+PP moved to Resources)
- `resources-card.hbs` — AP pools (General always; Reaction/Attack/Defense if max > 0) with refresh+edit buttons; PP single pool with refresh+edit
- `tabs-strip.hbs` — vertical icon-only tab navigation
- `left-rail-skills.hbs` — Standard Skills + Career Skills sections, each grouped by category with collapsible group headers; per-skill row: name (clickable=roll) + cat tag + improve checkbox + % total
- `right-rail-defenses.hbs` — Temp HP input + overall HP summary + hit-location list (expandable rows showing armor-layer dropdown joining hit-location items with equipped armor items by `hitlocID`) + Rest button STUB (P9 builds dialog)
- `right-rail-conditions.hbs` — actor `effects.statuses` + per-hit-location `system.elysium.locationConditions[]` combined with affected location chips
- `right-rail-senses.hbs` — Perception skill (clickable for roll) + vision types from mutation/super items
- `right-rail-effects.hbs` — active effects WITHOUT statusId (Conditions card handles statusId ones); name + source + toggle + edit + delete + add button

**3 edited .mjs files**:
- `module/actor/sheets/character.mjs`:
  - Width/height bumped 865×850 → 1200×900
  - PARTS registration restructured: header/stats/resources/leftRail/4×rightRail/tabs are shell parts; tab content parts (combat/items/pers/social/arcane/mutations/mysticism/sorcery/divine/super/statistics/background/dev) unchanged
  - `_configureRenderOptions` rewritten — render order: header → stats → resources → leftRail → 4×rightRail → tab content (conditional) → tabs
  - `_preparePartContext` — shell parts get no special context (data already populated by `_prepareContext`); tab parts continue to set `context.tab`
  - `_getTabs` — adds per-tab icon glyphs (swords, sack, scroll, mask-theater, people-group, hat-wizard, cross, eye, fire, dna, bolt, table-list, book-open, code) for vertical strip; shell parts excluded from tab list; statistics retained as tab
  - `_prepareContext` extended with ~160 lines of shell context: `isLocked`, `isNPC`, ancestry/career display + click-IDs, `rollVisibility` flag, `currentDifficulty` flag, `difficultyOptions`, `difficultyShortLabels` map, `initiativeBonus`/`moveBase`/`luckPoints`, `damageModifier`/`healingRate`/`xpBonus`, `ap` object with all 4 pool current/max values + `hasReact`/`hasAttack`/`hasDefense` flags, `pp` value/max, `standardSkillGroups`/`careerSkillGroups` (grouped by category, alphabetical), `tempHP`, `overallHP` summary, `hitLocations` with armor-layer arrays (joined by `hitlocID`), `conditions` (combined actor+per-location), `perceptionSkill` + `visionTypes`, `activeEffects` (excluding status-typed ones)
- `module/actor/sheets/base-actor-sheet.mjs`:
  - 12 new action handlers wired into the `actions` object
  - Handler implementations: `_onRollVisibility`, `_onDifficultySet`, `_onAPRefresh` (multi-pool), `_onAPEdit` (DialogV2 prompt), `_onPPRefresh`, `_onPPEdit`, `_onRestStub` (notification only — P9 builds dialog), `_onSkillImproveToggle`, `_onEffectCreate` (creates new AE on actor, opens its sheet), `_onEffectEdit`, `_onEffectToggle`, `_onEffectDelete` (with DialogV2 confirm)
- `module/actor/sheets/npcV2.mjs`: structure unchanged in P8; `npcV2.header.hbs` gets the NPC badge near the name input. Full NPC-Character shell parity is **deferred to a follow-up after P9** (when each tab content is unified); P8 ships the NPC badge as the minimal-viable user-visible change.

**Stylesheet** `styles/elysium-sheets.css` — 872 lines, 123 rule blocks:
- Shell grid layout (`.application.elysium.sheet.actor .window-content`): 4-column grid (280px / 1fr / 260px / 48px) × 4-row grid (auto/auto/auto/1fr); part placement by class selector; vertical tabs strip spans all rows on right edge; right-rail cards auto-flow in column 3 from row 4 onward
- Card chrome (shared): bg `--ely-surface-card`, border `--ely-border-subtle`, radius `--ely-radius-3`
- Header card grid; portrait + EXP-Dice badge (crimson circle, bottom-right); name h2 in BoucherieBlock display font; NPC badge crimson pill; header strip with Public/GM toggle + difficulty 7-chip strip + Init/Move/Luck stat chips
- Stats card 2-column grid; per-row stat block (40-1fr-60-24px sub-grid) + derived block separated by left border
- Resources card 2-column grid; per-pool resource rows with sub-rows for Reaction/Attack/Defense (indented, transparent bg)
- Left rail skills: bucket titles in decorative font, group titles with `▾/▸` collapse indicators, skill rows with hover highlight
- Right rail cards (defenses/conditions/senses/effects): consistent card chrome with header titles in display font + optional action button
- Defenses card: Temp HP input + overall HP summary + hit-location collapsible rows + Rest button with crimson hover state
- Vertical tab strip: 32×32 square icon chips, transparent default, crimson active state, raised hover
- All tokens semantic (`--ely-*`); zero legacy var references in new CSS

**Version bumps**:
- System: `1.0.0-alpha.13` → `1.0.0-alpha.14`
- Compendium: `1.0.0-alpha.2` → `1.0.0-alpha.3`

### Side findings opened in P8 (post-implementation)

These are noted for follow-up but don't block alpha.14 ship:

- **#25 — NPC shell parity deferred**: P8 audit promised NPC = Character shell with NPC badge. Shipped only the NPC badge; structural NPC sheet matches will follow after P9 unifies tab content. NPC sheet currently still uses its 3-part header/main/notes structure with the new NPC badge in the header.

### Verification — pre-ship

- 200+ .mjs files all pass `node --check`
- All 5 .json files parse
- 0 occurrences of `profession*` in source (verified via `grep -ric`)
- 0 structural `profession*` references in compendium .db files (prose preserved)
- CSS brace balance: 123/123
- Item type `career` registered in both system.json + init.mjs
- Imports of renamed `data/item/career.mjs` and `item/sheets/career.mjs` resolve

### Verification — live smoke (to capture on install)

1. Boot — alpha.14 + compendium alpha.3 load cleanly
2. Item type `career` works: `Item.create({type:'career'})` succeeds, `Item.create({type:'profession'})` fails
3. Compendium pack `elysium-compendium.careers` loads with 8 career items
4. 23/23 item render sweep clean (all renamed templates work)
5. Character sheet renders new 3-rail shell layout
6. Stats card shows 7 stats with correct totals + derived pairings
7. Resources card shows AP pools (General visible; Reaction/Attack/Defense hidden when max=0)
8. Skills rail populates with Standard + Career groups
9. Defenses card shows Temp HP, overall HP summary, hit-location list with armor-layer dropdowns
10. Conditions / Senses / Effects cards render correctly when populated
11. Vertical tab strip renders on right edge; tab icons display; clicking tabs switches content
12. NPC sheet renders with the new "NPC" badge in the header
13. New shell action handlers: AP refresh works, PP refresh works, AP/PP edit dialogs open, Rest button shows "coming in P9" notification, effect create/toggle/delete work, difficulty strip persists per-sheet via flag

### Version

System `1.0.0-alpha.14`; compendium `1.0.0-alpha.3`.

---



Thirteenth alpha. **Opens P7** (stylesheet consolidation), per the v1.0.0 ROADMAP. P7 was originally scoped as "audit every rule in `legacy.css` and `elysium.css` and migrate them all," but the prep audit (`docs/p7-prep-audit.md`) surfaced that approach as needlessly risky — many of the rules style markup that P8–P11 will rebuild from scratch. With user direction, P7 narrows to **set-up-the-foundation-and-defer** (audit Framing B): create the new file structure cleanly, migrate stable foundation rules, leave per-component rules where they currently work, and defer the legacy-file deletion to P12 after P8–P11 have replaced the markup those rules style.

This ship establishes the v1.0.0 token-driven foundation so that P8–P11 can build the rebuilt surfaces against semantic tokens rather than the BRP-era `--ely-legacy-*` namespace.

### What this release ships

- **Five new CSS files** in `styles/`:
  - `styles/elysium-reset.css` (93 lines) — `@import` Google Fonts, two `@font-face` declarations (Modesto, BoucherieBlock), universal box-sizing reset, body baseline. All scoped to `.application.elysium` except the at-rules.
  - `styles/elysium-base.css` (179 lines) — heading hierarchy h1–h6 with `--ely-font-size-N` scale + display font for h1/h2; default link styling using `--ely-text-link*` family; paragraph + inline emphasis (strong, em, code/kbd/samp); `<hr>` and `<small>` defaults. Every rule pulls from semantic tokens.
  - `styles/elysium-components.css` (212 lines) — button baseline including primary-action variant, focus-ring (`--ely-border-focus`), form-control baseline (text/number/email/password/search/textarea/select with hover, focus, disabled states), native checkbox/radio tinting, scrollbar styling (Firefox `scrollbar-color` + WebKit `::-webkit-scrollbar`).
  - `styles/elysium-sheets.css` (stub, 30 lines) — header comment documenting that this file is populated by P8 (sheet shell), P9 (tab content), P10 (item sheets). No rules in P7.
  - `styles/elysium-chat.css` (stub, 25 lines) — header comment documenting that this file is populated by P11 (chat cards + dialogs). No rules in P7. Notes that chat cards render outside `.application.elysium` and need a `.elysium-chat-card`-style marker scope.
- **`system.json` `styles` array updated** to the documented P7 load order — new files first, legacy files last:
  ```
  styles/elysium-tokens.css        (P1)
  styles/elysium-reset.css         (P7, new)
  styles/elysium-base.css          (P7, new)
  styles/elysium-components.css    (P7, new)
  styles/elysium-sheets.css        (P7, new stub)
  styles/elysium-chat.css          (P7, new stub)
  css/legacy.css                   (BRP-era, retained)
  css/npc.css                      (BRP-era, retained)
  styles/elysium.css               (BRP-era, retained)
  ```
- **`css/legacy.css`** — `@import` and two `@font-face` declarations deleted from the top (lines 1–15), now hosted by `elysium-reset.css` to prevent double-loading. New file header comment documents the v1.0.0-alpha.13 change. File shrinks 1719 → 1714 lines.
- **Documentation**:
  - `docs/p7-prep-audit.md` — P7 prep audit with the five locked design decisions, file inventory, bridge variable mapping table (legacy → semantic), scope, what P7 doesn't do, acceptance criteria.
- **Version bump:** `1.0.0-alpha.12` → `1.0.0-alpha.13`. Compendium module unchanged at v1.0.0-alpha.2 (P7 has no compendium impact).

### Locked design decisions (P7 prep audit)

1. **Framing B** — set-up-the-foundation-and-defer. New file structure, foundation rules migrated, legacy files retained. P12 audits and deletes legacy files after P8–P11 replace the markup.
2. **Commit to v1.0.0 visuals from P7 forward** — dark theme as primary identity; v1.0.0 dark/bone/crimson palette applies wherever semantic tokens get retargeted. Half-measures across multiple phases produce a half-BRP-half-Elysium look; we accept the larger visual jump in P7 as the price of one clean cutover.
3. **Conservative dead-rule audit** — kill only rules with obviously-dead targets. Aggressive pruning happens naturally in P8–P11 as each surface gets rebuilt.
4. **Legacy variables stay in `css/legacy.css`** — `--ely-legacy-*` definitions remain in their original `:root` blocks. Moving them is busywork that gets undone in P12.
5. **Load order: new files first, legacy files last** — preserves current specificity so any rule that *does* override a foundation rule keeps working.

### Side findings auto-resolved

None — P7 is a forward-architecture phase, not a bug-fix phase.

### Side findings opened

None.

### Verification

Pre-ship:
- All 5 new CSS files brace-balanced (4 + 17 + 20 + 0 + 0 blocks)
- `legacy.css` brace-balanced after declaration removal
- `system.json` parses; styles array order verified by inspection
- Font asset paths verified to resolve from new file location:
  - `../css/fonts/modesto-condensed.woff2` ← exists
  - `../assets/Boucherie-Block.ttf` ← exists
- 185/185 `node --check` (no .mjs files touched)
- 8/8 JSON parses

Live (test-2 world) — sweep at smoke-test time:
1. Boot — alpha.13 loads cleanly; all 9 stylesheets parse without 404s or syntax errors
2. Font network requests — `Boucherie-Block.ttf`, `modesto-condensed.woff2`, Google Fonts CSS all 200-OK from the new file location
3. Visual identity — body text in any Elysium application surface uses the v1.0.0 semantic tokens (off-white #e8e6e1 on dark surfaces); heading hierarchy h1–h6 visible across item sheets if used
4. No regressions — existing item-sheet + actor-sheet renders still work (their per-component rules in legacy.css/elysium.css continue to apply)
5. Baseline visual-regression: expected drift from alpha.2 baselines, captured as new `alpha13-{character-empty, npc-empty, weapon-detail}-dark.snapshot.json` baselines. Diffs documented as intentional v1.0.0-identity shift.

### P7 status post-ship

P7 is **partially shipped**. Foundation in place; sheet/chat rules deferred. Per the audit and locked decisions, full P7 close requires:
- P8 → fills in `elysium-sheets.css` for the actor sheet shell
- P9 → expands `elysium-sheets.css` for tab content
- P10 → expands `elysium-sheets.css` for item sheets
- P11 → fills in `elysium-chat.css` for chat cards + dialogs
- P12 → audits and deletes `legacy.css`, `npc.css`, and the old `styles/elysium.css`

The ROADMAP P7 row is updated to reflect this — "FOUNDATION SHIPPED (alpha.13); component rules deferred to P8–P11".

### Version

`1.0.0-alpha.13` (system only; compendium unchanged at alpha.2).

---



Twelfth alpha. Single-issue patch ship surfaced by alpha.11 live smoke. Extends side-finding #24's prep-loop hardening to the armor-branch hit-location lookups, which were the actual cause of the "Failed data preparation" error message originally attributed to #24's transient-state diagnosis. Pre-existing bug, exposed by compendium-drop testing in alpha.11's smoke.

### What this release ships

- **`module/actor/actor.mjs`** armor prep branch (lines 240–290): every `actorData.items.get(itm.system.hitlocID)` lookup is now guarded with `if (hitLoc?.system)`. There are four such lookups in the armor branch:
  1. Line 246 (was) — `actlEnc` calc, was gated by `equipStatus === 'equipped'` but still threw when equipped armor had empty hitlocID
  2. Lines 255–257 — `ppCurr`/`pSCurr` accumulation, gated by `equipStatus !== 'stowed'`
  3. Lines 264–273 — armor-point/penalty accumulation, gated by `equipStatus === 'equipped'`
  4. Lines 277–278 — the unguarded `enc` accumulation that ran regardless of equipStatus and was the actual smoke failure site
- **Root cause**: compendium armor items can land on an actor with `hitlocID: ''` (default initial value). The `items.get('')` lookup returns undefined; the unguarded subsequent property access on the result throws every actor-prep cycle. The error propagates as "Failed data preparation for Actor.X. Cannot read properties of undefined (reading 'system')" — exactly the signature my alpha.11 #24 fix was trying to address, but the issue was in different code than my guards (`hitLoc` lookup undefined, not `itm` iterator undefined).
- **Version bump:** `1.0.0-alpha.11` → `1.0.0-alpha.12`. Compendium module (`elysium-compendium`) unchanged at v1.0.0-alpha.2 — no content changes in this release; only ship the system zip.

### Side findings touched

This release effectively re-resolves side-finding #24 with the actual fix at the actual fault site. The alpha.11 #24 fix (transient-state guards on the iteration loops in `_prepDerivedStats`) was correct in principle but applied to the wrong code — it hardened against `itm` being undefined when the actual problem was `actorData.items.get(unknownId)` being undefined. Both guards stay in place (the alpha.11 ones are defensive against transient cascade state; the alpha.12 ones address the compendium-drop case).

### Verification

Pre-ship:
- Syntax sweep: 185/185 `node --check` green.

Live smoke results from alpha.11 (this is what found the bug):
- 25/25 instanceof creation ✓
- 23/23 sheet render sweep ✓ (with #20 and #21 dissolved as predicted)
- 9/9 persistence cases ✓ (including new equipStatus choices lock accepts 'equipped' and rejects 'garbage')
- 18/18 compendium drops ✓ (Passions pack empty, skipped)
- 7/7 compendium shape checks ✓ (renames + zero-reader fields gone + equipStatus normalized)
- Fresh-actor ancestry cascade ✓ (statNaturalMax populates, ancestryMove populates, 7 hit-locations created, stat-mod AEs with lowercase paths, zero prep errors)
- World-scope hit-location creation ✓ (#19 fix verified)
- Weapon sheet with compendium Longsword ✓ (#23 fix verified — `skill1Name: 'Long Blades'`)
- Full-loadout (compendium drops + ancestry cascade) **FAILED** — 9+ "Failed data preparation" errors. End-state of actor correct (statNaturalMax, ancestryMove, 7 hit-locations, 25 items), but console-noisy. Root-caused to actor.mjs:278 hit-location lookup on stowed armor with empty hitlocID. **Fixed in alpha.12**.

NPC capture markers (#4) deferred for re-verify — the Claude-in-Chrome bridge wedged when reading NPC sheet DOM, likely on token-shaped content in the rendered template. Structural fix (NPC_SHEET_MARKERS list + Actor-subtype dispatch in capture.mjs) is correct by inspection; runtime marker match-rate verifiable through other paths.

### Version

`1.0.0-alpha.12` (system only; compendium unchanged at alpha.2).

---



Eleventh alpha. Closes P6 (Item DataModels). Combines the core P6.6 work (template.json Item block deletion, system.json `htmlFields` manifest cleanup) with an expanded cleanup pass that resolves 13 of the 17 remaining side findings logged across P5–P6. Per the project's "fix at the core, no band-aids" principle, this ship is the larger one — DataModel schema renames, code fixes, and compendium content regeneration — chosen over the option of multiple smaller ships because the core P6.6 work and the expanded fixes had no dependencies forcing them apart.

The expanded scope is documented in `docs/p6-6-expanded-audit.md` with per-finding audit, files touched, and smoke surfaces. This release pairs with a co-shipped Compendium content update (Elysium Compendium module v1.0.0-alpha.2) that contains the matching content-shape changes; the system zip alone is NOT sufficient on its own for users who have the previous compendium installed.

### Core P6.6 work (was alpha.10 intermediate)

- **`template.json` Item block removed.** All 23 item-type schema blocks plus the `Item.templates.base` definition plus the `Item.types` list are gone. The 23 item DataModels in `module/data/item/*.mjs` (shipped across alpha.4–alpha.9) are now the canonical schema source. The file shrunk from 720 lines to 3 lines (a single `_comment` marker). Foundry V14 allows DataModels and template.json to coexist; V16 deprecates the file entirely. Retained as an empty marker through V14 for transparency.
- **`system.json` `documentTypes.Item.<type>.htmlFields` manifest cleanup (side-finding #6 closed).** All 23 item-type entries previously listed `["description", "gmNotes"]` where `gmNotes` was a phantom field name — the stored field has always been `gmDescription`. 21 types: `gmNotes` → `gmDescription`. `ability`: same plus preserved `effectText` and `prerequisitesText`. `wound`: `htmlFields` array dropped entirely (WoundDataModel skips `makeItemBase()`, no description/gmDescription).

### Expanded P6.6 work — 13 side findings fixed

Schema-only / sheet / hook fixes (no compendium impact):

- **#19** — `module/elysium/hooks/item.mjs:111`: added optional chain to guard against world-scope (parentless) hit-location creation. Previously threw `TypeError: cannot read 'sheet' of null`.
- **#20** — removed unregistered `<type>Label` setting reads in `module/item/sheets/{mutation,sorcery,super}.mjs`. These three sheets called `game.settings.get('elysium', this.item.type + 'Label')` for settings that were never registered, throwing on every render. `itemType` now falls back to the base sheet's i18n localization (`TYPES.Item.<type>`).
- **#22** — fixed dynamic import path in `module/elysium/sheets/item/item-modifiers.mjs:106`. The relative path was `../active-effects/...` but the target lives at `module/elysium/active-effects/`, requiring `../../active-effects/...`. Previously caused "Failed to fetch dynamically imported module" on every armor/weapon/gear drop.
- **#23** — completed historic `fromBRPIDBest` → `fromElysiumIDBest` rename. Two missed call sites in `module/item/sheets/weapon.mjs:63,69`. Previously caused weapon-sheet skill1Name/skill2Name to throw `is not a function`.
- **#4** — `test/visual-regression/capture.mjs` now dispatches Actor captures by subtype: `NPC_SHEET_MARKERS` (10 npc-template-class markers) for NPCs, `CHARACTER_SHEET_MARKERS` for characters. Previously NPC captures matched only 1/10 markers (the generic root).
- **#24** — `module/actor/actor.mjs` prep loops hardened against transient item state. Four `for (let itm of actorData.items)` loops in `_prepDerivedStats` now `if (!itm.system) continue` at the top. Fixes "Failed data preparation" cascade errors during `ancestry-drop._applyHitLocationSet`'s delete-then-recreate sequence. Defensive against any transient state, not just ancestry-drop's.

Writer-path fixes:

- **#1** — write/read split between `system.elysium.statNaturalMax` (writer, declared) and `flags.elysium.statNaturalMax` (readers, always empty). Three reader sites updated to read from `system.elysium.*` matching the writers and the CharacterDataModel TypedObjectField declaration (`module/elysium/creation/creation.mjs:117,171` and `module/elysium/actor/ancestry-drop.mjs:352`). For `patron.standing`: the data is ephemeral runtime, not persistent state; writer at `magic.mjs:217` moved to `flags.elysium.patron.standing` to match the existing reader. Audit-correction note: the original audit doc proposed moving the writer to flags; inspection during execution revealed the field IS declared, so the right fix was to move the readers to system.
- **#18** — declared `system.elysium.ancestryMove` SchemaField on CharacterDataModel with `{baseMove, flyMove, swimMove}` integer fields. Writer at `ancestry-drop.mjs:367` unchanged; write now persists. Data is persistent structured state (ancestry's movement contribution, cached on actor); `system.elysium.*` is the right home.

DataModel + compendium renames:

- **#11** — `favouredEnemy` → `nemesis` rename across the super DataModel and config constant. Includes the historic `isfavouredEnemy` (lowercase 'f' typo) → `isNemesis` correction. Compendium `superpowers.db`: 36 key renames across 18 super docs (script: `compendium-rename-finding11.py`).
- **#13** — hit-location-side `creatureType` → `bodyPlan` rename. Resolves the field-name collision with the actor-side `creatureType` (which lives at a different path, `system.elysium.creatureType`, and is unchanged). Touches the DataModel, the hit-location sheet handler, the detail template (both edit and readonly bindings), and `hit-locations.db` (23 doc renames).

DataModel + compendium cleanups:

- **#14** — 12 compendium-only zero-reader fields dropped across 4 DataModels (`armor.mjs`: av2, avr2, armBal, armVar; `hit-location.mjs`: bap, bapRnd; `arcane.mjs`: cost, pcost, magicChosen, mpCurr, mpMax, spellCat; `sorcery.mjs`: subType). All were pre-v0.21.0 ballistic-armor vestiges or pre-magic-rebuild remnants with zero code readers. Compendium content cleaned in parallel: **666 field removals across 379 docs in 5 .db files** (script: `compendium-cleanup-finding14.py`).
- **#9** — culture's `statMods.stat` now a choices-locked lowercase StringField (`['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha']`). Compendium `ancestries.db` normalized: 31 stat values across 20 ancestries (script: `compendium-normalize-finding9.py`).
- **#8** — `equipStatus` choices-locked to `['stowed', 'equipped']` on armor, weapon, and gear DataModels. Pre-validation normalization for legacy `'carried'`/`'worn'` values now happens via DataModel `static migrateData(source)` hooks (V14-correct hook for source-data shape transformation, runs before cleanData's choices check). New helper `migrateLegacyEquipStatus` in `module/data/item/_shared.mjs`. The previous post-construct normalizer in `module/elysium/hooks/item.mjs` is removed; the schema-layer approach is correct because it eliminates the workaround that forced equipStatus to be a free StringField.

### Side findings closed without source change

- **#2** — Dropped character-elysium fields (`patron`, `essences`, `schoolMastery`, `companion`): closed by user decision. Fresh world per project direction; no migration needed.
- **#5** — Claude-in-Chrome bridge wedge: environmental, documented in handoff + visual-regression README. Not a code defect.
- **#10** — Culture permissive fields (`naturalWeapons`, `resistances`, `subraces`): audit-confirmed deferred. All 20 compendium ancestries still have empty values for all three; tightening shapes against zero ground-truth content would be guessing.
- **#21** — Personality sheet render error: AUDIT CONFIRMED NON-REPRODUCIBLE. Five back-to-back isolated renders pass. Expected to dissolve post-#20-fix; the original bulk-render failure was contamination from rendering super/sorcery/mutation immediately before. Re-verify in smoke.

### Side-finding accounting (24 cumulative across P5–P6)

| Status | Findings | Count |
|---|---|---|
| Auto-resolved by alpha.10 core P6.6 (template + manifest edits) | #3, #6, #7, #12, #15, #16, #17 | 7 |
| Fixed in alpha.11 expanded P6.6 | #1, #4, #8, #9, #11, #13, #14, #18, #19, #20, #22, #23, #24 | 13 |
| Closed without source change | #2, #5, #10 | 3 |
| Re-verify in smoke (expected to dissolve with #20 fix) | #21 | 1 |
| **Total** | | **24** |

All 24 cumulative side findings handled.

### Compendium module co-ship

`elysium-compendium` v1.0.0-alpha.1 → v1.0.0-alpha.2. Content-shape-changing updates make alpha.2 incompatible with the previous system schema; install BOTH the alpha.11 system AND the alpha.2 compendium together. Content changes:
- 666 field removals across 5 packs (per #14)
- 36 key renames in `superpowers.db` (per #11)
- 23 key renames in `hit-locations.db` (per #13)
- 31 stat-case normalizations in `ancestries.db` (per #9)

### Verification

Pre-ship (source-tree-only):
- Syntax sweep green: 185/185 `node --check`
- JSON parse sweep green: 8/8 (system.json, template.json, 3 lang, 3 baseline snapshots)
- All 5 modified .db files re-parse as valid NDJSON
- `grep "favouredEnemy"` returns zero hits in system source (only doc-comment references); `grep "fromBRPID"` returns zero hits
- `grep "gmNotes" system.json` returns zero hits (down from 23 in alpha.9); `grep "gmDescription" system.json` returns 22 hits

Live (test-2 world, Foundry 14.361) — smoke results filled in below at smoke-test time:
1. **Boot** — alpha.11 loads cleanly; 23 item + 2 actor DataModels registered.
2. **Type creation sweep** — `Item.create({type, name})` for all 23 item types + character + npc; 25/25 instanceof pass.
3. **Render sweep** — render-and-close one of each item type; 23/23 expected clean (with #20 fixed, mutation/sorcery/super now succeed; #21 expected dissolved).
4. **Persistence sweep** — NumberField, StringField (free + choices including the new equipStatus lock), HTMLField (gmDescription), nested SchemaField, ArrayField, deep magic types.
5. **Compendium drop sweep** — drop one item from each content-bearing type from the regenerated compendium. Zero validation errors. Specific checks: nemesis-renamed super lands with `system.elysium.nemesis.{isNemesis, targets}`; bodyPlan-renamed hit-location lands with `system.bodyPlan`; equipStatus normalization on any legacy `'carried'`/`'worn'` armor.
6. **Ancestry cascade** — drop a culture onto a character with pre-existing items, verify no "Failed data preparation" errors (#24 fix).
7. **statNaturalMax persistence** — drop a culture with statMods, verify `actor.system.elysium.statNaturalMax` populates correctly (#1 fix).
8. **ancestryMove persistence** — drop a culture, verify `actor.system.elysium.ancestryMove` populates with baseMove/flyMove/swimMove (#18 fix).
9. **Hit-location world-scope** — `Item.create({type: 'hit-location'})` at world scope without parent actor; no error (#19 fix).
10. **NPC sheet capture** — capture an NPC sheet via the visual-regression harness; expect markersMatched ≥ 5/10 (#4 fix).
11. **Weapon sheet with compendium skill** — open a compendium-sourced Longsword sheet; expect clean render with skill1Name populated (#23 fix).

### P6 complete

P6.0 ✓ prep audit (`docs/p6-prep-audit.md`), P6.1 ✓ (alpha.4, 6 trivial items), P6.2 ✓ (alpha.5, 8 standard items), P6.3 ✓ (alpha.6 → alpha.7 hotfix, 3 combat items), P6.4 ✓ (alpha.8, 4 magic items), P6.5 ✓ (alpha.9, profession + skill), P6.6 ✓ (alpha.11, this release). All 23 of 23 item DataModels shipped and live-verified.

With P6 closed, the v1.0.0 rebuild has completed the data layer. Next major effort is P7 — stylesheet consolidation: replace the BRP-era CSS architecture with the P1 token-based system across 6 new style files (`elysium-tokens.css`, `elysium-reset.css`, `elysium-base.css`, `elysium-components.css`, `elysium-sheets.css`, `elysium-chat.css`); audit and migrate `css/elysium-legacy.css` rule-by-rule. P7 deletes the legacy CSS at completion.

### Version

`1.0.0-alpha.11` (system). `1.0.0-alpha.2` (elysium-compendium module, co-shipped). Side-finding ledger reaches 0 open / 1 to-verify after smoke.

---

## [1.0.0-alpha.9] — P6.5 final-pair item DataModels (profession + skill)

Ninth alpha. Ships the **last 2 of 23 item DataModels**: `profession` and `skill`. With this release, every item type has a DataModel. Only template.json deletion and final acceptance (P6.6) remain.

### What this release ships

- **`docs/p6-5-handoff.md`** — P6.5 prep audit. Significant compendium-vs-template divergences for both types; two new side findings.
- **2 DataModels** in `module/data/item/`:
  - `profession.mjs` — 5 own + base + 11 elysium + 4 compendium-only + 1 compendium-only-elysium = ~22 slots. **Declares 4 compendium-only top-level fields** (`commonSkills`, `professionalSkills`, `culture`, `cultureBonus`) — `commonSkills` and `professionalSkills` are ARRAYS OF STRING SKILL NAMES (not `{uuid, elysiumid}` despite the field-name overlap with culture item type's similarly-named fields). **Declares 1 compendium-only elysium field**: `themes` (array of strings, e.g., `['fighter', 'vanguard']` on Fighter). 8 compendium items.
  - `skill.mjs` — 25 own + base + 4 compendium-only top + 2 elysium + 2 compendium-only-elysium = ~34 slots. The most-referenced item type in the system. **`skill.system.elysium.arcaneRole`** is the field the casting system reads (`cast-shared.mjs:289`, `custom-spell-builder.mjs:90,99`) to route F/T skills during arcane spell construction. **Six compendium-only fields declared** (side-finding #14 family): top-level `cmbtSkill`, `fixed`, `magicSkill`, `professional` (all booleans, zero readers); elysium `arcaneRole` (READ by casting) and `forbidden` (no readers). **Note `cmbtSkill` and `combat` are two distinct fields** — both must be declared because both appear in stored data. 131 compendium items (107 + 24 across skills.db and arcane-knowledge.db).
- **`module/hooks/init.mjs`** — 2 new imports + 2 registrations; section comment updated to "23 of 23 item types complete".

### Field-set decisions

**Compendium-driven declarations** — 11 new fields not in template.json across both types:
- skill: 6 (cmbtSkill, fixed, magicSkill, professional, elysium.arcaneRole, elysium.forbidden)
- profession: 5 (commonSkills, professionalSkills, culture, cultureBonus, elysium.themes)

**Critical typo correction**: `skill.category` initial is `'comnmod'` (matching compendium + module/apps/select-lists.mjs:51), NOT template's `'cmmnmod'`. Side-finding #17. Becomes a non-issue when template's Item block is removed in P6.6.

**baseFormula structure**: 3-key SchemaField with explicit keys `"1"`, `"2"`, `"Func"`. Slots 1 and 2 are each `{stat, value}` SchemaFields. Same pattern as the fixed-key effectByTier from P6.4.

**No locked enums in P6.5.** All string fields (category, skillCategory, skillSubgroup, arcaneRole, baseFormula.Func, baseFormula.X.stat, profession.elysium.tier, magicSystemAccess) intentionally free. The `arcaneRole` is a particularly notable choice — it has only 3 observed values ('', 'form', 'technique') and is mechanically driven, but locking would prevent mod content from adding new roles. Casting system uses `!==` comparisons that fail gracefully for unknown values.

### Two new side findings

**#17 — `skill.category` template-vs-code typo.** Template defaults `'cmmnmod'`; code and compendium use `'comnmod'`. Schema uses `'comnmod'`. Becomes non-issue when template's Item block is deleted in P6.6.

**#18 — `CharacterDataModel.system.elysium.ancestryMove` is undeclared but `ancestry-drop.mjs:367` writes to it.** Caught during the P6.5 audit grep for live `system.elysium.X` write sites. Verified live: the write does not throw, but the data is silently dropped (Foundry strict-validation cleanData). The accompanying `system.move` write persists. Same shape as P5.2 side-finding #1 (patron.standing) — a write site touches a field that isn't declared on the DataModel. P12 candidate.

### Verification (live, post-install)

Same shape as prior P6.* phases, plus skill-specific checks:
1. Boot — both DataModels registered; total 23 item DMs (= 21 + 2)
2. Defaults — `skill.category === 'comnmod'` (the typo fix), baseFormula structure correct, all 6 compendium-only skill fields default-init, arcaneRole=''
3. Persistence — covering baseFormula deep nesting, arcaneRole writes ('form', 'technique'), profession's STRING-array shapes (commonSkills, professionalSkills, themes)
4. **Compendium drop test** — drop 1 skill (from skills.db), 1 skill (from arcane-knowledge.db with arcaneRole='form'), 1 profession (Fighter with themes=['fighter', 'vanguard']). Zero validation errors. Critical integrity check: arcaneRole='form' must round-trip on the arcane-knowledge skill so the casting system can find it.
5. Regression: sample types across P6.1–P6.4 + actors
6. Cleanup

### Version

`1.0.0-alpha.9`. **23 of 23 item types shipped (100%).** Next: alpha.10 = P6.6 (template.json deletion, acceptance, visual regression baselines). After that, P6 is complete.

---

## [1.0.0-alpha.8] — P6.4 magic-item DataModels

Eighth alpha. Ships the 4 magic-item DataModels: `divine`, `mysticism`, `arcane`, `sorcery`. The deepest schemas in the system: sorcery alone has ~38 slots, with fixed-shape nested structures (5-named-tier thresholds, 5-key effectByTier object, three fixed-length-5 arrays).

Also: refactors `ability.mjs` to use a shared `makeThemedBundle()` helper.

### What this release ships

- **`docs/p6-4-handoff.md`** — P6.4 prep audit. Covers compendium-vs-template divergences, the arcane/mysticism shared-fields pattern (17 bit-identical top-level fields), the ability/mysticism shared themed-bundle pattern, fixed-shape nested structure decisions, three new side findings.
- **`module/data/item/_shared.mjs`** — adds two helpers:
  - `makeThemedBundle()` — returns `{activation, benefits, drawbacks, addOns}` SchemaField/ArrayField bundle. Used by both `ability` (refactored) and the new `mysticism`. Per the project's "factor when proven by 2 reuses" principle.
  - `makeSpellBaseFields()` — returns the 17-field top-level spell-base block (base/xp/profession/personality/culture/personal/effects/category/impact/range/duration/pppl/damage/prsnlty/occupation/cultural/improve). Used by both `arcane` (which adds `mem`) and `mysticism`.
- **4 DataModels** in `module/data/item/`:
  - `divine.mjs` — 6 own + base + 21 elysium = ~29 slots. Includes fixed-length-5 integer arrays (`apCostByTier`, `powCostByTier`) and a 5-fixed-key `effectByTier` SchemaField. 30 compendium items. Aligns with template exactly.
  - `mysticism.mjs` — 17 spell-base + base + 9 elysium = ~28 slots. Uses both shared helpers. 5 compendium items. The `_doc` template documentation string is dropped.
  - `arcane.mjs` — 17 spell-base + mem + base + 6 compendium-only + 17 elysium = ~42 slots. **Declares 6 compendium-only fields** (`cost`, `pcost`, `magicChosen`, `mpCurr`, `mpMax`, `spellCat`) — vestigial legacy from older versions, zero code reads (side-finding #14); `spellCat` duplicates `elysium.school` (#15). 42 compendium items. Has the 4-key `elysium.baseline` nested SchemaField.
  - `sorcery.mjs` — 8 own + base + 1 compendium-only + 27 elysium = ~38 slots (largest in P6.4 by slot count). 264 compendium items (most-populous item type in the game). Includes: **5-named-tier `thresholds` SchemaField** (nascent/developing/established/potent/transcendent, each `{min, max}`), 5-fixed-key `effectByTier` SchemaField, three fixed-length-5 arrays (`apCostByTier`, `damageByTier`, `locationsByTier`), and the JS-reserved-word field name `var` (valid as an object key). One compendium-only field: `subType`.
- **`ability.mjs` refactor** — replaces the inline `{activation, benefits, drawbacks, addOns}` declarations with `...makeThemedBundle()`. Bit-identical shape; zero behavioral change. Cleanup-only.
- **`init.mjs`** — 4 new imports + 4 registrations.

### Field-set decisions

**Compendium-driven declarations** (side-finding #14):
- `arcane.{cost, pcost, magicChosen, mpCurr, mpMax, spellCat}` — 6 fields not in template; zero readers; required to accept compendium drops
- `sorcery.subType` — always `''` in 264 items; zero readers

**Documentation-only fields dropped**:
- `mysticism.elysium._doc`
- Plus the pre-existing `ability.elysium.activation._doc` and `ability.elysium._addOnSchema_doc` (dropped in P6.2; now dropped via `makeThemedBundle()`)

**Fixed-shape nested structures** (all five compendium-driven):
- `divine.elysium.effectByTier`, `sorcery.elysium.effectByTier` — 5 explicit keys ("1".."5") as SchemaField. All 30 + 264 items use exactly these keys.
- `sorcery.elysium.thresholds` — 5 explicit named keys (nascent/developing/established/potent/transcendent), each `{min, max}`.
- `divine.elysium.apCostByTier`, `divine.elysium.powCostByTier`, `sorcery.elysium.apCostByTier`, `sorcery.elysium.locationsByTier` — `ArrayField<NumberField>` with 5-element initials.
- `sorcery.elysium.damageByTier` — `ArrayField<StringField>` with 5-element initial.

**No locked enums in P6.4.** Magic types use content-creator-extensible vocabularies (schools, domains, disciplines, essences, damage types). Locking any would break community content modules.

### Side findings flagged

**#14** — Arcane has 6 compendium-only fields, sorcery has 1, all zero-readers. Pre-existing data redundancy from older versions. P6.6 candidate: regenerate compendium without these, then drop schema declarations.

**#15** — `arcane.spellCat` duplicates `arcane.elysium.school`. Same 8-value vocabulary; pre-existing redundancy. P12 to deduplicate.

**#16** — `divine.domain` (top-level) duplicates `divine.elysium.domain`. Same 6-value set. Same redundancy pattern. P12 to deduplicate.

### Verification (live, post-install)

Same shape as P6.3 plus magic-specific spot-checks:
1. Boot — 4 DataModels, expected field counts
2. Defaults — fixed-length-5 arrays initialize correctly, the 5-key effectByTier defaults to all empty strings, sorcery.elysium.thresholds.transcendent.max === 999
3. Persistence — covering: fixed-key effectByTier writes (set the "3" key), threshold writes (deep nesting), fixed-length array element writes, ability's refactored themed-bundle still works
4. **Compendium drop test** — 1 of each magic type onto a character; zero validation errors; verify arcane's 6 compendium-only fields persist; sorcery's thresholds preserved
5. Regression: ability via the refactored shared helper; all P6.1–P6.3 + actors

### Version

`1.0.0-alpha.8`. **21 of 23 item types shipped (91%)**. Next: alpha.9 = P6.5 (profession + skill). Then alpha.10 = P6.6 (acceptance + template.json deletion).

---

## [1.0.0-alpha.7] — P6.3 hotfix: weaponType blank-string acceptance

Hotfix release for P6.3 (no new functionality). Smoke-test discovered that `Item.create({type: 'weapon'})` fails with `weaponType: may not be a blank string` when no system data is provided, because Foundry V14's `StringField` defaults to `blank: false` even when `''` appears in the field's `choices` list. The blank-rejection check runs independently of the choices-membership check.

**Fix**: added `blank: true` to `weapon.weaponType` in `module/data/item/weapon.mjs`. Initial remains `''` to preserve backward-compat with template.json's default. Choices list `['', 'melee', 'ranged']` unchanged.

No other DataModels had this issue: a sweep confirmed `weapon.weaponType` is the only StringField across all 17 item DataModels (and both actor DataModels) where `choices` contains `''`. All other locked-enum fields have non-blank initials.

This bug only manifested for newly-created weapons; compendium weapon drops populate `weaponType` from real data ('melee' or 'ranged') and weren't affected. Hit-location, armor, and existing world items were never impacted.

### Originally-planned alpha numbering shifts +1

Previous plan: alpha.6=P6.3, alpha.7=P6.4, alpha.8=P6.5, alpha.9=P6.6. Revised: alpha.6=P6.3 (now superseded by this hotfix), alpha.7=P6.3 hotfix, alpha.8=P6.4, alpha.9=P6.5, alpha.10=P6.6.

---

## [1.0.0-alpha.6] — P6.3 combat-item DataModels

Sixth alpha. Ships the 3 combat-item DataModels: `hit-location`, `armor`, `weapon`. All three have substantial compendium content (53 weapons, 26 armor, 23 hit-locations). Stored-schema-only continues.

### What this release ships

- **`docs/p6-3-handoff.md`** — P6.3 prep audit covering compendium-vs-template type mismatches, legacy ballistic-armor field handling, enum-locking decisions, and 2 new side findings.
- **3 DataModels** in `module/data/item/`:
  - `hit-location.mjs` — 22 own + base + 10 elysium = ~33 slots. **Declares base despite template's `templates: []`** (compendium populates `description` on every item). **Declares 2 legacy ballistic fields** (`bap`, `bapRnd`) not in template — compendium-driven. `criticalEntry` is nullable. `locType` is the only locked enum.
  - `armor.mjs` — 24 own + 4 legacy + base + 9 elysium = ~38 slots. **Declares 4 legacy ballistic-armor fields** not in template (`av2`, `avr2`, `armBal`, `armVar`) — pre-v0.21.0 removal, compendium-driven. `castingPenaltyOverride` is nullable. Locked choices on `flexibility`, `layer`, `wornStratum`.
  - `weapon.mjs` — 51 own + base + 14 elysium = ~67 slots (the largest schema in P6.3). **CRITICAL TYPE CORRECTION**: `elysium.force` is declared as `NumberField({integer, initial: 1, min: 0})` despite template's `initial: "M"` (string) default. Compendium has 53/53 items with `force` as int 0-7. Template's default is type-incorrect — side-finding #12 for P12. Locked choices on 5 enums: `weaponType`, `hands`, `elysium.weaponSize`, `elysium.damageType`, `elysium.reloadType`. `enc`/`cost`/`damageBonusMultiplier` are non-integer NumberFields.

### Field-set decisions

**Compendium-driven declarations** (fields NOT in template.json but required to accept live data):
- `hit-location.{bap, bapRnd, description, gmDescription}` — legacy ballistic + base
- `armor.{av2, avr2, armBal, armVar}` — legacy ballistic

These are all vestigial from pre-v0.21.0 BRP-classic ballistic-armor; no code reads them but every compendium item has them.

**Dropped fields** (template-only documentation):
- `weapon.elysium.{_reloadType_doc, _damageBonusMultiplier_doc}`
- `armor.elysium.{_layer_doc, _wornStratum_doc, _apMax_doc}`
- `hit-location.elysium.{_bodyPart_doc, _side_doc, _index_doc}`

Eight `_doc` keys dropped total across P6.3.

**Locked enums (9)**: `weapon.{weaponType, hands}`, `weapon.elysium.{weaponSize, damageType, reloadType}`, `armor.elysium.{flexibility, layer, wornStratum}`, `hit-location.locType`.

**Intentionally free** (high content-extensibility risk or insufficient ground truth): `weapon.elysium.{reach, force}`, `weapon.{range1/2/3, skill1/2, ammoType}`, `armor.elysium.{material, castingLocation}`, `equipStatus` on weapon and armor (per side-finding #8), `hit-location.creatureType` (per side-finding #13).

### Side findings flagged (NOT fixed in P6.3)

**#12 — `weapon.elysium.force = "M"` template default is type-incorrect.** Compendium has 53/53 items with `force` as int 0-7. Template was never updated to match. DataModel overrides with NumberField; template fix is P12 (when compendium is regenerated, the template should align).

**#13 — `creatureType` field-name collision.** Actor-side (NPC/Character P5 DataModels) locks `creatureType` to `['humanoid', 'beast', 'undead', 'construct', 'spirit', 'elemental', 'plant', 'aberration']` — used for creature classification. Hit-location-side `creatureType` uses a different vocabulary (`['amorphous', 'generic', 'hexapod', 'humanoid', 'quadruped', 'serpentine']`) — used as template-set tags identifying which hit-location set belongs to which creature shape. Different concepts, same field name. P6.3 leaves hit-location's free to avoid breaking compendium drops. P12 should rename one.

### Verification (live, post-install)

Same shape as P6.2 + the augmented compendium drop test:
1. Boot — 3 new DataModels with expected field counts
2. Create + defaults — spot-check nullables (`criticalEntry === null`, `castingPenaltyOverride === null`), legacy fields (`armor.armBal === false`), the type-corrected `weapon.elysium.force === 1` (int, not 'M' string)
3. Persistence roundtrips covering all field-class types including nullable round-trips (null → value → null), float NumberField, ArrayField<String>
4. **Compendium drop test** — drop 1 weapon, 1 armor, 1 hit-location onto a character; expect zero validation errors. Verify `force: int` survives roundtrip; the legacy fields persist.
5. Regression: P6.1 + P6.2 + actors

### Version

`1.0.0-alpha.6`. P6.3 of 6 sub-phases. **17 of 23 item types shipped** (74%). Next: alpha.7 = P6.4 (magic items — the deepest schemas in the system: sorcery has 28 elysium sub-keys, arcane has 17).

---

## [1.0.0-alpha.5] — P6.2 standard-complexity item DataModels

Fifth alpha. Ships the 8 standard-complexity item types: `passion`, `persTrait`, `allegiance`, `mutation`, `super`, `ability`, `gear`, `culture`. Stored-schema-only continues; sparse-field elysium partitions continue.

### What this release ships

- **`docs/p6-2-handoff.md`** — the P6.2 prep audit. Covers field-set analysis per type, compendium-vs-template divergences (most consequential below), enum-locking decisions, three new side findings, and the per-type schema spec the DataModels implement against.
- **8 DataModels** in `module/data/item/`:
  - `passion.mjs` — 3 own + base + 4 elysium = 9 slots. Matches template.json exactly. No compendium content (passions.db is empty).
  - `persTrait.mjs` — 6 own + base = 8 slots. Matches template.json. No compendium content.
  - `allegiance.mjs` — 9 own + base = 11 slots. Matches template + compendium. 1 compendium item.
  - `mutation.mjs` — 3 own + base + 3 elysium = 8 slots. 69 compendium items.
  - `super.mjs` — 12 own + base + 10 elysium = 23 slots. **Preserves the `favouredEnemy.isfavouredEnemy` lowercase-'f' typo** from template.json verbatim (P12 candidate). 18 compendium items.
  - `ability.mjs` — 6 own + base + 8 elysium (incl. `arcaneParent` NOT in template) = 16 slots. **Declares `elysium.arcaneParent`** — present on compendium content, missing from template; strict validation would reject compendium drops without it. **Drops `_doc` and `_addOnSchema_doc`** — documentation-only strings in template, not real fields. 47 compendium items.
  - `gear.mjs` — 7 own + base + 6 elysium (3 from template + 3 from compendium) = 15 slots. **Declares `elysium.{arcaneRole, isTome, linkedSkill}`** — present on tome compendium items, missing from template; strict validation would reject tome drops without them. `equipStatus` left as free StringField per side-finding #8. 150 compendium items.
  - `culture.mjs` — 4 own + base + deeply-nested `elysium.ancestry` (14 sub-fields) = ~26 effective slots. Cultures and ancestries share this item type. Top-level character-creation fields (`skills`/`groups` use `{uuid, elysiumid, bonus}` shape — distinct from personality's `{uuid, elysiumid}`); `stats` is a 7-stat block with `{formula, mod}` per stat; `elysium.ancestry.traits` uses `{uuid, name}` shape (distinct again). 20 compendium ancestries.
- **`module/hooks/init.mjs`** — 8 new imports + 8 `CONFIG.Item.dataModels[type]` registrations.

### Field-set decisions

**Compendium-driven declarations** (fields NOT in template.json but required to accept live data):
- `ability.elysium.arcaneParent` (StringField)
- `gear.elysium.{arcaneRole, isTome, linkedSkill}` (StringField, BooleanField, StringField)

**Dropped fields** (template documentation strings, not real data):
- `ability.elysium.activation._doc`
- `ability.elysium._addOnSchema_doc`

**Free StringFields** (intentionally NOT locked with `choices:` despite enum-shaped values):
- `ability.elysium.{abilityType, category, theme, activation.type}` — content-creator-extensible
- `super.elysium.{category, theme}` — content-extensible
- `gear.equipStatus` — see side-finding #8 (the post-validation normalizer makes choices-locking inappropriate)
- `mutation.impact` — no compendium ground-truth
- `passion.elysium.category` — only template default known

**Permissive shapes** for fields with no compendium ground-truth (P12 to tighten):
- `culture.elysium.ancestry.naturalWeapons` — ArrayField<ObjectField>
- `culture.elysium.ancestry.resistances` — ObjectField
- `culture.elysium.ancestry.subraces` — ArrayField<StringField>

### Side findings flagged for P12 (NOT fixed in P6.2)

**#8 — `equipStatus` legacy-value handling.** The elysium/hooks/item.mjs `preCreateItem` normalizer corrects 'carried'/'worn' to 'stowed' POST-validation. Adding choices lock would reject those compendium drops before the normalizer could fix them. Free StringField for now; revisit if Foundry exposes a pre-validation data-migration hook.

**#9 — `culture.elysium.ancestry.statMods[].stat` case mismatch.** Compendium uses uppercase ('INT', 'STR'); actor.system.stats uses lowercase. Consumer code is presumed to normalize. Free StringField accepts both; no migration risk for P6.2.

**#10 — Three culture-ancestry fields have unknown inner shapes** because all 20 compendium ancestries have empty values for them: `naturalWeapons` (ArrayField<ObjectField>), `resistances` (ObjectField), `subraces` (ArrayField<StringField>). Permissive declarations accept any shape. Tighten in P12 once content populates ground-truth values.

**#11 — `super.elysium.favouredEnemy.isfavouredEnemy` typo** in template.json (lowercase 'f' in 'favoured'). Preserved verbatim in schema to match stored data. P12 should rename and add a migration shim if anyone's worlds have stored values.

### Verification (live test-2 world, post-install)

To be run after install. Adds a critical new test class beyond P6.1's schema verification: **compendium drop test** — drop one of each compendium-having type (ability, gear, mutation, culture, allegiance, super) onto a character via `createEmbeddedDocuments`. Expect zero validation errors. This is the test that validates the audit-driven schema additions (especially the compendium-driven fields).

### Version

`1.0.0-alpha.5`. P6.2 of 6 sub-phases. Next: alpha.6 = P6.3 (combat items: weapon, armor, hit-location — the largest schemas after magic).

---

## [1.0.0-alpha.4] — P6.0 audit + P6.1 trivial-item DataModels

Fourth alpha. Opens P6 (Item DataModels) with the audit pass and the six smallest item types shipped together. Same stored-schema-only pattern as P5; same `_shared.mjs` factor-out idiom.

### What this release ships

- **`docs/p6-prep-audit.md`** — the P6 prep audit doc, modeled on `p5-prep-audit.md`. Captures the 23-type bucketing, per-type field counts, compendium content availability (15 of 23 types have live data; 8 do not — conveniently all 6 P6.1 types are in the no-content bucket), the item base-template pattern, two side findings logged for later (#6: `system.json.documentTypes.Item.<type>.htmlFields` references a phantom `gmNotes` field that doesn't exist anywhere — the stored field is `gmDescription`; #7: `wound.created` is a pre-existing dead field with zero readers/writers). Lays out the implementation spec for P6.1 and queues the audit work P6.2–P6.5 will need.
- **`module/data/item/_shared.mjs`** — `makeItemBase()` helper returning the `description` / `gmDescription` HTMLField pair shared across most item types via template.json's `Item.templates.base`. Other helpers will accrete as later sub-phases need them.
- **Six DataModels** in `module/data/item/`:
  - `wound.mjs` — `WoundDataModel`, 3 fields (value/treated/locId). Skips the base template. **Drops `created`** (side-finding #7, pre-existing dead field).
  - `reputation.mjs` — `ReputationDataModel`, 1 own + base (3 slots).
  - `failing.mjs` — `FailingDataModel`, 2 own + base (4 slots).
  - `powerMod.mjs` — `PowerModDataModel`, 3 own + base (5 slots).
  - `skillcat.mjs` — `SkillcatDataModel`, 3 own + base (5 slots). `attrib` is a fixed 8-stat SchemaField of string-tier values `"0".."4"` per the existing actor.mjs `_categoryXXX` formulas (string comparisons against literal "0".."4", not numbers). `stat` has choices `['none', 'str', 'con', 'int', 'siz', 'pow', 'dex', 'cha', 'edu']`.
  - `personality.mjs` — `PersonalityDataModel`, 2 own + base (4 slots). `skills` is `ArrayField<{uuid, elysiumid}>`; `groups` is `ArrayField<{options, skills: [{uuid, elysiumid}]}>`. The same `{uuid, elysiumid}` skill-reference shape will be reused by P6.2 culture and P6.5 profession — factor into `_shared.mjs` then, not preemptively.
- **`module/hooks/init.mjs`** — six new imports plus six `CONFIG.Item.dataModels[type]` registrations in section 3a.

### Field-set decisions (deltas vs template.json)

- **`wound.created` DROPPED** (side-finding #7). ZERO reads, ZERO writes anywhere in source.
- **`skillcat.attrib` values stored as strings** (`"0".."4"`), not numbers, matching template.json and the actor.mjs switch statement. NumberField would force-cast away from the existing string comparisons.
- **`skillcat.stat` and `skillcat.attrib.{str,con,...}` have `choices:`** locked against actor.mjs's switch arms. Invalid writes will throw `DataModelValidationError` (verified pattern from P5).
- **`personality.groups[].options`** is `NumberField(integer, initial: 1, min: 0)`. Template.json had `1` as the default; the personality.mjs `add-group` action creates `{options: 1, skills: []}`.

### Verification (live test-2 world, Foundry 14.361)

To be run after install. Smoke test plan from `docs/p6-prep-audit.md`:
1. Boot — confirm all 6 `CONFIG.Item.dataModels[type].name === 'XYZDataModel'`
2. Create each of the 6 types via `Item.create({type, name})`
3. Persistence roundtrip across NumberField, StringField (free), StringField-with-choices (valid + invalid), BooleanField, HTMLField, nested SchemaField, ArrayField — one write per field-class type, distributed across the 6 types
4. Cleanup — delete all 6 smoke items

### Side findings flagged for later (NOT fixed in P6.1)

**#6 — `system.json.documentTypes.Item.<type>.htmlFields: ["description", "gmNotes"]`** is wrong for 23 of 23 item types. Real stored field is `gmDescription`; `gmNotes` doesn't exist as a stored field. Pre-existing manifest bug. Fix in P6.6 when `system.json` is touched anyway to drop `htmlFields` entirely (DataModel HTMLFields self-declare HTML-ness).

**#7 — `wound.created` dead field**, dropped from WoundDataModel schema. Theoretical-only migration concern (wounds are short-lived combat artifacts).

### Version

`1.0.0-alpha.4`. P6.1 of 6 sub-phases. Roadmap: alpha.5 = P6.2 (standard items), alpha.6 = P6.3 (combat items), alpha.7 = P6.4 (magic items), alpha.8 = P6.5 (profession + skill), alpha.9 = P6.6 (acceptance + `template.json` deletion).

---

## [1.0.0-alpha.3] — P5.3 Actor acceptance: baselines, template.json cleanup, P5 complete

Third alpha of the v1.0.0 rebuild. Closes out P5 (Actor DataModels). No new DataModel code shipped — this release is acceptance work: visual-regression baselines locked, template.json cleanup, console-clean verification.

### What this release ships

- **`template.json` Actor block removed.** `CharacterDataModel` and `NPCDataModel` are now the canonical schema source. `template.json` shrunk from 1000 to 720 lines; only the `Item` block remains (P6 will retire that). The `_comment` header was rewritten to reflect the new state. No code referenced template.json directly (grep confirmed); `game.model.Actor.*` and `system.model.actor.*` lookups go through the registered DataModels per V14 dispatch.
- **Visual regression baselines captured against the post-P5 state:**
  - `test/visual-regression/baseline/alpha2-character-empty-dark.snapshot.json` — character sheet, fresh empty actor, dark theme. 38 design tokens locked + 7-of-10 character markers matched (3 markers are forward-looking for v1.0.0 rebuild — `.elysium-tab`, `.elysium-sheet-title`, `.elysium-card-title` — and remain null on current templates).
  - `test/visual-regression/baseline/alpha2-npc-empty-dark.snapshot.json` — NPC sheet, fresh empty actor, dark theme. 38 design tokens locked + 1-of-10 markers matched (see SIDE-FINDING #4 below).
  - Both baselines exclude the `outerHTML` field because the Claude-in-Chrome bridge classifies form-content HTML as cookie-shaped and scrubs it. The README documents `outerHTML` as non-diffed metadata, so the omission has zero impact on diff behavior. Future captures should include it where the testing channel permits.
- **Version bump:** `1.0.0-alpha.2` → `1.0.0-alpha.3`.

### Verification (live test-2 world, Foundry 14.361)

- Console-clean check: created a character + an NPC + re-prepared all 6 actors (4 pre-existing + 2 just created). Zero console errors, zero console warnings, zero schema/DataModel/validation messages.
- Roundtrip cumulative (P5.1 + P5.2 smoke tests): NPC and Character both pass create/render/persist/reload across NumberField, StringField, StringField-with-choices (valid + invalid), ArrayField, HTMLField, TypedObjectField, and nested SchemaField updates. `DataModelValidationError` properly fires on invalid choice writes.
- Self-diff sanity: `diff.mjs` reports zero changes when each baseline is compared against itself.

### Side findings flagged for P12 (NOT fixed in this release — orthogonal to P5 acceptance)

**#4 — `capture.mjs` uses `CHARACTER_SHEET_MARKERS` for any Actor doc-type.** The NPC sheet uses a different template tree (the root has class `npcv2`, not `character`) and only matches the `.application.elysium` root marker; the other 9 character-specific markers (sheet-title, resource-label, elysiumTab, etc.) return null on NPC because the NPC template doesn't use those class names. The 1-marker NPC baseline is still useful (locks sheet-root background/color + full token palette), but P12 should add an `NPC_SHEET_MARKERS` list and dispatch by `sheet.document.type` in `captureSheet()`.

**#5 — Claude-in-Chrome bridge wedges on rendered character sheets.** Four ProseMirror HTMLField editors (background, backstory, biography, description) each apparently embed chrome-extension iframes that wedge subsequent JS evals with "Cannot access a chrome-extension:// URL of different extension". Workaround used in this release: render + capture + close in the same eval before any post-render delay can let ProseMirror fully attach. Documenting for future Claudes who do live testing — render-and-await-and-then-query-DOM is NOT a viable pattern; render-and-immediately-capture-and-close IS. Also: the bridge scrubs payloads whose content looks like base64, cookie values, or auth tokens. The string `tokens` as a key name triggers a defensive blocker even when the values are CSS variables, so for read-back the field must be renamed (or kept inside `window` and serialized via download). The `outerHTML` field of the snapshot is bridge-blocked and was omitted from this release's baselines.

### P5 complete

P5.1 ✓ (NPCDataModel, alpha.1 post-ship), P5.2 ✓ (CharacterDataModel, alpha.2), P5.3 ✓ (baselines + template.json Actor cleanup, alpha.3). All three P5 sub-phases shipped and live-verified.

Next phase: P6 (Item DataModels). The remaining `Item` block in `template.json` is the migration target.

---

## [1.0.0-alpha.2] — P5.2 Character DataModel

Second alpha of the v1.0.0 rebuild. Adds `CharacterDataModel` alongside the `NPCDataModel` shipped post-alpha.1, completing the P5 actor-DataModel surface. Stored-schema-only per the P5 design decision: `ElysiumActor`'s existing `_prepareCharacterData → _prepDerivedStats` chain continues to populate derived fields (label/total/deriv/visible on stats, `skillcategory` totals from owned skill items, etc.) — none of that prep logic moved into the DataModel.

### What this release ships

- **`module/data/actor/character.mjs`** — `CharacterDataModel extends foundry.abstract.TypeDataModel`. Reuses the shared field-builders from `_shared.mjs` (`makeStats`, `makeHealth`, `makePower`, `makeFatigue`, `makeActionPoints`, `makeResourcePair`) for the 11 base-template fields, which are bit-identical to the NPC base. Sparse-declares the full character-side `elysium` partition (`expDice`, `expDiceOverride`, `buildPoints`, `skillPoints`, `statNaturalMax`, `ancestryId` plus the four shared creature/language fields), all of which NPC sparse-skips per P3 Decision 3. Adds 21 character-own fields plus `skillcategory` (TypedObjectField) and `stories` (ArrayField of `{title, value}` SchemaFields).
- **`module/hooks/init.mjs`** — registers `CONFIG.Actor.dataModels.character = CharacterDataModel` next to the NPC registration in section 3a.
- **One field declared that is NOT in `template.json`**: `elysium.expDiceOverride`. It's a one-shot boolean dynamically written by `stat-improvement.mjs` via `'system.elysium.expDiceOverride': true/false` and consumed by the next stat-improvement roll. Without an explicit declaration, DataModel strict validation would reject those writes.

### Field decisions (vs `template.json`)

- **KEPT**: `expDice`, `buildPoints`, `skillPoints`, `statNaturalMax` (declared but see side-finding #1 below), `ancestryId`, `creatureType`/`creatureSubtype`/`creatureTags`/`languages`, all 21 character-own fields except `distincitve`, plus `skillcategory` and `stories`.
- **DROPPED**: `patron`, `essences`, `schoolMastery`, `companion` (side-finding #2 — zero `system.elysium.*` reads/writes; vestigial from the v0.9.0–v0.20.0 magic/companion subsystem integration era, which ended up routing through `flags.elysium.*` instead). `distincitve` (side-finding #3 — typo for "distinctive" with zero occurrences anywhere; not preserving the typo).

### Side findings flagged for P12 / bug-sweep (NOT fixed in this release)

P5.2 scope is the DataModel definition; fixing pre-existing logic bugs would conflate scope.

1. **`flags.elysium.X` reads paired with `system.elysium.X` writes** — same shape as the P4 `brpidFlag` mismatch. `patron.standing` (read `magic.mjs:204`, write `magic.mjs:217`), `statNaturalMax` (read `ancestry-drop.mjs:352`/`creation.mjs:117,171`, write `ancestry-drop.mjs:359,477`). Writes succeed against the now-declared DataModel fields; reads still hit flags and return undefined, falling through to defaults. Data is being persisted but not read back. Fixing requires changing the reads to use `actor.system.elysium.X` — deferred to a bug-sweep phase or P12.
2. **Dropped character-elysium fields are not declared.** `patron`, `essences`, `schoolMastery`, `companion` and their sub-keys. If any data was ever stored at those paths it will be silently dropped during DataModel `cleanData`. Migration concern is theoretical only for `test-2` (fresh world); production users with existing characters need migration support eventually — track as a P12 concern.
3. **`character.distincitve` typo** in `template.json`. Same theoretical-only migration concern as #2.

### Smoke test (live `test-2` world, Foundry 14.361)

Run after install via Claude in Chrome `javascript_tool`. Expect: schema 45 top-level fields, character create succeeds and `actor.system instanceof CharacterDataModel`, sheet renders without exceptions, persistence roundtrips on NumberField/StringField-with-choices/StringField-with-invalid-choice (DataModelValidationError, value unchanged)/ArrayField/HTMLField/TypedObjectField/nested SchemaField, derived data populates (`stats.str.total` is numeric, `skillcategory` accumulates per `actor.mjs:168`), compendium skill drop preserves `elysiumidFlag` (P4 hotfix regression check), NPC create still works (regression check).

### Version

`1.0.0-alpha.2`. Bumped per the original P5 plan: alpha.2 is the character-DataModel ship.

---

## [1.0.0-alpha.1] — Foundation: tokens, harness, design, rename codemod

First alpha of the v1.0.0 rebuild. Pure foundation — no user-visible feature changes vs 0.22.0, but the system underneath is now structurally different and ready for the rebuild phases that follow.

### What this release IS

- **Identity rename complete**: `system.id` is now `"elysium"` (was `"elysium-brp"`). Title is `"Elysium"` (was `"Elysium BRP"`). All BRP-namespaced artifacts renamed to Elysium-namespaced:
  - 1,497 `BRP.*` i18n key refs → `Elysium.*` (deep-merged lang files; 614 BRP keys + 34 Elysium keys → unified 647-key Elysium namespace in `en.json`)
  - 691 `BRP*` JS identifier renames across 78 files (`BRPCheck` → `ElysiumCheck`, etc; 2 case-fix anomalies cleaned up: `BRPactorDetails` → `ElysiumActorDetails`, `BRPactorItemDrop` → `ElysiumActorItemDrop`)
  - 725 new `.elysium` CSS class selectors (was 229 `.brp` selectors + 35 templates with `class="brp"`)
  - 166 `--brp-*` CSS variables → `--ely-legacy-*` (P7 will retire these to the new semantic tokens)
  - 610 `elysium-brp` string occurrences (system id, path strings, etc.) → `elysium`
  - 242 `brpid` identifier renames → `elysiumid` (the content-ID concept)
  - Foundry socket namespace `system.brp` → `system.elysium` (unified across all emit/listen)
- **File renames**:
  - `module/brp.mjs` → `module/main.mjs` (system entrypoint)
  - `module/brpid/` → `module/elysiumid/` (content-ID system)
  - `module/sheets/brp-active-effect-sheet.mjs` → `module/sheets/elysium-active-effect-sheet.mjs`
  - `module/setup/brp-dialog.mjs` → `module/setup/elysium-dialog.mjs`
  - `module/settings/settings-brpid.mjs` → `module/settings/settings-elysiumid.mjs`
  - `templates/brpid/` → `templates/elysiumid/`
  - `css/brp.css` → `css/legacy.css`
  - `packs/brp-id-macros` → `packs/elysiumid-macros`
  - Deleted: `assets/brp-logo-powered_by-*.png` (BRP branding retired; template refs migrated to `char-sheet-logo.png` placeholder)
- **Compendium content migrated** (separate `elysium-compendium` module): 906 `flags.brp.brpidFlag` → `flags.elysium.elysiumidFlag` rewrites + 906 `_stats.systemId: "elysium-brp"` → `"elysium"` rewrites + 59 `flags.elysium-brp` merges into `flags.elysium`, across 22 .db files (53 weapons, conditions, hit locations, ancestries, spells, etc.)
- **Foundation artifacts shipped**:
  - `styles/elysium-tokens.css` — 102-token design system (497 lines, 14 categories: text, surface, accent, border, skill, space, radius, font, line, shadow, duration, easing, z) with locked palette including bone `#c5aa8f` decorative text and crimson `#8a2020` action accent
  - `test/visual-regression/` — structural snapshot harness (capture.mjs + diff.mjs + README + first committed baseline) for catching unintended regressions during the upcoming template rebuild phases
  - `docs/datamodel-design.md` — DataModel migration design spec (349 lines, 10 design decisions, per-type implementation order) that P5/P6 implement against

### What this release IS NOT

- **No DataModel migration yet** (P5/P6, future alphas). `template.json` still in effect; `system.elysium.*` partition is still nested in compendium content (will be flattened during P5/P6 alongside the DataModel switch).
- **No template rebuild yet** (P8–P11). Sheets render with the same HBS templates as 0.22.0, except now using renamed classes/i18n keys.
- **No light theme work yet** (P12 decision pending).

### Decisions captured

- Deep-merge strategy for lang files: when both `BRP.Settings` and `Elysium.Settings` existed (one collision), Settings subkeys were unioned; Elysium values would have won on sub-collision but none occurred (108 BRP + 22 Elysium = 130 merged Settings subkeys, no overlap).
- Local var `brp` in `combat-card-buttons.mjs` (used as shorthand for the elysium flag handle) renamed to `cardFlag` to remove ambiguity.
- Flag-namespace bug found and fixed: three sites in `actor.mjs:613` and `character.mjs:571,577` were writing `flags.brp.brpidFlag` at runtime while all other code reads `flags.elysium.elysiumidFlag`. Fixed.
- `i18n` key collision resolved at the dual-namespace seam: keys `Elysium.brp` and `Elysium.brpSettings` (the original BRP system labels) renamed to `Elysium.system` and `Elysium.systemSettings`, with values updated to "Elysium" and "Elysium Settings". 8 settings-dialog `title` refs updated.
- `BRPID` system fully relabeled to `ElysiumID` end-to-end: code identifiers, lang keys (`BRPIDFlag` → `ElysiumIDFlag`, settings subkeys), compendium flag namespace, and Foundry CONFIG slot.
- Asset deletion: BRP-branded logo PNGs deleted; refs rewritten to `char-sheet-logo.png` as placeholder. P12 will source proper Elysium-branded assets.

### Migration notes (for the curious)

- No campaign data migration is needed — per project scope, this is a fresh-world rebuild. Existing 0.22.0 worlds should NOT be upgraded in place.
- The 0.22.0 build remains available as the final BRP-era reference for anyone wanting to pin to the legacy architecture.
- Foundry V14 / V16 DataModel prep is folded into v1.0.0 (P5/P6 in upcoming alphas).

### Post-ship updates (still under 1.0.0-alpha.1)

The alpha.1 version held while two follow-on workstreams shipped: a P4 codemod hotfix and the P5.1 NPC DataModel. Both are described in detail in `ROADMAP-v1.0.0.md`'s decision log; summary here:

**P4 hotfix — `brpid<UpperCase>` rename completion (discovered during P5 prep audit).** The original P4 codemod's `\bbrpid\b` regex didn't fire across the lowercase→uppercase boundary, so identifiers like `brpidFlagItems`, `brpidFlag`, `brpidRegExp`, `fromBRPID*`, `compareBRPIDPrio`, `sheetBRPID` were missed. The critical case: compendium .db content was already migrated to `flags.elysium.elysiumidFlag` in Step 6, but 91 code-side reads still used `flags.elysium.brpidFlag` — a silent breakage that didn't show up in the fresh-world smoke test because no compendium content had been dropped onto actors yet. Renamed in code-content lockstep: 201 substitutions across 19 .mjs/.hbs files. Dead `brpidFlagItems` derived field (zero readers) deleted from `actor.mjs`. Three integrity sweeps green post-rename. Settings keys with persisted values (`itemBRPID`, `firstAidBRPID`) deferred — those need a `Hooks.once('ready')` migration shim, queued for a coordinated naming-migration phase.

**P5.1 — NPC DataModel.** First DataModel in the v1.0.0 rebuild. `module/data/actor/npc.mjs` defines `NPCDataModel extends foundry.abstract.TypeDataModel`. `module/data/actor/_shared.mjs` factors out the base-template helpers (`makeStats`, `makeHealth`, `makePower`, `makeFatigue`, `makeActionPoints`, `makeResourcePair`) for reuse by P5.2 character. Stored-schema-only per P5 design decision: `ElysiumActor.prepareDerivedData` continues to populate label/total/deriv/visible on stats and the various stamped fields. Audit-driven field corrections vs the original P3 design (audit was the live-probe source of truth): `sanity` and `fatigue.recoveryType` kept (P3 said drop); `_v0140doc`, `power.battVal`, `power.battMax` dropped (zero readers grep-confirmed); `health.daily` kept despite zero meaningful reads because live writes reset it to 0 (removal would break those updates under strict-schema validation). Sparse-declares only 4 of the 13 `system.elysium.*` subkeys (creatureType, creatureSubtype, creatureTags, languages) — the character-only fields are sparse-skipped per P3 Decision 3. Smoke-tested green: 16 test cases covering NPC create, schema validation (including choices-constraint enforcement via `DataModelValidationError`), persistence roundtrip for NumberField/StringField/ArrayField, sheet render (22 visible inputs), compendium skill drop, derived-data population, and no-regression of pre-DataModel behavior.

**P5.2 (CharacterDataModel) is queued.** Handoff spec at `docs/p5-2-handoff.md`. Version bumps to 1.0.0-alpha.2 with the P5.2 ship.

---

## [0.22.0] — Rules expansion: armor/weapon HP, new combat mechanics, hit-location-at-attack

v0.22.0 is a feature release accumulating eight alpha cycles (alpha.5 through alpha.12) of major rules work. Headline additions:

- **Unified flat-HP / Mythras-HP prep flow** (alpha.5) — single derivation path; no more dual currHP recalculation
- **Outmanoeuvre mechanic** (alpha.6) — Mythras-style opposed-roll blocking from p114
- **Passive blocking** (alpha.7) — weapons and shields can be set into a covering stance that contributes AP to a chosen hit location
- **Ward Location** (alpha.8) — Mythras parry-size damage downgrade; unified with passive-block into a single `coveringStance` module
- **Armor/weapon HP rules change** (alpha.9–alpha.12):
  - Flat material-based armor AP with crit-triggered wear (Major Wound and attack-roll-crit both decrement)
  - Weapons take damage from fumbles (GM-button on fumble card) and from crit-parry-vs-sub-crit (the "parry holds on crit" exception is encoded)
  - Hit-location rolled at attack time (d20) with GM-only override dialog
  - Combat chat cards automatically surface GM action buttons (Apply Crit Armor / Apply Crit-Parry / Apply Fumble Weapon Damage) based on resolved result levels — no more manual API calls or macros required
- **Compendium tuning** — all 53 weapons re-tuned from placeholder values to differentiated HP (alpha.11) and AP (alpha.12) per weapon category

### What's new at the API surface

`game.system.api.elysium` exposes 8 mechanic modules in v0.22.0:
- `engagement` / `engagementUI` — Mythras reach + encroachment
- `charge` — knockback and charge resolution
- `outmanoeuvre` — opposed-roll blocking
- `coveringStance` — passive blocking + ward (unified, `passiveBlock` alias kept for back-compat)
- `armorWear` — crit-triggered armor AP loss (Phase B)
- `weaponWear` — fumble / crit-parry weapon damage (Phase C)
- `combatCardButtons` — chat-card GM-action injection (Phase D)

### New settings

- `hitLocationVisibility` — controls whether the rolled hit-location tag on combat chat cards is visible to all (`'everyone'`) or hidden from non-GMs (`'gm-only'` default)

### Schema / data changes

- **Armor** items: current AP stored in BRP-standard `system.av1`, max in `system.elysium.apMax`. Broken state derived (`apMax > 0 && av1 === 0`).
- **Weapon** items: max HP in `system.hp`, current in `system.hpCurr` (BRP-standard fields, previously unused). Broken state derived (`hp > 0 && hpCurr === 0`).
- **Combat chat cards** (`flags.brp.chatCard[]` entries) gained two fields for CM rolls with a target: `hitLocationId` and `hitLocationName`. Rendered as a small tag on the card, gated by the visibility setting.

### Migration

A one-time migration (`armor-hp-schema-v0220a9.mjs`) runs on first load to convert legacy armor items to the new schema. Idempotent, guarded by a hidden world flag. Actor-owned weapons keep their existing `hp`/`hpCurr` values; only fresh compendium imports pick up the alpha.11+ tuning.

### Pairs with

ElysiumCompendium module v0.22.0 (companion content release with HP + AP tuning across all 53 weapons).

### Detail entries

Each alpha cycle's full notes are preserved below as `[0.22.0-alpha.N]` entries.

## [0.22.0-alpha.12] — Phase D: hit-location-at-attack + GM action buttons on combat cards

Phase D closes the loop on Phases B and C: the alpha.10/.11 mechanics now have a **visible GM-action surface** during normal play. Where alpha.11 required the GM to remember the `game.system.api.elysium.weaponWear` / `armorWear` API surface or run macros, alpha.12 surfaces the relevant buttons directly on resolved combat chat cards.

### Rules implemented

- **Hit location rolled at attack time** for every weapon (CM) roll with a targeted defender. A d20 is rolled against the defender's hit-location table during `BRPCheck.makeRoll`. The chosen location is stashed on the chatCard entry (`hitLocationId` / `hitLocationName`) and persists in `flags.brp.chatCard`.
- **GM override dialog**: only the GM driving the roll sees an optional override dialog after the d20 — they can accept the rolled location or pick a different one from a dropdown of all the defender's locations. Per the alpha.12 design call, this is a **narrative-only tool**: no difficulty modifier, no penalty. PCs never see the dialog; their rolled location is final.
- **Visible location tag** on the chat card. Default visibility is **GM-only** (rendered but hidden from non-GMs via inline `display:none`) per the new `hitLocationVisibility` setting. World-scoped setting; campaigns running Mythras-style transparent combat can flip it to `everyone`.
- **Combat-card GM action buttons** appear automatically below resolved CM cards:
  - **Apply Fumble Weapon Damage** — emitted per participant who rolled `resultLevel === 0` (BRP fumble).
  - **Apply Crit Armor Damage** — pre-bound to the rolled hit location. Emitted when an attacker scored `origResLevel >= 4` (Critical) AND has a target + rolled location. **Suppressed** when a sub-crit parry exists on the same card — in that case the crit-parry rule applies and the blow's energy goes into the parry weapon, not the armor.
  - **Apply Crit-Parry Damage** — emitted on OP/CB (opposed/combat) cards when one participant rolled crit (origResLevel >= 4) and another rolled an attempted-but-sub-crit parry (2 <= origResLevel < 4). Pre-bound to the parrier's weapon with both result levels embedded as data attrs (the click handler re-checks the rule gate).
  - **Crit-vs-crit holds**: no button at all — the parry stopped the attack cleanly.

### New module

`module/elysium/mechanics/combat-card-buttons.mjs` (~230 lines). Exposed at `game.system.api.elysium.combatCardButtons`:
- `injectCombatCardButtons(msg, root)` — main injector, GM-only, gated on `cardType` + `state === 'closed'` + `rollType === 'CM'`. Idempotent.
- `applyHitLocationVisibility(root)` — applies the `hitLocationVisibility` setting to any `.elysium-hitloc-tag` elements. Runs for all users (not just GMs) so non-GMs get the tag hidden.

### New module (helper)

`module/elysium/combat/hit-location-attack.mjs` (~140 lines). Pure function `rollHitLocationForAttack(config)` consumed by `BRPCheck.makeRoll`. Includes the GM override dialog. Idempotent — re-running with `hitLocationId` already set is a no-op.

### Settings

New world-scoped setting `elysium.hitLocationVisibility`:
- `'gm-only'` (default) — tag rendered in DOM but hidden via inline style for non-GMs
- `'everyone'` — tag visible to all viewers

The data itself (`chatCard[].hitLocationId`) is ALWAYS stored on the card regardless of this setting; the buttons need it. The setting controls only the visible tag.

### Files changed

- `module/apps/check.mjs` — `makeRoll` now calls `rollHitLocationForAttack` for CM rolls; chatCard entry includes `hitLocationId` + `hitLocationName`
- `module/elysium/combat/hit-location-attack.mjs` — NEW (~140 lines)
- `module/elysium/mechanics/combat-card-buttons.mjs` — NEW (~230 lines)
- `module/elysium/hooks/chat-card.mjs` — wires both injectors into `onRenderChatMessageHTML`
- `module/elysium/elysium.mjs` — imports + API exposure
- `module/elysium/settings/register-settings.mjs` — registers `hitLocationVisibility`
- `templates/chat/roll-result.html` — renders `.elysium-hitloc-tag` when present
- `lang/en.json` — 2 new keys (`hitLocationVisibility` + Hint)
- `system.json` — version → 0.22.0-alpha.12

### Verification

15/15 dom-based smoke tests pass covering: solo NO crit, OP crit-vs-sub-crit (crit-parry), OP crit-vs-crit (no buttons), fumbles, mixed crit+fumble, idempotency, non-GM gating, both visibility settings, missing target/location guards.

### v0.22.0 progress

| # | Item | Status |
|---|---|---|
| 1 | Flat-HP / MythrasHP unify | DONE alpha.5 ✓ |
| 2 | Outmanoeuvre | DONE alpha.6 ✓ |
| 3 | Passive blocking | DONE alpha.7 ✓ |
| 4 | Ward Location + unification | DONE alpha.8 ✓ |
| 5a | Armor HP — Phase A (schema) | DONE alpha.9 ✓ |
| 5b | Armor HP — Phase B (crit damage) | DONE alpha.10 ✓ |
| 5c | Weapon HP — Phase C (fumble + crit-parry) | DONE alpha.11 ✓ |
| 5d | **Phase D — chat-card button surface + hit-location-at-attack** | **DONE alpha.12 ✓** |
| 6 | Compendium audit (weapon AP tuning) | Lower priority |

## [0.22.0-alpha.11] — Phase C: weapon damage from fumbles and crit-parry

The final piece of the v0.22.0 armor/weapon HP rules-change. Phase A (alpha.9) reworked the armor schema; Phase B (alpha.10) shipped crit-triggered armor damage. Phase C now does the parallel work for weapons.

### Rules implemented

- **Fumble weapon damage**: when the fumble-table result indicates the wielder's weapon takes damage, the GM clicks an **Apply Fumble Weapon Damage** button to decrement `system.hpCurr` by 1. Fully GM-adjudicated (the fumble table itself decides which fumble results trigger damage).
- **Crit-parry damage**: when an attack rolled a Critical success (resultLevel ≥ 4) AND the defender's parry rolled below Critical (resultLevel < 4 but high enough to parry), the defender's parry weapon takes 1 HP damage. The GM clicks **Apply Crit-Parry Damage** to apply.
- **Crit-parry exception (parry holds)**: if the parry was ALSO a Critical (resultLevel ≥ 4), the parry "holds" and the weapon takes NO damage. The rule lives in `applyCritParryDamage()` — callers pass both result levels and the function gates on them, so the click handler re-checks at apply time.
- **Broken weapons**: a weapon is broken when `hp > 0 && hpCurr === 0`. Broken state is purely derived (no separate flag). The `hp > 0` guard means placeholder/untuned weapons with `hp:0` don't show as broken.

### New module

`module/elysium/mechanics/weapon-wear.mjs` (~280 lines), mirroring `armor-wear.mjs`. Exposed at `game.system.api.elysium.weaponWear`:

- `applyWeaponDamage(item, amount, reason)` — decrements `hpCurr`, posts chat card, broken at 0. Idempotent on already-broken pieces.
- `repairWeapon(item, amount)` — restores `hpCurr` up to `hp` (max).
- `isWeaponBroken(item)` — `hp > 0 && hpCurr === 0`.
- `applyCritParryDamage(parryWeapon, attackRL, parryRL, reason)` — encodes the full rule including the crit-parry exception. Returns `{applied, reason, previous, current, broken}` so debugging the no-op paths is easy (`parry-was-crit`, `attack-not-crit`, `already-broken`, `no-parry-weapon`).
- `buildApplyFumbleDamageButtonHTML(actorId, weaponId)` — GM-button HTML for fumble cards.
- `buildApplyCritParryButtonHTML(defenderId, parryWeaponId, attackRL, parryRL)` — GM-button HTML for combat-resolution cards. Carries both result levels in data attrs.
- `wireWeaponWearChatHandlers()` — delegated click handler for both chat-card buttons and the weapon-sheet Repair button.

### Sheet UI

The weapon item sheet (`module/elysium/sheets/item/weapon-fields.mjs`) now renders a **Weapon HP** fieldset:
- **Max HP** input (`system.hp`) and **Current HP** input (`system.hpCurr`), `0 .. 999`.
- Red+bold styling on the current-HP input + a red **BROKEN** badge when the weapon is broken.
- **Repair +1** button (disabled at max).

Renders inline in the weapon detail tab, between the active-engagement info and the wielded modifiers fieldset.

### State storage

No schema migration needed — `system.hp` (max) and `system.hpCurr` (current) are part of the BRP-standard weapon template and were already being populated. The 53 catalog weapons in the Elysium compendium all carry `hp: 15, hpCurr: 15` (placeholder tuning; per-weapon HP differentiation is a separate content-audit task tracked under the compendium audit row of the roadmap).

### Why GM-facilitated (no auto-trigger)

Both fumble and crit-parry triggers depend on data BRP-classic combat-card resolution doesn't carry through to a centralized chokepoint: the fumble-table outcome is rolled separately, and the parry contest doesn't expose both result levels together. The pure-function API is in place so future automation work (a richer combat-card flow) can wire auto-triggers directly to `applyCritParryDamage` / `applyWeaponDamage` with no public-surface changes.

### Files changed

- `module/elysium/mechanics/weapon-wear.mjs` (new, ~280 lines)
- `module/elysium/elysium.mjs` (import, API exposure, ready-hook wiring)
- `module/elysium/sheets/item/weapon-fields.mjs` (new `injectWeaponHP` helper + call from `injectWeaponFields`)
- `lang/en.json` (5 new keys: `Weapon.HPFields`, `Weapon.HPBase[Hint]`, `Weapon.HPCurrent[Hint]`)
- `system.json` (version bump → 0.22.0-alpha.11)

### v0.22.0 progress

| # | Item | Status |
|---|---|---|
| 1 | Flat-HP / MythrasHP unify | DONE alpha.5 ✓ |
| 2 | Outmanoeuvre | DONE alpha.6 ✓ |
| 3 | Passive blocking | DONE alpha.7 ✓ |
| 4 | Ward Location + unification | DONE alpha.8 ✓ |
| 5a | Armor HP — Phase A (schema + cleanup) | DONE alpha.9 ✓ |
| 5b | Armor HP — Phase B (crit damage) | DONE alpha.10 ✓ |
| 5c | **Weapon HP — Phase C** | **DONE alpha.11 ✓** |
| 6 | Compendium audit (weapon HP tuning) | Lower priority |

The full v0.22.0 armor/weapon HP rules-change is now mechanically complete. v0.22.0 stable can ship after a brief soak.

## [0.21.0] — Cleanup release: AST-driven refactors, dead-code removal, BRP-classic ballistic-armor system removed

v0.21.0 is a cleanup-only release. No new game mechanics — every change is structural, removing dead/duplicate/vestigial code and splitting the two largest monolithic modules into per-concern modules. Outmanoeuvre and other new mechanics deferred to v0.22.0 with full design specs captured in `ROADMAP-v0.22.0.md`.

### v0.20.0 regex-fragility lesson, applied

Every bulk transform in v0.21.0 uses real AST tooling, not regex. Three reusable tools live in `tools/`:
- `find-let-to-const.mjs` — acorn-based detector for `let` declarations that should be `const`
- `apply-let-to-const.mjs` — applies the conversions with per-file `node --check` validation and automatic revert on failure
- `extract-methods.mjs` — class-static method extractor that rewrites `this._foo()` calls to `foo()` bare calls
- `extract-functions.mjs` — top-level function extractor with automatic import-graph detection
- `sheet-extension-deps.mjs` — dependency analyzer used during the sheet-extension refactor

These tools are durable artifacts: future refactors can re-use them instead of writing regex.

### Sheet-extension surgery (the headline refactor)

`module/elysium/sheets/sheet-extension.mjs` was 2370 lines, 41 static methods on one class. Each method did header decoration, char-tab extensions, combat-tab badges/conditions/engagement, items-tab container nesting, effects-tab item-modifier listings, skills-tab collapsibility, item-sheet fields (weapon/armor/gear/ancestry/themed-ability), event wiring, or shared helpers — all in one namespace.

**Result**: 2370-line monolith → 160-line dispatcher + 15 focused modules:

```
module/elysium/sheets/
  sheet-extension.mjs            (160 lines)   — dispatcher, only entry
                                                 points extendActorSheet
                                                 and extendItemSheet
  shared.mjs                     ( 87 lines)   — modeConstToPresetSheet,
                                                 aeModeLabel, promptAttributeKey,
                                                 escapeHtml
  actor/
    header.mjs                   (135 lines)   — AP injection, Temp HP editable
    char-tab.mjs                 (155 lines)   — Statistics tab extension
    combat-tab.mjs               (528 lines)   — healing rate, wound tiers,
                                                 location conditions, conditions
                                                 panel, engagement badges
    items-tab.mjs                (124 lines)   — container nesting
    effects-tab.mjs              ( 90 lines)   — item-modifier AE listing
    skills-tab.mjs               ( 56 lines)   — section/subsection collapsibility
    events.mjs                   ( 59 lines)   — delegated click handlers
  item/
    item-modifiers.mjs           (167 lines)   — SHARED by weapon/armor/gear
    weapon-fields.mjs            ( 95 lines)   — Weapon Size/Reach/Force
    armor-fields.mjs             ( 92 lines)   — Armor flexibility/material
    gear-fields.mjs              (116 lines)   — Gear + container contents
    ancestry-fields.mjs          ( 64 lines)   — Ancestry data fields
    themed-ability.mjs           (284 lines)   — Themed-ability bundle UI
    stored-in.mjs                ( 55 lines)   — "Stored In" container selector
```

`tools/extract-methods.mjs` was built specifically for this refactor: it parses the source AST with acorn, locates each `MethodDefinition` by name, extracts the byte range verbatim, rewrites `this._foo(...)` calls to bare `foo(...)` calls (since all extracted methods now share module scope), detects sibling-call references and external-symbol uses automatically. Module-scope helpers (`_modeConstToPresetSheet`, `_aeModeLabel`, `_promptAttributeKey`, `_escapeHtml`) consolidated to `shared.mjs` and renamed without the leading underscore. Bonus async cleanup: `_promptAttributeKey` converted from explicit `new Promise(resolve => ...)` to `await DialogV2.wait` during the move.

### Register-hooks split

`module/elysium/hooks/register-hooks.mjs` was 730 lines — the dispatcher + every Hooks.on handler + two large inline anonymous handlers. Same refactor pattern as sheet-extension:

```
module/elysium/hooks/
  register-hooks.mjs            ( 76 lines)  — dispatcher, only Hooks.on calls
  actor.mjs                     ( 52 lines)  — _onCreateActor, _onUpdateActor,
                                                _onPreUpdateActor,
                                                _relevantFieldChanged
  item.mjs                      (379 lines)  — _onPreCreateItem, _onCreateItem,
                                                _onDeleteItem, _onPreUpdateItem,
                                                _onUpdateItem, _absorbWithTempHP
  combat.mjs                    ( 26 lines)  — _onCombatStart/Round/Turn/End
  render-actor-sheet.mjs        ( 14 lines)
  render-item-sheet.mjs         ( 14 lines)
  render-combat-tracker.mjs     ( 26 lines)  — brace badges on combat-tracker
  chat-card.mjs                 (220 lines)  — onRenderChatMessageHTML +
                                                4 button-class wirers (cast-card,
                                                disrupt-sustain, cast-disrupt,
                                                cap-override)
```

`tools/extract-functions.mjs` (companion to extract-methods.mjs) handled the top-level FunctionDeclarations. The two inline anonymous handlers were extracted manually; chat-card.mjs was further decomposed into a top-level dispatcher plus 4 button-class helpers (`wireCastCardButtons`, `wireDisruptSustainButtons`, `wireCastDisruptButtons`, `wireCapOverrideButtons`).

### armBal/armVar/BAP system removal — BRP-classic ballistic armor

Removed the entire BRP-classic ballistic-armor system, replaced in Elysium by the material × stratum + location-scaling system in the armor catalog and the damage-bucket logic in `armor-vs-damage.mjs`.

- Schema (template.json): 8 field defaults removed (`armBal`, `armVar`, `av2`, `avr2`, `bap`, `bapRnd` × 2 locations)
- Lang keys (en/es/fr): 8 keys × 3 langs = 24 entries removed (`armBal`, `armBalHint`, `armVar`, `armVarHint`, `bap`, `bapHint`, `avb`, `ballistic`)
- JS code: `base-item-sheet.mjs` toggle allow-lists (2 sites), `rollType.mjs` switch cases (`cbap`, `nbap`, `ncbap` + shift-for-ballistic branch), `actor.mjs` init/accumulation (3 sites)
- Templates: `character.items.hbs` (BAP column header collapsed, dual-AP rendering simplified, all `{{#if armBal}}`/`{{#if armVar}}` blocks removed), `character.combat.hbs` (BAP tooltip dropped), `armor.detail.hbs` (powermod-scores AV2 block removed, options-toggle buttons removed, `energyMax` gating switched from `armVar` to `ppMax > 0`), `npcV2.main.hbs` (hitloc BAP column → placeholder cells, armor summary BAP row removed)

All 75 templates compile cleanly via `Handlebars.precompile()` after the change.

### let → const bulk transform

`tools/find-let-to-const.mjs` identified 392 candidates across 52 files. `tools/apply-let-to-const.mjs` applied them all with per-file `node --check` validation. **Zero reverts** — every patched file passed syntax check on first try.

After the transform:
- `let` statements remaining: 291 (all genuine reassignment cases)
- `const` statements: 2829

Top files touched (by candidate count):
- `module/actor/actor-itemDrop.mjs`: 43
- `module/actor/sheets/base-actor-sheet.mjs`: 36
- `module/apps/check.mjs`: 35
- `module/actor/sheets/character.mjs`: 31
- `module/combat/damage.mjs`: 28
- `module/apps/rollType.mjs`: 24
- `module/apps/charDev.mjs`: 23
- `module/apps/select-lists.mjs`: 23
- `module/actor/actor.mjs`: 19

### Armor-layering extraction

Extracted `_checkArmorLayerConflict`, `_resolveArmorLayer`, `_resolveWornStratum` from `module/elysium/hooks/register-hooks.mjs` to new `module/elysium/mechanics/armor-layering.mjs` (138 lines including full JSDoc commentary). `register-hooks.mjs` went from 819 → 730 lines (-89 lines). Live test: soft+soft collision still rejects with the correct user-facing message.

### Callback-Promise → async conversions

Five functions converted from `return new Promise(resolve => { ... callback: () => resolve(X) ... })` to `await foundry.applications.api.DialogV2.wait(...)` with `rejectClose: false`:

- `module/elysium/actor/ancestry-drop.mjs::_confirmReplacement`
- `module/elysium/actor/ancestry-drop.mjs::_chooseSubrace`
- `module/elysium/creation/creation.mjs::assignRolledStats`
- `module/elysium/critical/critical-roller.mjs` luck-save dialog
- `module/elysium/sheets/shared.mjs::promptAttributeKey` (during sheet-extension extraction)

`module/casting/arcane-cast.mjs::_chooseSchool` was already async-clean — the roadmap entry was wrong.

`module/apps/skill-selection.mjs::create` was audited but NOT converted — the "keep dialog open while pick-count is insufficient" semantics require the explicit Promise wrapper. The unreachable `return dlg` after the Promise was removed (dead code).

### Dead-code removal

Roughly 540 lines of dead/duplicated/vestigial code purged across 6 files (4 deleted entirely, 2 trimmed):

- `module/setup/update.mjs` (132 lines) — entire file deleted. Contained `updateWorld`, `updateDialog`, and `v13153` functions implementing a migration path from BRP-classic 13.1.53 (pre-Elysium fork) format. Per the v0.20.0 design decision ("new world required, no migration"), this entire migration path is dead code.
- `templates/updates/update13.1.53.hbs` deleted — the welcome dialog template ("Welcome to Version 13.1.53 for Basic Role Playing") that the migration prompted with. Empty `templates/updates/` directory removed.
- `module/brp.mjs` — removed the `updateWorld` import, the `_runVersionMigrationIfNeeded` helper, and the `if (game.user.isGM) await _runVersionMigrationIfNeeded()` call in `_onReady`.
- `module/settings/register-settings.mjs` — removed the `gameVersion` setting registration (8 lines) that gated the migration.
- `module/setup/context-menu.mjs` (13 lines) — entire file deleted. The `BRPContextMenu` class was a Foundry ContextMenu subclass that added nothing meaningful and was imported nowhere.
- `module/apps/chat.mjs` — `addChatListeners(html)` function removed (4 lines). Used jQuery `html.on('click', ...)` syntax — V12 API, replaced by `BRPChat.renderMessageHook` in the same file which uses native `addEventListener`.
- `module/sheets/brp-roll-table-config.mjs` (20 lines) — entire file deleted. `BRPRollTableConfig` was a `RollTableSheet` subclass with only two overrides; was imported only in a single commented-out line. The commented-out registration block at the end of `register-sheets.mjs` was also removed.
- `templates/brpid/brpid-editor.html` (~140 lines) — entire file deleted. Unreferenced `<form>`-based variant of the `.hbs` template with different markup.

### Audit findings (no action needed)

- **Settings audit**: inventoried all 44 settings registered by the system. 0 dead, 33 single-reader, 11 multi-reader. The v0.20.0 audit had already cleared the obvious dead settings.
- **Flat-HP BRP-classic prep loop**: the roadmap's "dead code" framing was wrong. The `actor.mjs::_prepareCharacterData` hit-location loop is NOT entirely dead — MythrasHP only enters its override branch when `oldMax !== newMax`; on steady state the BRP-classic loop IS authoritative for currHP-from-wound calculation. The `wound` item type is actively used. Deferred to v0.22.0 as a "unify prep flow" refactor.
- **Unused-export audit**: identified `invalidateFTCache`, `modeConstToPreset`, and `createTokenDialog` as exported-but-unused; each kept by design (dev utility, symmetric inverse, used internally).

### Integrity at ship time

- **148/148** .mjs files have valid syntax (`node --check`)
- **75/75** .hbs templates compile (`Handlebars.precompile()`)
- **5/5** JSON files parse cleanly

### Live smoke-test required post-install

The sheet-extension surgery and register-hooks split touch hot paths (every character/item sheet render, every actor/item create/update, every chat-message render, every combat round). Static checks all pass and the AST extraction is byte-perfect. Per-feature live verification at install time:

**Sheet-extension** (open a character sheet and an item sheet):
- AP panel appears in resources header alongside HP/PP/Fatigue
- Temp HP value/max divs are editable inputs
- Char tab shows Healing Rate, Luck Points, Fatigue level, Casting Penalty, EXP Dice
- Combat tab shows wound-tier badges, per-location condition icons, conditions panel, engagement badges on weapon rows
- Items tab shows container nesting
- Effects tab shows item-modifier AE groups
- Skills tab section/subsection collapsibility works
- Weapon sheet shows Size/Reach/Force fields and item-modifier section
- Armor sheet shows flexibility/material fields and item-modifier section
- Gear sheet shows container-contents UI and stored-in selector
- Culture sheet shows ancestry data fields
- Ability/Mysticism sheet shows themed-ability activation/benefits/drawbacks/addOns
- Console clean of `Elysium | extendActorSheet step "X" failed` errors

**Register-hooks** (exercise each hook):
- Create an actor → Elysium derived stats appear
- Drop a culture item → ancestry-drop pipeline fires (hit-locations, AEs)
- Apply a wound → critical-roll path fires when location HP <= 0
- Equip/unequip armor → armor-layering conflict check fires correctly
- Open sheets → render hooks fire
- Start/round/turn/end combat → combat hooks fire
- Brace a combatant → shield badge appears in combat tracker
- Post a cast card → Spend AP / Abandon / Undo PP buttons work
- Damage a sustainer → Disrupt-sustain button works
- Damage an active caster → Cast-disrupt button + Willpower roll work
- Player requests stat-cap override → GM-only approve/deny buttons work

Hot-fixes from this smoke test will ship as v0.21.1, v0.21.2, etc.

## [0.20.0] — Major cleanup: rules module folded into system, schema canonicalization, four-pool AP, damage modifier rework, knockback in feet

### Live smoke test — combat: engagement, charge, knockback

Continued the v0.20.0 smoke-test with a two-character scenario (Character vs Defender) to exercise engagement, reach math, change-range, and charge.

**Test setup**: Defender actor created with mid-range stats. Each actor equipped with a weapon. Tokens placed on the active scene, combat started with both as combatants. Engagement established at the longer weapon's reach.

**Reach math (pure functions)**: ✅ all correct after correct signatures
- `getReachDifference(weaponReach, engagementReach)` returns signed step delta: M vs S = +1, L vs S = +2, S vs L = -2, H vs T = +5
- `getEncroachmentSteps(weaponReach, engagementReach)` returns 0 when diff < 2, otherwise positive step count: L vs S = 2, VL vs S = 3
- `getHeldAtBaySteps(weaponReach, engagementReach)` returns positive count when defender's weapon is too short: S vs L = 2

**Engagement state**: ✅ end-to-end
- `establishEngagement(combatantA, combatantB.id, weaponA.id)` writes mirror records to both combatants' `flags.elysium.engagements` arrays, picks the longer weapon's reach as the engagement reach, posts info notification
- Spear (L) vs Dagger (S) → engagement at L; dagger held at bay by 2 steps, cannot directly attack; spear at full damage
- `resolveChangeRange('allow', initiator, opponent, 'S')` updates engagement reach on both sides to S, posts summary chat
- After Change Range to S: Spear damage capped at **'1d3+1'** (encroached); dagger at full damage, no longer held at bay — matches Mythras canon
- `canDirectlyAttack(weapon, engagementReach)` returns false when held-at-bay, true otherwise
- `getMaxDamage(weapon, engagementReach)` returns `'1d3+1'` when encroached, `null` otherwise

**Charge bonuses**: ✅ correct math for both bipeds and quadrupeds
- Biped (STR 18 + SIZ 13 = 31, base damage modifier +1d4, base weapon size L spear): charges with `+1d6` damage mod (one step up), weapon size H (one step up), +1 difficulty grade
- Quadruped (`creatureSubtype: 'quadruped'`): charges with `+1d8` damage mod (two steps up) — extra body mass behind the impact
- `stepDamageMod(tier, steps)` walks ELYSIUM.DAMAGE_MOD_TABLE by index, handles "+0" → "+1d2" → "+1d4" → "+1d6" progression and the negative side mirror
- `stepWeaponSize(letter, steps)` walks `['T','S','M','L','H','E']` by index

**Knockback**: ✅ all clamps fire
- `computeKnockback(rawDamage, defenderSIZ, braced?)` returns `{feet, squares, mustRoll, prone, excess}`
- No excess (dmg ≤ SIZ): 0 ft, mustRoll false
- Excess 3 (vs SIZ 13, damage 16): 1 square = 5 ft
- Excess 15 (damage 28 vs SIZ 13): 3 squares = 15 ft
- Braced reduces excess by half before computing: 28 vs 13 with brace = excess 15/2 = 7 → 2 squares = 10 ft
- ELYSIUM.MOVEMENT.squareSizeFt = 5 confirmed

**Cast/charge resolution paths**: ✅ resolveCharge posts the resolution chat card; resolveKnockback handles 'stayed' / 'prone' / 'roll' branches

### Real bug found and fixed (Bug 3 of v0.20.0)

**`system.dmgmodTier` was never written during prep, breaking all downstream damage-mod consumers.**

`ElysiumActorExtension.applyToActor` computes the Mythras damage modifier correctly via `calculateDamageModifier(actor)` (STR+SIZ → dice expression via DAMAGE_MOD_TABLE) and writes it to `flags.elysium.derived.damageModifier`. BUT three downstream readers — `combat-roll.mjs:184`, `charge-ui.mjs:185`, `charge.mjs:79` — all read `actor.system.dmgmodTier`, which is the documented schema field per the comments in `actor.mjs:509,717` (default `"+0"` in template.json line 145). The bridge between the computed value and the schema field never existed, so every actor reported damage modifier `+0`, regardless of STR/SIZ.

Effect on play: weapon damage rolls never gained the STR+SIZ bonus, and charges never gained the base damage modifier before applying the +1 (biped) / +2 (quadruped) step.

Fix: in `actor-extension.mjs:applyToActor`, append `update['system.dmgmodTier'] = derived.damageModifier` to the update payload just before the actor.update() call. Verified live:

- STR 18 (+culture bonus = 18) + SIZ 13 = 31 → `calculateDamageModifier` returns `+1d4` (Mythras: 26-30 = +1d2, 31-35 = +1d4)
- After fix: `actor.system.dmgmodTier === '+1d4'` ✓
- Biped charge: `computeChargeBonuses` returns `damageMod: '+1d6'` (1 step up from +1d4) ✓
- Quadruped charge: `damageMod: '+1d8'` (2 steps up) ✓

### Compendium data fixes (weapons.db)

While testing reach, I discovered the entire weapon compendium shipped with broken reach + size data:

1. **All 53 weapons had `reach: null`** — no reach data at all. Foundry's data layer fell back to the template default of `'M'`, so every weapon read as medium reach. The encroachment/held-at-bay system can never trigger from the shipped weapons. Fixed: 9 S (daggers/hatchets/buckler), 32 M (one-handed swords/axes/maces/bows/firearms), 10 L (greatswords/greataxes/spears/quarterstaff/halberd/whip/tail), 2 VL (pikes, longspears).
2. **All 53 weapons used full-word `weaponSize`** (`'small'`/`'medium'`/`'large'`) but the schema and every consumer (charge.mjs, engagement.mjs, sheet-extension.mjs) expects letter codes (`'S'`/`'M'`/`'L'`). `stepWeaponSize('medium', 1)` returns `'medium'` unchanged because `indexOf('medium')` in `['T','S','M','L','H','E']` is -1. Fixed all 53 records to use letter codes (16 S, 23 M, 14 L).

Both fixes are pure data — the engagement/charge code was already correct. Without these fixes, the entire reach-based combat subsystem was effectively dead despite the engagement code being well-implemented.

### Verified API surface

**game.system.api.elysium.engagement** — REACH_ORDER (fn), SIZE_ORDER (fn), getReachDifference, getEncroachmentSteps, getHeldAtBaySteps, getEffectiveSize, canDirectlyAttack, getMaxDamage, getEngagements, getEngagementWith, getActorEngagements, getEngagementWeapon

**game.system.api.elysium.engagementUI** — patchCombatTrackerContextMenu, registerContextMenu, openEngageDialog, openDisengageDialog, openChangeRangeDialog, establishEngagement, breakEngagement, resolveChangeRange, wireChangeRangeChatHandlers

**game.system.api.elysium.charge** — stepDamageMod, stepWeaponSize, computeChargeBonuses, computeKnockback, registerContextMenu, openChargeDialog, openKnockbackDialog, resolveCharge, resolveKnockback, wireChargeChatHandlers

### Cleanup at session end

Combat ended, Defender actor deleted, test tokens removed, test weapons deleted from Character, character stats reset to baseline (STR 11, SIZ 13, POW 11, no quadruped flag), engagement flags cleared. Character is back to: 1 culture, 4 mutations, 7 hit-locations, 4 armor pieces (the original four).

### v0.20.0 final summary

Three real bugs found and fixed in the smoke-test sessions:
1. Armor HP scaling damage didn't persist (mythras-hp.mjs)
2. Fresh armor drops looked pre-damaged (armor.db catalog records + mythras-hp.mjs null-check)
3. `system.dmgmodTier` never written during prep (actor-extension.mjs)

Two compendium data quality bugs found and fixed:
4. All 53 weapons had `reach: null` (weapons.db)
5. All 53 weapons used full-word `weaponSize` instead of letter codes (weapons.db)

Multiple false alarms ("apparent bugs" that were caller-side errors) documented for future smoke-test guidance — many casting and combat helpers have signatures that aren't obvious without reading the source. Filed v0.21.0 task to add JSDoc @typedef to the public API surface.


### Live smoke test — magic systems (all four traditions)

Continued the v0.20.0 smoke test by driving the magic pipelines through the Chrome extension. All four traditions verified end-to-end.

**Test setup** (recorded so the next session knows what state was used):
- Character actor with CON 19, SIZ 13, POW 18, PP 30, AP 3
- Magic skills added at 75%: Illusion (arcane school), Channeling (divine), Focus (mysticism), Light + Vitality (sorcery essences), Willpower
- Arcane F/T added at 60%: Form (Image), Technique (Create), Technique (Conceal) — pulled from `elysium-compendium.arcane-knowledge` pack (NOT the skills pack — these are skill items with `arcaneRole: 'form'|'technique'`)
- Allegiance: Faith (Lawkeeper) at 75 points — divine casts require an item of type `allegiance` whose name matches `/faith/i`, NOT a skill
- Test spells: Mirror Image (arcane, basePP 2, requiredSL 2), Bless (divine War, tier 1, AP 1), Renewal Field (sorcery vitality, basePP 2, tier 1), Slow Fall (mysticism, basePP 0, tier 1)

**Arcane (Mirror Image): ✅ end-to-end pass**
- `beginArcaneCast` opens active cast, runs F/T checks silently as GM whispers, posts in-progress chat card
- `spendCastAP` rolls Illusion 75% → SL 5 vs required 2 → cast resolves on first AP
- PP 30→28 (cost 2, matches basePP), AP 3→2 (cost 1 attempt)
- Card flag chain: tradition=arcane, completed=true, ppSpent=2, apSpent=1, finalRoll=29, accumulatedSL=5/2

**Divine (Bless tier 1): ✅ end-to-end pass**
- `castDivine` opens `TierChoiceDialog` (two-stage: pickTier then cast)
- Channeling 75% rolled 30 → success
- PP 30→29 (cost 1 matches `powerCost`), AP 3→2 (cost 1 matches `apCostByTier[0]`)
- Card flag: tradition=divine, completed, Tier 1 effect rendered from `effectByTier`

**Sorcery (Renewal Field, Vitality essence, tier 1): ✅ end-to-end pass**
- `castSorcery` opens TierChoiceDialog (shares the class with divine via `faithTotal = -1` sentinel)
- Vitality 75% rolled 51 → success
- PP 30→28 (cost 2), AP 3→1 (cost 2)
- Card flag: tradition=sorcery, completed, Tier 1 effect rendered
- Bonus: damage-resolution path correctly handles "no targets selected" by posting a GM-resolve-manually notice rather than crashing

**Mysticism (Slow Fall tier 1): ✅ end-to-end pass**
- `castMysticism` opens TierChoiceDialog
- Focus 75% rolled 83 (technically over skill, but mysticism abilities take effect at the picked tier regardless — the roll determines a quality grade rather than success/failure)
- PP 30→30 (cost 0 — Slow Fall is `powerCost: 0`, mysticism is effortful via Focus, not PP-driven)
- AP 3→2 (cost 1 matches `apCostByTier[0]`)
- Card: tradition=mysticism, completed, effect rendered

**Pure-function helpers**: `classifyRoll`, `computeSL`, `manipulationCost`, `manipulationDiscount`, `summariseManipulation`, `maxCastableTier`, `maxCastableSorceryTier`, `classifyWoundSeverity`, `slLossForSeverity` — all return correct values. Signatures are `(skill, roll)` for the roll classifiers (not `(roll, skill)`), and `(damage, location)` for woundSeverity where `location` is the hit-location item (its `system.maxHP` is consulted to bucket damage into minor / serious (2×) / critical (3×)).

**Sustain system**: `getActiveSustains`, `addSustain`, `removeSustain` round-trip correctly. The sorcery Renewal Field cast auto-registered a sustain (1 PP/round) via the cast-completion hook. `disruptSustain` is wired but not stress-tested here.

**Active-cast lockout**: trying to begin a second cast while one is active correctly emits `"Character already has an active arcane cast (Mirror Image). Finish or abandon it first."` and aborts the new cast.

**Cast disruption**: `checkActiveCastDisruption(actor, damage)` correctly clears the active-cast flag when damage qualifies as critical (3× hit-location maxHP). Return value is `null` rather than an explanatory object — minor API-shape nit, but the disruption side-effect fires correctly.

### Bugs found (none new; all explained)

The two HP-scaling bugs found and fixed earlier in the session remain the only real bugs from this v0.20.0 smoke-test. Multiple of my mid-test calls **looked** like they exposed bugs but were caller-side errors:

- `classifyRoll(5, 75)` returned "failure" for every input — turned out the signature is `(skill, roll)` not `(roll, skill)`. Once flipped, all classifications correct.
- `manipulationCost({tiers, params})` returned 0 — signature is `(paramName: string, skillTotal: number)`. Once called correctly, returns the post-discount per-step cost.
- `classifyWoundSeverity(50)` always returned "minor" — signature requires a `(damage, locationItem)` pair; without a location, the function defaults to minor.
- `maxCastableTier(actor, spell)` returned 0 — signature is `(channelTotal, faithTotal)` (two numbers).
- `beginArcaneCast` hung when stubbed with `{ppCommitted, requiredSL, deltas, parametersTouched, summary, schoolName}` — the actual `openManipulationDialog` returns `{deltas, ppCommitted, manipulationCostSpent, parametersTouched}`. With the correct shape (or by auto-confirming the real dialog), the cast completes in ~500ms.
- Initial PP test had `actor.system.powerPoints` set rather than `system.power` — the casting code correctly reads/writes `system.power` per the template schema; my test data was wrong, not the system. Once corrected, PP decremented as expected.

**Pattern**: when smoke-testing API surfaces, read the signature at the source before assuming. Most apparent failures here were "the test is wrong" rather than "the code is wrong." Filed a tiny v0.21.0 task to add `@typedef` JSDoc on each casting export so the signatures are inspectable from `game.system.api.casting.SomeFn.toString()`.

### Cleanup at session end

Test character returned to baseline: test spells/abilities/skills/allegiance deleted (14 items removed), POW reset from the test bump of 18 back to 11, sustains and active-cast flags cleared. Remaining items: 1 culture, 4 mutations, 7 hit-locations, 4 armor pieces (the original four from before testing).


### Hotfix — armor HP scaling fixes from live smoke-test session

Found two bugs in `ElysiumMythrasHP.applyArmorHPScaling` by driving Foundry through the Chrome extension and exercising the actual data paths. Both fixed in `module/elysium/actor/mythras-hp.mjs` and verified live before persisting.

**Bug 1: damage-preservation logic was wrong, damage didn't stick.**

The original code computed `damage = oldMax - oldValue` to "preserve" the damage taken across scaling changes, then wrote `value = newMax - damage`. The problem: `armorHP.max` is derived (set each prep cycle) but its persisted on-disk value is always equal to `base` (the catalog HP), not the scaled value. So `oldMax` always equaled `base`, and for a freshly-dropped piece on Chest with `base=28, value=28`, `damage = 28 - 28 = 0`. The actual damage I wrote (`value=30` after applying 9 damage from 39) was lost because:

```
oldMax = 28 (from persisted base, not 39)
oldValue = 30 (after my damage write)
damage = max(0, 28 - 30) = 0      ← clamped, info lost
newMax = round(28 × 1.40) = 39
value = max(0, 39 - 0) = 39        ← reset to full
```

Fixed by adopting a simpler model: `value` is the source of truth for current HP, NOT "damage taken from max." Scaling just clamps `value` to `[0, newMax]`. Verified in the running browser: write `value=32`, force re-prep, value stays at `32/39`. Move from Chest (max 39, value 35) to Head (max 20), value clamps to `20/20`.

**Bug 2: catalog records shipped with `value === base`, making fresh drops look pre-damaged.**

After Bug 1's fix, a Steel Plate dropped fresh on Chest landed at `28/39` instead of `39/39`. The catalog records ship with `armorHP: {base: 28, value: 28, max: 28}` — `value === base` was a sensible "full HP at neutral location" default, but after location-scaling pushes `max` to 39, `value` remains at 28 and the piece looks already-damaged.

Two clean fixes were available: (a) catalog records ship with `value: null` so first-prep initializes `value = newMax`, or (b) `applyArmorHPScaling` detects "value equals base AND base ≠ newMax" as the fresh-drop signature and resets value to newMax. Chose (a) — fewer special cases, self-documenting data.

Required code change too: my initial fresh-drop detection used `!Number.isFinite(Number(value))`, but `Number(null)` is `0` in JavaScript (a finite number), so null values weren't detected. Changed to check the raw `rawValue === null || rawValue === undefined` BEFORE coercion, then fall through to the existing finite/range checks. Verified:

- Fresh drop with value=null: lands at 39/39 ✓ (chest), 20/20 ✓ (head)
- Write value=30 (9 damage from 39): stays at 30/39 ✓
- Write value=-20: clamps to 0/39 ✓
- Heal to value=50 (over max): clamps to 39/39 ✓

All 26 armor catalog records updated to ship `armorHP.value: null`.

### Live smoke test results — broader system

Used the Chrome extension to drive Foundry VTT in the browser and exercise the full system. Findings:

**All clean:**
- System init: 35 casting helpers, 5 combat helpers, 16 Elysium API entries, 16 armor materials, location HP factors all loaded
- Mythras HP: CON 19 + SIZ 13 character correctly produces Chest 9 / Abdomen 8 / Leg 7 / Head 7 / Arm 6
- Armor HP scaling per body part: Steel Plate base 28 → Chest 39, Abdomen 34, Leg 28, Arm 24, Head 20 — all match spec
- Armor relocation: damaged piece moved to smaller location correctly clamps current HP
- Layering: Soft+Mail+Plate stack simultaneously on one location, total AP 7 + magical Cloak stacks freely
- Layering conflicts: Soft+Soft, Mail+Mail rejected with clear messages
- Per-stratum AP cap: AP 5 soft piece correctly rejected ("exceeds the 2 AP cap for soft armor")
- Damage-vs-armor by type:
  - Slashing/Piercing/Bludgeoning: full AP from all pieces
  - Fire/Cold: organic full, metal half (matches spec)
  - Lightning: metal bypassed (none), organic blocks full
  - Sonic: bypasses everything
  - Corrosive: full AP, wear events emitted (but uniform — see Phase B note)
- Template parse: all 53 system templates compile cleanly via `Handlebars.precompile()`
- Console errors during character-sheet render: zero (defensive try/catch wrapping is working)
- Drop pipeline: compendium → `_onDropItem` → `_onDropItemCreate` → `_BRPonDropItemCreate` → hit-location dialog → item created with hitlocID → `applyArmorHPScaling` runs → max scales, value initializes. Full end-to-end works.

**Known incomplete (not bugs — flagged for v0.21.0):**
- `computeCorrosiveArmorWear` applies uniform wear to every corrosive piece instead of cascading by `layerOrder`. The header comment already flags this: *"full cascade deferred to Phase B."*
- `computeCorrosiveArmorWear` uses `pieceName` rather than `pieceId` in wear events — can't disambiguate same-named pieces. Same Phase B.
- A few system templates contain trailing whitespace lines from earlier unwrap passes (cosmetic only; valid Handlebars).

**Observation about browser-extension automation against Foundry:**

Foundry's sub-windows (character sheets, item sheets, dialogs) shift focus to themselves in a way that detaches Chrome's extension content-script from the tab — Claude in Chrome reports "Cannot access a chrome-extension:// URL of different extension" until the sub-window is closed. Workaround: do functional testing entirely through `game.system.api.*` and direct document manipulation (no `sheet.render()` calls) — covers everything except visual UI verification. Visual UI testing requires the user to leave the sheet alone (not click into it) while the extension takes screenshots. Captured in `ROADMAP-v0.21.0.md` for future smoke-test sessions.


### Hotfix — armor.detail.hbs Handlebars parse error

User report: opening any armor item sheet threw `Parse error on line 82: Expecting 'OPEN_ENDBLOCK', got 'INVERSE'`.

Root cause: two `{{#if useWealth}}` blocks in `templates/item/armor.detail.hbs` had been unwrapped during the v0.20.0 settings cleanup (the `useWealth` setting was removed — Elysium always uses gold pieces — and the conditional was supposed to collapse to just its `{{else}}` branch). The unwrap pass kept BOTH branches in place and left stray `{{else}}` markers where the outer `{{#if useWealth}}` opener used to be. The Handlebars parser walked the file, saw `{{else}}` without an open block context to alternate against, and threw.

This is the fourth instance of the same bug class I've hit during the v0.20.0 audit (the others: `system['elysium']` mass mis-migration, multi-line import collapse, comment-bisected import names, and an earlier `{{else}}`-unaware unwrapper). Confirms the v0.21.0 lesson: bulk transforms on JavaScript and Handlebars should use real parsers (`@babel/parser`, the `handlebars` library's own AST), not regex.

Fix: replaced the two corrupted blocks with their intended post-unwrap content — Elysium always shows "Price (Gold)" with the numeric input/display, no more dropdown-vs-numeric branching. The outer `{{#if isGM}} ... {{else}} ... {{/if}}` structure (which preserved GM editable inputs vs player read-only displays) was undisturbed.

**Defensive check added to the build process.** Wrote a Handlebars precompile script (one-off; not added to the system runtime) that walks every `.hbs` in `templates/`, runs `Handlebars.precompile()` on it, and reports failures. Ran across all 76 templates — only `armor.detail.hbs` failed; the fix resolved it; the script then reported clean across all 76. Future v0.20.x hotfixes will run this check before packaging.

**Discovery:** my earlier custom Python `{{#if}}/{{/if}}` balance checker was producing false positives on `{{#*inline "name"}} ... {{/inline}}` Handlebars inline-partial syntax (because of the `*`) and false negatives on this kind of mid-block `{{else}}` orphaning. The Handlebars-native precompile catches both cases correctly. Updated my development notes; the v0.21.0 roadmap now recommends precompile-based validation in CI.

No code changes were needed — this was a template-only fix. Pack and ship.


### Armor catalog v2 — material × stratum + location HP scaling

Replaced the v0.20.0 material-only catalog (19 records) with the v2 material × stratum design (26 records). Three design changes per user direction:

**1. Material × Stratum SKU model.**

Worn armor now ships as one record per (material, stratum) combination. So Iron has TWO records — Iron Mail (AP 3, base HP 12) and Iron Plate (AP 4, base HP 22) — rather than a single Iron material that fills both roles. Same for every metal that can be both mail and plate.

Eligibility rules:
- Organic materials (cloth, leather, fur, hide) — soft stratum only
- Rigid biological (bone, dragonscale) — plate stratum only
- All metals (bronze, iron, steel, cold iron, silver, mithral, orichalcum, adamantite) — both mail and plate

This gives 4 soft + 8 metals × 2 strata + 2 rigid plates + 4 magical = 26 records.

**2. Comprehensive material catalog.**

Expanded `ELYSIUM.ARMOR_MATERIALS` with the rare and magical metals you requested:

- **cold iron** (`'cold-iron'` key) — bypasses fey, fiend, and magical-creature resistance. Same AP/HP curve as iron.
- **silver** — bypasses undead, lycanthrope, and silver-vulnerable resistance. Softer than iron (AP 2 mail / AP 3 plate, slightly lower HP).
- **mithral** (corrected spelling, was "mythril") — lightweight magical metal. AP 3 mail / AP 5 plate; HP 20 / 35.
- **orichalcum** — divine golden alloy. Slightly tougher than mithral (HP 22 / 38).
- **adamantite** — apex protection. AP 3 mail (HP 25) / AP 5 plate (HP 45).

Each material declares a `damageBucket` and additional traits like `antiFey`, `antiFiend`, `antiUndead`, `antiLycanthrope`, `lightweight`, `divine`, `indestructible`. The damage-vs-armor table already consults `damageBucket`; the anti-supernatural traits are descriptive in v0.20.0 (no automation yet) and ready for a future damage-vs-creature-type subsystem.

**3. AP fixed by material, HP scales by location.**

The catalog records carry `system.elysium.armorHP.base` (the HP for a Medium location — `leg`). At equip time, the bound hit-location's `bodyPart` is looked up in the new `ELYSIUM.ARMOR_LOCATION_HP_FACTORS` table:

| bodyPart | factor | Steel Plate HP (base 28) |
| --- | --- | --- |
| chest | 1.40 | 39 |
| abdomen | 1.20 | 34 |
| leg | 1.00 | 28 (baseline) |
| arm | 0.85 | 24 |
| head | 0.70 | 20 |

Extended factors are defined for non-humanoid body shapes: `wing` (0.90), `tail` (0.80), `hindleg` (1.00), `foreleg` (0.95), `hand`/`foot`/`paw`/`hoof` (0.50–0.55), `claw` (0.50), `shell` (1.50), `segment` (1.10).

A new `ElysiumMythrasHP.applyArmorHPScaling(actor)` method runs in `prepareDerivedData` after `applyToActor`. It walks every armor item on the actor; for each one with a bound `hitlocID`, it looks up the location's bodyPart, scales `armorHP.max = round(armorHP.base × factor)`, and clamps `armorHP.value` to preserve damage taken. Idempotent; safe to re-run.

Legacy records without `armorHP.base` (v0.19.x or pre-fix v0.20.0 worlds) get auto-migrated on first prep: the existing `armorHP.max` is copied to `base`, then scaling proceeds normally. No world migration script needed.

**Schema additions:**
- `armor.system.elysium.armorHP.base` (Number, default 10) — new field
- Updated armor item sheet shows three fields: "Base HP (Medium location)" editable, "Current HP" editable, and a read-only "max" display showing the location-scaled value. The sheet now makes the scaling visible to the player.

**Workflow at the table:**
1. Player drags `Steel Plate` from the compendium onto their character sheet
2. Hit-location dialog asks "Which location?" (existing flow)
3. Player picks Chest → the Steel Plate item lands on the character with `hitlocID` pointing at the Chest location
4. `prepareDerivedData` fires; `applyArmorHPScaling` looks up Chest's bodyPart, finds factor 1.40, sets `armorHP.max = round(28 × 1.40) = 39`
5. Player drops a second Steel Plate, picks Head → `armorHP.max = round(28 × 0.70) = 20`. Same record, different HP because helms have less surface area.
6. Damage to the chest piece subtracts from `armorHP.value`; the chest piece (39 HP) takes longer to break than the helm (20 HP) under sustained damage. Matches real-world intuition.

**Catalog summary table (base HP shown — actual HP varies by location):**

Soft (max stratum AP 2):
- Cloth/Padded AP 1 / 4 HP / 2gp
- Fur AP 1 / 5 HP / 8gp
- Leather AP 2 / 6 HP / 15gp
- Hide AP 2 / 8 HP / 10gp

Mail (max stratum AP 3):
- Bronze AP 2 / 10 HP / 60gp
- Iron AP 3 / 12 HP / 100gp
- Steel AP 3 / 15 HP / 200gp
- Silver AP 2 / 10 HP / 800gp (anti-undead, anti-lycanthrope)
- Cold Iron AP 3 / 12 HP / 1000gp (anti-fey, anti-fiend)
- Mithral AP 3 / 20 HP / 2000gp (lightweight)
- Orichalcum AP 3 / 22 HP / 3500gp (divine)
- Adamantite AP 3 / 25 HP / 5000gp

Plate (max stratum AP 5):
- Bone AP 4 / 12 HP / 40gp (brittle)
- Bronze AP 3 / 18 HP / 200gp
- Iron AP 4 / 22 HP / 400gp
- Steel AP 5 / 28 HP / 800gp
- Silver AP 3 / 18 HP / 2500gp (anti-undead, anti-lycanthrope)
- Cold Iron AP 4 / 22 HP / 3000gp (anti-fey, anti-fiend)
- Mithral AP 5 / 35 HP / 8000gp (lightweight)
- Orichalcum AP 5 / 38 HP / 12000gp (divine)
- Adamantite AP 5 / 45 HP / 20000gp (indestructible)
- Dragonscale AP 4 / 25 HP / 6000gp (fire/acid resistance)

Magical (stacks freely, one per location):
- Cloak of Resistance AP 1 / 5 HP / 1500gp
- Bracers of Defense AP 2 / 8 HP / 2500gp
- Robe of Protection AP 2 / 6 HP / 3000gp
- Dragonscale Mantle AP 3 / 18 HP / 12000gp

All 26 records validated against per-stratum AP caps (soft ≤ 2, mail ≤ 3, plate ≤ 5). Total compendium record count: 906 (was 899; armor went 19 → 26).


### Armor compendium redesign — material-based catalog

User feedback: the v0.20.0 armor list (Iron Helm, Chain Coif, Padded Cap, ...) was wrong for the design. Armor should be material-based — the player picks a material, drops it on the character, the hit-location dialog assigns the location. AP and HP are intrinsic to the material; stratum is derived from material.

**Old catalog deleted, new one shipped.** The previous 27 records were named per-piece (helm, coif, breastplate, vambraces, etc.) which forced players to find a chain helm AND a chain shirt AND chain chausses etc. for full chain mail coverage. The new catalog has one record per material; the same `Steel Plate` item dropped on Head becomes a helm, dropped on Chest becomes a cuirass, dropped on Arm becomes pauldrons. Schema-wise the item is identical; the location-name comes from the hit-location it's bound to.

**New armor catalog (19 records):**

Soft stratum (max AP 2):
- Cloth / Padded Garment — AP 1 / HP 4 / 2gp
- Fur Armor — AP 1 / HP 5 / 8gp
- Hide Armor — AP 2 / HP 8 / 10gp
- Leather Armor — AP 2 / HP 6 / 15gp

Mail stratum (max AP 3):
- Bronze Mail — AP 2 / HP 10 / 60gp
- Iron Mail — AP 3 / HP 12 / 100gp
- Steel Mail — AP 3 / HP 15 / 200gp
- Mythril Mail — AP 3 / HP 20 / 2000gp
- Adamantite Mail — AP 3 / HP 25 / 5000gp

Plate stratum (max AP 5):
- Bone Plate — AP 4 / HP 12 / 40gp (brittle — low HP for the AP)
- Bronze Plate — AP 3 / HP 18 / 200gp
- Iron Plate — AP 4 / HP 22 / 400gp
- Steel Plate — AP 5 / HP 28 / 800gp
- Mythril Plate — AP 5 / HP 35 / 8000gp
- Adamantite Plate — AP 5 / HP 45 / 20000gp

Magical (layer='magical', no stratum, stacks freely; one per location):
- Cloak of Resistance — AP 1 / HP 5 / 1500gp
- Bracers of Defense — AP 2 / HP 8 / 2500gp
- Robe of Protection — AP 2 / HP 6 / 3000gp
- Dragonscale Mantle — AP 3 / HP 18 / 12000gp

**Encumbrance and modifiers scale by stratum** (per piece):
- Soft: 0.8 enc/AP, no movement/perception/stealth penalties
- Mail: 1.2 enc/AP, −10 manipulation, −5 perception/physical, −10 stealth
- Plate: 1.5 enc/AP, −15 manipulation, −10 perception/physical, −15 stealth

So a Steel Plate (AP 5) on Chest contributes 7.5 enc and the plate-stratum modifiers; the same record on Head contributes the same numbers — the hit-location-specific "feel" is left to the GM (or future per-location encumbrance scaling, deferred to v0.21.0).

**Bone is brittle.** Per user direction: "Bone is hard so same layer as Plate but would have fewer HP since it is more brittle." Bone Plate ships at AP 4 / HP 12 — comparable AP to Iron Plate's AP 4 / HP 22, but the bone armor only absorbs about half the wear before it breaks. The brittleness flavor is captured in the description; if mechanical fragility (e.g. bone takes double damage from bludgeoning) is wanted later, that's a v0.21.0 material-trait extension.

**ARMOR_MATERIALS catalog expanded** to support the new materials. Each material now declares a `damageBucket` ('organic' | 'metal' | 'rigid' | 'natural') that the damage-vs-armor table consults:

- 'organic' (cloth, leather, fur, hide): insulates against fire/cold (full AP), blocks lightning (non-conductive), vulnerable to acid
- 'metal' (bronze, iron, steel, mythril, adamantite): conducts (lightning bypasses), half AP vs fire/cold, varies on acid (mythril & adamantite resist)
- 'rigid' (bone, dragonscale): non-conductive but transmits heat through (half AP vs fire/cold)
- 'natural': intrinsic body armor

The legacy `'metal'` material key is preserved for backward compat with v0.19.x records.

**Damage-vs-armor table updated** to use the new `damageBucket` classification. Replaced the v0.19.x cloth/non-cloth split:

```
fire/cold:  full AP for 'organic', half for everything else
lightning:  none vs 'metal', full vs everything else
```

This means Mythril Plate now correctly half-blocks fire damage (it's metal, half AP) but Dragonscale Mantle also half-blocks it (rigid bucket, same behavior). Bone Plate half-blocks fire too despite being non-metal — correct, because hard plate transmits heat regardless of composition.

**Side effects on the wider system:**

- The armor item sheet's material dropdown now lists all 13 materials (was 4). User-created armor items get the full catalog.
- All 19 records pass the per-stratum AP cap check (soft≤2, mail≤3, plate≤5) and the per-location total cap (≤10).
- The legacy "Padded Cap / Iron Helm / Chain Coif" names are gone — players can no longer accidentally end up with mismatched per-piece coverage. The drop dialog already prompts for location, so the workflow becomes: drag material → pick location.

**Total compendium record count**: 899 (was 907; armor went 27 → 19).

This is a breaking change to existing characters using v0.20.0-pre records — their armor items will still exist (the records were already on disk; this just replaces the compendium template) but new drops will use the new catalog. World migration is not needed since the field schema didn't change; only the record set did.


### Hotfix — armor compendium + drop handler

User reported a runtime error trying to drop armor on a character sheet. Investigation found three layered bugs that together broke armor drops entirely:

**Primary bug: armor drop handler had an inverted HPL check.**

`module/actor/actor-itemDrop.mjs::_BRPonDropItemCreate` had this leftover from a `useHPL` unwrap pass:

```js
if (nItm.type === 'armor') {
  if (nItm.system.HPL) {
    reqResult = 0;
    errMsg = nItm.name + " : " + game.i18n.localize('BRP.armorNotHPL');
  }
  // ... hit-location dialog ...
}
```

The original BRP-canon logic was `if (!useHPL && nItm.system.HPL) { reject — "this is HPL armor but you're in flat mode" }`. When `useHPL` was hardcoded to true and unwrapped, the outer guard disappeared but the inner `if (nItm.system.HPL)` check remained — now inverted in meaning: it rejected armor that IS marked HPL-compatible, in a system where HPL is always on. And every shipped armor record in the compendium had `system.HPL: true`. So **every armor drop** failed with "This armor is not compatible with Hits Per Location."

Fixed by removing the dead `nItm.system.HPL` rejection. The drop handler now simply prompts for a hit-location every time (which is correct in Elysium where HPL is always on).

**Secondary bug: layering classifications were inferred and wrong for mail-tier armor.**

The 27 shipped armor records (in `Elysium_Compendium-v0.20.0/packs/armor.db`) had no explicit `system.elysium.layer` or `system.elysium.wornStratum` fields. The layer-conflict resolver in `register-hooks.mjs` falls back to inference from `flexibility`:

```js
flexibility === 'inflexible' → wornStratum 'plate'
flexibility === 'natural'    → layer 'natural'
otherwise                    → wornStratum 'soft'
```

This worked for plate (correctly → plate stratum, AP cap 5) and most cloth/padded (correctly → soft, AP cap 2). But every chain and scale piece had `flexibility: 'flexible'` → inferred as **soft stratum**. With the soft cap at AP 2, three records exceeded the cap and would silently fail the per-stratum AP check on equip:

- Scale Coif (AP 3) — flagged as soft, exceeds soft cap 2
- Chain Hauberk (AP 3) — same
- Scale Mail (AP 3) — same

And several more (Chain Coif, Chain Shirt, Chain Sleeves, Chain Chausses, Brigandine) were classified soft when they should have been mail — they passed the cap check by coincidence but would have triggered a stratum collision with actual soft armor (e.g. equipping a Padded Gambeson then trying to add a Chain Shirt would have failed with "only one soft piece per location" because both were mis-classified soft).

Fixed by adding explicit `system.elysium.layer: 'worn'` and `system.elysium.wornStratum: <correct>` to all 27 armor records, derived from the `system.elysium.material` field:

- cloth, padded, gambeson, quilted, leather → soft
- chain, scale, brigandine, lamellar → mail
- plate → plate
- Cloak of Resistance → layer 'magical' (no stratum)

Also added the `layer` and `wornStratum` fields to the armor schema in `template.json` so custom user-created armor items get sensible defaults instead of relying on inference. The armor item sheet already has dropdowns for both fields (in `_injectArmorFields`), so GMs can override them per-piece — they now show the explicit values from the compendium records instead of inference results that don't match what the data implies.

**Tertiary bug: dead `system.HPL` field and toggle.**

With HPL always-on in Elysium, the BRP-canon `system.HPL` boolean (indicating "this armor is hit-location-compatible") is meaningless. Cleanup:

- Removed the HPL toggle UI from `templates/item/armor.detail.hbs`
- Stripped the `system.HPL` field from all 27 compendium records
- Removed the field from the armor schema in `template.json`
- Removed the `'HPL'` entry from the `system['elysium']`-allowlist in `base-item-sheet.mjs::_onItemToggle` (was a safety filter; now an unreachable case)
- Removed three lang keys: `BRP.armHPL`, `BRP.armHPLHint`, `BRP.armorNotHPL` from en.json, es.json, fr.json (where applicable)

**Verification**: re-ran the per-stratum AP cap check across all 27 armor records — zero failures. The chain/scale equipment now correctly occupies the mail stratum (AP cap 3, so AP 3 fits) and is distinguishable from soft (cloth/leather) when checking for stratum collisions.

**Future-work doc**: created `ROADMAP-v0.21.0.md` capturing the sheet-extension split (2363 lines, 41 methods → per-tab modules), the dead flat-HP code path in `actor.mjs::_prepareCharacterData`, the `register-hooks.mjs` split, and the general lesson learned about regex-based AST surgery (use real parsers next time). This is the place new v0.21.0 work should go.


### Smoke-test audit pass — major endemic bug fixed + structural cleanups

A targeted audit pass across three phases of the system, prompted by the runtime crashes that surfaced during initial smoke testing. The headline finding was a single bug class that turned out to be systemic.

**The headline find: `system['elysium']` was wrong everywhere.**

Static scan found **114 sites across 24 files** reading `item.system?.['elysium']?.X` when the canonical schema path is `item.system.elysium.X`. Confirmed via `template.json` inspection that NO Item or Actor type has an `'elysium'` key at the `system` level — all Elysium data lives at `system.elysium.{field}`. Confirmed via grep that NO code writes to `system['elysium']` anywhere. So every one of the 114 reads was returning `undefined` and silently falling back to default values.

Origin: the earlier flag-namespace migration wave that renamed `flags.elysium` → `flags['elysium']` mistakenly migrated `system.elysium` paths too in many files. The fix was previously applied piecemeal — in `ancestry-drop.mjs` (4 sites), `actor.mjs::prepareDerivedData` (5 sites for power-tab activation), and `sheet-extension.mjs` (10 weapon-reach sites) — but the systemic scope wasn't recognized until this audit.

Impact of the fix — data that NOW actually flows through:
- **Combat damage**: weapon `damageBonusMultiplier`, armor `material` vs damage-type interactions, hit-location-targeted damage routing
- **Casting**: every spell `tier`, `apCost`, `powerCost`, `school`, `domain`, `essence`, `validSchools`, `baseline`, `requiredSL`, `isDamageSpell`, `isReactive`, `isSustained`, `forbidden`, `effectByTier`, `apCostByTier`, `damageByTier`, `damageType`, `saveSkill`, `maintainPPPerRound`, `school`, `discipline`, `forms`, `techniques` — 60+ sites in `arcane-cast.mjs` / `divine-cast.mjs` / `sorcery-cast.mjs` / `mysticism-cast.mjs` / `cast-shared.mjs` / `spell-learning.mjs` / `manipulation-dialog.mjs` / `tier-choice-dialog.mjs` / `custom-spell-builder.mjs`
- **Mythras HP**: body-part-based HP calculation in `mythras-hp.mjs` (correct lookup of `bodyPart` and `maxHPModifier`)
- **Engagement / charge**: weapon `reach` (10 sites across `engagement-ui.mjs` / `charge-ui.mjs`), `weaponSize`, `creatureSubtype`, `creatureTags`
- **Critical rolls**: body-part routing in `critical-roller.mjs`
- **Active effects**: location-conditions list in `factory.mjs` (apply/clear)
- **Combat extension**: `locationConditions` for end-of-turn ticks, `maxHPModifier` persistence for Withered
- **Actor extension**: ancestry lookup, leg-part detection for movement penalties
- **Effect grades**: `gradeModifiers`, `activation` profile for themed abilities
- **Item sheets**: `abilityType` for percentile abilities, stored forms/techniques on arcane sheets
- **Character sheet**: skill category/subgroup categorisation, arcane-role partitioning, passion category-based partitioning
- **Power-tab activation in `actor.mjs::_prepareCharacterData`**: was already partially fixed but had remaining sites for `skillSubgroup === 'sorcery'`, `'mysticism'`, `'divine'` (was previously only activating based on direct items)

Without this fix, the v0.20.0 build would have shipped with damage modifiers always reading 1.0, every armor piece behaving as `cloth`, every weapon reaching as `M`, every spell costing exactly 1 AP / 1 PP, every wound criticalling the same body-part table, no themed-ability grade modifications applying, no max-HP loss conditions persisting. **A huge portion of the system's mechanical surface was non-functional.**

The fix itself was mechanical (`.system?.['elysium']?.` → `.system?.elysium?.`, plus the non-optional variants) because there were zero legitimate writes to the wrong path — if any existed, they'd be cleaned-up separately, but in this case the fix was unambiguous.

**Phase 1 — hook flow + initialization. Rewrote two foundational files.**

- `brp.mjs` consolidated. Module-load-time side effects went from one `BRPHooks.listen()` plus 7 inline `Hooks.on()` calls down to a single `Hooks.once('init', ...)` and `Hooks.once('ready', ...)`, with `_registerLifecycleHooks()` doing the wiring. Duplicate ready handler merged. `_configureInitiative()` and `_runVersionMigrationIfNeeded()` factored out. Total: cleaner load order, all subsystems guaranteed to see `game.brp` and `CONFIG.BRP` before they're consulted.
- `hooks/init.mjs` rewritten. Multi-line imports cleaned up (no more regex-mangled single-line concatenations with trailing inline comments). API construction split into `_buildCastingApi()` and `_buildCombatApi()` helpers so the Init function stays narrow and the API surface is easy to spot.
- Two dead hook files deleted: `render-actor-sheet.mjs` and `render-item-sheet.mjs`. Both registered `Hooks.on(..., () => {})` — empty function bodies. The `BRPHooks.listen()` chain in `hooks/index.mjs` updated to drop them.

**Phase 2 — sheet rendering paths. Defensive isolation.**

Each independent injection in `ElysiumSheetExtension.extendActorSheet` and `extendItemSheet` now runs in its own try/catch with a stable error tag (`Elysium | <step>`). Previously, a single bad injection — say, the wound-tier badge logic encountering an unexpected item shape — would throw mid-render and prevent every subsequent injection from running. Now each injection is isolated: failures log to the console with a step name and the others continue. The sheet renders even if one decoration is broken.

Confirmed via static scan that all 54 setting reads in `module/` resolve to 54 registered keys.

**Phase 3 — casting + combat APIs.**

The bulk of the `system['elysium']` fixes were here (described above). Beyond that, no additional bug class found at this layer — the casting pipelines themselves are well-structured.

**Additional code-quality cleanups (caught by the audit):**

- **18 dead `await arr.filter/find/map(...)` patterns** in `combat/damage.mjs`, `actor/actor-itemDrop.mjs`, `actor/sheets/character.mjs`. `await` on a synchronous array method is misleading — it's a no-op that suggests the call is async when it isn't. Stripped.
- **5 dead `&& true)` and `(true &&` conditionals** — relics of `useHPL` unwrap passes. Simplified.
- **3 `if (true) { A } else { B }` blocks** unwrapped to keep `A` and drop the unreachable `else`. Affected `combat/damage.mjs`, `actor/actor-itemDrop.mjs`, `actor/actor.mjs`.
- **`async` removed from `_prepareCharacterData` and `_prepareNpcData`** in `actor/actor.mjs`. Foundry calls `prepareDerivedData()` synchronously and expects synchronous completion; marking these methods async was misleading and fragile (no actual `await` in either body).
- **Dead variable removed**: `const flags = actorData.flags.boilerplate || {}` in `prepareDerivedData`. Leftover from Foundry's boilerplate system template; never read.
- **EDU visibility checks simplified**: three sites had `if (key === 'edu' && true /* v0.20.0: EDU not used in Elysium */) { stat.visible = false }`. Replaced with the equivalent `stat.visible = key !== 'edu'`.
- **`if (actorData.type === 'npc')` brace-less body** in `_prepStats` wrapped in explicit braces for safety.
- **Orphan stale comment removed** from `_onPreUpdateActor` (`// header inputs target it directly. No reroute needed any more.)` — was vestigial, replaced with an explanation of what the snapshot-prevHealth logic is doing.
- **Tightened combat-hook bodies** in `register-hooks.mjs` (no blank lines before a single-call body).

**Confirmed clean afterwards:**
- All 132 `.mjs` files pass `node --check`
- All 5 JSON files (system, template, en/es/fr lang) validate
- 907 compendium records across 22 packs parse cleanly
- Zero `system['elysium']` reads remain (was 114)
- Zero `await arr.filter/find/map` remain
- Zero `if (true)` / `&& true)` / `(true &&` dead conditionals remain
- All 54 setting reads have matching registrations

**Deferred to v0.21.0** (flagged but not addressed):
- The flat-HP BRP-classic code path in `actor.mjs::_prepareCharacterData` (lines computing `health.value`, BRP-style hit-location maxHP via `Math.ceil(health.max / fractionHP) + adj`, dead/unconscious status based on flat `health.value`). The Mythras HP module overrides all of this work each prep cycle, so the BRP-classic path is wasted CPU but not user-visible. Removing it would require ensuring no other code path consults `system.health.value` for character actors. Architecturally a clean refactor; cosmetically a non-bug. Out of scope for v0.20.0.


### Audit cleanup pass

Systematic dead-code audit following the settings cleanup waves. Findings + fixes:

**Real bug fixed: character header derived-stats blank.** The character header template at `character.header.hbs:184-202` read seven derived-stat cells from `actor.flags.elysium.derived.*` — but the namespace was renamed to `flags.elysium.derived.*` earlier in this release. Every cell rendered empty: Damage Modifier, Healing Rate, XP Bonus, Power Points Max, Luck Points Max, Action Points Max, Initiative. Fixed by switching to Handlebars bracket-key syntax `flags.[elysium].derived.X` (the hyphen requires bracket escape).

**BRP-fatigue dead-code purge.** With `useFP` deleted in the prior wave, the BRP-classic flat fatigue pool (`system.fatigue.value`/`max`/`mod`/`effects`) no longer has any UI surface. Cleaned up the dangling writes:
- `actor.mjs::prepareDerivedData` was computing `system.fatigue.max = ceil(STR + CON - ENC + mod + effects)` for both character and NPC actors every prep cycle. Removed (the value was never read).
- `actor.mjs::prepareDerivedData` was overwriting `system.fatigue.label` and `system.fatigue.labelAbbr` with BRP-classic strings ("Fatigue", "FP") — clobbering the Mythras ladder labels the fatigue manager writes there. Removed.
- `actor.mjs::updateVitals` and `base-actor-sheet.mjs::_onRollCharStats` wrote `system.fatigue.value = max` after stat rolls. Removed (dead write).
- `setup/config.mjs::BRP.keysActiveEffects` had `'system.fatigue.effects': 'BRP.fatigue'` as a valid AE target in the AE config dropdown. Removed.
- `templates/actor/npcV2.main.hbs` had a BRP-FP-bonus input field (`system.fatigue.mod`). Removed.

**Dead template conditionals unwrapped.** Eight context flags were hardcoded to constant values in `character.mjs` and `base-actor-sheet.mjs`: `useHPL=true`, `useAlleg=true`, `usePassion=true`, `usePersTrait=true`, `useBeastiary=true`, `useWealth=true`, `useEDU=false`, `useFP=false`. Their template `{{#if useX}}` branches were dead conditional logic — the body either always rendered or never rendered. A Handlebars-aware unwrapper walked 9 templates (`character.header`, `character.combat`, `character.items`, `character.social`, `character.pers`, `npcV2.main`, plus 3 item-detail templates), found every `{{#if X}}` / `{{#unless X}}` / `{{#isOr X useBeastiary}}` block involving these flags, and either unwrapped to the body (always-true cases) or deleted the block entirely (always-false cases). Total dead-branch eliminations: ~30+ across the actor and item sheets. Context flag assigns also stripped from `character.mjs` and `base-actor-sheet.mjs`; the `useSocialTab`/`usePersTab` tab-visibility derivations simplified to constant `true`.

**Stale namespace references fixed.** `module/elysium/actor/ancestry-drop.mjs` had three sites with `data.flags['elysium'] = data.flags.elysium || {}` — a fallback to the pre-merge rules-module namespace. With backward compatibility dropped earlier this release, the fallback can't fire (no such namespace exists), so the code reduces to `data.flags['elysium'] ??= {}`. Same kind of stale reference cleaned up in ~6 doc comments across other files.

**Zero-read settings deleted.** `statNaturalMaxBase` and `startingSkillCap` were registered as Elysium-subsystem settings but never read by any code path. The actual values come from `ELYSIUM.STAT_NATURAL_MAX_BASE` and `ELYSIUM.STARTING_SKILL_CAP` in `config/config.mjs`. Both settings deleted. Final Elysium subsystem count: 10 settings (was 12 at the start of this audit, ~25 at the start of the v0.20.0 release).

**Empty hook handler deleted.** `_onPreCreateActor` had an empty body — the original logic (initializing `flags.elysium` defaults on actor creation) was moved into `template.json` during the migration-removal wave, but the empty stub remained registered. Function and its `Hooks.on('preCreateActor', ...)` registration both removed.

**Orphan lang keys pruned.** Static scan found 69 English / 71 Spanish / 72 French lang keys defined but never referenced anywhere in the codebase, including:
- Six pre-Elysium BRP magic-system settings (`useMagic`, `usePsychic`, `magicLabel`, `psychicLabel` + hint variants)
- Four legacy display settings (`actorTabNameHoverColour`, `actorTabNameShadowColour` + hint variants)
- 21 `Elysium.Weapon.*` keys for weapon-field labels that were planned for localization but never wired (current templates hardcode English)
- Various stragglers across `Elysium.HP`, `Elysium.TempHP`, `Elysium.BP`, `Elysium.SP`, `Elysium.Cancel`, `Elysium.Apply`, etc.

The scanner preserved keys in dynamically-referenced namespaces (`TYPES.Actor.*`, `TYPES.RegionBehavior.*`, `BRP.TABS.*`, `BRP.wealthLevel.*`) where the access pattern is `localize('BRP.TABS.' + tabName)` rather than literal key references.

**Unused imports stripped.** 52 unused `import { X }` named imports across 99 .mjs files removed. Most were stragglers from refactoring waves where the imported symbol was no longer referenced in the consuming file (e.g. `BRPContextMenu`, `BRPDamage`, `BRPUtilities` imported but unused in `character.mjs`). Foundry's module loader doesn't tree-shake, so unused imports were genuinely loading dead code on every world startup.

### Hotfix — broken Handlebars conditionals across 9 templates

Character sheet failed to render with `Parse error: Expecting 'EOF', got 'INVERSE'` at `character.header.hbs:149`. Root cause: my Handlebars conditional unwrapper from audit pass 1 didn't handle `{{else}}` clauses correctly.

The original templates contained patterns like:
```hbs
{{#if useWealth}}
  ... wealth level dropdown (use case A) ...
{{else}}
  ... numeric wealth input (use case B) ...
{{/if}}
```

For an always-true flag like `useWealth`, the correct rewrite is to keep the if-body and drop the else-body. My unwrapper instead removed just the opener and closer, leaving the entire `{{else}} ... {{/if}}` block dangling without a matching opener.

**Rewrote the unwrapper** to properly find `{{else}}` at the same nesting depth as the opener and split the block into true/false branches. The new logic:
- For `{{#if X}} A {{else}} B {{/if}}` with X always-true → emit A
- For `{{#if X}} A {{else}} B {{/if}}` with X always-false → emit B
- For `{{#if X}} A {{/if}}` (no else) with always-true → emit A
- For `{{#if X}} A {{/if}}` (no else) with always-false → drop entirely
- `{{#unless X}}` inverted

Re-ran the unwrapper from the **original** source templates (not the broken work copies), then applied the orthogonal edits that the earlier audit had layered on top:
- `flags.elysium.derived` → `flags.[elysium].derived` rename in `character.header.hbs` (7 sites)
- BRP-FP-bonus input block removal in `npcV2.main.hbs`
- `armour` → `armor` rename (case-preserving) in all 9 templates

A systemwide Handlebars balance check (open/close/else counts across every `.hbs` file, including nested blocks) confirms all 156 templates are now balanced.

**Also restored**: `context.useHPL = true` in `character.mjs::_prepareContext`. The audit-pass cleanup removed the assign on the assumption that all references were just template `{{#if useHPL}}` (now unwrapped). But three JS reads remained in `_prepareItems` (line 415, 468) and the armor-list assembly (line 674) — these gate logic that still needs to run. The assign is restored with a comment explaining why; the three reads now correctly evaluate to truthy.

The lesson this time: my unwrapper was syntactically incorrect for the `{{else}}`-having case. The audit caught broken templates immediately on first sheet render — exactly the kind of bug that should have been caught by a Handlebars syntactic balance check after the unwrap pass. Adding that check post-hoc found three broken files (`character.header.hbs`, `character.combat.hbs`, `gear.detail.hbs`) and one file with stale flag-conditional logic in JS.

### Hotfix — manipulationCost / clearProactiveAPGate missing in init.mjs

Init crashed with `ReferenceError: manipulationCost is not defined` at `init.mjs:75`. Two imports from `../casting/cast-shared.mjs` had been dropped by the unused-imports sweep: `manipulationCost` and `clearProactiveAPGate`. Both ARE used (exposed via `game.system.api.casting`).

Root cause of the regex bug: the original `init.mjs` had a multi-line import with embedded `//` comments between names:

```js
import {
  refundPP, computeSL, classifyRoll,
  // v0.10.0
  manipulationCost, manipulationDiscount, summariseManipulation,
  ...
}
```

When my unused-imports regex split the captured names by `,`, one chunk came out as the multi-line string `"
  // v0.10.0
  manipulationCost"`. The usage check then searched for that whole literal string in the rest of the file, found zero matches, and dropped the name as "unused". Same for `clearProactiveAPGate` after the `// v0.10.2 proactive AP gate` comment.

A targeted audit (verify every property-shorthand name in `game.system.api = {...}` object literals resolves to a bound name) confirmed only these two names were affected and that no other api-object shorthand has unresolved references.

The lesson, again: regex-based AST surgery on JavaScript needs to strip comments from import bodies before splitting names. The fix for this is straightforward (preprocess `imports_str` by stripping `//...` comments before splitting on commas), but at this point the audit caught everything and the build is consistent — no further mass-edits planned in this release.

### Hotfix — allegiance.mjs missing import

`module/item/sheets/allegiance.mjs` had its `import { BRPItemSheetV2 } from './base-item-sheet.mjs'` line commented out, causing `Uncaught ReferenceError: BRPItemSheetV2 is not defined` when opening any allegiance item sheet. Restored the import.

A system-wide static audit (parse all `extends X` and `new X(...)` references, check each name resolves to an `import` or local definition or known global) confirmed this was the only file affected — all other 129 .mjs files have correctly-imported base classes.

The damage traces back to a transformation in an earlier flag-namespace pass that mishandled this specific file's original layout: line 1 was a pre-existing commented-out import (`//import { addBRPIDSheetHeaderButton } from '../../brpid/brpid-button.mjs'`) followed by line 2 with the real import. The real import line got rewritten to use the commented-out line's prefix.

### Feature: hit-location auto-application on ancestry drop

A culture/ancestry item can now declare which Mythras body shape it represents (`humanoid`, `quadruped`, `winged-quadruped`, `centaur`, `avian`, `serpentine`, `hexapod`, `humanoid-hexapod`, `amorphous`), and the matching hit-location set is auto-applied when the ancestry is dropped on a character. The 9 GM macros for manual application remain available for NPCs and ad-hoc use.

**Architecture.**
- `ELYSIUM.HIT_LOCATION_SETS` in `config/config.mjs` is the single source of truth — a map from shape key to an array of part specs `{ name, low, high, displayName? }`. The 9 standard Mythras body shapes are defined here.
- `culture.system.elysium.ancestry.hitLocationSet` (new field on the schema) stores the shape key per ancestry. Defaults to `'humanoid'`.
- `ElysiumAncestryDrop.applyHitLocationSet(actor, shape)` is the shared apply helper. It sources records from the `elysium-compendium.hit-locations` pack, overrides each record's roll range per the spec, removes any existing hit locations on the actor to avoid mixing creature-type sets, then creates the new ones. Returns the number of locations applied.
- The ancestry-drop flow (`handlePostCreate`) calls this helper as step 10 of the apply sequence, after move stats and before subrace processing. If a subrace is selected, the subrace's own `hitLocationSet` (if specified) takes precedence; otherwise the parent ancestry's shape is used.

**UI.** The ancestry-fields fieldset on the culture item sheet (injected by `ElysiumSheetExtension._injectAncestryFields`) now has a Hit-Location Body Shape dropdown listing all 9 shapes from `ELYSIUM.HIT_LOCATION_SET_LABELS`. The author of a custom ancestry picks the shape there.

**Macro refactor.** The 9 GM hit-location apply macros (`Apply Humanoid Hit Locations`, etc.) previously hardcoded their part specs inline (~2.5–4KB each). They now delegate to `game.system.api.elysium.ancestryDrop.applyHitLocationSet(actor, shape)` with the shape key as a single argument. Each macro is now ~1KB and the part specs live in exactly one place (`config.mjs`). Adding a new body shape now requires editing one config table and (optionally) writing a one-line macro — no per-macro spec maintenance.

**Compendium records.** All 20 shipped ancestries (Elf/Dwarf/Gnome/Halfling/Human variants) explicitly set `hitLocationSet: 'humanoid'`. Custom ancestries added by GMs default to `'humanoid'` when the field is missing.

**Pre-existing bug fixed.** `ancestry-drop.mjs` had four reads of `item.system?.['elysium']?.ancestry`, but the canonical schema path is `item.system.elysium.ancestry` (per `template.json`; confirmed by the file's own writes at lines 107-108). The bug came from an over-eager bulk replace during the earlier `flags.elysium → flags['elysium']` namespace rename — `system.elysium` paths got incorrectly migrated too. This affected only the *read* paths; the writes were correct. The consequence: `handlePreCreate`, `handlePostCreate`, and `handlePostDelete` all returned `undefined` for `ancestry`, so every ancestry effect (stat mods, BP/SP pools, traits, natural armor/weapons, resistances, languages, stat maxima, move) silently failed to apply. Dragging an ancestry onto a character was effectively a no-op. Fixed: all four sites updated to `item.system?.elysium?.ancestry`. A systemwide grep for the same pattern (`system['elysium']`) confirmed zero remaining instances.

This bug was likely the most impactful regression in the v0.20.0 release — the ancestry system was the headline feature and it was non-functional. The fix unblocks the entire ancestry → character-creation flow.

### Audit cleanup pass 2 — CSS, helpers, compendium

Continued cleanup after the main audit pass. Three additional categories cleaned:

**CSS dead-selector pass.** Static scan against the codebase (templates + JS that emits HTML) found 68 CSS classes with no callers. After excluding Foundry-framework classes (`.editor-container`, `.theme-dark`, `.sheet-body`, etc. — emitted by Foundry itself even though our CSS styles them), and after confirming that prefix-style classes like `.elysium-damage-*`, `.elysium-tier-*`, `.outcome-*`, `.severity-*` are alive via Handlebars template-literal emission (`elysium-damage-${type}`, `outcome-{{this.outcome}}`), 29 truly-dead classes remained:

- `.elysium-weapon-fields` + 5 sub-classes (the standalone Elysium weapon fieldset, replaced by inline rendering in BRP's `weapon.detail.hbs`)
- `.magic-tab-grid`, `.psychic-listitem` (pre-Elysium magic/psychic item types, now arcane/mysticism)
- `.combat-attributes` (the BRP-classic non-HPL combat panel, removed in the `useHPL` template unwrap)
- `.elysium-stat-spacer`, `.elysium-stat-value`, `.elysium-range-sep`, `.elysium-skill-categories` (vestigial from earlier sheet-extension drafts)
- 18 other one-off vestiges (`.GR-item`, `.aura-img`, `.background-doc`, `.bottom-panel`, `.brp-header`, `.dsn-hide`, etc.)

A depth-aware CSS pruner walked the rule blocks and either dropped rules whose entire selector list was dead (34 rules removed) or trimmed selectors whose comma-list contained dead alternatives (5 rules pruned).

Net: 149 fewer CSS lines (~3.7 KB), no functional change.

**Handlebars helpers file deleted.** `module/elysium/helpers/handlebars.mjs` registered six helpers (`elysiumFatigueLabel`, `elysiumPips`, `elysiumSigned`, `elysiumEssenceTier`, `elysiumDifficulty`, `elysiumJoin`), none of which had any caller in templates or code. The helpers were leftovers from earlier sheet-extension drafts that moved the same computations into `_prepareContext`. File deleted entirely; the `registerHandlebarsHelpers()` call removed from `elysium.mjs::init`. If specific helpers are needed in the future, a fresh helpers file can be added.

**Compendium pack flag-namespace migration.** Static scan of all 907 compendium records found 59 records (in `conditions.db`, `critical-tables.db`, `magic-tables.db`) still using the pre-merge `flags.elysium.X` namespace instead of the new `flags.elysium.X`. The flag block (`{ "elysium": { "conditionCategory": "dot" } }` etc.) was migrated to `{ "elysium": { "conditionCategory": "dot" } }` in-place. No consumers currently read this field, but if any code paths come to depend on it in the future, the data will now be in the correct location.

Records with both namespaces (none found, but the migration handled this case) would have merged the old data into the new namespace with the new taking precedence on conflict.

### Result of audit + audit-pass-2 combined

- **Module code:** 30,293 lines across 130 .mjs files (was 30,476 in 131 files at start of audit)
- **CSS:** 5,137 lines (was 5,286)
- **Handlebars templates:** 6,331 lines
- **Elysium settings:** 10 (was 12 at start of audit; was ~25 at start of v0.20.0)
- **Compendium:** 907 records, all flag namespaces consistent at `flags.elysium`

All `.mjs` pass `node --check`. All JSON validates. All 22 pack `.db` files parse cleanly.


### Result

- **143 fewer lines** in module/* (10,645 → 10,502 in elysium subsystem alone)
- **64 fewer English lang keys** (1168 → 1104) — equivalent reductions in es.json and fr.json
- **2 fewer Elysium settings** (12 → 10), removing two non-functional placebos
- **One real rendering bug fixed** (character header derived stats)
- **One ladder-clobber bug fixed** (Mythras fatigue labels were overwritten every actor-prep cycle by the BRP-classic constants)

All `.mjs` files pass `node --check`. All JSON validates. All 22 pack `.db` files parse cleanly (907 records, unchanged).

### Hotfix — engagement namespace migration and weapon system-path reads

Second wave of regressions from the rules-module-into-system merge. User reported `ReferenceError: engagement is not defined` thrown from `_injectEngagementBadgesOnCombatTab` on character sheet render. Investigation found a broader pattern.

**Bug 1: `_injectEngagementBadgesOnCombatTab` missing local declaration.** The original rules-module code at the top of the function read `const engagement = game.elysium?.engagement` — sourcing the engagement module from the pre-merge rules-module global. When the rules module was folded into the system fork, that global became `game.system.api.elysium.engagement`. Somewhere along the way the `const engagement = ...` line was deleted, leaving the `if (!engagement) return` guard and downstream `engagement.getActorEngagements(actor)` calls referencing an undefined identifier. Restored as `const engagement = game.system.api?.elysium?.engagement`.

**Bug 2: ALL `game.elysium.X` reads were broken.** Same root cause, wider scope. The post-merge API lives at `game.system.api.elysium`, not `game.elysium`. 13 stale `game.elysium.X` references (across `combat-extension.mjs`, `magic.mjs`, `engagement-ui.mjs`, `sheet-extension.mjs`) all updated. Two doc-comment references in `engagement.mjs` and `sheet-extension.mjs` also updated for accuracy. Without this, the fatigue, active-effects, charge, and engagement subsystems were all silently broken in their respective consumers — sheet rest button, magic overcast fatigue, combat-end bleed advance, and engagement badges all hit `undefined` properties.

**Bug 3: `weapon.system['elysium'].reach` should be `weapon.system.elysium.reach`.** 10 sites in `sheet-extension.mjs` (engagement badges + warning cards + item-sheet engagement info) were reading weapon data from `weapon.system['elysium'].*`. The canonical schema location is `weapon.system.elysium.{reach, weaponSize, force, ...}` per `template.json`. The `'elysium'` flag-namespace rename only applies to `actor.flags['elysium']`, not to `system` paths — a prior bulk substitution touched these by mistake. Without fix, every read returned `undefined`, so reach defaulted to `'M'` and engagement state was always computed against the same medium reach regardless of the weapon's actual reach. Fixed.

**Systematic re-scan.** After fix, I ran a tree-wide diff comparing every function body in `module/elysium/` and `module/` against the pre-cleanup rules-module and system-fork originals. The diff looked for: (a) empty bodies that originally had code, (b) `if (!X) return` first-line guards where `X` is not bound in the function. Both scans returned zero results. The same scan ran across all BRP-base files (excluding the elysium subtree). Also zero results.

**The deeper lesson.** The settings-cleanup sweep that removed `masterEnable` guards was a regex-on-source operation that didn't understand JavaScript scope. Several handlers had local `const` declarations that depended on the guard *not* firing — when the guard was deleted, the bodies became reachable for the first time, exposing pre-existing bugs that had been masked by the guard. The hotfix waves caught five of these (renderCombatTracker, _onCombatEnd, _onRenderActorSheet, _onRenderItemSheet, _onPreUpdateItem) in the prior turn; this one caught three more (the engagement namespace + weapon system-path + game.elysium namespace bugs). A handler-body diff against pre-cleanup sources should have been part of the cleanup wave itself, not an after-the-fact bugfix.

This is a no-version-bump hotfix on top of the v0.20.0 release; world data unaffected.

### Hotfix — four broken-state regressions from the settings cleanup

User reported a `ReferenceError: root is not defined` thrown from `renderCombatTracker` on world load. Investigation found that the bulk Python sweep that removed `if (!getSetting('masterEnable', true)) return` guards from `register-hooks.mjs` had unmasked or introduced four broken-state regressions:

**1. `renderCombatTracker` inline handler.** Referenced an undefined `root` variable in the body. The `masterEnable` guard above it had been the only thing preventing the function from ever reaching the broken reference. Fixed by defining `root` from the `html` argument the same way the `renderChatMessageHTML` handler does (V14 passes HTMLElement directly; V13 wrapped in jQuery). This was the reported crash.

**2. `_onCombatEnd` handler body was empty.** The sweep had deleted the body's only meaningful call (`ElysiumCombatExtension.onCombatEnd(combat, options, userId)`) along with the guard. Effect: combat-end cleanup never fired — the four-pool AP reset (added in this release), active-cast cleanup, and proactive-AP-gate clearing all silently skipped. Restored the call.

**3. `_onRenderActorSheet` handler body was empty.** The body was supposed to call `ElysiumSheetExtension.extendActorSheet(app, html, data)`. Effect: **the entire Elysium UI extension never rendered.** Every Elysium-specific UI element on the character sheet — the four-pool AP display, the Mythras stat panels on the CHAR tab, the fatigue meter, the Luck Points display, the per-location condition icons, the wound-tier annotations, the custom-spell builder, the ability add-on tree, the stat-improve buttons — silently never appeared. The character sheet would have rendered as plain BRP with none of the Mythras-flavored content visible.

**4. `_onRenderItemSheet` handler body was empty.** Same pattern — should call `ElysiumSheetExtension.extendItemSheet(app, html, data)`. Effect: item sheets missed their Elysium UI extensions.

**5. `_onPreUpdateItem` missing parent guard.** The `if (!item.parent) return` line was deleted alongside the `masterEnable` guard. Without it, world-level items (compendium items being edited, etc.) would hit branches that assume `item.parent` exists. Restored.

Root cause: the regex `^\s*if\s*\(\s*!getSetting\(\s*'masterEnable'\s*,\s*[^)]+\)\s*\)\s*return(?:\s+[^
]*)?
` was supposed to match a single line, but the trailing `
` plus a too-aggressive interaction with the migration-removal wave's pre-stubbed handler bodies left several function bodies in unintended states. The sweep should have been followed by a handler-body diff against the pre-cleanup source — which is what found and fixed all five today.

After fix:
- All 156 `.mjs` files pass `node --check`
- All handler bodies verified against the pre-cleanup source — no further empty-or-unbound regressions
- Systematic re-scan for the same class of bug (unbound identifier in early-return guard) across every `.mjs` in `module/` returned zero results

This is a no-version-bump hotfix on top of the v0.20.0 release; world data is not affected since these were pure code regressions.

### Known deprecation — template.json (V16 migration planned)

Foundry V14 emits a deprecation warning on world load:

> `[elysium] System template.json is deprecated. System-provided Document types should be defined in system.json, and optionally be associated with a system data model. Support for template.json will be removed in V16.`

This is informational under V14; worlds work normally. The migration to V14+ DataModels is deferred to a future release for these reasons:

- The migration is a substantial architectural change. Every actor type (`character`, `npc`) and every item type (`weapon`, `armor`, `skill`, `culture`, `profession`, `passion`, `hit-location`, `arcane`, `divine`, `mysticism`, `wound`, `gear`, `mutation`, `super`, `tome`, etc.) needs a `foundry.data.fields`-based schema definition with proper field types, defaults, and where useful, validate callbacks. Estimated scope is on the order of 1,200–1,500 lines of new schema code across ~18 new files.
- V16 is at least one major Foundry version away. The deprecation is not breaking under V14.
- v0.20.0 is already a large release that has had three rounds of regression hotfixes. Stacking an architectural rewrite on top would mix concerns and make any DataModel-related bug indistinguishable from a v0.20.0 cleanup regression.

**Planned for v0.21.0 (or v1.0.0):** full DataModel migration. The plan:
1. Audit every field in `template.json` against current read/write callsites
2. Define `BaseActorDataModel`, `CharacterDataModel`, `NPCDataModel` and their item-side equivalents under `module/data/`
3. Move `system.elysium.*` fields into properly-typed schemas
4. Register data models via `documentTypes` in `system.json`
5. Delete `template.json`
6. Test every actor/item read path against the new schemas

V14 supports both `template.json` and DataModels simultaneously during the transition, so existing worlds will keep working through the migration.

**Breaking release.** A new world is required — migration code is gone, schema fields moved, settings removed. There is no upgrade path from earlier worlds.

### Architecture: rules module merged into system

The previously separate `elysium` rules module has been folded into the `elysium` system entirely. There is no longer a separate rules module to install. All of the rules-module code now lives under `module/elysium/`:

- `module/elysium/elysium.mjs` — subsystem entry, registers hooks/settings/i18n/Handlebars helpers and exposes the API via `game.system.api.elysium`
- `module/elysium/{config,active-effects,actor,combat,creation,critical,fatigue,helpers,hooks,magic,mechanics,settings,sheets}/` — subsystem source
- `styles/elysium.css` — rules-module styles merged into the system's stylesheet list
- `lang/en.json` — rules-module translation keys deep-merged into the system's lang file

The runtime `BRPActor.prototype.prepareDerivedData` patch (Mythras HP override) now lives inside the same package as `BRPActor` itself, simplifying load ordering. The `game.modules.get('elysium')?.api` indirection in `base-actor-sheet.mjs` has been replaced with direct `game.system.api.elysium` reads. The standalone `Elysium_Rules-v0.X.zip` deliverable is gone.

### Migration code removed

All 8 migration modules deleted (1306 lines): `migrate-0_5_0`, `migrate-0_5_12`, `migrate-0_6_0`, `migrate-0_12_0`, `migrate-0_15_0`, `migrate-0_16_0`, `migrate-0_17_0`, `migrate-0_18_0`. The v0.7.5 one-shot setting-flipper, the `_backfillBRPidFlags` recovery path, the `flags.elysium.migratedTo` markers, and the `migrateArmorItem` / `migrateAllArmor` armor-AE-bootstrap functions are all gone. Worlds must be created fresh.

### Schema canonicalization: `flags.elysium.*` → `system.elysium.*`

Data fields the BRP template already provides under `system.elysium.*` are now read from there everywhere, with no `flags.elysium.*` fallback chain. Affected fields: `ancestryId`, `patron`, `essences`, `schoolMastery`, `buildPoints`, `skillPoints`, `expDice`, `expDiceOverride`, `languages`, `statNaturalMax`, `ancestryMod`, `ancestryMove`, `companion`, `creatureType`, `creatureSubtype`, `creatureTags` on actors; `flexibility`, `material`, `layerOrder`, `armorHP`, `castingLocation`, `ancestry`, `layer`, `wornStratum` on items. The `ElysiumData` path-helper class and its file (`module/elysium/helpers/data.mjs`) are deleted; the 29 `ElysiumData.path(...)` callsites are direct property reads now. Form-name strings in `_injectArmorFields` and `_injectAncestryFields` flipped from `flags.elysium.*` to `system.elysium.*` so the sheet saves to the correct path.

`flags.elysium.*` paths remain in use only for runtime state that doesn't belong in the data model: `modifiers` (Active Effect aggregation targets), `derived` (cached derived-stats blob), `activeCast`, `activeSustains`, `proactiveAPSpentThisTurn`, `braced`, `engagements`, `activeAbilities`, `purchasedAddOns`, `criticalEntry`, `criticalRolls`, `condition`, `bleedRate`, `ongoingDamage`, `castCard`, `apModifier`, `fatigueLevel`, `tempPowSacrificed`, `intPool`.

### Four-pool Action Points (fully wired)

The `actionPoints` schema's four pools — `value/max`, `attackValue/attackMax` (proactive restricted, your turn, attacks only), `reactValue/reactMax` (reactive general), and `defenseValue/defenseMax` (reactive restricted, others' turns, parry/evade only) — are now wired end to end:

- `actor-extension.mjs::_gatherAPModifiers` handles the `'defense'` AE group
- `calculateActionPoints` returns `defenseMax` / `defenseValue` and the writeback in `calculateDerivedStats` includes them
- `combat-extension.mjs::onCombatEnd` resets `defenseValue` to 0 alongside the other pools
- `_refreshActionPoints` and the refresh-AP button restore `defenseValue` to `defenseMax`
- Sheet header shows the format `8/8 · A 1 · R 2 · D 1`, with any pool at zero max omitted
- Tooltip explains each pool's restriction

`restricted-ap.mjs::spendActionPoint` had defense handling correct before this release; the change brings the rest of the codebase up to its baseline.

### Damage modifier canonicalization

Deleted the BRP `_damageBonus` curve in `actor.mjs` (half/full/dbl outputs based on STR+SIZ) and the parallel `dmgBonus.half/full/dbl/str` reads in `combat-roll.mjs::getDamageBonus`. Damage rolls now use the canonical Mythras formula: `weapon.dmg1 + (actor.system.dmgmodTier × weapon.system.elysium.damageBonusMultiplier)`.

- New field: `weapon.system.elysium.damageBonusMultiplier` (Number, default 1.0). Editable on the weapon sheet next to the Melee toggle.
- 1.0 = full damage bonus; 0 = no bonus; 0.5 = half (e.g. small/light weapons); 2.0 = double (e.g. STR-leverage two-handers).
- The multiplier walks `ELYSIUM.DAMAGE_MOD_TABLE` by table index (not linearly through the dice formula) via `ElysiumActorExtension.scaleDamageModByMultiplier`. The table's progression is non-uniform: `-1d6 → -1d4 → -1d2 → +0 → +1d2 → +1d4 → +1d6 → +1d8 → +1d10 → +1d12 → +2d6 → +2d8 → +2d10 → +2d12 → ...`, so multiplying by table index preserves the canonical step relationships.

The `DMG_MOD_TIERS` private array in `charge.mjs` is deleted; `stepDamageMod` now walks `ELYSIUM.DAMAGE_MOD_TABLE` directly.

### Knockback in feet

`computeKnockback` returns `{ feet, squares, mustRoll, prone, excess }`. The math is unchanged: each 5 points of excess damage over SIZ = 1 square. Display now reads `Knocked back 10ft (2 squares)` instead of the prior `Knocked back 2m`. The system's grid units are feet, so this aligns the math, the data model, and the chat-card text.

### Body-part schema (hit locations)

`hit-location.system.elysium` gains:
- `bodyPart` — `'head' | 'chest' | 'abdomen' | 'arm' | 'leg' | 'wing' | 'tail' | ''`
- `side` — `'left' | 'right' | ''`
- `index` — Number ≥ 0, for creatures with multiple identical limbs (e.g. a spider's eight legs as index 0–3 on each side)

`bodyPart` is now canonical for arm-vs-leg distinction in the Mythras HP table (`arm = max(1, base - 1)`, `leg = base`, etc.) and for critical-table routing. The legacy name-regex inference fallback in `mythras-hp.mjs::_inferBodyPart` has been removed; it now falls back to `locType` only when `bodyPart` is missing. `calculateMove` detects legs by `bodyPart === 'leg'` (was a buggy `locType !== 'limb'` early-return with name regex). Hit-location item sheet gets editable dropdowns for `bodyPart` and `side`, plus a numeric input for `index`.

### `_powBonus` removed

The local `_powBonus` POW-bonus tables in `combat-extension.mjs` (unreferenced) and `magic.mjs::meditate` (used for meditation PP recovery) are deleted. Meditation now recovers 1 PP per hour, per Mythras canon — POW gates the pool max but doesn't scale the recovery rate.

### System settings cleanup

Deleted as toggleable settings (now hardcoded on, internally assumed `true`):
- `useHPL` — per-location HP is core to Mythras combat
- `usePassion` — passions support Faith / cultural identity
- `usePersTrait` — personality traits are core character data
- `useAlleg` — allegiance is how Faith is modelled

Deleted entirely (no longer relevant to Elysium):
- `useEDU` — Elysium uses 7 stats, EDU is not one
- `starterSkills` / `starterTraits` — BRP onboarding helpers don't fit Elysium's ancestry/profession-driven creation flow
- `beastiary` — alternate HP code path subsumed by hardcoded per-location HP
- `actorBRPID` — BRPID can be set manually via the sheet header editor
- `hpMod` — superseded by `hpMultiplier` (registered by the elysium subsystem, with per-location application)
- `ppLabelLong` / `ppLabelShort` / `hpLabelLong` / `hpLabelShort` / `fpLabelLong` / `fpLabelShort` / `sanLabelLong` / `sanLabelShort` / `sanLabelLoss` / `res5LabelLong` / `res5LabelShort` — fixed Elysium terminology, no per-resource label overrides needed (the Ancestry relabel module handles the Culture/Ancestry/Race/Species toggle)

The `gameMods` settings menu is gone. The GM scene-controls beastiary toggle is gone. The `BRPUtilities.beastiaryMode` helper is gone.

Kept settings: `useSAN`, `useFP`, `useRes5`, `skillBonus`, `useAVRand`, `useReputation`, `diffValue`, `initStat`, `initMod`, `switchShift`, `defaultTab`, `development`, `gameVersion`, `itemBRPID`, `firstAidBRPID`, plus the Elysium subsystem's own settings (`masterEnable`, `enableTempHP`, `enableActionPoints`, `enableArcane`, `enableMysticism`, `enableAncestrySystem`, `enableCriticalTables`, `hpMultiplier`, `statRollMethod`, `ancestryTerm`, etc.).

### Item type cleanup

`template.json` legacy sorcery fields removed: `tierIndex`, `thresholds`, `isConfluence`, `essenceRarity`, `unlockExpCost`, `isFreeAbility`, `currentSkillPct`, `baseStatA`, `baseStatB` — replaced by the v0.19.0 tier-based fields (`baseTier`, `maxTier`, `apCostByTier`, `effectByTier`, `damageType`, `isSustained`, `maintainPPPerRound`, `forbidden`, etc.). Legacy `_comment_*` inline-comment keys stripped from `template.json` and `lang/en.json`.

The manifest's `documentTypes` listed three retired types (`power`, `magic`, `psychic`) that haven't been part of the schema since v0.8.0. They're removed; `arcane`, `divine`, `mysticism` are listed (matching the actual template).

### Cross-package API consolidation

`game.modules.get('elysium')?.api` (the rules module's API surface) is gone — everything moved to `game.system.api.elysium.{config, activeEffects, criticalRoller, fatigue, ancestryDrop, magic, combat, creation, actor, relabel, engagement, engagementUI, charge, effectGrades, restrictedAP, statImprovement}`. Two call sites in `base-actor-sheet.mjs` (stat-improve toggle and roll-all) updated.

`game.system.api.casting` and `game.system.api.combat` are unchanged.

---

### Settings cleanup wave 2

A deep audit of the settings system found that many "feature toggle" settings were either structurally lying (the off-state was never implemented; disabling them produced broken half-states), zero-read (registered but never consulted by any code path), or duplicate (BRP-base toggles shadowed by Elysium toggles doing the same job).

**27 settings deleted in this wave:**

*Structural pretenders (8):* `masterEnable`, `enableActionPoints`, `enableWoundThresholds`, `enableCriticalTables`, `enableMythrasFatigue`, `enableArmorLayering`, `enableTempHP`, `enableArmorCastingPenalty`. Each gated a code path whose off-state was missing or broken — disabling them produced silent broken state (e.g. AP draining without refresh, locations stuck at 0 HP with no critical fire, casting penalties accumulating on actors but not applied to rolls). Now hardcoded on; the guards have been unwrapped throughout the codebase (38 setting reads + 5 positive-condition wraps removed).

*Zero-read dead settings (7):* `enableDivine`, `enableSorcery`, `enableSuperpowers`, `enableSpecialEffects`, `enableShieldPassiveBlocking`, `enableCharacterCreation`, `showDifficultyGradeNames`. Registered as world settings, never consulted by any code path. The "magic source toggles" (enableArcane, enableMysticism, enableDivine, enableSorcery, enableSuperpowers) were partly wired (Arcane had 2 reads with broken null-return paths; Mysticism had 1) — rather than wire them symmetrically, all five were deleted. Campaigns now gate magic access by what spells exist in the compendium, not via a global flag.

*EXP-dice false toggles (4):* `enableExpDiceSystem`, `sessionExpDicePool`, `expFumbleImmediateAdvance`, `expAdvancementTiming`. The enable-toggle was a UI relabel masquerading as a feature flag (off = "XP" label, but every cost/award/spend path runs anyway). The other three had zero reads.

*BRP-base power-source duplicates (3 + 3 labels):* `mutation`, `sorcery`, `super`, `mutationLabel`, `sorceryLabel`, `superLabel`. These predate Elysium's per-tradition toggles and gated the BRP power-source dropdowns. With the Elysium magic toggles also deleted, the power-source dropdowns always show all options. The Power Rules settings menu and its template are removed.

**Result:** ~73 settings before → 46 after. Every remaining setting either properly gates its feature, is a campaign tuning knob, or is pure cosmetic UI config.

*Settings retained as legitimate alternate rules:* `enableMythrasHealingRate`, `enableLuckPoints`, `enableOvercasting`, `requireSpellLearningRoll`, `autoApplyConditions`, `enableAncestrySystem`. Each properly gates its feature with no half-wired paths.

*Settings retained as campaign tuning:* `hpMultiplier`, `ancestryLabel`, `statRollMethod`, `statNaturalMaxBase`, `startingSkillCap`.

*Settings retained as cosmetic:* `showFatigueOnSheet`.

### Pre-existing bug fixed

`ElysiumActorExtension.calculateDerivedStats` was missing a `const derived = {}` declaration — a previous wave deleted it alongside the `masterEnable` early-return without restoring it. The function would have thrown on first invocation. Restored.

### Cross-namespace setting-read bug fixed

`character.mjs::ancestryColumnLabel` was reading `game.settings.get('elysium', 'ancestryLabel')` — using the pre-merge rules-module namespace. Foundry V14 throws on unknown setting scope, so this would have thrown on every character sheet render. Fixed to `'elysium'`.

### Lang cleanup

100 dead `Elysium.Settings.*` and `BRP.Settings.*` keys removed from `lang/en.json`. Spanish and French translations were unchanged (they didn't contain the dead keys).


### Settings cleanup wave 3 — consistency pass

**Luck Points consistency.** Two unguarded code paths that wrote to `system.luckPoints.value` would have run regardless of `enableLuckPoints`: the `[data-elysium-action="spendLuck"]` click handler in `sheet-extension.mjs` and the spend at `critical-roller.mjs:263`. Both now check the setting. The critical-roller fix is defense-in-depth (callers already guard); the sheet-button fix closes a real gap.

**`useFP` deleted.** The BRP-classic flat fatigue points system (`system.fatigue.value`/`max`, with the value/max panel on the character header) was a parallel system to Mythras fatigue. Bleeding writes to the Mythras fatigue ladder; combat actions assumed it; the BRP panel was double-bookkeeping. Setting registration removed from `settings-optional-rules.mjs`. Three context-setting sites hardcoded to `false` (so the `{{#if useFP}}` template branches never render). The `{{#if useFP}}` blocks themselves stripped from `character.header.hbs`, `character.statistics.hbs`, and `npcV2.main.hbs` (where it would have rendered for NPCs via `useBeastiary=true`). Settings UI checkbox removed from `optional-settings.hbs`. Lang strings removed from en/es/fr.

The dead writes to `system.fatigue.max` and the dead `restoreFatigue` action in `actor.mjs` were left in place — harmless write-only-no-readers code that doesn't affect Mythras fatigue.

**Pre-existing bug fixed: EXP dice read path mismatch.** Four sites in the codebase read `actor.flags['elysium'].expDice` but every write went to `system.elysium.expDice` (the canonical template schema field). The bug would have surfaced as "EXP dice never appear available" in every consumer: `creation.mjs::startStatRoll`, `creation.mjs::spendStatExpDice`, `creation.mjs::awardExpDice`, the add-on tree in `sheet-extension.mjs`, the stat-improvement subsystem, and the BRP character sheet's EXP Dice display. Reads updated to `actor.system?.elysium?.expDice`.

**Award EXP Dice macro added.** New entry in `compendium/packs/macros.db` (brpid `m.script.award-exp-dice`). GM-only, prompts for count, awards to all selected tokens (or the user's character if none selected), posts a chat-card summary listing each actor's before/after. Replaces the deleted `expFumbleImmediateAdvance` and `expAdvancementTiming` settings — advancement is now explicitly GM-driven via this macro.

**`useWealth` and `wealthLabel` deleted.** Wealth is always shown; the label is fixed as "Gold". Three context-setting sites hardcoded. The `char-settings.hbs` template was rewritten — it still had `starterSkills` and `starterTraits` UI from before this release's settings cleanup (those settings were deleted in the original v0.20.0 wave but the template wasn't pruned). The new template shows only the three `background1/2/3` text fields that actually still exist as settings. Lang strings removed.

**Display Options audit.** All 15 display settings (`actorFontColour`, `actorTitleColour`, `actorTertiaryColour`, `actorBackColour`, `secBackColour`, `actorTabNameColour`, `actorRollableColour`, `actorRollableShadowColour`, `actorSheetBackground`, `charSheetLogo`, `charSheetMainFont`, `charSheetTitleFont`, `charSheetMainFontSize`, `charSheetTitleFontSize`, `brpIconPrimary`) audited individually. Each has exactly 2 reads (truthy-check + apply-to-CSS-variable on `.brp.actor` elements). None are dead, none are half-wired. All retained as legitimate per-campaign theming hooks.

**Settings file rename for consistency.** Eight settings files renamed from camelCase to kebab-case to match the rest of the codebase:

- `settings-NPCOptions.mjs` → `settings-npc.mjs`
- `settings-brpidOptions.mjs` → `settings-brpid.mjs`
- `settings-charOptions.mjs` → `settings-character.mjs`
- `settings-combatOptions.mjs` → `settings-combat.mjs`
- `settings-diceOptions.mjs` → `settings-dice.mjs`
- `settings-displayOptions.mjs` → `settings-display.mjs`
- `settings-optionalRules.mjs` → `settings-optional-rules.mjs`
- `settings-xpOptions.mjs` → `settings-xp.mjs`

Import paths in `register-settings.mjs` updated.


---

## Elysium 14.2.1-elysium-0.19.5 — v0.19.5 hotfix pairing (paired with rules 0.19.5 and compendium 0.13.5)

## Elysium 14.2.1-elysium-0.19.5 — v0.19.5 hotfix pairing (paired with rules 0.19.5 and compendium 0.13.5)

No BRP-system changes. Version bumped to maintain pairing with the rules module's Items-tab container-nesting feature. See `elysium-rules/CHANGELOG.md` for detail.

## Elysium 14.2.1-elysium-0.19.4 — v0.19.4 hotfix pairing (paired with rules 0.19.4 and compendium 0.13.4)

**Template schema addition** to support the new Withered (max-HP reduction) condition.

`template.json`:
- Added `system.elysium.maxHPModifier` field (signed integer, default 0) to every hit-location item. Negative values represent reductions to the location's max HP (Withered condition's per-round tick writes to this); positive values can buffer max HP for future buff effects.
- The rules-module's `ElysiumMythrasHP.applyToActor` now reads this modifier and applies it on top of the Mythras-computed baseline, so the reduction survives `prepareDerivedData` recomputation cycles.

No other system-level changes. See `elysium-rules/CHANGELOG.md` for the condition system expansion (15 new conditions, Withered's new mechanic) and `elysium-compendium/CHANGELOG.md` for spell prose updates following the new `<Condition> X for Y rounds` convention.

## Elysium 14.2.1-elysium-0.19.3 — v0.19.3 hotfix: Skill Group dropdown (top-level skillCategory)

Third hotfix on the v0.19.0 line. Surfaces the previously-hidden top-level `system.elysium.skillCategory` field on the skill item sheet. This drives the four major sections on the character sheet's Skills tab: Standard, Professional, Combat, Magic.

### What was hidden

The Elysium fork has been carrying **three** distinct categorisation fields on every skill, each serving a different purpose:

| Field | Values | Purpose |
|---|---|---|
| `system.category` | `mentmod`, `cmbtmod`, `comnmod`, `knowmod`, `mnplmod`, `physmod`, `zcmbtmod` | BRP-base modifier label (cosmetic, also drives weapon-subtype dropdown) |
| `system.elysium.skillCategory` | `standard`, `professional`, `combat`, `magic` | **Top-level Skills-tab section** |
| `system.elysium.skillSubgroup` | `''`, `arcane`, `sorcery`, `divine`, `mysticism` | Magic-tradition sub-bucket (within `skillCategory: 'magic'`) |

v0.19.1 fixed the visible-but-broken Category dropdown. v0.19.2 added the missing Subgroup dropdown. v0.19.3 adds the missing **Skill Group** dropdown for the top-level category.

This is the field that drives Skills-tab grouping in `_buildCategorisedSkills`:
- `standard` (21 skills) → Standard Skills section
- `professional` (44 skills) → Professional Skills section
- `combat` (19 skills) → Combat Skills section (Axes, Bludgeon, Long Blades, Short Blades, Polearms, Manual Ranged, Mechanical Ranged, Shield, Brawn, Unarmed, Martial Arts, Heavy/Medium/Light Armor, plus combat abilities like Assassin's Strike, Combat Stance, Vanguard)
- `magic` (23 skills) → Magic Skills section (further split by `skillSubgroup` into Arcane/Sorcery/Divine/Mysticism sub-buckets)

Knowledge-flavored skills (Lore, Language, etc.) are tagged at the BRP modifier level as `category: 'knowmod'` but rolled up at the Elysium level into `skillCategory: 'professional'` — they're Profession-locked Knowledge skills, not a separate top-level group.

### Fix — Skill Group dropdown added to skill item sheet

New row in `templates/item/skill.detail.hbs`, positioned at the top of the details tab (before Category). Options: Standard / Professional / Combat / Magic. `skillGroupOptions` is built in `module/item/sheets/skill.mjs::_preparePartContext`.

The handler's generic `this.document.update(formData.object)` writes the new `system.elysium.skillCategory` value without further changes.

The row is conditionally hidden when `item.system.group` is true (skill groups don't carry a top-level group classification — same pattern as the Category and Subgroup rows added in v0.19.1 and v0.19.2).

### What's NOT changed

- No skill data migration. All 107 skills already have the correct `system.elysium.skillCategory` value in shipped data; the field was just not visible in the UI.
- No character-sheet changes — the grouping logic in `_buildCategorisedSkills` was correct all along (it has been since v0.15.0).
- No casting changes. The cast pipelines find skills by `subgroup` (the magic-tradition field, not the top-level category), and that lookup has been working throughout.

### Three-field summary for v0.19.3

Opening a skill item sheet now exposes all three fields. For example, **Long Blades** displays:
- **Skill Group:** Combat
- **Category:** Combat (with the weapon-subtype dropdown also showing)
- **Subgroup:** — (no subgroup)

For **Blight**:
- **Skill Group:** Magic
- **Category:** Mental
- **Subgroup:** Sorcery Essence

For **Athletics**:
- **Skill Group:** Standard
- **Category:** Physical
- **Subgroup:** — (no subgroup)

## Elysium 14.2.1-elysium-0.19.2 — v0.19.2 hotfix: Skill Subgroup dropdown + catName fix

Second hotfix on the v0.19.0 line. Surfaces the previously-hidden skill subgroup field on the skill item sheet, so GMs can view and edit how a skill clusters on the character sheet's Skills tab (Arcane Schools, Sorcery Essences, Divine, Mysticism). Also fixes a related display bug.

### What was hidden

The `system.elysium.skillSubgroup` field has existed since v0.15.0 and drives the skill-grouping on the character sheet (`_buildCategorisedSkills` routes magic skills into per-subgroup buckets based on it). The shipped data uses four values: `arcane`, `sorcery`, `divine`, `mysticism`. The character sheet rendered these groups correctly, but **the skill item sheet had no UI for the field** — a GM opening Blight saw no indication that it was tagged as a sorcery essence skill, and couldn't change the tag through the sheet.

### Fix — Subgroup dropdown added to skill item sheet

New row in `templates/item/skill.detail.hbs`, positioned right after Category. Options:

| Value | Display label |
|---|---|
| `""` | — (no subgroup) |
| `arcane` | Arcane School |
| `sorcery` | Sorcery Essence |
| `divine` | Divine |
| `mysticism` | Mysticism |

`subgroupOptions` is built in `module/item/sheets/skill.mjs::_preparePartContext` (alongside `catOptions`). The handler at the bottom of the same file already does a generic `this.document.update(formData.object)`, which writes the new `system.elysium.skillSubgroup` value without further changes.

The row is conditionally hidden when `item.system.group` is true (skill groups don't carry subgroups — same pattern as the existing Category row).

### Fix — `catName` derivation for read-only display path

In `skill.mjs`, the read-only `catName` value (shown to non-GM players) was computed as `game.i18n.localize("BRP." + this.item.system.category.split('.')[2])`. This expected the category to be a brpid like `i.skillcat.mental`, where `split('.')[2]` extracts `mental`. The shipped data uses short codes (`mentmod`, `cmbtmod`) with no dots, so `split('.')[2]` returned `undefined` and the read-only display showed literal "BRP.undefined" text.

Fixed to use the raw category as the localize key: `game.i18n.localize("BRP." + this.item.system.category)`. Combined with the new lang entries added in v0.19.1 (mentmod, knowmod, cmbtmod, comnmod), this now displays the correct label.

### What's NOT changed

- No skill data migration. Every skill already has the correct subgroup value; the field was just not visible in the UI.
- No character-sheet changes — the grouping logic in `_buildCategorisedSkills` was correct all along.
- No casting-pipeline changes. The arcane/sorcery cast helpers' `findSkill(actor, { subgroup: '...' })` lookups continued to work throughout.

## Elysium 14.2.1-elysium-0.19.1 — v0.19.1 hotfix: Skill category dropdown population

Single fix on top of v0.19.0. Bug surfaced during smoke testing: opening any skill item showed an **empty Category dropdown** in the Details tab, even though the underlying data had the category populated correctly (e.g., Blight had `system.category: 'mentmod'`).

### Root cause

`BRPSelectLists.getCategoryOptions()` in `module/apps/select-lists.mjs` populated the dropdown from items with brpids matching `^i.skillcat` in the compendium. The shipped compendium does not include any `skillcat` items — they were assumed to be created per-world. The shipped skill data uses short codes (`mentmod`, `knowmod`, `cmbtmod`, `comnmod`, `mnplmod`, `physmod`) for `system.category`, which never match the brpid-keyed option list, so the dropdown rendered empty for every skill.

This is a pre-existing v0.18.x bug that v0.19.0 inherited. The actor sheet's `_checkSkillCat` function already handles the legacy short codes explicitly (see comment at `actor-itemDrop.mjs:634-647`), so this fix aligns the item sheet dropdown with the same convention.

### Fix

`getCategoryOptions()` now returns a hardcoded option list using the six short codes actually present in shipped skill data, with display labels matching BRP convention:

| Short code | Display label |
|---|---|
| `cmbtmod`  | Combat |
| `comnmod`  | Communication |
| `knowmod`  | Knowledge |
| `mentmod`  | Mental |
| `mnplmod`  | Manipulation |
| `physmod`  | Physical |
| `zcmbtmod` | Combat (Weapon) |

No skill data migration is needed — every shipped skill's existing `system.category` value already matches one of these keys.

### Lang file additions

Added `mentmod`, `knowmod`, `cmbtmod`, `comnmod` keys to `lang/en.json` (the shipped lang had only `mnplmod`, `mntlmod` (note typo: mental was `mntlmod` in lang but `mentmod` in data), `physmod`, `zcmbtmod`). The option-list function has fallback English labels in code for safety; the lang additions are the proper long-term resolution.

### What's NOT changed

- No skill data migration. Every skill in `skills.db` already has the correct category value; they were just not rendering in the UI.
- No skillcat compendium pack added. The fix avoids that scope entirely.
- No actor-sheet changes — `_checkSkillCat` already handled the legacy values correctly.

## Elysium 14.2.1-elysium-0.19.0 — v0.19.0 release: Sorcery, divine rebalance, cross-tradition damage framework (paired with rules 0.19.0 and compendium 0.13.0)

The full v0.19.0 release. This entry summarises everything from the phased development sequence (A → O); see the per-phase entries below for change-by-change detail.

### Phase D-2 — Hit-location targeting and armor integration

The sorcery cast pipeline now resolves damage automatically when the caster has targeted tokens. The new `_resolveSorceryDamage` function (in `module/casting/sorcery-cast.mjs`):

- Reads `damageByTier[chosenTier-1]` for the dice expression (e.g. `"1d6"`, `"2d8"`)
- Reads `locationsByTier[chosenTier-1]` for how many random hit locations to hit per target (most: 1; high-tier AoE: 2-3)
- For each targeted token, rolls N random hit locations using the new `rollMultipleHitLocations(actor, count)` helper
- For each location, rolls fresh damage dice (per locked design: multi-location AoE rolls dice per location, not once shared)
- Applies the cross-tradition `applyArmorToDamage` to compute final damage per location
- Posts a per-target chat message with the full breakdown (location, raw damage, armor effects, final damage)

If no tokens are targeted at cast time, a chat notice prompts the GM to apply damage manually. Same for spells without a `damageByTier` expression (e.g. Mantle of Element which is a self-buff).

The `casterChoosesLocation` flag (added to the sorcery schema) is honored: for self-heals and defensive self-buffs, the spell affects the first N hit locations on the target rather than rolling random. A full location-picker dialog is deferred to a future polish phase.

**New file:** none — extensions to existing `armor-vs-damage.mjs` for the hit-location rollers, integration in `sorcery-cast.mjs`.

**Schema additions** in `template.json` `Item.sorcery.elysium`:
- `damageByTier: ["", "", "", "", ""]` — 5 dice expression strings
- `locationsByTier: [1, 1, 1, 1, 1]` — 5 hit-location counts
- `casterChoosesLocation: false` — flag for self-targeted abilities

**System API additions** (`game.system.api.combat`):
- `rollRandomHitLocation(actor)` — rolls a d20 against hit-location ranges
- `rollMultipleHitLocations(actor, count)` — rolls N distinct random locations

### Phase E/F — Sorcery sheet template polish (skill categories already shipped)

The shipped skills compendium already has all 12 essence skills with appropriate categories and subgroups (verified during phase). No code or content changes were needed for E/F beyond the D-1 sheet rewrite.

The sorcery sheet template gained the damageByTier/locationsByTier inputs per tier, and the casterChoosesLocation flag in the flags section.

### Phase G — New signature conditions (16 added)

Added 16 new conditions to `packs/conditions.db` per the locked v0.19.0 design:
- **Elemental:** Chilled, Shocked, Staggered
- **Vitality:** Stabilized, Bolstered, Energized, Purged, Disrupted
- **Death:** Withered, Anti-Healed, Doomed, Marked for Death
- **Ward:** Warded, Resistant, Contained, Reflected

Already-shipped conditions are reused where applicable: Burning (elemental), Prone, Bleeding, Dying.

Patch applied via `elysium-compendium/dev/patch-conditions-v0.19.0.py` (re-runnable, idempotent). Pre-patch backup at `packs/conditions.db.pre-v0.19.0.bak`.

### Phase H — Essence keystone descriptions

The four essence skills (Elemental, Vitality, Death, Ward) now have full descriptions including their keystone passive text:

- **Elemental Attunement** — choose Fire/Frost/Storm/Stone/Water/Wind/Corrosion at first awakening; -1 PP discount for situationally-aligned casts
- **Vital Sense** — auto-detect wounded/dying/bleeding within 30 ft; -1 PP discount when targeting them
- **Death Sense** — auto-detect corpses/dying/mortality within 30 ft; -1 PP execution-target discount on Bleeding/Dying/Wounded/Withered/Marked targets
- **Ward Sight** — auto-detect magical effects/hostile intent/concealed weapons within 30 ft; -1 PP discount on defensive reactions and dispel-magic targeting

The cast pipeline does NOT yet auto-compute the -1 PP keystone discount; the discount is documented but applied manually by GM judgment. A future phase may automate the trigger detection.

### Phase J — 88 sorcery abilities populated

`packs/abilities-sorcery.db` populated with all 88 authored abilities (4 essences × 22 abilities each):
- 22 Elemental abilities (Flame Bolt, Frost Bolt, Lightning Bolt, ..., Cataclysm iconic)
- 22 Vitality abilities (Mend Wound, Healing Touch, Bolster, ..., Resurrection of the Worthy iconic)
- 22 Death abilities (Withering Bolt, Grave Touch, Reaper's Strike, ..., Reaper's Call iconic) — all `forbidden: true`
- 22 Ward abilities (Shield of Force, Barrier Wall, Sanctum Dome, ..., Aegis of Worlds iconic)

Each ability has full `effectByTier` text (5 tier descriptions per ability), `apCostByTier`, `damageByTier`, `locationsByTier`, and all v0.19.0 flag fields populated.

Iconic abilities (one per essence) have `baseTier: 5` so they're only castable when the sorcerer has 95%+ in the essence skill. Iconic PP cost: 3.

Patch applied via `elysium-compendium/dev/patch-sorcery-content-v0.19.0.py` (re-runnable, idempotent). Backups at `packs/skills.db.pre-v0.19.0.bak`.

### Phase N — Migration validator

New script at `elysium-compendium/dev/migrate-v0.19.0.py` checks all packs for v0.19.0 schema consistency. Identified and fixed 53 divine spells missing one or more of the new schema fields (`isSustained`, `maintainPPPerRound`, `powCostByTier`) — the Phase A divine patch only touched spells with non-default values, leaving the rest schema-incomplete. Migration script applied default values to all 30 divine spells so the schema is uniform.

Final validator output: **0 issues**.

### Phase O — Release wrap

Versions bumped to clean `v0.19.0` / `0.13.0` / `14.2.1-elysium-0.19.0` (no phase-suffix).

### Cumulative summary across all phases

**System (elysium):**
- New module: `combat/armor-vs-damage.mjs` (~270 lines) — cross-tradition damage-vs-armor table + hit-location rollers
- Cast pipelines: divine and sorcery both updated to use v0.19.0 schema fields
- Sorcery cast pipeline fully replaced (was a v0.18.x stub)
- Sorcery item sheet fully rewritten with v0.19.0 fields
- Tier-choice dialog generalized for both divine and sorcery
- Template schema additions on divine and sorcery item types
- 33-case armor-vs-damage smoke test

**Rules module (elysium):**
- `hpMultiplier` world setting (Number, 0.5-4.0, default 1.0)
- `ElysiumMythrasHP.hpForLocation()` applies the multiplier
- `arcaneDamagePerPP` setting removed (hardcoded to 4 in system fork)

**Compendium:**
- Divine rebalance applied to `packs/spells-divine.db` (16 of 30 spells edited)
- 16 new conditions added to `packs/conditions.db`
- 88 sorcery abilities added to `packs/abilities-sorcery.db` (was empty)
- 4 essence skill descriptions updated with keystone text
- All packs schema-consistent per Phase N validator

### Known limitations carried into v0.19.0

These are functional but defer polish to future releases:

1. **Keystone discount logic is GM-applied**, not auto-computed. The keystone text describes the trigger conditions but the cast pipeline doesn't currently check them and reduce PP automatically.
2. **`casterChoosesLocation` defaults to "first N locations"** rather than opening a picker dialog. Sufficient for testing; a polish phase may add the picker.
3. **POW recovery for Resurrection is manual.** No automatic "long rest" hook restores POW yet.
4. **Sustained spell disruption-on-damage is manual.** GM triggers the disrupt button (same as v0.18.x arcane).
5. **Death's Refusal and Anchor Life** are described in the per-tier effect text but lack dedicated active-effect plumbing. GM tracks the deferred-death and consume-on-trigger mechanics manually.

These are intentional v0.19.0 scope cuts. The mechanics work; just less automation than full-polish.

## Elysium 14.2.1-elysium-0.19.0-phase-d1 — Phase D-1: Sorcery cast pipeline (paired with rules 0.19.0-phase-d1 and compendium 0.13.0-phase-d1)

Fourth slice of v0.19.0. Phase D is split into multiple sub-phases because it's the largest remaining piece. D-1 is the **cast pipeline replacement**: the v0.18.x flat-cast stub is gone, replaced with a full tier-based pipeline modeled on the divine pattern. The sorcery item sheet template is also rewritten to expose the v0.19.0 schema fields.

D-2 (next phase) will add hit-location targeting and `applyArmorToDamage` integration so damage spells actually subtract armor automatically. D-1 lays the foundation; D-2 makes damage spells dynamic.

### Sorcery cast pipeline — full rewrite (`module/casting/sorcery-cast.mjs`)

The v0.18.x stub was a flat single-AP cast: no tier choice, no per-tier scaling, no hit-location targeting, no armor interaction, no sustain registration. It existed only to keep the cast button from crashing. Phase D-1 replaces it with the real v0.19.0 mechanic.

**New entry point:** `beginSorceryCast(actor, spell)`. The old `castSorcery` name is preserved as a back-compat alias so the existing sheet button at `base-actor-sheet.mjs` line 714 continues to work without modification.

**Pipeline behavior per the locked v0.19.0 design:**

1. **Essence skill lookup.** The spell's `essence` field (e.g. `'elemental'`) drives the search. Matches a skill item with subgroup `'sorcery'` and a name containing the essence (e.g. "Elemental Essence"). Falls back to any sorcery-subgroup skill if no name match.

2. **Tier availability computation.** Tier thresholds locked at **1 / 50 / 70 / 85 / 95** (a change from the v0.18.x stub's 1/25/50/75/100). Combined with the spell's `baseTier` and `maxTier`, this produces the list of tiers the player may choose from. Iconic abilities (`baseTier: 5`) require the sorcerer to be Transcendent (95+ essence skill) to cast at all.

3. **Tier-choice dialog.** Reuses the existing `TierChoiceDialog` (originally built for divine in v0.18.0). Phase D-1 generalizes the dialog to support both divine (two-skill: Channeling + Faith) and sorcery (single-skill: essence). Sorcery passes the essence skill total in the `channelTotal` slot and `-1` as a sentinel in `faithTotal`. The dialog's `_prepareContext` detects this and switches the header/labels/instructions accordingly. Dialog code now has both `DIVINE_TIER_LABELS` ("Untested/Devotee/Anointed/Chosen/Saint") and `SORCERY_TIER_LABELS` ("Nascent/Developing/Established/Potent/Transcendent").

4. **AP and PP payment.** AP cost is taken from `apCostByTier[chosenTier - 1]` (per-tier costs; most sorcery is `[1,1,1,1,1]`; iconics are `[—,—,—,—,3]`). PP cost is a flat `powerCost` (default 2 for normal abilities, 3 for iconics). Insufficient PP → existing overcast-to-fatigue behavior via `payPP`.

5. **Spontaneous & reliable.** A d100 is rolled against the essence skill total, but **the spell always fires** regardless of result. The roll value is captured as the resistance value for opposed-save targets. There is no failure mode where the sorcerer's spell fizzles — this is the locked-design distinction from arcane (which can fizzle on roll failure) and divine (which can fizzle on Channel fail or twist on Faith fail).

6. **Chat card and forbidden warning.** Standard cast card is posted. If the spell's `forbidden` flag is true (Death, Blight, Void essences), the chat card prepends a `⚠ Forbidden essence cast` warning paragraph for visibility — the GM may invoke social consequences.

7. **Sustain registration.** Mirrors the Phase C divine wiring: if `isSustained: true`, calls `addSustain(actor, { ..., ppPerRound: maintainPPPerRound })`. Per-round drain happens via the existing `runSustainUpkeep` hook in `elysium-rules/combat-extension.mjs`.

### Sorcery item schema — `template.json` rewrite

The `Item.sorcery.elysium` schema gained the v0.19.0 fields. The legacy fields (`tierIndex`, `thresholds`, `isConfluence`, etc.) are preserved on the schema for backward compatibility, but the new cast pipeline does not read them. Existing items in user worlds will load with the legacy fields intact and default values for the new fields.

**New fields:**
- `baseTier: 1` (Number) — lowest tier the ability can be cast at. Iconic abilities set 5.
- `maxTier: 5` (Number) — highest tier the ability scales to.
- `apCostByTier: [1, 1, 1, 1, 1]` (Array<Number>) — per-tier AP cost.
- `effectByTier: { "1": "", ..., "5": "" }` (Object<String, String>) — per-tier effect description shown in the cast card and tier-choice dialog.
- `isDamageSpell: false` (Boolean) — flags abilities that deal damage (for Phase D-2's armor-vs-damage integration).
- `damageType: ""` (String) — one of the locked v0.19.0 damage types (slashing/piercing/bludgeoning/force/fire/cold/lightning/corrosive/sonic/poison/necrotic/psychic/radiant/distortion).
- `isSustained: false` (Boolean) — flags abilities like Sanctum Dome, Siphon, Grave Mist.
- `maintainPPPerRound: 0` (Number) — PP cost per round to maintain a sustained ability. Typically 1.
- `forbidden: false` (Boolean) — flags Death/Blight/Void abilities. Triggers the `⚠ Forbidden essence cast` chat warning.

**Threshold values updated:** `thresholds.nascent.max` changed from 25 → 49, `developing` from 26-50 → 50-69, `established` from 51-75 → 70-84, `potent` from 76-99 → 85-94, `transcendent` from 100-999 → 95-999. These match the locked v0.19.0 tier thresholds (1/50/70/85/95).

**Default `powerCost` changed:** 0 → 2 (Phase D-1's default for newly-created sorcery items; matches the design baseline).

### Sorcery item sheet — full rewrite (`templates/item/sorcery.detail.hbs`)

The shipped sorcery sheet exposed only legacy fields (`range`, `pppl`, `powCost`, `maxLvl`, `saveSkill`). The new sheet exposes all v0.19.0 fields:

- **Essence selector** (12 options): Elemental, Vitality, Death (forbidden), Ward, Light, Shadow, Mind, Presence, Soul, Wild, Blight (forbidden), Void (forbidden). Selecting a forbidden essence does NOT auto-set the forbidden flag — that's a separate checkbox so GMs can author forbidden custom abilities or grant exemptions.
- **Base/Max tier** number inputs (1-5).
- **PP cost** number input.
- **AP-cost-by-tier grid** (T1-T5, editable per cell).
- **Damage type** selector (14 v0.19.0 damage types plus the empty "non-damaging" option).
- **Save skill** selector (same as divine: Evade/Willpower/Endurance/Brawn).
- **Per-tier effect textareas** — five textareas (T1-T5), each editable by the GM. This is where the actual ability description lives; players see the rendered text in read-only mode and in the cast-time tier-choice dialog.
- **Range** text input (flavour text for chat-card display).
- **Three flag checkboxes**: isDamageSpell, isSustained, forbidden.
- **Conditional maintainPPPerRound** field — appears only when isSustained is checked.

Sheet code (`module/item/sheets/sorcery.mjs`) gains the `apCostByTierList` and `effectsByTierList` context builders that the divine sheet has. Form handler (`mySorceryHandler`) is defensively patched to preserve legacy `maxLvl`/`currLvl`/`memLvl` fields when the new template omits them.

### Tier-choice dialog generalization (`module/casting/tier-choice-dialog.mjs`)

The dialog is now tradition-aware. Detection uses the `faithTotal === -1` sentinel that sorcery passes:

- **Header:** divine shows "Channeling: X% · Faith: Y%"; sorcery shows "Essence skill: X%".
- **Tier labels:** divine uses Untested/Devotee/Anointed/Chosen/Saint; sorcery uses Nascent/Developing/Established/Potent/Transcendent.
- **Instructional text:** divine mentions "both Channeling and Faith above the tier band"; sorcery mentions "your essence skill is above the tier band".

Mechanics are otherwise identical: a per-tier button list with AP cost and effect description, single-tier selection, Cast/Cancel buttons.

### `game.system.api` additions

Two new exports added to the casting namespace:
- `beginSorceryCast(actor, spell)` — the new entry point
- `maxCastableSorceryTier(skillTotal)` — utility for sheet rendering or macros that need to know which tier a sorcerer qualifies for

### Verification

Tier-threshold math hand-verified across the full skill range (0/1/49/50/69/70/84/85/94/95/120/200), including the iconic-availability case (baseTier=5 requires skill ≥95). All `.mjs` files syntax-check clean across both modules.

### What's NOT in Phase D-1

- **Hit-location targeting.** The cast pipeline currently just posts the per-tier effect text to chat; it doesn't prompt for a hit location or roll a random one. Phase D-2 adds this.
- **Damage application.** The pipeline doesn't yet roll damage dice from spell text or apply `applyArmorToDamage`. The `damageType` field is captured on the chat card for GM reference, but no automatic damage subtraction happens. Phase D-2 adds this.
- **Keystone discount logic.** Per the locked v0.19.0 design, each essence has a passive keystone that grants a -1 PP discount under specific conditions (Death Sense, Ward Sight, etc.). These are per-essence and complex; Phase H will implement them.
- **88 sorcery abilities content.** The compendium pack `abilities-sorcery.db` is currently empty (0 lines). Phase J will populate it with the authored content from the design docs.
- **Sorcery sheet tab UX.** The new template is functional but visually plain; Phase F may polish the layout with CSS.

## Elysium 14.2.1-elysium-0.19.0-phase-c — Phase C: Divine cast pipeline wiring (paired with rules 0.19.0-phase-c and compendium 0.13.0-phase-c)

Third slice of v0.19.0. Phase C wires the divine cast pipeline to actually USE the schema fields added in Phase A. The Phase A divine rebalance shipped data — sustained spells flagged as such, Resurrection's POW ladder defined — but no code consumed those fields. Phase C closes that loop: sustained divine spells now auto-register on the sustain registry, and Resurrection auto-applies POW loss at cast time.

### `module/casting/divine-cast.mjs` — two new behaviors at cast completion

**Sustained-spell registration.** When a divine cast completes successfully and the spell has `isSustained: true`, the pipeline now calls `addSustain(actor, { spellId, spellName, ppPerRound: maintainPPPerRound, schoolName })`. This registers the spell with the existing sustain registry (originally built for arcane in v0.10.0), which means:

- The per-round PP drain happens automatically at the start of each combat round (via `runSustainUpkeep`, invoked by `elysium-rules/combat-extension.mjs`'s combat round-start hook).
- If the cleric runs out of PP mid-fight, the sustain collapses with a chat notice (existing arcane-sustain machinery handles this).
- The cleric can voluntarily end the sustain via the existing UI buttons.
- Manual disruption (GM-triggered Willpower save vs damage) is supported via the existing `disruptSustain` API.

Notably, **the sustain entry uses `maintainPPPerRound` for the per-round cost, not the full cast cost.** This differs from arcane sustains, which charge the full cast PP every round. The divine design uses a fixed 1 PP/round upkeep regardless of cast cost — Spirit Guardians (2 PP cast) and Spiritual Weapon (3 PP cast) both maintain at 1 PP/round.

The three currently-sustained divine spells (Spiritual Weapon, Spirit Guardians, Investiture of Flame) all have `maintainPPPerRound: 1` per the Phase A data patch.

**POW loss for Resurrection.** When a divine cast completes successfully and the spell has a non-empty `powCostByTier` array, the pipeline now calls a new private helper `applyDivinePOWLoss(actor, spellName, chosenTier, powCostByTier)`. This:

- Reads the current `system.stats.pow.effects` value (the temporary-modifier slot for the POW stat)
- Decrements it by `powCostByTier[chosenTier - 1]`
- Persists via `actor.update()` — which triggers Foundry's `prepareData` cycle, automatically recomputing `system.power.max` (PP-max derives from total POW)
- Posts a chat notice explaining the loss and the recovery rate

Currently only Resurrection has a non-empty `powCostByTier` (`[2, 2, 3, 4, 5]` per Phase A). At cleric tier 5, a successful Resurrection cast drops POW by 5 — the iconic Mythras-style sacrifice. POW recovers at 1 per day of rest, but **v0.19.0 does not yet implement automatic recovery** — the GM tracks the recovery interval manually, or uses the existing actor edit form to restore POW after sufficient time.

Both behaviors are gated on `succeeded` — a twisted prayer (Wild Magic outcome) does NOT trigger sustain registration or POW loss. The cleric got punished enough.

### Cross-version behavior

Existing v0.18.x worlds upgrading to v0.19.0-phase-c will see:
- Re-casting an already-active sustained divine spell refreshes the sustain (replaces the entry); doesn't accumulate multiple copies.
- Sustained divine spells will collapse if the cleric drops below 1 PP at combat round start.
- POW losses from Resurrection persist across sessions (stored on the actor's stats data, not on a transient flag).

### What's NOT in Phase C

- Auto-disruption-on-damage for sustained divine spells — same status as arcane sustains, which are manual-only. Deferred to a later polish phase.
- Automatic POW recovery during rest — GM tracks manually.
- POW loss display on the cleric's sheet — the `effects` field is already shown in the stats panel; players can see their current temporary modifiers there.

## Elysium 14.2.1-elysium-0.19.0-phase-b — Phase B: applyArmorToDamage() function (paired with rules 0.19.0-phase-b and compendium 0.13.0-phase-b)

Second slice of v0.19.0. Phase B adds the cross-tradition damage-vs-armor function that implements the locked damage type interaction table. No data changes; no other code is wired to call the new function yet (call sites come in Phase D when the sorcery cast pipeline lands).

### `module/combat/armor-vs-damage.mjs` — new file

Implements `applyArmorToDamage(rawDamage, damageType, targetActor, hitLocationId) → { final, totalEffectiveAP, breakdown }` per the locked v0.19.0 design (see `elysium-rules/docs/v0.19.0-design/DESIGN-sorcery-v0.19.0.md` § "Cross-tradition damage and armor framework").

The function walks the target actor's equipped armor pieces on the affected hit location, computes each piece's effective AP per the damage-type interaction table, sums effective APs, and returns final damage. The breakdown array enables chat-card display of what was reduced and why.

Damage type categories:
- **FULL AP** (slashing, piercing, bludgeoning, force, corrosive) — armor's `av1` applies normally
- **HALF AP vs metal, FULL vs cloth** (fire, cold) — `Math.floor(av/2)` for chain/scale/plate, full for cloth
- **FULL AP vs cloth, NONE vs metal** (lightning) — cloth insulates; metal conducts
- **BYPASS universally** (sonic, poison, necrotic, psychic, radiant, distortion) — armor doesn't reduce

The function reads `system.elysium.material` on each armor piece. Materials supported: cloth, chain, scale, plate. Defaults to 'full AP' for unknown materials (safe fallback).

Layered armor: each piece's effective AP is computed independently, then summed. A character wearing gambeson (cloth av1) + chain hauberk (chain av3) + half plate (plate av4) takes 8 AP vs slashing (1+3+4), 4 AP vs fire (1 full + 1 half + 2 half), 1 AP vs lightning (cloth only).

Stowed armor (`equipStatus !== 'equipped'`) does not protect. Worn armor not matching `hitlocID` does not protect (per BRP convention).

### Two helper exports also included

- `computeCorrosiveArmorWear(breakdown, armorDamage)` — placeholder for the layered corrosive cascade logic. Phase B implements the simple flat case (all corrosive damage hits the outer layer). Multi-layer cascade deferred to a later patch.
- `formatArmorBreakdownHTML(breakdown, rawDamage, final)` — renders a chat-card-friendly HTML block listing each piece's reduction. Used by future cast pipelines that resolve damage automatically.

### Exposed via `game.system.api.combat`

New top-level namespace on the system API:
```javascript
game.system.api.combat = {
  applyArmorToDamage,
  computeCorrosiveArmorWear,
  formatArmorBreakdownHTML,
}
```

Other modules and macros can invoke these without cross-package imports.

### Tested

`tests/test-armor-vs-damage.mjs` runs 33 cases covering every damage type × armor material combination, plus edge cases (zero damage, unknown damage types, stowed armor, layered stacks). All passing. Test file ships in the dev tree but does not affect runtime — it's a node-runnable smoke test for the function in isolation.

### What's NOT changed in Phase B

The new function is **not yet called from any cast pipeline**. Current state:
- Divine cast pipeline (in `divine-cast.mjs`) extracts the `damageType` field from spells and includes it in the chat card, but does not auto-apply armor reduction — damage is still rolled and entered manually by the GM, same as v0.18.x.
- Arcane cast pipeline does not yet read damage type (the field exists on some shipped arcane spells but isn't consumed in casting flow).
- Sorcery cast pipeline is still the v0.18.x stub.

Phase D's sorcery pipeline overhaul is where the function gets its first live caller. The divine pipeline gets retrofitted in a later phase if desired (current behaviour is non-breaking for v0.18.x campaigns).

## Elysium 14.2.1-elysium-0.19.0-phase-a — Phase A: arcane multiplier hardcoded + divine schema additions (paired with rules 0.19.0-phase-a and compendium 0.13.0-phase-a)

First slice of the v0.19.0 release. System-fork changes for Phase A are minimal — confined to the arcane multiplier removal and three new schema fields on the divine spell type.

### Arcane damage multiplier hardcoded

The `arcaneDamagePerPP` setting registration was removed in the rules module. In the system fork, the three call sites that read it have been converted to use a hardcoded constant `ARCANE_DAMAGE_PER_PP = 4`, exported from `module/casting/cast-shared.mjs`.

Files changed:
- `module/casting/cast-shared.mjs` — added `export const ARCANE_DAMAGE_PER_PP = 4` with explanatory comment
- `module/casting/arcane-cast.mjs` — `game.settings.get('elysium', 'arcaneDamagePerPP') ?? 1` replaced at both call sites (lines 255 and 412 of v0.18.2); import block updated; function docstring updated
- `module/casting/manipulation-dialog.mjs` — same replacement at the projection-display call site; import block and docstring updated
- `templates/item/arcane.detail.hbs` — tooltip on the damage field updated to reference the constant by name

### Divine spell schema additions

`template.json` `Item.divine.elysium` gained three new fields, all backwards-compatible (existing items get defaults via Foundry's auto-migration):

- `isSustained: Boolean` (default false) — flags spells like Spiritual Weapon, Spirit Guardians, Investiture of Flame that persist beyond one round
- `maintainPPPerRound: Number` (default 0) — PP cost per round to keep a sustained spell active. Phase C's cast pipeline will deduct this at start of caster's turn.
- `powCostByTier: Array<Number>` (default `[0, 0, 0, 0, 0]`) — per-tier POW reduction (currently only Resurrection uses this; ladder is `[2, 2, 3, 4, 5]`). Phase C wires automatic application.

### What is NOT changed in Phase A

- Cast pipeline does not yet read `maintainPPPerRound` or `powCostByTier` — wired in Phase C
- Sorcery cast pipeline still the v0.18.x stub — Phase D
- Cross-tradition damage-vs-armor function not yet present — Phase B
- Sorcery spell schema and sheet template — Phase D/F

## Elysium 14.2.1-elysium-0.18.2 — Version bump for v0.18.2 release pairing

No system-fork code changes in this patch. Bumped to keep version pairing with rules 0.18.2 (CSS fix) and compendium 0.12.2 (Range/Duration + Resurrection rework).

## Elysium 14.2.1-elysium-0.18.1 — Divine spell sheet renders per-tier fields (paired with rules 0.18.1)

Patch release. v0.18.0 added schema fields (`effectByTier`, `apCostByTier`, `baseTier`, `maxTier`, `damageType`) but the divine spell sheet template wasn't updated to display them. Players opening Cure Wounds saw a v0.17.0-style sheet with no per-tier scaling visible.

### Changes

- **`templates/item/divine.detail.hbs`** rewritten:
  - baseTier / maxTier fields (replace legacy single `tier`)
  - AP cost displayed as a 5-cell tier grid (T1-T5)
  - damageType as a colored tag selector
  - effectByTier rendered as a per-tier section with each tier showing its number, AP cost, and effect description text-area
- **`module/item/sheets/divine.mjs`** — `_preparePartContext` for the details tab now precomputes `effectsByTierList` and `apCostByTierList` so the template can iterate without HBS arithmetic helpers.

### What is NOT changed

- Cast pipeline (unchanged from v0.18.0)
- Schema (unchanged — fields existed; only display was missing)

## Elysium 14.2.1-elysium-0.18.0 — Divine multi-AP pipeline + damage type system (pairs with rules 0.18.0 and compendium 0.12.0)

System-fork side of the v0.18.0 Divine v2 redesign.

### Schema (`template.json`)

**Arcane spells gain:**
- `system.elysium.damageType` (string)
- `system.elysium.forbidden` (boolean)

**Divine spells gain:**
- `system.elysium.baseTier` (number, default 1)
- `system.elysium.maxTier` (number, default 5)
- `system.elysium.apCostByTier` (array of 5, default `[1,1,2,2,3]`)
- `system.elysium.effectByTier` (object with keys "1"-"5")
- `system.elysium.damageType` (string)

### `module/casting/divine-cast.mjs` — full rewrite (v0.17.0 → v0.18.0)

State machine instead of single function:
- `beginDivineCast(actor, spell)` — open tier dialog, validate, charge first AP+PP, post in-progress card
- `spendDivineCastAP(actor)` — decrement remaining; on last AP, fire Channeling roll
- `abandonDivineCast(actor, reason)` — refund PP, clear state
- `_resolveDivineCast(actor, spell, ctx)` — internal: Channeling roll, conditional Faith roll, post completion card
- `maxCastableTier(channelTotal, faithTotal)` — utility

Active-cast state tracked in `flags.elysium.activeCast = { tradition: 'divine', spellId, chosenTier, apTotal, apSpent, ppCommitted, messageId }`. The same flag slot is used by arcane (which sets `tradition: 'arcane'`); a character can have only one active cast across all traditions.

`castDivine` retained as a backward-compat alias for `beginDivineCast`.

### NEW: `module/casting/tier-choice-dialog.mjs`

ApplicationV2 dialog. Opens at cast start. Shows the player which tiers they qualify for (based on Channeling and Faith totals), with AP cost and effect description per tier. Returns `{ tier }` on confirm, null on cancel.

### Cast card template (`templates/chat/cast-card.hbs`)

New section showing damage type prominently with color-coded styling. Reads `damageType` from the cast context.

### Casting API exports (`module/hooks/init.mjs`)

Added: `beginDivineCast`, `spendDivineCastAP`, `abandonDivineCast`, `maxCastableTier`. Removed: `divineChannelBandBonus`, `divineChannelBandLabel` (deprecated).

### Required pairing

System fork v14.2.1-elysium-0.18.0 **requires** rules module 0.18.0 (migration helper) and compendium 0.12.0 (per-tier spell content).

## Elysium 14.2.1-elysium-0.17.0 — Divine cast pipeline rewrite (pairs with rules 0.17.0 and compendium 0.11.0)

System-fork side of the v0.17.0 Divine redesign. The rules-module CHANGELOG carries the design discussion; this entry documents the system-fork code changes.

### `module/casting/divine-cast.mjs` — full rewrite

Pre-v0.17.0: 92 lines, single d100-vs-Faith roll, tier flavor only.

Post-v0.17.0: 220 lines, two-skill tier gate + Channeling cast roll + conditional Faith roll for wild magic. New flow:

```
1. Find Faith allegiance (existing — uses faiths[0])
2. Find Channeling skill via findSkill(actor, { subgroup: 'divine' })
3. Tier gate: Channeling >= TIER_THRESHOLDS[tier] AND Faith >= TIER_THRESHOLDS[tier]
4. Pay AP (consumed even on failure)
5. Pay PP (refunded on Channel fail)
6. Roll d100 vs Channeling
   - Fail → refundPP, post fizzle card, return
   - Critical fumble → same as fail (locked design: no special consequence)
7. (Channel succeeded) If Faith < 100: roll d100 vs Faith
   - Faith fail → wild magic via rollMagicTable('divineWildMagic')
   - Faith success → spell happens cleanly
   - (Faith == 100 skips this step entirely)
8. Post chat card with Channeling band damage scaling note for damage spells
```

`TIER_THRESHOLDS` constant defined inline: `{1: 1, 2: 50, 3: 70, 4: 85, 5: 95}`. Matches Mythras grade thresholds.

### New exports

`divineChannelBandBonus(channelTotal)` — returns 0/1/2/3/4 (additional damage dice for the cleric's current Channeling band).

`divineChannelBandLabel(channelTotal)` — returns "Untested (<50)" / "Devotee (50-69)" / etc.

Both wired into `module/hooks/init.mjs` exports under `game.system.api.casting`.

### Schema (`template.json`)

Divine spell schema gains `system.elysium.isDamageSpell: false` (mirrors arcane v0.16.0). Set per-spell in compendium 0.11.0 content.

`minFaithRank` field retained in schema for backward compat; cast code no longer reads it (replaced by `tier`-based threshold lookup).

### Sheet integration

No changes — the Divine tab template at `templates/actor/character.divine.hbs` already had Channeling-skill section and Faith-allegiance section since v0.7.7. Both populate correctly from the existing `context.elysiumDivineTab.{channelingSkills, faiths}` infrastructure.

### Required pairing

System fork v14.2.1-elysium-0.17.0 **requires** rules module 0.17.0 (which carries the migration helper for actor-owned divine spells) and compendium 0.11.0 (spell descriptions, Faith bands, isDamageSpell content). Without rules 0.17.0, `migrateWorldTo0_17_0` doesn't run — actor-local divine spells with no `isDamageSpell` field will display incorrectly until manually edited.

## Elysium 14.2.1-elysium-0.16.0 — Arcane redesign: schema, INT-pool, cast-disruption, custom-spell builder (pairs with rules 0.16.0 and compendium 0.10.0)

System-fork side of the v0.16.0 Arcane redesign. The rules-module CHANGELOG carries the full design discussion; this entry documents the system-fork code changes specifically.

### Schema (`template.json`)

Arcane spell `system.elysium` block: removed `baseline.magnitude` (4 baseline params remain: range, duration, targets, area). Added top-level `isDamageSpell: false` boolean as the new damage-or-not gate.

### Manipulation dialog (`module/casting/manipulation-dialog.mjs`)

`PARAMS` constant now `['range', 'duration', 'targets', 'area']` (was 5 entries). All call sites that iterated this list (delta init, label map, effective baseline, cast-as-written reset) updated.

Damage-show condition rewritten: was `baseline.magnitude > 0 || deltas.magnitude > 0`, now `spell.system.elysium.isDamageSpell` (with custom-spell-builder mode forcing it true so the player always has the toggle).

INT pool computation: was `actor.system.stats.int.total` (full INT). Now `Math.floor(int.total / 2)` minus any spent earlier in the same combat round. Pool persists in `actor.flags.elysium.intPool = { roundId, spent }`. The dialog reads this on open, subtracts from the floor-INT/2 base, and writes back the new total on successful cast.

Out-of-combat behavior: every cast gets a fresh pool; no flag tracking. The actor's combat-round membership is what triggers persistent tracking.

### Cast-shared (`module/casting/cast-shared.mjs`)

`MANIPULATION_BASE_COST` table loses the `magnitude: 2` entry. JSDoc `@param` types for the manipulation helpers updated to remove magnitude. The `'magnitude'` string in the `summariseManipulation` iteration drops out automatically since it iterates `Object.keys(MANIPULATION_BASE_COST)`.

The `// v0.10.0 — PP-as-magnitude` comment on `ppCommitted` field rewritten to clarify that "magnitude" was the legacy field name; the actual semantic is "PP committed for damage scaling at cast time."

### Arcane casting (`module/casting/arcane-cast.mjs`)

`humanReadableManipulation()` iteration drops magnitude. `computeProjectedDamage()` rewritten:

```js
function computeProjectedDamage (spell, manipulation, damagePerPP) {
  if (!spell || !manipulation) return 0
  const isDamageSpell = !!spell?.system?.elysium?.isDamageSpell
  if (!isDamageSpell) return 0
  return (Number(manipulation.ppCommitted) || 0) * damagePerPP
}
```

Same call sites and same return shape as before; just the gating predicate changes. Existing PP-commit display row in the chat card and manipulation dialog continues to work.

### NEW: Cast disruption (`module/casting/cast-disruption.mjs`)

Standalone module handling SL-loss-on-hit during active casts. Exported via `game.system.api.casting`:
- `checkActiveCastDisruption(actor, woundItem)` — call from the wound-created hook to determine if a disruption applies. Returns `{activeCast, severity, slLoss, damage, location, willpower}` or null.
- `applyDisruptionRoll(actor, rollResult, ctx)` — call after the player rolls. Reduces `accumulatedSL` on the active cast based on `slLoss` (a number or 'all'). Returns `{outcome, slBefore, slAfter, slLost}`.
- `classifyWoundSeverity(damage, location)` — wound tier classifier. Mythras-canonical thresholds: `damage >= maxHP * 3` → critical, `>= maxHP * 2` → serious, otherwise minor.
- `slLossForSeverity(severity)` — design-spec-defined SL-loss table. Critical → 'all', serious → 2, minor → 1.
- `findWillpowerSkill(actor)` — locates a skill named "Willpower" (case-insensitive) on the actor.

Wired into the rules-module's `wound-created` hook (which already handles sustain disruption) — the hook checks both sustains AND active casts; both can fire on the same wound event.

### NEW: Custom-spell builder (`module/casting/custom-spell-builder.mjs`)

ApplicationV2 dialog opened by the Arcane tab's "Cast Custom" button. Lets a player author a spell live with full Form/Technique/school/isDamageSpell/requiredSL/basePP control, then routes to `beginArcaneCast` with the freshly-created spell item.

Strategy: **always create the spell item on the actor first; offer to discard after the cast resolves.** This means the cast pipeline reads from a real Foundry document, the player can see the saved spell in their spellbook even before deciding whether to keep it, and the keep/discard decision is informed by how the cast actually went.

Sanity gates: builder refuses to open if the actor lacks any school skill, any Form, or any Technique — would be unusable otherwise.

Polling: after `beginArcaneCast()` returns, the dialog polls `actor.getFlag('elysium', 'activeCast')` every 500ms (max 60s) to detect cast completion or abandonment. When the flag clears, the keep/discard prompt fires. The 60s timeout is a safety valve in case the active cast flag fails to clear.

Exposed via `game.system.api.casting.openCustomSpellBuilder(actor)`. Also wired into the character sheet's actions registry as `castCustomSpell` for the Arcane tab button.

### Sheet integration (`module/actor/sheets/base-actor-sheet.mjs`)

Imports `CustomSpellBuilder`. Adds `castCustomSpell` to the actions registry. Adds `_onCastCustomSpell()` static method that opens the builder for the current actor.

### Arcane tab template (`templates/actor/character.arcane.hbs`)

New "Cast Custom" affordance in the spell list section header. Sits next to the existing "+" add-spell button. Icon: `fas fa-magic`. Tooltip pulled from rules-module locale `Elysium.Magic.CastCustomTooltip`.

### Custom-spell builder template (`templates/casting/custom-spell-builder.hbs`)

New file. Multi-section form: identity (name, school dropdown), Forms (toggle grid, filtered to actor's owned), Techniques (toggle grid, filtered), damage flag (single toggle), casting params (requiredSL number, basePP number). Footer with Proceed / Cancel buttons.

### Casting API exports (`module/hooks/init.mjs`)

Adds to `game.system.api.casting`:
- `checkActiveCastDisruption`, `applyDisruptionRoll`, `classifyWoundSeverity`, `slLossForSeverity`, `findWillpowerSkill` (cast-disruption helpers)
- `openCustomSpellBuilder` (lambda wrapping `CustomSpellBuilder.open`)

### Required pairing

System fork v14.2.1-elysium-0.16.0 **requires** rules module 0.16.0 (which carries the wound-created-hook integration, the chat button click handlers, the migration helper, and the locale strings) and compendium 0.10.0 (which has spells authored against the new schema). Without rules 0.16.0 the cast-disruption prompt won't post; without compendium 0.10.0 the Arcane tab spell list will be empty.

## Elysium 14.2.1-elysium-0.15.1 — Arcane tab F/T sections (pairs with rules 0.15.2; compendium unchanged at 0.9.1)

Splits the Arcane tab's single "Arcane Skill" section into three: **Arcane Schools** (Evocation, Abjuration, etc.), **Forms** (the 14 F/T skills tagged `arcaneRole === 'form'`), and **Techniques** (the 10 F/T skills tagged `arcaneRole === 'technique'`). Removes the obsolete passion-based F/T section that's been empty since v0.15.0's migration moved F/T off passions.

This replaces a DOM-injection-based UI (shipped in rules 0.15.0) that targeted an abilities tab that doesn't exist. The F/T skills were already appearing on the Arcane tab — the v0.15.0 injection was redundant and a no-op. This release routes the data into proper template-rendered sections so each section has a clear header, count, and collapse affordance.

### `_buildCategorisedSkills` splits the arcane bucket

Previously `out.magic.arcane = { skills: [] }` held everything tagged `skillSubgroup === 'arcane'` regardless of role. Now `out.magic.arcane = { skills: [], formSkills: [], techniqueSkills: [] }` — school skills go to `skills`, F/T skills route to `formSkills` or `techniqueSkills` based on `system.elysium.arcaneRole`.

The `skills` field still holds the school-skill subset, so the Skills tab's "Magic > Arcane" subsection (which reads `magic.arcane.skills`) automatically excludes F/T — they have a more prominent home on the Arcane tab now. No change to `character.skills.hbs` was needed.

`out.counts.magic` gains `arcaneForms` and `arcaneTechniques` counts. The existing `arcane` count means school skills only (matching what the Skills tab renders). `magic.total` sums all four for backward compat with any consumer reading the rolled-up count.

### `context.elysiumArcaneTab` exposes the F/T buckets

`elysiumArcaneTab.formSkills` and `elysiumArcaneTab.techniqueSkills` are added alongside the existing `arcaneSkills` (school skills), `activeSustains`. The Arcane tab template iterates them as separate sections.

### `templates/actor/character.arcane.hbs` rewrite

- "Arcane Skill" section renamed to "Arcane Schools" (now school-skills-only).
- New "Forms" section iterating `elysiumArcaneTab.formSkills`.
- New "Techniques" section iterating `elysiumArcaneTab.techniqueSkills`.
- Removed the obsolete `passionsArcane`-based "Forms and Techniques" section (was empty since v0.15.0 anyway).
- Each F/T row carries a tooltip pointing at the skill's own item sheet for percentage edits, since the row is read-only on the tab (matching how every other skill row works on the BRP character sheet).
- Spell list and active-sustains list unchanged.

### What is NOT changed

- Casting code (`module/casting/cast-shared.mjs`, `arcane-cast.mjs`) — unchanged from v0.15.0.
- `template.json` schema — unchanged.
- The `findFormOrTechnique` walk over `actor.items` — unchanged. The data routing change is purely about how skills are grouped for *display*; the underlying items are untouched.
- The Skills tab's "Magic > Arcane" subsection — automatically excludes F/T because `magic.arcane.skills` no longer contains them, with no template change needed.

### Required pairing

System fork v14.2.1-elysium-0.15.1 **requires** rules module 0.15.2 (which carries the locale strings the new template references and removes the obsolete dead injector code). Without rules 0.15.2 the new template would render with raw locale keys ("Elysium.Magic.ArcaneSchools" instead of "Arcane Schools"). Compendium 0.9.1 remains compatible — no content changes were needed.

## Elysium 14.2.1-elysium-0.15.0 — Arcane casting code: F/T skill lookups (pairs with rules 0.15.0 and compendium 0.9.0)

The arcane casting code in `module/casting/` is updated for v0.15.0's restructure of Forms and Techniques from passion items to skill items. See the rules module v0.15.0 CHANGELOG for the full architectural rationale and the sheet-UI piece. This release covers only the system-fork code changes.

### `module/casting/cast-shared.mjs`

`findFormOrTechnique(actor, kind, value)` rewritten:
- Filters `actor.items` by `type === 'skill'` (was `'passion'`).
- Matches on `system.elysium.skillSubgroup === 'arcane'` and `system.elysium.arcaneRole === kind.toLowerCase()`.
- Name match (`"Form (X)"` / `"Technique (X)"`) unchanged.
- Returns the skill item or null. Callers continue to read `system.total` for the percentage and treat null as "auto-fail → wild magic."

`getArcaneFormsTechniquesFromCompendium()` rewritten:
- Source pack: `elysium-compendium.passions` → `elysium-compendium.arcane-knowledge`.
- Filter: `doc.type === 'skill'` + `skillSubgroup === 'arcane'` + `arcaneRole in {'form','technique'}`.
- Output shape unchanged. Callers (the spell sheet's F/T multi-select dropdowns) need no changes.

### `module/casting/arcane-cast.mjs`

`runFormTechniqueChecksSilent(actor, spell)` updated:
- Local variable `passion` renamed to `ftSkill`. Same call to `findFormOrTechnique`, same read of `system.total`, same wild-magic stash on failure. The rename is purely cosmetic for code clarity.

Three rename sites: lines 587, 591, 622.

### Compatibility notes

This release **requires** compendium v0.9.0. Without it, `getArcaneFormsTechniquesFromCompendium` finds no pack and warns "Elysium arcane-knowledge pack not found; F/T dropdowns will be empty." Casting still works (the cast code reads from `actor.items` directly via `findFormOrTechnique`, which is unaffected by the absence of the pack), but spell sheets won't populate their F/T dropdowns.

This release **expects** rules module v0.15.0, which ships the migration helper. Without it, existing test characters retain their F/T passions, which the v0.15.0 cast code no longer recognises (it now looks for skills). The migration converts them at world ready.

No template.json schema changes. No actor or sheet template changes — the v0.15.0 sheet UI lives entirely in the rules module's `sheet-extension.mjs` as DOM-side injection.

## Elysium 14.2.1-elysium-0.14.3 — Flag-scope hotfix + Create-Item dropdown cleanup

Pairs with **Elysium rules module 0.14.1** and **ElysiumCompendium 0.8.3** (both unchanged from v0.14.2).

Hotfix on top of v0.14.2. Two unrelated bugs caught after v0.14.2 shipped, both surfaced via the in-Foundry "Create Item" dialog.

### Bug 1: `getFlag('brp', ...)` throws after system-id rename (regression from v0.14.1)

The v0.14.1 release notes claimed:

> Document flag accesses (`getFlag('brp', ...)`) intentionally LEFT as-is — these are document-flag namespaces, not system-id references, and changing them would orphan existing flagged data.

**That reasoning was wrong**, and the v0.14.2 hotfix didn't catch it. Foundry's `Document#getFlag(scope, ...)` and `Document#setFlag(scope, ...)` validate `scope` against the set of registered flag scopes — which is the active modules plus the active system id. With the system id renamed from `'brp'` to `'elysium'`, the bare scope `'brp'` is no longer registered, and *any* `getFlag('brp', ...)` or `setFlag('brp', ...)` call throws:

```
Error: Flag scope "brp" is not valid or not currently active
  at BRPItem.getFlag (foundry.mjs:15213)
  at brpid.mjs:385
```

This breaks every "Create Item" sheet whose `_prepareContext` calls into BRPID's compendium lookup (Skill, Weapon, Mutation, etc. — anything that calls `select-lists.mjs:getCategoryOptions` or `getWeaponSkillOptions`).

The fix preserves the **data namespace** distinction the v0.14.1 notes were trying to protect (BRP-ID content tags should remain at `flags.brp.brpidFlag` for compatibility with external BRP-ID content) but corrects the **API call** path. Two patterns:

- **Reads** switch from `doc.getFlag('brp', 'key')` to direct property access `doc.flags?.brp?.key`. This bypasses Foundry's scope validator entirely and reads the same underlying data.
- **Writes** switch from `setFlag('brp', 'key', val)` to `Document#update({ 'flags.brp.key': val })`. The update path doesn't validate scope (only `setFlag` does), and this is the same pattern already used by every other chat-card writer in `module/cards/*.mjs`.

Sites patched (12 total in 7 files, all in `elysium/module/`):

- `brpid/brpid.mjs:385` — BRP-ID compendium lookup (the throw site visible in user reports)
- `actor/actor-itemDrop.mjs:401, 648` — duplicate-item detection on actor drops
- `apps/check.mjs:784, 785, 788, 801` — chat-card state tracking (3 reads + 1 write; the write became `Document#update`)
- `hooks/render-journal-entry-sheet.mjs:7, 17` — adventure-entry CSS flags
- `hooks/render-journal-entry-page-text-sheet.mjs:2` — same
- `hooks/render-note-config.js:3` — note hide-background flag
- `hooks/draw-note.mjs:3` — same

The `flags.brp.*` data namespace is kept everywhere; only the access mechanism changed. No data migration required for existing worlds.

### Bug 2: Create-Item dropdown shows three phantom types and is missing three real ones

`lang/{en,es,fr}.json` had `TYPES.Item.power`, `TYPES.Item.magic`, and `TYPES.Item.psychic` labels — but none of those are declared item types in `template.json`. They appeared in Foundry's create-item dropdown because Foundry pulls dropdown entries from the locale, but selecting them would create an item with no usable schema.

Conversely, three legitimate declared types (`arcane`, `divine`, `mysticism`) had no labels at all and didn't appear in the dropdown.

This locale file has been correct for some BRP fork's lifetime but never matched Elysium's `template.json` declared types. The fix:

- **Removed** orphan labels: `power`, `magic`, `psychic`
- **Added** missing labels: `arcane: "Arcane Spell"`, `divine: "Divine Spell"`, `mysticism: "Mysticism Ability"`
- **Added** missing `ability: "Ability"` label to `es.json` and `fr.json` (was already present in `en.json`)
- **Fixed** stray leading space in `failing: " Failing"` → `"Failing"` (cosmetic)

After this fix, all 23 declared `Item.types` in `template.json` have a label in every locale, and zero orphan labels remain. Note that `es.json` and `fr.json` still hold English placeholder strings for these labels — actual Spanish/French translation is out of scope for this hotfix.

### Verification checklist for users

After installing v0.14.3, the following Create-Item flows should NOT throw `Flag scope "brp" is not valid or not currently active`:

- Skill, Weapon, Mutation, Armor, Equipment, Hit Location (any item type whose sheet uses `select-lists`)
- The dropdown should now list **Arcane Spell**, **Divine Spell**, **Mysticism Ability** (legitimate types) and should NOT list **Power**, **Magic**, or **Psychic Ability** (orphans).

Adventure-entry CSS, note backgrounds, BRP-ID compendium lookups, and chat-card opposed-roll tracking should all continue to work — the data namespace is unchanged, only the access pattern.

## Elysium 14.2.1-elysium-0.14.2 — System-id rename completion (registerSheet + multi-line settings)

Pairs with **Elysium rules module 0.14.1** and **ElysiumCompendium 0.8.1**.

Hotfix on top of 0.14.1. The 0.14.1 rename caught most system-id references but missed two patterns where the regex-based search didn't reach: multi-line `settings.get(...)` calls (one site in `brp.mjs`) and all `registerSheet('brp', ...)` calls (27 sites across `register-sheets.mjs` and `chaosium-canvas-interface-init.mjs`).

Without these fixes, Foundry would fail on world load with `"brp.gameVersion" is not a registered game setting` (because the setting was registered under `'elysium'` but accessed under `'brp'`), and document sheets wouldn't register against the renamed system at all.

This hotfix re-runs a robust AST-aware audit across all `.mjs/.js` files and updates every system-id reference (whether single-line, multi-line, or in any function call) to `'elysium'`. Document flag namespaces (`getFlag('brp', ...)`, `flags.brp.brpidFlag`) intentionally remain — those are document-data namespaces, not system-id references.

## Elysium 14.2.1-elysium-0.14.1 — System-id rename to elysium (BREAKING)

Pairs with **Elysium rules module 0.14.1** and **ElysiumCompendium 0.8.1**.

**⚠ BREAKING CHANGE for users coming from v0.14.0 or earlier.** The system id was previously `"brp"` — identical to the upstream BRP system maintained at https://github.com/JamesB-EZ/BRP-FoundryVTT — which caused worlds intended for upstream BRP to silently load the Elysium fork instead. v0.14.1 fixes this by renaming the system id to `"elysium"`, ensuring the two forks coexist cleanly on the same Foundry installation.

**What changed:**
- `system.json` `id` field: `"brp"` → `"elysium"`.
- `system.json` macros pack `system` reference updated.
- `system.json` media path updated from `systems/brp/assets/...` to `systems/elysium/assets/...`.
- All 204 hardcoded template paths in JS source (`systems/brp/templates/...`) updated to `systems/elysium/templates/...` across 55 files.
- All 259 `game.settings.get/set/register('brp', ...)` calls updated to `'elysium'`.
- One template (`templates/actor/character.header.hbs`) updated to use new asset path.

**What did NOT change:**
- The BRP-ID content-tagging namespace (`flags.brp.brpidFlag`) inside compendium documents and the corresponding `getFlag('brp', 'brpidFlag')` lookups in `actor-itemDrop.mjs`. This is a content namespace, not a system-id reference, and changing it would break compatibility with externally-authored content using the BRP-ID system.
- CSS class names like `.brp.sheet.actor` and FormApplication classes containing `'brp'`. Renaming would require parallel CSS updates and is purely cosmetic.
- Document flag accesses for journal entries (`getFlag('brp', 'css-adventure-entry')` etc.) — these are document-flag namespaces, not system-id references, and changing them would orphan existing flagged data.

**Migration steps for users:**
1. Uninstall the old `brp`-id Elysium fork (delete `Data/systems/brp/` if it was the Elysium variant; if you also had upstream BRP installed, that one stays).
2. Install the new `elysium`-id system fork from the v0.14.1 release.
3. For each world previously using the Elysium fork: edit the world's `world.json` and change `"system": "brp"` to `"system": "elysium"`.
4. Re-install the Elysium rules module (v0.14.1) and compendium (v0.8.1) as both have updated system dependencies.
5. User settings preferences will reset — reconfigure under `Game Settings → Configure Settings → Elysium BRP`.

## Elysium 14.2.1-elysium-0.14.0 — Restricted AP schema

Pairs with **Elysium rules module 0.14.0** and **ElysiumCompendium 0.8.0**.

Schema-only change supporting the v0.14.0 Combat Stance ability and the broader restricted-AP system. The actor's `actionPoints` schema gains a new pair of fields:

- `defenseValue` — current defense-only AP (parry, evade, defensive maneuvers)
- `defenseMax` — maximum defense-only AP

These join the existing `value` / `max` (general), `attackValue` / `attackMax` (attack-only), and `reactValue` / `reactMax` (reaction-only) pools. Combat Stance grants restricted AP based on its active mode: Defensive → defenseValue, Offensive → attackValue, Balanced → general value. The rules-module's `restrictedAP` helper handles spending priority (restricted pool first, fallback to general).

Also bundled in this version: critical/fumble formula change in `apps/check.mjs` (high-skill characters crit more, fumble less; crossover at skill 50%) and Mythras-canon difficulty grade replacement in `apps/select-lists.mjs` and `apps/check.mjs` (Very Easy ×3 / Easy ×2 / Routine ×1.5 / Average ×1 / Difficult ×0.5 / Formidable ×0.25 / Impossible ×0.1, replacing the BRP-flavor names). Lang files (en/es/fr) updated with new label keys.

## Elysium 14.2.1-elysium-0.13.0 — Mysticism schema bundle fields

Pairs with **Elysium rules module 0.13.0** and **ElysiumCompendium 0.7.0**.

Schema-only change. The mysticism item template is extended with the same themed-bundle fields that v0.12.0 added for ability items: `activation` (object with type/actionCost/ppCost/duration/endConditions), `benefits` (array), `drawbacks` (array), `addOns` (array). Defaults are empty/passive when omitted, so existing mysticism content is unaffected.

This enables mysticism abilities like Enhance Attributes (which has 7 rank-tiered enhancement add-ons spanning skill thresholds 50/70/85/95) to use the same schema and sheet UI as themed abilities. The compendium 0.7.0 mysticism rebuild relies on these fields.

## Elysium 14.2.1-elysium-0.12.1 — EXP cost rebalance documentation

Pairs with **Elysium rules module 0.12.1+** and **ElysiumCompendium 0.6.2+**.

Documentation-only change. The `_addOnSchema_doc` field in `template.json`
referenced the old 1/2/3/4 add-on EXP-cost schedule, which was rebalanced
to 5/6/7/8 in compendium 0.6.2. Schema doc updated to match.

No behavior changes; existing v0.12.0 worlds upgrade transparently.

## Elysium 14.2.1-elysium-0.12.0 — Unreleased

Pairs with **Elysium rules module 0.12.0** and **ElysiumCompendium 0.6.0**.

Schema additions to support the v0.12.0 themed-ability content. All
additions are optional / loose: pre-v0.12.0 entries serialize without
the new fields and remain valid. The reverse (v0.12.0 entries on the
older 0.11.x system fork) is not supported — the ability bundle fields
would be unrecognized.

### Added — `template.json`

- **`ability.elysium`** gained `theme`, `activation` (with `type`,
  `actionCost`, `ppCost`, `duration`, `endConditions[]`), `benefits[]`,
  `drawbacks[]`, and `addOns[]`. These power the themed-bundle ability
  pattern (Rage with 10 add-ons, Combat Stances with stance variants,
  Aura with aura-type variants, etc.). Each add-on is
  `{name, description, requiredSkillPercent, xpDiceCost, ppCost?, effect?}`
  where the gating tier (50/70/85/95) and EXP-die cost (1/2/3/4) are
  paired by design.
- **`super.elysium`** gained `theme` for browse/filter alignment with
  themed abilities.
- **`weapon.elysium`** gained `reloadType` (`none` | `quick` | `standard`
  | `slow`). Tags ranged-reload weapons (firearms, crossbows) so the
  Gunslinger theme's abilities target them uniformly. Default `none`;
  the field is omitted when default to preserve byte-identity for
  pre-existing weapon entries.
- **Actor `system.elysium.companion`** added (`powSpent`,
  `companionActorId`) as a scaffold for the Companion/Pet POW-sacrifice
  mechanic. Conversion ratios and content TBD in a future release.

### Notes

The `effect?` slot in `addOns[]`, `benefits[]`, `drawbacks[]` is
reserved for future structured automation hooks (AE pipeline integration,
auto-roll macros, etc.). v0.12.0 entries fill in description text only;
the slot exists in the schema so later versions can wire structure
without another schema bump.

JSON schema field names remain British (`favouredEnemy`, `naturalArmor`)
by deliberate design — only user-facing entry names are en-US.

## Elysium 14.2.1-elysium-0.11.1 — 2026-05-08

Pairs with **Elysium rules module 0.11.1** and **ElysiumCompendium 0.5.3** (unchanged).

Sheet-side fixes for v0.11.0 play-test feedback. See the rules-module CHANGELOG for full design notes.

### Changed — `module/actor/sheets/character.mjs`

- `context.expDiceDisplay` and `context.expDiceAvailable` exposed for the statistics tab template, sourced from `actor.flags.elysium.expDice`. The new bonus block now renders the EXP dice as "Nd4" / "Nd6" instead of the legacy BRP percentile XP value.

### Changed — `templates/actor/character.statistics.hbs`

- EXP Dice cell now reads `{{expDiceDisplay}}` instead of `{{actor.system.totalXP}}`. Tooltip corrected (each attempt costs 1 EXP die; default 1d4, Fast Learner upgrades to 1d6).

---

## Elysium 14.2.1-elysium-0.11.0 — 2026-05-08

Pairs with **Elysium rules module 0.11.0** and **ElysiumCompendium 0.5.3** (unchanged).

The Characteristic Improvement system. See the rules-module CHANGELOG for full design notes and player workflow; this entry covers system-fork code changes.

### Added — schema

- `system.stats.<key>.improve` extended from POW-only to all 7 stats (`str`, `con`, `int`, `siz`, `pow`, `dex`, `cha`).
- `system.stats.<key>.failCounter` (integer, default 0) on all 7 stats — counts consecutive failed improvement rolls; auto-improve triggers at 10.
- `system.stats.<key>.capOverride` (boolean, default false) on all 7 stats — set on GM approval to push past cap, cleared on improvement.
- `system.actionPoints.mod` (integer, default 0) — proactive AP bonus surfaced on the CHAR tab.
- `system.actionPoints.reactMod` (integer, default 0) — reactive AP bonus surfaced on the CHAR tab.

### Added — sheet

- `module/actor/sheets/base-actor-sheet.mjs`:
  - `statImproveToggle` action (registered) + `_onStatImproveToggle` handler. Click routes to `markForImprovement`; Shift+Click routes to `rollImprovement`. Both calls go through `game.modules.get('elysium').api.statImprovement`.
  - `rollAllImprovements` action (registered) + `_onRollAllImprovements` handler — calls `rollAllMarkedImprovements`.
- `module/actor/sheets/character.mjs` — `context.ancestryColumnLabel` exposed to the statistics tab template; reads from the rules-module `ancestryLabel` setting (Culture / Ancestry / Race / Species → Cultural / Ancestry / Race / Species column header).

### Changed — templates

- `templates/actor/character.header.hbs` — POW-only improve checkbox replaced with a per-stat checkbox loop. Each stat row gets its own `.elysium-stat-improve-toggle` anchor with `data-action="statImproveToggle"` and `data-stat-key="<key>"`. Tooltip explains click vs Shift+Click and the at-cap GM-approval behaviour.
- `templates/actor/character.statistics.hbs` — full restructure:
  - Columns reduced from 10 to 8: Name · Initial · Ancestry · Experience · Effects · Total · Fail Cnt · (spacer).
  - Redistribute, Age, and Dice columns removed.
  - Cultural column header now uses `{{ancestryColumnLabel}}` (driven by setting).
  - Experience column shows `stat.exp` read-only (count of +1s applied).
  - Fail Cnt column shows `stat.failCounter` with an amber tint (`.elysium-fail-cnt-active`) when non-zero.
  - Bottom block restructured: HP/PP/Proactive AP/Reactive AP bonuses (input fields), Total ENC, Fatigue Bonus (when fatigue is enabled), EXP Dice. Personal Skill Points, Professional Skill Points, Total XP, and Luck Points display removed.

### Notes

- Fresh world recommended. No migration code; new schema fields have safe defaults.
- The legacy POW improvement icon-button row in `character.dev.hbs` is unchanged; it's redundant with the headline panel for POW now but cleaning that up would shift the dev-tab layout — deferred to a polish release.

---

## Elysium 14.2.1-elysium-0.10.0 — 2026-05-07

Pairs with **Elysium rules module 0.10.0** and **ElysiumCompendium 0.5.0**.

The Arcane Manipulation Redesign. See the rules-module CHANGELOG for full design notes; this entry covers system-fork code changes.

### Added

- `module/casting/manipulation-dialog.mjs` — ApplicationV2 dialog for per-cast parameter bending and PP commitment. Reusable for the custom-spell builder via `options.custom = true`.
- `module/casting/sustain.mjs` — sustained spells subsystem (`addSustain`, `removeSustain`, `runSustainUpkeep`, `disruptSustain`).
- `module/casting/spell-learning.mjs` — `learnArcaneSpell` API (school-skill roll → add to actor on success).
- `templates/casting/manipulation-dialog.hbs` — dialog template.
- Manipulation cost helpers in `cast-shared.mjs`: `MANIPULATION_BASE_COST`, `manipulationDiscount`, `manipulationCost`, `summariseManipulation`. Unit-tested at module scope.
- `getArcaneFormsTechniquesFromCompendium` in `cast-shared.mjs` — reads the passions pack and returns `{ forms, techniques }` for spell-sheet dropdowns; cached after first call.

### Changed — `arcane` item template (`template.json`)

- `baseMP` → `basePP` (Mana renamed to Power Points)
- Added: `baseline { range, duration, magnitude, targets, area }`, `validSchools[]`, `isReactive`, `isSustained`

### Changed — `arcane-cast.mjs` pipeline

Restructured around the new flow:

1. Open manipulation dialog before any rolls. Cancel returns immediately.
2. Multi-school chooser when `validSchools.length > 1`.
3. F/T rolls become GM-whispered (`rollMode: 'gmroll'`), failures stashed on active-cast.
4. SL accumulation loop unchanged.
5. Completion path checks stashed F/T failures; on any failure, rolls wild magic table and posts a corrupted-completion card. PP paid in full either way.
6. Reactive spells (`isReactive: true`) bypass the SL loop entirely — single roll, immediate completion or fumble or fail. Routed through `spendAP({ reactiveAllowed: true })`.
7. Sustained spells (`isSustained: true`) register on the actor at completion.

### Changed — `spendAP`

New `{ reactiveAllowed }` option. When true, drains `actionPoints.reactValue` first (reactive-only pool can ONLY pay for reactions), then falls back to `actionPoints.value`. Default false preserves proactive-spend semantics.

### Changed — `rollD100`

Accepts `{ rollMode: 'gmroll' }`. Skips dice-so-nice animation and whispers a roll-result chat message to GMs only. Used for silent F/T checks.

### Changed — `arcane.detail.hbs` and `arcane.mjs` item sheet

F/T fields render as compendium-sourced multi-select dropdowns (GM edit mode) or read-only tags (player view). `_prepareSubmitData` normalises `forms` and `techniques` to arrays of strings (handles 0/1/N selection cases).

### Changed — `cast-card.hbs`

Added corrupted-completion path (alternate banner, F/T-failure list + wild-magic block, no normal description). Added projected-damage display block. Removed F/T list from the abandoned branch (per new "F/T never reveals on abandon" rule).

### Changed — `templates/actor/character.arcane.hbs`

Added Active Sustained Spells panel with drop-sustain affordance. Renders only when the actor has any active sustains.

### Changed — `base-actor-sheet.mjs`

New `dropSustain` action handler.

### Changed — `init.mjs`

Casting API surface expanded with manipulation, sustain, and spell-learning helpers.

---

## Elysium 14.2.1 — 2026-05-01

Forked from BRP V14.2. Internal system ID kept as `brp` for full backward compatibility with all BRP code, asset paths, and existing worlds.

### Added — Elysium Schema Extensions

#### `system.elysium.*` on items

**Weapons** — Size, Reach, Force (ranged), Damage Type, Special Effects array
**Armor** — Flexibility, Material, Layer Order, Armor HP, Casting Location, Casting Penalty Override
**Hit Locations** — Creature Subtype, Creature Tags, Critical Roll history, Critical Entry data
**Cultures (Ancestries)** — Full ancestry data structure: stat mods, traits, natural armor, languages, subraces, combination rules
**Mutations** — Vision Type, Vision Range, Ability Tier
**Superpowers (super)** — Tier, Max Tier, Prerequisite, Category, Favoured Enemy data, Vision data
**Sorcery** — Essence, Rarity, Confluence flag, Restricted flag, Ability Type, Tier, Skill, Thresholds, Cost
**Magic (Arcane spells)** — School, Techniques, Forms, Base SL, Base MP, Ritual flag, Permanent flag, PP/AP cost
**Power (Divine spells)** — Magic System, Domain, Tier, Reactive flag, Ritual flag, Spell Tags
**Profession** — Tier, Group sizes, Package costs, Magic System Access, Starting Equipment/Abilities/Wealth

#### `system.elysium.*` on actor base
- `luckPoints` — Mythras Luck Points (value/max)
- `fatigue` — Mythras fatigue level + recovery type
- `actionPoints` — AP pool with reaction/attack subpools
- `tempHP` — Temporary hit points
- `expDice` — EXP dice for advancement
- `buildPoints` — BP for character creation
- `skillPoints` — SP for character creation
- `creatureType`, `creatureSubtype`, `creatureTags`
- `languages` — Known languages array
- `statNaturalMax` — Per-stat natural maximum from ancestry
- `patron` — Patron name + standing (Divine)
- `essences` — Awakened essences (Sorcery)
- `schoolMastery` — School proficiency (Arcane)
- `ancestryId` — Current ancestry item ID

### Changed
- Default grid units changed from metres to feet (Elysium uses imperial)
- Manifest URL updated to point at ElysiumBRP repository
- Title displays as "Elysium BRP" in Foundry's system list

### Preserved
- All existing BRP V14.2 code paths unchanged
- All asset paths (`systems/brp/...`) work as before
- Settings namespace `brp` works as before
- Existing BRP V14 worlds continue to function — Elysium fields are additions, not replacements

---

---


## 14.2
- Update BRPID for Journals and Roll Tables  - show work and be visible now.

## 14.1
- This is all the work of RevCivic - thank you for this
- Updated for FoundryVTT Version 14 compatibility
- Replaced all jQuery DOM API usage with native browser DOM APIs (jQuery was removed in FoundryVTT v14)
- Fixed `CONST.CHAT_MESSAGE_OTHER` reference to use `CONST.CHAT_MESSAGE_STYLES.OTHER`
- Removed deprecated `{ async: true }` option from `TextEditor.enrichHTML` calls
- Finalize release workflow and correct version tagging
- Add standard GitHub Actions release workflow for automated Foundry VTT package publishing

## 13.57
- If using Random Armor and not using Hits per LOcation, you can now roll the Random Armor Values from the combat tab (bugfix)

## 13.56
- Migration of Github account

## 13.1.55
- A few more damage categories added to weapons
- Weapons can also do double damage bonus

## 13.1.54
- Special Damage and Disease Damage indicators added to weapons
- GIFs and HTML in spell descriptions etc should now appear in Description to Chat rolls
- A series of NPC options added to Base Stats sheet
- Removed gap between NPC sheet and notes
- NPCs no longer add weapon skills when adding a weapon (since they don't use them)
- NPC weapons now have a "Special" damage column added - a red burst indicates special weapon type with a tooltip showing what the damages are (e.g. Poison)
- Item images can be changed once again

## 13.1.53
- The system has moved to V2 Application - and the sheets run in Dark Mode as well.
- Context menus have been removed on the character sheet and replaced with key options or additional icons.  Please see the wiki
- Character Sheet Background Tab is renamed to Story.  You can now add multiple sections each with a title and text to edit.  Existing background entries have been migrated.  Thanks to the Call of Cthulhu system.
- Background Name Game Settings have been removed as now replaced with Story tab.
- When Development Phase is turned on then a new tab appears on the character sheet - you make improvement rolls from here
- Setting colours etc in the Display Options override the values in both Light and Dark Mode.
- There are a few tweaks to the NPC sheet as well (Notes have been migrated to a new tab), there is an ALT MOVE option (Move Notes will be deleted in due course), NPC sheet only shows populated sections when locked
- Character Sheet Combat Tab now shows the Damage Bonus type for each weapon and there's a tooltip on "Damage" to show the Special Damage Type
- There is a new game setting for users to decide if they want the Item sheets to open to the Description tab by default.  Users set this according to their preference rather than at a game level.
- Under Optional Game Rules you can now rename Sanity
- Physical Items (Gear, Weapons and Armor) now let you enter a cost value (e.g. 10) if you've turned off Wealth Levels.
- BRPID Editor no longer errors where game language doesn't have a BRPIDKey list - Thank you to FreeRaisor.

## 13.1.52
- Changes to CCI: Open Document (James B)
- Wound sheet no longer auto closes when making edits

## 13.1.51
-  Missing BRPIDs on actors in world shouldn't stop NPCs being imported
-  Active Effects added to wounds
-  Minor change to tlayout of skills tab on character sheet when unlocked - Cat Bonus is now included in total

## 13.1.50
- Additional CCI option, Ambient Light toggle added
- All CCI show/hide options have become show/hide/toggle

## 13.1.49
- Additional Chaosium Canvas Interface options added

## 13.1.48
- French language pack added thanks to Vonv
- A default scene will be created for new worlds (to help with using GM tools) - thanks to James B
- A Dark/Light mode macro has been added (to help with testing) - thanks to James B

## 13.1.47
- Chaosium Canvas Interface Added thanks to James B

## 13.1.46
- Fixed character sheet so the box doesn't cut through CHA when not using EDU
- Added a game option under "Character Options" to opt to use wealth ratings (default) or use a cash value along with a label for it
- There is now a "+" icon on the Character Sheet Sorcery and Magic tabs that will let you add a spell directly to the character sheet

## 13.1.45
-  Spanish Language pack added courtesy of Adrian_Martin(bakali77)

## 13.1.44
- (Hopefully) this is updated for Foundry V13.
- Please note this version does not support Foundry V12 - please stay on BRP v12.1.43 if you haven't moved to Foundry v13
- And please do back up your world before migtation in case you need to roll back
- The system is stil on Application v1 - the move to v2 will happen in due course
- Please report any issues at https://github.com/Genii-Locorum/brp/issues

## 12.1.43
- Active Effects have been added to Weapons, Armor and Gear.  You can read more at https://github.com/Genii-Locorum/brp/wiki/Active-Effects
- Active Effects do work for Unlinked Actors - when Foundry fix the underlying issue we may see duplicate effects until we remove the fix.
- There is now an Active Effects tab on these item sheets - GMs can edit effects, Players can only view the current effects.
- Weapons and Gear must be carried for the effects to apply, Armor must be worn
- There is a limited list of active effects - these can be added to - please let me have your feedback if there are more to be added
- You can add bonuses to skills, magic and psychic abilities by manually adding a customised data path -  see the Wiki for more info on this.
- There is now an "effects" tab on the character sheet which lists the effects and the item they are attached to.  Click on the Source Item name to open the item sheet.
- This is all the hard work of JamesB.  Thank you so much for this.

## 12.1.42
- Error witn Item "HP and PP" labels showing as undefined fixed.
- Damage to the chest now triggers the correct statuses
- There are icons to the left and right of Hit Points, the sword adds a wound, the heart heals a wound.
- For powers (Magic, Sorcery, Superpower etc) the context menu now has the option to send the item description to the chat window.
- When power roles (Magic, Psychic) are made then the description is also shown in the "hidden" section of the roll.  This only applies to Normal rolls at the moment.
- There's a new Combat game setting that let's you have a "Quick Combat" roll.  This is a non-oppossed combat roll that also shows the damage that would be caused for each success level
- There is now a Custom Resource in the "Optional Rules" menu - you can turn it on/off and give it a label.  It will then appear on the actor sheet.  There is no automation added.
- There is now a Fatigue Point modifier on actors.

## 12.1.41
- Slight tweak to roll cards to centre the first line next to the actor image
- A lot more options to adjust the character sheet - https://github.com/Genii-Locorum/brp/wiki/Game-Settings:-Display-Options
- The character sheet logo setting has moved to the Display Options
- The character sheet visual adjustments are a work in progress - please feedback any other changes needed or areas where the expected results aren't working.
- Instead of selecting to use Magic Points rather than Power Points you can now add a name and abbreviation instead of Power Points/PP - see the Optional Game Rules settings
- You can also change the name and abbreviations for Hit Points and Fatigue Points.
- BRP IDs can be automatically added for Items now - see the BRPID game settings (Actor BRPID has moved here from Char Settings)

## 12.1.40
- Roll chat cards updated to increase size of the actor image and the space for the skill, weapon etc name and there is some additional info in the "expandable" section of the card
- There is now a game setting to choose if you want to show XP & POW Improvement Dice Rolls where you have Dice So Nice module activated.  You could see a lot of dice rolled.
- POW improvement rolls no longer increase POW when the roll is failed (oops).
- When dropping professions etc you should no longer get console errors if actor items don't have BRPIDs.
- There's a new game setting, which if activated, autogenerates the BRP ID for new actors based on the name.  Initially the BRPID fingerprint icon will be orange to warn you.
- Special Weapon Damages are now being applied properly
- Game Settings have been reorganised (the list was getting too long) in to several sub-forms - click on the relevant button to open the subform
- There is a new advances skill category calculation - Negative Secondary - like Secondary but for stat values less than 10
- Where you've added a different label to a Power in game settings this also applies to the list on the relevant character sheet tab and the item sheet.
- Under BRP Game Settings > Display Options there is now two Colour settings to change the main background and secondary background colours on the actor sheet.  Enter a colour reference such as rgba(0,141,142) or #008080.
  These are sort of a test to see if it's what people want.  I will expand the list if it is.

## 12.1.39
- Personal Skill Points are now totalled on the Skills tab, in unlocked mode, under the correct column
- MOVE score added to culture item and added to character sheet along with the culture
- On the character sheet there is now an option under the Skills tab context menu to toggle how the skills are displayed
- When adding a profession to the character you now choose the wealth level.  This can be edited when the character sheet is unlocked.
- On the "CHAR" tab the Redistribute values are no longer manually entered.  When in "Development Mode" and with the character sheet unlocked use the arrows by the
  stats to redistribute stats.  You can only redistribute 3 points and there are min/maxes in place.  Unless the redistributed points net to nil the column is red
- Age has been added to the character sheet neer the top left of the Personal Section
- Clicking on the "Impact" of a Magic Spell or a Psychic Ability on the actor sheet causes an Impact (Damage or Healing) dice roll
- When adding a skill, profession, personality etc the system will check if you have the Skill Category on the character and if not it will add it automatically
- There are two game settings for the initiative formula - select a stat (or none) and enter a modifier.  If your formula is invalid you will get an error message when your world starts and the default formula is used


## 12.1.38
- Context menu for Psychic Abilities now shows XP improvement options when there is an improvement tick and development mode is on
- All improvement checks exclude the item.system.effects score
- Psychic Ability item sheet, when owned, now shows the Improvement button which can be toggled on and off
- Personality Traits now have a "Starter Trait" toggle.
- There is a new game setting "Starter Traits".  If turned on then any new character will, if Personality Traits are used, automatically start with
  any trait which has the "Starter Trait" toggle activated.

## 12.1.37
- Fixed issue with "easy" rolls incorrectly getting XP checks
- Only characters can get XP checks (not NPCs) - this was throwing an error in the console for weapons
- Chat card for skills rolls etc now show the correct actor image where wildcard tokens are used.


## 12.1.36
- The autoXP game setting has changed from a tick box to a drop down selection - None (not auto XP), Any Success (tick XP for success, special success of critical) or On Fail/Fumble.
  Please re-check your setting following world migration, as they are likely to have reset to "none".

## 12.1.35
- Culture now has the correct title on the item sheet
- Failings on the character sheet now display the failing name if the short description is blank
- Where the system can't find a skill category in dice rolls then the Cat Bonus now correctly sets to nil
- There are now game settings to allow you to change the titles of the "power" tabs on the character sheet.  Leave them blank to use the defaults
- You can now click on the skill category in the character sheet skill tab to open up the Skill Category item
- In the skill category, when on a character, you can enter a "manual" modifier that is added to the calculated bonus

## 12.1.34
- Layout of Items on characters now fixed to a consistent grid size
- Culture has been added as an Item.  You can set the characteristic dice rolls and culture bonuses, plus skills with skill modifiers.
- Adding a culture to a character adds the characterstic formulae, bonuses, skills with modifiers.
- When in development mode and with the character sheet unlocked there is a dice icon on the "CHAR" tab that lets you roll the dice - with a chat message showing the results.
- When you have added a culture the name is shown on the character sheet and there's a context menu to view or delete the culture.
- If you don't drop a culture item on the character you can manually enter a culture name
- You can also manually enter/edit the dice rolls for characteristics if development mode is on and the character sheet is unlocked.
- You can now edit (and keep the changes) to weapon ammo and hitpoints on the NPC sheet
- Specialised skills now show under a common "main skill" heading on the actor sheet (so all Languages appear under "Language")
- A macro has been included in BRP ID Macros compendium to rename all actor and game world specialised skills

## 12.1.33
- When dropping a Specialism skill on to the character sheet where the specialism hasn't been chosen you will get asked for the specialism name
- When the character sheet is unlocked the Skills Tab context menu now includes a "Recalculate skill base scores" which does exactly that.
- When dropping Personality on to a character - the skills included in the personality are added to the character - with relevant choices presented to the player and base scores calculated.
- The same applies for a Profession
- Skills added via the Personality gain the +20 bonus and are highlighted in the Skill Dev tab (Skill tab when character sheet unlocked), though you can edit the Personality Points on any skill
- Skills added via the Profession are highlighted in the Skill Dev tab, though the system doesn't restrict you to spending Professional Skill Points on just these skill
- NPCs now have a Power Modifier option on the Base Stats tab
- NPCs now have a 'Move Notes" entry on the base stats tab for a longer description of their movement.  This appears as a tooltip on the main NPC sheet
- GMs should now be able to drag all items from the Characters and NPCs to the items menu or compendia
- The skill category on the Skill Item Sheet should now display properly for players (it was fine for GMs)

## 12.1.32
- Fixed issue with the Sorcery Spell sheet nullifying levels when opened by a player
- Fixed issue with Psychic abilities not being able to access Description/GM Notes
- Added 'Crush and Knockabck' as a special damage type.  This and 'Impale and Knockback' now do the relevant special damage.
- Most Item names can now be edited by players since the name is less critical with the intro of BRPIDs.  This doesnt include Hit Location, Skill Category and Wound
- When creating a new character only adds new skills and skill categories if not already on the sheet (was a problem with duplicating characters)
- You can now drop NPCs from the compendium to the canvas.  If the NPC already exists in the game actors (where BRPID and Priority match) then you won't get an additional copy created in game
- For characteristic rolls there are now two new difficulty levels - Tricky and Awkward for STAT * 4 and STAT * 3 respectively.  Difficulty levels now show the multiplier.


## 12.1.31
- BRP IDs have been added to the game - see the Github Wiki for more information - https://github.com/Genii-Locorum/brp/wiki/BRP-IDs.  This is a major change so please BACKUP YOUR WORLDS before implementing this.
- A number of macros have been included to help with migration - more info at https://github.com/Genii-Locorum/brp/wiki/Migrating-to-BRP-IDs
- You no longer need to bring comepndium items in to the game items and can drag items etc straight from the compendia
- The list of weapon types (and some other checks) are no longer generated from just in world game items, but pull a list from game items and compendia based on BRPIDs.  You will still need some combat skills etc before you create weapons but they can be in the compendia rather than in world
- Under skills there is a new toggle option "Combat Skill" - if toggled on then the skill is included in the list of weapon types.  You don't need to toggle this on if the Category is set to Combat as these are automatically included.  This removes some hard coding to include Dodge, Throw and Demolitions.  It means you can also include other skills you create or rename those skills.
- Most compendia have been removed from this system but have been placed in to a separate module - the aim is to make customising your world easier (you can use the new module, import the content, remove the module, edit the content and save your own compendia)
- Instructions have been removed from within the game but have migrated to the Github Wiki - https://github.com/Genii-Locorum/brp/wiki
- For Personality, you can now manually enter the personality name when the character sheet is unlocked if you don't have a Personality Item on the character sheet - if you later add a Personality item it supercedes (but doesnt erase) the manual entry.  If you right click the "personality" title and there is no context menu this shows you don't have a relevant item.  The same applies to Profession.
- When skills or powers are shown on Personality, Profession etc either in the main list or optional groups you can now click on the name to open the relevant Item sheet.  These will be the best match based on the BRPID with the highest priority as the actual skill etc is not stored in the Personality, Profession etc.  This means you can ammend a skill etc without having to relink it to the Personality etc
-Hit Locations (the item) now have a Display Name (e.g. Head) and a Creature Type (e.g. Humanoid).  The item name will be a combination of the two with the Creature Type, if populated, appearing in brackets.  The Display Name is what's shown on the Character & NPC sheets.  This is to make finding the right hit location for a creature easier in a big list of hit locations
-Skill Categories have been added as a new Item.  You can change the name and configure how the category modifiers are calculated.  The BRPID for each modifier in world or the compendium is used to generate the list of possible skill categories.  Skill categories are automatically added to new characters.  It is imperative that you either have a skill category with the BRPID 'i.skillcat.combat' or you flag all the weapon skills as combat skills.  If you don't you won't see a list of weapon skills.
- Because of the above the game settings for Social and Supernatural have been removed (include or don't include the relevant game items as you see fit.)
- For NPCs you can now enter Max HP formula (as two stats, a multiple and a modifier) on the Base Stats Tab and the calculation formula is then displayed.  It defaults to CON, SIZ, 0.5 & 0
- When dropping unlinked NPC actors to a scene you can get the Random or Average stats to be autorolled for you - you may get asked depending on the game settings - there's a new one to choose Ask, Do nothing, use Random stats or Average Stats.
- In game settings you can also choose whether to show NPC names on tokens as defaults. You can also do the same for Resource Bars

## 12.1.29
- Added a Description section to NPCs for extended notes.
- You now access NPC stats and base stats (dice to roll) via separate icons rather than toggling one
- There is a new GM tool - Bestiary Mode.  When toggled on you will see more HPL and Armor & SAN Loss sections on the NPC sheet even if your game doesn't use them.  This mode is aimed at creating a Bestiary for distribution to other users who may use game settings that you don't.
- SAN Loss has been added to NPC sheets
- Fixed a bug with NPC hit points on HPL not recording properly.

## 12.1.28
- Fixed Combat rolls not correctly reducing success level.

## 12.1.27
- HP on weapons on NPC sheet are now saved
- NPC Fatigue Points Max are autocalculated
- When rolling or averaging stats for an NPC the Current HP, PP, FP and SP are set to maximum values

## 12.1.26
- A Special Success Damage Roll for a Crushing Weapon now adds +1D4 Damage Bonus if the base Damage Bonus = 0
- Macros can now be dragged between hotbar slots and from the Macro Directory
- When rolling damage the rolled dice are now visible if you expand the chat message
- Combat cards can now be resolved with only 1 roll in them
- Combat rolls now tick relevant XP skills when successfully made and relevant game setting is on
- Hit Locations now check they are not already on the character sheet before they can be dropped
- Armor - previously if the Ballistic Armor values were left blank, then the non-ballistics armor value was assumed to be used.  This no longer happens - you will need to update the Ballistic Armor values in each piece of armor
- If using Hits Per Location, Armor on the Items tab is grouped by Hit Location with a summary of the location.  Clicking on the expand icon (on the right) hides the specific hit location but shows the relevant armor items.  Clicking on the collapse icon hides the armor items and reveals the hit location.  Clicking on the title "ARMOR" expands all hit locations whilst SHIFT + CLICK collapses them all.

## 12.1.25
- Added a game setting for "Reputation" - choose from None (reputation not used), single (single reputation item allowed) or multiple (multiple reputation items allowed).  NPCs will always use the mutliple option.
- Reputation item can be dragged to macro bar
- New tab on character sheet "SOCIAL" that combines Reputation and Allegiance Items.  Visible if either is allowed in game
- New tab on character sheet "PERS" (Personality) that combines Passion and Personality Traits. Visible if either is allowed in game
- There are now "+" icons on the Armor and Weapons grids on the character sheet to directly add Armor and Weapons to the character sheet.
- Please note that Instructions for new items are being added to the Github wiki (https://github.com/Genii-Locorum/brp/wiki) - overtime more instructions will be added to, and ingame instructions migrated to, the wiki.

## 12.1.24
- Removed the superfluous true/false flag on the Character Sheet Allegiance tab (this was for potenital ally status)
- Fixed the inline edit for NPC Allegiance points
- Total Professional Skill Points, Personal Skill Points and XP now shown on the "CHAR" tab (this adds up totals from Skill, Magic and Psychic items)
- Fixed error with Critical Damage not rolling

## 12.1.23
- Skill categories on the actor sheet get to use the full width of the skill list column to prevent wrap around issues
- Add Supernatural as a skill category and a game setting.  If unticked then any skills with Supernatural won't be shown on the character sheet
- Add Social as a skill category and a game setting.  If unticked then any skills with Social won't be shown on the character sheet
- Personality Traits have been added.  You can roll on the Personality Trait or the Opposed Trait and do XP improvements as well.
- You can drag Personality Traits to the hotbar for a macro.  Using the ALT key when clicking on it triggers the Opposed roll.
- Added macro roll functionality for Passions (previously only displayed the item sheet).
- All item Descriptions and GM Descriptions are now rich text.
- Background, backstory and biography are now rich text.
- NPC sheets now have Passions, Allegiance and Personality Traits.  Unless you have an item on the NPC or the sheet is unlocked you won't see the sections (to save space) - you can drag and drop an item on and it will appear.  This has been added for Powers as well.

## 12.1.22
- Change to manifest URL to correct it

## 12.1.21
- Fix to NPC sheet to allow in line edit of #ATT on weapons ((it was failing to make the update after a new value was entered))
- Tooltip added on NPC sheet explaining BAP

## 12.1.20
- Added option to adjust maximum magic points to character (on the CHAR tab)
- Gear, Weapons and Armor can now have stored magic/power points.  Enter them on the item sheet (default is zero).  The current value can be edited directly on the character sheet.
- If you hover over Power/Magic points then a tool tip shows current and maximum stored power points.  If an item is "stored" then it is not included
- A few tweaks to the character sheet Combat/Item tab with font size to accomodate the Stored PP/MP.  These are only shown if the Max is set to 1 or more.

## 12.1.19
- Added Dodge to list of weapon skills available when creating weapon.  Added Dodge as a weapon to the compendium.  Use this to "Dodge" in combat (this is a a workaround pending a better option)

## 12.1.18
- Fixed issue with Combined/Oppossed/Cooperative rolls in V11 (Issue#16)
- Fixed issue with AudioHelper error on XP rolls.

## 12.1.17
- Fixed issue with Wounds not being created if not using HPL on actors (worked for tokens)

## 12.1.16
- Updated for V12 release 324

## 11.1.15
- Added NPC actor type
- Added a game settings for Allegiances
- Added Allegiance item, and an allegiance roll (normal roll only)
- Allegiance Improvement has an XP check like skills and magic
- Added a game settings for Passions
- Added Passion item, and a passion roll (normal and opposed)
- Passion Improvement has an XP check like skills and magic
- Fixed issue with not being able to add Wounds to an unlinked token (and couldn't roll XP checks either)
- Can open mutation, psychic, sorcery and superpower item sheets on Character sheet by clicking on the names

## 11.1.14
- Added combat rolls from weapons on the hotbar
- Tidied up some of the chat message outputs
- Can cast Magic spells - click on the spell total score

## 11.1.13
- Tweaked context menus so they go up if the start point is in the bottom half of the screen
- Roll cards fixed so the correct roll is deleted rather than always the first roll
- Dice rolls now visible on opposed, cooperative and combined rolls when using Dice so Nice when roll is resolved
- Updated roll chat messages to add extra info when expanding the roll (GM or owner can click on the indidividual result lines)

## 11.1.12
- Hotfix to reinsert code to calculate stats total

## 11.1.11
- Context menus should now render upwards if they would drop off the bottom of the screen
- Skills will roll from the macro bar (you can roll weapon skills from the Skills tab, but not weapons from the items tab - yet)
- Skill tab percentages now include the category bonus
- ENC now calculated (shown on Characteristics tab).  FP adjusted an
- "Carry status" is now shown as icon rather than words (the words are available as a tooltip)
- Auto calc of Encumberance (Items, Armor Weapons) which in turn updates the Max Fatigue Points
- Changed the combat tab.  Rate of Fire is now visible by hovering over "Attack".  Added ENC (hover to see quantity).
- Fatigue and Power point spend and recovery added
- Added error check on dropping Weapon on character sheet to make sure a Skill has been added to the weapon if first skill slot
- Added an game setting  to change the logo at the top centre of the character sheet.  58px height and 700px wide max.
- Added a setting in Skills for "Starter Skills".  Any skill flagged as a starter skill we be automatically added to a new character sheet
  if the relevant game setting is on (this may get added in time)

## 11.1.10
- Removed a testing element left in (oops) that forced max dice roll values
- Added context menu options for weapon skill and damage rolls

## 11.1.9
- Added GM Tools to the scene tools and a Development Phase
- Added XP improvement checks, only available when Development Phase is turned on by the GM.  Applies to Normal Skill, Combined, Oppossed and POW v POW rolls.
- Added POW improvement roll, only available when Dev Phase is turned on
- Option to turn on "auto XP" checks when succesfully using a skill
- Cooperative skill rolls added
- Can roll weapon damage from items in the Combat tab (unless damage is "Special")
- Can roll weapon attacks from skill% in items in the Combat tab
- Updated partial success rolls for Combined rolls

## 11.1.8
- Added Socket functionality (pre-cursor to combined/opposed rolls)
- Combined and Opposed skill rolls added
- Skills now roll off the values not the name (context menus are off the name).  Clicking on the name opens the skill item sheet
- Some changes to skills and weapons (additional skills added - Lasso, Net, Thrown Axe) and which weapons use which skills changed
  based on discussions with author.  Rates of Fire also added to advanced missile weapons

## 11.1.7
- Added wound/hit point statuses, minor and major wounds
- Update hit locations for wound statuses
- Characteristics now roll off the value not the name (context menus are off the name)

## 11.1.6
- Minor change to natural healing
- Added a "general" hit location when new character is created and the game is using HPL to hold poison damage etc
- Moved Damage Bonus to show correctly in the derived stats area rather than the Combat Tab
- Characteristic Rolls added along with instructions
- Game settings added for Impossible rolls, Resistance rolls always having a 1% success/fail and detailed Resistance Roll results
- Specialised skills, where "specialism chosen" is toggled on will now have the specialism name shown first so it is more visible in the skill list

## 11.1.5
- Hits per location autocalculated
- Added Wounds which autoupdate hits (total and HPL)
- Added healing (treat wounds, natural healing, heal all wounds)
- Add HP adjustment to hit locations

## 11.1.4
- Updated item drop so base skill scores are automatically calculated
- Autocalc for Max HP, PP & FP added
- Added a Game Setting to allow characters to have enhanced HP
- Added a flat modifier to characters on Characteristics tab to increase HP (driven by superpowers)

## 11.1.3
- Corrected error in character.mjs pointing to wrong sheet in some operating systems.

## 11.1.2
- Corrected error in actor-itemDrop for adding skills to character sheet when a weapon is dropped (refencing skill1 instead of skill2)
- Added note in readme reminding users to "Keep Document ID" on importing from Compendia

## 11.1.1
- Initial Beta Release
