export function listen() {
  Hooks.on('renderNoteConfig', async (application, element, context, options) => {
    // v1.1.0-c1 (BRP→Elysium identity rename, Category D): two pre-existing
    // residues are fixed together:
    //   1. The `flags.brp.hide-background` namespace is migrated to
    //      `flags.elysium.hide-background`. Direct property access continues
    //      (bypasses the validator), and the form input writes via
    //      Document#update with the new path.
    //   2. The `BRP.mapNoteNoBackground` localize call was a latent bug —
    //      no `BRP.*` lang namespace exists (P4 merged it into `Elysium.*`),
    //      so the call returned the raw key string as fallback. The key
    //      already lives at `Elysium.mapNoteNoBackground` in all 3 locales;
    //      the call is updated to match. Users were seeing literal
    //      "BRP.mapNoteNoBackground" as the label text before this fix.
    // Per the v1.0.0 no-backcompat policy, users with the legacy flag set
    // on map pins need to re-toggle once.
    const hideBackground = application.document.flags?.elysium?.['hide-background'] ?? false
    const formGroup = element.querySelector('[name=texture\\.tint]').closest('div.form-group')
    const newGroup = document.createElement('div')
    newGroup.classList.add('form-group')
    formGroup.after(newGroup)
    const label = document.createElement('label')
    label.setAttribute('for', application.id + '-hide-background')
    label.innerText = game.i18n.localize('Elysium.mapNoteNoBackground')
    const div = document.createElement('div')
    div.classList.add('form-fields')
    const input = document.createElement('input')
    input.type = 'checkbox'
    input.name = 'flags.elysium.hide-background'
    input.checked = hideBackground
    input.id = application.id + '-hide-background'
    div.append(input)
    newGroup.append(label)
    newGroup.append(div)
    formGroup.after(newGroup)
    application.document?.object?.draw()
  })
}
