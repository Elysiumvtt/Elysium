/**
 * Elysium Sheet Extension — dispatcher
 *
 * Integrates Elysium UI into the BRP-base V14 character sheet at the
 * proper structural locations rather than as loose floating panels:
 *
 *   - Header resources row: Action Points alongside HP / PP / Fatigue
 *   - CHAR tab statistics grid: Healing Rate, Luck Points, EXP Dice,
 *     Fatigue level, Casting Penalty
 *   - Combat tab healing section: Healing Rate alongside healing actions
 *   - Item sheets: Weapon Size/Reach/Force, Armor flexibility/material,
 *     Ancestry data fields
 *
 * Approach: hook renderActorSheetV2 / renderItemSheetV2, find the relevant
 * existing structural elements (.resources, .personal-stats-grid, etc.)
 * and inject our additions. Do not modify the BRP-base system templates.
 *
 * v0.21.0 restructure: this file used to be a 2370-line class with 41
 * static methods. Each method has been extracted into a focused module
 * under sheets/actor/ or sheets/item/. The class kept here is just the
 * entry-point dispatcher — it imports the extracted functions and calls
 * them in the same order with the same try/catch wrapping that the
 * original file used.
 */

import { getSetting } from '../settings/register-settings.mjs'

// Actor-sheet injections — one per tab/concern
import { injectAPIntoResources, makeHPEditable }              from './actor/header.mjs'
import { extendStatisticsTab }                                 from './actor/char-tab.mjs'
import {
  injectHealingRateIntoCombatTab,
  injectWoundTiersIntoCombatTab,
  injectLocationConditionsOnCombatTab,
  injectConditionsPanel,
  injectEngagementBadgesOnCombatTab,
  injectCoveringStanceTogglesOnCombatTab,
  injectCoveringStanceBadgesOnLocations,
}                                                              from './actor/combat-tab.mjs'
import { injectContainerNesting }                              from './actor/items-tab.mjs'
import { injectItemModifiersIntoEffectsTab }                   from './actor/effects-tab.mjs'
import { wireSkillSectionCollapsing }                          from './actor/skills-tab.mjs'
import { wireEvents }                                          from './actor/events.mjs'

// Item-sheet injections — one per item type / concern
import { injectWeaponFields }    from './item/weapon-fields.mjs'
import { injectArmorFields }     from './item/armor-fields.mjs'
import { injectGearFields }      from './item/gear-fields.mjs'
import { injectAncestryFields }  from './item/ancestry-fields.mjs'
import { injectThemedAbilityFields } from './item/themed-ability.mjs'
import { injectStoredInSelector } from './item/stored-in.mjs'

export class ElysiumSheetExtension {

  /**
   * Called on every actor sheet render.
   *
   * Each injection is independent — if one fails, the others should still
   * run. We wrap each in a try/catch with a console.error so a single bad
   * injection can't break the entire sheet. Failures are logged with a
   * stable tag (`Elysium | <step>`) so they're easy to spot.
   */
  static async extendActorSheet (app, html, data) {
    const actor = app.actor
    if (!actor) return

    // Only extend BRP-base character sheet (not NPC, not other modules)
    if (!app.constructor.name.includes('Character')) return

    const steps = [
      // Header resources row — add Action Points alongside HP / PP / Fatigue
      ['injectAPIntoResources',           () => injectAPIntoResources(html, actor)],

      // Convert the HP value/max divs into editable inputs so users can
      // set Temp HP directly. BRP-base renders these as read-only divs because
      // its native HP is fully derived; under Elysium the panel represents
      // Temp HP, so direct editing is the natural UX.
      ['makeHPEditable',                  () => makeHPEditable(html, actor)],

      // CHAR tab — repurpose Total XP, add Healing Rate, Luck Points,
      // Fatigue level, Casting Penalty
      ['extendStatisticsTab',             () => extendStatisticsTab(html, actor)],

      // Combat tab — Healing Rate (gated on Mythras-rate setting)
      ['injectHealingRateIntoCombatTab',  () => {
        if (getSetting('enableMythrasHealingRate', true)) {
          injectHealingRateIntoCombatTab(html, actor)
        }
      }],

      // Combat tab — wound-tier badges on each hit-location row
      ['injectWoundTiersIntoCombatTab',   () => injectWoundTiersIntoCombatTab(html, actor)],

      // Combat tab — per-location condition icons (Bleeding, Burning, etc.)
      ['injectLocationConditionsOnCombatTab', () => injectLocationConditionsOnCombatTab(html, actor)],

      // Combat tab — active conditions panel below hit-locations
      ['injectConditionsPanel',           () => injectConditionsPanel(html, actor)],

      // Items tab — visually nest contained items under their container
      ['injectContainerNesting',          () => injectContainerNesting(html, actor)],

      // EFF tab — item-modifier AEs grouped by source item
      ['injectItemModifiersIntoEffectsTab', () => injectItemModifiersIntoEffectsTab(html, actor)],

      // Combat tab — engagement badges on each weapon row
      ['injectEngagementBadgesOnCombatTab', () => injectEngagementBadgesOnCombatTab(html, actor)],

      // Combat tab — covering-stance toggle on each equipped weapon row
      // (handles both passive-block and ward via stance-type selector)
      ['injectCoveringStanceTogglesOnCombatTab', () => injectCoveringStanceTogglesOnCombatTab(html, actor)],

      // Combat tab — covering-stance coverage badges on hit-location rows
      // (renders both passive-block AP and ward Size badges)
      ['injectCoveringStanceBadgesOnLocations', () => injectCoveringStanceBadgesOnLocations(html, actor)],

      // SKILLS tab — section/subsection collapsibility wiring
      ['wireSkillSectionCollapsing',      () => wireSkillSectionCollapsing(html, actor)],

      // Click handlers for our added elements (must run last so handlers
      // attach to elements created by the injections above).
      ['wireEvents',                      () => wireEvents(app, html, actor)],
    ]

    for (const [stepName, fn] of steps) {
      try {
        await fn()
      } catch (err) {
        console.error(`Elysium | extendActorSheet step "${stepName}" failed:`, err)
      }
    }
  }

  /**
   * Called on every item sheet render. Same defensive pattern as
   * extendActorSheet — each injection independent.
   */
  static async extendItemSheet (app, html, data) {
    const item = app.item
    if (!item) return

    const steps = []

    if (item.type === 'weapon')  steps.push(['injectWeaponFields',  () => injectWeaponFields(html, item)])
    if (item.type === 'armor')   steps.push(['injectArmorFields',   () => injectArmorFields(html, item)])
    if (item.type === 'gear')    steps.push(['injectGearFields',    () => injectGearFields(html, item)])
    if (item.type === 'culture') steps.push(['injectAncestryFields',() => injectAncestryFields(html, item)])

    // Themed-bundle abilities (Rage, Combat Stances, Aura, etc.) and
    // mysticism items (v0.13.0+) carry the same activation/benefits/
    // drawbacks/addOns bundle schema.
    if (item.type === 'ability' || item.type === 'mysticism') {
      steps.push(['injectThemedAbilityFields', () => injectThemedAbilityFields(html, item)])
    }

    // For all carryable item types on an actor, offer a "Stored In" selector
    // that lets the user pick a container gear item to put this one inside.
    if (['weapon', 'armor', 'gear'].includes(item.type)) {
      steps.push(['injectStoredInSelector', () => injectStoredInSelector(html, item)])
    }

    for (const [stepName, fn] of steps) {
      try {
        await fn()
      } catch (err) {
        console.error(`Elysium | extendItemSheet step "${stepName}" failed:`, err)
      }
    }
  }
}
