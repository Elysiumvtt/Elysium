/**
 * Elysium Rules — Settings registration
 * 
 * All settings live under the 'elysium' namespace to keep
 * fully separate from BRP's own settings.
 * 
 * Settings categories:
 *   - Core toggles (which Elysium subsystems are active)
 *   - Combat options (AP system, wounds, criticals)
 *   - Magic options (per-system enable/disable)
 *   - Character creation options
 *   - Display options (terminology, UI)
 *   - Compatibility options (override behaviour)
 */

import { ELYSIUM } from '../config/config.mjs'

const M = ELYSIUM.MODULE_ID

export function registerSettings () {
  // === CORE MODULE TOGGLES =========================================

  game.settings.register(M, 'masterEnable', {
    name:    'Elysium.Settings.masterEnable',
    hint:    'Elysium.Settings.masterEnableHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
    requiresReload: true,
  })

  // === COMBAT OPTIONS ==============================================

  game.settings.register(M, 'enableActionPoints', {
    name:    'Elysium.Settings.enableActionPoints',
    hint:    'Elysium.Settings.enableActionPointsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
    requiresReload: true,
  })

  game.settings.register(M, 'enableWoundThresholds', {
    name:    'Elysium.Settings.enableWoundThresholds',
    hint:    'Elysium.Settings.enableWoundThresholdsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableCriticalTables', {
    name:    'Elysium.Settings.enableCriticalTables',
    hint:    'Elysium.Settings.enableCriticalTablesHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableMythrasFatigue', {
    name:    'Elysium.Settings.enableMythrasFatigue',
    hint:    'Elysium.Settings.enableMythrasFatigueHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableMythrasHealingRate', {
    name:    'Elysium.Settings.enableMythrasHealingRate',
    hint:    'Elysium.Settings.enableMythrasHealingRateHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableSpecialEffects', {
    name:    'Elysium.Settings.enableSpecialEffects',
    hint:    'Elysium.Settings.enableSpecialEffectsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableArmourLayering', {
    name:    'Elysium.Settings.enableArmourLayering',
    hint:    'Elysium.Settings.enableArmourLayeringHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableLuckPoints', {
    name:    'Elysium.Settings.enableLuckPoints',
    hint:    'Elysium.Settings.enableLuckPointsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableShieldPassiveBlocking', {
    name:    'Elysium.Settings.enableShieldPassiveBlocking',
    hint:    'Elysium.Settings.enableShieldPassiveBlockingHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  // === MAGIC SYSTEM TOGGLES ========================================

  game.settings.register(M, 'enableArcane', {
    name:    'Elysium.Settings.enableArcane',
    hint:    'Elysium.Settings.enableArcaneHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableSorcery', {
    name:    'Elysium.Settings.enableSorcery',
    hint:    'Elysium.Settings.enableSorceryHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableDivine', {
    name:    'Elysium.Settings.enableDivine',
    hint:    'Elysium.Settings.enableDivineHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableMysticism', {
    name:    'Elysium.Settings.enableMysticism',
    hint:    'Elysium.Settings.enableMysticismHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableSuperpowers', {
    name:    'Elysium.Settings.enableSuperpowers',
    hint:    'Elysium.Settings.enableSuperpowersHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableArmourCastingPenalty', {
    name:    'Elysium.Settings.enableArmourCastingPenalty',
    hint:    'Elysium.Settings.enableArmourCastingPenaltyHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'enableOvercasting', {
    name:    'Elysium.Settings.enableOvercasting',
    hint:    'Elysium.Settings.enableOvercastingHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  // Magic damage scaling - tunable here without changing config
  game.settings.register(M, 'arcaneDamagePerMP', {
    name:    'Elysium.Settings.arcaneDamagePerMP',
    hint:    'Elysium.Settings.arcaneDamagePerMPHint',
    scope:   'world',
    config:  true,
    type:    Number,
    default: 1,
    range:   { min: 1, max: 5, step: 1 },
  })

  // === ANCESTRY / TERMINOLOGY ======================================

  game.settings.register(M, 'enableAncestrySystem', {
    name:    'Elysium.Settings.enableAncestrySystem',
    hint:    'Elysium.Settings.enableAncestrySystemHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'ancestryLabel', {
    name:    'Elysium.Settings.ancestryLabel',
    hint:    'Elysium.Settings.ancestryLabelHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      'culture':  'Culture (BRP default)',
      'ancestry': 'Ancestry',
      'race':     'Race',
      'species':  'Species',
    },
    default: 'ancestry',
  })

  // === CHARACTER CREATION OPTIONS ==================================

  game.settings.register(M, 'enableCharacterCreation', {
    name:    'Elysium.Settings.enableCharacterCreation',
    hint:    'Elysium.Settings.enableCharacterCreationHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'statRollMethod', {
    name:    'Elysium.Settings.statRollMethod',
    hint:    'Elysium.Settings.statRollMethodHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      '4d6dl':   '4d6 drop lowest (Elysium default)',
      '3d6':     '3d6 (BRP default for STR/CON/DEX/POW/CHA)',
      '2d6+6':   '2d6+6 (BRP default for SIZ/INT)',
      'pointBuy':'Point buy',
    },
    default: '4d6dl',
  })

  game.settings.register(M, 'statNaturalMaxBase', {
    name:    'Elysium.Settings.statNaturalMaxBase',
    hint:    'Elysium.Settings.statNaturalMaxBaseHint',
    scope:   'world',
    config:  true,
    type:    Number,
    default: 20,
    range:   { min: 18, max: 25, step: 1 },
  })

  game.settings.register(M, 'startingSkillCap', {
    name:    'Elysium.Settings.startingSkillCap',
    hint:    'Elysium.Settings.startingSkillCapHint',
    scope:   'world',
    config:  true,
    type:    Number,
    default: 70,
    range:   { min: 50, max: 100, step: 5 },
  })

  // === EXPERIENCE OPTIONS ==========================================

  game.settings.register(M, 'enableExpDiceSystem', {
    name:    'Elysium.Settings.enableExpDiceSystem',
    hint:    'Elysium.Settings.enableExpDiceSystemHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'expFumbleImmediateAdvance', {
    name:    'Elysium.Settings.expFumbleImmediateAdvance',
    hint:    'Elysium.Settings.expFumbleImmediateAdvanceHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'expAdvancementTiming', {
    name:    'Elysium.Settings.expAdvancementTiming',
    hint:    'Elysium.Settings.expAdvancementTimingHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      'endOfSession': 'End of session (default)',
      'downtime':     'Downtime only',
      'immediate':    'Immediate (any time)',
    },
    default: 'endOfSession',
  })

  // === DISPLAY ======================================================

  game.settings.register(M, 'showDifficultyGradeNames', {
    name:    'Elysium.Settings.showDifficultyGradeNames',
    hint:    'Elysium.Settings.showDifficultyGradeNamesHint',
    scope:   'client',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'showFatigueOnSheet', {
    name:    'Elysium.Settings.showFatigueOnSheet',
    hint:    'Elysium.Settings.showFatigueOnSheetHint',
    scope:   'client',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'autoApplyConditions', {
    name:    'Elysium.Settings.autoApplyConditions',
    hint:    'Elysium.Settings.autoApplyConditionsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  // === HIDDEN / WORLD STATE ========================================

  // Stored Per-actor state for things like applied wound conditions
  // can be flagged here. Most are stored on the actor itself.

  game.settings.register(M, 'sessionExpDicePool', {
    name:    '',
    hint:    '',
    scope:   'world',
    config:  false,
    type:    Object,
    default: {},
  })
}

/**
 * Helper: get a setting value with defaults
 */
export function getSetting (key, defaultValue = null) {
  try {
    return game.settings.get(ELYSIUM.MODULE_ID, key)
  } catch (e) {
    return defaultValue
  }
}
