// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'

export function injectHealingRateIntoCombatTab (html, actor) {
    const hr = actor.flags?.['elysium']?.derived?.healingRate
    if (hr === undefined || hr === null) return

    // Find the healing section by localisation match — it's a div.diff-label
    // whose text starts with the localised "Healing" label.
    const healingLabels = html.querySelectorAll('.diff-label')
    let healingDiv = null
    for (const div of healingLabels) {
      const text = div.textContent?.trim().toLowerCase()
      if (text?.startsWith('healing') && !text.includes('rate')) {
        healingDiv = div
        break
      }
    }
    if (!healingDiv) return

    // Avoid double injection
    if (healingDiv.querySelector('.elysium-healing-rate')) return

    // Rest button — decrements fatigue by one level
    if (!healingDiv.querySelector('.elysium-rest-btn')) {
      const restBtn = document.createElement('span')
      restBtn.className = 'centre rollable elysium-rest-btn'
      restBtn.style.paddingLeft = '30px'
      restBtn.dataset.tooltip = game.i18n.localize('Elysium.Fatigue.RestTooltip')
                              || 'Rest — recover one Fatigue level'
      restBtn.innerHTML = `<a class="largeIcon"><i class="fas fa-bed"></i></a>`
      restBtn.addEventListener('click', async (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        if (!game.system.api?.elysium?.fatigue) return
        const before = actor.system?.fatigue?.level ?? 0
        if (before === 0) {
          ui.notifications.info(`${actor.name} is already Fresh.`)
          return
        }
        await game.system.api.elysium.fatigue.decrement(actor, 1)
        const after = actor.system?.fatigue?.level ?? 0
        const restBody = `<p><strong>${actor.name}</strong> rests — Fatigue ${before} → ${after}.</p>`
        const restHtml = await foundry.applications.handlebars.renderTemplate(
          'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
          { variant: 'success', icon: 'bed', body: restBody }
        )
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: restHtml,
        })
      })
      healingDiv.appendChild(restBtn)
    }

    // Healing Rate display
    const span = document.createElement('span')
    span.className = 'elysium-healing-rate'
    span.style.paddingLeft = '30px'
    span.innerHTML = `<strong>${game.i18n.localize('Elysium.HealingRate.Short')}:</strong> ${hr}`
    span.dataset.tooltip = game.i18n.localize('Elysium.HealingRate.Tooltip')
    healingDiv.appendChild(span)
  }

export function injectWoundTiersIntoCombatTab (html, actor) {
    // Each hit-location row is an <li class="item" data-item-id="..." ...>
    // inside the combat tab. Find them and locate each row's status cell.
    const hitlocItems = html.querySelectorAll('li.item[data-item-id]')
    if (!hitlocItems.length) return

    for (const li of hitlocItems) {
      const itemId = li.dataset.itemId
      if (!itemId) continue
      const item = actor.items.get(itemId)
      if (!item || item.type !== 'hit-location') continue

      // Compute tier
      const tier = computeWoundTier(item)
      if (!tier) continue   // Healthy — leave row clean

      // Find the row's hitloc-tab-grid container, then the Status cell.
      // The Status column is the cell that holds the bleeding/incap/etc icons —
      // structurally it's the cell BEFORE the wound-name cell in BRP-base's grid.
      const grid = li.querySelector('.hitloc-tab-grid')
      if (!grid) continue
      const woundCell = grid.querySelector('.wound-name')
      const statusCell = woundCell?.previousElementSibling
      if (!statusCell) continue

      // Avoid double injection
      if (statusCell.querySelector('.elysium-wound-tier')) continue

      const span = document.createElement('span')
      span.className = `elysium-wound-tier elysium-tier-${tier.key}`
      span.textContent = tier.label
      span.dataset.tooltip = tier.tooltip
      statusCell.appendChild(span)
    }
  }

export function computeWoundTier (item) {
    if (item.system?.severed) {
      return {
        key:     'severed',
        label:   game.i18n.localize('Elysium.WoundTier.Severed') || 'Severed',
        tooltip: 'Location severed — permanent loss until magical healing or prosthesis.',
      }
    }
    const max  = item.system?.maxHP || 0
    const curr = item.system?.currHP ?? max
    if (max <= 0) return null

    if (curr === 0) {
      return {
        key:     'critical',
        label:   game.i18n.localize('Elysium.WoundTier.Critical') || 'Critically Wounded',
        tooltip: 'Location is critically wounded — unusable, critical roll triggered.',
      }
    }
    if (curr <= Math.floor(max / 2)) {
      return {
        key:     'severe',
        label:   game.i18n.localize('Elysium.WoundTier.Severe') || 'Severely Wounded',
        tooltip: 'Location is severely wounded — significant impairment.',
      }
    }
    if (curr < max) {
      return {
        key:     'wounded',
        label:   game.i18n.localize('Elysium.WoundTier.Wounded') || 'Wounded',
        tooltip: 'Location has taken damage but is still functional.',
      }
    }
    return null    // Healthy
  }

export function injectLocationConditionsOnCombatTab (html, actor) {
    const factory = game.system.api?.elysium?.activeEffects
    if (!factory) return

    const hitlocItems = html.querySelectorAll('li.item[data-item-id]')
    if (!hitlocItems.length) return

    for (const li of hitlocItems) {
      const itemId = li.dataset.itemId
      const item = actor.items.get(itemId)
      if (!item || item.type !== 'hit-location') continue

      const list = item.system?.elysium?.locationConditions || []
      if (list.length === 0) continue

      const grid = li.querySelector('.hitloc-tab-grid')
      if (!grid) continue
      const woundCell = grid.querySelector('.wound-name')
      const statusCell = woundCell?.previousElementSibling
      if (!statusCell) continue

      // Idempotent: clear any existing condition icons first
      statusCell.querySelectorAll('.elysium-loc-cond-icon-wrap').forEach(el => el.remove())

      const iconRow = document.createElement('span')
      iconRow.className = 'elysium-loc-cond-icons'

      for (const cond of list) {
        const def = factory.getDefinition?.(cond.name)
        if (!def?.locationIcon) continue

        // Wrap in <a> so the click target is reliable across icon FA
        // versions (some FA classes ignore pointer events on the <i>).
        const wrap = document.createElement('a')
        wrap.className = 'elysium-loc-cond-icon-wrap'
        wrap.dataset.elysiumLocId = item.id
        wrap.dataset.elysiumCondName = cond.name
        const amountText = cond.amount ? ` ${cond.amount}` : ''
        wrap.dataset.tooltip =
          `${cond.name}${amountText} — source: ${cond.source || 'manual'}\n` +
          `Ctrl+click to remove`

        const icon = document.createElement('i')
        icon.className = `${def.locationIcon} elysium-loc-cond-icon`
        if (def.iconColor) icon.style.color = def.iconColor
        wrap.appendChild(icon)

        iconRow.appendChild(wrap)
      }

      statusCell.appendChild(iconRow)
    }

    // Wire Ctrl+click handler — delegated on the combat tab so it
    // survives partial re-renders. Only attach once per render of
    // this tab; check via a marker on the tab root.
    const combatTab = html.querySelector('.tab.combat') || html.querySelector('[data-tab="combat"]')
    if (combatTab && !combatTab.dataset.elysiumLocCondHandlerWired) {
      combatTab.dataset.elysiumLocCondHandlerWired = '1'
      combatTab.addEventListener('click', async (ev) => {
        const wrap = ev.target.closest('.elysium-loc-cond-icon-wrap')
        if (!wrap) return
        if (!ev.ctrlKey && !ev.metaKey) return    // require Ctrl (or Cmd on Mac)
        ev.preventDefault()
        ev.stopPropagation()

        const locId    = wrap.dataset.elysiumLocId
        const condName = wrap.dataset.elysiumCondName
        if (!locId || !condName) return

        const removed = await factory.removeLocationCondition(actor, locId, condName)
        if (removed) {
          ui.notifications?.info(`${condName} removed from ${actor.items.get(locId)?.name || 'location'}.`)
        }
      })
    }
  }

export function injectConditionsPanel (html, actor) {
    // Find the COMBAT tab container — class "tab combat" on the BRP-base sheet.
    const combatTab = html.querySelector('.tab.combat') || html.querySelector('[data-tab="combat"]')
    if (!combatTab) return

    // Avoid double-injection on re-render
    if (combatTab.querySelector('.elysium-conditions-panel')) return

    // Actor-level AEs (Stunned, Difficult, Unconscious, Frozen, etc.).
    // Per-location conditions (Bleeding, Burning, etc.) are NOT here —
    // they live on hit-location items as locationConditions entries.
    const aeConditions = actor.effects.contents.filter(e => {
      const group = e.flags?.['elysium']?.group || ''
      return group.startsWith('condition.') ||
             group.startsWith('wound.') ||
             group === 'fatigue'
    })

    // Per-location conditions, aggregated by name across all hit-locations.
    // factory.getLocationConditionsByName returns:
    //   { Bleeding: [{ locationName, locationId, amount, source }], ... }
    const factory = game.system.api?.elysium?.activeEffects
    const perLocation = factory?.getLocationConditionsByName?.(actor) || {}
    const perLocationEntries = Object.entries(perLocation)

    // Synthetic chips: derived effects that aren't AEs but should still
    // appear in the panel for visibility. (Currently empty — kept for
    // future use if needed.)
    const synthetics = []

    const total = aeConditions.length + perLocationEntries.length + synthetics.length

    // Always render the panel header so users know where to look,
    // even if there are no conditions yet.
    const panel = document.createElement('div')
    panel.className = 'elysium-conditions-panel'

    const title = game.i18n.localize('Elysium.Conditions.PanelTitle') || 'Active Conditions'
    const empty = game.i18n.localize('Elysium.Conditions.None') || 'No active conditions.'

    if (total === 0) {
      panel.innerHTML = `
        <div class="elysium-conditions-header">${title}</div>
        <div class="elysium-conditions-empty">${empty}</div>
      `
    } else {
      const aeChips = aeConditions.map(ae => renderConditionChip(ae)).join('')
      const locChips = perLocationEntries.map(([name, occurrences]) =>
        renderLocationConditionChip(name, occurrences)
      ).join('')
      const synthChips = synthetics.map(s => renderSyntheticChip(s)).join('')
      panel.innerHTML = `
        <div class="elysium-conditions-header">${title}</div>
        <div class="elysium-conditions-list">${aeChips}${locChips}${synthChips}</div>
      `
    }

    combatTab.appendChild(panel)

    // Wire remove buttons (actor-level AE chips are removable;
    // synthetics and per-location aggregates aren't — per-location
    // conditions must be removed from each location individually).
    panel.querySelectorAll('[data-elysium-remove-ae]').forEach(btn => {
      btn.addEventListener('click', async (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        const aeId = btn.dataset.elysiumRemoveAe
        if (!aeId) return
        await actor.deleteEmbeddedDocuments('ActiveEffect', [aeId])
      })
    })
  }

export function renderLocationConditionChip (conditionName, occurrences) {
    const factory = game.system.api?.elysium?.activeEffects
    const def = factory?.getDefinition?.(conditionName) || {}
    const tooltipLines = occurrences.map(o =>
      `${o.locationName}: ${o.amount}${o.source ? ` (${o.source})` : ''}`
    )
    const count = occurrences.length
    const countSuffix = count > 1 ? ` ×${count}` : ''
    // Pull amount of first occurrence for a quick eyeball
    const firstAmount = occurrences[0]?.amount
    const amountSuffix = firstAmount ? ` ${firstAmount}` : ''

    const iconHtml = def.locationIcon
      ? `<i class="${def.locationIcon}" style="${def.iconColor ? `color:${def.iconColor};` : ''}"></i> `
      : ''

    return `
      <span class="elysium-condition-chip elysium-tier-condition elysium-chip-perlocation"
            data-tooltip="${tooltipLines.join('\n')}">
        ${iconHtml}<span class="elysium-condition-name">${conditionName}${amountSuffix}${countSuffix}</span>
      </span>
    `
  }

export function renderConditionChip (ae) {
    const group = ae.flags?.['elysium']?.group || ''
    const tier = group.startsWith('condition.') ? 'condition'
              : group.startsWith('wound.')     ? 'wound'
              : group === 'fatigue'            ? 'fatigue'
              : 'other'

    // Build a tooltip from the AE's changes (best-effort summary).
    const changes = ae.changes || []
    const summary = changes.length > 0
      ? changes.map(c => `${c.key.split('.').pop()}: ${c.value}`).join(', ')
      : ''

    // Duration display
    const dur = ae.duration
    let durText = ''
    if (dur?.rounds && Number.isFinite(dur.rounds))   durText = `${dur.rounds}r`
    else if (dur?.seconds && Number.isFinite(dur.seconds)) durText = `${dur.seconds}s`

    // Build display name. For ongoing-damage AEs, append the per-round
    // amount so "Burning" becomes "Burning 2" and "Bleeding" becomes
    // "Bleeding 1". The amount is read directly from the AE's flags —
    // every condition AE (factory-created or migrated) carries the
    // values from CONDITION_DEFINITIONS.
    let displayName = ae.name
    const ongoingDamage = ae.flags?.['elysium']?.ongoingDamage
    const bleedRate     = ae.flags?.['elysium']?.bleedRate
    if (ongoingDamage?.amount) {
      displayName = `${ae.name} ${ongoingDamage.amount}`
    } else if (Number.isFinite(bleedRate) && bleedRate > 0) {
      displayName = `${ae.name} ${bleedRate}`
    }

    return `
      <span class="elysium-condition-chip elysium-tier-${tier}"
            data-tooltip="${summary || ae.name}">
        <span class="elysium-condition-name">${displayName}</span>
        ${durText ? `<span class="elysium-condition-duration">${durText}</span>` : ''}
        <a class="elysium-condition-remove"
           data-elysium-remove-ae="${ae.id}"
           data-tooltip="${game.i18n.localize('Elysium.Conditions.Remove') || 'Remove'}">
          <i class="fas fa-times"></i>
        </a>
      </span>
    `
  }

export function renderSyntheticChip (synth) {
    return `
      <span class="elysium-condition-chip elysium-tier-${synth.tier || 'other'} elysium-chip-synthetic"
            data-tooltip="${synth.tooltip}">
        <span class="elysium-condition-name">${synth.label}</span>
      </span>
    `
  }

export function injectEngagementBadgesOnCombatTab (html, actor) {
    // v0.20.0: pre-merge this read `game.elysium?.engagement` (the rules
    // module's global). Now the engagement module is exposed on the merged
    // system API at `game.system.api.elysium.engagement`. The guard remains
    // because the API is populated late in init — early sheet renders may
    // hit this before the API is ready.
    const engagement = game.system.api?.elysium?.engagement
    if (!engagement) return

    const records = engagement.getActorEngagements(actor)
    if (records.length === 0) return

    // Group engagements by weaponId so we can attach a badge per weapon row
    const byWeapon = new Map()
    for (const rec of records) {
      const wId = rec.engagement.weaponId
      if (!wId) continue
      if (!byWeapon.has(wId)) byWeapon.set(wId, [])
      byWeapon.get(wId).push(rec)
    }
    if (byWeapon.size === 0) return

    const reachLabels = ELYSIUM.WEAPON_REACHES || {}

    for (const [weaponId, recs] of byWeapon.entries()) {
      const weapon = actor.items.get(weaponId)
      if (!weapon) continue

      // Find this weapon's row on the Combat tab. BRP-base renders each weapon
      // with data-item-id set on its container element.
      const row = html.querySelector(
        `.tab.combat [data-item-id="${weaponId}"], ` +
        `[data-tab="combat"] [data-item-id="${weaponId}"]`
      )
      if (!row) continue
      if (row.querySelector('.elysium-eng-badge')) continue   // idempotent

      // Decide the worst state across all engagements of this weapon
      let worstState = 'normal'
      const tooltipLines = []
      for (const { combatant: c, engagement: eng } of recs) {
        const opp = game.combat?.combatants.get(eng.withId)
        const oppName = opp?.name || '?'
        const reachLabel = reachLabels[eng.reach] || eng.reach
        const heldAtBay  = engagement.getHeldAtBaySteps(weapon.system?.elysium?.reach || 'M', eng.reach) > 0
        const encroached = engagement.getEncroachmentSteps(weapon.system?.elysium?.reach || 'M', eng.reach) > 0

        if (heldAtBay) {
          worstState = 'bay'
          tooltipLines.push(`vs ${oppName} @ ${reachLabel}: Held at bay — cannot directly attack`)
        } else if (encroached) {
          if (worstState !== 'bay') worstState = 'encroached'
          const cap = engagement.getMaxDamage(weapon, eng.reach)
          tooltipLines.push(`vs ${oppName} @ ${reachLabel}: Encroached — damage capped at ${cap}`)
        } else {
          if (worstState === 'normal') worstState = 'ok'
          tooltipLines.push(`vs ${oppName} @ ${reachLabel}: Normal engagement`)
        }
      }

      // Pick icon + class
      let icon, cls, label
      if (worstState === 'bay') {
        icon  = 'fa-ban'
        cls   = 'elysium-eng-badge-bay'
        label = 'Held at bay'
      } else if (worstState === 'encroached') {
        icon  = 'fa-triangle-exclamation'
        cls   = 'elysium-eng-badge-encroached'
        label = 'Encroached'
      } else {
        icon  = 'fa-circle-check'
        cls   = 'elysium-eng-badge-ok'
        label = 'Engaged'
      }

      const badge = document.createElement('span')
      badge.className = `elysium-eng-badge ${cls}`
      badge.dataset.tooltip = tooltipLines.join('\n')
      badge.innerHTML = `<i class="fas ${icon}"></i> ${label}`
      badge.dataset.elysiumBadgeWeaponId = weaponId

      // Find the weapon-name cell and append the badge inline.
      // BRP-base's weapon row has the name as the first cell (typically
      // a div with `.weapon-name` or just first text element).
      const nameCell = row.querySelector('.weapon-name') ||
                       row.querySelector('[data-item-id]')?.firstElementChild ||
                       row.firstElementChild
      if (nameCell) {
        nameCell.appendChild(badge)
      } else {
        row.appendChild(badge)
      }

      // Click handler — post a detailed chat warning
      badge.addEventListener('click', (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        postEngagementWarningCard(actor, weapon, recs, worstState)
      })
    }
  }

export function postEngagementWarningCard (actor, weapon, records, worstState) {
    const engagement = game.system.api?.elysium?.engagement
    if (!engagement) return

    const reachLabels = ELYSIUM.WEAPON_REACHES || {}
    const sizeLabels  = ELYSIUM.WEAPON_SIZES   || {}
    const baseSize  = weapon.system?.elysium?.weaponSize || 'M'
    const baseReach = weapon.system?.elysium?.reach || 'M'

    const rows = records.map(({ combatant, engagement: eng }) => {
      const opp = game.combat?.combatants.get(eng.withId)
      const oppName = opp?.name || '?'
      const eReach = eng.reach || 'M'
      const heldAtBay = engagement.getHeldAtBaySteps(baseReach, eReach) > 0
      const encroached = engagement.getEncroachmentSteps(baseReach, eReach) > 0

      let stateHtml
      if (heldAtBay) {
        stateHtml = `<span style="color:#882929;font-weight:600;">Held at bay</span> — your weapon (Reach ${reachLabels[baseReach]}) is too short for engagement at ${reachLabels[eReach]}. Cannot directly attack — only attack the weapon, close range, or use a Special Effect.`
      } else if (encroached) {
        const effSize = engagement.getEffectiveSize(weapon, eReach)
        const cap     = engagement.getMaxDamage(weapon, eReach)
        stateHtml = `<span style="color:#884400;font-weight:600;">Encroached</span> — fighting at ${reachLabels[eReach]} (your weapon is Reach ${reachLabels[baseReach]}). Effective Size: <b>${sizeLabels[effSize]}</b> (was ${sizeLabels[baseSize]}). Damage capped at <b>${cap}</b>.`
      } else {
        stateHtml = `<span style="color:#005500;">Normal engagement</span> at ${reachLabels[eReach]}.`
      }

      return `<li><b>vs ${oppName}</b>: ${stateHtml}</li>`
    }).join('')

    // Per c2 audit D4: edge case — caller-built body has per-row state
    // markup with inline-tinted spans (not retokenable without per-state
    // CSS — flagged as P12-c4 retoken candidate). Outer shell uses partial.
    // Variant maps worstState → token: bay=danger, encroached=fire, normal=info.
    const variant = worstState === 'bay'        ? 'danger'
                  : worstState === 'encroached' ? 'fire'
                  : 'info'
    const body = `<p><em>Mythras Reach engagement state</em></p>
      <ul>${rows}</ul>`

    foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      {
        variant,
        title: `${actor.name} — ${weapon.name}`,
        icon: 'arrows-to-circle',
        body,
      }
    ).then(content => {
      ChatMessage.create({
        content,
        speaker: ChatMessage.getSpeaker({ actor }),
        whisper: game.user.isGM ? [] : [game.user.id],
      })
    }).catch(err => console.error('Elysium | engagement warning post failed:', err))
  }

/**
 * Inject a covering-stance toggle button onto each equipped weapon
 * row on the Combat tab. Click → opens the stance dialog (passive-
 * block / ward selector + location pickers); right-click → drops the
 * stance if active.
 *
 * Visual state:
 *   - Inactive: grey shield icon
 *   - Passive-block active: green (#2a6e2a) shield icon
 *   - Ward active: amber (#a07020) shield icon
 *
 * Idempotent: bails if the row already has a `.elysium-cs-toggle` element.
 */
export function injectCoveringStanceTogglesOnCombatTab (html, actor) {
  const cs = game.system.api?.elysium?.coveringStance
  if (!cs) return

  const equippedWeapons = actor.items.filter(i =>
    i.type === 'weapon' && i.system?.equipStatus === 'equipped'
  )
  if (equippedWeapons.length === 0) return

  for (const weapon of equippedWeapons) {
    const row = html.querySelector(
      `.tab.combat [data-item-id="${weapon.id}"], ` +
      `[data-tab="combat"] [data-item-id="${weapon.id}"]`
    )
    if (!row) continue
    if (row.querySelector('.elysium-cs-toggle')) continue

    const stance = cs.getStance(weapon)
    const isShield = cs.isShield(weapon)

    let bg = 'transparent', border = '#888', color = 'inherit'
    let label = `Set up covering stance. ${isShield ? 'Shield' : 'Weapon'} AP: ${weapon.system?.ap || 0}.`
    if (stance?.type === cs.STANCE_PASSIVE_BLOCK) {
      bg = '#2a6e2a'; border = '#2a6e2a'; color = '#fff'
      label = `Passive Block active — click to update, right-click to drop. ${_csTooltipBody(actor, weapon, stance)}`
    } else if (stance?.type === cs.STANCE_WARD) {
      bg = '#a07020'; border = '#a07020'; color = '#fff'
      label = `Ward active — click to update, right-click to drop. ${_csTooltipBody(actor, weapon, stance)}`
    }

    const btn = document.createElement('button')
    btn.type = 'button'
    btn.className = `elysium-cs-toggle ${stance ? 'elysium-cs-active' : ''}`
    btn.dataset.elysiumCsItemId = weapon.id
    btn.style.cssText = `
      background: ${bg};
      color: ${color};
      border: 1px solid ${border};
      border-radius: 3px;
      padding: 1px 6px;
      margin-left: 6px;
      font-size: 11px;
      cursor: pointer;
    `
    const icon = isShield ? 'fa-shield-halved' : 'fa-shield'
    btn.innerHTML = `<i class="fas ${icon}"></i>`
    btn.dataset.tooltip = label

    const nameCell = row.querySelector('.weapon-name') ||
                     row.querySelector('[data-item-id]')?.firstElementChild ||
                     row.firstElementChild
    if (nameCell) nameCell.appendChild(btn)
    else row.appendChild(btn)

    btn.addEventListener('click', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      await cs.openStanceDialog(actor, weapon)
    })
    btn.addEventListener('contextmenu', async (ev) => {
      ev.preventDefault()
      ev.stopPropagation()
      if (cs.isItemInCoveringStance(weapon)) {
        await cs.dropStance(actor, weapon)
      }
    })
  }
}

function _csTooltipBody (actor, weapon, stance) {
  if (!stance) return ''
  const locNames = stance.locationIds.map(id => actor.items.get(id)?.name || '?').join(', ')
  const sizeLabels = CONFIG.ELYSIUM?.WEAPON_SIZES || {}
  const wSize = weapon.system?.elysium?.weaponSize || 'M'
  const effectNote = stance.type === 'ward'
    ? `Size ${sizeLabels[wSize] || wSize}; damage downgraded per parry table.`
    : `AP ${weapon.system?.ap || 0}.`
  return `Covers: ${locNames}${stance.crouching ? ' (crouching)' : ''}. ${effectNote}`
}

/**
 * Inject covering-stance badges onto each hit-location row that is
 * currently being covered by an equipped item. Passive-block and ward
 * coverage render as distinct badges (green vs amber) so the player
 * can tell at a glance which protection a location enjoys; both can
 * be present on the same location.
 *
 * Idempotent.
 */
export function injectCoveringStanceBadgesOnLocations (html, actor) {
  const cs = game.system.api?.elysium?.coveringStance
  if (!cs) return

  const hitLocs = actor.items.filter(i => i.type === 'hit-location')
  for (const loc of hitLocs) {
    const row = html.querySelector(
      `.tab.combat [data-item-id="${loc.id}"], ` +
      `[data-tab="combat"] [data-item-id="${loc.id}"]`
    )
    if (!row) continue
    if (row.querySelector('.elysium-cs-loc-badges')) continue

    const pbItems = cs.getPassivelyBlockingItemsForLocation(actor, loc.id)
    const wardItems = cs.getWardingItemsForLocation(actor, loc.id)
    if (pbItems.length === 0 && wardItems.length === 0) continue

    const container = document.createElement('span')
    container.className = 'elysium-cs-loc-badges'
    container.style.cssText = `display:inline-flex;gap:3px;margin-left:6px;`

    if (pbItems.length > 0) {
      const totalAP = pbItems.reduce((s, it) => s + (Number(it.system?.ap) || 0), 0)
      const sources = pbItems.map(it => `${it.name} (AP ${it.system?.ap || 0})`).join(', ')
      const badge = document.createElement('span')
      badge.className = 'elysium-pb-loc-badge'
      badge.style.cssText = `
        display:inline-flex; align-items:center; gap:3px;
        background:#2a6e2a; color:#fff;
        padding:1px 6px; border-radius:3px; font-size:11px;
      `
      badge.innerHTML = `<i class="fas fa-shield-halved"></i> +${totalAP} AP`
      badge.dataset.tooltip = `Passively blocked by: ${sources}`
      container.appendChild(badge)
    }

    if (wardItems.length > 0) {
      const sizeLabels = CONFIG.ELYSIUM?.WEAPON_SIZES || {}
      const sources = wardItems.map(it => {
        const wSize = it.system?.elysium?.weaponSize || 'M'
        return `${it.name} (Size ${sizeLabels[wSize] || wSize})`
      }).join(', ')
      // Show the best warder's size
      const SIZE_ORDER = ['T','S','M','L','H','E']
      let bestIdx = -1, bestSize = 'M'
      for (const it of wardItems) {
        const s = it.system?.elysium?.weaponSize || 'M'
        const i = SIZE_ORDER.indexOf(s)
        if (i > bestIdx) { bestIdx = i; bestSize = s }
      }
      const badge = document.createElement('span')
      badge.className = 'elysium-ward-loc-badge'
      badge.style.cssText = `
        display:inline-flex; align-items:center; gap:3px;
        background:#a07020; color:#fff;
        padding:1px 6px; border-radius:3px; font-size:11px;
      `
      badge.innerHTML = `<i class="fas fa-shield-alt"></i> Ward ${sizeLabels[bestSize] || bestSize}`
      badge.dataset.tooltip = `Warded by: ${sources}. Damage downgraded per Mythras parry-size table (use the chat-card "Apply Ward" button to compute).`
      container.appendChild(badge)
    }

    const nameCell = row.querySelector('.item-name') || row.firstElementChild
    if (nameCell) nameCell.appendChild(container)
    else row.appendChild(container)
  }
}

// alpha.7 back-compat aliases — exported names that the dispatcher
// imported in alpha.7 still work; the dispatcher (sheet-extension.mjs)
// is being updated to call the new names directly in alpha.8.
export const injectPassiveBlockTogglesOnCombatTab = injectCoveringStanceTogglesOnCombatTab
export const injectPassiveBlockBadgesOnLocations  = injectCoveringStanceBadgesOnLocations

