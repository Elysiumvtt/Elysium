# P9 Tab content rebuild — prep audit

Captured 2026-05-14, between P8 close (alpha.29) and P9 start.

## Decisions locked at audit time (user-confirmed)

1. **Statistics tab folds into header tile drill-down.** No separate gutter
   chip. The new stat tiles become the home for "click for derived-stat
   detail" — tooltip, popover, or dialog (P9 picks one during the statistics-
   absorption ship). The standalone `character.statistics.hbs` retires.

2. **Dev tab keeps current scope, refreshed against new identity.** Still
   gated on the `development` setting; same handlers (`powImprove`,
   `xpRolls`, `viewDoc`); just new markup + classes. No scope creep into
   GM-toolbox territory in P9.

3. **Magic tabs use smart consolidation.** When exactly one magic tradition
   is active on the actor, that tradition gets its direct chip
   (`Arcane` / `Divine` / etc.) — current behavior. When two or more are
   active, the chips collapse into a single `Magic` gutter chip whose
   content body holds sub-tabs (one per active tradition). `Mutations` and
   `Super` are technically in the magic-conditional set today but are NOT
   spell-shape tabs — audit recommends keeping them as direct chips
   regardless (they're "powers," not "magic disciplines").

4. **NPC sheet parity is design-stage only.** Every shared sub-component
   defined in P9 includes a "NPC adaptation notes" callout, listing what
   differs for NPC reuse (e.g. NPCs lack skill improvement checkboxes,
   so `improve-checkbox.hbs` needs an `editable` flag). No NPC code in P9.
   Side finding #25 (NPC shell rebuild) gets its own focused alpha after
   P9 character work lands, before P10.

5. **Audit-then-stop discipline.** This doc ships alone. No version bump.
   No code touched. After review and lock-in of sequencing + shared-
   component names, P9 first-tab alpha follows.

## Phase scope summary

P9 rebuilds the 13 tab content templates registered in `character.mjs`
PARTS (lines 37–88) against the v1.0.0 design language. The tab CONTENT
templates currently render legacy markup against `css/legacy.css`,
`css/npc.css`, and `styles/elysium.css`. After P9, every tab uses
`elysium-*` semantic classes resolving against `--ely-*` tokens.

**Net change**: 13 templates removed from `templates/actor/character.*.hbs`
and recreated in new positions/forms; new shared partials added under
`templates/actor/parts/`; CSS additions in `styles/elysium-sheets.css`;
`_configureRenderOptions` and `_getTabs` in `character.mjs` updated to
implement smart consolidation; statistics part removed from PARTS list;
three orphaned legacy partials (`character.header.hbs`, `character.skills.hbs`,
`character.effects.hbs`) deleted opportunistically.

Out of scope: NPC shell rebuild, item sheet rebuild (P10), chat cards
(P11), legacy.css/npc.css/styles/elysium.css deletion (P12), light theme
retirement (P12).

---

## (a) Per-tab inventory

Source: grep over `templates/actor/character.*.hbs` for class attributes,
`data-action` attributes, `prose-mirror` elements; cross-referenced
against `context.*` reads in `character.mjs:_prepareContext`.

### Always-on tabs (7)

| Tab | Lines | Distinct legacy classes | Distinct actions | ProseMirror | Tradition |
|---|---:|---:|---:|---|---|
| combat | 159 | 27 | 9 | no | always |
| items | 127 | 27 | 5 | no | always |
| social | 62 | 17 | 5 | no | always |
| pers | 54 | 18 | 5 | no | always |
| statistics | 92 | 18 | 1 | no | always *(folds to drill-down)* |
| background | 31 | 17 | 3 | **yes (N storySections)** | always |
| dev | 41 | 18 | 3 | no | gated on `development` setting |

### Conditional magic tabs (6)

| Tab | Lines | Distinct legacy classes | Distinct actions | Spell-base shape | Active when |
|---|---:|---:|---:|---|---|
| arcane | 233 | 37 | 7 | spell + skill summary + sustains | `system.arcane != ""` |
| mysticism | 151 | 33 | 6 | feat + skill summary | `system.mysticism != ""` |
| divine | 122 | 18 | 4 | spell + skill summary + faiths | `system.divine != ""` |
| sorcery | 66 | 21 | 5 | spell + skill summary | `system.sorcery != ""` |
| super | 42 | 13 | 2 | power + failings (not spell-shape) | `system.super != ""` |
| mutations | 21 | 14 | 2 | mutation list (not spell-shape) | `system.mutation != ""` |

### Orphaned legacy partials (zero live references)

| File | Lines | Status |
|---|---:|---|
| `templates/actor/character.skills.hbs` | 293 | superseded by `parts/left-rail-skills.hbs`; delete during P9 cluster 1 |
| `templates/actor/character.header.hbs` | 303 | superseded by `parts/header-card.hbs`; delete during P9 cluster 1 |
| `templates/actor/character.effects.hbs` | 27 | superseded by `parts/right-rail-effects.hbs`; delete during P9 cluster 1 |

Grep confirmed: no `{{> ...}}` partial includes, no template registrations,
no `loadTemplates` references to these three files anywhere in source.

### Per-tab data dependencies (context.* reads, abbreviated)

Combat
: `context.weapons`, `context.wounds`, `context.hitlocs`, `context.allHeal`, plus per-row
  derived flags (`weapon.system.skillScore`, `weapon.system.dmgName`,
  `weapon.system.hp`, etc.).

Items
: `context.armors`, `context.gears`, `context.activeEffect` for equipStatus
  state; per-row derived flags (encumbrance, AV, AVR, equipStatus,
  ballistic if `useAVRand`).

Social
: `context.allegiances`, `context.reputations`; per-row `improve`,
  `opposed`, `enemy`, `total`, `rank`.

Pers
: `context.passions` (== passionsGeneral; arcane passions filtered out),
  `context.persTraits`; per-row `improve`, `opptotal`, `opposedTrait`.

Statistics
: `context.stats`, `context.health`, `context.actionPoints`, `context.exp`,
  `context.expDiceDisplay`, `context.failCounter`, `context.enc`. *(Drill-
  down absorption: header tiles already expose `total` and `deriv`; statistics
  adds the breakdown into `base`/`effects`/`experience`/`hpBonus`/etc. — see
  section (b) for the migration plan.)*

Background
: `context.storySections` (array of `{title, value, enriched, isFirst, isLast}`),
  `context.editable`, `context.isLocked`. Two ProseMirror editors per section
  (one HTMLField). **Bridge wedge risk** during smoke per side finding #5.

Dev
: `context.stats`, `context.impItem`, `context.powImproveFixed`,
  `context.powImproveFormula`, `context.xpFixed`, `context.xpFormula`.

Arcane
: `context.arcanes`, `context.elysiumArcaneTab.{arcaneSkills, formSkills,
  techniqueSkills, activeSustains}`, `context.passionsArcane`, `context.builder`.

Mysticism
: `context.mysticisms` (feats), `context.elysiumMysticismTab.focusSkills`.

Divine
: `context.divines` (spells), `context.elysiumDivineTab.{channelingSkills,
  faiths}`.

Sorcery
: `context.elysiumSorceryTab.essenceSkills` *(spells come from filtered skill
  list, not a dedicated `sorceries` collection — confirmed in `character.mjs`
  context build; this is asymmetric with arcane/divine/mysticism)*.

Super
: `context.superpowers`, `context.failings`.

Mutations
: `context.mutations`.

### Per-tab action handler dependencies

All actions resolve through `base-actor-sheet.mjs:DEFAULT_OPTIONS.actions`
(61 total registered). P9 does NOT add new handlers; rebuild reuses the
existing handler set. No handler renames; no handler deletions. The
`statistics` tab's single action `rollCharStats` survives the drill-down
absorption and binds to the new drill-down trigger.

Cross-tab handler usage:
- `viewDoc`, `createDoc`, `itemToggle`, `skillRoll` — universal (10+ tabs)
- `castArcane` / `castDivine` / `castSorcery` / `castMysticism` /
  `castCustomSpell` — magic-cluster only
- `armorToggle`, `armorLocToggle` — items only
- `weaponRoll`, `damageRoll`, `armorRoll`, `addDamage`, `healing`,
  `viewWound` — combat only
- `allegianceRoll`, `reputationRoll` — social only
- `passionRoll`, `personalityRoll` — pers only
- `storyUp`, `storyDown`, `storyDelete` — background only
- `xpRolls`, `powImprove` — dev only

---

## (b) Current-vs-target per tab

This section documents intent only. Visual mockups happen at the per-tab
ship; this audit defines the data shape and major UI decisions per tab.
Each tab carries `OPEN QUESTIONS` callouts for items needing your decision
before the corresponding ship.

### Combat

**Today**: 13-column grid header + N weapon rows + hit-location grid +
healing actions. Per-weapon row shows name, chance%, damage, dmg-bonus,
range, attacks, hands/crew, PP store, HP/AP, encumbrance, ammo, status.

**Target v1.0.0**:
- Section-card chrome (new shared partial) per logical block: Weapons,
  Hit Locations, Healing Actions, Active Wounds.
- Weapon row redesigned as crimson-bone-dark rows with `--ely-action-hover`
  background on hover; columns trimmed to **8 visible** by default (name,
  chance, damage, range, attacks, hands, status, ammo); the remaining 5
  columns (dmg-bonus, PP store, HP, AP, encumbrance) move to an expandable
  detail row per weapon. Trade: vertical density vs at-a-glance scanability.
- Hit-locations table: per-location HP value + AP value + bodyPart label.
  Visual treatment: location name on a crimson tile (matching stat tiles),
  HP shown as `current/max` with progress fill behind the number when HP < max.
- Healing actions block (heal all, treat wound): becomes a row of
  `elysium-button-primary` chips matching the AP/PP refresh buttons.

**OPEN QUESTION combat-1**: Expand-detail-row for trimmed columns vs
keep-all-columns-with-tighter-styling. Recommendation: **expand-detail-row** —
matches the D&D Beyond aesthetic of clean headers with on-demand detail.

**OPEN QUESTION combat-2**: Wounds — render inline in the hit-location row
(showing wounds against that location) or as a separate "Active Wounds"
card below hit-locations. Recommendation: **inline + summary card** — wound
indicator dot/icon on the affected hit-location row, with a separate card
listing each wound's narrative detail (severity, healing progress, etc.).

### Items

**Today**: armor table + gear table + sort controls + add buttons.

**Target v1.0.0**:
- Two section-cards: Armor and Gear. Money/wealth shown as a third small
  card at the top showing wealth label + chip (gold/silver/copper if applicable).
- Armor row: name, hit-locations-covered (chips), AV, AVR, equipStatus
  toggle, encumbrance.
- Gear row: name, quantity, encumbrance, equipStatus toggle, value-if-present.
- Sort controls become section-card header buttons (small icon-only).
- Filter chip ("show equipped only") in the section-card header.

**OPEN QUESTION items-1**: Wealth representation — keep as a label
(`wealthName` → "Comfortable" / "Wealthy" / etc.) per current Mythras
convention, or add a numeric currency field? Recommendation: **keep as
label only** — Mythras canonical, project rule "don't change rules, change
identity."

**OPEN QUESTION items-2**: Ballistic columns (`av2`, `avr2`, `armBal`,
`armVar`) — these are vestigial pre-v0.21.0 BRP-classic remnants per P6.3
audit. Hide them entirely in v1.0.0 even when `useAVRand` is set, or keep
the conditional render? Recommendation: **hide entirely** — vestigial,
zero useful coverage, the setting itself should retire in P12.

### Social

**Today**: allegiances list + reputations list (reputations conditional on
`useReputation`).

**Target v1.0.0**:
- Section-card per: Allegiances, Reputations *(conditional)*.
- Allegiance row: name, title, total %, improve checkbox (same square
  18×18 as header stats), opposed marker icon, enemy marker icon.
- Reputation row: name, rank label, value, improve checkbox.

**OPEN QUESTION social-1**: Allegiance "title" field (faith name, faction
title) — display inline with allegiance name (e.g. "Faith of Helios:
Devout") or as a sub-line? Recommendation: **sub-line in smaller font** —
matches the stat-tile-pill-then-name pattern.

### Pers (Personality)

**Today**: passions list + personality traits list. Trait rows have an
opposed-trait column showing the inverse score (e.g. Bold/Cautious 65/35).

**Target v1.0.0**:
- Section-card per: Passions, Personality Traits.
- Passion row: name, total %, improve checkbox.
- Personality trait row: trait name on left, opposed-trait name on right,
  visual scale-bar in the middle showing the split (this is a new visual
  treatment matching the "balanced pair" aesthetic — see mock during ship).

**OPEN QUESTION pers-1**: Trait scale-bar visualization — horizontal bar
with center marker showing position, vs two side-by-side percentage chips,
vs current flat numbers. Recommendation: **horizontal scale-bar** — most
distinctive, matches the new identity.

### Statistics — folds to drill-down

**Today**: separate tab listing every stat + every derived value in a wide
grid. ~92 lines, single action.

**Target v1.0.0**: statistics tab **deleted**. Per-tile drill-down absorbs
the data. Click (or hover-with-delay) on any stat tile opens a popover
showing:
- Base value (`stat.base`)
- Plus effects (`stat.effects` if non-zero)
- Plus experience (`stat.experience` if non-zero)
- Equals total (`stat.total`)
- Plus all derived stats keyed to this stat (full list, not just the
  primary one shown on the tile)

Plus a card-style "full stats sheet" view accessible from the dev or
header context menu for GMs who want the wide grid layout.

**OPEN QUESTION statistics-1**: Drill-down UI: tooltip (hover, simple) vs
popover (click, richer) vs dialog (click, full sheet). Recommendation:
**popover** — hover tooltips are too easy to trigger by accident on the
tight tile grid; dialogs are heavy for what amounts to 6–10 lines of detail;
popover with click-outside-to-dismiss is the right weight.

**OPEN QUESTION statistics-2**: "Full stats sheet" — needed at all, or is
per-tile drill-down sufficient? Recommendation: **defer to P12** — ship
P9 with drill-down only; if GMs miss the wide-grid view, add it then.

### Background

**Today**: N user-named story sections; each section is a ProseMirror
editor with a title input + reorder + delete controls. Locked-state hides
controls and renders enriched HTML only.

**Target v1.0.0**:
- Section-card chrome (consistent with other tabs).
- Each story section's title becomes a small section-card-style header
  inside the larger Background card; ProseMirror body styled to match
  `--ely-text-primary` on `--ely-surface-1` with consistent line-height.
- New-section button → `elysium-button-primary` matching combat healing
  actions.
- Reorder controls → consistent icon-button styling (matching items sort
  controls).

**Bridge wedge risk**: this tab is the single highest-risk surface for the
Claude-in-Chrome bridge per side finding #5 (multiple ProseMirror editors
embed chrome-extension iframes). Smoke pattern for background-tab ship:
render + capture geometry + close in same eval; never read rendered DOM
nodes containing the prosemirror element.

**OPEN QUESTION background-1**: ProseMirror toolbar — keep Foundry default
or restyle? Recommendation: **keep Foundry default** — restyling a
Foundry framework component blows scope; identity comes from
surrounding card chrome.

### Dev

**Today**: dev list of stats with XP/POW improvement controls + manual
formula triggers.

**Target v1.0.0**: same shape, new identity. Section-card chrome; row
styling matches Items gear row. Buttons follow `elysium-button-primary`.

**OPEN QUESTION dev-1**: Anything to add or remove from dev tab? Recommendation:
**no scope change** — see decision 2.

### Arcane

**Today**: largest tab (233 lines). Sections: school skills (Evocation,
Abjuration), forms skills, techniques skills, spells list, active sustains,
custom spell builder, arcane passions.

**Target v1.0.0**:
- Section-card per: Skills (school + forms + techniques as collapsible
  sub-groups within the one card), Spells, Active Sustains, Custom
  Builder, Arcane Passions.
- Spell row: name, school chip, PP cost, range, duration, cast button.
- Sustain row: spell name, drop button, sustain-since-time if available.
- Custom builder: kept current shape, restyled.

**OPEN QUESTION arcane-1**: Custom Spell Builder is a complex UI (drag-and-
drop builder for component selection). Restyle in-place or scope-out and
ship as a side dialog? Recommendation: **restyle in-place** — ripping it
out of the tab is a separate feature; P9 only changes its skin.

### Mysticism

**Today**: focus skills + feats list. Bit-identical shape to arcane minus
custom builder and sustains.

**Target v1.0.0**:
- Section-card per: Focus Skills, Feats.
- Feat row: name, duration, effects-short, cast button.
- Reuses arcane's spell-row shape where applicable.

### Divine

**Today**: channeling skills + spells list + faith allegiances.

**Target v1.0.0**:
- Section-card per: Channeling Skills, Spells, Faiths.
- Faith card: allegiance name + current rank/points pill.
- Spell row: matches arcane spell row.

### Sorcery

**Today**: essence skills + spells (filtered from skills, not a dedicated
collection — asymmetric with other magic tabs).

**Target v1.0.0**:
- Section-card per: Essence Skills, Spells.
- Spell row: matches arcane spell row.

**NOTE**: the asymmetry in data source (spells-as-skills, not spells-as-
`sorceries`-bucket) is a pre-existing oddity, NOT changed in P9. P12 may
want to fix.

### Super

**Today**: superpowers list + failings list.

**Target v1.0.0**:
- Section-card per: Powers, Failings.
- Power row: name, PPPL cost, range, level, duration, short-description.
- Failing row: name, short-description.

### Mutations

**Today**: mutations list (single section).

**Target v1.0.0**:
- Single section-card: Mutations.
- Row: name, major/minor chip, advantage/disadvantage chip, impact value.

---

## (c) Shared sub-components

Cross-tab class-frequency analysis (`item`, `gr-list`, `diff-label`,
`item-control`, `item-name`, `rollable`, `inline-edit`, `centre`, etc.
appearing in 4–12 tabs each) confirms strong sharing potential.

### Proposed shared partials under `templates/actor/parts/`

| Partial | Purpose | Consumed by | NPC adaptation note |
|---|---|---|---|
| `tab-section-card.hbs` | Titled card chrome (header + body slot + optional action chips in header) | every tab | needs `kind="npc"` flag to drop add-button affordance |
| `item-row-weapon.hbs` | Weapon row (8 visible cols + expand) | combat | NPC weapons are a different shape — needs separate partial for NPC |
| `item-row-gear.hbs` | Gear row | items | NPC re-uses as-is |
| `item-row-armor.hbs` | Armor row | items | NPC re-uses as-is |
| `item-row-spell.hbs` | Spell row (works for arcane/divine/mysticism/sorcery spells + super powers) | arcane, divine, mysticism, sorcery, super | NPC re-uses as-is (when NPC has magic) |
| `item-row-skill-summary.hbs` | Skill summary row used in magic tabs' skill section | arcane, divine, mysticism, sorcery | NPC re-uses as-is |
| `item-row-passion.hbs` | Passion row | pers, arcane (arcane passions) | NPC re-uses as-is |
| `item-row-allegiance.hbs` | Allegiance row | social, divine (faiths) | NPC re-uses as-is |
| `improve-checkbox.hbs` | Square 18×18 improve toggle | social, pers, arcane, dev, +many | needs `editable` flag; NPC renders read-only |
| `prose-mirror-section.hbs` | Wraps a single prosemirror editor with consistent chrome | background, possibly social/pers (notes) | NPC re-uses as-is |
| `section-card-header-button.hbs` | Small icon button for "add item", "sort", "filter" used in card headers | every tab with add/sort/filter | NPC renders different button set |
| `stat-drill-down-popover.hbs` | Per-stat-tile detail popover (replaces statistics tab) | header-card | NPC sheet has stat tiles too once #25 closes; popover applies |

### Proposed CSS additions in `styles/elysium-sheets.css`

Net new rules expected (rough estimate; finalized per-ship):
- `.elysium-tab-section-card` + variants — ~25 lines
- `.elysium-item-row` base + per-variant decorators — ~40 lines
- `.elysium-improve-checkbox` — ~15 lines *(may already exist from header
  stats; check at ship time)*
- `.elysium-section-card-header` + button variants — ~20 lines
- `.elysium-spell-row` overlay — ~15 lines
- `.elysium-stat-drill-popover` — ~25 lines
- Magic sub-tab nav (when 2+ magic traditions active) — ~25 lines

Estimated total new CSS: ~165 lines added to `elysium-sheets.css` (currently
~950 lines per HANDOFF). Approximate after P9 close: ~1100 lines.

### Smart consolidation logic for magic tabs

`_configureRenderOptions` change (proposal, written here for review,
implemented at first magic-ship):

```js
const activeMagic = [
  this.actor.system.arcane    !== "" ? 'arcane'    : null,
  this.actor.system.divine    !== "" ? 'divine'    : null,
  this.actor.system.mysticism !== "" ? 'mysticism' : null,
  this.actor.system.sorcery   !== "" ? 'sorcery'   : null,
].filter(Boolean);

if (activeMagic.length === 1) {
  options.parts.push(activeMagic[0]);  // direct chip
} else if (activeMagic.length >= 2) {
  options.parts.push('magic');          // consolidated chip
  // (magic part body iterates activeMagic and renders one sub-tab
  //  per active tradition)
}

// mutations + super stay as direct chips regardless — they're
// "powers" not "spell-shape magic disciplines."
if (this.actor.system.mutation !== "") options.parts.push('mutations');
if (this.actor.system.super    !== "") options.parts.push('super');
```

`_getTabs` needs a parallel update to emit the `magic` chip's icon
(`fas fa-sparkles` or similar; final pick during ship) when consolidated.

A new `templates/actor/parts/character.magic.hbs` partial holds the
sub-tab nav + the inner tab content (each existing magic tab template
becomes the inner content of its sub-tab).

**OPEN QUESTION magic-1**: When consolidated, default sub-tab on open —
first by alphabetic order, or by some other rule (most spells? most-
recently-cast?). Recommendation: **alphabetic** — simplest, predictable;
revisit if user reports it's wrong.

---

## (d) Legacy-CSS blockers

### Cross-tab "universal" legacy classes

These appear in 6+ tabs each and are the highest-priority targets for
shared partial replacement:

| Class | Tabs using | Defined in | Replacement |
|---|---:|---|---|
| `item` | 12 | `css/legacy.css` | `.elysium-item-row` (via shared partial) |
| `diff-label` | 12 | `css/legacy.css` | section-card-header field-label slot |
| `centre` | 12 | `css/legacy.css` | utility class; replace with `text-align: center` rule on row variant or new `.elysium-u-text-center` if utility approach preferred |
| `rollable` | 11 | `css/legacy.css` | new `.elysium-rollable` decorator (hover state + cursor-pointer + `--ely-accent-action` underline) |
| `gr-list` | 10 | `css/legacy.css` | flow within `.elysium-tab-section-card` body slot |
| `item-control` | 7 | `css/legacy.css` | new `.elysium-section-card-header-button` |
| `item-edit` | 6 | `css/legacy.css` | folds into row's view-action affordance |
| `truncate` | 5 | `css/legacy.css` | `.elysium-u-truncate` utility (text-overflow: ellipsis) |
| `inline-edit` | 5 | `css/legacy.css` | form field uses base.css form-control style; no class needed |

### Tab-specific legacy classes (high-touch)

Arcane (37 classes) and mysticism (33 classes) carry the most tab-specific
legacy markup, including `skill-cell-*`, `skill-prsnlty`, `skill-occ`,
`skills-tab-grid`, `magic-list-header`, `magic-listitem`. These all
collapse into the new `item-row-skill-summary.hbs` + `item-row-spell.hbs`
shared partials, so the rebuild eliminates them rather than restyling.

Combat-specific: `weapon-tab-grid`, `hitloc-tab-grid`, `combat-input-small`,
`weapon-name`, `wound-name`, `wound-item` — all replaced by combat-row
partials.

Items-specific: `armor-tab-grid`, `armor-input-small`, `gear-tab-grid` —
replaced by armor/gear row partials.

Background-specific: `bio-section`, `bio-section-value`, `story-subtitle`,
`section-header`, `flexrow-elysium`, `header-buttons`, `move-section-up/
down`, `delete-section` — all replaced by `prose-mirror-section.hbs` +
existing `elysium-button-primary` rules.

### Legacy classes that survive into v1.0.0

None expected. Every legacy class observed in the 13 tab templates is
replaceable.

### `css/legacy.css` retirement readiness after P9

Post-P9, `css/legacy.css` will have:
- Foundation rules: already migrated to `elysium-reset.css` /
  `elysium-base.css` / `elysium-components.css` in P7
- Sheet-shell rules: already replaced by `elysium-sheets.css` in P8
- Tab-content rules: replaced by `elysium-sheets.css` additions in P9
- Item-sheet rules: still active (replaced in P10)
- Chat card rules: still active (replaced in P11)
- Theme variable definitions (`--ely-legacy-*`): still active (consumed
  by P10/P11 surfaces; final retirement in P12)

So `legacy.css` cannot be deleted at P9 close. P9 contribution to its
retirement: removes ~40 distinct rule blocks of tab-content styling
(estimated; final count taken at P9 close per actual class usage).

---

## Proposed rebuild sequencing

Five ship clusters, smallest-blast-radius first per project rule "one
concern per ship":

### Cluster 1: shared scaffold + simplest tab pair (alpha.30)

Builds the shared sub-component foundation. Ships two simplest tabs as
validation cases.

Touches:
- New partials: `tab-section-card.hbs`, `improve-checkbox.hbs`,
  `section-card-header-button.hbs`, `item-row-passion.hbs`
- CSS: `.elysium-tab-section-card` + `.elysium-improve-checkbox` +
  `.elysium-section-card-header` rules in `elysium-sheets.css`
- Rebuild: `character.mutations.hbs` (simplest), `character.dev.hbs` (next
  simplest)
- Delete: three orphaned legacy partials (`character.skills.hbs`,
  `character.header.hbs`, `character.effects.hbs`) — opportunistic cleanup
- Smoke: live verify both rebuilt tabs render, all tabs still clickable

Why this pair: mutations is the smallest tab (21 lines), proves the
scaffold scales DOWN; dev validates handler reuse (`powImprove`,
`xpRolls`, `viewDoc` all keep working) and the section-card chrome under
a non-trivial data shape.

### Cluster 2: combat (alpha.31)

Single-tab ship for the most user-visible tab. High-traffic; warrants
focused attention.

Touches:
- New partials: `item-row-weapon.hbs`, `item-row-hitloc.hbs`,
  `wound-detail-card.hbs`
- CSS: weapon-row rules + hit-location-row rules + expand-detail-row
  behavior
- Rebuild: `character.combat.hbs`
- Smoke: weapon roll, damage roll, armor roll, healing, view wound

### Cluster 3: items + social + pers (alpha.32)

Three small-medium tabs sharing the item-row + passion/trait/allegiance
row partials. Single ship because the partials chain together.

Touches:
- New partials: `item-row-gear.hbs`, `item-row-armor.hbs`,
  `item-row-allegiance.hbs`, `item-row-trait.hbs`
- CSS: pers trait scale-bar visualization is the most novel rule here
- Rebuild: `character.items.hbs`, `character.social.hbs`, `character.pers.hbs`
- Smoke: each tab's action set

### Cluster 4: background + statistics absorption (alpha.33)

Two unusual tabs paired because they each touch the header-card area:
background is the prose-mirror-heavy case; statistics absorbs into header
tile drill-down.

Touches:
- New partials: `prose-mirror-section.hbs`, `stat-drill-down-popover.hbs`
- Update: `header-card.hbs` to wire the drill-down popover trigger
- CSS: prosemirror chrome restyling + popover rules
- Rebuild: `character.background.hbs`
- Delete: `character.statistics.hbs`, `'statistics'` removed from PARTS
- Smoke: background tab edits persist; stat tile drill-down opens correctly;
  no other tab visually regresses

### Cluster 5: magic family + smart consolidation (alpha.34 + alpha.35)

Two ships because magic is complex and smart consolidation is a behavior
change.

**alpha.34** — Magic shared scaffold + single-tradition mode:
- New partials: `item-row-spell.hbs`, `item-row-skill-summary.hbs`,
  `magic-tab-shell.hbs`
- Rebuild all 4 magic-tab templates (arcane, divine, mysticism, sorcery)
  to use shared scaffold; keep super and mutations as-is (cluster 1
  already shipped mutations)
- Smoke: single-tradition test character renders each magic discipline
  correctly

**alpha.35** — Smart consolidation:
- New partial: `character.magic.hbs` consolidated wrapper
- `_configureRenderOptions` + `_getTabs` updates per section (c)
- Rebuild: `character.super.hbs` (was deferred to cluster 5 since it's
  visually adjacent to magic tabs even though not part of consolidation
  logic)
- Smoke: 1-tradition character → direct chip; 2-tradition character →
  consolidated `Magic` chip with sub-tabs; mutations + super always direct

### Optional cluster 6: NPC parity (alpha.36, post-P9)

Side finding #25 closure. Scope: NPC sheet uses the same shell + shared
partials as character; NPC-specific differences (no improve checkboxes,
different tab set, simpler header) honored via the `editable` /
`kind="npc"` flags baked into shared partials in P9.

Touches:
- NPC sheet `_configureRenderOptions` + `_prepareContext` parity work
- NPC-specific shell adjustments
- Smoke: NPC renders cleanly, character still renders cleanly

This ships BEFORE P10 so item-sheet rebuild has a stable NPC baseline
to work against.

### Total estimate

5 clusters in 5–6 alphas (cluster 5 = 2 alphas); optional cluster 6 for
NPC parity. 3–4 sessions matches ROADMAP estimate. Cluster 1 must ship
first to establish the scaffold; clusters 2–4 can re-order if priorities
shift; cluster 5 must come after the others since smart consolidation
depends on the magic-tab rebuilds existing.

---

## Open questions requiring lock-in before cluster 1 ships

A compact list of every OPEN QUESTION raised above, grouped for ease of
decision:

### Visual feel (recommend approving all-or-nothing)
- **combat-1**: expand-detail-row for trimmed columns vs keep-all-columns
- **combat-2**: wounds inline + summary card vs separate cards
- **social-1**: allegiance title inline vs sub-line
- **pers-1**: trait visualization — horizontal scale-bar vs side-by-side chips vs flat numbers
- **statistics-1**: stat drill-down — tooltip vs popover vs dialog

### Scope (recommend approving all)
- **items-1**: wealth-as-label only (no numeric currency)
- **items-2**: drop ballistic columns entirely
- **statistics-2**: defer full-stats-sheet view to P12
- **dev-1**: no scope change to dev tab
- **arcane-1**: restyle custom spell builder in-place

### Behavior
- **background-1**: keep Foundry default prosemirror toolbar
- **magic-1**: alphabetic default sub-tab when consolidated

My recommendation: approve all 12 with the values I've given. Each has its
rationale in the corresponding section above. If you want to override any,
specify which and the new direction; otherwise "approve all" locks them.

---

## Closing notes

This audit is descriptive of CURRENT STATE and prescriptive of TARGET
STATE per the locked decisions, but does not commit to specific markup
or class names beyond what's listed above. Each cluster ship will produce
its own concrete templates against this scaffold; if a partial's name
needs adjusting or a section's data shape needs refining, that adjustment
happens in the ship's CHANGELOG entry and updates this audit retroactively
via a "P9 audit revision" appendix.

After your review:
1. Lock the 12 open questions (approve-all OK).
2. Lock cluster sequencing (or reorder).
3. Lock shared-partial names (or rename).
4. Confirm "NPC parity is cluster 6, post-character-work" is correct.

Then cluster 1 (alpha.30) opens.
