# Elysium → Español translation glossary

Established BRP / Mythras / Elysium terminology for Spanish translations. Used by the c3 translation script to constrain machine-translation output to game-mechanically correct terms.

## Stat abbreviations (PRESERVE as-is — universal in es TTRPG)
- STR → STR (Strength → Fuerza)
- CON → CON (Constitution → Constitución)
- SIZ → SIZ (Size → Tamaño)
- INT → INT (Intelligence → Inteligencia)
- POW → POW (Power → Poder)
- DEX → DEX (Dexterity → Destreza)
- CHA → CHA (Charisma → Carisma)
- EDU → EDU (Education → Educación)

## Core BRP mechanical terms
- Hit Points / HP → Puntos de Vida / PV
- Power Points / PP → Puntos de Poder / PP
- Magic Points / MP → Puntos Mágicos / PM
- Action Points / AP → Puntos de Acción / PA
- Armor Points / AP → Puntos de Armadura / PA (context-dependent)
- Skill → Habilidad
- Characteristic → Característica
- Hit Location → Localización de Impacto
- Healing Rate → Tasa de Curación
- Damage Modifier → Modificador de Daño
- Damage Bonus → Bonificador de Daño
- Critical → Crítico
- Special → Especial
- Success → Éxito
- Failure → Fracaso / Fallo
- Fumble → Pifia
- Difficulty grade → Grado de Dificultad

## Mythras-specific
- Reach → Alcance
- Encroached → Acortado
- Held at bay → Mantenido a raya
- Engagement → Enfrentamiento
- Sustain (a spell) → Mantener / Sostener
- Ward → Custodia / Salvaguarda
- Brace → Apoyar / Sujetar (weapon-bracing context)
- Charge → Carga
- Knockback → Empuje / Derribo
- Outmanoeuvre → Superar en maniobra
- Change Range → Cambiar Alcance
- Passive Block → Bloqueo Pasivo
- Covering Stance → Postura de Cobertura
- Effective Size → Tamaño Efectivo
- Stance → Postura
- Endurance roll → Tirada de Resistencia
- Willpower roll → Tirada de Voluntad

## Spell schools / disciplines
- Arcane → Arcano
- Divine → Divino
- Mysticism → Misticismo
- Sorcery → Hechicería
- School → Escuela
- Discipline → Disciplina
- Spell → Hechizo
- Caster → Lanzador
- Casting → Lanzamiento

## Damage types
- physical → físico
- fire → fuego
- cold → frío
- electric → eléctrico
- corrosive → corrosivo
- poison → veneno
- mind → mental
- distortion → distorsión

## Elysium-specific mechanics
- EXP Dice / EXP die → Dado(s) EXP
- Stat improvement → Mejora de Característica
- Cap override → Anular Límite
- Major wound → Herida Mayor
- Serious wound → Herida Grave
- Minor wound → Herida Leve
- Ongoing damage → Daño Continuo
- Temp HP → PV Temporales
- Overcast → Sobrecarga (in casting context)
- Luck Point → Punto de Suerte
- Spend luck → Gastar suerte

## Fatigue levels (Mythras-style)
- Fresh → Descansado
- Winded → Sin aliento
- Tired → Cansado
- Weary → Fatigado
- Exhausted → Exhausto
- Spent → Agotado
- Collapsed → Colapsado
- Skill Grade → Grado de Habilidad (penalty context)
- AP Penalty → Penalización a PA
- Move Penalty → Penalización a Movimiento
- Initiative Penalty → Penalización a Iniciativa

## UI / sheet labels
- Sheet → Hoja
- Description → Descripción
- Settings → Configuración
- Tooltip → (translate inline only — no UI label)
- Roll → Tirar / Tirada
- Drag → Arrastrar
- Drop → Soltar
- Item → Objeto
- Actor → Actor (preserve)
- Effect → Efecto
- Active Effect → Efecto Activo
- Apply → Aplicar
- Remove → Quitar
- Approve → Aprobar
- Decline → Denegar

## Roles / Ancestry
- Ancestry → Ascendencia
- Subrace → Subraza
- Trait → Rasgo
- Career → Profesión
- Culture → Cultura
- Personality → Personalidad
- Allegiance → Lealtad
- Reputation → Reputación
- Passion → Pasión

## Resource references
- The system uses the term "Elysium" verbatim across languages — DO NOT translate.
- Foundry / VTT — preserve.
- BRPID / BRP-ID — preserve (technical identifier).
- d100 / d6 / 3d6 — preserve dice notation.

## Style notes for translation pass

- Tone: neutral, mechanical, like a rulebook reference. Avoid colloquialisms.
- Spanish punctuation: use «» for quotes where natural; ¿? for questions.
- Sheet labels: short and unambiguous (avoid 3+ word translations for 1-word source terms).
- Tooltips: full sentences, end with period.
- Hints (longer): can be 1-3 sentences; preserve any HTML tags in source.
- Format strings with `{placeholder}`: preserve placeholder name verbatim.
- When source uses `→` (arrow), preserve in translation.
- When source uses `•` or `·` (bullet/middot), preserve.

## Manual-review flag

Translations longer than ~15 words OR containing HTML tags should be flagged for second-pass review against this glossary.
