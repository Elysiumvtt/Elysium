// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

export function wireSkillSectionCollapsing (html, actor) {
    // section/subsection markup. v0.8.0 finalised tab names:
    // arcane / sorcery / mysticism / divine.
    const tabsToWire = [
      '.tab.skills',
      '.tab.arcane',
      '.tab.sorcery',
      '.tab.mysticism',
      '.tab.divine',
    ]

    for (const selector of tabsToWire) {
      const tabEl = html.querySelector(selector)
      if (!tabEl) continue
      if (tabEl.dataset.elysiumCollapseWired === '1') continue
      tabEl.dataset.elysiumCollapseWired = '1'

      tabEl.addEventListener('click', (ev) => {
        // Avoid swallowing clicks on inputs / buttons / inner anchors
        if (ev.target.closest('input, select, button, textarea, .elysium-magic-add')) return

        const header = ev.target.closest(
          '.elysium-skill-section-header, ' +
          '.elysium-skill-subsection-header, ' +
          '.elysium-spec-parent-header, ' +
          '.elysium-magic-section-header'
        )
        if (!header) return

        // Find the body element that should toggle. For specialism
        // parent rows the body is the .elysium-spec-children child;
        // for everything else, the immediate next sibling.
        let body = null
        if (header.classList.contains('elysium-spec-parent-header')) {
          body = header.parentElement?.querySelector('.elysium-spec-children')
        } else {
          body = header.nextElementSibling
        }
        if (!body) return

        const isCollapsed = header.classList.toggle('collapsed')
        body.style.display = isCollapsed ? 'none' : ''
      })
    }
  }
