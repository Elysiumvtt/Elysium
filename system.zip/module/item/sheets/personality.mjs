import { ElysiumUtilities } from '../../apps/utilities.mjs'
import { ElysiumDragDropItemSheet } from './base-dragdrop-item-sheet.mjs'

/**
 * Personality item sheet — P10 cluster 3b / alpha.41 rewrite.
 *
 * Defines a set of skills (main list) + optional skill groups (each
 * with a count of how many skills the player must choose from it).
 * Drops add skill references (NOT embedded copies — different from
 * super); deletes splice the collection.
 *
 * Inherits everything from ElysiumDragDropItemSheet: 8 drag/drop
 * methods + 4 collection-management methods + the imperative listener
 * wiring in _onRender. Only `_onDrop` needs personality-specific
 * semantics (skill duplicate detection + main/group routing). Form
 * handler preserves the existing groups-skill-rehydration logic.
 */
export class ElysiumPersonalitySheet extends ElysiumDragDropItemSheet {

  static DEFAULT_OPTIONS = {
    classes: ['personality'],
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }],
    position: { width: 560, height: 640 },
    form: { handler: ElysiumPersonalitySheet.myPersonalityHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/personality.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Resolve skill + group-skill references into displayable rows
    const perSkill = []
    const grpSkill = []
    for (const skill of this.item.system.skills) {
      const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({
        elysiumid: skill.elysiumid,
      }))[0]
      if (tempSkill) {
        perSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: tempSkill.name,
          category: tempSkill.system.category,
          variable: tempSkill.system.variable,
          base: tempSkill.system.base,
          group: tempSkill.system.group,
        })
      } else {
        perSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: game.i18n.localize('Elysium.invalid'),
          category: '', variable: '', base: '', group: '',
        })
      }
    }
    for (let index = 0; index < this.item.system.groups.length; index++) {
      for (const skill of this.item.system.groups[index].skills) {
        const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({
          elysiumid: skill.elysiumid,
        }))[0]
        if (tempSkill) {
          grpSkill.push({
            uuid: skill.uuid,
            elysiumid: skill.elysiumid,
            name: tempSkill.name,
            category: tempSkill.system.category,
            variable: tempSkill.system.variable,
            base: tempSkill.system.base,
            group: tempSkill.system.group,
            index,
          })
        } else {
          grpSkill.push({
            uuid: skill.uuid,
            elysiumid: skill.elysiumid,
            name: game.i18n.localize('Elysium.invalid'),
            category: '', variable: '', base: '', group: '', index,
          })
        }
      }
    }
    context.perSkill = perSkill.sort(ElysiumUtilities.sortByNameKey)
    context.grpSkill = grpSkill.sort(ElysiumUtilities.sortByNameKey)

    // Header chip per audit-3-cluster-3: (when owned) Skill Count
    const chips = []
    if (context.hasOwner) {
      const total = perSkill.length + grpSkill.length
      chips.push({
        label: game.i18n.localize('Elysium.skillCount'),
        value: String(total),
      })
    }
    context.itemHeaderChips = chips

    return context
  }

  // -----------------------------------------------------------------
  // OVERRIDE — personality-specific drop semantics
  // -----------------------------------------------------------------

  /**
   * Drop semantics: stores REFERENCES (uuid + elysiumid) to existing
   * skills, not embedded copies. Routes to main list or optional group
   * based on the drop target's class. Duplicate detection in both
   * destinations when the dropped skill is non-generic.
   */
  async _onDrop(event, type = 'skill', collectionName = 'skills') {
    event.preventDefault()
    event.stopPropagation()

    const optionalSkill = event?.currentTarget?.classList?.contains('optional-skills')
    const ol = event?.currentTarget?.closest('ol')
    const index = ol?.dataset?.group
    const dataList = await ElysiumUtilities.getDataFromDropEvent(event, 'Item')
    const collection = this.item.system[collectionName]
      ? foundry.utils.duplicate(this.item.system[collectionName])
      : []
    const groups = this.item.system.groups
      ? foundry.utils.duplicate(this.item.system.groups)
      : []

    for (const item of dataList) {
      if (!item || !item.system) continue
      if (![type].includes(item.type)) continue

      // F10 (rc.2) defensive guard — see career.mjs for rationale.
      if (!item.flags?.elysium?.elysiumidFlag?.id) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      if (optionalSkill) {
        // Dropping into an optional skill group
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          // Non-generic: enforce uniqueness across main list AND this group
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          if (groups[index].skills.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
        }
        groups[index].skills = groups[index].skills.concat({
          uuid: item.uuid,
          elysiumid: item.flags.elysium.elysiumidFlag.id,
        })
      } else {
        // Dropping into main skill list
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          // Remove from any groups (adding to main list de-dupes from groups)
          for (let i = 0; i < groups.length; i++) {
            const idx = groups[i].skills.findIndex(
              el => el.elysiumid === item.flags.elysium.elysiumidFlag.id,
            )
            if (idx !== -1) groups[i].skills.splice(idx, 1)
          }
        }
        collection.push({
          uuid: item.uuid,
          elysiumid: item.flags.elysium.elysiumidFlag.id,
        })
      }
    }
    await this.item.update({ 'system.groups': groups })
    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  // -----------------------------------------------------------------
  // FORM HANDLER — re-flatten groups + rehydrate skills arrays
  // -----------------------------------------------------------------
  static async myPersonalityHandler(event, form, formData) {
    const system = foundry.utils.expandObject(formData.object)?.system
    if (typeof system !== 'undefined' && system.groups) {
      formData.object['system.groups'] = Object.values(system.groups || [])
      for (let index = 0; index < this.item.system.groups.length; index++) {
        formData.object[`system.groups.${index}.skills`] = foundry.utils.duplicate(
          this.item.system.groups[index].skills,
        )
      }
    }
    await this.document.update(formData.object)
  }
}
