# P11 prep audit — chat cards + dialogs

Captured 2026-05-15, after P10 close (alpha.44 ship).
Audit-then-stop deliverable. **No code shipped from this document.**
User approval on the locked decisions opens cluster 1.

## 0. Phase posture in three sentences

P10 closed with 23/23 item sheets migrated to v1.0.0 and 9 shared item
partials in place. P11 rebuilds the **chat-message** and **dialog**
template surface — what players see during play after a sheet is closed
— against the v1.0.0 dark-bone-crimson identity. Goal: every chat card
and dialog uses tokenised v1.0.0 styling and shared partials, preserves
every JS-imperative class hook (Phase D button injection, the
`.cardbutton` legacy listener, V14 action wiring), and ships in audited
clusters with smoke between each.

---

## 1. Pre-audit issue: P11 scope description mismatch in CHANGELOG

The alpha.44 CHANGELOG entry's "Next" section says:

> P10 closes. **P11 (legacy.css final retirement sweep — any remaining
> orphan blocks)** and **P12 (polish: cast-card rebuild, statistics tab
> fold, DataModel cleanup, lang-parity gap, weapon DataModel/template
> alignment for the dead-code branches found in cluster 5 smoke, etc.)**
> become the next phases.

This contradicts `ROADMAP-v1.0.0.md §P11` (which describes P11 as chat
cards + dialogs) and both HANDOFF docs (which agree with the ROADMAP).
The ROADMAP is the canonical phase plan; the CHANGELOG paragraph drifted.

**Recommended fix**: in the cluster 1 ship, correct the alpha.44
"Next" paragraph to match the ROADMAP (P11 = chat cards + dialogs,
P12 = polish + acceptance). The "cast-card rebuild" item that the
CHANGELOG put under P12 actually IS P11 work and is captured below.
The legacy.css retirement is a continuous activity across P11 and P12,
not a phase of its own.

**Decision (audit-0)** — Apply this CHANGELOG correction in cluster 1.
Recommendation: yes.

---

## 2. Surface inventory

### 2a. Chat templates (`templates/chat/` — 12 files)

| # | File | LOC | Style state | Renderer |
|--:|---|--:|---|---|
| 1 | `cast-card.hbs` | 264 | **v1.0.0 island** (`elysium-cast-*`) — pre-token | `module/casting/cast-shared.mjs:392,407` |
| 2 | `roll-result.html` | 88 | Legacy (`gr-card`/`dice-roll`/`pending`) | `check.mjs` default |
| 3 | `roll-combat.html` | 76 | Legacy — **near-clone of roll-opposed.html** | `check.mjs:247` |
| 4 | `roll-opposed.html` | 76 | Legacy — **near-clone of roll-combat.html** | `check.mjs:239` |
| 5 | `roll-combined.html` | 89 | Legacy — group-roll cousin of cb/op | `check.mjs:235` |
| 6 | `roll-cooperative.html` | 98 | Legacy — group-roll cousin of cb/op | `check.mjs:243` |
| 7 | `roll-damage.html` | 33 | Legacy (`gr-card`) | `check.mjs:170` |
| 8 | `roll-armor.html` | 28 | Legacy (`gr-card`) | `check.mjs:190` |
| 9 | `quick-combat.html` | 75 | Legacy (`gr-card`) | `check.mjs:211` |
| 10 | `XP-result.html` | 19 | Legacy (`flavour-result`, `XPCheck`) | `charDev.mjs:144` |
| 11 | `rollStats.html` | 13 | Legacy (`flavour-result`, `XPCheck`) | `base-actor-sheet.mjs:316` |
| 12 | `itemDescription.html` | 7 | Legacy (`gr-card`, `name`) | `utilities.mjs:237` |

**Net**: ~870 LOC of templates. `cast-card.hbs` alone is ~30% of the
template volume.

Five of the rolls (combat/opposed/combined/cooperative + the singleton
result variants) share an unmistakable common shape: a `gr-card` form
wrapper, a label row, an iterated `gr-list > dice-roll > actor-roll`
participant strip, success-pip annotation per participant, and an
optional GM-only resolve/close button footer. Combat and opposed are
byte-for-byte identical save the card-label key (`Elysium.card.CB` vs
`OP`) and one `data-preset` value (`resolve-cb-card` vs `resolve-op-card`).

### 2b. Dialog templates (`templates/dialog/` — 10 files)

All 10 are pure form dialogs mounted in Foundry V14 `DialogV2`
(via our thin `ElysiumDialog` extension at
`module/setup/elysium-dialog.mjs:1`). DialogV2 harvests form data by
element `name` attributes at submit time — no per-class JS listener
wires into these templates.

| # | File | LOC | Purpose | Form-element names |
|--:|---|--:|---|---|
| 1 | `difficulty.hbs` | 80 | Roll-difficulty picker | `addStat`, `diffVal`, `difficulty`, `resistance`, `flatMod`, `range`, `hands`, `wound` |
| 2 | `damageDiff.hbs` | 40 | Damage-mod sub-dialog | `success`, `range`, `hands`, `level` |
| 3 | `treatWound.hbs` | 31 | First-aid healing input | `treatWound`, `healType`, `woundId` |
| 4 | `newWound.hbs` | 17 | Wound assignment input | `damage`, `woundLoc` |
| 5 | `skillSelect.hbs` | 15 | Multi-pick skill picker | (rendered into `SkillsSelectDialog`) |
| 6 | `selectItem.hbs` | 11 | Single-radio picker | `selectItem` |
| 7 | `hitLocChoice.hbs` | 10 | Hit-location dropdown | `hitLoc` |
| 8 | `npcTokenCreate.hbs` | 11 | NPC stat-roll picker | `statCreate` |
| 9 | `selectPower.hbs` | 9 | Power-category dropdown | `selectPower` |
| 10 | `getValue.hbs` | 11 | Single numeric input | `myValue` |

**Net**: ~235 LOC of templates. Mostly thin form layouts using
`flexcol`/`flexrow`/`stat-name`/`diff-label` legacy classes.

### 2c. Casting dialog templates (`templates/casting/` — 3 files)

These mount as full `HandlebarsApplicationMixin(ApplicationV2)` apps
(not DialogV2) and bind via Foundry V14 `actions` maps + dataset
attributes. **No class-based JS hooks.**

| # | File | LOC | Vocabulary | Renderer |
|--:|---|--:|---|---|
| 1 | `manipulation-dialog.hbs` | 154 | **v1.0.0 island #2** (`elysium-manip-*`) — pre-token | `module/casting/manipulation-dialog.mjs:85` |
| 2 | `custom-spell-builder.hbs` | 96 | **v1.0.0 island #3** (`csb-*` scoped under `elysium-custom-spell-builder`) — pre-token | `module/casting/custom-spell-builder.mjs:71` |
| 3 | `tier-choice-dialog.hbs` | 61 | **v1.0.0 island #4** (`tcd-*` scoped under `elysium-tier-choice-dialog`) — pre-token | `module/casting/tier-choice-dialog.mjs:76` |

### 2d. Combat-tracker template (`templates/combat/` — 1 file)

| # | File | LOC | Style state | Renderer |
|--:|---|--:|---|---|
| 1 | `combat-tracker.html` | 126 | Legacy — **markup dictated by Foundry core** | `module/combat/combat-tracker.mjs:4` |

Overrides Foundry V14's `CombatTracker` template path. The class
hierarchy, `data-control` attribute set, `combatant`/`directory-list`
class skeleton, and `data-document-id`/`data-combatant-id` dataset
attributes are all read by core Foundry code. **Restyling-only is
safe; structural rewrite is not.**

### 2e. Inline-HTML chat content (OUT OF P11 SCOPE — see §4)

51 callsites across the codebase call `ChatMessage.create({content: ...})`
with inline-HTML strings (not templates). Most live in
`module/elysium/mechanics/` (charge-ui, covering-stance, outmanoeuvre,
engagement-ui, weapon-wear, armor-wear) and `module/casting/` (sustain,
spell-learning, sorcery-cast, divine-cast). They use scoped wrapper
classes like `elysium-covering-stance-card`, `elysium-disrupt-success`,
etc., with inline `style=` attributes.

These are **not template files** — they're JS string-builders. P11
restyling rules can reach them at the CSS level (their wrapper classes
remain), but converting them to templates is a separate
JS-refactor effort. Recommendation: leave the markup alone in P11;
update only the wrapper-class CSS as a side effect of the new chat
token system. Deeper template refactor → P12 or beyond.

---

## 3. JS-imperative class-hook contract (the audit-5 lock for P11)

This is the list of class names, attribute selectors, dataset keys,
and DOM-search patterns that **listeners read from rendered chat / dialog
DOM**. Touching any of these without auditing the consumer breaks
behavior at runtime, not at render. Preserve all of them on rebuilt
markup; layer new v1.0.0 classes alongside for styling (the audit-5
pattern from P9/P10 clusters 3a/3b/4/5/6).

### 3a. Legacy chat-card layer

Source: `module/apps/chat.mjs` (`ElysiumChat.renderMessageHook`).
Hook: `renderChatMessageHTML` (registered at
`module/hooks/render-chat-message.mjs:3`).

| Selector | Behaviour | Must preserve |
|---|---|---|
| `.cardbutton` | Binds click → `ElysiumCheck.triggerChatButton` | YES — Phase D button surface |
| `.owner-only` | Hidden for non-owner of `data-partic-id` / `data-partic-type` | YES — visibility gate |
| `.gm-visible-only` | Hidden for non-GM | YES |

`data-preset` values that `triggerChatButton` dispatches to
(`module/apps/check.mjs:754`):

- `close-card` — `GRCard.GRClose`
- `remove-gr-roll` — `GRCard.GRRemove` (uses `data-rank`)
- `resolve-gr-card` — `GRCard.GRResolve`
- `resolve-op-card` — `OPCard.OPResolve`
- `resolve-cb-card` — `CBCard.CBResolve`
- `resolve-co-card` — `COCard.COResolve`

Additional dataset on resolve buttons: `data-partic-id`,
`data-particType` (note the camelCase legacy spelling). Preserve.

### 3b. Phase D combat-card-button injection

Source: `module/elysium/hooks/chat-card.mjs` +
`module/elysium/mechanics/combat-card-buttons.mjs`.

The injector appends a `<div class="elysium-combat-card-buttons">`
panel into the rendered chat card. The mount-point lookup is:

```js
const form = root.querySelector('form.elysium.gr-card') || root
form.appendChild(panel)
```

**`form.elysium.gr-card` is a Phase D mount-point selector**, not just
legacy decoration. Renaming or dropping either class would orphan the
GM-action panel. Preserve on every chat-message form that should host
the GM-action panel (combat/opposed/combined/cooperative roll cards in
particular).

| Selector | Read by | Must preserve |
|---|---|---|
| `form.elysium.gr-card` | Panel mount point | YES |
| `.elysium-hitloc-tag` | Visibility setting gate (`applyHitLocationVisibility`) | YES |
| `.elysium-weapon-wear-btn` + `[data-elysium-weapon-wear-action]` | Programmatic injection from `weapon-wear.mjs:287` | YES (injected, not in templates) |
| `.elysium-armor-wear-btn` + `[data-elysium-armor-wear-action]` | Programmatic injection from `armor-wear.mjs:219` | YES (injected, not in templates) |

### 3c. Cast-card click layer

Source: `module/elysium/hooks/chat-card.mjs` (`wireCastCardButtons`,
`wireDisruptSustainButtons`, `wireCastDisruptButtons`,
`wireCapOverrideButtons`).

| Selector | Behaviour | Dataset reads |
|---|---|---|
| `[data-cast-action]` | Spend AP / Abandon / Undo PP | `data-cast-action`, `data-actor-id`, `data-pp-amount` |
| `.elysium-disrupt-btn` | Disrupt-sustain on damage | `data-actor-id`, `data-spell-id`, `data-spell-name` |
| `.elysium-cast-disrupt-btn` | Cast-disruption Willpower roll | `data-actor-id`, `data-severity`, `data-sl-loss`, `data-damage` |
| `.elysium-cap-btn` + `.elysium-cap-approve` | Stat-cap / EXP-dice override approval | `data-actor-id`, `data-stat-key` |
| `.elysium-stat-cap-card`, `.elysium-stat-dice-card` | Used by `.elysium-cap-btn` closest() lookup | (no datasets) |

### 3d. Foundry-built-in (don't touch)

| Selector | Owner |
|---|---|
| `data-action="expandRoll"` on `.dice-roll` | Foundry's built-in dice-tooltip toggle |
| `closest('.message')` | Foundry chat-message ancestor — set by core, not us |
| `data-control=*` on combat-tracker buttons | Foundry CombatTracker class — must use exact attribute set |
| `combatant`, `directory-list`, `directory-item`, `combat-control`, `combat-button`, `combatant-control` | Foundry CombatTracker DOM contract |

### 3e. Vestigial decorator (cleanup candidate, NOT P11 scope)

`data-handle-change` appears on 18 inputs/selects across the dialog
templates but has **zero JS consumers** (`grep` returns 0 hits across
`module/`). It's a legacy decorator from a removed event binding. It's
harmless to leave; cleanest is to drop it during P11 ship of any
touched template. Recommendation: drop opportunistically while
rewriting touched templates, do not add to new markup.

---

## 4. Architectural decisions for P11

### Decision (c11-1) — Chat-card scoping marker class

The placeholder header in `styles/elysium-chat.css` (P7) already
captured this: chat cards render outside `.application.elysium`
(they live in Foundry's chat log). The v1.0.0 chat CSS needs its own
root marker class so its selectors don't depend on the sheet scope.

**Recommendation**: Adopt `.elysium-chat-card` as the v1.0.0 chat-card
root class, applied to the outer `<form>` of every Elysium-emitted
chat card. Wrap all v1.0.0 chat-card rules under it.

**Co-existence with Phase D mount-point selector**: The Phase D code at
`combat-card-buttons.mjs:94` looks up `form.elysium.gr-card`. We keep
`elysium` and `gr-card` on the form (they're JS hooks per §3b) and
add `elysium-chat-card` as a third class:

```html
<form class="elysium gr-card elysium-chat-card">
```

This layered-class pattern is the same audit-5 lock pattern used
throughout P9/P10. New CSS rules target `.elysium-chat-card`, never
`.gr-card`. Legacy rules for `.gr-card` get retired only after the last
consumer is rewritten (and even then, only if a grep confirms zero
non-legacy reads).

Cast-card and the four casting-dialog islands keep their existing
scope roots (`.elysium-cast-card`, `.elysium-manip-dialog`,
`.elysium-custom-spell-builder`, `.elysium-tier-choice-dialog`).
The new shared chat CSS rules (chip, badge, divider) can be reused
inside those islands by adding `.elysium-chat-card` alongside, or by
hoisting the shared rules to apply to `.elysium-chat-card, .elysium-cast-card`
selectors.

### Decision (c11-2) — Dialog scoping marker class

Dialogs render inside Foundry's `DialogV2` window which carries the
`elysium` class (from `ElysiumDialog.DEFAULT_OPTIONS.classes`). Today's
dialogs use `<form class="elysium">` as their inner root. The
ApplicationV2 casting dialogs already adopt distinct scoping roots
(`.elysium-manip-dialog`, etc.) — that pattern works.

**Recommendation**: Adopt `.elysium-dialog` as the v1.0.0 dialog
inner-root marker class, applied to the outer `<form>` / `<section>`
of every Elysium-emitted DialogV2 dialog. The 10 generic dialogs in
`templates/dialog/` adopt it on their root element. ApplicationV2
casting dialogs keep their existing island roots (they're already
distinct CSS namespaces with full coverage).

### Decision (c11-3) — Vocabulary harmonisation strategy for the 4 v1.0.0 islands

`cast-card.hbs`, `manipulation-dialog.hbs`, `custom-spell-builder.hbs`,
and `tier-choice-dialog.hbs` are already in v1.0.0-shaped markup, but:

1. They predate the design tokens — every color is a hardcoded `rgba()`
   or a `--ely-legacy-*` fallback.
2. Each has its own island vocabulary (`elysium-cast-*`, `elysium-manip-*`,
   `csb-*`, `tcd-*`) — none of which align with the shared `elysium-*`
   vocabulary established in P7-P10 (section-card, chip, field-row,
   etc.).
3. cast-card's background gradient (`rgba(245, 235, 215, 0.4)`) is a
   light-parchment look that clashes with the locked dark theme.

Three options to consider:

- **(A) Leave the islands alone, retoken-only** — Replace the hardcoded
  colors with token references but keep the markup, class names, and
  CSS scoped sections as-is. Smallest blast radius; preserves visual
  identity (after retoning); ships fast.
- **(B) Full harmonisation** — Rewrite all 4 to use the shared v1.0.0
  vocabulary (`elysium-section-card`, `elysium-chip`, etc.) the way
  item sheets do. Maximum design coherence; largest blast radius;
  needs careful regression testing of the cast pipeline.
- **(C) Hybrid** — Retoken first (cluster 1), then if time/budget allows,
  do a follow-up harmonisation cluster later in P11 or punt to P12.

**Recommendation**: Option (C). Retoken in cluster 1 alongside building
out `elysium-chat.css`. Defer harmonisation evaluation to after the
legacy chat cards land — by then we'll have shared chat partials
(chip, success-pip strip, participant-row) and can assess concretely
whether collapsing the 4 islands onto them produces a net simplification.
This matches the audit-5 lock discipline (preserve behaviour first;
retire vocabularies later only after the consumer count proves it safe).

Specifically for the cast-card's light-parchment background — that's a
**visual mismatch with the locked dark theme**, not just a vocabulary
question. Recommend fixing in cluster 1's retoken pass: switch to
`var(--ely-surface-card)` (#1a1a1a) and `var(--ely-text-body)` (#e8e6e1).

### Decision (c11-4) — Shared chat partials taxonomy

Across the 11 legacy chat templates, four patterns appear repeatedly:

1. **Card header** — bold label, optional close/resolve buttons
2. **Participant row** — actor portrait + roll-details strip + success/fail pip annotation
3. **Roll-tooltip block** — owner-gated hidden detail block (`rollHidden`/`bottom-line`)
4. **Resolve/close footer** — GM-only `cardbutton` pair

**Recommendation**: Extract these as shared partials in
`templates/chat/parts/`:

- `chat-card-shell.hbs` — outer `<form class="elysium gr-card elysium-chat-card">` wrapper with title slot
- `chat-card-participant-row.hbs` — actor portrait + name + (rollVal, tooltip) — accepts entry context
- `chat-card-success-pip.hbs` — the 0/1/2/3-pip success/fail/fumble pip strip driven by `resultLevel`
- `chat-card-tooltip-rows.hbs` — owner-gated hidden detail rows
- `chat-card-resolve-footer.hbs` — GM-only resolve+close button pair, accepts the `data-preset` value

This mirrors the P10 `templates/item/parts/` taxonomy. Pre-loaded once
in `init.mjs` via `loadTemplates(...)` (the existing partial-registration
pattern from P9/P10 item parts).

Cluster sequencing (§5) builds the partials in cluster 1 and consumes
them in clusters 2-4.

### Decision (c11-5) — Sequencing for the group-roll quartet

`roll-combat.html`, `roll-opposed.html`, `roll-combined.html`,
`roll-cooperative.html` share ~90% of their markup. The variations are:

- Card label key (`Elysium.card.CB`/`OP`/`GR`/`CO`)
- Resolve `data-preset` value (`resolve-cb-card`/`-op-card`/`-gr-card`/`-co-card`)
- "Crown" indicator on highest-rolling participant (only combat + opposed; not combined / cooperative which compute partial successes)
- Computed-success block at the bottom of combined + cooperative when closed (singular highest roll for combined; per-participant success/fail strip for cooperative)

Two options:

- **(A) Single shared partial with conditional slots** — All four
  consume one `chat-card-grouproll.hbs` partial driven by context flags
  (`hasCrown`, `hasComputedSuccess`, `successLayout: 'single' | 'strip'`).
- **(B) Two partials** — `chat-card-grouproll-simple.hbs` (cb/op) and
  `chat-card-grouproll-resolved.hbs` (gr/co), with a thin per-card
  template wrapping each.

**Recommendation**: Option (A). The behavioural difference is captured
fully in context flags; a single partial keeps the visual logic in one
place. Each per-card template becomes a 10-line consumer that sets
`cardLabel`, `resolvePreset`, and the success-layout flag, then includes
the partial. Total markup volume drops from ~340 LOC across 4 files to
~150 LOC (1 partial + 4 thin wrappers).

### Decision (c11-6) — Cast-card co-residence with new shell partials

`cast-card.hbs` is already in a distinct shape (state-machine
in-progress / completed / abandoned) and uses its own attempts-log,
manipulation summary, and tradition-tagged card-border styling. **It
does not naturally fit the group-roll shell**.

**Recommendation**: Leave `cast-card.hbs` standalone (not consuming
the group-roll partials), but retoken its color values to use design
tokens in cluster 1. Reconsider full harmonisation in cluster 6 per
c11-3.

### Decision (c11-7) — Combat-tracker template treatment

`combat-tracker.html` is a Foundry core template override. Its markup
structure, class names, and `data-control` attribute set are dictated
by core CombatTracker code. Touching the structure breaks turn ordering.

**Recommendation**: Treat combat-tracker as a **cosmetic-only CSS
restyle**, no template structural changes. The template stays at
alpha.44 markup; new CSS rules under `.elysium-chat-card`-adjacent
scope (e.g. `.combat-sidebar.elysium-combat-tracker`) restyle the
visible surface only. Lands as the final cluster (cluster 7) or punts
to P12.

If smoke surfaces a layout problem CSS can't address without structural
changes, surface that finding and revisit — but the default plan is
"do not touch the markup".

### Decision (c11-8) — Inline-HTML chat content is OUT OF P11 SCOPE

The 51 `ChatMessage.create({content: ...})` callsites that build inline
HTML strings (covering-stance, charge-ui, outmanoeuvre, engagement-ui,
weapon-wear, armor-wear, sustain, spell-learning, etc.) are not P11
template work. P11 changes their **visual side effects** automatically
via the shared chat-CSS rules they consume (where they use scoped
wrapper classes), but no JS-string edits ship in P11.

**Recommendation**: Confirm this scope-cut. If a specific inline-HTML
card needs immediate restyle, surface it as a discrete finding during
smoke and decide then.

### Decision (c11-9) — Cluster sequencing

Recommended cluster plan (7 clusters across the phase):

| Cluster | Scope | Approx. LOC touched | Risk |
|--:|---|--:|---|
| C1 | Foundation: build `elysium-chat.css` + 5 shared partials + retoken the 4 v1.0.0 islands (cast-card, manipulation, csb, tcd). Also ships the `audit-0` CHANGELOG fix. | ~600 CSS + 5 partials + ~200 LOC retokening | Med — first chat CSS work; cast-card has live consumers in the cast pipeline |
| C2 | Group-roll quartet: roll-combat / roll-opposed / roll-combined / roll-cooperative onto shared grouproll partial | -190 LOC net (~340 → ~150) | Med — Phase D button injection sites; smoke each card |
| C3 | Singleton-roll cards: roll-result / roll-damage / roll-armor / quick-combat | ~225 LOC touched | Low — fewer JS dependencies, simpler shapes |
| C4 | Chat micro-cards: XP-result / rollStats / itemDescription | ~40 LOC touched | Low — tiny templates |
| C5 | Generic dialogs (the 10 in `templates/dialog/`) | ~235 LOC touched | Low — V14 DialogV2 form harvesting is class-agnostic |
| C6 | Optional: v1.0.0-island harmonisation evaluation. If green-light after C2-C5, rewrite cast-card / manipulation / csb / tcd onto the shared partial vocabulary. Else punt to P12. | TBD | Med-High if pursued |
| C7 | Combat-tracker cosmetic-only restyle, or punt to P12 | ~50 CSS LOC | Low if cosmetic-only |

**Recommendation**: Lock C1-C5 firmly; defer the C6 go/no-go to after
C5 smoke; treat C7 as a small final ship or punt-to-P12 decision at
that point. This matches the P10 pattern (6 clusters across alpha.38-44
including a "let it emerge" sequencing for late clusters based on what
the early ones revealed).

### Decision (c11-10) — Smoke methodology

Two distinct smoke surfaces in P11:

- **Chat-card smoke** — Chat-message rendering is straightforward to
  invoke from the world console (`ChatMessage.create(...)` with a
  flag-shaped payload). Use **offline-render** for the templates
  themselves (`foundry.applications.handlebars.renderTemplate(path, ctx)`
  with a fixture context) to catch HTML-shape regressions without
  needing live rolls. Round-trip with one live roll per card type
  before closing each cluster.
- **Dialog smoke** — Generic dialogs are pure form layouts; offline-
  render is sufficient. ApplicationV2 casting dialogs (manipulation,
  csb, tcd) have lifecycle behaviour (action handlers, render-on-state-
  change) — these need a live open-and-interact smoke.

Bridge content-safety filter awareness (Rule 8): chat-card class names
include strings like `elysium-cast-card[data-tradition="arcane"]` —
the filter can chunk these on the bridge. Use char-code reconstruction
or chunked reads when bridge output is blocked. Verify via source-tree
read whenever bridge output is suspect.

### Decision (c11-11) — i18n coverage for cluster sequencing

**Pre-existing i18n state** (audited 2026-05-15):
- 58 distinct `Elysium.X` literals used across `templates/chat/` and
  `templates/dialog/`
- 57 resolve in `lang/en.json`
- **1 missing**: `Elysium.flatModHint` (referenced in `difficulty.hbs:36`
  as a tooltip text). Fix in cluster 5 (where difficulty.hbs ships).
- Pre-existing lang-parity gap: en has 1259 keys, es and fr each have
  1058 (gap = 205 keys, larger than the 35 captured in HANDOFF-state.md).
  Tracked separately as the P12 lang-parity sweep; not P11 work.

**Going forward**: every new i18n key P11 introduces lands in all three
of en/es/fr with the en value placeholder-prefixed in es/fr (e.g.
`"[ES] Cast"`) so the lang-parity sweep at P12 has a uniform target.

### Decision (c11-12) — Damage-type token usage

cast-card.hbs displays a damage-type tag on damage-dealing spells via
`.elysium-cast-damage-type-tag.elysium-damage-{type}` (one class per
type: `fire`, `cold`, `electric`, `physical`, etc.). Today those colors
are hardcoded.

The token file already defines damage-type semantic tokens
(`--ely-accent-fire`, `--ely-accent-cold`, `--ely-accent-electric`,
`--ely-accent-poison`, `--ely-accent-corrosive`, `--ely-accent-physical`,
`--ely-accent-distortion`, `--ely-accent-mind`, `--ely-accent-air`).

**Recommendation**: In C1's cast-card retoken, replace hardcoded
damage-type colors with the matching token. Each `.elysium-damage-X`
rule reduces to a one-line `background: var(--ely-accent-X);` (or
`subtle` variant for tag fills).

### Decision (c11-13) — Legacy CSS retirement timing

Per the P7 framing-B decision, `css/legacy.css` (1639 LOC) stays in
the load order until P12 even after all consumers are retired. P11
follows the same discipline: when a chat-card template stops using
`.gr-card`-only / `.dice-roll`-only / etc. via the rebuild, those CSS
blocks become orphaned but DO NOT get deleted in P11.

P11 ships a running tally of newly-orphaned blocks in each cluster's
changelog entry. P12 does the final retirement sweep.

**Exception**: The Phase D mount-point selector `form.elysium.gr-card`
requires `.gr-card` to stay on rebuilt markup (§3b). That class never
becomes orphaned; only its STYLING moves from `.gr-card { ... }` rules
to `.elysium-chat-card { ... }` rules.

### Decision (c11-14) — `data-handle-change` cleanup

This decorator has zero JS consumers but appears on 18 templates' inputs
(15 are in P11 scope). It costs 1 line of legacy decoration per input.

**Recommendation**: Drop it opportunistically while rewriting any
touched template. Do not add it to new markup. Do not do a separate
sweep of untouched templates in P11 — those drops land at P12.

---

## 5. Cluster-1 deliverable specifics (to confirm before coding starts)

Cluster 1 is the foundation cluster — gets the most concrete pinning.
The decisions above set the architecture; this section lists what
cluster 1 SPECIFICALLY ships, so cluster 1 audit (when we get there)
already has the answers.

**Files added**:
- `templates/chat/parts/chat-card-shell.hbs`
- `templates/chat/parts/chat-card-participant-row.hbs`
- `templates/chat/parts/chat-card-success-pip.hbs`
- `templates/chat/parts/chat-card-tooltip-rows.hbs`
- `templates/chat/parts/chat-card-resolve-footer.hbs`

**Files modified**:
- `styles/elysium-chat.css` — built out from 25-line placeholder to ~600
  LOC of v1.0.0 chat-card vocabulary, including new shared rules for the
  partials above and retoned shared rules for the 4 islands.
- `templates/chat/cast-card.hbs` — retoken pass; no markup changes
  beyond adding `elysium-chat-card` class alongside `elysium-cast-card`
  on the root, plus the damage-type token swap.
- `templates/casting/manipulation-dialog.hbs` — retoken; add
  `elysium-dialog` alongside `elysium-manip-dialog` on root.
- `templates/casting/custom-spell-builder.hbs` — retoken; add
  `elysium-dialog` alongside `elysium-custom-spell-builder` on root.
- `templates/casting/tier-choice-dialog.hbs` — retoken; add
  `elysium-dialog` alongside `elysium-tier-choice-dialog` on root.
- `module/init.mjs` — register the 5 new chat-card partials via the
  existing `loadTemplates` block.
- `CHANGELOG.md` — apply the audit-0 P11/P12 scope-correction (with
  retroactive note that the alpha.44 "Next" paragraph drifted from the
  ROADMAP).
- `system.json` — bump to `1.0.0-alpha.45`.

**Files NOT touched**:
- Any legacy `.html` chat template — those land in C2/C3/C4
- Any dialog template — those land in C5
- `combat-tracker.html` — lands in C7 or punts to P12
- `css/legacy.css` — orphaning happens in C2-C5; deletion is P12

**Lang impact**: zero new i18n keys in cluster 1 (the new partials are
styling-only consumers of existing context). `Elysium.flatModHint`
addition is cluster 5 work.

---

## 6. Out of scope for P11

- Inline-HTML chat content in `module/elysium/mechanics/*` and
  `module/casting/*` JS (51 emit-sites). Restyling reaches them via
  shared CSS rules where they share wrapper classes; no JS edits ship.
- `css/legacy.css` retirement (orphaning is tracked; deletion is P12).
- The pre-existing lang-parity gap (en→es/fr = 205-key drift). P12.
- Statistics tab redesign (P12 carryover from P9 cluster 4).
- Bio-section CRUD migration to V14 actions (P12 carryover from P9).
- Magic-development grids (P12 carryover from P9 cluster 5).
- Weapon DataModel/template dead-code branches (P12 carryover from
  P10 cluster 5).
- DataModel cleanup for form handlers maintaining legacy fields (P12).
- `data-handle-change` decorator sweep across untouched templates (P12).

---

## 7. Smoke risks specific to P11

1. **Phase D mount-point regression** — If any rebuilt template drops
   the `form.elysium.gr-card` class set, the GM-action panel (fumble /
   crit-armor / crit-parry buttons) silently stops appearing on resolved
   weapon cards. Symptom is invisible at render time — only surfaces
   when a critical or fumble actually happens in play. **Mitigation**:
   smoke each rebuilt group-roll card with a forced-critical roll
   fixture; verify the GM panel injects.

2. **`triggerChatButton` regression** — If `.cardbutton` is dropped from
   any resolve/close/remove button, clicking does nothing. **Mitigation**:
   per-cluster smoke must include clicking each emitted button on a
   live card.

3. **Cast-card retoken regression** — cast-card has the most complex
   conditional-render tree (in-progress / completed / corrupted /
   abandoned / fumbled / wild-magic). A retoken edit could miss a
   nested rule that only shows in one state. **Mitigation**: cluster 1
   smoke must render fixtures for all 5 states (offline-render is fine
   for this).

4. **Owner-gated content disclosure regression** — If `.owner-only` is
   misapplied or its `data-partic-id`/`data-partic-type` dataset attrs
   get malformed during rebuild, players might see GM-only tooltip
   contents (raw difficulty, hidden mods). **Mitigation**: smoke each
   card type as both a GM and a non-GM player to verify visibility gates.

5. **Combat-tracker breakage** — Restyling combat-tracker is high-risk
   if a CSS rule accidentally `display: none`s a `data-control` button,
   or if a flex change reorders the strip. **Mitigation**: combat-tracker
   gets the most conservative CSS treatment — additive only, no rule
   resets without grep-confirming what they retire.

6. **ApplicationV2 action-handler binding** — V14 action-map bindings
   live on the dialog's `tag` element; if a retoken misses adding the
   new marker class to the right root, action wiring still works (it's
   not class-driven) but styling targets miss. **Mitigation**:
   verify after retoken that scoped rules actually apply (DevTools
   computed-style spot check).

---

## 8. Open questions for user lock-in

These are decisions the audit recommends a particular answer for but
wants explicit user input on:

1. **Audit-0 (CHANGELOG fix scope)** — Apply the alpha.44 "Next"
   correction in cluster 1, or defer to a standalone bump?
   Recommendation: fold into cluster 1.

2. **c11-3 (v1.0.0 island harmonisation strategy)** — Option A retoken-only,
   B full harmonisation now, or C retoken first / re-evaluate later?
   Recommendation: C.

3. **c11-6 (cast-card co-residence)** — Leave cast-card as a standalone
   vocabulary even after the new shared partials exist, or rebuild onto
   the partials? Recommendation: leave standalone in cluster 1; revisit
   in cluster 6 per c11-3.

4. **c11-7 (combat-tracker treatment)** — Cosmetic-only restyle in C7
   ship, or punt entirely to P12? Recommendation: do C7 if there's
   capacity at end of phase; otherwise punt — there's a real risk
   ratio mismatch for re-styling a Foundry-core template.

5. **c11-9 (cluster sequencing)** — The 7-cluster plan above. Lock
   C1-C5 now? Or chunk differently?

6. **Visual direction for the legacy 11 cards** — The 4 v1.0.0 islands
   established their own aesthetics (the cast-card's success/fail
   banners, the manipulation-table layout, the tier-card grid). What
   single design direction should the rebuilt legacy cards take? Three
   options surface from the existing materials:
   - **(i) Cast-card-inspired** — bordered card with header strip,
     bone-trim divider, dark crimson result banners. Visually rich.
   - **(ii) Item-sheet-inspired** — section-card with rounded corners,
     subtle border, chip + field-row composition (the P10 design
     language). Visually consistent with the sheet UI.
   - **(iii) Hybrid** — borrow chip/badge components from the item
     sheet, but use a tighter card shape (chat-message column is
     narrower than a sheet).
   Recommendation: (iii). The chat column is constrained (typically
   ~250px wide on default Foundry sidebar); cast-card-style padding
   would feel cramped, but the bare item-sheet vocabulary may feel too
   spare for combat results. The hybrid lets us reuse chip + badge
   tokens with chat-specific spacing tokens.

7. **Per-card behaviour preservation vs simplification** — Several
   legacy cards have small UX inconsistencies (e.g. `roll-combat.html`
   and `roll-opposed.html` have identical markup but slightly different
   conditional flows for the closed state; `roll-combined.html` and
   `roll-cooperative.html` each compute the closed-state summary
   slightly differently; `roll-result.html` is the only card that
   surfaces a hit-location tag via `elysium-hitloc-tag`). Audit-then-
   stop recommends preserving every behaviour during the migration
   per Rule 7. Confirm: yes, preserve all current per-card UX in
   cluster 2-4 ships, defer any UX consolidation to P12?

---

## 9. Ready-to-go checklist (when locked, cluster 1 begins)

- [ ] User confirms or revises decisions audit-0 through c11-14
- [ ] User confirms cluster sequencing (§4.c11-9) is acceptable
- [ ] User confirms cluster-1 deliverable list (§5)
- [ ] User confirms the 7 open questions (§8)
- [ ] User confirms inline-HTML JS chat content is out of P11 scope (§6)
- [ ] Smoke methodology (§4.c11-10) accepted: offline-render + 1 live per
      card type per cluster, plus the per-risk mitigations in §7

---

## 10. Phase budget estimate

- C1 foundation: ~1 ship (alpha.45)
- C2 group-roll quartet: ~1 ship (alpha.46)
- C3 singleton-roll cards: ~1 ship (alpha.47)
- C4 chat micro-cards: combinable with C3 or solo (alpha.47/48)
- C5 generic dialogs: ~1 ship (alpha.48 or .49)
- C6 island-harmonisation evaluation: 0-1 ships (alpha.50 if pursued)
- C7 combat-tracker restyle: 0-1 ships (alpha.51 if pursued)

Net: ~4-7 alpha ships across P11, depending on C6/C7 go/no-go and
whether C3/C4 collapse into one. Mirrors the P10 cluster cadence
(7 ships, 6 clusters, alpha.38-44).
