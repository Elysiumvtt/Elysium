# P10 prep audit — item-sheet rebuild (all 23 item types)

Captured 2026-05-14, after P9 close (alpha.37 smoke pass).
Audit-then-stop deliverable. **No code shipped from this document.**
User approval on the locked decisions opens cluster 1.

## 0. Phase posture in three sentences

P9 rebuilt the **actor** sheet's tab content against the v1.0.0 design
language. P10 rebuilds the **item** sheets — every type a character or
NPC can own. Goal: every item sheet uses the new dark-bone-crimson
identity, retires legacy CSS class names within scope, preserves all
data and action wiring, ships in audited clusters with smoke pass
between each.

## 1. Surface inventory — 23 item types in scope

Sheets and templates exist for all 23 registered Item types
(verified against `module/setup/register-sheets.mjs:44–157`).

| # | Type | Sheet class LOC | Template LOC | PARTS count | Tier |
|--:|---|--:|--:|--:|---|
|  1 | reputation | 123 | 10 | 5 (header/tabs/details/description/gmNotes) | T1 |
|  2 | failing    | 123 | 15 | 5 | T1 |
|  3 | wound      | 106 | 17 | 4 (no description/gmNotes; has effects) | T1 |
|  4 | passion    | 124 | 20 | 5 | T1 |
|  5 | powerMod   | 121 | 20 | 5 | T1 |
|  6 | mutation   | 129 | 30 | 5 | T1 |
|  7 | gear       | 143 | 39 | 5 | T1 |
|  8 | allegiance | 136 | 49 (+13 benefits) | 6 (extra `benefits` tab) | T1 |
|  9 | persTrait  | 121 | 47 | 5 | T1 |
| 10 | super      | 278 | 70 | 5 | T2 |
| 11 | personality| 353 | 80 | 5 | T2 |
| 12 | mysticism  | 135 | 101 | 5 | T2 |
| 13 | hit-location| - | 105 | 5 | T2 |
| 14 | skillcat   | 143 | 117 | 5 | T2 |
| 15 | culture    | 397 | 126 | 5 | T2 |
| 16 | armor      | 145 | 134 | 5 | T2 |
| 17 | divine     | 170 | 187 | 5 | T2 |
| 18 | arcane     | 301 | 188 | 5 | T3 |
| 19 | ability    | (T1-shell) | (-) | 5 | T2 |
| 20 | skill      | 340 | 223 (+17 header) | 5 (+ skill.header subpartial) | T3 |
| 21 | sorcery    | 191 | 248 | 5 | T3 |
| 22 | weapon     | 191 | 341 | 5 | T3 |
| 23 | career     | 416 | (3 templates: 33+5+15) | 7 (`skills` / `powers` / `wealth` instead of single `details`) | T3 |

**Net**: ~4530 LOC of sheet classes + ~2474 LOC of templates =
~7000 LOC of surface area. Largest single template is `weapon.detail.hbs`
(341 lines); largest sheet class is `career.mjs` (416 lines).

### 1a. Legacy CSS coverage (v1.0.0 elysium-* class adoption: **0%**)

Every existing item template uses the legacy class vocabulary, NOT
the v1.0.0 `elysium-*` scope. Top legacy classes consumed:

| Class | Refs across all item templates | Purpose |
|---|--:|---|
| `skill-display` | 172 | Label text for an input/value pair |
| `centre` | 147 | Text-align utility |
| `boxed` | 79 | Bordered value pill |
| `stat-input` | 71 | Generic input wrapper |
| `weapon-input` | 60 | Inline form-row layout (despite name, used everywhere) |
| `new-row` | 45 | Spacer between blocks |
| `bold` | 43 | Weight utility |
| `weapon-display` | 40 | Read-only value with weapon styling |
| `skill-cat` | 35 | Category badge |
| `toggle-active` | 34 | Boolean-toggle button state |
| `item-title` | 34 | Header label |
| `font14` | 30 | Size utility |

These rules live in `css/legacy.css` (1714 LOC) and `css/npc.css`
(298 LOC) plus `styles/elysium.css` (3120 LOC). Together: ~5100 lines
of legacy CSS that P10 will progressively orphan as item types are
rebuilt. Per the P7 framing-B decision the legacy files stay until P12,
even after every consuming markup is retired — P12 owns final deletion.

### 1b. Existing item-sheet shell architecture

Every item sheet (except `wound` and `career`) follows an identical
5-PART layout (and `career` follows a 7-PART variant):

```
PARTS = {
  header:      'item.header.hbs'                  ←  shared shell
  tabs:        'global/parts/tab-navigation.hbs'  ←  shared shell
  details:     '<itemType>.detail.hbs'            ←  per-type body
  effects:     'item.active-effects.hbs'          ← shared (most types)
  description: 'item.description.hbs'             ←  shared shell
  gmNotes:     'item.gmnotes.hbs'                 ←  shared, GM-only
}
```

`career` exposes three body PARTS (`skills` / `powers` / `wealth`) instead
of one `details`. `allegiance` adds a `benefits` tab. `wound` skips
`description`/`gmNotes` but keeps `effects` (active-effects from
wounds matter at runtime).

**The shared PARTS (header, tabs, description, gmnotes, active-effects)
are reusable scaffold** — rebuilding them once in v1.0.0 affects all
23 sheets. This is the cluster-1 anchor: a shared scaffold ship.

### 1c. Action handlers in scope

Only **6 distinct actions** fire from item-sheet markup:

- `onEditImage` — header image edit (base sheet)
- `editBRPid` — header frame button (base sheet, every sheet)
- `itemToggle` — boolean field flip (base sheet)
- `addItemEffect` / `openActiveEffect` — active-effects tab
- `ftAdd` / `ftRemove` — career form/technique skill adds (career only)

All handlers are already registered in either `base-item-sheet.mjs`
or each subclass. P10 preserves them verbatim; rebuilds touch only
templates + CSS (parallel to how P9 handled magic action handlers).

## 2. Architectural decisions for P10

### Decision (audit-1) — Shell-first sequencing

The shared shell partials (`item.header`, `tab-navigation`,
`item.description`, `item.gmnotes`, `item.active-effects`) are
consumed by 23 sheets. Rebuild them FIRST as cluster 1, before any
type-specific detail rebuild. Same pattern as P9's cluster-1
shared-scaffold ship.

Cluster 1 = a fully v1.0.0-styled scaffold + a single item type as the
"validator" (we recommend **gear** — simplest non-trivial detail, 39
template LOC, 7 form fields, no specialized data).

Recommendation: **lock**.

### Decision (audit-2) — Per-item-type tab decision: keep-or-drop

The audit-2 lock is **per-item-type case-by-case**, not a blanket
policy, per user direction. Audit recommendations:

| Type | Detail | Effects | Desc | GMNotes | Recommendation |
|---|---|---|---|---|---|
| reputation | 10L | — | shared | shared | **Single-page** (detail trivial, fold description below) |
| failing    | 15L | — | shared | shared | **Single-page** |
| wound      | 17L | inline | — | — | **Single-page** (no desc/gmnotes today) |
| passion    | 20L | — | shared | shared | **Single-page** |
| powerMod   | 20L | — | shared | shared | **Single-page** |
| mutation   | 30L | — | shared | shared | **Single-page** |
| gear       | 39L | — | shared | shared | **Keep tabs** (gear has price/encumbrance/etc.; long-form desc warrants its own tab) |
| persTrait  | 47L | — | shared | shared | **Keep tabs** |
| allegiance | 49L+13L benefits | — | shared | shared | **Keep tabs** (extra benefits tab is content-bearing) |
| super      | 70L | — | shared | shared | **Keep tabs** (description is the powers' rules text) |
| personality| 80L | — | shared | shared | **Keep tabs** |
| mysticism  | 101L | — | shared | shared | **Keep tabs** (talents/feats sub-blocks) |
| hit-location| 105L | — | shared | shared | **Keep tabs** |
| skillcat   | 117L | — | shared | shared | **Keep tabs** |
| culture    | 126L | — | shared | shared | **Keep tabs** (ancestry data is content-bearing) |
| armor      | 134L | shared | shared | shared | **Keep tabs** |
| divine     | 187L | — | shared | shared | **Keep tabs** |
| arcane     | 188L | — | shared | shared | **Keep tabs** |
| ability    | (small) | — | shared | shared | **Keep tabs** |
| skill      | 223L | — | shared | shared | **Keep tabs** |
| sorcery    | 248L | — | shared | shared | **Keep tabs** |
| weapon     | 341L | shared | shared | shared | **Keep tabs** |
| career     | 33+5+15L | — | shared | shared | **Keep tabs** (3-tab structure is its primary navigation) |

6 of 23 go single-page; 17 keep tabs. Single-page candidates are all
short, simple items (≤30L details) where the tab strip's chrome
exceeds the value of separating sections. For single-page sheets,
description content still renders — just inlined below the detail
block rather than in a tab.

The single-page mode also implies sheet-class changes: those 6
sheets drop their `tabs`/`description`/`gmNotes`/`effects` PARTS and
become 2-PART (`header`+`details`) sheets. The detail template
embeds the description directly (with GM-notes inline conditionally
when `isGM`).

Recommendation: **lock per the table above**; user can adjust any
individual row before cluster execution.

### Decision (audit-3) — Sheet width — recommendation requested

Per user direction, locking width based on recommendation.

Current per-class widths (sampled):
- base default 520
- weapon overrides to 600
- armor / sorcery / arcane / skill / career probably 520 (default)

D&D-Beyond-style item cards are typically 500–600 wide. v1.0.0
character sheet is 1200×900. Item-sheet content varies a lot — weapon
has 2-column dense layout; reputation has 1 field.

**Recommendation: standardize on 560×640 baseline for v1.0.0 item
sheets, with a wider 720×720 variant for content-heavy types**:
- 560×640 → single-page items + most tabbed items (description tab
  comfortably fits a paragraph + ProseMirror toolbar at 560)
- 720×720 (the "wide" variant) → weapon, armor, arcane, sorcery,
  divine, mysticism, skill, career, culture — items with multi-column
  detail layouts.

The wider variant fits two-column grids cleanly (D&D-Beyond cards
average ~700px at desktop). Going wider than 720 starts dominating
the player's viewport; going narrower than 560 cramps ProseMirror.

The two-width strategy means **one extra design token**:
`--ely-item-sheet-width` (560 default) and
`--ely-item-sheet-width-wide` (720). Sheet classes opt in via
`DEFAULT_OPTIONS.position.width` override. Heights track the width
1:1.14 ratio (640:560 ≈ 720:630, rounded to 720).

Recommendation: **lock the 560/720 two-tier model.**

### Decision (audit-4) — Shared-partial taxonomy

P9 introduced a `tab-section-card-header` + `improve-checkbox` +
`section-card-header-button` shared-scaffold vocabulary. P10 should
reuse them where applicable AND add item-sheet-specific shared
partials for repeating row patterns. Proposed additions (registered
in `init.mjs:2a` per the cluster 1 pattern):

| Partial | Purpose | First-use cluster |
|---|---|---|
| `item-shell-header.hbs` | v1.0.0-restyled header (replaces `item.header.hbs`) | C1 |
| `item-shell-tabs.hbs` | v1.0.0-restyled tab nav (replaces `tab-navigation.hbs` for items) | C1 |
| `item-shell-description.hbs` | v1.0.0 description tab (replaces `item.description.hbs`) | C1 |
| `item-shell-gmnotes.hbs` | v1.0.0 GM notes tab | C1 |
| `item-shell-effects.hbs` | v1.0.0 active-effects tab | C1 |
| `item-field-row.hbs` | label + input/display pair (the "skill-display + stat-input" pattern, 172+71 legacy refs) | C1 |
| `item-field-grid.hbs` | 2-column grid wrapper for the same | C1 |
| `item-chip.hbs` | small read-only value pill (replaces `boxed centre`) | C1 |
| `item-toggle.hbs` | boolean field with toggle visual (replaces `toggle-active`) | C2 |
| `item-section-card.hbs` | A complete section card with header + body — alias to the existing `tab-section-card-header` partial wrapped with a body div | C1 |

**Reuse from P9 (no rebuild needed):**
- `tab-section-card-header.hbs`
- `improve-checkbox.hbs`
- `section-card-header-button.hbs`
- The skill row / spell row / passion row partials (where any item
  detail renders sub-items, those rows are reusable)

### Decision (audit-5) — Active-effects tab — restyle, no functional change

The active-effects tab is the only non-trivial JS-bound surface
shared across item types (weapon / armor / wound use it). Its
internals invoke `ElysiumActiveEffectSheet.activateListeners`
which depends on specific class names. **The audit-5 lock**: P10
restyles the visual chrome but PRESERVES legacy class hooks that
`activateListeners` reads, exactly as P9 cluster 4 did for
bio-section CRUD.

The migration of active-effects to V14 action handlers is **deferred
to P12** alongside bio-CRUD. Lock-in expected mid-ship if a deeper
inspection reveals different needs.

Recommendation: **lock as restyle-only**; migration filed as P12.

### Decision (audit-6) — Item header re-design

The current `item.header.hbs` shows: type label, name input, image
(50×50). v1.0.0 should additionally surface key item state at a
glance: equipped/cost/AP/range for items where applicable. Audit
recommends a 3-zone header pattern matching the actor sheet's:

```
┌────────────────────────────────────────────────────────────┐
│ IMG │ NAME (display font, large)                          │
│ 64  │ TYPE LABEL + ELYSIUM_ID FINGERPRINT BADGE           │
│ ×64 │ HEADER CHIPS (per-type: cost / equip / cast / range)│
└────────────────────────────────────────────────────────────┘
```

Header chip set is per-type and prepared via context. Each item type's
sheet class adds 2–5 header chips in `_prepareContext` that bubble to
the shared `item-shell-header.hbs`. Single source of truth; sheet
classes own which chips fire.

Recommendation: **lock the 3-zone header pattern**, but defer the
exact chip set per item type to the cluster that ships that item.

### Decision (audit-7) — Cluster sequencing

Two competing axes:
1. **By complexity** — ship simple items first (T1), grow into
   complex ones (T3). Each ship is small; each smoke proves the
   shell scales.
2. **By usage frequency** — ship the most-used items first (weapon,
   skill, gear) so user-visible improvement comes earliest.

Audit recommends **axis 1 (by complexity)**, mirroring P9:
shell-scaffold ship first, then simplest items, then complex. Bugs
in the shared scaffold get caught early on simple items where the
blast radius is small; complex items inherit a battle-tested
scaffold by the time they arrive.

Proposed clusters (each its own audit lock + own alpha):

| Cluster | Items | Why grouped | Risk |
|---|---|---|---|
| **C1** — Shell scaffold + 1 validator | shared partials + **gear** | Validate scaffold against a simple non-trivial item | Med |
| **C2** — Tier 1 simple (8 items) | reputation, failing, wound, passion, powerMod, mutation, persTrait, allegiance | All ≤49L details, mostly single-page candidates | Low |
| **C3** — Tier 2 mid (8 items) | super, personality, mysticism, hit-location, skillcat, culture, armor, divine, ability | Multi-section detail, multi-tab, no specialized sub-systems | Med |
| **C4** — Magic items (arcane, sorcery) | arcane, sorcery | Tightly coupled to character-sheet's magic tab consolidation; spell items have multi-tier data + custom layouts | Med-High |
| **C5** — Skill + Weapon | skill, weapon | The two highest-traffic surfaces; most complex layouts (223L + 341L details) | High |
| **C6** — Career (multi-tab) | career | Three-tab variant + form/technique skill machinery | High |

Total: 6 clusters across alphas .38 → .43+ (some clusters may need
hotfixes after live smoke).

Recommendation: **lock the 6-cluster sequence**.

### Decision (audit-8) — Smoke pattern carries forward from P9

P9 cluster lessons all apply:
- offline-render smoke via `_prepareContext` + `_preparePartContext` +
  `renderTemplate`, parse via DOMParser
- bridge wedge avoidance — render+capture+close in same eval, never
  read rendered NPC sheet DOM directly, navigate-recovery on wedge
- audit-then-stop discipline before each cluster
- single-cluster ship + smoke before next
- live-click testing (vs offline-render) reserved for action-handler
  invocation verification on a new `data-action` emission

Sheet width changes mean visual regression baselines need re-locking
once cluster 1 ships and the new shell renders.

Recommendation: **lock**.

## 3. Out of scope for P10

- **Item compendium content updates** — no item compendium .db file
  changes; data shapes stay fixed. The `elysium-compendium` package
  continues at alpha.3.
- **Item DataModel changes** — schemas are P5/P6 territory and they're
  closed.
- **Migration of `editBRPid` / `editElysiumID` to a per-sheet action**
  — it's a base-sheet method that gets attached via `_renderFrame`;
  works against V14, no need to touch.
- **Active-effects-to-V14-actions migration** — P12 cleanup (audit-5).
- **Roll table or chat-card item surfaces** — P11 territory.
- **NPC sheet item rendering surfaces** — those are inside the actor
  sheet's right rails (P9 cluster 3 owns); the standalone item sheet
  rebuild here doesn't touch them.

## 4. Smoke risks specific to P10

1. **Active-effects regression** — the 3 sheets that use the effects
   tab (weapon, armor, wound) bind JS listeners on legacy class
   names. If the v1.0.0 restyle changes class names underneath the
   listener, effects-management goes silent (same failure mode as
   alpha.34's viewDoc bug). Mitigation: cluster 1 includes an
   action-handler invocation smoke on the effects tab as part of the
   gear validator (gear doesn't use effects, but the shell does, so
   the partial must still render cleanly).

2. **Width regression on existing per-class overrides** — weapon,
   armor, arcane have custom widths. The cluster 1 width-token
   change will need explicit override removal in those sheet
   classes. Audit-then-fix per cluster.

3. **Career multi-tab** — career.mjs (416 LOC) is the largest sheet
   class. The 3 PARTS (`skills`, `powers`, `wealth`) all have
   significant data prep in `_prepareContext`. Cluster 6 risk:
   rebuilding all three at once might cascade. Mitigation: ship
   career as its own cluster with a deliberate audit.

4. **ProseMirror inside the shared `description` partial** — the
   only HTMLField editor we ship across all 23 sheets. Already
   bridge-wedge-prone per side-finding #5. Mitigation: smoke pattern
   already accommodates it; no new risk introduced.

5. **Form auto-submit on input change** — every item sheet uses
   `submitOnChange: true` in the base. Restyled inputs that change
   the input name or wrapping markup risk silent data loss if the
   form selector breaks. Mitigation: ALL `name="system.X"` attrs are
   preserved verbatim during template rebuild; no markup change
   removes a `name` attribute.

## 5. Open questions for user lock-in

1. **p10-1**: Audit-2 per-item tab decisions (table in §2.audit-2).
   6 items go single-page; 17 keep tabs. Confirm the recommendations,
   or flag specific items to flip.

2. **p10-2**: Audit-3 sheet width — confirm 560/720 two-tier model
   with the 9 items in §2.audit-3's "wide" set, OR pick a different
   width baseline.

3. **p10-3**: Cluster 1 validator — recommended **gear** because
   simple non-trivial. User may prefer **weapon** (eats the biggest
   regression risk first) or **failing** (smallest possible). Each
   has tradeoffs; recommendation **gear** stands but is flippable.

4. **p10-4**: Cluster sequencing (§2.audit-7's 6-cluster plan) —
   confirm or rearrange. Notable consideration: shipping skill
   (cluster 5) BEFORE arcane/sorcery (cluster 4) might catch
   skill-shape bugs that arcane spells depend on. The recommended
   sequence ships arcane/sorcery first to settle their layout while
   the skill item's data shape remains alpha.36-stable.

5. **p10-5**: Active-effects scope — confirm audit-5's restyle-only
   approach with V14-actions-migration deferred to P12, OR commit
   to V14 actions migration as part of cluster 1.

6. **p10-6**: Header chips per-item-type — defer per-type chip set
   to its own cluster's prep (audit-6 recommendation), or lock all
   item types' chip sets here in the audit.

## 6. Ready-to-go checklist

- [x] 23 item types catalogued
- [x] Sheet class + template LOC measured per type
- [x] Legacy CSS class consumption survey complete
- [x] Existing shared-shell partials identified
- [x] Action handlers in scope confirmed (6 only)
- [x] Single-page candidates flagged (6 of 23)
- [x] Width recommendation locked (560/720 two-tier)
- [x] Cluster sequence drafted (6 clusters)
- [x] Smoke risks enumerated (5 distinct)
- [ ] User decision on 6 open questions (5 have recommendations + 1
      is a sequencing detail)
- [ ] Approval to open cluster 1

## 7. Phase budget estimate

Each cluster ≈ 1 alpha + possible hotfix per the P9 pattern.

| Cluster | Estimated alphas | Notes |
|---|--:|---|
| C1 | 1-2 | Scaffold ship; alpha A scaffold, alpha B if validator catches issues |
| C2 | 1 | 8 simple types in one ship — high cohesion |
| C3 | 1-2 | 9 mid-tier types; might split |
| C4 | 1 | Magic items |
| C5 | 1-2 | Skill + Weapon; may split if weapon's complexity warrants |
| C6 | 1-2 | Career multi-tab |
| **Total** | **6–10 alphas** | mapping roughly to .38 → .43+ |

ROADMAP estimate for P10 was "2 sessions"; this audit suggests 1–2
sessions if clusters cohere, possibly stretching to 2 if hotfixes
multiply or any cluster has a P9-cluster-5-style mid-smoke iteration
arc.

---

**Audit posture**: this document is read-only until user locks the 6
open questions. No code shipped from this prep.
