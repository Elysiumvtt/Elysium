import { ElysiumActiveEffectSheet } from '../../sheets/elysium-active-effect-sheet.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumWoundSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['wound'],
    position: {
      width: 560,
      height: 640
    },
    form: {
      handler: ElysiumWoundSheet.myWoundHandler
    }
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template: 'systems/elysium/templates/item/wound.detail.hbs',
      scrollable: ['']
    },
  }

  // Single-page — effects display is INLINED inside the details template
  // via item-singlepage-effects.hbs (audit-2 + c2-1 lock). The effects
  // context (effects/effectKeys/effectChanges) is still prepared in
  // _prepareContext below; the inlined partial reads them.
  static TAB_ORDER = null

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    context.effects = ElysiumActiveEffectSheet.getItemEffectsFromSheet(this.document)
    const changesActiveEffects = ElysiumActiveEffectSheet.getEffectChangesFromSheet(this.document)
    context.effectKeys = changesActiveEffects.effectKeys
    context.effectChanges = changesActiveEffects.effectChanges

    // Header chips per c2-2 lock — Damage value always; treated/untreated when owned.
    const chips = [{
      label: game.i18n.localize('Elysium.damage'),
      value: String(this.item.system.value ?? 0),
    }];
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.status'),
        value: this.item.system.treated
          ? game.i18n.localize('Elysium.treated')
          : game.i18n.localize('Elysium.untreated'),
      });
    }
    context.itemHeaderChips = chips;

    return context
  }

  // Activates the legacy class-hook listeners (audit-5 lock — preserved
  // through item-singlepage-effects.hbs's `active-effect-change-edit`).
  _onRender(context, _options) {
    ElysiumActiveEffectSheet.activateListeners(this)
  }

  //--------------------HANDLER----------------------------------
  static async myWoundHandler(event, form, formData) {
    if (!formData.object['system.value']) {
      formData.object['system.value'] = 0
    } else if (formData.object['system.value'] < 0) {
      formData.object['system.value'] = 0
    }
    await this.document.update(formData.object)
  }
}
