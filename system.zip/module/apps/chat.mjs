import { ElysiumCheck } from '../apps/check.mjs'
import { ElysiumActorDetails } from '../apps/actorDetails.mjs'

// v0.21.0: `addChatListeners (html)` removed — was a jQuery-based V12
// listener that bound `.cardbutton` click via `html.on(...)`. Replaced
// by `ElysiumChat.renderMessageHook` below which uses
// `querySelectorAll(...).forEach(b => b.addEventListener(...))` (native
// V14 API). The legacy function had no callers.

export class ElysiumChat {
  static async renderMessageHook(message, html) {
    ui.chat.scrollBottom()
    html.querySelectorAll(".cardbutton").forEach(b => b.addEventListener('click', ElysiumCheck.triggerChatButton));
    if (!game.user.isGM) {
      const ownerOnly = html.querySelectorAll('.owner-only')
      for (const zone of ownerOnly) {
        const actor = await ElysiumActorDetails._getParticipant(zone.dataset.particId, zone.dataset.particType)
        if ((actor && !actor.isOwner) || (!actor && !game.user.isGM)) {
          zone.style.display = 'none'
        }
      }
    }

    const gmVisibleOnly = html.querySelectorAll('.gm-visible-only')
    for (const elem of gmVisibleOnly) {
      if (!(game.user.isGM)) elem.style.display = 'none'
    }
    ui.chat.scrollBottom()
    return
  }
}
