/**
 * SuperDataModel — schema for items of type 'super' (super-power).
 *
 * Per P6.2 spec. Stored-schema-only. 18 compendium items in superpowers.db.
 *
 * Super-powers are the system's flexible "ability with mods" container.
 * `powerMod` is an ArrayField<{uuid, elysiumid}> referencing embedded
 * powerMod items on the parent actor (super.mjs:185).
 *
 * `cpc` and `pppl` are stored as STRINGS per template.json (literal '1'
 * defaults). They represent character-creation-point-cost and PP-per-level
 * — string typing is preserved to match template.json and existing data.
 *
 * v1.0.0-alpha.11 (side-finding #11): `favouredEnemy` renamed to `nemesis`
 * across schema and compendium. Old name was a generic D&D-borrow; the
 * new name disambiguates and reduces overlap with published-game terms.
 * The inner typo `isfavouredEnemy` (lowercase 'f') was simultaneously
 * corrected to `isNemesis`. No migration needed — fresh world.
 *
 * String enums (category, theme, etc.) left as free StringFields per
 * audit — content-extensibility risk; locked choices would break custom
 * super-power themes.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class SuperDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      // powerMod: ArrayField<{uuid, elysiumid}> of embedded powerMod refs.
      powerMod: new fields.ArrayField(
        new fields.SchemaField({
          uuid:      new fields.StringField({ initial: '' }),
          elysiumid: new fields.StringField({ initial: '' }),
        }),
        { initial: [] },
      ),
      category:    new fields.StringField({ initial: '' }),
      cpc:         new fields.StringField({ initial: '1' }),       // string per template
      cpcSpent:    new fields.NumberField({ integer: true, initial: 0 }),
      level:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      range:       new fields.StringField({ initial: '' }),
      duration:    new fields.StringField({ initial: '' }),
      pppl:        new fields.StringField({ initial: '1' }),       // string per template
      specialism:  new fields.BooleanField({ initial: false }),
      specName:    new fields.StringField({ initial: '' }),
      mainName:    new fields.StringField({ initial: '' }),
      chosen:      new fields.BooleanField({ initial: false }),
      elysium: new fields.SchemaField({
        tier:             new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        maxTier:          new fields.NumberField({ integer: true, initial: 3, min: 0 }),
        prerequisite:     new fields.StringField({ initial: '' }),
        category:         new fields.StringField({ initial: 'passive' }),
        theme:            new fields.StringField({ initial: '' }),
        usesPerEncounter: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        currentUses:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        visionType:       new fields.StringField({ initial: '' }),
        visionRange:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // v1.0.0-alpha.11 (side-finding #11): renamed from favouredEnemy.
        nemesis: new fields.SchemaField({
          isNemesis: new fields.BooleanField({ initial: false }),
          targets:   new fields.ArrayField(new fields.StringField(), { initial: [] }),
        }),
      }),
    }
  }
}
