/**
 * FailingDataModel — schema for items of type 'failing'.
 *
 * Failings are character-creation choices that give back creation points
 * (cpcMod is typically negative) in exchange for a narrative drawback.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. Uses makeItemBase() for the shared
 * description/gmDescription HTMLFields.
 *
 * Field set matches template.json exactly. `shortDesc` is an optional
 * display-name override: when set, it replaces the item's `name` on
 * the character super-tab row (see `templates/actor/parts/failing-row.hbs`).
 * When empty, the row falls back to `name`. The sheet labels this
 * field "Display Name" (i18n key `Elysium.displayName`). `cpcMod` is
 * the integer character-creation-point adjustment (typically negative).
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class FailingDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      shortDesc: new fields.StringField({ initial: '' }),
      cpcMod:    new fields.NumberField({ integer: true, initial: 0 }),
    }
  }
}
