

import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumActiveEffectSheet } from '../../sheets/elysium-active-effect-sheet.mjs'
import { ElysiumActorSheetV2 } from './base-actor-sheet.mjs'

export class ElysiumCharacterSheet extends ElysiumActorSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['character'],
    position: {
      width: 1200,
      height: 900
    },
    window: {
      resizable: true,
    },
  }

  static PARTS = {
    // P8 shell parts (alpha.14) — header, stats, resources cards at top;
    // left rail = skills; right rail = defenses + conditions + senses + effects;
    // vertical tab strip on the right edge.
    header: {template: 'systems/elysium/templates/actor/parts/header-card.hbs'},
    /* stats: embedded in header-card.hbs as of alpha.24 (was a separate part) */
    resources: {template: 'systems/elysium/templates/actor/parts/resources-card.hbs'},
    leftRail: {template: 'systems/elysium/templates/actor/parts/left-rail-skills.hbs'},
    rightRailDefenses: {template: 'systems/elysium/templates/actor/parts/right-rail-defenses.hbs'},
    rightRailConditions: {template: 'systems/elysium/templates/actor/parts/right-rail-conditions.hbs'},
    rightRailSenses: {template: 'systems/elysium/templates/actor/parts/right-rail-senses.hbs'},
    rightRailEffects: {template: 'systems/elysium/templates/actor/parts/right-rail-effects.hbs'},
    tabs: {template: 'systems/elysium/templates/actor/parts/tabs-strip.hbs'},
    // Tab content parts (P9 will rebuild these against the new design)
    background: {
      template: 'systems/elysium/templates/actor/character.background.hbs',
      scrollable: ['']
    },
    combat: {
      template: 'systems/elysium/templates/actor/character.combat.hbs',
      scrollable: [''],
    },
    items: {
      template: 'systems/elysium/templates/actor/character.items.hbs',
      scrollable: [''],
    },
    arcane: {
      template: 'systems/elysium/templates/actor/character.arcane.hbs',
      scrollable: [''],
    },
    mutations: {
      template: 'systems/elysium/templates/actor/character.mutations.hbs',
      scrollable: [''],
    },
    pers: {
      template: 'systems/elysium/templates/actor/character.pers.hbs',
      scrollable: [''],
    },
    mysticism: {
      template: 'systems/elysium/templates/actor/character.mysticism.hbs',
      scrollable: [''],
    },
    social: {
      template: 'systems/elysium/templates/actor/character.social.hbs',
      scrollable: [''],
    },
    sorcery: {
      template: 'systems/elysium/templates/actor/character.sorcery.hbs',
      scrollable: [''],
    },
    divine: {
      template: 'systems/elysium/templates/actor/character.divine.hbs',
      scrollable: [''],
    },
    magic: {
      template: 'systems/elysium/templates/actor/character.magic.hbs',
      scrollable: [''],
    },
    statistics: {
      template: 'systems/elysium/templates/actor/character.statistics.hbs',
      scrollable: [''],
    },
    super: {
      template: 'systems/elysium/templates/actor/character.super.hbs',
      scrollable: [''],
    },
    dev: {
      template: 'systems/elysium/templates/actor/character.dev.hbs',
      scrollable: [''],
    },
  }

  _configureRenderOptions(options) {
    super._configureRenderOptions(options);
    // P8 shell parts always render in this order:
    //   header → resources → (rails + tab content + vertical tab strip)
    // Skills and Effects are no longer tabs (they're rails).
    // Statistics retained as a tab (drill-down view).
    // alpha.24: stats grid markup embedded directly into header-card.hbs
    //          (eliminated the standalone 'stats' part to remove the grid-row
    //          gap that was visually separating it from the Move/Luck chips).
    options.parts = [
      'header', 'resources',
      'leftRail',
      'rightRailDefenses', 'rightRailConditions',
      'rightRailSenses', 'rightRailEffects',
      'combat', 'items',
    ];

    // Cluster 5 alpha.37 — smart consolidation of magic disciplines.
    // Collect the active magic disciplines (arcane / divine / mysticism /
    // sorcery only — mutations and super are NOT magic and stay as their
    // own independent direct chips below). When exactly one is active we
    // push its direct PART; when two or more are active we push the
    // consolidated 'magic' wrapper instead. The consolidated wrapper's
    // content body holds a sub-tab strip and the active discipline's body
    // partial. Stashed on the instance so _getTabs (which runs in
    // _prepareContext after this method) can build the tooltip and
    // _preparePartContext can default the sub-tab group.
    const activeMagic = [];
    if (this.actor.system.arcane    != "") activeMagic.push('arcane');
    if (this.actor.system.divine    != "") activeMagic.push('divine');
    if (this.actor.system.mysticism != "") activeMagic.push('mysticism');
    if (this.actor.system.sorcery   != "") activeMagic.push('sorcery');
    this._activeMagicDisciplines = activeMagic;

    if (activeMagic.length === 1) {
      options.parts.push(activeMagic[0]);
    } else if (activeMagic.length >= 2) {
      options.parts.push('magic');
    }
    // 0 active → no magic chip rendered.

    if (this.actor.system.mutation != "") {
      options.parts.push('mutations')
    }
    if (this.actor.system.super != "") {
      options.parts.push('super')
    }
    if (true || (game.settings.get('elysium', 'useReputation') > 0)) {
      options.parts.push('social')
    }
    if (true || (true > 0)) {
      options.parts.push('pers')
    }
    options.parts.push('statistics','background')
    if (game.settings.get('elysium', 'development')) {
      options.parts.push('dev')
    }
    // tabs strip renders LAST (right edge of sheet); it lists every tab
    // content part registered above for navigation
    options.parts.push('tabs')
  }

  /** @override */
  async _preparePartContext(partId, context) {
    switch (partId) {
      // Tab content parts — set context.tab for tab-content rendering
      case 'combat':
      case 'items':
      case 'social':
      case 'pers':
      case 'statistics':
      case 'arcane':
      case 'mutations':
      case 'mysticism':
      case 'sorcery':
      case 'divine':
      case 'super':
      case 'background':
      case 'dev':
        context.tab = context.tabs[partId];
        break;
      case 'magic': {
        // Consolidated magic surface — alpha.37.
        // Build the per-discipline sub-tab list (one chip per active
        // discipline). Default tabGroups['magic'] to the alphabetic-first
        // active discipline on initial render; also fall back to it if
        // the stored value is stale (discipline no longer active).
        context.tab = context.tabs[partId];
        const active = this._activeMagicDisciplines ?? [];
        if (!this.tabGroups['magic'] || !active.includes(this.tabGroups['magic'])) {
          this.tabGroups['magic'] = active[0];
        }
        const activeSub = this.tabGroups['magic'];
        const labelMap = {
          arcane:    context.arcaneLabel,
          divine:    context.divineLabel,
          mysticism: context.mysticismLabel,
          sorcery:   context.sorceryLabel,
        };
        const iconMap = {
          arcane:    'fas fa-hat-wizard',
          divine:    'fas fa-cross',
          mysticism: 'fas fa-eye',
          sorcery:   'fas fa-fire',
        };
        context.magicSubTabs = active.map(d => ({
          id:     d,
          label:  labelMap[d] ?? d,
          icon:   iconMap[d] ?? '',
          active: d === activeSub,
        }));
        context.magicActiveDiscipline = activeSub;
        context.activeMagicDisciplines = active;
        // Per-discipline boolean flags so the consolidated wrapper template
        // can gate each <section> emission without needing an `includes`
        // Handlebars helper. Top-level context only — `{{#each}}` would
        // shift Handlebars context away from the actor's `system` object
        // and break discipline-body partials that gate on `system.lock`.
        context.hasMagicArcane    = active.includes('arcane');
        context.hasMagicDivine    = active.includes('divine');
        context.hasMagicMysticism = active.includes('mysticism');
        context.hasMagicSorcery   = active.includes('sorcery');
        break;
      }
      // Shell parts (P8) — no tab context needed; they render at the
      // shell level. Context is already populated by the unified
      // _prepareContext override (rail data, header data, etc.).
      case 'header':
      case 'stats':
      case 'resources':
      case 'leftRail':
      case 'rightRailDefenses':
      case 'rightRailConditions':
      case 'rightRailSenses':
      case 'rightRailEffects':
      case 'tabs':
        break;
    }
    return context;
  }

  _getTabs(parts, context) {
    // If you have sub-tabs this is necessary to change
    const tabGroup = 'primary';
    // Default tab for first time it's rendered this session
    if (!this.tabGroups[tabGroup]) {
      this.tabGroups[tabGroup] = 'combat';
    }

    // P8 — per-tab icon glyphs for vertical icon strip
    const TAB_ICONS = {
      combat:     'fas fa-swords',
      items:      'fas fa-sack',
      background: 'fas fa-scroll',
      pers:       'fas fa-mask-theater',
      social:     'fas fa-people-group',
      arcane:     'fas fa-hat-wizard',
      divine:     'fas fa-cross',
      mysticism:  'fas fa-eye',
      sorcery:    'fas fa-fire',
      magic:      'fas fa-wand-sparkles',
      mutations:  'fas fa-dna',
      super:      'fas fa-bolt',
      statistics: 'fas fa-table-list',
      story:      'fas fa-book-open',
      dev:        'fas fa-code',
    }

    return parts.reduce((tabs, partId) => {
      const tab = {
        cssClass: '',
        group: tabGroup,
        id: '',
        icon: '',
        label: 'Elysium.TABS.',
      };
      switch (partId) {
        // Shell parts — not tabs, skip
        case 'header':
        case 'stats':
        case 'resources':
        case 'leftRail':
        case 'rightRailDefenses':
        case 'rightRailConditions':
        case 'rightRailSenses':
        case 'rightRailEffects':
        case 'tabs':
          return tabs;
        case 'combat':
        case 'items':
        case 'social':
        case 'pers':
        case 'statistics':
        case 'background':
        case 'dev':
          tab.id = partId;
          tab.label += partId;
          tab.tooltip = game.i18n.localize("Elysium."+partId);
          tab.icon = TAB_ICONS[partId] || '';
          break;
        case 'arcane':
          tab.id = partId;
          tab.label = context.arcaneLabel.slice(0, 5);
          tab.tooltip = context.arcaneLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        case 'mutations':
          tab.id = partId;
          tab.label = context.mutationLabel.slice(0, 5);
          tab.tooltip = context.mutationLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        case 'mysticism':
          tab.id = partId;
          tab.label = context.mysticismLabel.slice(0, 5);
          tab.tooltip = context.mysticismLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        case 'sorcery':
          tab.id = partId;
          tab.label = context.sorceryLabel.slice(0, 5);
          tab.tooltip = context.sorceryLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        case 'divine':
          tab.id = partId;
          tab.label = context.divineLabel.slice(0, 5);
          tab.tooltip = context.divineLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        case 'magic': {
          // Consolidated magic chip — alpha.37. Tooltip lists the
          // currently-active disciplines using their settings-driven
          // labels so the player can see what's inside without clicking.
          const labelMap = {
            arcane:    context.arcaneLabel,
            divine:    context.divineLabel,
            mysticism: context.mysticismLabel,
            sorcery:   context.sorceryLabel,
          };
          const activeLabels = (this._activeMagicDisciplines ?? [])
            .map(d => labelMap[d])
            .filter(Boolean);
          tab.id = partId;
          tab.label = 'Magic';
          tab.tooltip = activeLabels.length
            ? `Magic — ${activeLabels.join(', ')}`
            : 'Magic';
          tab.icon = TAB_ICONS[partId];
          break;
        }
        case 'super':
          tab.id = partId;
          tab.label = context.superLabel.slice(0,5);
          tab.tooltip = context.superLabel;
          tab.icon = TAB_ICONS[partId];
          break;
        }
      if (this.tabGroups[tabGroup] === tab.id) tab.cssClass = 'active';
      tabs[partId] = tab;
      return tabs;
    }, {});
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const actorData = this.actor.toObject(false);
    // F11 (rc.4 cleanup): `context.logo = game.settings.get('elysium', 'charSheetLogo')`
    // retired here — no template ever consumed `{{logo}}`. Dead code from v0.x
    // sheet rebuild. Setting + display-settings.hbs UI also retired in this ship.
    // v0.20.0: useWealth/useEDU/useFP/useHPL/useAlleg/usePassion/usePersTrait
    // context flags removed — their template `{{#if useX}}` branches were all
    // hardcoded one way (true for HPL/Alleg/Passion/PersTrait; false for EDU/FP)
    // and have been unwrapped/deleted directly in the templates. The wealthLabel
    // string interpolation remains since templates still use `{{wealthLabel}}`
    // as the currency display name.
    //
    // Exception: context.useHPL is still read in 3 places of the JS code
    // (in _prepareItems and again to assemble context.armors). Setting it
    // true here preserves that logic without rewriting those branches.
    context.useHPL = true;
    context.wealthLabel = "Gold";
    context.useSAN = game.settings.get('elysium', 'useSAN');
    context.useRES5 = game.settings.get('elysium', 'useRes5');
    context.useReputation = game.settings.get('elysium', 'useReputation');
    context.wealthName = actorData.system.wealth
    context.wealthOptions = await ElysiumSelectLists.getWealthOptions(0, 4)
    if (actorData.system.wealth >= 0 && actorData.system.wealth <= 4 && actorData.system.wealth != "") {
      context.wealthName = game.i18n.localize('Elysium.wealthLevel.' + actorData.system.wealth)
    }
    context.statLocked = true
    if (!actorData.system.lock && game.settings.get('elysium', 'development')) { context.statLocked = false }

    // Social tab: visible when allegiances (always-on in Elysium) or reputation
    // tracking is active. Personality tab: always visible (passions + traits are
    // both core character data in Elysium).
    context.useSocialTab = true;   // allegiances are always-on
    context.usePersTab   = true;   // passions + traits are always-on
    context.useAVRand = game.settings.get('elysium', 'useAVRand');
    context.background1 = game.settings.get('elysium', 'background1');
    context.background2 = game.settings.get('elysium', 'background2');
    context.background3 = game.settings.get('elysium', 'background3');
    let resource = 2;
    if (game.settings.get('elysium', 'useSAN')) { resource++ };
    if (game.settings.get('elysium', 'useRes5')) { resource++ };
    context.resource = resource;
    // v0.8.0: power-tab labels are fixed Elysium strings, sourced from
    // Elysium.arcane / Elysium.mysticism / Elysium.divine in the rules-module lang
    // file. The legacy magicLabel / psychicLabel BRP settings are no
    // longer consulted — those were customisation hooks for BRP-canon
    // worlds and aren't relevant in Elysium.
    context.arcaneLabel    = game.i18n.localize('Elysium.arcane')
    context.mysticismLabel = game.i18n.localize('Elysium.mysticism')
    context.divineLabel    = game.i18n.localize('Elysium.divine')
    // BRP-canon power labels (kept for the unchanged super / mutation /
    // v0.20.0: BRP super/mutation/sorcery label-override settings deleted.
    // Tabs use the fixed BRP localized strings.
    context.superLabel    = game.i18n.localize('Elysium.super')
    context.mutationLabel = game.i18n.localize('Elysium.mutation')
    context.sorceryLabel  = game.i18n.localize('Elysium.sorcery')

    // v0.11.0: Ancestry column label for the CHAR tab. Driven by the
    // ancestryLabel setting (Culture / Ancestry / Race / Species).
    // Falls back to "Ancestry" if the setting isn't readable.
    context.ancestryColumnLabel = (() => {
      try {
        const choice = game.settings.get('elysium', 'ancestryLabel')
        const map = { culture: 'Cultural', ancestry: 'Ancestry', race: 'Race', species: 'Species' }
        return map[choice] ?? 'Ancestry'
      } catch (_) {
        return 'Ancestry'
      }
    })()

    // v0.11.0: EXP Dice display for the CHAR tab bonus block.
    // Source of truth: actor.system.elysium.expDice (Elysium's
    // creation-time stat-advancement system also uses this flag).
    // Shape: { available: <int>, diceSize: <int> } → "Nd4" / "Nd6".
    {
      const exp = this.document.system?.elysium?.expDice ?? {}
      const available = Number(exp.available) || 0
      const diceSize = Number(exp.diceSize) || 4
      context.expDiceDisplay = `${available}d${diceSize}`
      context.expDiceAvailable = available
    }
    // Resolve the actor's currently-active culture, personality, and
    // career items. Each "slot" supports either a real Item (preferred,
    // gives sheet links) or a free-text name fallback (for legacy actors
    // or quick-NPC setup).
    const tempCult = this.actor.items.find(i => i.type === 'culture')
    if (tempCult) {
      context.culture = tempCult.name
      context.cultureId = tempCult._id
      context.cultureUsed = true
    } else {
      context.culture = actorData.system.culture
      context.cultureUsed = false
    }

    const tempPers = this.actor.items.find(i => i.type === 'personality')
    if (tempPers) {
      context.personality = tempPers.name
      context.personalityId = tempPers._id
      context.personalityUsed = true
    } else {
      context.personality = actorData.system.personalityName
      context.personalityUsed = false
    }

    const tempProf = this.actor.items.find(i => i.type === 'career')
    if (tempProf) {
      context.career = tempProf.name
      context.careerId = tempProf._id
      context.careerUsed = true
    } else {
      context.career = actorData.system.careerName
      context.careerUsed = false
    }
    context.xpFixed = "+" + game.settings.get('elysium','xpFixed') +"%";
    context.xpFormula = "+" + game.settings.get('elysium','xpFormula') + "%";

    //Story Section
    context.storySections = []
    if (context.system.stories instanceof Array && context.system.stories.length) {
      for (const story of context.system.stories) {
        context.storySections.push({
          title: story.title,
          value: story.value,
          enriched: await foundry.applications.ux.TextEditor.implementation.enrichHTML(
            story.value,
            {
              secrets: context.editable
            }
          )
        })
      }
      context.storySections[0].isFirst = true
      context.storySections[context.storySections.length - 1].isLast = true
    }

    await this._prepareItems(context);
    context.rollData = context.actor.getRollData();
    //Get a List of Active Effects for the Actor
    context.effects = await ElysiumActiveEffectSheet.getActorEffectsFromSheet(this.document)
    context.tabs = this._getTabs(options.parts, context);

    // === P8 shell context (alpha.14) ===
    // Header card context
    context.isLocked = !!this.actor.system.lock
    context.isNPC = false  // overridden in NPC sheet's _prepareContext
    // Ancestry display + click-link
    const ancestryItem = this.actor.items.find(i => i.type === 'ancestry')
    context.ancestryUsed = !!ancestryItem
    context.ancestry    = ancestryItem?.name ?? (this.actor.system.ancestryName ?? '')
    context.ancestryId  = ancestryItem?.id ?? null
    // Career display + click-link
    const careerItem = this.actor.items.find(i => i.type === 'career')
    context.careerUsed = !!careerItem
    context.career     = careerItem?.name ?? (this.actor.system.careerName ?? '')
    context.careerId   = careerItem?.id ?? null

    // Header strip: roll-visibility + difficulty + chips
    context.rollVisibility = this.actor.getFlag('elysium', 'headerRollVisibility') ?? 'public'
    context.currentDifficulty = this.actor.getFlag('elysium', 'headerDifficulty') ?? 'average'
    context.difficultyOptions = await ElysiumSelectLists.getDifficultyOptions()
    context.difficultyShortLabels = {
      veryEasy:   'VE',
      easy:       'E',
      routine:    'R',
      average:    'A',
      difficult:  'D',
      formidable: 'F',
      impossible: 'I',
    }
    const derived = this.actor.flags?.elysium?.derived ?? {}
    context.initiativeBonus = derived.initiative ?? 0
    context.moveBase        = this.actor.system.move ?? 0
    {
      // Canonical luck-points source: actor.system.luckPoints (populated by
      // actor-extension._prepDerivedStats from flags.elysium.derived.luckPoints).
      // The flags version only carries .max; the system field carries both.
      const lp = this.actor.system?.luckPoints ?? {}
      context.luckPoints = {
        value: lp.value ?? 0,
        max:   lp.max   ?? 0,
      }
    }

    // Stats card derived pairings
    context.damageModifier = derived.damageModifier ?? '0'
    context.healingRate    = derived.healingRate ?? 0
    context.xpBonus        = derived.xpBonus ?? 0

    // Resources card — AP pools + PP
    const apData = this.actor.system.actionPoints ?? {}
    const ppData = derived.powerPoints ?? { value: 0, max: derived.powerPointsMax ?? 0 }
    // Fallback: if system.actionPoints is empty (fresh actor), pull from derived flags
    const dAP = derived.actionPoints ?? {}
    context.ap = {
      value:        apData.value        ?? dAP.value        ?? 0,
      max:          apData.max          ?? dAP.max          ?? 0,
      reactValue:   apData.reactValue   ?? dAP.reactValue   ?? 0,
      reactMax:     apData.reactMax     ?? dAP.reactMax     ?? 0,
      attackValue:  apData.attackValue  ?? dAP.attackValue  ?? 0,
      attackMax:    apData.attackMax    ?? dAP.attackMax    ?? 0,
      defenseValue: apData.defenseValue ?? dAP.defenseValue ?? 0,
      defenseMax:   apData.defenseMax   ?? dAP.defenseMax   ?? 0,
    }
    context.ap.hasReact   = context.ap.reactMax   > 0
    context.ap.hasAttack  = context.ap.attackMax  > 0
    context.ap.hasDefense = context.ap.defenseMax > 0
    context.pp = {
      value: ppData.value ?? 0,
      max:   ppData.max   ?? derived.powerPointsMax ?? 0,
    }

    // Skills rail — group standard + career skills by category
    {
      const allSkills = this.actor.items.filter(i => i.type === 'skill')
      const groupByCat = (skills) => {
        const cats = {}
        for (const s of skills) {
          const cat = s.system?.elysium?.skillCategory || 'Other'
          if (!cats[cat]) cats[cat] = []
          // Short cat code for the tag column
          const catShort = (cat.match(/[A-Z]/g) || cat.slice(0, 3).toUpperCase().split('')).join('').slice(0, 3)
          cats[cat].push({
            id: s.id,
            name: s.name,
            catShort,
            system: s.system,
          })
        }
        return Object.entries(cats).sort((a, b) => a[0].localeCompare(b[0])).map(([category, skills]) => ({
          category,
          skills: skills.sort((a, b) => a.name.localeCompare(b.name)),
        }))
      }
      const standardSkills = allSkills.filter(s => (s.system?.elysium?.skillSubgroup ?? '') !== 'career')
      const careerSkills   = allSkills.filter(s => (s.system?.elysium?.skillSubgroup ?? '') === 'career')
      context.standardSkillGroups = groupByCat(standardSkills)
      context.careerSkillGroups   = groupByCat(careerSkills)
    }

    // Defenses card — Temp HP + overall HP + hit-location list with armor layers
    {
      context.tempHP = this.actor.system?.elysium?.tempHP ?? 0
      const hitlocs = this.actor.items.filter(i => i.type === 'hit-location')
      const armorItems = this.actor.items.filter(i => i.type === 'armor' && i.system?.equipStatus === 'equipped')
      let totalCur = 0, totalMax = 0
      context.hitLocations = hitlocs.map(loc => {
        const cur = Number(loc.system?.currHP) || 0
        const mx  = Number(loc.system?.maxHP)  || 0
        totalCur += cur
        totalMax += mx
        // Find armor items contributing AP to this hit-location
        const layers = armorItems
          .filter(a => a.system?.hitlocID === loc.id)
          .map(a => ({
            itemId:   a.id,
            itemName: a.name,
            ap:       Number(a.system?.ap) || 0,
          }))
        const totalAP = layers.reduce((sum, l) => sum + l.ap, 0)
        return {
          id: loc.id,
          name: loc.name,
          currentHP: cur,
          maxHP: mx,
          totalAP,
          layers,
        }
      })
      context.overallHP = { current: totalCur, max: totalMax }
    }

    // Conditions card — combine actor.effects with statuses + per-hit-location conditions
    {
      const conditions = []
      // Actor-wide status effects (those with statuses.size > 0)
      for (const eff of this.actor.effects) {
        if (eff.statuses && eff.statuses.size > 0) {
          conditions.push({
            name: eff.name,
            icon: eff.icon || eff.img || null,
            affectedLocations: [],
          })
        }
      }
      // Per-hit-location conditions
      const hitlocs = this.actor.items.filter(i => i.type === 'hit-location')
      const locCondMap = new Map()  // condName → [locName, ...]
      for (const loc of hitlocs) {
        const locConds = loc.system?.elysium?.locationConditions ?? []
        for (const lc of locConds) {
          const condName = lc.name || lc.condition || 'Unknown'
          if (!locCondMap.has(condName)) locCondMap.set(condName, [])
          locCondMap.get(condName).push(loc.name)
        }
      }
      for (const [condName, locNames] of locCondMap.entries()) {
        // Merge with actor-wide if same name, else add new entry
        const existing = conditions.find(c => c.name === condName)
        if (existing) {
          existing.affectedLocations.push(...locNames)
        } else {
          conditions.push({
            name: condName,
            icon: null,
            affectedLocations: locNames,
          })
        }
      }
      context.conditions = conditions
    }

    // Senses card — Perception skill + vision types from mutation/super items
    {
      // Find Perception skill by name (case-insensitive)
      const percItem = this.actor.items.find(i => i.type === 'skill' && /perception/i.test(i.name))
      context.perceptionSkill = percItem
        ? { id: percItem.id, total: percItem.system?.total ?? 0 }
        : null
      const visionTypes = []
      const visionSources = this.actor.items.filter(i =>
        (i.type === 'mutation' || i.type === 'super')
        && i.system?.elysium?.visionType
      )
      for (const v of visionSources) {
        visionTypes.push({
          name:  v.system.elysium.visionType,
          range: v.system.elysium.visionRange ?? '',
        })
      }
      context.visionTypes = visionTypes
    }

    // Active Effects card — AEs WITHOUT statuses (those are in Conditions)
    {
      const aes = []
      for (const eff of this.actor.effects) {
        if (eff.statuses && eff.statuses.size > 0) continue
        let originName = null
        if (eff.origin) {
          try {
            const m = eff.origin.match(/Item\.([a-zA-Z0-9]+)$/)
            if (m) {
              const item = this.actor.items.get(m[1])
              if (item) originName = item.name
            }
          } catch (_) {}
        }
        aes.push({
          id: eff.id,
          name: eff.name,
          icon: eff.icon || eff.img || null,
          origin: eff.origin || null,
          originName,
          disabled: !!eff.disabled,
        })
      }
      context.activeEffects = aes
    }

    return context
  }

  //
  _prepareItems(context) {
    // Initialize containers.
    // v0.8.0: arcane / divine / mysticism are first-class types.
    // The bucket names mirror the type names — no more 'magics' or 'psychics'.
    const gears = [];
    const skills = [];
    const skillsDev = [];
    const skillsAlpha = [];
    const hitlocs = [];
    const arcanes = [];
    const divines = [];
    const mutations = [];
    const mysticisms = [];
    const sorceries = [];
    const superpowers = [];
    const failings = [];
    const armors = [];
    const weapons = [];
    const wounds = [];
    const allegiances = [];
    const passions = [];
    const persTraits = [];
    const reputations = [];
    const improve = [];

    // Iterate through items, allocating to containers
    this.actor.system.totalProf = 0
    this.actor.system.totalPers = 0
    this.actor.system.totalXP = 0

    // Add items to containers.
    for (let itm of this.document.items) {
      itm.img = itm.img || DEFAULT_TOKEN;

      if (itm.type === 'gear') {
        itm.system.equippedName = game.i18n.localize('Elysium.' + itm.system.equipStatus)
        gears.push(itm);
      } else if (itm.type === 'skill') {
        skillsDev.push(itm)
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total - itm.system.effects, opp:false })
        }
        itm.system.grandTotal = itm.system.total + (this.actor.system.skillcategory[itm.system.category] ?? 0)
        let tempName = itm.name.toLowerCase()
        if (itm.system.specialism) {
          tempName = itm.system.specName.toLowerCase()
        }
        itm.system.orderName = tempName
        skillsAlpha.push(itm);
        skills.push(itm);
        this.actor.system.totalProf = this.actor.system.totalProf + itm.system.career
        this.actor.system.totalPers = this.actor.system.totalPers + itm.system.personal
        this.actor.system.totalXP = this.actor.system.totalXP + itm.system.xp
      } else if (itm.type === 'hit-location') {
        hitlocs.push(itm);
        if (context.useHPL) {
          itm.system.list = 0
          itm.system.count = 0
          itm.system.hitlocID = itm._id
          armors.push(itm)
        }
      } else if (itm.type === 'wound') {
        wounds.push(itm);
      } else if (itm.type === 'arcane') {
        // v0.8.0: was BRP 'magic'. Schema unchanged — Arcane spells track
        // a casting skill (school), with grandTotal computed against the
        // category bonus.
        itm.system.grandTotal = itm.system.total + (this.actor.system.skillcategory[itm.system.category] ?? 0)
        arcanes.push(itm);
        this.actor.system.totalProf = this.actor.system.totalProf + itm.system.career
        this.actor.system.totalPers = this.actor.system.totalPers + itm.system.personal
        this.actor.system.totalXP = this.actor.system.totalXP + itm.system.xp
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: context.arcaneLabel, score: itm.system.total - itm.system.effects, opp:false })
        }
      } else if (itm.type === 'divine') {
        // v0.8.0: Divine spells. No skill-percentile track of their own —
        // gating happens via the patron Faith allegiance allegPoints.
        divines.push(itm);
      } else if (itm.type === 'mutation') {
        mutations.push(itm);
      } else if (itm.type === 'mysticism') {
        // v0.8.0: was BRP 'psychic'. Schema unchanged.
        itm.system.grandTotal = itm.system.total + (this.actor.system.skillcategory[itm.system.category] ?? 0)
        mysticisms.push(itm);
        this.actor.system.totalProf = this.actor.system.totalProf + itm.system.career
        this.actor.system.totalPers = this.actor.system.totalPers + itm.system.personal
        this.actor.system.totalXP = this.actor.system.totalXP + itm.system.xp
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: context.mysticismLabel, score: itm.system.total - itm.system.effects, opp:false })
        }
      } else if (itm.type === 'sorcery') {
        itm.system.ppCost = itm.system.currLvl * itm.system.pppl
        if (itm.system.mem) {
          itm.system.ppCost = itm.system.memLvl * itm.system.pppl
        }
        sorceries.push(itm);
      } else if (itm.type === 'super') {
        superpowers.push(itm);
      } else if (itm.type === 'failing') {
        failings.push(itm);
      } else if (itm.type === 'armor') {
        itm.system.hide = false
        if (itm.system.hitlocID) {
          const hitLocTemp = this.actor.items.get(itm.system.hitlocID)
          if (hitLocTemp) {
            itm.system.hitlocName = hitLocTemp.system.displayName
            itm.system.lowRoll = hitLocTemp.system.lowRoll
            if (context.useHPL) {
              itm.system.hide = hitLocTemp.system.hide
            }
          }
        }
        itm.system.equippedName = game.i18n.localize('Elysium.' + itm.system.equipStatus)
        itm.system.list = 1
        armors.push(itm);
      } else if (itm.type === 'weapon') {
        if (itm.system.range3 != "") {
          itm.system.rangeName = itm.system.range1 + "/" + itm.system.range2 + "/" + itm.system.range3
        } else if (itm.system.range2 != "") {
          itm.system.rangeName = itm.system.range1 + "/" + itm.system.range2
        } else {
          itm.system.rangeName = itm.system.range1
        }

        if (itm.system.specialDmg) {
          itm.system.dmgName = game.i18n.localize('Elysium.special')
        } else if (itm.system.dmg3 != "") {
          itm.system.dmgName = itm.system.dmg1 + "/" + itm.system.dmg2 + "/" + itm.system.dmg3
        } else if (itm.system.dmg2 != "") {
          itm.system.dmgName = itm.system.dmg1 + "/" + itm.system.dmg2
        } else {
          itm.system.dmgName = itm.system.dmg1
        }

        itm.system.damageHint = game.i18n.localize("Elysium." + itm.system.special)
        itm.system.dbName = "-"
        itm.system.dbNameHint=game.i18n.localize("Elysium.none")
        if (itm.system.db === "half") {
          itm.system.dbName = "½"
          itm.system.dbNameHint=game.i18n.localize("Elysium.half")
        } else if (itm.system.db === "full") {
          itm.system.dbName = game.i18n.localize('Elysium.dmgBonusInitials')
          itm.system.dbNameHint=game.i18n.localize("Elysium.full")
        } else if (itm.system.db === "oneH") {
          itm.system.dbName = "1H"
          itm.system.dbNameHint=game.i18n.localize("Elysium.oneH")
        }

        let skill1Select = "";
        let skill2Select = "";
        skill1Select = skills.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === itm.system.skill1)[0]
        skill2Select = skills.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === itm.system.skill2)[0]
        if (skill1Select && skill2Select) {
          if (itm.system.skill2 === 'none') {
            if (skill1Select) {
              itm.system.sourceID = skill1Select._id
            }
          } else {
            if (skill2Select.system.total >= skill1Select.system.total) {
              itm.system.sourceID = skill2Select._id
            } else {
              itm.system.sourceID = skill1Select._id
            }
          }
        } else if (skill1Select) {
          itm.system.sourceID = skill1Select._id
        } else if (skill2Select) {
          itm.system.sourceID = skill2Select._id
        }

        if (itm.system.sourceID) {
          itm.system.skillScore = this.actor.items.get(itm.system.sourceID).system.total + this.actor.system.skillcategory[this.actor.items.get(itm.system.sourceID).system.category]
          itm.system.skillName = this.actor.items.get(itm.system.sourceID).name
        } else {
          itm.system.skillScore = 0
          itm.system.skillName = game.i18n.localize('Elysium.noWpnSkill')
        }
        itm.system.equippedName = game.i18n.localize('Elysium.' + itm.system.equipStatus)
        weapons.push(itm)
      } else if (itm.type === 'allegiance') {
        if (itm.system.allegApoth) {
          itm.system.rank = game.i18n.localize('Elysium.allegApoth')
        } else if (itm.system.allegAllied) {
          itm.system.rank = game.i18n.localize('Elysium.allegAllied')
        }
        allegiances.push(itm);
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total, opp:false })
        }
      } else if (itm.type === 'passion') {
        passions.push(itm);
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total, opp:false })
        }
      } else if (itm.type === 'persTrait') {
        persTraits.push(itm);
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total, opp:false })
        }
        if (itm.system.oppimprove) {
          improve.push ({_id: itm._id, name: itm.system.oppName, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total, opp:true })
        }
      } else if (itm.type === 'reputation') {
        reputations.push(itm);
        if (itm.system.improve) {
          improve.push ({_id: itm._id, name: itm.name, typeLabel: game.i18n.localize('TYPES.Item.'+itm.type), score: itm.system.total, opp:false })
        }
      } else if (itm.type === 'skillcat') {
        // F10 (rc.2) defensive guard. Skip skillcats lacking ElysiumID metadata
        // rather than throwing during sheet prepareItems. This bug was reachable
        // from any actor with a programmatically-created skillcat (e.g. user
        // creates a new skill category manually via the items tab without
        // routing through the ElysiumID system). rc.1 surfaced this as a sheet
        // render failure within minutes of install.
        if (!itm.flags?.elysium?.elysiumidFlag?.id) continue
        skills.push({
          name: itm.name, isType: true, count: skills.filter(itm => itm.isType).length,
          flags: { elysium: { elysiumidFlag: { id: itm.flags.elysium.elysiumidFlag.id } } },
          system: { category: itm.flags.elysium.elysiumidFlag.id, total: itm.system.total },
          _id: itm._id
        });
        skillsAlpha.push({
          name: itm.name, isType: true, count: skillsAlpha.filter(itm => itm.isType).length,
          flags: { elysium: { elysiumidFlag: { id: itm.flags.elysium.elysiumidFlag.id } } },
          system: { category: itm.flags.elysium.elysiumidFlag.id, total: itm.system.total },
          _id: itm._id
        });
      }
    }

    //Sort Skills by Category then Skill Name
    skills.sort(function (a, b) {
      const x = a.name.toLowerCase();
      const y = b.name.toLowerCase();
      const r = a.isType ? a.isType : false;
      const s = b.isType ? b.isType : false;
      const p = a.system.category;
      const q = b.system.category;
      if (p < q) { return -1 };
      if (p > q) { return 1 };
      if (r < s) { return 1 };
      if (s < r) { return -1 };
      if (x < y) { return -1 };
      if (x > y) { return 1 };
      return 0;
    });

    let previousSpec = "";
    for (let skill of skills) {
      skill.isSpecialisation = false
      if (skill.system.specialism && (previousSpec != skill.system.mainName)) {
        previousSpec = skill.system.mainName;
        skill.isSpecialisation = true;
      }
    }

    skillsAlpha.sort(function (a, b) {
      const x = a.system.orderName;
      const y = b.system.orderName;
      const r = a.isType ? a.isType : false;
      const s = b.isType ? b.isType : false;
      const p = a.system.category;
      const q = b.system.category;
      if (p < q) { return -1 };
      if (p > q) { return 1 };
      if (r < s) { return 1 };
      if (s < r) { return -1 };
      if (x < y) { return -1 };
      if (x > y) { return 1 };
      return 0;
    });

    let alphaPreviousSpec = "";
    for (let alphaskill of skillsAlpha) {
      alphaskill.isAlphaSpecialisation = false
      if (!alphaskill.system.specialism) {
        alphaPreviousSpec = ""
      }
      if (alphaskill.system.specialism && (alphaPreviousSpec != alphaskill.system.mainName)) {
        alphaPreviousSpec = alphaskill.system.mainName;
        alphaskill.isAlphaSpecialisation = true;
      }
    }

    //Sort Armors by HitLocation and List score
    armors.sort(function (a, b) {
      const x = a.system.lowRoll;
      const y = b.system.lowRoll;
      const p = a.system.list;
      const q = b.system.list;
      if (x < y) { return 1 };
      if (x > y) { return -1 };
      if (p < q) { return -1 };
      if (p > q) { return 1 };
      return 0;
    });

    //Sort Improve by Type and Name score
    improve.sort(function (a, b) {
      const x = a.typeLabel;
      const y = b.typeLabel;
      const p = a.name;
      const q = b.name;
      if (x < y) { return -1 };
      if (x > y) { return 1 };
      if (p < q) { return -1 };
      if (p > q) { return 1 };
      return 0;
    });

    // Sort Hit Locations
    hitlocs.sort(function (a, b) {
      const x = a.system.lowRoll;
      const y = b.system.lowRoll;
      if (x < y) { return 1 };
      if (x > y) { return -1 };
      return 0;
    });

    //If using HPL add number of items of armor per Hit Loc
    if (context.useHPL) {
      let locID = ""
      const newArmors = []
      for (let itm of armors) {
        if (itm.system.list === 0) {
          const armList = armors.filter(arm => arm.system.list === 1 && arm.system.hitlocID === itm._id)
          itm.system.length = armList.length
        } else {
          if (itm.system.hitlocID != locID) {
            itm.system.show = true
            locID = itm.system.hitlocID
          } else {
            itm.system.show = false
          }
        }
        newArmors.push(itm)
      }
      context.armors = newArmors;
    } else {
      context.armors = armors;
    }

    // Assign and return
    context.persTraits = persTraits.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.gears = gears.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.skills = skills;
    context.skillsDev = skillsDev;
    context.skillsAlpha = skillsAlpha;
    // Elysium fork (v0.7.0+): categorised skills collection. Skills are
    // grouped by `system.elysium.skillCategory` (and `skillSubgroup` for
    // Magic). Specialism families (Lore / Craft / Language / Exotic) are
    // further grouped under a parent name.
    context.elysiumSkills = _buildCategorisedSkills(skillsAlpha)
    context.hitlocs = hitlocs;
    context.arcanes    = arcanes.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.divines    = divines.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.mutations  = mutations.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.mysticisms = mysticisms.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.sorceries  = sorceries.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.superpowers = superpowers.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.failings = failings.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.weapons = weapons.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.wounds = wounds;
    context.allegiances = allegiances.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.passions = passions.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.reputations = reputations.sort(function (a, b) {return a.name.localeCompare(b.name)});
    context.improve = improve;

    // Elysium fork (v0.7.6+): split passions and re-bucket skill summaries
    // Elysium fork (v0.8.0+): split passions and re-bucket skill summaries
    // for each power tab.
    //
    // - context.passionsArcane: passions with system.elysium.category 'arcane'
    //   (Forms + Techniques) — shown on the Arcane tab, NOT Personality.
    // - context.passionsGeneral: everything else (Loyalty, Hatred, etc.) —
    //   shown on the Personality tab as before.
    // - context.elysiumArcaneTab / SorceryTab / MysticismTab / DivineTab:
    //   per-tab summary buckets (skill list + spells/feats already in
    //   `arcanes` / `divines` / `mysticisms` / `sorceries` collections).
    context.passionsArcane = context.passions
      .filter(p => p.system?.elysium?.category === 'arcane')
    context.passionsGeneral = context.passions
      .filter(p => p.system?.elysium?.category !== 'arcane')

    // Replace context.passions with passionsGeneral so the Personality
    // tab (which iterates context.passions) only sees non-arcane ones.
    context.passions = context.passionsGeneral

    // Per-tab context buckets. Each tab's spells/feats list is the
    // already-collected `arcanes` / `divines` / `mysticisms` / `sorceries`
    // bucket from the item-routing loop above. Each tab's skill summary
    // is the pre-categorised collection from _buildCategorisedSkills.
    context.elysiumArcaneTab = {
      // School skills (Evocation, Abjuration, etc.). Pre-v0.15.1 this bucket
      // also held F/T skills — see _buildCategorisedSkills for the split.
      arcaneSkills: context.elysiumSkills.magic.arcane.skills,
      // v0.15.1: Forms and Techniques as their own per-role buckets, surfaced
      // in their own collapsible sections on the Arcane tab. Each entry is
      // a regular skill item with system.elysium.arcaneRole === 'form' |
      // 'technique', editable via the skill's own item sheet.
      formSkills:      context.elysiumSkills.magic.arcane.formSkills,
      techniqueSkills: context.elysiumSkills.magic.arcane.techniqueSkills,
      // v0.10.0: active sustained spells, surfaced for the Arcane tab UI.
      activeSustains: this.document.getFlag('elysium', 'activeSustains') ?? [],
    }

    context.elysiumSorceryTab = {
      essenceSkills: context.elysiumSkills.magic.sorcery.skills,
    }

    context.elysiumMysticismTab = {
      focusSkills: context.elysiumSkills.magic.mysticism.skills,
      // The mysticism feats list is `context.mysticisms` (already sorted).
    }

    const faithAllegiances = context.allegiances.filter(a => /faith/i.test(a.name || ''))
    context.elysiumDivineTab = {
      channelingSkills: context.elysiumSkills.magic.divine.skills,
      faiths: faithAllegiances,
      // The divine spells list is `context.divines` (already sorted).
    }

    return context
  }

  //Activate event listeners using the prepared sheet HTML
  _onRender(context, _options) {
    this._dragDrop.forEach((d) => d.bind(this.element));
    this.element.querySelectorAll('.inline-edit').forEach(n => n.addEventListener("change", ElysiumActorSheetV2.skillInline.bind(this)))
    this.element.querySelectorAll('.addNewSection').forEach(n => n.addEventListener("click", ElysiumActorSheetV2.createBioSection.bind(this)))
    this.element.querySelectorAll('.move-section-up').forEach(n => n.addEventListener("click", ElysiumActorSheetV2.moveBioSectionUp.bind(this)))
    this.element.querySelectorAll('.move-section-down').forEach(n => n.addEventListener("click", ElysiumActorSheetV2.moveBioSectionDown.bind(this)))
    this.element.querySelectorAll('.delete-section').forEach(n => n.addEventListener("dblclick", ElysiumActorSheetV2.deleteBioSection.bind(this)))

  //Change Font Colours etc if the game settings are populated
    //Colours
    if (game.settings.get('elysium', 'actorFontColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--ely-legacy-colour-primary',game.settings.get('elysium', 'actorFontColour')))
    }
    if (game.settings.get('elysium', 'actorTitleColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--ely-legacy-colour-secondary',game.settings.get('elysium', 'actorTitleColour')))
    }
    if (game.settings.get('elysium', 'actorTertiaryColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--ely-legacy-colour-tertiary',game.settings.get('elysium', 'actorTertiaryColour')))
    }
    if (game.settings.get('elysium', 'iconPrimary')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--ely-legacy-icon-primary',game.settings.get('elysium', 'iconPrimary')))
    }
    if (game.settings.get('elysium', 'secBackColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--ely-legacy-labelback',game.settings.get('elysium', 'secBackColour')))
    }
    if (game.settings.get('elysium', 'actorRollableColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-rollable-colour',game.settings.get('elysium', 'actorRollableColour')))
    }
    if (game.settings.get('elysium', 'actorRollableShadowColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-rollable-shadow',game.settings.get('elysium', 'actorRollableShadowColour')))
    }
    if (game.settings.get('elysium', 'actorBackColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-sheet-back',game.settings.get('elysium', 'actorBackColour')))
    }
    if (game.settings.get('elysium', 'actorTabNameColour')) {
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-tab-name-colour',game.settings.get('elysium', 'actorTabNameColour')))
    }

    //Font Size - TODO need to review character sheet to see it impacts everywhere
    if (game.settings.get('elysium', 'charSheetMainFontSize')) {
      const fontSize = game.settings.get('elysium', 'charSheetMainFontSize')+'px'
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-main-font-size',fontSize))
    }
    if (game.settings.get('elysium', 'charSheetTitleFontSize')) {
      const fontSize = game.settings.get('elysium', 'charSheetTitleFontSize')+'px'
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-title-font-size',fontSize))
    }

    //Sheet Background
    if (game.settings.get('elysium', 'actorSheetBackground')) {
      const imagePath = "url(/" + game.settings.get('elysium', 'actorSheetBackground') + ")"
      document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-back-img',imagePath))
    }

    //Fonts
    if (game.settings.get('elysium', 'charSheetMainFont')) {
      const fontSource = "url(/" + game.settings.get('elysium', 'charSheetMainFont') + ")"
      const customSheetFont = new FontFace(
        'customSheetFont',
        fontSource
      )
      customSheetFont
        .load()
        .then(function (loadedFace) {
          document.fonts.add(loadedFace)
        })
        .catch(function (error) {
          ui.notifications.error(error)
        })
        document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-main-font','customSheetFont'))
    }

    if (game.settings.get('elysium', 'charSheetTitleFont')) {
      const fontSource = "url(/" + game.settings.get('elysium', 'charSheetTitleFont') + ")"
      const customTitleFont = new FontFace(
        'customTitleFont',
        fontSource
      )
      customTitleFont
        .load()
        .then(function (loadedFace) {
          document.fonts.add(loadedFace)
        })
        .catch(function (error) {
          ui.notifications.error(error)
        })
        document.querySelectorAll('.elysium.actor').forEach(el=>el.style.setProperty('--actor-title-font','customTitleFont'))
    }

  }
}

// =====================================================================
// ELYSIUM v0.7.0+ — Categorised skill collections
// =====================================================================
//
// Build a structured object the SKILLS tab template can iterate to
// render category sections. Reads `system.elysium.skillCategory` and
// `system.elysium.skillSubgroup` on each skill.
//
// Output shape:
//   {
//     standard:     { skills: [...], specialisms: { Lore: [...], Craft: [...], Language: [...], Exotic: [...] } },
//     career: { skills: [...], specialisms: {...} },
//     combat:       { skills: [...], specialisms: { Exotic: [...] } },
//     magic: {
//       arcane:    { skills: [...] },
//       sorcery:   { skills: [...] },
//       divine:    { skills: [...] },
//       mysticism: { skills: [...] },
//     },
//     // Counts used for header display + empty-section hiding
//     counts: { standard: N, career: N, combat: N, magic: { arcane: N, sorcery: N, ... } },
//   }
//
// Skills with no `skillCategory` (legacy or pre-v0.7.0 content) drop
// into a `uncategorised` bucket the template renders separately at the
// bottom — visible but flagged for the user to categorise.
// =====================================================================

function _buildCategorisedSkills(skillItems) {
  const out = {
    standard:     { skills: [], specialisms: {} },
    career: { skills: [], specialisms: {} },
    combat:       { skills: [], specialisms: {} },
    magic: {
      // v0.15.1: 'skills' aliases the previous bucket but holds only
      // school skills (Evocation, Abjuration, etc.) so the Skills tab's
      // Arcane subsection continues to render exactly what it did
      // pre-v0.15. F/T skills are routed into formSkills /
      // techniqueSkills so the Arcane tab can render them as their own
      // section. See character.arcane.hbs and character.mjs::_prepareItems.
      arcane:    { skills: [], formSkills: [], techniqueSkills: [] },
      sorcery:   { skills: [] },
      divine:    { skills: [] },
      mysticism: { skills: [] },
    },
    uncategorised: { skills: [] },
  }

  // Sort once, all subsequent operations preserve this ordering
  const sorted = [...skillItems].sort((a, b) => {
    const an = a.system?.specialism ? a.system.specName : a.name
    const bn = b.system?.specialism ? b.system.specName : b.name
    return (an || a.name).localeCompare(bn || b.name)
  })

  for (const item of sorted) {
    const cat = item.system?.elysium?.skillCategory || ''
    const sub = item.system?.elysium?.skillSubgroup || ''
    const isSpec = !!item.system?.specialism
    // Specialism parent name — for Lore (Arcana) → "Lore"
    const parent = isSpec ? (item.system?.mainName || _extractParent(item.name)) : ''

    const placeInBucket = (bucket) => {
      if (isSpec && parent) {
        if (!bucket.specialisms[parent]) bucket.specialisms[parent] = []
        bucket.specialisms[parent].push(item)
      } else {
        bucket.skills.push(item)
      }
    }

    if (cat === 'standard')        placeInBucket(out.standard)
    else if (cat === 'career') placeInBucket(out.career)
    else if (cat === 'combat')      placeInBucket(out.combat)
    else if (cat === 'magic') {
      if (sub === 'arcane') {
        // v0.15.1: route F/T skills (arcaneRole === 'form' | 'technique')
        // into their own buckets; everything else (school skills like
        // Evocation, Abjuration) stays in `skills`.
        const role = item.system?.elysium?.arcaneRole
        if (role === 'form')           out.magic.arcane.formSkills.push(item)
        else if (role === 'technique') out.magic.arcane.techniqueSkills.push(item)
        else                           out.magic.arcane.skills.push(item)
      }
      else if (sub === 'sorcery')  out.magic.sorcery.skills.push(item)
      else if (sub === 'divine')   out.magic.divine.skills.push(item)
      else if (sub === 'mysticism') out.magic.mysticism.skills.push(item)
      else                          out.uncategorised.skills.push(item)
    }
    else                            out.uncategorised.skills.push(item)
  }

  // Counts — useful for the template's section headers and for
  // hiding empty sections cleanly. magic.arcane is the school-skill
  // count only (matching what Skills-tab's Arcane subsection renders);
  // F/T have their own per-role counts surfaced on the Arcane tab.
  out.counts = {
    standard:     out.standard.skills.length     + _sumSpecCounts(out.standard.specialisms),
    career: out.career.skills.length + _sumSpecCounts(out.career.specialisms),
    combat:       out.combat.skills.length       + _sumSpecCounts(out.combat.specialisms),
    magic: {
      arcane:    out.magic.arcane.skills.length,
      arcaneForms:      out.magic.arcane.formSkills.length,
      arcaneTechniques: out.magic.arcane.techniqueSkills.length,
      sorcery:   out.magic.sorcery.skills.length,
      divine:    out.magic.divine.skills.length,
      mysticism: out.magic.mysticism.skills.length,
      total: out.magic.arcane.skills.length +
             out.magic.arcane.formSkills.length +
             out.magic.arcane.techniqueSkills.length +
             out.magic.sorcery.skills.length +
             out.magic.divine.skills.length + out.magic.mysticism.skills.length,
    },
    uncategorised: out.uncategorised.skills.length,
  }

  // Convert specialisms maps to arrays of {parent, items} for easier
  // iteration in Handlebars (which doesn't iterate object keys cleanly
  // when they're dynamic).
  out.standard.specialismList     = _specMapToList(out.standard.specialisms)
  out.career.specialismList = _specMapToList(out.career.specialisms)
  out.combat.specialismList       = _specMapToList(out.combat.specialisms)

  return out
}

function _extractParent(name) {
  // Handle "Lore (Arcana)" → "Lore"
  const m = name.match(/^([^(]+?)\s*\(/)
  return m ? m[1].trim() : name
}

function _sumSpecCounts(specMap) {
  return Object.values(specMap).reduce((s, arr) => s + arr.length, 0)
}

function _specMapToList(specMap) {
  return Object.keys(specMap).sort().map(parent => ({
    parent,
    items: specMap[parent],
    count: specMap[parent].length,
  }))
}
