/**
 * Elysium Rules — Hook registration
 *
 * All hooks live here in one file for visibility. The hooks
 * delegate to manager classes, which check settings before acting.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'
import { ElysiumAncestryDrop } from '../actor/ancestry-drop.mjs'
import { ElysiumFatigueManager } from '../fatigue/fatigue-manager.mjs'
import { ElysiumCriticalRoller } from '../critical/critical-roller.mjs'
import { ElysiumCombatExtension } from '../combat/combat-extension.mjs'
import { ElysiumMagic } from '../magic/magic.mjs'
import { ElysiumSheetExtension } from '../sheets/sheet-extension.mjs'

const M = ELYSIUM.MODULE_ID

export function registerHooks () {
  // Actor data preparation — adds Elysium derived stats
  Hooks.on('preCreateActor', _onPreCreateActor)
  Hooks.on('createActor', _onCreateActor)

  // Hook into prepareDerivedData via wrapping
  Hooks.on('updateActor', _onUpdateActor)

  // Item drop on actor — intercept ancestry, profession, etc.
  Hooks.on('preCreateItem', _onPreCreateItem)
  Hooks.on('createItem', _onCreateItem)
  Hooks.on('deleteItem', _onDeleteItem)

  // Sheet rendering — extend BRP sheets with Elysium UI
  Hooks.on('renderActorSheetV2', _onRenderActorSheet)
  Hooks.on('renderItemSheetV2', _onRenderItemSheet)

  // Combat — initiative, AP tracking, fatigue ticks
  Hooks.on('combatStart', _onCombatStart)
  Hooks.on('combatRound', _onCombatRound)
  Hooks.on('combatTurn', _onCombatTurn)
  Hooks.on('deleteCombat', _onCombatEnd)

  // HP changes — wound thresholds and critical table rolls
  Hooks.on('preUpdateActor', _onPreUpdateActor)
  Hooks.on('preUpdateItem', _onPreUpdateItem)
}


// === ACTOR HOOKS ====================================================

async function _onPreCreateActor (actor, data, options, userId) {
  if (!getSetting('masterEnable', true)) return

  // Initialise Elysium-specific actor flags structure
  await actor.updateSource({
    'flags.elysium': {
      version:           '0.1.0',
      luckPoints:        { value: 0, max: 0 },
      fatigue:           { level: 0, label: 'fresh', recoveryType: 'physical' },
      actionPoints:      { value: 0, max: 0, reactValue: 0, reactMax: 0 },
      tempHP:            { value: 0, max: 0 },
      ancestryId:        '',
      patron:            null,
      essences:          [],
      schoolMastery:     {},
      buildPoints:       { total: 0, ancestry: 0, spent: 0, remaining: 0 },
      skillPoints:       { total: 0, ancestry: 0, spent: 0, remaining: 0 },
      expDice:           { available: 0, diceSize: 4 },
    }
  })
}

async function _onCreateActor (actor, options, userId) {
  if (!getSetting('masterEnable', true)) return

  // Trigger derived stat calculation if configured
  ElysiumActorExtension.calculateDerivedStats(actor)
}

async function _onUpdateActor (actor, change, options, userId) {
  if (!getSetting('masterEnable', true)) return

  // Recalculate derived stats if relevant fields changed
  if (_relevantFieldChanged(change)) {
    ElysiumActorExtension.calculateDerivedStats(actor)
  }
}

function _relevantFieldChanged (change) {
  if (!change.system) return false
  return change.system.stats !== undefined ||
         change.system.health !== undefined ||
         change.system.power !== undefined ||
         change.system.fatigue !== undefined
}


// === ITEM HOOKS =====================================================

async function _onPreCreateItem (item, data, options, userId) {
  if (!getSetting('masterEnable', true)) return
  if (!item.parent) return // not on actor

  // Intercept ancestry drops
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    return await ElysiumAncestryDrop.handlePreCreate(item, data, options, userId)
  }

  // Intercept armour drops to apply Elysium layer rules
  if (item.type === 'armour' && getSetting('enableArmourLayering', true)) {
    return await ElysiumActorExtension.validateArmourLayer(item)
  }
}

async function _onCreateItem (item, options, userId) {
  if (!getSetting('masterEnable', true)) return
  if (!item.parent) return

  // Apply ancestry effects (mutations, AEs, mods) on creation
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    return await ElysiumAncestryDrop.handlePostCreate(item, options, userId)
  }
}

async function _onDeleteItem (item, options, userId) {
  if (!getSetting('masterEnable', true)) return
  if (!item.parent) return

  // Clean up ancestry-related items when ancestry removed
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    return await ElysiumAncestryDrop.handlePostDelete(item, options, userId)
  }
}


// === SHEET HOOKS ====================================================

async function _onRenderActorSheet (app, html, data) {
  if (!getSetting('masterEnable', true)) return
  await ElysiumSheetExtension.extendActorSheet(app, html, data)
}

async function _onRenderItemSheet (app, html, data) {
  if (!getSetting('masterEnable', true)) return
  await ElysiumSheetExtension.extendItemSheet(app, html, data)
}


// === COMBAT HOOKS ===================================================

function _onCombatStart (combat, updateData) {
  if (!getSetting('masterEnable', true)) return
  if (!getSetting('enableActionPoints', true)) return

  ElysiumCombatExtension.onCombatStart(combat, updateData)
}

function _onCombatRound (combat, updateData, updateOptions) {
  if (!getSetting('masterEnable', true)) return
  if (!getSetting('enableActionPoints', true)) return

  ElysiumCombatExtension.onRound(combat, updateData, updateOptions)
}

function _onCombatTurn (combat, updateData, updateOptions) {
  if (!getSetting('masterEnable', true)) return
  if (!getSetting('enableActionPoints', true)) return

  ElysiumCombatExtension.onTurn(combat, updateData, updateOptions)
}

function _onCombatEnd (combat, options, userId) {
  if (!getSetting('masterEnable', true)) return

  ElysiumCombatExtension.onCombatEnd(combat, options, userId)
}


// === HP CHANGE HOOKS ================================================

async function _onPreUpdateActor (actor, change, options, userId) {
  if (!getSetting('masterEnable', true)) return
  if (!getSetting('enableWoundThresholds', true)) return

  // Detect HP changes that cross wound thresholds
  if (change.system?.health !== undefined) {
    options.elysiumPrevHealth = foundry.utils.deepClone(actor.system.health)
  }
}

async function _onPreUpdateItem (item, change, options, userId) {
  if (!getSetting('masterEnable', true)) return
  if (!item.parent) return

  // Hit location HP change → check critical threshold
  if (item.type === 'hit-location' && change.system?.currHP !== undefined) {
    if (getSetting('enableCriticalTables', true)) {
      const newHp = change.system.currHP
      const maxHp = item.system.maxHP || 0
      const oldHp = item.system.currHP || 0

      // Triggered: HP just reached 0 (critical wound threshold)
      if (oldHp > 0 && newHp <= 0 && maxHp > 0) {
        options.elysiumTriggerCritical = {
          itemId:   item.id,
          location: item.system.locType || 'limb',
          actor:    item.parent.id,
        }
      }
    }
  }
}
