// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

export function injectAPIntoResources (html, actor) {
    const ap = actor.system?.actionPoints
    if (!ap) return

    const resourcesContainer = html.querySelector('.resources')
    if (!resourcesContainer) return

    // Avoid double-injection on re-render
    if (resourcesContainer.querySelector('.elysium-ap-resource')) return

    // Count existing resource panels and add 1 for AP
    const existingPanels = resourcesContainer.querySelectorAll('.each-resource').length
    const newCount = existingPanels + 1

    // Update the resource-Ncol class to keep alignment (2col → 3col → 4col → 5col)
    resourcesContainer.classList.remove(
      'resource-2col', 'resource-3col', 'resource-4col', 'resource-5col'
    )
    if (newCount >= 5) resourcesContainer.classList.add('resource-5col')
    else if (newCount === 4) resourcesContainer.classList.add('resource-4col')
    else if (newCount === 3) resourcesContainer.classList.add('resource-3col')
    else resourcesContainer.classList.add('resource-2col')

    // Build the AP panel matching BRP-base's structure (each-resource + resource-grid).
    // Format the suffix as "· A 1 · R 2 · D 1" with any pool at zero max omitted.
    // v0.20.0: four-pool model — general (value/max), attack (offensive
    // restricted), react (reactive general), defense (reactive restricted).
    const suffixBits = []
    if ((ap.attackMax || 0) > 0)  suffixBits.push(`A ${ap.attackValue || 0}`)
    if ((ap.reactMax || 0) > 0)   suffixBits.push(`R ${ap.reactValue || 0}`)
    if ((ap.defenseMax || 0) > 0) suffixBits.push(`D ${ap.defenseValue || 0}`)
    const suffixStr = suffixBits.length > 0 ? ` · ${suffixBits.join(' · ')}` : ''
    const apHtml = `
      <div class="each-resource centre elysium-ap-resource">
        <label class="resource-label"
               data-tooltip="${buildAPTooltip(ap)}">
          ${game.i18n.localize('Elysium.AP.Label')}
        </label>
        <div class="resource-grid">
          <div class="right">
            <a class="smallIcon" data-elysium-action="refreshAP"
               data-tooltip="${game.i18n.localize('Elysium.AP.RefreshTooltip')}">
              <i class="fas fa-rotate-right"></i>
            </a>
          </div>
          <input class="attrib-inp centre" type="number"
                 name="system.actionPoints.value"
                 value="${ap.value || 0}" data-dtype="Number"/>
          <span class="divider"> / </span>
          <div class="attrib-disp tertiary bold">${ap.max || 0}</div>
          <div class="left">
            <span class="elysium-ap-reaction"
                  data-tooltip="${game.i18n.localize('Elysium.AP.ReactionTooltip')}">
              ${suffixStr}
            </span>
          </div>
        </div>
      </div>
    `

    const wrapper = document.createElement('div')
    wrapper.innerHTML = apHtml
    resourcesContainer.appendChild(wrapper.firstElementChild)
  }

export function buildAPTooltip (ap) {
    const lines = [game.i18n.localize('Elysium.AP.Tooltip')]
    if (ap.breakdown?.base !== undefined) lines.push(`Base: ${ap.breakdown.base}`)
    if (ap.breakdown?.spell)    lines.push(`Spell: +${ap.breakdown.spell}`)
    if (ap.breakdown?.skill)    lines.push(`Skill: +${ap.breakdown.skill}`)
    if (ap.breakdown?.ancestry) lines.push(`Ancestry: +${ap.breakdown.ancestry}`)
    if (ap.breakdown?.items)    lines.push(`Items: +${ap.breakdown.items}`)
    if (ap.breakdown?.wound)    lines.push(`Wounds: ${ap.breakdown.wound}`)
    if (ap.breakdown?.fatigue)  lines.push(`Fatigue: ${ap.breakdown.fatigue}`)
    if ((ap.attackMax || 0) > 0)  lines.push(`Attack pool: ${ap.attackValue || 0}/${ap.attackMax} (your turn, attacks only)`)
    if ((ap.reactMax || 0) > 0)   lines.push(`React pool: ${ap.reactValue || 0}/${ap.reactMax} (others' turns, any reaction)`)
    if ((ap.defenseMax || 0) > 0) lines.push(`Defense pool: ${ap.defenseValue || 0}/${ap.defenseMax} (others' turns, parry/evade)`)
    return lines.join(' / ')
  }

export function makeHPEditable (html, actor) {
    const hpLabel = html.querySelector('[data-target="system.health"]')
    if (!hpLabel) return

    const hpPanel = hpLabel.closest('.each-resource')
    if (!hpPanel) return

    // Avoid double-injection on re-render
    if (hpPanel.querySelector('.elysium-thp-edit')) return

    const grid = hpPanel.querySelector('.resource-grid')
    if (!grid) return

    // The grid's children are: [right-icon, value-div, divider, max-div, left-icon]
    // Replace value-div (index 1) and max-div (index 3) with inputs.
    const children = grid.children
    if (children.length < 4) return

    const valueDiv = children[1]
    const maxDiv   = children[3]

    if (!valueDiv?.classList.contains('attrib-disp')) return
    if (!maxDiv?.classList.contains('attrib-disp')) return

    // Use the actual tempHP values, not the health-derived display
    const tempHP = actor.system?.tempHP || { value: 0, max: 0 }

    const valueInput = document.createElement('input')
    valueInput.type = 'number'
    valueInput.name = 'system.tempHP.value'
    valueInput.value = Number(tempHP.value) || 0
    valueInput.className = 'attrib-inp centre elysium-thp-edit'
    valueInput.dataset.dtype = 'Number'

    const maxInput = document.createElement('input')
    maxInput.type = 'number'
    maxInput.name = 'system.tempHP.max'
    maxInput.value = Number(tempHP.max) || 0
    maxInput.className = 'attrib-inp centre elysium-thp-edit'
    maxInput.dataset.dtype = 'Number'

    valueDiv.replaceWith(valueInput)
    maxDiv.replaceWith(maxInput)
  }
