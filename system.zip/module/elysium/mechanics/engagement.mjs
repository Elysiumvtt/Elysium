// =====================================================================
// ELYSIUM | Engagement helpers (Mythras Reach mechanics)
// =====================================================================
//
// Pure helper functions over the Mythras Reach rules. No UI here — the
// helpers are exposed via game.system.api.elysium.engagement for macro use, and
// consumed by the weapon-sheet effective-Size display in v0.5.3.
//
// Engagement state schema (set by the v0.5.4+ UI):
//
//   combatant.flags['elysium'].engagements = [
//     { withId: <combatantId>, reach: <Mythras letter>, weaponId: <itemId> },
//     ...
//   ]
//
// A combatant can have MULTIPLE engagements simultaneously — one per
// opponent. Each engagement is independent: different opponent, possibly
// different reach, possibly different wielded weapon.
//
// Mythras rules summary (for reference inside this file):
//   - Reach difference < 2 steps: no penalty either side
//   - Reach difference >= 2 steps: the longer-weapon wielder is
//     "encroached" if engaged at the shorter reach; the shorter-weapon
//     wielder is "held at bay" if engaged at the longer reach.
//   - Encroached wielder: weapon Size drops by N steps, damage capped
//     at 1d3+1.
//   - Held-at-bay wielder: cannot directly attack the opponent; can only
//     attack the weapon, close range, or use a Special Effect.
// =====================================================================

import { ELYSIUM } from '../config/config.mjs'
const REACH_ORDER_FALLBACK = ['T', 'S', 'M', 'L', 'VL', 'H']
const SIZE_ORDER_FALLBACK  = ['T', 'S', 'M', 'L', 'H', 'E']

function reachOrder () {
  return ELYSIUM.WEAPON_REACH_ORDER || REACH_ORDER_FALLBACK
}
function sizeOrder () {
  return ELYSIUM.WEAPON_SIZE_ORDER || SIZE_ORDER_FALLBACK
}

/**
 * Number of reach steps a weapon's reach is above (positive) or below
 * (negative) the engagement's current reach. 0 means equal.
 *
 *   weapon Reach = M, engagement reach = M  →  0
 *   weapon Reach = L, engagement reach = M  →  +1 (longer)
 *   weapon Reach = S, engagement reach = L  →  -2 (shorter)
 *
 * @param {string} weaponReach   - Mythras reach letter (T/S/M/L/VL/H)
 * @param {string} engagementReach - Mythras reach letter
 * @returns {number}
 */
export function getReachDifference (weaponReach, engagementReach) {
  const order = reachOrder()
  const wIdx = order.indexOf(weaponReach)
  const eIdx = order.indexOf(engagementReach)
  if (wIdx < 0 || eIdx < 0) return 0
  return wIdx - eIdx
}

/**
 * The wielder is "encroached" when engaged at a reach 2+ steps SHORTER
 * than their weapon. Long-spear used at Touch range: encroached by 3.
 * Returns the number of steps of encroachment, or 0 if not encroached.
 *
 * @param {string} weaponReach
 * @param {string} engagementReach
 * @returns {number}  0 if not encroached, else N>=2
 */
export function getEncroachmentSteps (weaponReach, engagementReach) {
  const diff = getReachDifference(weaponReach, engagementReach)
  return diff >= 2 ? diff : 0
}

/**
 * The wielder is "held at bay" when engaged at a reach 2+ steps LONGER
 * than their weapon. Dagger user vs greatsword wielder fighting at Long
 * reach: held at bay by 2 steps.
 *
 * @param {string} weaponReach
 * @param {string} engagementReach
 * @returns {number}  0 if not held at bay, else N>=2
 */
export function getHeldAtBaySteps (weaponReach, engagementReach) {
  const diff = getReachDifference(weaponReach, engagementReach)
  return diff <= -2 ? -diff : 0
}

/**
 * Effective Size of a weapon at the given engagement reach. When
 * encroached, Size drops by N steps (clamped to 'T').
 *
 * @param {object} weapon - weapon item or its system data
 * @param {string} engagementReach - Mythras reach letter
 * @returns {string} effective Size letter
 */
export function getEffectiveSize (weapon, engagementReach) {
  const sys = weapon?.system?.elysium || weapon?.elysium || weapon || {}
  const baseSize  = sys.weaponSize || 'M'
  const baseReach = sys.reach || 'M'

  const enc = getEncroachmentSteps(baseReach, engagementReach)
  if (enc === 0) return baseSize

  const order = sizeOrder()
  const baseIdx = order.indexOf(baseSize)
  if (baseIdx < 0) return baseSize
  const newIdx = Math.max(0, baseIdx - enc)
  return order[newIdx]
}

/**
 * True if the wielder can directly attack the opponent at this
 * engagement reach. False when held at bay.
 *
 * @param {object} weapon
 * @param {string} engagementReach
 * @returns {boolean}
 */
export function canDirectlyAttack (weapon, engagementReach) {
  const sys = weapon?.system?.elysium || weapon?.elysium || weapon || {}
  const baseReach = sys.reach || 'M'
  return getHeldAtBaySteps(baseReach, engagementReach) === 0
}

/**
 * Mythras damage cap when encroached. Returns null if no cap applies.
 * The official rule: encroached wielders' damage is capped at 1d3+1.
 *
 * @param {object} weapon
 * @param {string} engagementReach
 * @returns {string|null}  '1d3+1' if capped, null if normal damage
 */
export function getMaxDamage (weapon, engagementReach) {
  const sys = weapon?.system?.elysium || weapon?.elysium || weapon || {}
  const baseReach = sys.reach || 'M'
  const enc = getEncroachmentSteps(baseReach, engagementReach)
  return enc > 0 ? '1d3+1' : null
}

/**
 * Read all engagements stored on a combatant.
 *
 * @param {Combatant} combatant
 * @returns {Array<{withId, reach, weaponId}>}
 */
export function getEngagements (combatant) {
  return combatant?.flags?.['elysium']?.engagements || []
}

/**
 * Find the active engagement record between two combatants in the same
 * encounter. Returns null if not engaged.
 *
 * @param {Combatant} combatant
 * @param {string} otherCombatantId
 * @returns {object|null}
 */
export function getEngagementWith (combatant, otherCombatantId) {
  const list = getEngagements(combatant)
  return list.find(e => e.withId === otherCombatantId) || null
}

/**
 * Find any combatant on the active combat that the given actor is
 * engaged with. Useful for sheet displays that don't have direct access
 * to a combatant — pass an actor and we look up the combatant first.
 *
 * @param {Actor} actor
 * @returns {Array<{combatant, engagement}>}
 */
export function getActorEngagements (actor) {
  if (!actor) return []
  const combat = game.combat
  if (!combat) return []
  // Find every combatant for this actor (an actor can have multiple
  // tokens in the same combat — list each separately)
  const myCombatants = combat.combatants.filter(c => c.actorId === actor.id)
  const out = []
  for (const c of myCombatants) {
    const list = getEngagements(c)
    for (const eng of list) {
      out.push({ combatant: c, engagement: eng })
    }
  }
  return out
}

/**
 * Resolve the wielded weapon item from an engagement record.
 *
 * @param {Actor} actor
 * @param {object} engagement
 * @returns {Item|null}
 */
export function getEngagementWeapon (actor, engagement) {
  if (!actor || !engagement?.weaponId) return null
  return actor.items.get(engagement.weaponId) || null
}

/**
 * Public API exposed on game.system.api.elysium.engagement
 */
export const ElysiumEngagement = {
  // Constants & lookups
  REACH_ORDER: reachOrder,
  SIZE_ORDER:  sizeOrder,

  // Pure helpers
  getReachDifference,
  getEncroachmentSteps,
  getHeldAtBaySteps,
  getEffectiveSize,
  canDirectlyAttack,
  getMaxDamage,

  // State accessors
  getEngagements,
  getEngagementWith,
  getActorEngagements,
  getEngagementWeapon,
}
