// =====================================================================
// ELYSIUM | Charge mechanics (Mythras p102)
// =====================================================================
//
// Charging is the act of moving quickly to increase the force and impact
// of an attack. v0.5.7 implements "Charging into Contact" — the attacker
// stops in engagement after the charge.
//
// Common principles:
//   - Requires at least one full Combat Round of running/sprinting
//     prior to contact (NOT enforced — GM declares)
//   - Attacker takes +1 difficulty grade on the attack roll
//   - Attacker's Damage Mod increases by 1 step (bipedal) or 2 (4+ legs)
//   - Attacker's weapon Size increases by 1 step
//   - Defender's response options: Parry / Evade / Counterattack
//   - All charge benefits are lost after the first attack
//
// "Charging through Contact" (mounted/large creatures sweeping past) is
// DEFERRED to a future release. Surprise/ambush is also deferred.
// =====================================================================

import { ELYSIUM } from '../config/config.mjs'// ---- Damage Mod tier helpers ---------------------------------------
//
// v0.20.0: The Mythras Damage Mod tiers are defined canonically in
// ELYSIUM.DAMAGE_MOD_TABLE (config.mjs). Charge stepping walks that
// table by INDEX rather than maintaining a parallel private array.

/**
 * Step a Damage Modifier tier up (positive steps) or down (negative).
 *
 * Walks ELYSIUM.DAMAGE_MOD_TABLE — the canonical Mythras progression.
 * Each table row has a `dice` field (e.g. '+1d6'); we find the input
 * tier's row by matching dice, then add/subtract `steps` from that index,
 * clamping to the table bounds.
 *
 * @param {string} dmgmodTier  current tier string e.g. '+1d4'
 * @param {number} steps       positive to increase, negative to decrease
 * @returns {string}           resulting tier string (clamped to bounds)
 */
export function stepDamageMod (dmgmodTier, steps) {
  const table = ELYSIUM.DAMAGE_MOD_TABLE
  if (!Array.isArray(table) || table.length === 0) {
    return dmgmodTier || '+0'
  }
  const current = dmgmodTier || '+0'
  const idx = table.findIndex(row => row.dice === current)
  if (idx < 0) {
    // Unknown tier — return original unchanged
    return current
  }
  const newIdx = Math.max(0, Math.min(table.length - 1, idx + steps))
  return table[newIdx].dice
}

/**
 * Step a weapon Size tier up or down. Returns the resulting Mythras
 * Size letter (T/S/M/L/H/E), clamped to bounds.
 */
export function stepWeaponSize (sizeLetter, steps) {
  const order = ELYSIUM.WEAPON_SIZE_ORDER || ['T', 'S', 'M', 'L', 'H', 'E']
  const idx = order.indexOf(sizeLetter || 'M')
  if (idx < 0) return sizeLetter || 'M'
  const newIdx = Math.max(0, Math.min(order.length - 1, idx + steps))
  return order[newIdx]
}

/**
 * Compute charge bonuses for an attacker.
 *
 * Bipedal attackers get +1 Damage Mod step.
 * Quadrupedal+ attackers get +2 Damage Mod steps.
 * All chargers get +1 weapon Size step and +1 difficulty grade.
 *
 * @param {Actor}  attacker
 * @param {Item}   weapon
 * @returns {{damageMod, weaponSize, difficulty, legs}}
 */
export function computeChargeBonuses (attacker, weapon) {
  const baseDmgMod = attacker?.system?.dmgmodTier || '+0'
  const baseSize   = weapon?.system?.elysium?.weaponSize || 'M'

  // Detect quadruped+ via creature subtype if available; default to biped
  const subtype = attacker?.system?.elysium?.creatureSubtype || ''
  const tags    = attacker?.system?.elysium?.creatureTags || []
  const legs = (
    subtype === 'quadruped' ||
    tags.includes('quadruped') ||
    tags.includes('multilegged')
  ) ? 4 : 2

  const dmgModSteps = legs >= 4 ? 2 : 1
  const sizeSteps   = 1

  return {
    damageMod:  stepDamageMod(baseDmgMod, dmgModSteps),
    weaponSize: stepWeaponSize(baseSize, sizeSteps),
    difficulty: '+1 grade',
    legs,
  }
}

// ---- Knockback ------------------------------------------------------

/**
 * Compute knockback distance in feet given raw damage and defender's SIZ.
 *
 * Mythras p103: "An attack which imparts more damage than the SIZ of the
 * recipient will, by default, result in him being knocked back. The damage
 * in this circumstance is accounted before any reduction due to parrying
 * or armor. They are also thrust backwards one square (5 feet) for each
 * five points of damage (or fraction thereof) in excess of their SIZ."
 *
 * Brace reduces knockback by halving the excess damage before computing.
 *
 * v0.20.0: returns feet (5ft per square) — was metres in v0.19.x. Each 5
 * points of excess damage = 1 square = ELYSIUM.MOVEMENT.squareSizeFt feet.
 *
 * @param {number}  rawDamage    raw damage rolled (before parry/armor)
 * @param {number}  defenderSIZ  defender's SIZ stat
 * @param {boolean} braced       defender used Brace combat action
 * @returns {{feet, squares, mustRoll, prone, excess}}  knockback result
 */
export function computeKnockback (rawDamage, defenderSIZ, braced = false) {
  const dmg = Number(rawDamage) || 0
  const siz = Number(defenderSIZ) || 0
  let excess = Math.max(0, dmg - siz)

  if (braced) {
    excess = Math.floor(excess / 2)
  }

  if (excess <= 0) {
    return { feet: 0, squares: 0, mustRoll: false, prone: false, excess: 0 }
  }

  // 1 square per 5 damage over (or fraction thereof)
  const squares = Math.ceil(excess / 5)
  const squareSizeFt = ELYSIUM.MOVEMENT?.squareSizeFt || 5
  const feet = squares * squareSizeFt

  return {
    feet,
    squares,
    mustRoll: true,        // defender must roll Acrobatics/Athletics
    prone:    false,        // unknown until roll resolves
    excess,
  }
}

export const ElysiumCharge = {
  stepDamageMod,
  stepWeaponSize,
  computeChargeBonuses,
  computeKnockback,
}
