/**
 * Elysium Critical Roller
 *
 * Triggered when a hit location reaches 0 HP.
 * Rolls on the appropriate location-based critical table,
 * applies resulting conditions, handles escalation on already-critical
 * locations, and offers Luck Point save against instant death.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActiveEffectFactory } from '../active-effects/factory.mjs'
export class ElysiumCriticalRoller {

  /**
   * Trigger a critical roll for a given hit location item.
   * Called from the preUpdateItem hook when location HP crosses 0.
   */
  static async rollCritical (actor, hitLocationItem, options = {}) {
    if (!actor || !hitLocationItem) return null

    // Look up the table by bodyPart (head/chest/abdomen/leg/arm/etc.) first;
    // fall back to BRP locType for legacy data. This matters because BRP's
    // locType collapses legs and arms into 'limb', so without bodyPart we
    // can't tell which Critical table to roll on.
    const bodyPart = hitLocationItem.system?.elysium?.bodyPart
    const locType  = hitLocationItem.system?.locType || 'limb'
    const lookupKey = bodyPart || locType
    const tableKey = ELYSIUM.CRITICAL_TABLE_MAP[lookupKey]
                  || ELYSIUM.CRITICAL_TABLE_MAP[locType]
                  || ELYSIUM.CRITICAL_TABLE_MAP.default

    // Check for escalation: location already at 0 HP previously
    const isAlreadyCritical = (hitLocationItem.flags?.['elysium']?.criticalRolls?.length || 0) > 0
    let bonus = 0
    if (isAlreadyCritical) {
      bonus = (hitLocationItem.flags['elysium'].criticalRolls || [])
        .reduce((sum, r) => sum + r, 0)
    }

    // Roll
    const roll = await new Roll('1d10').evaluate()
    const result = roll.total
    let totalRoll = result + bonus

    // Cap at 10
    if (totalRoll > 10) totalRoll = 10

    // Look up entry from compendium RollTable
    const entry = await this._lookupEntry(tableKey, totalRoll)

    // Record this roll on the hit location for future escalation
    const rollHistory = hitLocationItem.flags?.['elysium']?.criticalRolls || []
    rollHistory.push(result)
    await hitLocationItem.update({
      'flags.elysium.criticalRolls': rollHistory,
    }, { render: false })

    // Handle instant death (10) with Luck Point save
    let savedByLuck = false
    if (totalRoll === 10 && entry?.severity === 'lethal' && entry?.instantDeath) {
      if (getSetting('enableLuckPoints', true)) {
        savedByLuck = await this._offerLuckPointSave(actor, entry)
      }
    }

    // Apply conditions / effects
    if (!savedByLuck && getSetting('autoApplyConditions', true)) {
      await this._applyCriticalEffects(actor, hitLocationItem, entry)
    } else if (savedByLuck) {
      // Reduced result: drop to Dying instead of dead
      await this._applyDying(actor)
    }

    // Build chat card
    await this._postChatCard(actor, hitLocationItem, entry, {
      naturalRoll: result,
      bonus,
      totalRoll,
      tableKey,
      savedByLuck,
    })

    return { entry, totalRoll, savedByLuck }
  }

  // === TABLE LOOKUP =================================================

  static async _lookupEntry (tableKey, roll) {
    // Try ElysiumCompendium module first (where content lives)
    let pack = game.packs.get('elysium-compendium.elysium-critical-tables')
    // Fall back to Elysium rules module (legacy / development)
    if (!pack) pack = game.packs.get('elysium.elysium-critical-tables')

    if (pack) {
      const tableId = await this._findTableIdByKey(pack, tableKey)
      if (tableId) {
        const table = await pack.getDocument(tableId)
        if (table) {
          const tableResult = table.results.find(r =>
            roll >= r.range[0] && roll <= r.range[1]
          )
          if (tableResult) {
            return this._parseTableResult(tableResult, tableKey, roll)
          }
        }
      }
    }

    // Fallback to fixed-data entry (always works even without compendium)
    return this._fallbackEntry(tableKey, roll)
  }

  static async _findTableIdByKey (pack, key) {
    const index = await pack.getIndex()
    const entry = index.find(e =>
      e.flags?.['elysium']?.criticalTableKey === key ||
      e.name?.toLowerCase().includes(key.toLowerCase())
    )
    return entry?._id
  }

  static _parseTableResult (tableResult, tableKey, roll) {
    return {
      tableKey,
      roll,
      name:        tableResult.text || tableResult.name || `Result ${roll}`,
      description: tableResult.description || '',
      conditions:  tableResult.flags?.['elysium']?.conditions || [],
      ongoing:     tableResult.flags?.['elysium']?.ongoing || [],
      permanent:   tableResult.flags?.['elysium']?.permanent || false,
      severity:    tableResult.flags?.['elysium']?.severity || this._inferSeverity(roll),
      instantDeath: tableResult.flags?.['elysium']?.instantDeath || (roll === 10),
    }
  }

  static _inferSeverity (roll) {
    if (roll <= 3) return 'serious'
    if (roll <= 7) return 'severe'
    return 'lethal'
  }

  /**
   * Fallback critical entries — built-in data so the system works
   * even before the compendium tables are populated.
   */
  static _fallbackEntry (tableKey, roll) {
    const tables = ELYSIUM.CRITICAL_TABLES_FALLBACK || FALLBACK_TABLES
    const table = tables[tableKey] || tables.body
    const entry = table[roll - 1] || table[table.length - 1]
    return {
      tableKey,
      roll,
      ...entry,
      severity: this._inferSeverity(roll),
      instantDeath: (roll === 10 && entry.lethal),
    }
  }

  // === EFFECT APPLICATION ===========================================

  static async _applyCriticalEffects (actor, hitLocation, entry) {
    if (!entry) return

    // Apply immediate conditions (actor-level: Difficult, Stunned, etc.)
    // The factory's applyCondition handles actor-level AE creation.
    // Per-location conditions go through applyLocationCondition instead.
    for (const condition of (entry.conditions || [])) {
      const def = ElysiumActiveEffectFactory.getDefinition(condition)
      if (def?.perLocation) {
        await ElysiumActiveEffectFactory.applyLocationCondition(
          actor, hitLocation.id, condition,
          { source: `crit:${entry.name}` }
        )
      } else {
        await this._applyCondition(actor, condition)
      }
    }

    // Apply ongoing conditions (Bleeding, Arterial Bleeding, etc.)
    for (const ongoing of (entry.ongoing || [])) {
      const def = ElysiumActiveEffectFactory.getDefinition(ongoing)
      if (def?.perLocation) {
        await ElysiumActiveEffectFactory.applyLocationCondition(
          actor, hitLocation.id, ongoing,
          { source: `crit:${entry.name}` }
        )
      } else {
        await this._applyCondition(actor, ongoing, { ongoing: true })
      }
    }

    // Stamp the critical-entry flag on the location for sheet display.
    // We no longer set `system.incapacitated` — the wound-tier system
    // (Healthy / Wounded / Severely Wounded / Critically Wounded /
    // Severed) communicates location status; BRP's incapacitated/injured
    // booleans are vestigial in the Elysium fork (v0.6.0+).
    //
    // We also no longer set `system.bleeding: true` directly — bleeding
    // from criticals is handled by the per-location applyLocationCondition
    // call above (Bleeding entries in the ongoing list).
    await hitLocation.update({
      'flags.elysium.criticalEntry': {
        roll:      entry.roll,
        name:      entry.name,
        severity:  entry.severity,
        permanent: entry.permanent,
      },
    })
  }

  /**
   * Apply a Mythras-named condition AE to the actor. Delegates to the
   * Active Effect factory, which is the single source of truth for
   * how condition AEs are constructed (including bleedRate, ongoingDamage,
   * stacking, etc. read from CONDITION_DEFINITIONS).
   *
   * `fromCritical: true` is stamped via extraFlags so future code can
   * tell critical-spawned conditions apart from manually-applied or
   * factory-default ones.
   */
  static async _applyCondition (actor, conditionName, options = {}) {
    return ElysiumActiveEffectFactory.applyCondition(actor, conditionName, {
      ongoing: !!options.ongoing,
      extraFlags: { fromCritical: true },
    })
  }

  static async _applyDying (actor) {
    await this._applyCondition(actor, 'Dying')
  }

  // === LUCK POINT SAVE ==============================================

  static async _offerLuckPointSave (actor, entry) {
    // Defense-in-depth: callers already guard this, but if anything else
    // ever invokes _offerLuckPointSave directly, the guard at the spend
    // point keeps the off-state honest.
    if (!getSetting('enableLuckPoints', true)) return false

    const luck = actor.system?.luckPoints?.value || 0
    if (luck <= 0) return false

    const content = `
      <div class="elysium-luck-save">
        <h3>${game.i18n.localize('Elysium.Luck.InstantDeathSaveTitle')}</h3>
        <p>${game.i18n.localize('Elysium.Luck.InstantDeathSaveBody')}</p>
        <p><strong>${entry.name}</strong></p>
        <p>${game.i18n.format('Elysium.Luck.PointsAvailable', { count: luck })}</p>
      </div>
    `
    // DialogV2.wait resolves with the action string of the clicked button,
    // or with whatever the per-button callback returns. Cancel/window-close
    // returns null because rejectClose:false.
    const result = await foundry.applications.api.DialogV2.wait({
      window: { title: game.i18n.localize('Elysium.Luck.SaveTitle') },
      content,
      buttons: [
        { action: 'die', label: game.i18n.localize('Elysium.Luck.AcceptDeath') },
        { action: 'save', label: game.i18n.localize('Elysium.Luck.SpendOne'), default: true,
          callback: async () => {
            await actor.update({
              'system.luckPoints.value': luck - 1,
            })
            const luckBody = `<p><strong>${actor.name}</strong> ${game.i18n.localize('Elysium.Luck.SpentForSave')}</p>`
            const luckHtml = await foundry.applications.handlebars.renderTemplate(
              'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
              { variant: 'bonus', icon: 'star', body: luckBody }
            )
            ChatMessage.create({
              speaker: ChatMessage.getSpeaker({ actor }),
              content: luckHtml,
            })
            return 'save'
          }},
      ],
      rejectClose: false,
    })
    return result === 'save'
  }

  // === CHAT CARD ====================================================

  static async _postChatCard (actor, hitLocation, entry, rollMeta) {
    if (!entry) return

    const body = `<p>${actor.name}</p>
      <p><strong>${game.i18n.localize('Elysium.Critical.Roll')}:</strong>
         ${rollMeta.naturalRoll}${rollMeta.bonus > 0 ? ` + ${rollMeta.bonus}` : ''} → ${rollMeta.totalRoll}</p>
      <p><strong>${entry.name}</strong></p>
      <p><em>${entry.description || ''}</em></p>
      ${entry.conditions?.length ? `<p><strong>${game.i18n.localize('Elysium.Critical.Effects')}:</strong></p><ul>${entry.conditions.map(c => `<li>${c}</li>`).join('')}</ul>` : ''}
      ${entry.ongoing?.length ? `<p><strong>${game.i18n.localize('Elysium.Critical.Ongoing')}:</strong></p><ul>${entry.ongoing.map(c => `<li>${c}</li>`).join('')}</ul>` : ''}
      ${entry.permanent ? `<p>⚠ ${game.i18n.localize('Elysium.Critical.PermanentNote')}</p>` : ''}
      ${rollMeta.savedByLuck ? `<p>✦ ${game.i18n.localize('Elysium.Luck.SavedByLuck')}</p>` : ''}`

    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
      {
        variant: 'danger',
        title: `⚠ ${game.i18n.localize('Elysium.Critical.Title')} — ${hitLocation.name}`,
        icon: 'skull-crossbones',
        body,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  }
}

// Built-in fallback critical tables — used when compendium not loaded
const FALLBACK_TABLES = {
  head: [
    { name: 'Ringing Blow',       conditions: ['Staggered'],         ongoing: [],           permanent: false },
    { name: 'Eye Flash',          conditions: ['Blinded (1D3 rounds)'], ongoing: [],        permanent: false },
    { name: 'Rattled Teeth',      conditions: ['Difficult verbal spells'], ongoing: [],     permanent: false },
    { name: 'Fractured Cheekbone',conditions: ['Difficult'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Concussion',         conditions: ['Stunned','Difficult'],ongoing: [],          permanent: false },
    { name: 'Shattered Nose',     conditions: ['Difficult'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Burst Eardrum',      conditions: ['Deafened (one side)'],ongoing: [],          permanent: true  },
    { name: 'Eye Destroyed',      conditions: ['Blinded (one eye)'], ongoing: [],           permanent: true  },
    { name: 'Skull Fracture',     conditions: ['Unconscious','Dying'],ongoing: ['Arterial Bleeding'], permanent: true  },
    { name: 'Decapitated',        conditions: ['Dead'],              ongoing: [],           permanent: true, lethal: true },
  ],
  arm: [
    { name: 'Numbed Limb',        conditions: ['Arm unusable 1 round'], ongoing: [],        permanent: false },
    { name: 'Deep Gash',          conditions: ['Difficult'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Sprained Wrist',     conditions: ['Difficult'],         ongoing: [],           permanent: false },
    { name: 'Torn Muscle',        conditions: ['Difficult'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Dislocated Shoulder',conditions: ['Arm unusable','Very Difficult'], ongoing: [], permanent: false },
    { name: 'Fractured Forearm',  conditions: ['Arm unusable'],      ongoing: ['Bleeding'], permanent: false },
    { name: 'Compound Fracture',  conditions: ['Arm unusable','Stunned'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Severed Tendons',    conditions: ['Hand permanently useless'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Arm Shattered',      conditions: ['Arm unusable','Dying'], ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Arm Severed',        conditions: ['Arm lost','Dying'],  ongoing: ['Arterial Bleeding'], permanent: true, lethal: true },
  ],
  body: [
    { name: 'Winded',             conditions: ['Staggered','-1 AP next round'], ongoing: [], permanent: false },
    { name: 'Bruised Ribs',       conditions: ['Difficult','-1 AP'], ongoing: [],           permanent: false },
    { name: 'Deep Wound',         conditions: [],                    ongoing: ['Bleeding'], permanent: false },
    { name: 'Cracked Ribs',       conditions: ['Difficult','-1 AP'], ongoing: ['Bleeding'], permanent: false },
    { name: 'Punctured Lung',     conditions: ['-1 AP','Difficult'], ongoing: ['Suffocating'], permanent: true },
    { name: 'Ruptured Organ',     conditions: ['Dying'],             ongoing: ['Internal Bleeding'], permanent: true },
    { name: 'Spinal Strike',      conditions: ['Paralysed','Dying'], ongoing: [],           permanent: true },
    { name: 'Gutted',             conditions: ['Dying'],             ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Heart Struck',       conditions: ['Dying'],             ongoing: [],           permanent: true },
    { name: 'Destroyed Torso',    conditions: ['Dead'],              ongoing: [],           permanent: true, lethal: true },
  ],
  leg: [
    { name: 'Knee Strike',        conditions: ['Prone','Half move'], ongoing: [],           permanent: false },
    { name: 'Deep Thigh Gash',    conditions: ['-5ft move'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Twisted Knee',       conditions: ['Half move'],         ongoing: [],           permanent: false },
    { name: 'Torn Hamstring',     conditions: ['Quarter move','Difficult'], ongoing: ['Bleeding'], permanent: false },
    { name: 'Fractured Shin',     conditions: ['Half move'],         ongoing: ['Bleeding'], permanent: false },
    { name: 'Shattered Kneecap',  conditions: ['Leg unusable'],      ongoing: ['Bleeding'], permanent: true },
    { name: 'Compound Leg Fracture', conditions: ['Leg unusable','Prone','Stunned'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Severed Femoral Artery', conditions: ['Dying'],         ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Leg Shattered',      conditions: ['Leg unusable','Dying'], ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Leg Severed',        conditions: ['Leg lost','Dying'],  ongoing: ['Arterial Bleeding'], permanent: true, lethal: true },
  ],
  tailWing: [
    { name: 'Clipped Wing',       conditions: ['Cannot fly this round'], ongoing: [],       permanent: false },
    { name: 'Tail Lash Wound',    conditions: ['-20% tail attacks'], ongoing: ['Bleeding'], permanent: false },
    { name: 'Wing Membrane Tear', conditions: ['Fly Move halved'],   ongoing: ['Bleeding'], permanent: false },
    { name: 'Tail Joint Broken',  conditions: ['Tail unusable'],     ongoing: [],           permanent: false },
    { name: 'Wing Bone Fractured',conditions: ['Cannot fly'],        ongoing: ['Bleeding'], permanent: false },
    { name: 'Wing Destroyed',     conditions: ['Cannot fly until magically healed'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Tail Severed',       conditions: ['Tail lost','-20% physical (balance)'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Wing Torn Off',      conditions: ['Wing lost','Dying'], ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Spine Exposed',      conditions: ['Paralysed','Dying'], ongoing: [],           permanent: true },
    { name: 'Catastrophic',       conditions: ['Dead'],              ongoing: [],           permanent: true, lethal: true },
  ],
  aquatic: [
    { name: 'Bruised Fin',        conditions: ['Half swim move'],    ongoing: [],           permanent: false },
    { name: 'Torn Membrane',      conditions: ['Difficult swim'],    ongoing: ['Bleeding'], permanent: false },
    { name: 'Damaged Gill',       conditions: ['-1 AP underwater'],  ongoing: [],           permanent: false },
    { name: 'Pierced Fin',        conditions: ['Quarter swim move'], ongoing: ['Bleeding'], permanent: false },
    { name: 'Tentacle Crushed',   conditions: ['Tentacle unusable'], ongoing: ['Bleeding'], permanent: false },
    { name: 'Gill Severed',       conditions: ['Suffocating underwater'], ongoing: ['Bleeding'], permanent: true },
    { name: 'Tentacle Severed',   conditions: ['Tentacle lost'],     ongoing: ['Bleeding'], permanent: true },
    { name: 'Fin Severed',        conditions: ['Cannot swim'],       ongoing: ['Arterial Bleeding'], permanent: true },
    { name: 'Lateral Line Destroyed', conditions: ['Blinded underwater','Dying'], ongoing: [], permanent: true },
    { name: 'Catastrophic Aquatic', conditions: ['Dead'],            ongoing: [],           permanent: true, lethal: true },
  ],
}
