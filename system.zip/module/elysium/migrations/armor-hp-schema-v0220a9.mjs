// =====================================================================
// ELYSIUM | Armor schema migration v0.21.x → v0.22.0-alpha.9
// =====================================================================
//
// Migrates armor items from the old location-scaled HP model to the new
// flat-AP model:
//
//   OLD: system.elysium.armorHP = { base, value, max }
//        where base = catalog HP, max = base × location-factor, value = current HP
//
//   NEW: system.elysium.apMax = number   (max AP for repair)
//        system.av1            = number   (current AP, BRP-standard field)
//        Piece is broken when av1 reaches 0.
//
// Migration logic per item:
//   - If apMax is already set, skip (already migrated)
//   - Otherwise, take armorHP.base ?? armorHP.max ?? av1 as apMax
//   - Set av1 to armorHP.value ?? armorHP.base ?? armorHP.max (current,
//     bounded by apMax)
//   - Clear the armorHP object (set to null so Foundry removes it)
//
// Scoped to:
//   - actor-owned armor items (every actor in game.actors)
//   - world-collection armor items (game.items)
//
// Compendium pack contents are NOT migrated by this script — the catalog
// pack file (compendium/packs/armor.db) is migrated separately at build
// time so freshly-imported items already have the new schema.
//
// Idempotent: re-running has no effect (each item is skipped once apMax
// is set). Guarded by a world-level flag so it only runs once per world.
// =====================================================================

const MODULE_ID = 'elysium'
const MIGRATION_SETTING_KEY = 'armorHpSchemaMigrated_v0220a9'

/**
 * Register the migration-flag setting. Called from registerSettings()
 * during init. Hidden (config:false) — it's an internal one-way latch,
 * not a user-tunable option.
 */
export function registerArmorHpMigrationSetting () {
  if (!game.settings) return
  // Idempotent: registering twice would throw, so guard
  try {
    game.settings.register(MODULE_ID, MIGRATION_SETTING_KEY, {
      name:    'Armor HP schema migrated (v0.22.0-alpha.9)',
      scope:   'world',
      config:  false,
      type:    Boolean,
      default: false,
    })
  } catch (err) {
    // already registered, ignore
  }
}

/**
 * Run the migration once per world, on ready. Idempotent; the setting
 * flag guards against re-runs even though the per-item migration logic
 * is also idempotent.
 */
export async function migrateArmorHpSchemaOnce () {
  // Only the GM runs the migration to avoid duplicate updates across
  // connected clients.
  if (!game.user?.isGM) return

  let already = false
  try {
    already = game.settings.get(MODULE_ID, MIGRATION_SETTING_KEY) === true
  } catch (err) {
    // Setting not registered yet — fall through and try to register it
    console.warn('Elysium | armor-migration setting not registered; running anyway:', err.message)
  }
  if (already) {
    console.log('Elysium | Armor schema migration already ran on this world; skipping.')
    return
  }

  const stats = { actorsScanned: 0, itemsScanned: 0, itemsMigrated: 0, errors: 0 }

  // 1) Actor-owned items
  for (const actor of game.actors?.contents || []) {
    stats.actorsScanned++
    for (const item of actor.items.filter(i => i.type === 'armor')) {
      stats.itemsScanned++
      try {
        const updated = await _migrateOne(item)
        if (updated) stats.itemsMigrated++
      } catch (err) {
        stats.errors++
        console.error('Elysium | armor migration failed for', actor.name, '>', item.name, err)
      }
    }
  }

  // 2) World-collection items (loose items not owned by an actor)
  for (const item of (game.items?.contents || []).filter(i => i.type === 'armor')) {
    stats.itemsScanned++
    try {
      const updated = await _migrateOne(item)
      if (updated) stats.itemsMigrated++
    } catch (err) {
      stats.errors++
      console.error('Elysium | armor migration failed for world item', item.name, err)
    }
  }

  // Set the migration flag so we don't run again
  try {
    await game.settings.set(MODULE_ID, MIGRATION_SETTING_KEY, true)
  } catch (err) {
    console.warn('Elysium | could not persist migration flag:', err.message)
  }

  console.log(
    'Elysium | Armor schema migration complete:',
    `actorsScanned=${stats.actorsScanned}, itemsScanned=${stats.itemsScanned}, ` +
    `itemsMigrated=${stats.itemsMigrated}, errors=${stats.errors}`
  )

  if (stats.itemsMigrated > 0) {
    ui.notifications?.info(
      `Elysium: migrated ${stats.itemsMigrated} armor item(s) to the new flat-AP schema.`
    )
  }
}

/**
 * Migrate a single armor item. Returns true if an update was performed,
 * false if the item already had the new schema (no-op).
 */
async function _migrateOne (item) {
  const ely = item.system?.elysium || {}

  // Already migrated? (apMax is the new field; if it's a positive number,
  // the item is on the new schema regardless of whether armorHP also exists)
  if (typeof ely.apMax === 'number' && ely.apMax > 0) return false

  const armorHP = ely.armorHP
  const currentAv1 = Number(item.system?.av1) || 0

  // Pick the new apMax. Priority: armorHP.base (catalog value, un-scaled)
  // > armorHP.max (last-known scaled max) > current av1 (last resort)
  let apMax = 0
  if (armorHP && typeof armorHP.base === 'number') apMax = armorHP.base
  else if (armorHP && typeof armorHP.max === 'number') apMax = armorHP.max
  else apMax = currentAv1

  // Pick the new av1. Priority: armorHP.value (current HP) > armorHP.base
  // (full piece) > current av1
  let newAv1
  if (armorHP && typeof armorHP.value === 'number' && armorHP.value >= 0) {
    newAv1 = armorHP.value
  } else if (armorHP && typeof armorHP.base === 'number') {
    newAv1 = armorHP.base
  } else {
    newAv1 = currentAv1
  }

  // Bound by apMax. Allow newAv1 == apMax (fully repaired) but not over.
  newAv1 = Math.max(0, Math.min(newAv1, apMax))

  await item.update({
    'system.av1': newAv1,
    'system.elysium.apMax': apMax,
    'system.elysium.armorHP': null,   // Foundry removes null-valued objects
  })
  return true
}
