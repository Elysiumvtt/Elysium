/**
 * PersonalityDataModel — schema for items of type 'personality'.
 *
 * A personality bundles two skill lists:
 *   - `skills`: flat list of skills the personality always grants
 *   - `groups`: optional skill groups; each group offers `options` choices
 *     out of the listed skills
 *
 * Both lists use the {uuid, elysiumid} reference shape that gets resolved
 * in the sheet's _prepareContext (personality.mjs:39-56) and during
 * actor-itemDrop ingestion.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. Uses makeItemBase().
 *
 * Field decisions:
 *   - The {uuid, elysiumid} pair is the canonical drag-and-drop output
 *     in personality.mjs:_onDrop (lines 201, 221). uuid is the source
 *     compendium item's UUID; elysiumid is the stable content-ID per the
 *     ElysiumID system (P4 hotfix renamed brpidFlag → elysiumidFlag).
 *   - `groups` is an array of {options, skills: [{uuid, elysiumid}]} —
 *     personality.mjs:237 creates new groups as {options: 1, skills: []}.
 *   - This same shape will be needed by P6.2 culture and P6.5 career.
 *     Not factoring into _shared.mjs yet — waiting until P6.2 confirms
 *     bit-identical reuse there (per project decision: avoid premature
 *     abstraction).
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

function makeSkillRef () {
  return new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
  })
}

export class PersonalityDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      skills: new fields.ArrayField(makeSkillRef(), { initial: [] }),
      groups: new fields.ArrayField(
        new fields.SchemaField({
          options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
          skills:  new fields.ArrayField(makeSkillRef(), { initial: [] }),
        }),
        { initial: [] },
      ),
    }
  }
}
