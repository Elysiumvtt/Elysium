export class ElysiumSelectLists {

  //Attribute List
  static async getStatOptions() {
    const options = {
      "fixed": game.i18n.localize("Elysium.fixed"),
      "str": game.i18n.localize("Elysium.StatsStrAbbr"),
      "con": game.i18n.localize("Elysium.StatsConAbbr"),
      "siz": game.i18n.localize("Elysium.StatsSizAbbr"),
      "int": game.i18n.localize("Elysium.StatsIntAbbr"),
      "pow": game.i18n.localize("Elysium.StatsPowAbbr"),
      "dex": game.i18n.localize("Elysium.StatsDexAbbr"),
      "cha": game.i18n.localize("Elysium.StatsChaAbbr"),
      "edu": game.i18n.localize("Elysium.StatsEduAbbr"),
    };
    return options;
  }

  //Additional Attribute List
  static async addStatOptions(characteristic) {
    let options = {
      "none": game.i18n.localize("Elysium.none"),
      "str": game.i18n.localize("Elysium.StatsStrAbbr"),
      "con": game.i18n.localize("Elysium.StatsConAbbr"),
      "siz": game.i18n.localize("Elysium.StatsSizAbbr"),
      "int": game.i18n.localize("Elysium.StatsIntAbbr"),
      "pow": game.i18n.localize("Elysium.StatsPowAbbr"),
      "dex": game.i18n.localize("Elysium.StatsDexAbbr"),
      "cha": game.i18n.localize("Elysium.StatsChaAbbr"),
    }
    if (false) {
      options = Object.assign(options, { 'edu': game.i18n.localize("Elysium.StatsEduAbbr") })
    }
    return options;
  }

  //Skill Category List
  //
  // v0.19.0 fix: The shipped skills.db uses short codes (mentmod, knowmod,
  // cmbtmod, comnmod, mnplmod, physmod) for `system.category`. The original
  // implementation tried to look up elysiumid-keyed skillcat items from the
  // compendium, but the compendium doesn't ship any skillcat items, so the
  // dropdown rendered empty. Skill data is unchanged; only the option list
  // is corrected to match.
  //
  // The values returned here match what's stored on every skill in the
  // shipped compendium. The display labels follow BRP convention.
  static async getCategoryOptions() {
    const options = {
      "cmbtmod":  game.i18n.localize("Elysium.cmbtmod"),
      "comnmod":  game.i18n.localize("Elysium.comnmod"),
      "knowmod":  game.i18n.localize("Elysium.knowmod"),
      "mentmod":  game.i18n.localize("Elysium.mentmod"),
      "mnplmod":  game.i18n.localize("Elysium.mnplmod"),
      "physmod":  game.i18n.localize("Elysium.physmod"),
      "zcmbtmod": game.i18n.localize("Elysium.zcmbtmod"),
    };
    // Fallback to hardcoded English labels for any keys missing in the lang file.
    // (The shipped en.json has gaps: mentmod, knowmod, cmbtmod, comnmod have no
    // Elysium.<key> entries, so localize() returns the key unchanged.)
    const fallbacks = {
      "cmbtmod":  "Combat",
      "comnmod":  "Communication",
      "knowmod":  "Knowledge",
      "mentmod":  "Mental",
      "mnplmod":  "Manipulation",
      "physmod":  "Physical",
      "zcmbtmod": "Combat (Weapon)",
    };
    for (const [key, label] of Object.entries(options)) {
      // localize() returns the key string if the translation is missing
      if (label === `Elysium.${key}` || label === key) {
        options[key] = fallbacks[key];
      }
    }
    return options;
  }

  //Weapon Category List
  static async getWpnCategoryOptions() {
    const options = {
      "artillery": game.i18n.localize("Elysium.artillery"),
      "energy": game.i18n.localize("Elysium.energy"),
      "explosive": game.i18n.localize("Elysium.explosive"),
      "firearm": game.i18n.localize("Elysium.firearm"),
      "heavy": game.i18n.localize("Elysium.heavy"),
      "melee": game.i18n.localize("Elysium.melee"),
      "missile": game.i18n.localize("Elysium.missile"),
      "shield": game.i18n.localize("Elysium.shield"),
    };
    return options;
  }

  //Dam Bonus Category List
  static async getDamBonusOptions() {
    const options = {
      "none": game.i18n.localize("Elysium.none"),
      "half": game.i18n.localize("Elysium.half"),
      "full": game.i18n.localize("Elysium.full"),
      "dbl": game.i18n.localize("Elysium.double"),
      "oneH": game.i18n.localize("Elysium.oneH"),
      "str":  game.i18n.localize("Elysium.strDB"),
    };
    return options;
  }

  //Special Success  Category List
  static async getSpecialOptions() {
    const options = {
      "none": game.i18n.localize("Elysium.none"),
      "bleed": game.i18n.localize("Elysium.bleed"),
      "crush": game.i18n.localize("Elysium.crush"),
      "entangle": game.i18n.localize("Elysium.entangle"),
      "fire": game.i18n.localize("Elysium.fire"),
      "impale": game.i18n.localize("Elysium.impale"),
      "knockback": game.i18n.localize("Elysium.knockback"),
      "impknock": game.i18n.localize("Elysium.impknock"),
      "crushknock": game.i18n.localize("Elysium.crushknock"),
      "stun": game.i18n.localize("Elysium.stun"),
    };
    return options;
  }

  //Funcational Options List
  static async getFunctionalOptions() {
    const options = {
      "and": game.i18n.localize("Elysium.and"),
      "or": game.i18n.localize("Elysium.or"),
    };
    return options;
  }

  //Advanced Skill Category Options List
  static async getAdvSkillCatOptions() {
    const options = {
      "0": game.i18n.localize("Elysium.advSkillCat.0"),
      "1": game.i18n.localize("Elysium.advSkillCat.1"),
      "2": game.i18n.localize("Elysium.advSkillCat.2"),
      "3": game.i18n.localize("Elysium.advSkillCat.3"),
      "4": game.i18n.localize("Elysium.advSkillCat.4"),
    };
    return options;
  }

  //Wealth Options
  static getWealthOptions(min, max) {
    let options = {}
    let newOption = {}
    for (let i = 0; i <= max; i++) {
      if (i >= min) {
        newOption = { [i]: game.i18n.localize("Elysium.wealthLevel." + i), };
        options = Object.assign(options, newOption)
      }
    }
    return options
  }

  //Powers Category List
  static async getPowerCatOptions() {
    const options = {
      "magic": game.i18n.localize("Elysium.magic"),
      "mutation": game.i18n.localize("Elysium.mutation"),
      "psychic": game.i18n.localize("Elysium.psychic"),
      "sorcery": game.i18n.localize("Elysium.sorcery"),
      "super": game.i18n.localize("Elysium.super")
    };
    return options;
  }

  //Power Level List
  static async getPowerLvlOptions() {
    const options = {
      "normal": game.i18n.localize("Elysium.normal"),
      "epic": game.i18n.localize("Elysium.epic"),
      "heroic": game.i18n.localize("Elysium.heroic"),
      "superhuman": game.i18n.localize("Elysium.superhuman"),
    };
    return options;
  }

  //Spell Category List
  static async getSpellCatOptions() {
    const options = {
      "damage": game.i18n.localize("Elysium.damage"),
      "healing": game.i18n.localize("Elysium.healing"),
      "other": game.i18n.localize("Elysium.other"),
    };
    return options;
  }

  //Mutation Category List
  static async getMutationCatOptions() {
    const options = {
      "adv": game.i18n.localize("Elysium.adv"),
      "dis": game.i18n.localize("Elysium.dis"),
    };
    return options;
  }

  //Armor Burden List
  static async getArmorBurdenOptions() {
    const options = {
      "none": game.i18n.localize("Elysium.none"),
      "light": game.i18n.localize("Elysium.light"),
      "moderate": game.i18n.localize("Elysium.moderate"),
      "cumbersome": game.i18n.localize("Elysium.cumbersome"),
    };
    return options;
  }

  //Price Categories List
  static async getPriceOptions() {
    const options = {
      "none": game.i18n.localize("Elysium.none"),
      "cheap": game.i18n.localize("Elysium.cheap"),
      "inexpensive": game.i18n.localize("Elysium.inexpensive"),
      "average": game.i18n.localize("Elysium.average"),
      "expensive": game.i18n.localize("Elysium.expensive"),
      "priceless": game.i18n.localize("Elysium.priceless"),
      "restricted": game.i18n.localize("Elysium.restricted"),
    };
    return options;
  }

  //Hit Loc Options
  static getHitLocOptions(actor) {
    let options = {}
    let newOption = {}
    for (let i of actor.items) {
      if (i.type === 'hit-location') {
        if (i.system.locType != 'general') {
          newOption = { [i.id]: i.system.displayName, };
          options = Object.assign(options, newOption)
        } else if (!true && i.system.locType === 'general') {
          newOption = { [i.id]: i.name, };
          options = Object.assign(options, newOption)
        }
      }
    }
    return options
  }

  //Equipped List
  static async getEquippedOptions(type) {
    // Elysium fork: binary equipped/stowed for all item types
    return {
      "equipped": game.i18n.localize("Elysium.equipped"),
      "stowed":   game.i18n.localize("Elysium.stowed"),
    }
  }

  //Weapon Skill Options
  static async getWeaponSkillOptions(skillId) {
    const skillList = await game.system.api.elysiumid.fromElysiumIDRegexBest({ elysiumidRegExp: new RegExp('^i.skill'), type: 'i' })
    const newList = skillList.filter(itm => (itm.system.combat || itm.system.category === 'i.skillcat.combat')).map(itm => { return { elysiumid: itm.flags.elysium.elysiumidFlag.id, name: itm.name } })
    newList.sort(function (a, b) {
      const x = a.name;
      const y = b.name;
      if (x < y) { return -1 };
      if (x > y) { return 1 };
      return 0;
    });

    let options = {}
    let newOption = {}
    if (skillId != "1") {
      newOption = { "none": game.i18n.localize("Elysium.none") };
      options = Object.assign(options, { "none": game.i18n.localize("Elysium.none") })
    }

    for (let itm of newList) {
      if (itm.elysiumid) {
        options = Object.assign(options, { [itm.elysiumid]: itm.name })
      }
    }
    return options
  }

  //Handed List
  static async getHandedOptions() {
    const options = {
      "none": game.i18n.localize("Elysium.none"),
      "1H": game.i18n.localize("Elysium.1H"),
      "2H": game.i18n.localize("Elysium.2H"),
      "1-2H": game.i18n.localize("Elysium.1-2H"),
    };
    return options;
  }

  //Difficulty List
  static async getDifficultyOptions() {
    // v0.14.0: Mythras-canon difficulty grades replace BRP-flavor names.
    // Multipliers per Mythras core rulebook:
    //   Very Easy x3, Easy x2, Routine x1.5, Average x1,
    //   Difficult x0.5, Formidable x0.25, Impossible x0.1.
    const options = {
      "veryEasy":  game.i18n.localize("Elysium.veryEasy")  + " (*3)",
      "easy":      game.i18n.localize("Elysium.easy")      + " (*2)",
      "routine":   game.i18n.localize("Elysium.routine")   + " (*1.5)",
      "average":   game.i18n.localize("Elysium.average")   + " (*1)",
      "difficult": game.i18n.localize("Elysium.difficult") + " (*.5)",
      "formidable":game.i18n.localize("Elysium.formidable")+ " (*.25)",
      "impossible":game.i18n.localize("Elysium.impossible")+ " (*.1)",
    };
    return options;
  }

  //Difficulty List
  static async getCHDifficultyOptions() {
    let options = {
      "easy": game.i18n.localize("Elysium.easy") + " (*10)",
      "average": game.i18n.localize("Elysium.average") + " (*5)",
      "tricky": game.i18n.localize("Elysium.tricky") + " (*4)",
      "awkward": game.i18n.localize("Elysium.awkward") + " (*3)",
      "difficult": game.i18n.localize("Elysium.difficult") + " (*2.5)",
      "hard": game.i18n.localize("Elysium.hard") + " (*2)",
      "extreme": game.i18n.localize("Elysium.extreme") + " (*1)",
    };

    if (game.settings.get('elysium', 'allowImp')) {
      options = Object.assign(options, { "impossible": game.i18n.localize("Elysium.impossible") + " (=1%)" })
    }
    return options;
  }

  //Hit Location List
  static async getHitLocType() {
    const options = {
      "limb": game.i18n.localize("Elysium.limb"),
      "abdomen": game.i18n.localize("Elysium.abdomen"),
      "chest": game.i18n.localize("Elysium.chest"),
      "head": game.i18n.localize("Elysium.head"),
      "general": game.i18n.localize("Elysium.general"),
    };
    return options;
  }

  //Success Level List
  static async getSuccessOptions() {
    const options = {
      "4": game.i18n.localize("Elysium.resultLevel.4"),
      "3": game.i18n.localize("Elysium.resultLevel.3"),
      "2": game.i18n.localize("Elysium.resultLevel.2"),
    };
    return options;
  }

  //Auto XP Options List
  static async getXPOptions() {
    const options = {
      "0": game.i18n.localize("Elysium.none"),
      "1": game.i18n.localize("Elysium.onSuccess"),
      "2": game.i18n.localize("Elysium.onFailure"),
    };
    return options;
  }

  static async preLoadCategoriesCategories() {
    //Preload best Weapon Categories, Passions, Skills and Weapons - used in Character Creation
    return new Promise(async (resolve, reject) => {
      resolve(await game.system.api.elysiumid.fromElysiumIDRegexBest({ elysiumidRegExp: new RegExp('^i\.(skillcat|skill|weapon)\.'), type: 'i', showLoading: false }))
    })
  }

  //Weapon Skills List
  static async getWeaponSkills() {
    const weaponSkillsList = (await game.elysium.categories).filter(d => d.type === 'skill').filter(e => e.system.combat)
    weaponSkillsList.sort(function (a, b) {
      return a.name.localeCompare(b.name)
    });
    const options = weaponSkillsList.reduce((c, i) => {
      c[i.flags.elysium.elysiumidFlag.id] = i.name
      return c
    }, {})
    return options
  }

  // Spell save-skill list — used by mysticism + divine + arcane + sorcery.
  // Localized via Elysium.saveSkill* keys added in alpha.40.
  static async getSpellSaveSkillOptions() {
    return {
      '':          game.i18n.localize('Elysium.saveSkillNone'),
      'evade':     game.i18n.localize('Elysium.saveSkillEvade'),
      'willpower': game.i18n.localize('Elysium.saveSkillWillpower'),
      'endurance': game.i18n.localize('Elysium.saveSkillEndurance'),
      'brawn':     game.i18n.localize('Elysium.saveSkillBrawn'),
    };
  }

  // Divine damage-type list — used by divine (P10 cluster 3a).
  // The empty value renders as "— (none / healing)" because damage spells
  // without an explicit type are treated as healing in the divine cast pipeline.
  // Renamed from getSpellDamageTypeOptions() in cluster 4 (alpha.42) to make
  // room for sorcery's much larger cross-tradition palette below.
  static async getDivineDamageTypeOptions() {
    return {
      '':          game.i18n.localize('Elysium.damageNone'),
      'radiant':   game.i18n.localize('Elysium.damageRadiant'),
      'lightning': game.i18n.localize('Elysium.damageLightning'),
      'fire':      game.i18n.localize('Elysium.damageFire'),
      'sonic':     game.i18n.localize('Elysium.damageSonic'),
    };
  }

  // Sorcery damage-type list — used by sorcery (P10 cluster 4).
  // 14 damage types from the cross-tradition combat table + empty for non-damage.
  // The empty value renders as "—" (non-damaging spell: buffs, healing, debuffs).
  // Cluster 5's weapon damage chips will reuse this list.
  static async getSorceryDamageTypeOptions() {
    return {
      '':            game.i18n.localize('Elysium.damageNone'),
      'slashing':    game.i18n.localize('Elysium.damageSlashing'),
      'piercing':    game.i18n.localize('Elysium.damagePiercing'),
      'bludgeoning': game.i18n.localize('Elysium.damageBludgeoning'),
      'force':       game.i18n.localize('Elysium.damageForce'),
      'fire':        game.i18n.localize('Elysium.damageFire'),
      'cold':        game.i18n.localize('Elysium.damageCold'),
      'lightning':   game.i18n.localize('Elysium.damageLightning'),
      'corrosive':   game.i18n.localize('Elysium.damageCorrosive'),
      'sonic':       game.i18n.localize('Elysium.damageSonic'),
      'poison':      game.i18n.localize('Elysium.damagePoison'),
      'necrotic':    game.i18n.localize('Elysium.damageNecrotic'),
      'psychic':     game.i18n.localize('Elysium.damagePsychic'),
      'radiant':     game.i18n.localize('Elysium.damageRadiant'),
      'distortion':  game.i18n.localize('Elysium.damageDistortion'),
    };
  }

  // Sorcery essence list — used by sorcery (P10 cluster 4).
  // 12 essences + empty placeholder. Three essences (death, blight, void)
  // are forbidden by cultural convention; the helper composes the
  // "(<forbidden>)" suffix into the displayed label so the i18n keys
  // for the essence names themselves stay clean. Per c4-5: helper-side
  // composition keeps i18n key surface minimal and supports per-language
  // forbidden-suffix translations naturally.
  static async getSorceryEssenceOptions() {
    const FORBIDDEN = new Set(['death', 'blight', 'void']);
    const ESSENCES = [
      '', 'elemental', 'vitality', 'death', 'ward', 'light', 'shadow',
      'mind', 'presence', 'soul', 'wild', 'blight', 'void',
    ];
    const forbiddenSuffix = game.i18n.localize('Elysium.forbidden').toLowerCase();
    const out = {};
    for (const key of ESSENCES) {
      if (key === '') { out[''] = '—'; continue; }
      const capitalized = key.charAt(0).toUpperCase() + key.slice(1);
      const base = game.i18n.localize(`Elysium.essence${capitalized}`);
      out[key] = FORBIDDEN.has(key) ? `${base} (${forbiddenSuffix})` : base;
    }
    return out;
  }

}
