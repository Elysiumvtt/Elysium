import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Ability item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Two flavours, distinguished by `system.elysium.abilityType`:
 *   - 'static':     no roll, no value; pure descriptive trait (Toughness, Shield Wall)
 *   - 'percentile': has a value 0–100, rolls under it, improves via skill XP
 *
 * Inherits tabbed mode + standard `header`, `tabs`, `description`,
 * `gmNotes` enrichment from ElysiumItemSheetV2. Adds:
 *   - effectText + prerequisitesText enrichment (inline-on-details ProseMirror)
 *   - isPercentile flag for the Base/XP/Total panel conditional
 *   - header chips: Type, Category, (when percentile && owned) Total
 */
export class ElysiumAbilitySheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['ability'],
    position: { width: 560, height: 640 },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/ability.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const isPercentile = this.item.system?.elysium?.abilityType === 'percentile'
    if (isPercentile) {
      // Compute total only for percentile abilities
      this.item.system.total = (this.item.system.base || 0) + (this.item.system.xp || 0)
    }
    context.isPercentile = isPercentile

    // Header chips per c3-2:
    //   Type (Static/Percentile) + Category + (when percentile && hasOwner) Total
    const typeLabel = isPercentile
      ? game.i18n.localize('Elysium.Ability.TypePercentile')
      : game.i18n.localize('Elysium.Ability.TypeStatic')
    const category = this.item.system?.elysium?.category || ''
    const chips = [
      { label: game.i18n.localize('Elysium.Ability.Type'), value: typeLabel },
      { label: game.i18n.localize('Elysium.Ability.Category'), value: category === '' ? '—' : category },
    ]
    if (isPercentile && context.hasOwner) {
      chips.push({ label: game.i18n.localize('Elysium.total'), value: String(this.item.system.total ?? 0) })
    }
    context.itemHeaderChips = chips

    return context
  }

  /** @override — adds ability-specific HTMLField enrichment to details body. */
  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context)
    if (partId === 'details') {
      context.enrichedEffectText = await this._enrichField('effectText')
      context.enrichedPrerequisitesText = await this._enrichField('prerequisitesText')
    }
    return context
  }
}
