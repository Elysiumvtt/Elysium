import { ElysiumActiveEffectSheet } from '../../sheets/elysium-active-effect-sheet.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumGearSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['gear'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs: { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details: {
      template: 'systems/elysium/templates/item/gear.detail.hbs',
      scrollable: ['']
    },
    effects: { template: 'systems/elysium/templates/item/parts/item-shell-effects.hbs' },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes: { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' }
  }

  // Tabbed mode — base hoist (alpha.39) handles tab construction + GM gmNotes append.
  static TAB_ORDER = ['header', 'tabs', 'details', 'effects', 'description']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const actor = this.item.parent
    context.burdenOptions = await ElysiumSelectLists.getArmorBurdenOptions();
    context.priceOptions = await ElysiumSelectLists.getPriceOptions();
    if (actor) {
      context.hitLocOptions = await ElysiumSelectLists.getHitLocOptions(actor);
    };
    context.equippedOptions = await ElysiumSelectLists.getEquippedOptions(this.document.type);
    context.priceName = game.i18n.localize("Elysium." + this.item.system.price);
    context.effects = ElysiumActiveEffectSheet.getItemEffectsFromSheet(this.document)
    const changesActiveEffects = ElysiumActiveEffectSheet.getEffectChangesFromSheet(this.document)
    context.effectKeys = changesActiveEffects.effectKeys
    context.effectChanges = changesActiveEffects.effectChanges

    // P10 cluster 1 (alpha.38) — header chips per c1-2 lock.
    // 2 chips when not owned, 3 chips when owned. Each is read-only summary
    // of a key item attribute; chips render via item-shell-header.hbs.
    //
    // Value normalization:
    //   - Numeric values (ENC) are stringified so Handlebars' `{{#if}}`
    //     truthy-check on chip.value doesn't suppress a literal 0.
    //   - Localized labels guard against empty system.price (default for
    //     freshly-created items) — `localize("Elysium.")` would return
    //     the literal key back; emit em-dash placeholder.
    const encRaw = context.hasOwner ? this.item.system.actlEnc : this.item.system.enc;
    const encDisplay = String(encRaw ?? 0);
    const priceKey = this.item.system.price;
    const priceDisplay = priceKey
      ? game.i18n.localize('Elysium.' + priceKey)
      : '—';
    const equipKey = this.item.system.equipStatus;
    const equipDisplay = equipKey
      ? game.i18n.localize('Elysium.' + equipKey)
      : '—';
    const chips = [
      {
        label: game.i18n.localize('Elysium.enc'),
        value: encDisplay,
        tooltip: context.hasOwner
          ? game.i18n.localize('Elysium.actualENCHint')
          : game.i18n.localize('Elysium.enc'),
      },
      {
        label: game.i18n.localize('Elysium.price'),
        value: priceDisplay,
      },
    ];
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.status'),
        value: equipDisplay,
      });
    }
    context.itemHeaderChips = chips;

    context.tabs = this._getTabs(options.parts);
    return context
  }

  // _preparePartContext / _getTabs / _configureRenderOptions all inherited
  // from base (alpha.39 hoist). No overrides needed for gear.

  //Activate event listeners using the prepared sheet HTML
  _onRender(context, _options) {
    ElysiumActiveEffectSheet.activateListeners(this)
  }

  //-----------------------ACTIONS-----------------------------------
}
