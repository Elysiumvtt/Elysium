import { BRPSelectLists } from "../../apps/select-lists.mjs";
import { addBRPIDSheetHeaderButton } from '../../elysiumid/elysiumid-button.mjs'
import { BRPItemSheetV2 } from "./base-item-sheet.mjs";

export class BRPPowerSheet extends BRPItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['power'],
    position: {
      width: 520,
      height: 520
    },
    form: {
      handler: BRPPowerSheet.myPowerHandler
    }
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/item.header.hbs' },
    tabs: { template: 'systems/elysium/templates/global/parts/tab-navigation.hbs' },
    details: {
      template: 'systems/elysium/templates/item/power.detail.hbs',
      scrollable: ['']
    },
    description: { template: 'systems/elysium/templates/item/item.description.hbs' },
    gmNotes: { template: 'systems/elysium/templates/item/item.gmnotes.hbs' }
  }

  async _prepareContext(options) {
    let context = await super._prepareContext(options)
    context.headerDisplay = true;
    context.catOptions = await BRPSelectLists.getPowerCatOptions();
    context.catName = game.i18n.localize("BRP." + this.item.system.category);
    context.lvlOptions = await BRPSelectLists.getPowerLvlOptions();
    context.lvlName = game.i18n.localize("BRP." + this.item.system.level);
    context.tabs = this._getTabs(options.parts);
    return context
  }

  /** @override */
  async _preparePartContext(partId, context) {
    switch (partId) {
      case 'details':
        context.tab = context.tabs[partId];
        break;
      case 'description':
        context.tab = context.tabs[partId];
        context.enrichedDescription = await foundry.applications.ux.TextEditor.implementation.enrichHTML(
          this.item.system.description,
          {
            secrets: this.document.isOwner,
            rollData: this.document.getRollData(),
            relativeTo: this.document,
          }
        );
        break;
      case 'gmNotes':
        context.tab = context.tabs[partId];
        context.enrichedGMDescription = await foundry.applications.ux.TextEditor.implementation.enrichHTML(
          this.item.system.gmDescription,
          {
            secrets: this.document.isOwner,
            rollData: this.document.getRollData(),
            relativeTo: this.document,
          }
        );
        break;
    }
    return context;
  }

  _getTabs(parts) {
    const tabGroup = 'primary';
    //Default tab
    if (!this.tabGroups[tabGroup]) {
      if (game.settings.get('elysium','defaultTab')) {
        this.tabGroups[tabGroup] = 'description';
      }  else {
        this.tabGroups[tabGroup] = 'details';
      }
    }
    return parts.reduce((tabs, partId) => {
      const tab = {
        cssClass: '',
        group: tabGroup,
        id: '',
        icon: '',
        label: 'BRP.',
      };
      switch (partId) {
        case 'header':
        case 'tabs':
          return tabs;
        case 'details':
          tab.id = 'details';
          tab.label += 'details';
          break;
        case 'description':
          tab.id = 'description';
          tab.label += 'description';
          break;
        case 'gmNotes':
          tab.id = 'gmNotes';
          tab.label += 'gmNotes';
          break;
      }
      if (this.tabGroups[tabGroup] === tab.id) tab.cssClass = 'active';
      tabs[partId] = tab;
      return tabs;
    }, {});
  }

  _configureRenderOptions(options) {
    super._configureRenderOptions(options);
    //Only show GM tab if you are GM
    options.parts = ['header', 'tabs', 'details', 'description'];
    if (game.user.isGM) {
      options.parts.push('gmNotes');
    }
  }

  //Activate event listeners using the prepared sheet HTML
  _onRender(context, _options) {
  }

  //--------------------HANDLER----------------------------------
  static async myPowerHandler(event, form, formData) {
    const system = foundry.utils.expandObject(formData.object)?.system
    formData.object.name = game.i18n.localize("BRP." + formData.object['system.category']);
    await this.document.update(formData.object)
  }

  //-----------------------ACTIONS-----------------------------------

}


