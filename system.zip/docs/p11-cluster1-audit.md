# P11 Cluster 1 prep audit — foundation: partials + chat CSS + 4-island retoken

**Status**: PENDING
**Target alpha**: alpha.45
**Scope**: 5 new shared partials, `elysium-chat.css` build-out, retoken of the 4 v1.0.0 islands (cast-card, manipulation, csb, tcd), CHANGELOG audit-0 fix.
**Inheritance from**: P11 prep audit (`docs/p11-prep-audit.md`, decisions audit-0 through c11-14).

Cluster 1 is the foundation for clusters 2-5. Every later cluster consumes either a partial defined here or a CSS rule defined here. Locking the contracts at audit time means c2-c4 can ship without re-auditing the partial signatures.

---

## 1. Current-state inventory

### `styles/elysium-chat.css` — placeholder, 25 LOC

Built in P7 with a header comment + zero rules. The header captures two important locks:
- Chat cards render outside the `.application.elysium` scope (because they live in Foundry's chat log).
- The chat-CSS scoping marker class is intentionally NOT `.application.elysium`; it needs a chat-specific root.

P11 prep audit c11-1 locked `.elysium-chat-card` as that root.

### v1.0.0 island #1 — `templates/chat/cast-card.hbs` + CSS

CSS span in `styles/elysium.css`:
- Inline cast-buttons on spell rows: lines 1269-1324 (sheet-scoped, NOT cast-card — out of scope for c1)
- Cast-card primary: lines 1326-~1605 (~280 LOC)
- Cast-card secondary (`spent-notice`, `healing`, `disrupt-notice`): lines 1958-2496 (scattered, ~80 LOC)
- `cast-damage-type` + `elysium-damage-*`: lines 2664-2689 (~26 LOC)

Hardcoded color references found:
- `rgba(120, 70, 30, 0.x)` — bone/parchment-toned border + background (12 occurrences)
- `rgba(245, 235, 215, 0.x)` — light-parchment background gradient (2 occurrences)
- `rgba(94, 52, 112, 0.55)` — arcane purple border tint
- `rgba(170, 122, 26, 0.55)` — divine gold border tint
- `rgba(168, 60, 26, 0.55)` — sorcery red-orange border tint
- `rgba(31, 94, 110, 0.55)` — mysticism teal border tint
- `#2a7a2a` / `#1a5e1a` / `#888` / `#8a1818` — outcome colors on attempt log
- `var(--ely-legacy-colour-secondary, #5a3818)` / `var(--ely-legacy-colour-primary, #4a1818)` — legacy fallback consumers

The light-parchment background gradient `rgba(245, 235, 215, 0.4)` clashes with the locked dark theme (`#0a0a0a` surface base). This is the single biggest visual misalignment.

### v1.0.0 island #2 — `templates/casting/manipulation-dialog.hbs` + CSS

CSS span: `styles/elysium.css` lines 1662-~1850 (~190 LOC).
Hardcoded color references similar to cast-card. No light-parchment background; uses warmer dark tones already.

### v1.0.0 island #3 — `templates/casting/custom-spell-builder.hbs` + CSS

CSS span: `styles/elysium.css` lines 2542-~2700 (~155 LOC). Scoped under `.elysium-custom-spell-builder`.

### v1.0.0 island #4 — `templates/casting/tier-choice-dialog.hbs` + CSS

CSS span: `styles/elysium.css` lines 2696-~2800 (~100 LOC). Scoped under `.elysium-tier-choice-dialog`.

### Existing damage-type styling — alignment gap

`.elysium-damage-*` family in `styles/elysium.css` lines 2680-2689 covers 10 types (radiant, fire, cold, lightning, acid, force, necrotic, sonic, psychic, poison) with hardcoded backgrounds + text colors.

The data layer (`module/apps/select-lists.mjs:409`) emits **14** types from sorcery (slashing/piercing/bludgeoning/force/fire/cold/lightning/corrosive/sonic/poison/necrotic/psychic/radiant/distortion) plus the divine subset (radiant/lightning/fire/sonic). Misalignments:

- Data emits `corrosive`; CSS calls it `acid`.
- Data emits `slashing` / `piercing` / `bludgeoning` / `distortion`; CSS has no rules for these (falls back to default).

The design-token file (`elysium-tokens.css`) has its own damage semantic tokens: `--ely-accent-fire`, `--ely-accent-cold`, `--ely-accent-electric`, `--ely-accent-physical`, `--ely-accent-poison`, `--ely-accent-corrosive`, `--ely-accent-distortion`, `--ely-accent-mind`, `--ely-accent-air`. That's 9 tokens — a third vocabulary.

**Three taxonomies don't align**. See c1-9 below.

---

## 2. Eleven cluster-1 decisions

### c1-1: New scoping markers — apply pattern

The prep audit's c11-1 / c11-2 locked the marker names. Cluster 1 applies them to the four touched templates:

```html
<!-- cast-card.hbs root -->
<div class="elysium-cast-card elysium-chat-card" data-tradition="{{tradition}}">

<!-- manipulation-dialog.hbs root -->
<section class="elysium-manip-dialog elysium-dialog">

<!-- custom-spell-builder.hbs root -->
<div class="elysium-custom-spell-builder elysium-dialog">

<!-- tier-choice-dialog.hbs root -->
<div class="elysium-tier-choice-dialog elysium-dialog">
```

`.elysium-chat-card` and `.elysium-dialog` rules in the new `elysium-chat.css` provide token-driven body styling (color, font, line-height) that cascades into the island CSS. The island CSS keeps its specific layout rules (border, banner shape, table) but inherits the typographic + color base from the new shared marker rules.

**Recommendation**: Apply as described. No new partials in this decision — just marker class additions.

### c1-2: Five new shared partials — file paths and signatures

Five files under `templates/chat/parts/`. Pre-loaded via `module/init.mjs`'s existing `loadTemplates(...)` block (P9/P10 pattern).

**`chat-card-shell.hbs`** — outer wrapper with title slot. Used by clusters 2-4.

Context contract:
```
{
  title: string,                   // localized card label, e.g. "Combat Roll"
  cardType: string,                // 'CB'|'OP'|'GR'|'CO'|'CM'|'NO'|'RE'|'PP'|'IM'|'DM'|'AR'|'QC' — exposed for CSS hooks
  state: string|undefined,         // 'closed' or undefined; gates resolve-footer
  hasResolveFooter: bool,          // true if cluster passes a resolve-preset
  resolvePreset: string|undefined, // e.g. 'resolve-cb-card' — only when hasResolveFooter
  initiatorId: string|undefined,   // for owner-only data-partic-id on resolve buttons
  initiatorType: string|undefined, // 'character'|'npc' — for owner-only data-particType
  bodySlot: rendered HTML,         // the per-card body content
}
```

Renders:
```html
<form class="elysium gr-card elysium-chat-card" data-card-type="{{cardType}}">
  <div class="elysium-chat-card__title">{{title}}</div>
  {{{bodySlot}}}
  {{> chat-card-resolve-footer ...}}  {{!-- conditional inside the partial --}}
</form>
```

The `data-card-type` attribute is purely a CSS hook (lets us conditionally style headers by card type). Not read by any current JS — safe to add. The `form.elysium.gr-card` class set is preserved verbatim per c11-1 (Phase D mount-point + `.cardbutton` ancestor pattern).

**`chat-card-participant-row.hbs`** — one participant strip. Used by clusters 2 (group-roll quartet) and 3 (singleton-roll variants where applicable). NOT used by cast-card or chat micro-cards.

Context contract:
```
{
  entry: {
    particImg: string,
    particName: string,
    particId: string,        // for the owner-only block's data-partic-id
    particType: string,
    label: string,           // e.g. "Sword (75%)" or "1d6+1d4"
    targetScore: number|undefined, // shown only on rollable cards
    rollFormula: string|undefined, // shown only on damage/armor cards
    resultLevel: number,     // 0|1|2|3|4 or undefined for damage/armor cards
    resultLabel: string,
    rollVal: number|string,
    diffLabel: string|undefined,
    flatMod: number|undefined,
    malfunction: number|undefined,
    hitLocationName: string|undefined,
    hitLocationId: string|undefined,
  },
  index: number,                // for the per-row data-rank on remove buttons
  state: string|undefined,      // 'closed' or undefined; gates which annotations render
  cardType: string,             // gates RE/PP-specific tooltip block in tooltip-rows
  showCrown: bool,              // true on combat + opposed for the leader pip
  showRemoveButton: bool,       // true on cb/op/gr/co when state != 'closed'
  resultMode: string,           // 'pip-strip'|'flat-value'|'diff-display'
}
```

Renders the participant `<li class="actor-roll">` strip + the optional `.dice-tooltip` sibling block. `resultMode` switches which body shape renders:

- `pip-strip` — success-pip annotation with `resultLabel` (combat/opposed/combined/cooperative/result cards)
- `flat-value` — a single value display (damage/armor cards)
- `diff-display` — the difficulty/flatMod pending strip when card is not yet closed (group-roll cards in pending state)

**`chat-card-success-pip.hbs`** — the 0-3 pip strip driven by `resultLevel`. Standalone partial because it's reused inside both `chat-card-participant-row.hbs` AND the chat-dice closed-state summary at the bottom of combined/cooperative cards.

Context contract:
```
{
  resultLevel: number,    // 0|1|2|3|4
  resultLabel: string,
  rollValue: number|string,
  healing: number|undefined,    // optional bracketed [N] inline annotation
  showCrown: bool,              // adds the crown icon for highest scorer
}
```

Renders one `<span class="pending roll-XYZ">` with the right number of `<i class="result-success fas fa-certificate"></i>` / `<i class="result-fail fas fa-skull"></i>` glyphs. Preserves the `pending`/`roll-succ`/`roll-fail`/`roll-fumb`/`result-success`/`result-fail`/`result-yellow` class hooks (visible in legacy CSS; no JS reads them but the visual styling depends on them).

**`chat-card-tooltip-rows.hbs`** — the owner-gated hidden detail block. Used by clusters 2 and 3.

Context contract:
```
{
  entry: { ...same as participant-row.entry plus: rawScore, diffLabel, diceRolled, description, healingLabel, healing, resistance },
  cardType: string,      // for the RE/PP resistance branch
  rollMode: string,      // 'attribute-difficulty'|'attribute-resistance'|'damage'|'armor' — gates which rows show
}
```

Renders the `<div class="actor-roll dice-tooltip"><div class="owner-only" data-partic-id="..." data-partic-type="...">...</div></div>` block. **The `.owner-only` class hook + `data-partic-id`/`data-partic-type` dataset attributes are imperative contracts per c11-3a — preserved verbatim.**

**`chat-card-resolve-footer.hbs`** — GM-only resolve+close button pair. Used by clusters 2 (all 4 group-roll cards) and 3 (where applicable).

Context contract:
```
{
  resolvePreset: string,        // 'resolve-cb-card'|'resolve-op-card'|...
  initiatorId: string|undefined,
  initiatorType: string|undefined,
  resolveButtonClass: string,   // 'gm-visible-only' (combat/opposed) or 'owner-only' (combined/cooperative)
  resolveDataAttrs: object|undefined, // {'data-partic-id': X, 'data-particType': Y} when 'owner-only' mode
}
```

Renders:
```html
<button class='cardbutton {{resolveButtonClass}}' {{#each resolveDataAttrs}}{{@key}}="{{this}}" {{/each}}data-preset='{{resolvePreset}}' type="button">{{localize "Elysium.resolveCard"}}</button>
<button class='cardbutton {{resolveButtonClass}}' data-preset='close-card' type="button">{{localize "Elysium.closeCard"}}</button>
```

Per c11-3a: `.cardbutton` + `data-preset` + `.gm-visible-only` / `.owner-only` are all imperative contracts. Preserved verbatim.

**Recommendation**: Ship all five with these signatures. They're consumed by clusters 2-4; lock them now so those clusters' audits inherit the contract.

### c1-3: `module/init.mjs` partial registration

Five new template paths added to the existing `loadTemplates(...)` call. The block is already there from P9/P10 item-parts registration; add the new files at the end of the array (preserves the precedent ordering).

**Recommendation**: Append five paths to `loadTemplates`. No new code, just five new strings.

### c1-4: `elysium-chat.css` build-out structure

Built out from 25 LOC to ~600 LOC under the following ordered sections:

```
1. Header (existing, extended with new scoping notes)
2. Section A: Marker rules — .elysium-chat-card, .elysium-dialog
   (typography + color base that cascades into island content)
3. Section B: Shared chat partial styles
   B1. .elysium-chat-card__title
   B2. .elysium-chat-card .actor-roll family (participant-row layout)
   B3. .elysium-chat-card .pending family (success pips)
   B4. .elysium-chat-card .dice-tooltip family (owner-only hidden rows)
   B5. .elysium-chat-card .cardbutton (resolve footer button — TOKEN-DRIVEN)
4. Section C: Chip + badge components
   C1. .elysium-chat-chip — small inline label tag (e.g. hitloc-tag, damage-type tag)
   C2. .elysium-chat-badge — counter badge (e.g. SL count, AP count)
5. Section D: Card-type accents
   D1. .elysium-chat-card[data-card-type="CB"] — combat accent
   D2. .elysium-chat-card[data-card-type="OP"] — opposed accent
   D3. ...etc per card type
6. Section E: Island retoken — shared variables consumed by the islands
   E1. Tradition-tinted borders consumed by .elysium-cast-card[data-tradition]
   E2. Damage-type accent map (see c1-9 for details)
```

Section A's marker-rule body:

```css
.elysium-chat-card,
.elysium-dialog {
  color: var(--ely-text-body);
  background: var(--ely-surface-card);
  border: 1px solid var(--ely-border-subtle);
  border-radius: var(--ely-radius-1);
  font-family: var(--ely-font-family-body);
  font-size: var(--ely-font-size-1);
  line-height: 1.4;
  padding: var(--ely-space-2);
}
```

All rules use design tokens; zero hardcoded values. The chat-card scope-marker rule is **strict — no token-fallbacks like `var(--ely-text-body, #e8e6e1)`** because every chat-card consumer is in v1.0.0 territory (the legacy templates that ship in clusters 2-4 also adopt the marker class).

**Recommendation**: Build to this structure. ~600 LOC total. Section E gets refined as clusters 2-5 land — cluster 1 lands sections A-D plus the cast-card retoken in E.

### c1-5: Cast-card retoken mapping — exact token assignments

Every hardcoded color in `styles/elysium.css` lines 1326-1605 + 1958-2496 maps to a token. Listed by current value → token:

| Current | New |
|---|---|
| `rgba(120, 70, 30, 0.4)` (card border) | `var(--ely-border-decorative)` |
| `rgba(120, 70, 30, 0.25)` (header divider) | `var(--ely-border-subtle)` |
| `rgba(245, 235, 215, 0.4)→0.15)` (BG gradient) | **REPLACED**: solid `var(--ely-surface-card)` (kills the light-parchment look) |
| `var(--ely-legacy-colour-secondary, #5a3818)` | `var(--ely-text-decorative)` |
| `var(--ely-legacy-colour-primary, #4a1818)` | `var(--ely-accent-action)` |
| `rgba(0, 0, 0, 0.55)` (school italic) | `var(--ely-text-muted)` |
| `rgba(0, 0, 0, 0.6)` (caster) | `var(--ely-text-muted)` |
| `#2a7a2a` (outcome-success) | `var(--ely-accent-success)` |
| `#1a5e1a` (outcome-critical) | `var(--ely-accent-success-hover)` (or a "strong" variant if added) |
| `#888` (outcome-failure) | `var(--ely-text-muted)` |
| `#8a1818` (outcome-fumble) | `var(--ely-accent-danger)` |
| `rgba(94, 52, 112, 0.55)` (arcane) | `var(--ely-accent-mind)` |
| `rgba(170, 122, 26, 0.55)` (divine) | `var(--ely-accent-bonus)` |
| `rgba(168, 60, 26, 0.55)` (sorcery) | `var(--ely-accent-fire)` |
| `rgba(31, 94, 110, 0.55)` (mysticism) | `var(--ely-accent-cold)` |

**Trade-off**: The `--ely-accent-success-hover` mapping for "outcome-critical" is the weakest — there's no semantic-distinct token for "stronger green" today. The right answer is probably to add `--ely-accent-success-strong` to the token file. Recommendation: **don't add a new token in this cluster** — use the hover variant which is the strongest existing green; flag the token-gap as a P12 polish item.

**Recommendation**: Apply this mapping. Switch the gradient to solid surface-card color. Add `elysium-chat-card` class on the root.

### c1-6: Manipulation-dialog retoken mapping

CSS span lines 1662-~1850. Same general pattern as cast-card. The dialog already uses warmer dark tones (no light-parchment gradient to fix). Drop-in token substitution:

| Current | New |
|---|---|
| Various `rgba(120, 70, 30, ...)` borders | `var(--ely-border-decorative)` or `var(--ely-border-subtle)` |
| `var(--ely-legacy-colour-primary, #4a1818)` headings | `var(--ely-accent-action)` |
| `var(--ely-legacy-colour-secondary, #5a3818)` labels | `var(--ely-text-decorative)` |
| Hardcoded `#888880` etc. for muted text | `var(--ely-text-muted)` |
| Stepper button colors | `var(--ely-accent-bonus)` (matches the bonus-gold focus pattern) |
| "Overspent" state red | `var(--ely-accent-danger)` |

**Recommendation**: Apply the mapping. Add `elysium-dialog` class on the root.

### c1-7: Custom-spell-builder retoken mapping

CSS span lines 2542-~2700. Same pattern. Scoped under `.elysium-custom-spell-builder .csb-*` selectors — keep the existing nesting structure (only retoken values).

| Current | New |
|---|---|
| `.csb-section` borders | `var(--ely-border-subtle)` |
| `.csb-section h3` text | `var(--ely-text-decorative)` |
| `.csb-toggle` borders/text | `var(--ely-border-subtle)` / `var(--ely-text-body)` |
| `.csb-toggle.selected` highlight | `var(--ely-accent-bonus-subtle)` background + `var(--ely-accent-bonus)` border |
| `.csb-row input` borders | `var(--ely-border-subtle)` |
| `.csb-hint` color | `var(--ely-text-muted)` |

**Recommendation**: Apply. Add `elysium-dialog` class on the root.

### c1-8: Tier-choice-dialog retoken mapping

CSS span lines 2696-~2800. Same pattern. Scoped under `.elysium-tier-choice-dialog .tcd-*`.

| Current | New |
|---|---|
| `.tcd-header` divider | `var(--ely-border-subtle)` |
| `.tcd-domain` muted | `var(--ely-text-muted)` |
| `.tcd-skills` strong text | `var(--ely-text-body-strong)` if exists, else `var(--ely-text-body)` with weight |
| `.tcd-tier` borders | `var(--ely-border-subtle)` |
| `.tcd-tier-selected` highlight | `var(--ely-accent-bonus-subtle)` + `var(--ely-accent-bonus)` border |
| `.tcd-tier:hover` background | `var(--ely-surface-raised)` |
| `.tcd-tier-cost` accent | `var(--ely-accent-bonus)` |

**Recommendation**: Apply. Add `elysium-dialog` class on the root.

### c1-9: Damage-type taxonomy gap — defer, don't widen in c1

Three taxonomies don't align: data emits 14 types (`select-lists.mjs:409`), CSS covers 10 (`elysium.css:2680-2689`), tokens define 9. Misnamings ("acid" CSS vs "corrosive" data) and missing types (slashing/piercing/bludgeoning/distortion in data, no CSS) compound the gap.

Three options:

- **(A) Full re-taxonomy in cluster 1** — Resolve names, add the missing CSS rules, retoken everything to canonical tokens. Largest blast radius; could surface DataModel collisions.
- **(B) Retoken what aligns, leave gaps** — Map cleanly aligned types (fire, cold, poison, corrosive, distortion) to tokens; leave the remaining 5 CSS rules as-is with hardcoded values; do NOT add new CSS rules for currently-uncovered types. Damage-type taxonomy alignment becomes a P12 item.
- **(C) Add CSS for missing types using existing hardcoded color choices** — Fills the visual gap (typed tags render with a color instead of falling back to default), but commits us to colors that may not align with the eventual P12 alignment.

**Recommendation**: Option B. Retoken only the cleanly-aligned pairs:

| CSS class | New token mapping |
|---|---|
| `.elysium-damage-fire` | `background: var(--ely-accent-fire-subtle, #ffe0d0)` etc. — but `--ely-accent-fire-subtle` doesn't exist today |

**Problem surfaced**: the token file has `--ely-accent-fire` but not `--ely-accent-fire-subtle` (only `success`/`bonus`/`danger`/`info` have `-subtle` variants per the inventory). Damage-type tags need both a tint background AND a text color and a border for legibility, and the existing CSS rules use 3 distinct tones per type.

**Revised recommendation for c1-9**: Leave all 10 `elysium-damage-*` rules **unchanged** in cluster 1. The whole damage-type styling subsystem needs a focused token-augmentation pass that's beyond a chat-card retoken's scope. Mark as a P12 work item: "Damage-type tag taxonomy alignment — data emits 14 types; CSS covers 10 with name collision; tokens cover 9 different names. Needs (a) canonical name lock, (b) per-type subtle-tint tokens added, (c) CSS regenerated from tokens."

This keeps the cast-card damage-type tag visually identical to alpha.44 (its existing hardcoded colors work fine for the types in the existing CSS rules; the gaps are pre-existing and not introduced by c1).

**Recommendation**: Defer damage-type alignment entirely. Leave `.elysium-damage-*` rules as-is. Add a P12 work item.

### c1-10: CHANGELOG audit-0 correction wording

The alpha.44 "Next" paragraph reads:

> P10 closes. **P11 (legacy.css final retirement sweep — any remaining orphan blocks)** and **P12 (polish: cast-card rebuild, statistics tab fold, DataModel cleanup, lang-parity gap, weapon DataModel/template alignment for the dead-code branches found in cluster 5 smoke, etc.)** become the next phases.

This contradicts `ROADMAP-v1.0.0.md §P11` which describes P11 as chat cards + dialogs. Fix in the alpha.45 entry's "Note" preamble:

> **Note on alpha.44 changelog correction**: The alpha.44 "Next" paragraph drifted from `ROADMAP-v1.0.0.md §P11–P12`. The canonical phase plan (locked in P0) is:
> - **P11** — Chat cards + dialogs rebuild
> - **P12** — Polish + acceptance (light theme finalisation, lang-parity sweep, legacy CSS final retirement, DataModel cleanup, statistics tab fold, weapon DataModel/template alignment, plus the rest of the P10-deferred items captured in the cluster 5/6 changelogs)
>
> The alpha.44 paragraph's swap of P11 and P12 scope was a writing-error, not an architectural change. Cast-card rebuild that the alpha.44 paragraph put under P12 is correctly P11 work and lands in this alpha.45 ship per the c11 prep audit.

The alpha.44 paragraph itself is not edited (the changelog is append-only history). The correction note in alpha.45 makes the canonical scope explicit going forward.

**Recommendation**: Apply as written. Place after the alpha.45 header, before the cluster 1 narrative.

### c1-11: `system.json` bump + smoke methodology for c1

Version `1.0.0-alpha.44` → `1.0.0-alpha.45`. Pre-flight checks per Rule 5:

1. JS parse: `node --check module/init.mjs` (only modified .mjs file)
2. JSON parse: `system.json` + `lang/en.json` + `lang/es.json` + `lang/fr.json`
3. CSS brace balance: `styles/elysium-chat.css` (rewritten) + `styles/elysium.css` (4 retoken-affected ranges)
4. Handlebars block balance: 5 new partials + 4 island templates (root-class additions only)
5. Handlebars mustache balance: same files
6. i18n key existence sweep: 4 new keys planned in c1? **No** — partials are styling-only; islands' i18n stays as-is. Verify zero new `localize` calls.
7. Design-token existence sweep: every `var(--ely-*)` in new CSS must resolve in `elysium-tokens.css`. Run grep + diff.
8. Legacy CSS retirement pre-flight: ZERO CSS rules retired in c1 (per c11-13 — orphaning happens in c2-c5, deletion is P12). Verify no rules removed.
9. Lang parity: no new keys, so no parity impact.

Smoke pattern: offline-render of the four touched templates with fixture contexts covering each conditional branch (cast-card: 5 states; manipulation: damage / non-damage / reactive; csb: empty / partial / complete; tcd: divine / sorcery). Live render of one cast (any tradition) + one manipulation dialog open from a fresh world to verify nothing crashes.

**Recommendation**: Apply this checklist verbatim before the cluster-1 ship.

---

## 3. Out of scope for cluster 1

- Any legacy `.html` chat template rewrite (c2-c4 work)
- Any dialog template rewrite (c5 work)
- `combat-tracker.html` cosmetic restyle (c7 / P12)
- Damage-type taxonomy alignment (P12 per c1-9)
- Inline-HTML JS chat-content restyling (per c11-8, out of P11 entirely)
- The 51 `ChatMessage.create({content:...})` callsites — untouched
- The 205-key en→es/fr parity gap (P12)
- `data-handle-change` decorator removal (only on touched templates per c11-14; no untouched templates touched here)
- The "P12 carry-forward" items in HANDOFF-state.md §"P12 carryforward"
- Cast-card vocabulary harmonisation onto shared chat-card partials (deferred to c6 per c11-3 and c11-6)
- Card-type accent rules in Section D of the new CSS — **placeholder rules only** in c1; populated as c2-c4 land their card-specific styling

---

## 4. Smoke risks specific to cluster 1

1. **Marker-class cascade collision** — Adding `.elysium-chat-card` on cast-card root and defining typography rules at that scope could collide with the island's own typographic rules (e.g. `.elysium-cast-card .elysium-cast-spellname { font-size: 16px }`). The island's deeper selector specificity wins by default, but **font-family** inheritance could cause a regression if the marker rule sets a different family than the island assumes.
   **Mitigation**: Marker rule sets `font-family: var(--ely-font-family-body)`. Verify against the island's existing implicit `font-family: var(--font-primary, 'Signika', sans-serif)`. If they're different, set both explicitly via the marker (the island stops setting its own) OR leave the island override in place. Spot-check via DevTools after retoken.

2. **Cast-card light-parchment-gradient removal visual shock** — The cast-card background went from `rgba(245, 235, 215, 0.4)` light-parchment to `var(--ely-surface-card)` (#1a1a1a). Text contrast and overall feel of the card change substantially. This is **intentional** per the dark-theme lock, but worth a single screenshot during smoke to confirm.

3. **Token-existence regression** — Every `var(--ely-*)` reference in the new CSS must resolve to a defined token. A typo (`--ely-accent-fier`) renders silently as `unset`. Pre-flight grep + diff against the token file.

4. **Marker-class typo in template** — The 4 touched templates each grow ONE class on the root. A typo (`elsyium-chat-card` instead of `elysium-chat-card`) loses all new styling silently. Visual smoke catches this.

5. **Partial-registration order** — Foundry's `loadTemplates` is synchronous; the 5 new partials must be registered BEFORE any consumer template tries to render them. Cluster 1 has zero consumers (no template includes the new partials yet), so this risk doesn't materialise until c2 — but the registration must be in place. Smoke: console-test `Handlebars.partials['systems/elysium/templates/chat/parts/chat-card-shell.hbs']` is defined after world load.

---

## 5. Cluster-1 ship summary (what gets packaged)

**Files added** (5):
- `templates/chat/parts/chat-card-shell.hbs` (~25 LOC)
- `templates/chat/parts/chat-card-participant-row.hbs` (~80 LOC)
- `templates/chat/parts/chat-card-success-pip.hbs` (~35 LOC)
- `templates/chat/parts/chat-card-tooltip-rows.hbs` (~45 LOC)
- `templates/chat/parts/chat-card-resolve-footer.hbs` (~12 LOC)

**Files modified** (8):
- `styles/elysium-chat.css` — 25 → ~600 LOC
- `styles/elysium.css` — retoken lines 1326-1605 (cast-card), 1958-2496 (cast-card secondary), 1662-1850 (manipulation), 2542-2700 (csb), 2696-2800 (tcd). Approx 60-80 color literal substitutions; no rules added or removed.
- `templates/chat/cast-card.hbs` — 1 class addition on root + (if c11-12 applies) damage-type tag change. The damage-type token swap from c11-12 is **rolled back to "leave alone" per c1-9** — so just the 1 class addition.
- `templates/casting/manipulation-dialog.hbs` — 1 class addition on root
- `templates/casting/custom-spell-builder.hbs` — 1 class addition on root
- `templates/casting/tier-choice-dialog.hbs` — 1 class addition on root
- `module/init.mjs` — 5 new partial paths in `loadTemplates(...)`
- `CHANGELOG.md` — alpha.45 entry with audit-0 correction preamble + cluster-1 narrative
- `system.json` — version bump

**Lang impact**: zero new i18n keys.
**JS behaviour impact**: zero (no .mjs logic changes; only `init.mjs` partial path additions).
**Smoke surface**: 4 templates × offline-render of fixture contexts + 1 live cast roll.

---

## 6. Open questions for user lock-in

1. **c1-5 critical-outcome green** — Mapping `#1a5e1a` (cast-card "outcome-critical") to `var(--ely-accent-success-hover)` is the weakest substitution because the hover variant is semantically "interactive hover state", not "stronger green". Two alternatives:
   - **(a)** Use it anyway, flag for P12 token-augmentation (`--ely-accent-success-strong`)
   - **(b)** Add `--ely-accent-success-strong: #1a5e1a` to the token file in cluster 1
   - **(c)** Map to `var(--ely-accent-success)` (lose the visual distinction between success and critical)
   Recommendation: (a). Keeps token-file changes out of c1.

2. **c1-9 damage-type defer** — Recommended option B (leave all 10 `.elysium-damage-*` rules unchanged; flag the taxonomy gap for P12). Confirm? Or push harder for option A/C?

3. **CSS rule budget for new `elysium-chat.css`** — ~600 LOC is the estimate. Some clusters land 800+; some land 400. Confirm the estimate is acceptable or signal a tighter target.

4. **Smoke depth** — "Offline-render fixtures + 1 live cast" is the minimum. Want me to also test from the world console with a `ChatMessage.create(...)` containing a hand-crafted cast-card payload to round-trip the live render path? Default: yes; want to skip → tell me now.

---

## 7. Ready-to-go checklist (cluster 1 ships when all green)

- [ ] User confirms decisions c1-1 through c1-11
- [ ] User answers the 4 open questions in §6
- [ ] User confirms scope-cut list in §3
- [ ] User accepts smoke-risk mitigations in §4
- [ ] User accepts ship-summary in §5

Once locked, cluster 1 coding begins.
