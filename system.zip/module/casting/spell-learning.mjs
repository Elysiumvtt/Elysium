/**
 * Spell learning (v0.10.0).
 *
 * A found spell (scroll, recovered spellbook page, etc.) is added to a
 * character's spellbook only after a successful school-skill roll.
 *
 * Public API:
 *   learnArcaneSpell(actor, spellOrUuid)  - prompts a school roll, on
 *                                            success adds the spell to
 *                                            the actor and posts a chat
 *                                            card.
 *
 * Roll mechanic: standard d100 vs school-skill total. Critical halves
 * any future re-attempt (we don't track re-attempts in v0.10.0; this is
 * documented for future). Fumble means the spell can never be learned
 * by this caster (in v0.10.0 we just say "ruined" — no permanent flag).
 */

import { findSkill, rollD100, classifyRoll } from './cast-shared.mjs'
const ARCANE_SUBGROUP = 'arcane'

/**
 * Attempt to learn an Arcane spell. Resolves a school-skill roll;
 * on success adds the spell as an item on the actor.
 *
 * @param {Actor}                actor
 * @param {Item|string|object}   spellOrUuid - an Item, a UUID string, or
 *                                              a plain spell-data object
 * @returns {Promise<{ learned: boolean, outcome: string, item?: Item }>}
 */
export async function learnArcaneSpell (actor, spellOrUuid) {
  // Normalise input into a spell data object.
  let spellData = null
  let sourceItem = null
  if (typeof spellOrUuid === 'string') {
    sourceItem = await fromUuid(spellOrUuid)
    if (!sourceItem) {
      ui.notifications?.warn(`Could not resolve spell UUID: ${spellOrUuid}`)
      return { learned: false, outcome: 'not-found' }
    }
    spellData = sourceItem.toObject()
  } else if (spellOrUuid?.toObject) {
    sourceItem = spellOrUuid
    spellData = spellOrUuid.toObject()
  } else if (spellOrUuid?.type === 'arcane' || spellOrUuid?.system?.elysium) {
    spellData = spellOrUuid
  } else {
    ui.notifications?.warn('learnArcaneSpell: invalid spell argument.')
    return { learned: false, outcome: 'invalid' }
  }

  if (spellData.type !== 'arcane') {
    ui.notifications?.warn(`Not an Arcane spell: ${spellData.name ?? '?'}`)
    return { learned: false, outcome: 'wrong-type' }
  }

  // Already in the spellbook?
  const dupCheck = actor.items.find(itm =>
    itm.type === 'arcane'
    && (itm.name === spellData.name
        || (itm.flags?.elysium?.elysiumidFlag?.id
            && spellData.flags?.elysium?.elysiumidFlag?.id
            && itm.flags.elysium.elysiumidFlag.id === spellData.flags.elysium.elysiumidFlag.id)))
  if (dupCheck) {
    ui.notifications?.info(`${actor.name} already knows ${spellData.name}.`)
    return { learned: false, outcome: 'already-known', item: dupCheck }
  }

  // Find the school skill — same fallback chain as casting.
  const schoolName = spellData.system?.elysium?.school || ''
  let schoolSkill = null
  if (schoolName) schoolSkill = findSkill(actor, { name: schoolName })
  if (!schoolSkill) schoolSkill = findSkill(actor, { subgroup: ARCANE_SUBGROUP })
  if (!schoolSkill) {
    ui.notifications?.warn(
      `${actor.name} has no Arcane school skill to learn ${spellData.name}.`)
    return { learned: false, outcome: 'no-school' }
  }
  const skillTotal = schoolSkill.system?.total ?? schoolSkill.system?.base ?? 0

  // Roll.
  const { value: rollValue } = await rollD100({
    flavor: `Learning ${spellData.name} via ${schoolSkill.name}`,
  })
  const outcome = classifyRoll(skillTotal, rollValue)
  const success = ['critical', 'special', 'success'].includes(outcome)

  // Build a small chat card for the result.
  const variant = success ? 'success'
                : (outcome === 'fumble' ? 'danger' : 'fire')
  const icon = success ? 'book-open'
              : (outcome === 'fumble' ? 'skull' : 'times')
  const title = success ? 'Spell learned'
              : (outcome === 'fumble' ? 'The spell is ruined' : 'Failed to comprehend')

  const body =
    `<div><strong>${spellData.name}</strong> (${schoolName})</div>` +
    `<div>${schoolSkill.name} ${skillTotal}% — rolled <strong>${rollValue}</strong> (${outcome})</div>`

  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
    { variant, title, icon, body }
  )
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: html,
  })

  if (!success) {
    return { learned: false, outcome }
  }

  // Add the spell to the actor's items.
  // The elysiumLearnedSpell flag bypasses the requireSpellLearningRoll
  // gate in the rules-module's preCreateItem hook, preventing recursion.
  const created = await actor.createEmbeddedDocuments('Item', [spellData], {
    elysiumLearnedSpell: true,
  })
  const newItem = created?.[0] ?? null
  return { learned: true, outcome, item: newItem }
}
