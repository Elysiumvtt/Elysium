import { ElysiumUtilities } from '../../apps/utilities.mjs'
import { ElysiumDragDropItemSheet } from './base-dragdrop-item-sheet.mjs'
import ElysiumDialog from '../../setup/elysium-dialog.mjs'

/**
 * Culture item sheet — P10 cluster 3b / alpha.41 rewrite.
 *
 * Personality++ — adds:
 *   - Stat formula table (8 stats, 2-column pair layout)
 *   - Per-skill cultural bonus (prompted via ElysiumDialog.input on drop)
 *
 * Inherits everything from ElysiumDragDropItemSheet. Overrides
 * `_onDrop` (adds the cultural-bonus prompt step + stores the bonus
 * value with each reference).
 *
 * Per c3b-culture-3: stat formula data restructured into statPairs[]
 * in _prepareContext (4 row-pairs × 2 stats each), eliminating the
 * legacy `newrow` flag gymnastics in the template.
 */
export class ElysiumCultureSheet extends ElysiumDragDropItemSheet {

  static DEFAULT_OPTIONS = {
    classes: ['culture'],
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }],
    position: { width: 560, height: 640 },
    form: { handler: ElysiumCultureSheet.myCultureHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/culture.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Resolve skill + group-skill references (incl. cultural bonus)
    const perSkill = []
    const grpSkill = []
    for (const skill of this.item.system.skills) {
      const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({
        elysiumid: skill.elysiumid,
      }))[0]
      if (tempSkill) {
        perSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: tempSkill.name,
          category: tempSkill.system.category,
          variable: tempSkill.system.variable,
          base: tempSkill.system.base,
          group: tempSkill.system.group,
          bonus: skill.bonus,
        })
      } else {
        perSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: game.i18n.localize('Elysium.invalid'),
          category: '', variable: '', base: '', group: '', bonus: 0,
        })
      }
    }
    for (let index = 0; index < this.item.system.groups.length; index++) {
      for (const skill of this.item.system.groups[index].skills) {
        const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({
          elysiumid: skill.elysiumid,
        }))[0]
        if (tempSkill) {
          grpSkill.push({
            uuid: skill.uuid,
            elysiumid: skill.elysiumid,
            name: tempSkill.name,
            category: tempSkill.system.category,
            variable: tempSkill.system.variable,
            base: tempSkill.system.base,
            group: tempSkill.system.group,
            index,
            bonus: skill.bonus,
          })
        } else {
          grpSkill.push({
            uuid: skill.uuid,
            elysiumid: skill.elysiumid,
            name: game.i18n.localize('Elysium.invalid'),
            category: '', variable: '', base: '', group: '', index, bonus: 0,
          })
        }
      }
    }
    context.perSkill = perSkill.sort(ElysiumUtilities.sortByNameKey)
    context.grpSkill = grpSkill.sort(ElysiumUtilities.sortByNameKey)

    // Stat formula table — build paired rows so template doesn't need
    // `newrow` flag gymnastics (c3b-culture-3 cleanup).
    // Pairing order matches the legacy layout: str/siz, con/int, pow/cha, dex/edu.
    // The pairing came from the legacy `newrow` flag set on str/int/pow/cha.
    const pairing = [
      ['str', 'siz'],
      ['con', 'int'],
      ['pow', 'cha'],
      ['dex', 'edu'],
    ]
    const buildStat = (key) => {
      const raw = this.item.system.stats[key]
      return {
        key,
        label: game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key,
        formula: raw?.formula ?? '',
        mod: raw?.mod ?? 0,
      }
    }
    context.statPairs = pairing.map(([a, b]) => [buildStat(a), buildStat(b)])

    // Header chips per audit-3-cluster-3: (when owned) Skill Count + Stat Formula Count
    const chips = []
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.skillCount'),
        value: String(perSkill.length + grpSkill.length),
      })
      // Count stats with a non-empty formula (i.e. ones the GM actually filled)
      const formulaCount = Object.values(this.item.system.stats || {})
        .filter(s => s?.formula && s.formula !== '')
        .length
      chips.push({
        label: game.i18n.localize('Elysium.statFormulaCount'),
        value: String(formulaCount),
      })
    }
    context.itemHeaderChips = chips

    return context
  }

  // -----------------------------------------------------------------
  // OVERRIDE — culture drop semantics with bonus prompt
  // -----------------------------------------------------------------

  /**
   * Drop a skill onto either the main list or an optional group, prompting
   * the GM for a cultural bonus value via ElysiumDialog. If the bonus is
   * 0 (or the dialog is cancelled), the drop is skipped entirely.
   */
  async _onDrop(event, type = 'skill', collectionName = 'skills') {
    event.preventDefault()
    event.stopPropagation()

    const optionalSkill = event?.currentTarget?.classList?.contains('optional-skills')
    const ol = event?.currentTarget?.closest('ol')
    const index = ol?.dataset?.group
    const dataList = await ElysiumUtilities.getDataFromDropEvent(event, 'Item')
    const collection = this.item.system[collectionName]
      ? foundry.utils.duplicate(this.item.system[collectionName])
      : []
    const groups = this.item.system.groups
      ? foundry.utils.duplicate(this.item.system.groups)
      : []
    let cultureBonus = 0

    for (const item of dataList) {
      if (!item || !item.system) continue
      if (![type].includes(item.type)) continue

      // F10 (rc.2) defensive guard — see career.mjs for rationale.
      if (!item.flags?.elysium?.elysiumidFlag?.id) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      if (optionalSkill) {
        // Optional group: enforce uniqueness for non-generic skills
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          if (groups[index].skills.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
        }
        const usage = await this.enterValue('culture', item.name)
        if (usage) cultureBonus = Number(usage)
        if (cultureBonus === 0) continue
        groups[index].skills = groups[index].skills.concat({
          uuid: item.uuid,
          elysiumid: item.flags.elysium.elysiumidFlag.id,
          bonus: cultureBonus,
        })
      } else {
        // Main list
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          for (let i = 0; i < groups.length; i++) {
            const idx = groups[i].skills.findIndex(
              el => el.elysiumid === item.flags.elysium.elysiumidFlag.id,
            )
            if (idx !== -1) groups[i].skills.splice(idx, 1)
          }
        }
        const usage = await this.enterValue('culture', item.name)
        if (usage) cultureBonus = Number(usage)
        if (cultureBonus === 0) continue
        collection.push({
          uuid: item.uuid,
          elysiumid: item.flags.elysium.elysiumidFlag.id,
          bonus: cultureBonus,
        })
      }
    }
    await this.item.update({ 'system.groups': groups })
    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  /**
   * Prompt for the cultural bonus value (numeric input dialog).
   * If dialog is cancelled, returns undefined; caller treats that as 0.
   */
  async enterValue(type, name) {
    let title = ''
    if (type === 'culture') {
      title = game.i18n.localize('Elysium.culturalBonus') + ': ' + name
    }
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/dialog/getValue.hbs',
      { type },
    )
    const data = await ElysiumDialog.input({
      window: { title },
      content: html,
      ok: { label: game.i18n.localize('Elysium.confirm') },
    })
    return data.myValue
  }

  // -----------------------------------------------------------------
  // FORM HANDLER — re-flatten groups + rehydrate skills arrays
  // -----------------------------------------------------------------
  static async myCultureHandler(event, form, formData) {
    const system = foundry.utils.expandObject(formData.object)?.system
    if (typeof system !== 'undefined' && system.groups) {
      formData.object['system.groups'] = Object.values(system.groups || [])
      for (let index = 0; index < this.item.system.groups.length; index++) {
        formData.object[`system.groups.${index}.skills`] = foundry.utils.duplicate(
          this.item.system.groups[index].skills,
        )
      }
    }
    await this.document.update(formData.object)
  }
}
