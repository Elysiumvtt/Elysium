# Elysium Visual Regression Harness

Structural snapshot testing for Foundry UI. Built in P2 of the v1.0.0 rebuild.

## What this is

A two-piece test harness that detects unintended visual changes during the v1.0.0 rebuild work:

- **`capture.mjs`** — runs in the Foundry browser context. Snapshots sheet/chat/dialog state as structured JSON (computed styles for marker elements, design token values, DOM class lists).
- **`diff.mjs`** — runs in Node. Compares a captured snapshot to a baseline, reports semantic differences.

This is **not pixel screenshot testing**. We don't snapshot images — we snapshot the *visual decisions* (this title is bone-colored, this border is decorative-bone-width-1, this card is on surface-card). Image diffs would be too brittle for an environment with font/render variation between sessions. Structural diffs catch the things we actually care about.

## What it catches

- Design token value drift (`--ely-text-decorative` changed from `#c5aa8f` to something else)
- Color regressions on marker elements (section title rendered crimson when baseline was bone)
- Class-list changes (a rename codemod missed a template)
- Marker elements appearing/disappearing (selectors broke or rebuild changed structure)
- Font / size / layout property changes on tracked elements
- System identity changes (a snapshot from v0.22.0 vs one from 1.0.0-alpha.N — the comparator flags it)

## What it doesn't catch

- Pixel-level visual regressions (font hinting, anti-aliasing differences)
- Animation / transition issues
- Hover, focus, active states (capture is for resting state only)
- User-content text changes (intentionally — content variance isn't a regression)

## Workflow

### 1. Capture a baseline (one-time per sheet state)

In Foundry, open the world to a known canonical state. Open the sheet you want to baseline. In the browser console:

```js
const { captureSheet, downloadSnapshot } = await import(
  '/systems/elysium/test/visual-regression/capture.mjs'
)

// Capture the currently-focused actor sheet
const snap = await captureSheet(ui.activeWindow ?? Object.values(ui.windows).at(-1))
downloadSnapshot(snap, 'baseline-character-empty')
```

The browser downloads a `baseline-character-empty.snapshot.json`. Move it into `test/visual-regression/baseline/` and commit it.

### 2. Capture the current state (during development)

Same flow — `captureSheet(...)` → `downloadSnapshot(...)` — but save it as `captured.snapshot.json` or similar, **not** into the baseline directory.

### 3. Diff

```bash
node test/visual-regression/diff.mjs \
    test/visual-regression/baseline/baseline-character-empty.snapshot.json \
    /path/to/captured.snapshot.json
```

Exit code 0 = no changes. Exit code 1 = changes detected (printed to stdout in human-readable form).

### 4. Intentional changes → update the baseline

When a phase deliberately changes a marker (e.g. P7 retargets section titles from `--ely-legacy-colour-secondary` to `--ely-text-decorative`), the diff will fire. After verifying the change is intentional, replace the baseline with the new snapshot and commit it.

## Snapshot format

A snapshot is JSON with these top-level keys:

| Key | Purpose |
|---|---|
| `schemaVersion` | Format version. Currently `1`. Bump if the shape changes incompatibly. |
| `capturedAt` | ISO timestamp. Informational only; not used in diffs. |
| `target` | What was captured. `{kind, docType, subtype, name, docId}` for sheets; `{kind: 'chat-log'}`; `{kind: 'dialog', windowTitle}`. |
| `foundry` | Capture environment: `{version, systemVersion, systemId, theme}`. Useful for triaging "is this snapshot from before or after the rename?" |
| `tokens` | Flat map of every tracked design token to its computed value. Includes both `--ely-*` and legacy `--ely-legacy-*` for transition tracking. |
| `markers` | Array of marker results. Each is `{label, selector, tag, classes, ...properties}` for a matched element, or `null` if the selector didn't match. |
| `outerHTML` | (Sheet snapshots only) Full HTML of the captured element. **Not diffed** — but useful for manual inspection. |

## Markers

A "marker" is a curated `{selector, label, props}` triple. Markers are defined in `capture.mjs` in lists keyed to sheet type:

- `CHARACTER_SHEET_MARKERS` — actor sheet
- `ITEM_SHEET_MARKERS` — item sheets
- `CHAT_CARD_MARKERS` — chat log + combat cards
- `DIALOG_MARKERS` — modal dialogs

To add a new marker, edit `capture.mjs` and add an entry to the relevant list. Choose:

1. **A stable selector.** Prefer semantic class names that survive renames; if you must use a structural selector, pick one that's clearly load-bearing. For the rebuild, use combination selectors that match BOTH the legacy class name AND the future v1.0.0 class — e.g. `.brpTab, .elysium-tab` — so the marker survives the rename in P4.

2. **The smallest property set that catches regressions worth catching.** `VISUAL_PROPS` (color/background/border/font) is right for visible UI elements. `LAYOUT_PROPS` (display/grid-template/flex/padding/margin/gap) is right for structural elements. Mix as needed.

## Token tracking

Design tokens are captured separately from markers because they're queryable from any DOM element (they live on `:root`). Token drift is a strong regression signal — a token value change ripples to every consumer.

We track:
- All Elysium v1.0.0 tokens (`--ely-*`)
- A subset of legacy BRP tokens (`--ely-legacy-*`) for transition monitoring

When P7 retires the BRP variable system, the legacy token list in `capture.mjs` should be cleared.

## Limitations to be honest about

- **Cannot run in headless mode.** Foundry doesn't have a non-browser execution mode; capture requires a real browser session with a real world open.
- **Single-element markers.** If a selector matches 3 elements, only the first is captured. Add narrower selectors if you need to track instances.
- **No hover/focus snapshots.** Would require synthetic event dispatch; deferred unless we need it.
- **No CSS-cascade analysis.** We see the computed value, not which rule produced it. If you need to know "which selector won," use DevTools manually.

## Files

```
test/visual-regression/
├── README.md                    # this file
├── capture.mjs                  # Foundry-side capture engine
├── diff.mjs                     # Node-side diff tool + CLI
└── baseline/                    # committed baseline snapshots
    ├── (populated as baselines are captured)
    └── ...
```
