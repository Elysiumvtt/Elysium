/**
 * CharacterDataModel — schema for actors of type 'character'.
 *
 * Per P5 design (docs/datamodel-design.md), P5 prep audit
 * (docs/p5-prep-audit.md), and P5.2 handoff (docs/p5-2-handoff.md):
 * STORED-SCHEMA-ONLY. No prepareDerivedData override — ElysiumActor's
 * existing _prepareCharacterData → _prepDerivedStats chain continues
 * to populate derived fields (label, total, deriv, visible, formula,
 * etc.) on the live data object each prep cycle. Those derived fields
 * are stamped onto the runtime data and dropped by Foundry's clean
 * step on save.
 *
 * Sparse-field strategy (P3 Decision 3): Character declares the full
 * character-side elysium partition (expDice, buildPoints, skillPoints,
 * statNaturalMax, ancestryId, plus the shared creature/language
 * fields). NPC sparse-skips most of these.
 *
 * Field set is per the P5.2 handoff spec, which was derived from grep
 * audit + the P5 prep audit. Three side-findings flagged for separate
 * bug-sweep / P12 (NOT fixed here — orthogonal to P5.2 scope):
 *   1. patron.standing + statNaturalMax are READ from flags.elysium.*
 *      but WRITTEN to system.elysium.* — silent no-ops, same shape as
 *      the P4 brpidFlag mismatch
 *   2. patron, essences, schoolMastery, companion are template.json
 *      fields with ZERO system.elysium.* reads/writes — vestigial from
 *      v0.9.0–v0.20.0 magic/companion subsystem era; dropped from
 *      schema (will be re-declared if a future feature needs them)
 *   3. character.distincitve (typo for distinctive) — ZERO occurrences
 *      anywhere; dropped without preserving the typo
 *
 * One field NOT in template.json but declared here: expDiceOverride.
 * It's a one-shot boolean dynamically written by stat-improvement.mjs
 * via `'system.elysium.expDiceOverride': true/false`. Without this
 * declaration, DataModel strict validation would reject those writes.
 */

import {
  makeStats,
  makeHealth,
  makePower,
  makeFatigue,
  makeActionPoints,
  makeResourcePair,
} from './_shared.mjs'

const fields = foundry.data.fields

export class CharacterDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      // === From base template (identical to NPC base fields) ============
      stats:          makeStats(),
      health:         makeHealth(),
      power:          makePower(),
      fatigue:        makeFatigue(),
      actionPoints:   makeActionPoints(),
      tempHP:         makeResourcePair(0, 0),
      luckPoints:     makeResourcePair(0, 0),
      sanity:         makeResourcePair(0, 0),
      res5:           makeResourcePair(0, 0),
      dmgmodTier:     new fields.StringField({ initial: '+0' }),
      wealthValue:    new fields.NumberField({ integer: true, initial: 0 }),

      // Coinage tracker (P9 cluster 3 / alpha.33) — discrete coin
      // counts for PP/GP/SP/CP. Distinct from system.wealth (a
      // categorical Mythras label like "Comfortable"/"Wealthy") and
      // from system.wealthValue (legacy numeric wealth tier). Used by
      // the items tab's coinage card. Top-level (not under .elysium)
      // because coins are a generic TTRPG concept, not Elysium-fork-
      // specific. Bit-identical declaration on NPCDataModel.
      coins: new fields.SchemaField({
        pp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        gp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        sp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        cp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      }),

      // === Character-side elysium partition =============================
      // NPC sparse-skips most of these; Character declares the full set.
      // Audit-flagged side-findings (#1, #2) documented in the file header
      // and in docs/p5-2-handoff.md — NOT fixed in P5.2 scope.
      elysium: new fields.SchemaField({

        // expDice (17 occurrences in source) — EXP-dice progression
        // resource. Read/written by elysium/actor/stat-improvement.mjs
        // and creation/creation.mjs.
        expDice: new fields.SchemaField({
          available: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          diceSize:  new fields.NumberField({ integer: true, initial: 4 }),
        }),

        // expDiceOverride — NOT in template.json but actively written by
        // stat-improvement.mjs via 'system.elysium.expDiceOverride'.
        // One-shot boolean consumed by the next stat-improvement roll.
        // Must be declared or DataModel strict-validation rejects writes.
        expDiceOverride: new fields.BooleanField({ initial: false }),

        // buildPoints (8 occurrences) — point-buy pool for character
        // creation. `remaining` can go negative if over-spent (no min).
        buildPoints: new fields.SchemaField({
          total:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          ancestry:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          spent:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          remaining: new fields.NumberField({ integer: true, initial: 0 }),
        }),

        // skillPoints (8 occurrences) — same shape as buildPoints.
        skillPoints: new fields.SchemaField({
          total:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          ancestry:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          spent:     new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          remaining: new fields.NumberField({ integer: true, initial: 0 }),
        }),

        // statNaturalMax (5 occurrences) — keyed-by-stat-name dynamic
        // object. Values are the natural-max ceiling numbers for each
        // stat. TypedObjectField per audit's V14 API recommendation.
        // v1.0.0-alpha.11 (side-finding #1 resolved): readers in
        // creation.mjs and ancestry-drop.mjs now read from system.elysium.*
        // to match the writers and this declaration.
        statNaturalMax: new fields.TypedObjectField(
          new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        ),

        // ancestryId (6 occurrences) — UUID reference to ancestry item.
        // StringField for minimum migration risk; can upgrade to
        // DocumentUUIDField in P12 cleanup if desired.
        ancestryId: new fields.StringField({ initial: '' }),

        // ancestryMove — written by ancestry-drop._applyAncestryMove on
        // culture/ancestry drop; caches the ancestry's contribution to
        // movement. v1.0.0-alpha.11 (side-finding #18 resolved): declared
        // here so the write persists. Previously undeclared → silent drop.
        ancestryMove: new fields.SchemaField({
          baseMove: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          flyMove:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          swimMove: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        }),

        // Shared with NPC: creature/language fields. Character is a
        // creature too.
        creatureType: new fields.StringField({
          initial: 'humanoid',
          choices: ['humanoid', 'beast', 'undead', 'construct',
                    'spirit', 'elemental', 'plant', 'aberration'],
        }),
        creatureSubtype: new fields.StringField({ initial: 'human' }),
        creatureTags:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        languages:       new fields.ArrayField(new fields.StringField(), { initial: [] }),

        // DROPPED (zero system.elysium readers/writers; see side-finding
        // #2 in the file header): patron, essences, schoolMastery,
        // companion. If a future feature wires them up, declare then.
      }),

      // === Character-own fields (21 from template.json minus distincitve)
      age:             new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      background:      new fields.HTMLField({ initial: '' }),
      backstory:       new fields.HTMLField({ initial: '' }),
      biography:       new fields.HTMLField({ initial: '' }),
      culture:         new fields.StringField({ initial: '' }),
      description:     new fields.HTMLField({ initial: '' }),
      gender:          new fields.StringField({ initial: '' }),
      hand:            new fields.StringField({ initial: 'Right' }),  // free-text; no choices
      height:          new fields.StringField({ initial: '' }),
      lock:            new fields.BooleanField({ initial: false }),
      majorWnd:        new fields.BooleanField({ initial: false }),
      minorWnd:        new fields.BooleanField({ initial: false }),
      move:            new fields.NumberField({ integer: true, initial: 0 }),
      personalityName: new fields.StringField({ initial: '' }),
      careerName:  new fields.StringField({ initial: '' }),
      religion:        new fields.StringField({ initial: '' }),
      skillOrder:      new fields.BooleanField({ initial: true }),  // template default true
      wealth:          new fields.NumberField({ integer: true, initial: 0 }),
      weight:          new fields.StringField({ initial: '' }),

      // skillcategory: TypedObjectField keyed by skill-category id →
      // category-total number. Populated each prep cycle by
      // actor.mjs:168 from the actor's owned skill items.
      skillcategory: new fields.TypedObjectField(
        new fields.NumberField({ integer: true, initial: 0 }),
      ),

      // stories: ArrayField of {title, value} objects. Each story has a
      // title (free-text input) and value (HTML rich-text via
      // prose-mirror). Heavy use in character.background.hbs and
      // base-actor-sheet.mjs. `enriched`, `isFirst`, `isLast` are
      // template-stamped/derived — NOT stored.
      stories: new fields.ArrayField(
        new fields.SchemaField({
          title: new fields.StringField({ initial: '' }),
          value: new fields.HTMLField({ initial: '' }),
        }),
        { initial: [] },
      ),

      // DROPPED (side-finding #3): distincitve (typo for "distinctive"
      // in template.json) has ZERO grep occurrences in .mjs or .hbs.
      // Pre-existing dead field. Not preserving the typo.
    }
  }
}
