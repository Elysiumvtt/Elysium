/**
 * Sustained spells subsystem (v0.10.0).
 *
 * A "sustain" is an active arcane spell whose effect persists round-to-
 * round at a per-round PP cost. Sustains live in
 * `actor.flags['elysium'].activeSustains` as an array of state records.
 *
 * Lifecycle:
 *   - Cast completion → if spell.isSustained and cast succeeded
 *     (not corrupted, not fumbled), addSustain() registers the entry.
 *     Recasting an already-sustained spell replaces the existing entry.
 *   - Combat round start → runSustainUpkeep() drains ppPerRound from
 *     each sustain. Actor with insufficient PP → that sustain breaks.
 *   - Disruption (manual GM trigger) → disruptSustain() rolls Willpower
 *     vs an attack value; failure breaks the sustain.
 *   - Voluntary end → removeSustain() drops the entry.
 *
 * v0.10.0 ships with manual disruption (GM clicks the disrupt button).
 * Auto-disruption-on-damage is reserved for a later polish release.
 */

import { findSkill, rollD100 } from './cast-shared.mjs'
const SUSTAIN_FLAG = 'activeSustains'

/** Read all active sustains on this actor. Returns [] if none. */
export function getActiveSustains (actor) {
  return actor.getFlag('elysium', SUSTAIN_FLAG) ?? []
}

async function setActiveSustains (actor, list) {
  return actor.setFlag('elysium', SUSTAIN_FLAG, list)
}

/**
 * Register a new sustain on the actor (called at cast completion when
 * the spell is `isSustained`). Replaces any existing sustain for the
 * same spellId — re-casting an active sustain just refreshes it.
 *
 * @param {Actor}  actor
 * @param {object} entry
 * @param {string} entry.spellId
 * @param {string} entry.spellName
 * @param {number} entry.ppPerRound  - upkeep cost per round
 * @param {string} entry.schoolName
 * @param {string} [entry.manipulationSummary]
 */
export async function addSustain (actor, entry) {
  const list = getActiveSustains(actor).filter(s => s.spellId !== entry.spellId)
  list.push({
    ...entry,
    startedAtRound: game.combat?.round ?? null,
  })
  await setActiveSustains(actor, list)
  const body = `<p>${game.i18n.format('Elysium.Chat.SustainBegin', {
    actor: `<strong>${actor.name}</strong>`,
    spell: `<em>${entry.spellName}</em>`,
    pp: entry.ppPerRound,
  })}</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'mind', icon: 'infinity', body }
  )
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: html,
  })
}

/**
 * Drop a sustain by spellId. Posts a chat notice for visibility.
 */
export async function removeSustain (actor, spellId, reason = 'ended') {
  const list = getActiveSustains(actor)
  const target = list.find(s => s.spellId === spellId)
  if (!target) return
  const remaining = list.filter(s => s.spellId !== spellId)
  await setActiveSustains(actor, remaining)
  const body = `<p>${game.i18n.format('Elysium.Chat.SustainBreak', {
    actor: `<strong>${actor.name}</strong>`,
    spell: `<em>${target.spellName}</em>`,
    reason,
  })}</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'mind', icon: 'infinity', body }
  )
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: html,
  })
}

/**
 * Per-round upkeep. Called by a combat hook at the start of each round.
 * For each active sustain, drain `ppPerRound` PP. If insufficient, the
 * sustain breaks (PP is set to 0 — no overcast on upkeep).
 *
 * Returns: array of broken-sustain entries, for caller-side UI.
 */
export async function runSustainUpkeep (actor) {
  const list = getActiveSustains(actor)
  if (list.length === 0) return []

  const broken = []
  const survived = []
  let ppRemaining = Number(actor.system?.power?.value) || 0

  for (const sustain of list) {
    const cost = Number(sustain.ppPerRound) || 0
    if (ppRemaining >= cost) {
      ppRemaining -= cost
      survived.push(sustain)
    } else {
      // Insufficient — sustain breaks. PP isn't deducted (we don't pay
      // for what we couldn't sustain). Remaining PP can still feed
      // other lighter sustains in the same round, but it's rare to
      // have multiple sustains and the order is just list order.
      broken.push(sustain)
    }
  }

  // Apply: deduct the PP we actually spent on sustains that survived.
  const startingPP = Number(actor.system?.power?.value) || 0
  const ppSpent = startingPP - ppRemaining
  await actor.update({
    'system.power.value': ppRemaining,
  })
  await setActiveSustains(actor, survived)

  if (ppSpent > 0 || broken.length > 0) {
    const lines = []
    if (ppSpent > 0) {
      lines.push(`<strong>${actor.name}</strong> spends ${ppSpent} PP on sustains.`)
    }
    for (const b of broken) {
      lines.push(`<em>${b.spellName}</em> collapses (insufficient PP).`)
    }
    const body = `<p>${lines.join('<br>')}</p>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'mind', icon: 'infinity', body }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  }
  return broken
}

/**
 * Trigger a disruption check. Player rolls Willpower (or another save
 * skill) vs a target value (the attacker's d100 hit roll). Failure
 * breaks the sustain.
 *
 * @param {Actor}  actor
 * @param {string} spellId        - the sustain to test
 * @param {number} attackerRoll   - d100 the attacker rolled
 * @param {string} [saveSkillName='Willpower']
 */
export async function disruptSustain (actor, spellId, attackerRoll, saveSkillName = 'Willpower') {
  const sustain = getActiveSustains(actor).find(s => s.spellId === spellId)
  if (!sustain) {
    ui.notifications?.warn(`${actor.name} is not sustaining that spell.`)
    return
  }
  const skill = findSkill(actor, { name: saveSkillName })
  if (!skill) {
    ui.notifications?.warn(`${actor.name} has no ${saveSkillName} skill.`)
    return
  }
  const skillTotal = skill.system?.total ?? skill.system?.base ?? 0

  const { value: defenderRoll } = await rollD100({ flavor: `Disruption: ${sustain.spellName}` })
  const defenderSuccess = defenderRoll <= skillTotal
  const attackerSuccess = attackerRoll > 0 && attackerRoll <= 100  // attacker passed by definition (they hit)

  // Opposed-roll resolution: defender keeps sustain if their roll succeeds
  // AND beats the attacker's roll value (lower wins on ties — defender's
  // skill being higher is what matters). Simplified: defender succeeds
  // → keeps sustain. Defender fails → breaks. The attacker's roll value
  // is shown for context but we use a straight roll-under check here.
  const outcome = defenderSuccess
    ? game.i18n.localize('Elysium.Chat.SustainHolds')
    : game.i18n.localize('Elysium.Chat.SustainBreaks')
  const body = `<p>${game.i18n.format('Elysium.Chat.SustainDisruptRoll', {
    actor: `<strong>${actor.name}</strong>`,
    skill: saveSkillName,
    roll: `<strong>${defenderRoll}</strong>`,
    target: skillTotal,
    spell: `<em>${sustain.spellName}</em>`,
    attackerRoll,
  })}</p><p>${outcome}</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
    {
      variant: defenderSuccess ? 'mind' : 'danger',
      title: `${sustain.spellName} — disrupt check`,
      icon: 'infinity',
      body,
    }
  )
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: html,
  })
  if (!defenderSuccess) {
    await removeSustain(actor, spellId, 'disrupted by damage')
  }
}
