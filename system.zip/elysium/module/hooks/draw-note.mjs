export function listen() {
  Hooks.on('drawNote', async (application) => {
    if (application.document.getFlag('elysium', 'hide-background') ?? false) {
      application.controlIcon.bg.clear()
    }
  })
}
