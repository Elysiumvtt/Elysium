import { BRPCharacterSheet } from '../actor/sheets/character.mjs';
import { BRPNPCSheetV2 } from '../actor/sheets/npcV2.mjs';
import { BRPGearSheet } from '../item/sheets/gear.mjs';
import { BRPSkillSheet } from '../item/sheets/skill.mjs';
import { BRPHitLocSheet } from '../item/sheets/hit-location.mjs';
import { BRPPersonalitySheet } from '../item/sheets/personality.mjs';
import { BRPProfessionSheet } from '../item/sheets/profession.mjs'
import { BRPPowerSheet } from '../item/sheets/power.mjs'
import { BRPMagicSheet } from '../item/sheets/magic.mjs'
import { BRPMutationSheet } from '../item/sheets/mutation.mjs'
import { BRPPsychicSheet } from '../item/sheets/psychic.mjs'
import { BRPSorcerySheet } from '../item/sheets/sorcery.mjs'
import { BRPSuperSheet } from '../item/sheets/super.mjs'
import { BRPFailingSheet } from '../item/sheets/failing.mjs'
import { BRPPowerModSheet } from '../item/sheets/powerMod.mjs'
import { BRPArmourSheet } from '../item/sheets/armour.mjs'
import { BRPWeaponSheet } from '../item/sheets/weapon.mjs'
import { BRPWoundSheet } from '../item/sheets/wound.mjs'
import { BRPAllegianceSheet } from '../item/sheets/allegiance.mjs'
import { BRPPassionSheet } from '../item/sheets/passion.mjs'
import { BRPPersTraitSheet } from '../item/sheets/persTrait.mjs'
import { BRPReputationSheet } from '../item/sheets/reputation.mjs'
import { BRPRollTableConfig } from '../sheets/elysium-roll-table-config.mjs'
import { BRPJournalSheet } from '../sheets/elysium-journal-sheet.mjs'
import { BRPSkillCategory } from '../item/sheets/skillcat.mjs'
import { BRPCultureSheet } from '../item/sheets/culture.mjs'


export function registerSheets() {

  const { sheets } = foundry.applications;
  let { collections } = foundry.documents;


  foundry.documents.collections.Actors.unregisterSheet("core", foundry.appv1.sheets.ActorSheet);
  foundry.documents.collections.Actors.registerSheet('elysium', BRPCharacterSheet, {
    types: ['character'],
    makeDefault: true
  })

  foundry.documents.collections.Actors.registerSheet('elysium', BRPNPCSheetV2, {
    types: ['npc'],
    makeDefault: true
  })

  foundry.documents.collections.Items.unregisterSheet('core', foundry.appv1.sheets.ItemSheet)
  collections.Items.unregisterSheet("core", sheets.ItemSheetV2);
  foundry.documents.collections.Items.registerSheet('elysium', BRPGearSheet, {
    types: ['gear'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPSkillSheet, {
    types: ['skill'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPHitLocSheet, {
    types: ['hit-location'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPersonalitySheet, {
    types: ['personality'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPProfessionSheet, {
    types: ['profession'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPowerSheet, {
    types: ['power'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPMagicSheet, {
    types: ['magic'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPMutationSheet, {
    types: ['mutation'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPsychicSheet, {
    types: ['psychic'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPSorcerySheet, {
    types: ['sorcery'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPSuperSheet, {
    types: ['super'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPFailingSheet, {
    types: ['failing'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPowerModSheet, {
    types: ['powerMod'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPArmourSheet, {
    types: ['armour'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPWeaponSheet, {
    types: ['weapon'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPWoundSheet, {
    types: ['wound'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPAllegianceSheet, {
    types: ['allegiance'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPassionSheet, {
    types: ['passion'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPPersTraitSheet, {
    types: ['persTrait'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPReputationSheet, {
    types: ['reputation'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPSkillCategory, {
    types: ['skillcat'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', BRPCultureSheet, {
    types: ['culture'],
    makeDefault: true
  })

  foundry.documents.collections.RollTables.unregisterSheet('core', foundry.applications.sheets.RollTableSheet)
  foundry.documents.collections.RollTables.registerSheet('elysium', BRPRollTableConfig, {
    makeDefault: true
  })

  foundry.documents.collections.Journal.unregisterSheet('core', foundry.appv1.sheets.JournalSheet)
  foundry.documents.collections.Journal.registerSheet('elysium', BRPJournalSheet, {
    makeDefault: true
  })
}
