import { Elysium } from '../setup/config.mjs'
import { ElysiumUtilities } from '../apps/utilities.mjs'
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api

export class ElysiumIDEditor extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    tag: 'form',
    name: "elysiumidEditor",
    classes: ['elysium', 'dialog', 'elysiumid-editor'],
    form: {
      handler: ElysiumIDEditor._updateObject,
      closeOnSubmit: false,
      submitOnClose: true,
      submitOnChange: true,
    },
    position: {
      width: 900,
      height: "auto",
    },
    actions: {
      copyToClip: ElysiumIDEditor.copyToClip,
      guess: ElysiumIDEditor.guessID,
    },

    window: {
      title: 'Elysium.ElysiumIDFlag.title',
      contentClasses: ["standard-form"],
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/elysiumid/elysiumid-editor.hbs' },
  }

  static addElysiumIDSheetHeaderButton (application, element) {
    if (typeof application.options.actions.elysiumid !== 'undefined') return
    application.options.actions.elysiumid = {
      handler: (event, element) => {
        event.preventDefault()
        event.stopPropagation()
        if (event.detail > 1) return // Ignore repeated clicks
        if (event.button === 2 && (application.document.flags.elysium?.elysiumidFlag?.id ?? false)) {
          game.clipboard.copyPlainText(application.document.flags.elysium.elysiumidFlag.id)
          ui.notifications.info('Elysium.WhatCopiedClipboard', { format: { what: game.i18n.localize('Elysium.ElysiumIDFlag.key') }, console: false })
        } else {
          new ElysiumIDEditor({ document: application.document }, {}).render(true, { focus: true })
        }
      },
      buttons: [0, 2]
    }
    const copyUuid = element.querySelector('button.header-control.fa-solid.fa-passport')
    if (copyUuid) {
      const button = document.createElement('button')
      button.type = 'button'
      button.classList = 'header-control fa-solid fa-fingerprint icon'
      if (!(application.document.flags.elysium?.elysiumidFlag?.id ?? false)) {
        button.classList.add('invalid-elysiumid')
      }
      button.dataset.action = 'elysiumid'
      button.dataset.tooltip = 'Elysium.ElysiumIDFlag.id'
      copyUuid.after(button)
    }
  }

  async _prepareContext(options) {

    this.document = this.options.document
    const sheetData = await super._prepareContext()
    sheetData.objtype = this.document.type
    sheetData.objid = this.document.id
    sheetData.objuuid = this.document.uuid
    sheetData.supportedLanguages = CONFIG.supportedLanguages
    sheetData.isEditable = this.document.sheet.isEditable
    sheetData.guessCode = game.system.api.elysiumid.guessId(this.document)
    sheetData.idPrefix = game.system.api.elysiumid.getPrefix(this.document)
    sheetData.elysiumidFlag = this.document.flags?.elysium?.elysiumidFlag
    sheetData.id = sheetData.elysiumidFlag?.id || ''
    sheetData.lang = sheetData.elysiumidFlag?.lang || game.i18n.lang
    sheetData.priority = sheetData.elysiumidFlag?.priority || 0

    //const ElysiumIDKeys = foundry.utils.flattenObject(game.i18n.translations.Elysium.ElysiumIDFlag.keys ?? {})
    const ElysiumIDKeys = game.system.api.elysiumid.getElysiumIDKeys()

    const prefix = new RegExp('^' + ElysiumUtilities.quoteRegExp(sheetData.idPrefix))
    sheetData.existingKeys = Object.keys(ElysiumIDKeys).reduce((obj, k) => {
      if (k.match(prefix)) {
        obj.push({ k, name: ElysiumIDKeys[k] })
      }
      return obj
    }, []).sort(ElysiumUtilities.sortByNameKey)
    sheetData.isSystemID = (typeof ElysiumIDKeys[sheetData.id] !== 'undefined')
    const match = sheetData.id.match(/^([^\\.]+)\.([^\\.]*)\.(.+)/)
    sheetData._existing = (match && typeof match[3] !== 'undefined' ? match[3] : '')

    if (sheetData.id && sheetData.lang) {
      // Find out if there exists a duplicate ElysiumID
      const worldDocuments = await game.system.api.elysiumid.fromElysiumIDAll({
        elysiumid: sheetData.id,
        lang: sheetData.lang,
        scope: 'world'
      })
      const uniqueWorldPriority = {}
      sheetData.worldDocumentInfo = await Promise.all(worldDocuments.map(async (d) => {
        return {
          priority: d.flags.elysium.elysiumidFlag.priority,
          lang: d.flags.elysium.elysiumidFlag.lang ?? 'en',
          link: await foundry.applications.ux.TextEditor.implementation.enrichHTML(d.link),
          folder: d?.folder?.name
        }
      }))
      const uniqueWorldPriorityCount = new Set(worldDocuments.map((d) => d.flags.elysium.elysiumidFlag.priority)).size;
      if (uniqueWorldPriorityCount !== worldDocuments.length) {
        sheetData.warnDuplicateWorldPriority = true;
      }
      sheetData.worldDuplicates = worldDocuments.length ?? 0

      const compendiumDocuments = await game.system.api.elysiumid.fromElysiumIDAll({
        elysiumid: sheetData.id,
        lang: sheetData.lang,
        scope: 'compendiums'
      })
      const uniqueCompendiumPriority = {}
      sheetData.compendiumDocumentInfo = await Promise.all(compendiumDocuments.map(async (d) => {
        return {
          priority: d.flags.elysium.elysiumidFlag.priority,
          lang: d.flags.elysium.elysiumidFlag.lang ?? 'en',
          link: await foundry.applications.ux.TextEditor.implementation.enrichHTML(d.link, {}),
          folder: d?.folder?.name ?? ''
        }
      }))

      const uniqueCompendiumPriorityCount = new Set(compendiumDocuments.map((d) => d.flags.elysium.elysiumidFlag.priority)).size;
      if (uniqueCompendiumPriorityCount !== compendiumDocuments.length) {
        sheetData.warnDuplicateCompendiumPriority = true;
      }
      sheetData.compendiumDuplicates = compendiumDocuments.length ?? 0
    } else {
      sheetData.compendiumDocumentInfo = []
      sheetData.worldDocumentInfo = []
      sheetData.worldDuplicates = 0
      sheetData.compendiumDuplicates = 0
      sheetData.warnDuplicateWorldPriority = false
      sheetData.warnDuplicateCompendiumPriority = false
    }
    return sheetData
  }

  _onRender(context, options) {
    if (this.element.querySelector('input[name=_existing')) {
      this.element.querySelector('input[name=_existing').addEventListener("change", function (e) {
        const prefix = this.dataset.prefix
        let value = this.value
        if (value !== '') {
          value = prefix + ElysiumUtilities.toKebabCase(value)
        }
        const target = document.querySelector('input[name=id]');
        target.value = value
      })
    }

    if (this.element.querySelector('select[name=known]')) {
      this.element.querySelector('select[name=known]').addEventListener("change", function (e) {
        const value = this.value
        const target = document.querySelector('input[name=id]');
        target.value = value
      })
    }

  }

  static async copyToClip(event, target) {
    await ElysiumUtilities.copyToClipboard(target.parentElement.querySelector('input').value)
  }

  static async guessID(event, target) {
    const guess = target.dataset.guess
    const priority = this.document.flags.elysium?.elysiumidFlag?.priority ?? 0
    const lang = this.document.flags.elysium?.elysiumidFlag?.lang ?? game.i18n.lang

    await this.document.update({
      'flags.elysium.elysiumidFlag.id': guess,
      'flags.elysium.elysiumidFlag.lang': lang,
      'flags.elysium.elysiumidFlag.priority': priority,
    })
    this.document.sheet.element?.querySelectorAll('header.window-header .edit-elysiumid-warning, header.window-header .edit-elysiumid-exisiting').forEach(el => {
      el.style.color = guess ? 'var(--color-text-light-highlight)' : 'red'
    })
    this.render()
  }

  static async _updateObject(event, form, formData) {
    const usage = foundry.utils.expandObject(formData.object)
    const id = usage.id || ''
    const priority = usage.priority || 0
    const lang = usage.lang || game.i18n.lang
    await this.document.update({
      'flags.elysium.elysiumidFlag.id': id,
      'flags.elysium.elysiumidFlag.lang': lang,
      'flags.elysium.elysiumidFlag.priority': priority,
    })
    this.document.sheet.element?.querySelectorAll('header.window-header .edit-elysiumid-warning, header.window-header .edit-elysiumid-exisiting').forEach(el => {
      el.style.color = id ? 'var(--color-text-light-highlight)' : 'red'
    })
    this.render()
  }

}
