/**
 * Elysium Sheet Extension
 *
 * Augments BRP V2 actor and item sheets with Elysium UI:
 *   - Action Point pip display
 *   - Fatigue level meter
 *   - Casting penalty breakdown tooltip
 *   - Wound condition indicators
 *   - Luck Points display/spend buttons
 *   - Ancestry information panel
 *   - Magic system access indicators
 *
 * Implementation note: rather than rewriting BRP sheets, this hooks
 * into the renderActorSheetV2 callback and injects HTML into the
 * existing sheet template. This way BRP can be updated independently.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumData } from '../helpers/data.mjs'

export class ElysiumSheetExtension {

  /**
   * Called on every actor sheet render.
   */
  static async extendActorSheet (app, html, data) {
    const actor = app.actor
    if (!actor) return

    // Only extend BRP character sheet
    if (!app.constructor.name.includes('Character')) return

    // Inject Action Points display
    if (getSetting('enableActionPoints', true)) {
      this._injectActionPoints(html, actor)
    }

    // Inject Fatigue display
    if (getSetting('enableMythrasFatigue', true) &&
        getSetting('showFatigueOnSheet', true)) {
      this._injectFatigue(html, actor)
    }

    // Inject Luck Points display
    if (getSetting('enableLuckPoints', true)) {
      this._injectLuckPoints(html, actor)
    }

    // Inject casting penalty (for casters)
    if (getSetting('enableArmourCastingPenalty', true)) {
      this._injectCastingPenalty(html, actor)
    }

    // Wire up event handlers
    this._wireEvents(app, html, actor)
  }

  /**
   * Called on every item sheet render
   */
  static async extendItemSheet (app, html, data) {
    const item = app.item
    if (!item) return

    // Add Elysium fields to weapon, armour, culture sheets
    if (item.type === 'weapon') {
      this._injectWeaponFields(html, item)
    }
    if (item.type === 'armour') {
      this._injectArmourFields(html, item)
    }
    if (item.type === 'culture') {
      this._injectAncestryFields(html, item)
    }
  }


  // === ACTOR INJECTIONS =============================================

  static _injectActionPoints (html, actor) {
    const ap = actor.flags?.elysium?.actionPoints
    if (!ap) return

    const target = html.querySelector('.brp-character-stats') ||
                   html.querySelector('.tab.summary') ||
                   html.querySelector('.brp-stats')
    if (!target) return

    const apHtml = `
      <div class="elysium-ap-display" data-tooltip="${this._buildAPTooltip(ap)}">
        <label>${game.i18n.localize('Elysium.ActionPoints')}</label>
        <div class="elysium-ap-pips">
          ${this._renderPips(ap.value, ap.max)}
        </div>
        <span class="elysium-ap-text">${ap.value} / ${ap.max}</span>
      </div>
    `

    const wrapper = document.createElement('div')
    wrapper.innerHTML = apHtml
    target.appendChild(wrapper.firstElementChild)
  }

  static _renderPips (current, max) {
    let pips = ''
    for (let i = 0; i < max; i++) {
      pips += `<span class="elysium-pip ${i < current ? 'filled' : 'empty'}"></span>`
    }
    return pips
  }

  static _buildAPTooltip (ap) {
    const lines = []
    if (ap.breakdown?.base) lines.push(`Base: ${ap.breakdown.base}`)
    if (ap.breakdown?.spell) lines.push(`Spell: +${ap.breakdown.spell}`)
    if (ap.breakdown?.skill) lines.push(`Skill: +${ap.breakdown.skill}`)
    if (ap.breakdown?.ancestry) lines.push(`Ancestry: +${ap.breakdown.ancestry}`)
    if (ap.breakdown?.items) lines.push(`Items: +${ap.breakdown.items}`)
    if (ap.breakdown?.wound) lines.push(`Wounds: ${ap.breakdown.wound}`)
    if (ap.breakdown?.fatigue) lines.push(`Fatigue: ${ap.breakdown.fatigue}`)
    return lines.join(' / ')
  }

  static _injectFatigue (html, actor) {
    const fatigue = actor.flags?.elysium?.fatigue
    if (!fatigue) return

    const target = html.querySelector('.brp-resources') ||
                   html.querySelector('.tab.summary') ||
                   html.querySelector('.brp-stats')
    if (!target) return

    const data = ELYSIUM.FATIGUE_LEVELS[fatigue.level] || ELYSIUM.FATIGUE_LEVELS[0]
    const html_ = `
      <div class="elysium-fatigue-display" data-tooltip="${data.label}">
        <label>${game.i18n.localize('Elysium.Fatigue.Title')}</label>
        <div class="elysium-fatigue-bar">
          <div class="elysium-fatigue-fill" style="width: ${(fatigue.level / 9) * 100}%"></div>
        </div>
        <span class="elysium-fatigue-text">
          ${game.i18n.localize(`Elysium.Fatigue.Levels.${data.label}`)}
        </span>
      </div>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }

  static _injectLuckPoints (html, actor) {
    const luck = actor.flags?.elysium?.luckPoints
    if (!luck) return

    const target = html.querySelector('.brp-resources') ||
                   html.querySelector('.tab.summary') ||
                   html.querySelector('.brp-stats')
    if (!target) return

    const html_ = `
      <div class="elysium-luck-display">
        <label>${game.i18n.localize('Elysium.Luck.Title')}</label>
        <div class="elysium-luck-pips">
          ${this._renderPips(luck.value, luck.max)}
        </div>
        <span class="elysium-luck-text">${luck.value} / ${luck.max}</span>
      </div>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }

  static _injectCastingPenalty (html, actor) {
    const cp = actor.flags?.elysium?.derived?.castingPenalty
    if (!cp || cp.finalPenalty === 0) return

    const target = html.querySelector('.brp-resources') ||
                   html.querySelector('.tab.summary')
    if (!target) return

    const tooltip = cp.breakdown?.map(b =>
      `${b.item} (${b.location} ${b.flexibility}): ${b.penalty}%`
    ).join('\n') || ''

    const html_ = `
      <div class="elysium-casting-penalty" data-tooltip="${tooltip}">
        <label>${game.i18n.localize('Elysium.Magic.CastingPenalty')}</label>
        <span class="elysium-cp-text">${cp.finalPenalty}%</span>
      </div>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }


  // === ITEM INJECTIONS ==============================================

  static _injectWeaponFields (html, item) {
    const target = html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return

    const flags = ElysiumData.get(item)
    const html_ = `
      <fieldset class="elysium-weapon-fields">
        <legend>${game.i18n.localize('Elysium.Weapon.Fields')}</legend>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Weapon.Size')}</label>
          <select name="flags.elysium.weaponSize">
            ${ELYSIUM.WEAPON_SIZES.map(s =>
              `<option value="${s}" ${flags.weaponSize === s ? 'selected' : ''}>${s}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Weapon.Reach')}</label>
          <select name="flags.elysium.weaponReach">
            ${ELYSIUM.WEAPON_REACHES.map(r =>
              `<option value="${r}" ${flags.weaponReach === r ? 'selected' : ''}>${r}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Weapon.Force')}</label>
          <input type="number" name="flags.elysium.force"
                 value="${flags.force || 0}" min="0" max="20">
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }

  static _injectArmourFields (html, item) {
    const target = html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return

    const flags = ElysiumData.get(item)
    const html_ = `
      <fieldset class="elysium-armour-fields">
        <legend>${game.i18n.localize('Elysium.Armour.Fields')}</legend>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armour.Flexibility')}</label>
          <select name="flags.elysium.flexibility">
            ${Object.keys(ELYSIUM.ARMOUR_FLEXIBILITY).map(f =>
              `<option value="${f}" ${flags.flexibility === f ? 'selected' : ''}>${f}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armour.Material')}</label>
          <select name="flags.elysium.material">
            ${Object.keys(ELYSIUM.ARMOUR_MATERIALS).map(m =>
              `<option value="${m}" ${flags.material === m ? 'selected' : ''}>${m}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armour.HP')}</label>
          <input type="number" name="flags.elysium.armorHP.value"
                 value="${flags.armorHP?.value || 10}" min="0" max="999">
          <span> / </span>
          <input type="number" name="flags.elysium.armorHP.max"
                 value="${flags.armorHP?.max || 10}" min="0" max="999">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armour.LayerOrder')}</label>
          <input type="number" name="flags.elysium.layerOrder"
                 value="${flags.layerOrder || 1}" min="0" max="5">
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }

  static _injectAncestryFields (html, item) {
    if (!getSetting('enableAncestrySystem', true)) return
    const target = html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return

    const a = ElysiumData.path(item, 'ancestry', {}) || {}
    const html_ = `
      <fieldset class="elysium-ancestry-fields">
        <legend>${game.i18n.localize('Elysium.Ancestry.Fields')}</legend>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.BaseMove')}</label>
          <input type="number" name="flags.elysium.ancestry.baseMove"
                 value="${a.baseMove || 30}" min="0" max="120">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.FlyMove')}</label>
          <input type="number" name="flags.elysium.ancestry.flyMove"
                 value="${a.flyMove || 0}" min="0" max="120">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.BuildPoints')}</label>
          <input type="number" name="flags.elysium.ancestry.buildPoints"
                 value="${a.buildPoints || 0}" min="-50" max="50">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.SkillPoints')}</label>
          <input type="number" name="flags.elysium.ancestry.skillPoints"
                 value="${a.skillPoints || 0}" min="-50" max="50">
        </div>
        <p class="hint">${game.i18n.localize('Elysium.Ancestry.AdvancedHint')}</p>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }


  // === EVENT HANDLERS ===============================================

  static _wireEvents (app, html, actor) {
    // Spend Luck Point button
    html.querySelectorAll('[data-elysium-action="spendLuck"]').forEach(el => {
      el.addEventListener('click', async () => {
        const luck = actor.flags?.elysium?.luckPoints?.value || 0
        if (luck <= 0) return ui.notifications.warn(game.i18n.localize('Elysium.Luck.None'))
        await actor.update({ 'flags.elysium.luckPoints.value': luck - 1 })
      })
    })

    // Increment Fatigue button (GM only)
    html.querySelectorAll('[data-elysium-action="incrementFatigue"]').forEach(el => {
      el.addEventListener('click', async () => {
        if (!game.user.isGM) return
        const { ElysiumFatigueManager } = await import('../fatigue/fatigue-manager.mjs')
        await ElysiumFatigueManager.increment(actor, 1, 'physical', 'manual')
      })
    })

    // Decrement Fatigue button
    html.querySelectorAll('[data-elysium-action="decrementFatigue"]').forEach(el => {
      el.addEventListener('click', async () => {
        const { ElysiumFatigueManager } = await import('../fatigue/fatigue-manager.mjs')
        await ElysiumFatigueManager.decrement(actor, 1)
      })
    })
  }
}
