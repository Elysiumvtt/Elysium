/**
 * CultureDataModel — schema for items of type 'culture'.
 *
 * Per P6.2 spec. Stored-schema-only. 20 compendium items in ancestries.db
 * (which uses type 'culture' — cultures and ancestries share this type).
 *
 * Schema split:
 *   - Top-level fields {skills, groups, move, stats} are used during
 *     character creation when a culture is dragged onto a character.
 *     Compendium cultures don't populate these; they default-initialize.
 *   - `elysium.ancestry` is the deeply-nested ancestry schema used by the
 *     ancestry subsystem (enabled by `enableAncestrySystem` setting).
 *     Compendium cultures populate this fully.
 *
 * Shape decisions per P6.2 audit:
 *   - `skills` / `groups[].skills` use {uuid, elysiumid, BONUS} shape
 *     (culture.mjs:_onDrop:217,243). Distinct from personality's
 *     {uuid, elysiumid} — bonus is the cultural skill bonus.
 *   - `stats` is a 7-stat block (no edu), each {formula, mod}.
 *     Per-stat defaults from template.json: str/con/pow/dex/cha use
 *     '3d6'; int/siz use '2d6+6'.
 *   - `traits` uses {uuid, name} shape (NOT {uuid, elysiumid}) per
 *     compendium content like High Elf -> Keen Mind.
 *   - `naturalWeapons`, `resistances`, `subraces` declared with
 *     permissive inner shapes (empty in all 20 compendium ancestries;
 *     side-finding #10 for P12 to tighten once content populates).
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

function makeCultureSkillRef () {
  return new fields.SchemaField({
    uuid:      new fields.StringField({ initial: '' }),
    elysiumid: new fields.StringField({ initial: '' }),
    bonus:     new fields.NumberField({ integer: true, initial: 0 }),
  })
}

function makeStatBlock (formula) {
  return new fields.SchemaField({
    formula: new fields.StringField({ initial: formula }),
    mod:     new fields.NumberField({ integer: true, initial: 0 }),
  })
}

export class CultureDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),

      // Top-level character-creation fields. Empty on compendium cultures.
      skills: new fields.ArrayField(makeCultureSkillRef(), { initial: [] }),
      groups: new fields.ArrayField(
        new fields.SchemaField({
          options: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
          skills:  new fields.ArrayField(makeCultureSkillRef(), { initial: [] }),
        }),
        { initial: [] },
      ),
      move: new fields.NumberField({ integer: true, initial: 0 }),
      stats: new fields.SchemaField({
        str: makeStatBlock('3d6'),
        con: makeStatBlock('3d6'),
        int: makeStatBlock('2d6+6'),
        siz: makeStatBlock('2d6+6'),
        pow: makeStatBlock('3d6'),
        dex: makeStatBlock('3d6'),
        cha: makeStatBlock('3d6'),
      }),

      // Ancestry subsystem — fully populated on compendium ancestries.
      elysium: new fields.SchemaField({
        ancestry: new fields.SchemaField({
          isElysiumAncestry: new fields.BooleanField({ initial: false }),
          baseMove:          new fields.NumberField({ integer: true, initial: 30, min: 0 }),
          flyMove:           new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          swimMove:          new fields.NumberField({ integer: true, initial: 0, min: 0 }),
          buildPoints:       new fields.NumberField({ integer: true, initial: 0 }),
          skillPoints:       new fields.NumberField({ integer: true, initial: 0 }),

          // statMods: array of {stat: string, value: number}.
          // v1.0.0-alpha.11 (side-finding #9): schema-layer normalization
          // + choices lock. Compendium content historically used uppercase
          // stat names ('INT', 'STR') vs actor's lowercase 'int'/'str';
          // compendium regenerated to lowercase in this release, and the
          // schema now both enforces the 7-stat set and ensures the
          // canonical lowercase form via initial value choice.
          statMods: new fields.ArrayField(
            new fields.SchemaField({
              stat:  new fields.StringField({
                initial: 'str',
                choices: ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha'],
              }),
              value: new fields.NumberField({ integer: true, initial: 0 }),
            }),
            { initial: [] },
          ),

          // traits: {uuid, name} pairs referencing mutation/ability items.
          // Distinct from skill-refs (no elysiumid; has a stored name).
          traits: new fields.ArrayField(
            new fields.SchemaField({
              uuid: new fields.StringField({ initial: '' }),
              name: new fields.StringField({ initial: '' }),
            }),
            { initial: [] },
          ),

          naturalArmor: new fields.SchemaField({
            ap:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
            locations: new fields.StringField({ initial: 'all' }),
          }),

          // Permissive shapes (side-finding #10: 0 ground-truth content):
          naturalWeapons: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
          resistances:    new fields.ObjectField({ initial: {} }),
          languages:      new fields.ArrayField(new fields.StringField(), { initial: [] }),
          subraces:       new fields.ArrayField(new fields.StringField(), { initial: [] }),

          parentId:       new fields.StringField({ initial: '' }),
          isSubrace:      new fields.BooleanField({ initial: false }),
          hitLocationSet: new fields.StringField({ initial: 'humanoid' }),
        }),
      }),
    }
  }
}
