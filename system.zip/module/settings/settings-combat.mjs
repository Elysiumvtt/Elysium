const SETTINGS = {

  initStat: {
    name: 'Elysium.Settings.initStat',
    hint: 'Elysium.Settings.initStatHint',
    scope: 'world',
    config: false,
    default: "dex",
    type: String,
  },

  initMod: {
    name: 'Elysium.Settings.initMod',
    hint: 'Elysium.Settings.initModHint',
    scope: 'world',
    config: false,
    default: "+0",
    type: String,
  },

  initRound: {
    name: "Elysium.Settings.initRound",
    hint: "Elysium.Settings.initRoundHint",
    scope: "world",
    config: false,
    type: String,
    default: "no",
  },

  quickCombat: {
    name: "Elysium.Settings.quickCombat",
    hint: "Elysium.Settings.quickCombatHint",
    scope: "world",
    config: false,
    default: false,
    type: Boolean
  },

}

import { ElysiumSelectLists } from '../apps/select-lists.mjs'

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api
export class ElysiumCombatRuleSettings extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'rulesmenu'],
    id: 'char-settings',
    actions: {
      reset: ElysiumCombatRuleSettings.onResetDefaults,
    },
    form: {
      handler: ElysiumCombatRuleSettings.formHandler,
      closeOnSubmit: true,
      submitOnChange: false
    },
    position: {
      width: 550,
      height: 'auto',
    },
    tag: 'form',
    window: {
      resizable: true,
      title: 'Elysium.systemSettings',
      contentClasses: ["standard-form"]
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/settings/combat-settings.hbs',
            scrollable: ['']
     },
    footer: { template: 'templates/generic/form-footer.hbs' }
  }

  async _prepareContext(options) {
    const isGM = game.user.isGM;
    const optSet = {}
    optSet.initChoiceList = await ElysiumSelectLists.getStatOptions();
    optSet.initRoundList = {
      "no": game.i18n.localize('Elysium.no'),
      "manual": game.i18n.localize('Elysium.manual'),
      "auto": game.i18n.localize('Elysium.automatic'),
    }
    for (const [k, v] of Object.entries(SETTINGS)) {
      optSet[k] = {
        value: game.settings.get('elysium', k),
        setting: v
      }
    }
    return {
      isGM,
      optSet,
      buttons: [
        { type: "submit", icon: "fa-solid fa-save", label: "SETTINGS.Save" },
        { type: "reset", action: "reset", icon: "fa-solid fa-undo", label: "SETTINGS.Reset" },
      ]
    }
  }

  static registerSettings() {
    for (const [k, v] of Object.entries(SETTINGS)) {
      game.settings.register('elysium', k, v)
    }
  }

  static async onResetDefaults(event) {
    event.preventDefault()
    for await (const [k, v] of Object.entries(SETTINGS)) {
      await game.settings.set('elysium', k, v?.default)
    }
    return this.render()
  }

  static async formHandler(event, form, formData) {
    const settings = foundry.utils.expandObject(formData.object)
    await Promise.all(
      Object.entries(settings)
        .map(([key, value]) => game.settings.set("elysium", key, value))
    )
  }

}
