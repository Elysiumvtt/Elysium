// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { injectItemModifiers } from './item-modifiers.mjs'

export function injectArmorFields (html, item) {
    const target = html.querySelector('.tab.details') ||
                   html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return
    if (target.querySelector('.elysium-armor-fields')) return

    const ely = item.system?.elysium || {}
    const layer = ely.layer || (ely.flexibility === 'natural' ? 'natural' : 'worn')
    const wornStratum = ely.wornStratum
                     || (ely.flexibility === 'inflexible' ? 'plate'
                       : ely.flexibility === 'flexible'   ? 'soft'
                       : 'soft')

    const html_ = `
      <fieldset class="elysium-armor-fields">
        <legend>${game.i18n.localize('Elysium.Armor.Fields')}</legend>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Armor.LayerHint')}">
            ${game.i18n.localize('Elysium.Armor.Layer')}
          </label>
          <select name="system.elysium.layer">
            ${Object.keys(ELYSIUM.ARMOR_LAYERS).map(l =>
              `<option value="${l}" ${layer === l ? 'selected' : ''}>${ELYSIUM.ARMOR_LAYERS[l].label}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Armor.WornStratumHint')}">
            ${game.i18n.localize('Elysium.Armor.WornStratum')}
          </label>
          <select name="system.elysium.wornStratum">
            ${Object.keys(ELYSIUM.ARMOR_WORN_STRATA).map(s =>
              `<option value="${s}" ${wornStratum === s ? 'selected' : ''}>${ELYSIUM.ARMOR_WORN_STRATA[s].label} (${ELYSIUM.ARMOR_WORN_STRATA[s].examples})</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armor.Flexibility')}</label>
          <select name="system.elysium.flexibility">
            ${Object.keys(ELYSIUM.ARMOR_FLEXIBILITY).map(f =>
              `<option value="${f}" ${ely.flexibility === f ? 'selected' : ''}>${f}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Armor.Material')}</label>
          <select name="system.elysium.material">
            ${Object.keys(ELYSIUM.ARMOR_MATERIALS).map(m =>
              `<option value="${m}" ${ely.material === m ? 'selected' : ''}>${m}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Armor.HPBaseHint')}">
            Max AP
          </label>
          <input type="number" name="system.elysium.apMax"
                 value="${ely.apMax ?? 0}" min="0" max="999">
        </div>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Armor.HPCurrentHint')}">
            Current AP
          </label>
          <input type="number" name="system.av1"
                 value="${item.system?.av1 ?? 0}" min="0" max="999"
                 ${((ely.apMax ?? 0) > 0 && (item.system?.av1 ?? 0) === 0)
                   ? 'style="color:#a04040;font-weight:bold;"' : ''}>
          <span> / </span>
          <span class="elysium-armor-hp-max">${ely.apMax ?? 0}</span>
          ${((ely.apMax ?? 0) > 0 && (item.system?.av1 ?? 0) === 0)
            ? '<span class="elysium-armor-broken-badge" style="margin-left:8px;background:#a04040;color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;">BROKEN</span>'
            : ''}
          <button type="button"
                  class="elysium-armor-repair-btn"
                  data-elysium-armor-action="repair"
                  data-item-id="${item.id}"
                  style="margin-left:6px;padding:1px 8px;border-radius:3px;font-size:11px;cursor:pointer;"
                  ${((item.system?.av1 ?? 0) >= (ely.apMax ?? 0)) ? 'disabled' : ''}
                  data-tooltip="Restore 1 AP (up to Max AP).">
            Repair +1
          </button>
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)

    // Worn Modifiers fieldset — list each item-modifier AE as an editable row
    injectItemModifiers(html, item, target)
  }
