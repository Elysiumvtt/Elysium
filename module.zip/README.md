# Elysium — Rules & Mechanics Module

The mechanics layer of the Elysium ruleset for FoundryVTT V14. Adds combat overhauls, the five magic systems, character creation helpers, and many other optional rules — all toggleable via Settings.

## The Elysium Stack

Elysium is split across three packages:

| Repo | Purpose | Manifest URL |
|------|---------|--------------|
| **ElysiumBRP** | Custom BRP system fork — data schema | `https://github.com/Elysiumvtt/ElysiumBRP/releases/latest/download/system.json` |
| **Elysium** (this repo) | Rules & mechanics module | `https://github.com/Elysiumvtt/Elysium/releases/latest/download/module.json` |
| **ElysiumCompendium** | Content (weapons, ancestries, spells, etc.) | `https://github.com/Elysiumvtt/ElysiumCompendium/releases/latest/download/module.json` |

This module works with stock BRP V14 too — it falls back to `flags.elysium.*` when the ElysiumBRP fork isn't installed. For the best experience, install all three.

## What This Module Provides

### Core Combat Extensions
- **Action Points System** — INT+DEX based AP pool refreshed each combat round
- **Wound Threshold System** — Wounded / Severely Wounded / Critically Wounded / Severed
- **Critical Wound Tables** — 1D10 tables for Head / Arm / Body / Leg / Tail-Wing / Aquatic, with automatic condition application; built-in fallback data so it works even before the compendium is loaded
- **Mythras Special Effects** — Differential success-based combat manoeuvres
- **Mythras Healing Rate** — CON-based healing rate (1-5)
- **Mythras Fatigue System** — 10-level fatigue replacing simple exhaustion
- **Armour Layering** — Natural / Flexible / Inflexible layers, AP cap of 10 for worn armour
- **Luck Points** — Mythras-style 2 + POW bonus, full recovery each session

### Five Magic Systems
1. **Arcane (Wizard)** — Schools / Techniques / Forms / Success Levels / MP allocation
2. **Sorcery (Essence)** — 3 primary essences + 1 confluence, ability growth thresholds
3. **Divine / Patron** — Channel skill, domains, patron standing affecting recovery
4. **Mysticism (Ki/Inner)** — Activation rolls only when ability IS the action
5. **Superpowers / Passives** — No-cost conditional or always-on abilities

All five share a single Power Points pool (POW score). Armour casting penalty applies to Arcane and Sorcery; Divine and Mysticism are exempt.

### Character System
- **4D6 drop lowest** stat rolling (default; other methods configurable)
- **EXP Dice** advancement system — gamble (1 die + 3D6 roll) or guaranteed (dice equal to current score)
- **Ancestry System** — drag-drop ancestry items apply stat mods, mutations, natural armour, languages, BP/SP adjustments
- **Subraces and Combination Ancestries** — TP trade-off rules
- **Profession Packages** — 4 primary + 6 secondary + 2 bonus skills, capped at 70% starting skill
- **Custom Profession Builder** — same structure with GM approval

### Vision and Senses
- **Mutations**: Low-Light Vision, Infravision, Darkvision, Superior Darkvision
- **Superpowers**: Blindsight, Truesight

### Creature System
- **20 Primary Types** — Aberration to Vermin plus Astral / Ethereal / Shadow
- **Subtypes** for Humanoid, Fiend, Undead, Dragon, Elemental, Giant, Celestial, Lycanthrope, Vermin
- **Tags** — Shapechanger, Incorporeal, Swarm, Legendary, etc.
- **Favoured Enemy** — Broad / Subtype / Narrow specificity, max 3 selections via tier progression


## Installation

**Recommended order:**

1. Install **ElysiumBRP** system first (use the URL in the table above)
2. Create or load a world using **Elysium BRP** as the system
3. Open the Module Manager → Install Module → paste this manifest URL:
   ```
   https://github.com/Elysiumvtt/Elysium/releases/latest/download/module.json
   ```
4. Optionally install **ElysiumCompendium** for the full content library
5. Enable the module and reload

## Configuration

After enabling, open **Game Settings** → **Elysium**. Most rules can be turned on or off individually:

- Master Enable (top-level toggle)
- Action Points System
- Wound Thresholds
- Critical Wound Tables
- Mythras Fatigue System
- Mythras Healing Rate
- Combat Special Effects
- Armour Layering
- Luck Points
- Each Magic System (Arcane / Sorcery / Divine / Mysticism / Superpowers)
- Armour Casting Penalty
- Overcasting (PP debt becomes HP damage)
- Ancestry System
- Ancestry Terminology (Culture / Ancestry / Race / Species)
- Character Creation Helpers
- Stat Roll Method
- Starting Skill Cap
- EXP Dice Advancement


## API for Macros

The module exposes `game.elysium`:

```javascript
// Roll a stat advancement
game.elysium.creation.gambleStatIncrease(actor, 'str')
game.elysium.creation.guaranteedStatIncrease(actor, 'str')

// Award EXP dice
game.elysium.creation.awardExpDice(actor, 3)

// Increment fatigue
game.elysium.fatigue.increment(actor, 1, 'physical', 'long march')

// Make an effort roll
game.elysium.fatigue.effortRoll(actor, 'strenuous')

// Refresh Luck Points (start of session)
game.elysium.combat.refreshLuckPoints(actor)

// Spend PP (handles overcasting)
game.elysium.magic.spendPP(actor, 5)

// Cast an Arcane spell
game.elysium.magic.castArcane(actor, spell, {
  techniqueSkill: 65,
  formSkill: 70,
  schoolSkill: 55,
  mp: 3,
})
```


## Compatibility

- Works with **ElysiumBRP** (preferred) or **stock BRP V14.2**
- Foundry V14 (verified at 14.360)
- Does not modify BRP or ElysiumBRP system files — extends via flags and hooks


## Status

**v0.1.0** — Complete mechanical framework. All numerical values that need balancing during playtesting are flagged TBD in `module/config/config.mjs` under the `BALANCING` object.
