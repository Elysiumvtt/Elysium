// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { escapeHtml } from '../shared.mjs'

export function injectThemedAbilityFields (html, item) {
    // Bail if this isn't a v0.12.0 themed-bundle ability
    const ely = item.system?.elysium || {}
    const activation = ely.activation || {}
    const benefits   = Array.isArray(ely.benefits)  ? ely.benefits  : []
    const drawbacks  = Array.isArray(ely.drawbacks) ? ely.drawbacks : []
    const addOns     = Array.isArray(ely.addOns)    ? ely.addOns    : []

    const isBundle = (activation.type && activation.type !== 'passive') ||
                     benefits.length > 0 || drawbacks.length > 0 ||
                     addOns.length > 0

    if (!isBundle) return    // pre-v0.12.0 generic ability; nothing to render

    // Find the description tab; fall back to window-content if missing
    // The system fork's ability sheet (templates/item/ability.detail.hbs)
    // uses `.tab.details` for the main mechanical view (Type / Category /
    // Effect / Prerequisites). Append the v0.12.0 panels there, so they
    // sit alongside the existing mechanics blocks. Fall back to
    // `.tab.description` for richer prose tabs and `.window-content` as
    // last resort.
    const target = html.querySelector('.tab.details') ||
                   html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return
    if (target.querySelector('.elysium-themed-ability')) return  // re-render guard

    // Skill % the actor has in this ability. On owned items BRP-base populates
    // `system.value` after deriving from base+xp; for unowned compendium
    // entries, fall back to base+xp directly.
    const skillValue = Number.isFinite(item.system?.value)
      ? Number(item.system.value)
      : (Number(item.system?.base) || 0) + (Number(item.system?.xp) || 0)

    // Owned add-on names. Item-flag scope so it survives item moves.
    const purchased = new Set(item.flags?.['elysium']?.purchasedAddOns || [])

    // Actor context for purchase gates (only meaningful on owned items)
    const actor = item.parent
    const expDiceAvailable = Number(actor?.flags?.['elysium']?.expDice?.available) || 0

    // Build the panel HTML. Render activation, benefits, drawbacks, and
    // the add-on tree grouped by tier.
    const panel = document.createElement('div')
    panel.className = 'elysium-themed-ability'
    panel.innerHTML = `
      ${renderActivationPanel(activation)}
      ${renderBenefitsDrawbacks(benefits, drawbacks)}
      ${renderAddOnTree(addOns, skillValue, expDiceAvailable, purchased, !!actor)}
    `

    target.appendChild(panel)

    // Wire up purchase / refund clicks on the add-on checkboxes
    if (actor) {
      panel.querySelectorAll('.elysium-addon-toggle').forEach(box => {
        box.addEventListener('change', async (ev) => {
          const addOnName = box.dataset.addonName
          const isChecked = box.checked
          await toggleAddOnPurchase(item, addOnName, isChecked, ev)
        })
      })
    }
  }

export function renderActivationPanel (activation) {
    if (!activation || activation.type === 'passive' || !activation.type) return ''

    const ap = Number(activation.actionCost) || 0
    const pp = Number(activation.ppCost) || 0
    const duration = activation.duration || ''
    const endConditions = Array.isArray(activation.endConditions) ? activation.endConditions : []

    // Cost line — only show non-zero parts to avoid clutter
    const costParts = []
    if (ap > 0)            costParts.push(`<strong>${ap}</strong> Action${ap === 1 ? '' : 's'}`)
    if (ap === 0)          costParts.push(`<em>Free Action</em>`)
    if (pp > 0)            costParts.push(`<strong>${pp}</strong> PP`)
    const costLine = costParts.length ? costParts.join(' · ') : '<em>—</em>'

    const endHtml = endConditions.length
      ? `<ul class="elysium-end-conditions">${endConditions.map(c => `<li>${escapeHtml(c)}</li>`).join('')}</ul>`
      : ''

    const typeLabel = activation.type === 'sustained' ? 'Sustained' : 'Triggered'

    return `
      <fieldset class="elysium-activation-panel">
        <legend>Activation — ${typeLabel}</legend>
        <div class="elysium-activation-row"><span class="elysium-act-label">Cost:</span> ${costLine}</div>
        ${duration ? `<div class="elysium-activation-row"><span class="elysium-act-label">Duration:</span> ${escapeHtml(duration)}</div>` : ''}
        ${endConditions.length ? `<div class="elysium-activation-row"><span class="elysium-act-label">Ends on:</span> ${endHtml}</div>` : ''}
      </fieldset>
    `
  }

export function renderBenefitsDrawbacks (benefits, drawbacks) {
    if (benefits.length === 0 && drawbacks.length === 0) return ''

    const renderList = (items, cls) => {
      if (items.length === 0) return ''
      const lis = items.map(it => `<li>${escapeHtml(it.text || '')}</li>`).join('')
      return `<ul class="elysium-bd-list ${cls}">${lis}</ul>`
    }

    return `
      <div class="elysium-benefits-drawbacks">
        ${benefits.length ? `
          <fieldset class="elysium-benefits-panel">
            <legend>Benefits</legend>
            ${renderList(benefits, 'elysium-benefits')}
          </fieldset>` : ''}
        ${drawbacks.length ? `
          <fieldset class="elysium-drawbacks-panel">
            <legend>Drawbacks</legend>
            ${renderList(drawbacks, 'elysium-drawbacks')}
          </fieldset>` : ''}
      </div>
    `
  }

export function renderAddOnTree (addOns, skillValue, expDiceAvailable, purchasedSet, isOwned) {
    if (addOns.length === 0) return ''

    // Bucket by tier so we render them in 50 → 95 order even if the
    // build script wrote them interleaved.
    const tiers = [50, 70, 85, 95]
    const tierLabels = { 50: 'Tier 1', 70: 'Tier 2', 85: 'Tier 3', 95: 'Tier 4' }
    const buckets = Object.fromEntries(tiers.map(t => [t, []]))
    for (const a of addOns) {
      const t = Number(a.requiredSkillPercent) || 50
      ;(buckets[t] || buckets[50]).push(a)
    }

    const sections = tiers.map(tier => {
      const list = buckets[tier]
      if (list.length === 0) return ''

      const thresholdMet = skillValue >= tier
      const tierClass = thresholdMet ? 'elysium-tier-met' : 'elysium-tier-locked'

      const items = list.map(ao => {
        const owned = purchasedSet.has(ao.name)
        const dieCost = Number(ao.xpDiceCost) || 1
        const ppCost  = Number(ao.ppCost) || 0
        const canAfford = expDiceAvailable >= dieCost

        // Checkbox enable rule:
        //   - compendium / unowned: never enabled
        //   - owned + already purchased: enabled (lets user refund)
        //   - owned + not purchased + threshold met + can afford: enabled
        //   - otherwise: disabled
        const enabled = isOwned && (owned || (thresholdMet && canAfford))
        const disabledAttr = enabled ? '' : 'disabled'
        const checkedAttr  = owned ? 'checked' : ''

        // Why disabled? for the tooltip.
        let disabledReason = ''
        if (!isOwned)             disabledReason = 'Compendium preview — purchase available on owned items.'
        else if (!thresholdMet)   disabledReason = `Requires ${tier}% in this ability (you have ${skillValue}%).`
        else if (!canAfford)      disabledReason = `Requires ${dieCost} EXP dice (you have ${expDiceAvailable}).`

        const ppNote = ppCost > 0 ? ` · <em>${ppCost} PP/use</em>` : ''

        return `
          <div class="elysium-addon ${owned ? 'elysium-addon-owned' : ''}">
            <label class="elysium-addon-header"
                   ${disabledReason ? `data-tooltip="${escapeHtml(disabledReason)}"` : ''}>
              <input type="checkbox" class="elysium-addon-toggle"
                     data-addon-name="${escapeHtml(ao.name)}"
                     data-die-cost="${dieCost}"
                     data-tier="${tier}"
                     ${checkedAttr} ${disabledAttr}>
              <span class="elysium-addon-name">${escapeHtml(ao.name)}</span>
              <span class="elysium-addon-cost">${dieCost} EXP ${dieCost === 1 ? 'die' : 'dice'}${ppNote}</span>
            </label>
            <div class="elysium-addon-desc">${escapeHtml(ao.description || '')}</div>
          </div>
        `
      }).join('')

      const tierHeader = thresholdMet
        ? `${tierLabels[tier]} (${tier}%) — <span class="elysium-tier-status">unlocked</span>`
        : `${tierLabels[tier]} (${tier}%) — <span class="elysium-tier-status">locked</span>`

      return `
        <fieldset class="elysium-addon-tier ${tierClass}">
          <legend>${tierHeader}</legend>
          ${items}
        </fieldset>
      `
    }).join('')

    const poolLine = isOwned
      ? `<div class="elysium-addon-pool"><strong>EXP Dice Available:</strong> ${expDiceAvailable} · <strong>Skill:</strong> ${skillValue}%</div>`
      : `<div class="elysium-addon-pool"><em>Compendium preview — purchase UI disabled.</em></div>`

    return `
      <div class="elysium-addon-tree">
        <h3 class="elysium-section-h">Add-ons</h3>
        ${poolLine}
        ${sections}
      </div>
    `
  }

export async function toggleAddOnPurchase (item, addOnName, shouldOwn, ev) {
    const actor = item.parent
    if (!actor) return    // sanity — UI shouldn't have offered the toggle

    const ely = item.system?.elysium || {}
    const addOn = (ely.addOns || []).find(a => a.name === addOnName)
    if (!addOn) {
      ui.notifications?.error(`Add-on '${addOnName}' not found on this ability.`)
      ev.target.checked = !shouldOwn
      return
    }

    const owned = new Set(item.flags?.['elysium']?.purchasedAddOns || [])
    const dieCost = Number(addOn.xpDiceCost) || 1
    const tier    = Number(addOn.requiredSkillPercent) || 50
    const skillValue = Number.isFinite(item.system?.value)
      ? Number(item.system.value)
      : (Number(item.system?.base) || 0) + (Number(item.system?.xp) || 0)
    const expFlag = actor.system?.elysium?.expDice ?? {}
    const expAvailable = Number(expFlag.available) || 0

    if (shouldOwn) {
      // Purchase
      if (owned.has(addOnName)) return    // already owned — no-op
      if (skillValue < tier) {
        ui.notifications?.warn(`${addOnName}: requires ${tier}% (you have ${skillValue}%).`)
        ev.target.checked = false
        return
      }
      if (expAvailable < dieCost) {
        ui.notifications?.warn(`${addOnName}: requires ${dieCost} EXP dice (you have ${expAvailable}).`)
        ev.target.checked = false
        return
      }
      owned.add(addOnName)
      try {
        await item.update({
          'flags.elysium.purchasedAddOns': Array.from(owned),
        })
        await actor.update({
          'system.elysium.expDice.available': expAvailable - dieCost,
        })
        ui.notifications?.info(`Purchased ${addOnName} (-${dieCost} EXP ${dieCost === 1 ? 'die' : 'dice'}).`)
      } catch (err) {
        console.error('Elysium | add-on purchase failed:', err)
        ev.target.checked = false
      }
    } else {
      // Refund
      if (!owned.has(addOnName)) return    // wasn't owned — no-op
      owned.delete(addOnName)
      try {
        await item.update({
          'flags.elysium.purchasedAddOns': Array.from(owned),
        })
        await actor.update({
          'system.elysium.expDice.available': expAvailable + dieCost,
        })
        ui.notifications?.info(`Refunded ${addOnName} (+${dieCost} EXP ${dieCost === 1 ? 'die' : 'dice'}).`)
      } catch (err) {
        console.error('Elysium | add-on refund failed:', err)
        ev.target.checked = true
      }
    }
  }
