const { api, sheets } = foundry.applications;
import { ElysiumIDEditor } from '../../elysiumid/elysiumid-editor.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumRollType } from '../../apps/rollType.mjs'
import { ElysiumActorItemDrop } from '../actor-itemDrop.mjs'
import { ElysiumDamage } from '../../combat/damage.mjs'
import { ElysiumUtilities } from '../../apps/utilities.mjs'
import ElysiumDialog from '../../setup/elysium-dialog.mjs';
import { ElysiumActor } from '../actor.mjs'
import { isCtrlKey } from '../../apps/helper.mjs'
import { ElysiumCharDev } from '../../apps/charDev.mjs'
// v0.9.0 casting integration
import { beginArcaneCast, spendCastAP, abandonCast } from '../../casting/arcane-cast.mjs'
import { castDivine } from '../../casting/divine-cast.mjs'
import { castSorcery } from '../../casting/sorcery-cast.mjs'
import { castMysticism } from '../../casting/mysticism-cast.mjs'
import { refundPP } from '../../casting/cast-shared.mjs'// v0.16.0 custom spell builder
import { CustomSpellBuilder } from '../../casting/custom-spell-builder.mjs'
export class ElysiumActorSheetV2 extends api.HandlebarsApplicationMixin(sheets.ActorSheetV2) {
  constructor(options = {}) {
    super(options);
    this._dragDrop = this._createDragDropHandlers();
  }

  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'sheet', 'actor'],
    position: {
      width: 587,
      height: 800
    },
    window: {
      resizable: true,
    },
    tag: "form",
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: null }],
    form: {
      handler: ElysiumActorSheetV2._updateObject,
      submitOnChange: true,
    },
    actions: {
      onEditImage: this._onEditImage,
      editElysiumID: this._onEditElysiumID,
      actorToggle: this._onActorToggle,
      itemToggle: this._onItemToggle,
      rollStats: this._onRollStats,
      rollCharStats: this._onRollCharStats,
      skillRoll: this._onSkillRoll,
      statRoll: this._onStatRoll,
      weaponRoll: this._onWeaponRoll,
      damageRoll: this._onDamageRoll,
      armorRoll: this._onArmorRoll,
      passionRoll: this._onPassionRoll,
      allegianceRoll: this._onAllegianceRoll,
      personalityRoll: this._onPersTraitRoll,
      reputationRoll: this._onReputationRoll,
      viewDoc: this._viewDoc,
      deleteDoc: this._deleteDoc,
      createDoc: this._onItemCreate,
      hplHeal: this._onHPLHeal,
      deleteCulture: this._deleteCulture,
      deleteCareer: this._deleteCareer,
      deletePersonality: this._deletePersonality,
      addDamage: this._addDamage,
      healWound: this._healWound,
      attribute: this._onAttribute,
      restoreFatigue: this._onRestoreFatigue,
      restorePower: this._onRestorePower,
      skillCalc: this._onSkillCalc,
      treatWound: this._treatWound,
      viewWound: this._viewWound,
      healing: this._onHealing,
      armorToggle: this._onArmorToggle,
      armorLocToggle: this._onArmorLocToggle,
      impactRoll: this._onImpactRoll,
      redistStat: this._onRedisttibuteStats,
      xpRolls: this._onXPRolls,
      powImprove: this._onPowImprove,
      // v0.9.0 casting actions
      castArcane:    this._onCastArcane,
      castDivine:    this._onCastDivine,
      castSorcery:   this._onCastSorcery,
      castMysticism: this._onCastMysticism,
      castSpendAP:   this._onCastSpendAP,
      castAbandon:   this._onCastAbandon,
      castUndoPP:    this._onCastUndoPP,
      // v0.10.0
      dropSustain:   this._onDropSustain,
      // v0.11.0 — characteristic improvement
      statImproveToggle: this._onStatImproveToggle,
      rollAllImprovements: this._onRollAllImprovements,
      // v0.16.0 — custom spell builder
      castCustomSpell: this._onCastCustomSpell,
      // P8 — actor sheet shell actions (alpha.14)
      rollVisibility:    this._onRollVisibility,
      difficultySet:     this._onDifficultySet,
      apRefresh:         this._onAPRefresh,
      apEdit:            this._onAPEdit,
      ppRefresh:         this._onPPRefresh,
      ppEdit:            this._onPPEdit,
      restStub:          this._onRestStub,
      skillImproveToggle: this._onSkillImproveToggle,
      effectCreate:      this._onEffectCreate,
      effectEdit:        this._onEffectEdit,
      effectToggle:      this._onEffectToggle,
      effectDelete:      this._onEffectDelete,
    }
  }

  //Add ElysiumID Editor Button as seperate icon on the Window header
  async _renderFrame(options) {
    const frame = await super._renderFrame(options);
    //define button
    const sheetElysiumID = this.actor.flags?.elysium?.elysiumidFlag;
    const noId = (typeof sheetElysiumID === 'undefined' || typeof sheetElysiumID.id === 'undefined' || sheetElysiumID.id === '');
    //add button
    const label = game.i18n.localize("Elysium.ElysiumIDFlag.id");
    const elysiumidEditor = `<button type="button" class="header-control icon fa-solid fa-fingerprint ${noId ? 'edit-elysiumid-warning' : 'edit-elysiumid-exisiting'}"
        data-action="editElysiumID" data-tooltip="${label}" aria-label="${label}"></button>`;
    let el = this.window.close;
    while (el.previousElementSibling.localName === 'button') {
      el = el.previousElementSibling;
    }
    el.insertAdjacentHTML("beforebegin", elysiumidEditor);
    return frame;
  }

  async _prepareContext(options) {
    return {
      editable: this.isEditable,
      owner: this.document.isOwner,
      limited: this.document.limited,
      actor: this.actor,
      flags: this.actor.flags,
      isGM: game.user.isGM,
      fields: this.document.schema.fields,
      config: CONFIG.Elysium,
      system: this.actor.system,
      isLocked: this.actor.system.lock,
      isLinked: this.actor.prototypeToken?.actorLink === true,
      isSynth: this.actor.isToken,
      // v0.20.0: useEDU/useFP/useHPL/useAlleg/usePassion/useBeastiary context
      // flags removed — their template branches were unconditional and have
      // been unwrapped/deleted in the templates. useSAN/useRes5/useAVRand/
      // useReputation are real settings and still flow through.
      useSAN: game.settings.get('elysium', 'useSAN'),
      useRes5: game.settings.get('elysium', 'useRes5'),
      useAVRand: game.settings.get('elysium', 'useAVRand'),
      useReputation: game.settings.get('elysium', 'useReputation'),
      statOptions: await ElysiumSelectLists.addStatOptions(""),
    };
  }

  //---------------ACTIONS-------------

  // Change Image
  static async _onEditImage(event, target) {
    const attr = target.dataset.edit;
    const current = foundry.utils.getProperty(this.document, attr);
    const { img } = this.document.constructor.getDefaultArtwork?.(this.document.toObject()) ??
      {};
    const fp = new foundry.applications.apps.FilePicker({
      current,
      type: 'image',
      redirectToRoot: img ? [img] : [],
      callback: (path) => {
        this.document.update({ [attr]: path });
      },
      top: this.position.top + 39,
      left: this.position.left + 9,
    });
    return fp.browse();
  }

  // Handle editElysiumID action
  static _onEditElysiumID(event, target) {
    event.stopPropagation(); // Don't trigger other events
    if (event.detail > 1) return; // Ignore repeated clicks
    new ElysiumIDEditor({ document: this.document }, {}).render(true, { focus: true })
  }

  // Handle creating a new Owned Item for the actor using initial data defined in the HTML dataset
  static async _onItemCreate(event, target) {
    event.preventDefault();
    const docCls = getDocumentClass(target.dataset.documentClass);
    const docData = {
      name: docCls.defaultName({
        type: target.dataset.type,
        parent: this.actor,
      }),
    };
    // Loop through the dataset and add it to our docData
    for (const [dataKey, value] of Object.entries(target.dataset)) {
      // Ignore data attributes that are reserved for action handling
      if (['action', 'documentClass'].includes(dataKey)) continue;
      foundry.utils.setProperty(docData, dataKey, value);
    }

    // Create the embedded document
    const newItem = await docCls.create(docData, { parent: this.actor });
    const key = await game.system.api.elysiumid.guessId(newItem)
    await newItem.update({
      'flags.elysium.elysiumidFlag.id': key,
      'flags.elysium.elysiumidFlag.lang': game.i18n.lang,
      'flags.elysium.elysiumidFlag.priority': 0
    })

    //And in certain circumstances render the new item sheet
    if (docData.type === 'hit-location') {
      await newItem.update({
        'system.displayName': newItem.name
      })
    }

    //And in certain circumstances render the new item sheet
    if (!['wound'].includes(docData.type)) {
      newItem.sheet.render(true);
    }
  }

  //Toggle Actor
  static async _onActorToggle(event, target) {
    const prop = target.dataset.property;
    let checkProp = {};
    let checkVal = ""
    if (['lock','showNotes','skillOrder'].includes(prop)) {
      checkProp = { [`system.${prop}`]: !this.actor.system[prop] }
    } else     if (['strdb'].includes(prop)) {
      checkProp = { [`system.mod.${prop}`]: !this.actor.system.mod[prop] }
    } else if (['viewTab'].includes(prop)) {
      checkVal = target.dataset.tabval;
      checkProp = { [`system.${prop}`]: checkVal }
    }  else if (prop === 'powimprove') {
      checkProp = { 'system.stats.pow.improve': !this.actor.system.stats.pow.improve }
    } else if (prop === 'minorWnd') {
      checkProp = {
        'system.minorWnd': !this.actor.system.minorWnd,
        'system.health.daily': 0
      }
    } else if (prop === 'majorWnd') {
      checkProp = {
        'system.majorWnd': !this.actor.system.majorWnd,
        'system.health.daily': 0
      }
    } else {
      return
    }
    await this.actor.update(checkProp);
    return
  }

  //Roll Stats for NPC
  static async _onRollStats(event, target) {
    const type = target.dataset.property;
    for (let [key, stat] of Object.entries(this.actor.system.baseStats)) {
      let rollForm = stat.average
      if (type === 'random') {
        rollForm = stat.random
      }
      let checkProp = ""
      if (rollForm === "") {
        checkProp = { [`system.stats.${key}.base`]: 0 }
      } else {
        const roll = new Roll(rollForm)
        await roll.evaluate()
        const newVal = Math.round(Number(roll.total))
        checkProp = { [`system.stats.${key}.base`]: newVal }
      }
      await this.actor.update(checkProp)
      //Update Current HP etc to max (v0.20.0: fatigue.value/max not used)
      checkProp = {
        'system.health.value': this.actor.system.health.max,
        'system.power.value': this.actor.system.power.max,
        'system.sanity.value': this.actor.system.sanity.max
      }
      await this.actor.update(checkProp)
    }

    //If using HPL set location Current HP to Max HP
    await ElysiumActorSheetV2._resetHPL(this.actor)
  }

  //Roll Character Stats
  static async _onRollCharStats(event, target) {
    const confirmation = await ElysiumUtilities.confirmation('rollStats', 'chatMsg');
    if (!confirmation) { return }
    const results = []
    for (let [key, stat] of Object.entries(this.actor.system.stats)) {
      let checkProp = ""
      if (stat.formula === "") { continue }
      if (key === 'edu' && !false) { continue }
      const roll = new Roll(stat.formula)
      await roll.evaluate()
      const newVal = Math.round(Number(roll.total))
      checkProp = { [`system.stats.${key}.base`]: newVal }
      let diceRolled = ""
      for (let diceRoll of roll.dice) {
        for (let diceResult of diceRoll.results) {
          if (diceRolled === "") {
            diceRolled = diceResult.result
          } else {
            diceRolled = diceRolled + "," + diceResult.result
          }
        }
      }
      results.push({ label: stat.labelShort, result: newVal, formula: roll.formula, diceRolled: diceRolled })
      await this.actor.update(checkProp)
      if (game.modules.get('dice-so-nice')?.active) {
        game.dice3d.showForRoll(roll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
      }
    }
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this.actor.name }),
      actrImage: this.actor.img,
      results: results
    }
    const messageTemplate = 'systems/elysium/templates/chat/rollStats.html'
    const html = await foundry.applications.handlebars.renderTemplate(messageTemplate, messageData);

    // F15 (rc.7): legacy `type: CONST.CHAT_MESSAGE_STYLES.OTHER` retired here too.
    // See charDev.mjs:showXPChat for full rationale.
    const chatData = {
      user: game.user.id,
      content: html,
      speaker: {
        actor: this.actor._id,
        alias: this.actor.name,
      },
    }
    const msg = await ChatMessage.create(chatData);
    return
  }

  //Stat Roll
  static _onStatRoll(event, target) {
    ElysiumRollType._onStatRoll(event, target.dataset, this.document)
  }

  //Skill Roll
  static _onSkillRoll(event, target) {
    ElysiumRollType._onSkillRoll(event, target.dataset, this.document)
  }

  //Weapon Roll
  static _onWeaponRoll(event, target) {
    ElysiumRollType._onWeaponRoll(event, target.dataset, this.document)
  }

  //Damage Roll
  static _onDamageRoll(event, target) {
    ElysiumRollType._onDamageRoll(event, target.dataset, this.document)
  }

  //Armor Roll
  static _onArmorRoll(event, target) {
    ElysiumRollType._onArmor(event, target.dataset, this.document)
  }

  //Passion Roll
  static _onPassionRoll(event, target) {
    ElysiumRollType._onPassionRoll(event, target.dataset, this.document)
  }

  //Allegiance Roll
  static _onAllegianceRoll(event, target) {
    ElysiumRollType._onAllegianceRoll(event, target.dataset, this.document)
  }

  //Personality Trait Roll
  static _onPersTraitRoll(event, target) {
    ElysiumRollType._onPersTraitRoll(event, target.dataset, this.document)
  }

  //Reputation Trait Roll
  static _onReputationRoll(event, target) {
    ElysiumRollType._onReputationRoll(event, target.dataset, this.document)
  }

  //Magic Spell Impact Roll
  static async _onImpactRoll(event, target) {
    await ElysiumRollType._onImpactRoll(event, target.dataset, this.document)
  }

  //Resest HPL Action
  static async _onHPLHeal (event, target) {
    await ElysiumActorSheetV2._resetHPL(this.actor)
  }

  //Delete Culture
  static async _deleteCulture (event, target) {
    await ElysiumActorItemDrop.cultureDelete(event, this.actor)
  }

  //Delete Career
  static async _deleteCareer (event, target) {
    await ElysiumActorItemDrop.careerDelete(event, this.actor)
  }

  //Delete Personality
  static async _deletePersonality (event, target) {
    await ElysiumActorItemDrop.personalityDelete(event, this.actor)
  }

  //Add Damage
  static async _addDamage(event, target) {
    await ElysiumDamage.addDamage(target,this.actor, this.token, 0)
  }

  //Heal a Wound
  static async _healWound(event, target) {
    await ElysiumDamage.treatWound(event, this.actor)
  }

  //Restore All Fatigue
  static async _onRestoreFatigue (event, target) {
    if (event.detail === 2) {  //Only perform on double click
      await ElysiumUtilities.updateAttribute(this.actor, this.token, "fatigue", "restore")
    }
  }

  //Restore All Power
  static async _onRestorePower (event, target) {
    if (event.detail === 2) {  //Only perform on double click
      await ElysiumUtilities.updateAttribute(this.actor, this.token, "power", "restore")
    }
  }

  //Start Attribute modify
  static async _onAttribute(event, target) {
    const att = target.dataset.att
    const adj = target.dataset.adj
    let checkprop = ""
    const newVal = this.actor.system[att].value
    const newMax = this.actor.system[att].max
    if (adj === 'spend') {
      checkprop = { [`system.${att}.value`]: newVal - 1 }
    } else if (adj === 'recover' && newVal < newMax) {
      checkprop = { [`system.${att}.value`]: newVal + 1 }
    } else { return }

    this.actor.update(checkprop)
  }

  //Recalculate Skill Base Scores
  static async _onSkillCalc(event, target) {
    await ElysiumActor.charBaseSkillScores(this.actor);
  }

  //Item Toggle
  static async _onItemToggle(event, target) {
    const element = target;
    // P9 cluster 3 (alpha.33): widened from `closest("li")` to
    // `closest("[data-item-id]")`. New v1.0.0 row partials use <div>
    // not <li> for row containers; the legacy lookup returned null
    // and silently dropped the toggle. The wider selector covers
    // both legacy <li class="item"> and new <div data-item-id>.
    const li = target.closest("[data-item-id]");
    const item = this.actor.items.get(li.dataset.itemId);
    const prop = element.dataset.property;
    let checkProp = {};
    if (['hide', 'improve', 'oppimprove', 'mem', 'injured', 'bleeding', 'incapacitated', 'severed', 'dead', 'unconscious'].includes(prop)) {
      checkProp = { [`system.${prop}`]: !item.system[prop] }
    } else if (prop === 'equipStatus') {
      // Elysium fork: binary equipped/stowed (was worn/carried/packed/stored)
      if (item.system.equipStatus === 'equipped') {
        checkProp = { 'system.equipStatus': "stowed" }
      } else {
        checkProp = { 'system.equipStatus': "equipped" }
      }
    } else { return }

    await item.update(checkProp);
    this.actor.render(false);
    return;
  }

  static async _resetHPL(actor) {
    if (true || true) {
      const hitLocs = actor.items.filter(itm => itm.type === 'hit-location').map(itm => {
        return { _id: itm.id, 'system.currHP': itm.system.maxHP }
      })
      await Item.updateDocuments(hitLocs, { parent: actor })
    }
  }

  // View Embedded Document (CTRL+click to delete)
  static async _viewDoc(event, target) {
    const doc = this._getEmbeddedDocument(target);
    if (!doc) {return}
    const ctrlKey = isCtrlKey(event ?? false);
    if (!target.classList.contains('improvtab')) {
      if (ctrlKey) {
        if (!['career','culture','personality'].includes(doc.type)) {
          const confirmation = await ElysiumDialog.confirm({
            window: { title: game.i18n.localize("Elysium.deleteItem") },
            content: game.i18n.localize("Elysium.deleteConfirm") + "<br><strong> " + doc.name + "</strong>"
          })
          if (confirmation) {
            await doc.delete();
          }
          return
        }
      }
    }
    if (event.altKey) {
      if (['arcane','divine','mysticism','sorcery','mutation','super','failing'].includes(doc.type)) {
        ElysiumUtilities.sendToChat(event, this.document, "itemId")
        return
      }
    }
    doc.sheet.render(true);
  }

  //Delete Embedded Document
  static async _deleteDoc(event, target) {
    if (event.detail === 2) {  //Only perform on double click
      const doc = this._getEmbeddedDocument(target);
      await doc.delete();
    }
  }

  //Get Embedded Document
  _getEmbeddedDocument(target) {
    // P9 cluster 3 hotfix (alpha.34): widened from
    // `closest('li[data-document-class]')` to
    // `closest('[data-document-class]')`. New v1.0.0 row partials
    // (weapon-row, armor-row, hit-location-row, gear-row, allegiance-row,
    // reputation-row, passion-row, pers-trait-row, mutation-row, dev-row,
    // and per-armor-layer rows inside the defenses card) use `<div>`
    // not `<li>` for row containers. The legacy `closest('li[...]')`
    // returned null on these and fell through to the warning branch,
    // silently breaking viewDoc / deleteDoc clicks across every
    // rebuilt tab and the defenses-card armor-layer rows. The widened
    // selector covers both legacy `<li class="item">` and new
    // `<div data-item-id data-document-class>` rows. Same root cause
    // as the alpha.33 itemToggle widening.
    let docRow = target.closest('[data-document-class]');
    if (!docRow) {docRow = target}
    if (docRow.dataset.documentClass === 'Item') {
      return this.actor.items.get(docRow.dataset.itemId);
    } else if (docRow.dataset.documentClass === 'ActiveEffect') {
      const parent =
        docRow.dataset.parentId === this.actor.id
          ? this.actor
          : this.actor.items.get(docRow?.dataset.parentId);
      return parent.effects.get(docRow?.dataset.effectId);
    } else return console.warn('Could not find document class');
  }

  //Treat a Wound
  static async _treatWound(event, target) {
    const treatType = target.dataset.healing
    await ElysiumDamage.treatWound(event, this.actor, "itemId", treatType);
  }

  //View Wound
  static async _viewWound(event, target) {
    const hitloc = this.actor.items.get(target.dataset.itemId);
    const wound = this.actor.items.get(target.dataset.woundId)
    const ctrlKey = isCtrlKey(event ?? false);
    if (ctrlKey) {
      const confirmation = await ElysiumDialog.confirm({
        window: { title: game.i18n.localize("Elysium.deleteItem") },
        content: game.i18n.localize("Elysium.deleteConfirm") + "<br><strong> " + wound.name + "</strong>"
       })
      if (confirmation) {
        await wound.delete();
      }
      return
    } else if (event.altKey) {
      await ElysiumDamage.treatWound(event, this.actor, "woundId", "")
      return
    }
    wound.sheet.render(true);
  }

  //Healing Options
  static async _onHealing (event, target) {
    const prop = target.dataset.prop
    if (!prop) return
    switch (prop) {
      case 'natural':
        ElysiumDamage.naturalHeal(event, this.actor)
        break;
      case 'all':
        ElysiumDamage.allHeal(event, this.actor)
        break;
      case 'reset':
        ElysiumDamage.resetDaily(event, this.actor)
        break;
    }
  }

  //Collapse/Expand Armor on all Hit Locs
  static async _onArmorToggle(event, target) {
    if (!true) { return }
    const expand = event.shiftKey
    const changes = []
    const hitLocs = this.actor.items.filter(itm => itm.type === "hit-location").map(itm => {
      return { id: itm.id }
    })
    for (let hitLoc of hitLocs) {
      changes.push({
        _id: hitLoc.id,
        'system.hide': expand
      })
    }
    await Item.updateDocuments(changes, { parent: this.actor });
  }

  //Collaspe expand armor on hit locations
  static async _onArmorLocToggle(event, target) {
    if (!true) { return }
    const hitLocId = target.dataset.itemId
    const hitLoc = this.actor.items.get(hitLocId)
    await hitLoc.update({'system.hide': !hitLoc.system.hide})
  }

  //Redistribute Characteristics
  static async _onRedisttibuteStats(event, target) {
    const key = target.dataset.stat
    const change = target.dataset.type
    let checkProp = ""
    if (change === 'decrease') {
      //If at maximum redistribute points
      if (this.actor.system.redistDec <= -3 && this.actor.system.stats[key].redist <= 0) { return }
      //Don't go below min stat values
      if ((this.actor.system.stats[key].base + this.actor.system.stats[key].redist) === 3) { return }
      if (['int', 'siz'].includes(key) && ((this.actor.system.stats[key].base + this.actor.system.stats[key].redist) === 8)) { return }
      checkProp = { [`system.stats.${key}.redist`]: this.actor.system.stats[key].redist - 1 }
    }
    if (change === 'increase') {
      //If at maximum redistribute points
      if (this.actor.system.redistInc >= 3 && this.actor.system.stats[key].redist >= 0) { return }
      //Don't exceed 21 stat value
      if ((this.actor.system.stats[key].base + this.actor.system.stats[key].redist) === 21) { return }
      checkProp = { [`system.stats.${key}.redist`]: this.actor.system.stats[key].redist + 1 }
    }
    await this.actor.update(checkProp)
  }

  //Make Single XP Improvement Roll
  static async _onXPRolls(event, target) {
    const rollType = target.dataset.roll
    const improveType = target.dataset.prop
    if (improveType === 'all') {
      await ElysiumCharDev.onXPGainAll(this.document, this.document.token, rollType)
    } else {
      // F13 (rc.6): character.dev.hbs uses .elysium-dev-row wrappers carrying
      // both data-item-id and data-opp. The clicked <a data-action="xpRolls">
      // carries data-roll and data-prop but no id. Walk up using attribute
      // selector to find the row wrapper.
      const li = event.target.closest('[data-item-id]')
      if (!li) {
        console.warn('Elysium | _onXPRolls: no [data-item-id] wrapper found')
        return
      }
      const opp = li.dataset.opp
      const itemId = li.dataset.itemId
      await ElysiumCharDev.onXPGainSingle(itemId, this.document, this.document.token, rollType, opp)
    }
  }

  //POW Improvement Roll
  static async _onPowImprove(event, target) {
    const type = target.dataset.roll
    await ElysiumCharDev.powImprov(this.document, this.document.token, type)
  }

  // v0.11.0 — Characteristic improvement
  // Click: mark for improvement (or unmark if already marked).
  // Shift+Click: roll improvement immediately (3d6 over current stat).
  // At cap: posts GM-approval chat card instead of toggling.
  static async _onStatImproveToggle(event, target) {
    event?.preventDefault?.()
    const statKey = target?.dataset?.statKey
    if (!statKey) return
    const api = game.system.api?.elysium
    if (!api?.statImprovement) {
      ui.notifications?.error('Elysium subsystem not loaded.')
      return
    }
    if (event?.shiftKey) {
      await api.statImprovement.rollImprovement(this.document, statKey)
    } else {
      await api.statImprovement.markForImprovement(this.document, statKey)
    }
  }

  static async _onRollAllImprovements(event, target) {
    event?.preventDefault?.()
    const api = game.system.api?.elysium
    if (!api?.statImprovement) {
      ui.notifications?.error('Elysium subsystem not loaded.')
      return
    }
    await api.statImprovement.rollAllMarkedImprovements(this.document)
  }

  // ============================================================
  // v0.9.0 — Casting integration
  // ============================================================

  /**
   * Resolve the spell item from the click target. Spell rows carry
   * data-item-id on their <li>. The Cast button is a child of the row.
   */
  static _spellFromTarget(target, actor) {
    const row = target.closest('[data-item-id]')
    const id = row?.dataset?.itemId ?? target?.dataset?.itemId
    if (!id) return null
    return actor.items.get(id) ?? null
  }

  // Begin an Arcane cast (opens the active-cast slot, posts in-progress card).
  static async _onCastArcane(event, target) {
    event?.preventDefault?.()
    const spell = this.constructor._spellFromTarget(target, this.document)
    if (!spell) return
    await beginArcaneCast(this.document, spell)
  }

  // v0.16.0: Cast Custom — opens the live spell builder for the actor.
  // The builder creates a real spell item, casts it, and prompts the
  // player to keep or discard the spell after resolution.
  static async _onCastCustomSpell(event, _target) {
    event?.preventDefault?.()
    await CustomSpellBuilder.open(this.document)
  }

  // One-shot Divine cast.
  static async _onCastDivine(event, target) {
    event?.preventDefault?.()
    const spell = this.constructor._spellFromTarget(target, this.document)
    if (!spell) return
    await castDivine(this.document, spell)
  }

  // One-shot Sorcery cast.
  static async _onCastSorcery(event, target) {
    event?.preventDefault?.()
    const spell = this.constructor._spellFromTarget(target, this.document)
    if (!spell) return
    await castSorcery(this.document, spell)
  }

  // One-shot Mysticism cast.
  static async _onCastMysticism(event, target) {
    event?.preventDefault?.()
    const feat = this.constructor._spellFromTarget(target, this.document)
    if (!feat) return
    await castMysticism(this.document, feat)
  }

  // Spend 1 AP to advance an in-progress Arcane cast.
  // Triggered from a button on the in-progress chat card OR from a
  // small "Spend AP" button on the actor sheet (when active cast set).
  static async _onCastSpendAP(event, target) {
    event?.preventDefault?.()
    await spendCastAP(this.document)
  }

  // Abandon an in-progress Arcane cast.
  static async _onCastAbandon(event, target) {
    event?.preventDefault?.()
    await abandonCast(this.document)
  }

  // Refund PP from a completed cast (Undo button on chat card).
  // The button passes the PP amount via data-pp-amount.
  static async _onCastUndoPP(event, target) {
    event?.preventDefault?.()
    const amount = Number(target?.dataset?.ppAmount ?? 0)
    if (!amount) return
    await refundPP(this.document, amount)
    ui.notifications?.info(`Refunded ${amount} PP to ${this.document.name}.`)
  }

  // v0.10.0: voluntarily end an active sustained spell.
  static async _onDropSustain(event, target) {
    event?.preventDefault?.()
    const spellId = target?.dataset?.spellId
    if (!spellId) return
    const api = game.system.api?.casting
    if (!api?.removeSustain) return
    await api.removeSustain(this.document, spellId, 'released by caster')
    this.render()
  }

  // ==========================================================================
  // P8 — Actor sheet shell action handlers (alpha.14)
  // ==========================================================================

  /** Set the roll-visibility flag (Public/GM) on the header strip. */
  static async _onRollVisibility(event, target) {
    event?.preventDefault?.()
    const value = target?.dataset?.value
    if (!value) return
    await this.actor.setFlag('elysium', 'headerRollVisibility', value)
    this.render()
  }

  /** Set the difficulty flag (veryEasy ... impossible) on the header strip. */
  static async _onDifficultySet(event, target) {
    event?.preventDefault?.()
    const value = target?.dataset?.value
    if (!value) return
    await this.actor.setFlag('elysium', 'headerDifficulty', value)
    this.render()
  }

  /** Refresh an AP pool to its max. Pool = general | react | attack | defense. */
  static async _onAPRefresh(event, target) {
    event?.preventDefault?.()
    const pool = target?.dataset?.pool || 'general'
    const ap = this.actor.system.actionPoints ?? {}
    const update = {}
    if (pool === 'general') update['system.actionPoints.value']        = ap.max ?? 0
    if (pool === 'react')   update['system.actionPoints.reactValue']   = ap.reactMax ?? 0
    if (pool === 'attack')  update['system.actionPoints.attackValue']  = ap.attackMax ?? 0
    if (pool === 'defense') update['system.actionPoints.defenseValue'] = ap.defenseMax ?? 0
    await this.actor.update(update)
  }

  /** Edit the General AP value via a prompt. */
  static async _onAPEdit(event, target) {
    event?.preventDefault?.()
    const ap = this.actor.system.actionPoints ?? {}
    const current = ap.value ?? 0
    const max = ap.max ?? 0
    const input = await new Promise(resolve => {
      const dialog = new foundry.applications.api.DialogV2({
        window: { title: 'Edit General AP' },
        content: `<p>Set current General AP value (0–${max}):</p>
                  <input type="number" name="apValue" value="${current}" min="0" max="${max}" style="width:100%; margin-top:8px;">`,
        buttons: [
          {
            action: 'set',
            label: 'Set',
            default: true,
            callback: (event, button) => {
              const v = parseInt(button.form.elements.apValue.value, 10)
              return isNaN(v) ? null : Math.max(0, Math.min(max, v))
            }
          },
          { action: 'cancel', label: 'Cancel', callback: () => null }
        ],
        submit: (result) => resolve(result),
      })
      dialog.render(true)
    })
    if (input === null || input === undefined) return
    await this.actor.update({ 'system.actionPoints.value': input })
  }

  /** Refresh PP to max. */
  static async _onPPRefresh(event, target) {
    event?.preventDefault?.()
    const derived = this.actor.flags?.elysium?.derived ?? {}
    const max = derived.powerPoints?.max ?? derived.powerPointsMax ?? 0
    await this.actor.setFlag('elysium', 'derived.powerPoints', {
      value: max,
      max,
    })
  }

  /** Edit PP value via prompt. */
  static async _onPPEdit(event, target) {
    event?.preventDefault?.()
    const derived = this.actor.flags?.elysium?.derived ?? {}
    const pp = derived.powerPoints ?? { value: 0, max: derived.powerPointsMax ?? 0 }
    const current = pp.value ?? 0
    const max = pp.max ?? 0
    const input = await new Promise(resolve => {
      const dialog = new foundry.applications.api.DialogV2({
        window: { title: 'Edit Power Points' },
        content: `<p>Set current PP value (0–${max}):</p>
                  <input type="number" name="ppValue" value="${current}" min="0" max="${max}" style="width:100%; margin-top:8px;">`,
        buttons: [
          {
            action: 'set',
            label: 'Set',
            default: true,
            callback: (event, button) => {
              const v = parseInt(button.form.elements.ppValue.value, 10)
              return isNaN(v) ? null : Math.max(0, Math.min(max, v))
            }
          },
          { action: 'cancel', label: 'Cancel', callback: () => null }
        ],
        submit: (result) => resolve(result),
      })
      dialog.render(true)
    })
    if (input === null || input === undefined) return
    await this.actor.setFlag('elysium', 'derived.powerPoints', {
      value: input,
      max,
    })
  }

  /** Rest stub — P8 placeholder; P9 will build the rest dialog with GM approval. */
  static async _onRestStub(event, target) {
    event?.preventDefault?.()
    ui.notifications.info('Rest dialog coming in P9. The new dialog will let you declare rest hours and ask the GM to approve.')
  }

  /** Toggle the improve checkbox on a skill (mark for improvement). */
  static async _onSkillImproveToggle(event, target) {
    event?.preventDefault?.()
    const skillId = target?.dataset?.skillId
    if (!skillId) return
    const item = this.actor.items.get(skillId)
    if (!item) return
    const current = !!item.system?.elysium?.improve
    await item.update({ 'system.elysium.improve': !current })
  }

  /** Create a new Active Effect on the actor. */
  static async _onEffectCreate(event, target) {
    event?.preventDefault?.()
    const created = await ActiveEffect.create({
      name: 'New Effect',
      icon: 'icons/svg/aura.svg',
      origin: this.actor.uuid,
      disabled: false,
    }, { parent: this.actor })
    if (created) created.sheet.render(true)
  }

  /** Open an Active Effect for editing. */
  static async _onEffectEdit(event, target) {
    event?.preventDefault?.()
    const effectId = target?.dataset?.effectId
    if (!effectId) return
    const effect = this.actor.effects.get(effectId)
    if (!effect) return
    effect.sheet.render(true)
  }

  /** Toggle enabled/disabled state of an Active Effect. */
  static async _onEffectToggle(event, target) {
    event?.preventDefault?.()
    const effectId = target?.dataset?.effectId
    if (!effectId) return
    const effect = this.actor.effects.get(effectId)
    if (!effect) return
    await effect.update({ disabled: !effect.disabled })
  }

  /** Delete an Active Effect (with confirmation). */
  static async _onEffectDelete(event, target) {
    event?.preventDefault?.()
    const effectId = target?.dataset?.effectId
    if (!effectId) return
    const effect = this.actor.effects.get(effectId)
    if (!effect) return
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: 'Delete Effect' },
      content: `<p>Delete the active effect "<strong>${effect.name}</strong>"? This cannot be undone.</p>`,
    })
    if (confirmed) await effect.delete()
  }

  // End P8 shell action handlers
  // ==========================================================================

    //--------------------HANDLER----------------------------------
  static async _updateObject(event, form, formData) {
    const biographyKeyRegex = /^system.stories\.(\d+)\.(.+)$/
    const biographyKeys = Object.keys(formData.object).map(k => k.match(biographyKeyRegex)).filter(m => m)
    if (biographyKeys.length) {
      const biography = foundry.utils.duplicate(this.actor.system.stories)
      for (const biographyKey of biographyKeys) {
        biography[biographyKey[1]][biographyKey[2]] = formData.object['system.stories.' + biographyKey[1] + '.' + biographyKey[2]]
        delete formData[biographyKey[0]]
      }
      formData.object['system.stories'] = biography
    }

    if (event.target) {
      if (event.target.classList) {
        if (event.target.classList.contains('bio-section-value')) {
          const index = parseInt(
            event.target.dataset.index
          )
          await ElysiumActorSheetV2.updateBioValue(this.document,index, event.target.value)
          return
        }
        if (event.target.classList.contains('bio-section-title')) {
          const index = parseInt(
            event.target.closest('.bio-section').dataset.index
          )
          await ElysiumActorSheetV2.updateBioTitle(this.document,index, event.target.value)
          return
        }
      }
    }

    //const system = foundry.utils.expandObject(formData.object)?.system
    //formData.object.name = game.i18n.localize("Elysium." + formData.object['system.category']);
    await this.document.update(formData.object)
  }

//----------------LISTENERS---------------------------

  // Update skills etc without opening the item sheet
  static async skillInline(event) {
    event.preventDefault();
    const element = event.currentTarget;
    const li = event.currentTarget.closest(".item");
    const item = this.actor.items.get(li.dataset.itemId);
    let field = event.target.dataset.field;
    let newScore = event.target.value;
    if (['base', 'personality', 'career', 'culture', 'personal','xp','effects', 'currHP', 'quantity',
        'npcVal', 'allegPoints', 'hpCurr', 'ammoCurr','av1','ppCurr','pSCurr'].includes(field)) {
      newScore = Number(newScore)
      field = 'system.' + field;
    } else if (['displayName', 'ap', 'bap', 'apRnd', 'bapRnd', 'att', 'dmg1'].includes(field)) {
      field = 'system.' + field;
    } else if (field === 'name') {
    } else {
      console.log("Error, can't find action for field:" + field)
      return
    }
    await item.update({ [field]: newScore });
    this.actor.render(false);
    return;
  }

  //Add a New Story Section
  static async createBioSection (title = null) {
    const bio = this.document.system.stories
      ? foundry.utils.duplicate(this.document.system.stories)
      : []
    bio.push({
      title: "",
      value: null
    })
    await this.document.update({ 'system.stories': bio }, { renderSheet: false })
  }

  static async updateBioValue (actor, index, content) {
    const bio = foundry.utils.duplicate(actor.system.stories)
    bio[index].value = content
    await actor.update({ 'system.stories': bio })
    actor.render();
  }

  static async updateBioTitle (actor, index, title) {
    const bio = foundry.utils.duplicate(actor.system.stories)
    bio[index].title = title
    await actor.update({'system.stories': bio })
  }

  static async deleteBioSection (event) {
    const index = parseInt(
        event.target.closest('.bio-section').dataset.index
    )
    const bio = foundry.utils.duplicate(this.actor.system.stories)
    bio.splice(index, 1)
    await this.actor.update({ 'system.stories': bio })
  }

  static async moveBioSectionUp (event) {
    const index = parseInt(
        event.target.closest('.bio-section').dataset.index
    )
    if (index === 0) return
    const bio = foundry.utils.duplicate(this.actor.system.stories)
    if (index >= bio.length) return
    const elem = bio.splice(index, 1)[0]
    bio.splice(index - 1, 0, elem)
    await this.actor.update({ 'system.stories': bio })
  }

  static async moveBioSectionDown (event) {
    const index = parseInt(
        event.target.closest('.bio-section').dataset.index
    )
    const bio = foundry.utils.duplicate(this.actor.system.stories)
    if (index >= bio.length - 1) return
    const elem = bio.splice(index, 1)[0]
    bio.splice(index + 1, 0, elem)
    await this.actor.update({ 'system.stories': bio })
  }

  //-------------Drag and Drop--------------

  // Define whether a user is able to begin a dragstart workflow for a given drag selector
  _canDragStart(selector) {
    return this.isEditable;
  }

  //Define whether a user is able to conclude a drag-and-drop workflow for a given drop selector
  _canDragDrop(selector) {
    return this.isEditable;
  }

  //Callback actions which occur at the beginning of a drag start workflow.
  _onDragStart(event) {
    const docRow = event.currentTarget.closest('li');
    if ('link' in event.target.dataset) return;
    // Chained operation
    const dragData = this._getEmbeddedDocument(docRow)?.toDragData();
    if (!dragData) return;
    // Set data transfer
    event.dataTransfer.setData('text/plain', JSON.stringify(dragData));
  }

  //Callback actions which occur when a dragged element is over a drop target.
  _onDragOver(event) { }

  //Callback actions which occur when a dragged element is dropped on a target.
  async _onDrop(event) {
    const data = foundry.applications.ux.TextEditor.implementation.getDragEventData(event);
    const actor = this.actor;
    const allowed = Hooks.call('dropActorSheetData', actor, this, data);
    if (allowed === false) return;

    // Handle different data types
    switch (data.type) {
      case 'ActiveEffect':
        return this._onDropActiveEffect(event, data);
      case 'Actor':
        return this._onDropActor(event, data);
      case 'Item':
        return this._onDropItem(event, data);
      case 'Folder':
        return this._onDropFolder(event, data);
    }
  }

  //Handle the dropping of ActiveEffect data onto an Actor Sheet
  async _onDropActiveEffect(event, data) {
    const aeCls = getDocumentClass('ActiveEffect');
    const effect = await aeCls.fromDropData(data);
    if (!this.actor.isOwner || !effect) return false;
    if (this.actor.type === 'party') return false;
    return aeCls.create(effect, { parent: this.actor });
  }

  //Handle dropping of an Actor data onto another Actor sheet
  async _onDropActor(event, data) {
    if (!this.actor.isOwner) return false;
    await this.DropActor(data);
  }

  //Handle dropping of an item reference or item data onto an Actor Sheet
  async _onDropItem(event, data) {
    if (!this.actor.isOwner) return false;
    if (this.actor.type === 'party') return false;
    const item = await Item.implementation.fromDropData(data);
    // Handle item sorting within the same Actor
    if (this.actor.uuid === item.parent?.uuid)
      return this._onSortItem(event, item);
    // Create the owned item
    return this._onDropItemCreate(item, event);
  }

  //Handle dropping of a Folder on an Actor Sheet.
  async _onDropFolder(event, data) {
    if (!this.actor.isOwner) return [];
    const folder = await Folder.implementation.fromDropData(data);
    if (folder.type !== 'Item') return [];
    const droppedItemData = await Promise.all(
      folder.contents.map(async (item) => {
        if (!(document instanceof Item)) item = await fromUuid(item.uuid);
        return item;
      })
    );
    return this._onDropItemCreate(droppedItemData, event);
  }

  //Handle the final creation of dropped Item data on the Actor.
  async _onDropItemCreate(itemData, event) {
    itemData = await ElysiumActorItemDrop._onDropItemCreate(this.actor, itemData)
    const list = await this.actor.createEmbeddedDocuments('Item', itemData);
    return list;
  }

  //Returns an array of DragDrop instances
  get dragDrop() {
    return this._dragDrop;
  }

  _dragDrop;

  //Create drag-and-drop workflow handlers for this Application
  _createDragDropHandlers() {
    return this.options.dragDrop.map((d) => {
      d.permissions = {
        dragstart: this._canDragStart.bind(this),
        drop: this._canDragDrop.bind(this),
      };
      d.callbacks = {
        dragstart: this._onDragStart.bind(this),
        dragover: this._onDragOver.bind(this),
        drop: this._onDrop.bind(this),
      };
      return new foundry.applications.ux.DragDrop(d);
    });
  }

  //Drop Actor on to an Actor Sheet
  async DropActor(data) {
    return

  }
}
