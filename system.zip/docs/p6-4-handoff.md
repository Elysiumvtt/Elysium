# P6.4 Prep Audit — Magic Item DataModels

Companion to `p6-prep-audit.md`. Captured 2026-05-13 against v1.0.0-alpha.7. Covers:
`arcane`, `divine`, `mysticism`, `sorcery`. The deepest schemas in the system.

## Compendium content

| Type | Pack | Item count |
|---|---|---|
| arcane | spells-arcane.db | 42 |
| divine | spells-divine.db | 30 |
| mysticism | abilities-mysticism.db | 5 |
| sorcery | abilities-sorcery.db | 264 |

All 4 types have substantial live data — over 340 items across the four. Compendium-content
verification is the critical acceptance gate.

## Schema-shape audit

### Compendium-only fields (NOT in template.json — schema must declare)

**arcane**: 6 fields
- `cost: str` (values '1'..'5') — legacy of divine.cost; arcane inherited the shape but
  template was never updated
- `pcost: int` (values 1..5) — the modern numeric version of cost
- `magicChosen: bool` (always true in compendium)
- `mpCurr: int` (always 0; magic-point legacy)
- `mpMax: int` (always 0)
- `spellCat: str` — duplicate of `elysium.school` (same 8 values: Abjuration..Transmutation)

ZERO code reads any of these. Pure compendium-content metadata. Declare to accept drops;
P12 candidate to regenerate compendium without these and drop schema declarations.

**sorcery**: 1 field
- `subType: str` (always '' in 264 compendium items). Zero code reads. Declare permissively.

**divine, mysticism**: no compendium-only fields.

### Documentation-only fields (DROP)

Two `_doc` keys in P6.4 templates:
- `mysticism.elysium._doc` — explains v0.13.0 themed-bundle integration
- (none in arcane/divine/sorcery)

### Fixed-shape nested structures

**divine.elysium.{apCostByTier, powCostByTier}**: fixed-length-5 arrays of integers.
**sorcery.elysium.{apCostByTier, locationsByTier}**: same shape.
**sorcery.elysium.damageByTier**: fixed-length-5 array of strings (dice formulas).

Declare as `ArrayField<NumberField>` / `ArrayField<StringField>` with `initial:` arrays
of length 5. Foundry doesn't enforce array length — that's a logical constraint, not a
schema constraint. Side finding for P12 if length-enforcement becomes needed.

**divine.elysium.effectByTier** and **sorcery.elysium.effectByTier**: object with 5
fixed string-digit keys ("1".."5"). Compendium audit confirms all 30 + 264 items have
exactly these keys. Two declaration options:
- (a) SchemaField with explicit named keys (type-safe, enforces shape)
- (b) TypedObjectField<StringField> (accepts any string key)

Going with **(a) SchemaField with explicit keys**. Locks the shape to match all live
data. Side finding for P12 if mod content ever wants 6-tier spells.

**sorcery.elysium.thresholds**: object with 5 fixed named keys
(nascent/developing/established/potent/transcendent), each `{min, max}`. SchemaField
with explicit named keys + inner SchemaField for each tier.

**arcane.elysium.baseline**: `{range, duration, targets, area}` — 4-key SchemaField,
all numbers.

### Array fields

- `arcane.elysium.{techniques, forms, validSchools}`: `ArrayField<StringField>`.
  Techniques/forms populated in compendium (e.g. Magic Missile has `techniques: ["Create"]`,
  `forms: ["Force"]`). validSchools empty across all 42 spells; permissive declaration.
- `divine.elysium.spellTags`: `ArrayField<StringField>`. Empty in all 30 spells; permissive.

### Themed-bundle shape (mysticism + ability shared)

`mysticism.elysium.{activation, benefits, drawbacks, addOns}` is BIT-IDENTICAL to
`ability.elysium.{activation, benefits, drawbacks, addOns}` (modulo the `_doc` keys
which are dropped). Per project decision principle of "factor when proven by 2 reuses",
this is the trigger to introduce a helper.

**Plan**:
1. Add `makeThemedBundle()` to `module/data/item/_shared.mjs` — returns the 4 fields.
2. Refactor `ability.mjs` to use it (small change; no behavioral difference).
3. Use it in the new `mysticism.mjs`.

### Arcane + Mysticism shared top-level fields (17 fields)

Audit shows arcane and mysticism share 17 top-level fields exactly:
`base, xp, profession, personality, culture, personal, effects, category, impact, range,
duration, pppl, damage, prsnlty, occupation, cultural, improve`. Only `arcane` adds `mem`.

Both look like they derived from a common spell template that was forked. Strong factoring
candidate.

**Plan**: add `makeSpellBaseFields()` to `_shared.mjs` returning these 17 fields. Use in
arcane (which adds `mem`) and mysticism. Do NOT use for divine/sorcery — their top-level
shapes are completely different (divine: 6 own; sorcery: 9 own).

## String-enum locking decisions

| Field | Decision | Reason |
|---|---|---|
| `arcane.elysium.school` | FREE | 8 values observed but content-creator-extensible (custom schools) |
| `arcane.elysium.damageType` | FREE | Damage-system content-extensible |
| `divine.elysium.domain` | FREE | 6 values observed; extensible |
| `divine.elysium.damageType` | FREE | Same as arcane |
| `mysticism.elysium.discipline` | FREE | 3 values observed; extensible |
| `sorcery.elysium.essence` | FREE | 12 values observed; extensible |
| `sorcery.elysium.essenceRarity` | FREE | Only 'common' observed; insufficient ground truth |
| `sorcery.elysium.abilityType` | FREE | Only 'spell' observed |
| `sorcery.elysium.{baseStatA, baseStatB}` | FREE | Stat keys (int, pow, etc.) — could lock to actor's stat set, but mechanic-internal; leave free |
| `sorcery.elysium.damageType` | FREE | Same |
| `divine.elysium.spellTags[i]` | FREE | Empty in compendium |
| `arcane.elysium.{techniques[], forms[]}` | FREE | Per-spell tag set; content-extensible |

**Zero locked enums in P6.4.** All magic-type string fields are content-creator-extensible;
locking any of them would break community content extension.

## Stored-string-numerics (template stores number-shaped strings)

Following the P6.2 pattern from `super.cpc`:
- `arcane.pppl: '1'` (string in template, used in templates as text) — StringField
- `divine.cost: '1'` (string in template) — StringField
- `mysticism.pppl: '1'` — StringField
- `sorcery.pppl: '1'` — StringField  
- `sorcery.powCost: '0'` — StringField (top-level — different from elysium.powerCost which is int)
- `arcane.cost: '1'` (compendium-only, all strings '1'..'5') — StringField

Preserve string typing to match stored data + template defaults.

## Side findings

**#14 — `arcane.cost`, `arcane.pcost`, `arcane.mpCurr`, `arcane.mpMax`, `arcane.magicChosen`,
`arcane.spellCat`, `sorcery.subType` are compendium-driven but unused.** Same pattern as
the v0.21.0 ballistic-armor legacy. Zero code reads any of them. P6.6 candidate: regenerate
compendium without these, then drop schema declarations.

**#15 — `arcane.spellCat` duplicates `arcane.elysium.school`.** Both fields carry the
same 8-value vocabulary (Abjuration..Transmutation). Pre-existing data redundancy. P12 to
deduplicate.

**#16 — `divine.domain` and `divine.elysium.domain` duplicate.** Same 6-value set. Same
redundancy pattern. P12 to deduplicate.

# P6.4 implementation spec

## Shared helpers to add to `_shared.mjs`

```js
// Already exists: makeItemBase()

/**
 * Themed-bundle fields shared by ability + mysticism per audit. Bit-identical shape.
 * `_doc` field dropped (template documentation, not a stored value).
 */
export function makeThemedBundle () {
  return {
    activation: new fields.SchemaField({
      type:          new fields.StringField({ initial: 'passive' }),
      actionCost:    new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      ppCost:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      duration:      new fields.StringField({ initial: '' }),
      endConditions: new fields.ArrayField(new fields.StringField(), { initial: [] }),
    }),
    benefits: new fields.ArrayField(
      new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
      { initial: [] },
    ),
    drawbacks: new fields.ArrayField(
      new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
      { initial: [] },
    ),
    addOns: new fields.ArrayField(
      new fields.SchemaField({
        name:                  new fields.StringField({ initial: '' }),
        description:           new fields.StringField({ initial: '' }),
        requiredSkillPercent:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        xpDiceCost:            new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        ppCost:                new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        effect:                new fields.StringField({ initial: '' }),
      }),
      { initial: [] },
    ),
  }
}

/**
 * 17 top-level spell fields shared by arcane + mysticism per audit. Bit-identical.
 * Arcane adds `mem` on top of these; mysticism uses these as-is.
 */
export function makeSpellBaseFields () {
  return {
    base:        new fields.NumberField({ integer: true, initial: 0 }),
    xp:          new fields.NumberField({ integer: true, initial: 0 }),
    profession:  new fields.NumberField({ integer: true, initial: 0 }),
    personality: new fields.NumberField({ integer: true, initial: 0 }),
    culture:     new fields.NumberField({ integer: true, initial: 0 }),
    personal:    new fields.NumberField({ integer: true, initial: 0 }),
    effects:     new fields.NumberField({ integer: true, initial: 0 }),
    category:    new fields.StringField({ initial: '' }),
    impact:      new fields.StringField({ initial: 'other' }),
    range:       new fields.StringField({ initial: '' }),
    duration:    new fields.StringField({ initial: '' }),
    pppl:        new fields.StringField({ initial: '1' }),     // string per template
    damage:      new fields.StringField({ initial: '' }),
    prsnlty:     new fields.BooleanField({ initial: false }),
    occupation:  new fields.BooleanField({ initial: false }),
    cultural:    new fields.BooleanField({ initial: false }),
    improve:     new fields.BooleanField({ initial: false }),
  }
}
```

Note: also **refactor `ability.mjs`** to use `makeThemedBundle()` for its
`{activation, benefits, drawbacks, addOns}` block. Pure cleanup — no behavioral change.

## Per-type schema specs

### divine.mjs (6 own + base + 21 elysium = ~29 slots)

```js
class DivineDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      category: new fields.StringField({ initial: '' }),
      range:    new fields.StringField({ initial: '' }),
      duration: new fields.StringField({ initial: '' }),
      cost:     new fields.StringField({ initial: '1' }),      // STRING per template
      domain:   new fields.StringField({ initial: '' }),
      elysium: new fields.SchemaField({
        domain:        new fields.StringField({ initial: '' }),
        tier:          new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        baseTier:      new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        maxTier:       new fields.NumberField({ integer: true, initial: 5, min: 0 }),
        // Fixed-length-5 array of integers
        apCostByTier:  new fields.ArrayField(new fields.NumberField({ integer: true }),
          { initial: [1, 1, 2, 2, 3] }),
        powCostByTier: new fields.ArrayField(new fields.NumberField({ integer: true }),
          { initial: [0, 0, 0, 0, 0] }),
        // Fixed 5-key object: "1".."5" → string description per tier
        effectByTier: new fields.SchemaField({
          '1': new fields.StringField({ initial: '' }),
          '2': new fields.StringField({ initial: '' }),
          '3': new fields.StringField({ initial: '' }),
          '4': new fields.StringField({ initial: '' }),
          '5': new fields.StringField({ initial: '' }),
        }),
        isReactive:         new fields.BooleanField({ initial: false }),
        isRitual:           new fields.BooleanField({ initial: false }),
        ritualMinutes:      new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        powerCost:          new fields.NumberField({ integer: true, initial: 0 }),
        apCost:             new fields.NumberField({ integer: true, initial: 1 }),
        reactionCost:       new fields.NumberField({ integer: true, initial: 0 }),
        autoActivate:       new fields.BooleanField({ initial: true }),
        spellTags:          new fields.ArrayField(new fields.StringField(), { initial: [] }),
        minFaithRank:       new fields.NumberField({ integer: true, initial: 0 }),
        isDamageSpell:      new fields.BooleanField({ initial: false }),
        damageType:         new fields.StringField({ initial: '' }),
        saveSkill:          new fields.StringField({ initial: '' }),
        isSustained:        new fields.BooleanField({ initial: false }),
        maintainPPPerRound: new fields.NumberField({ integer: true, initial: 0 }),
      }),
    }
  }
}
```

### mysticism.mjs (17 own + base + 9 elysium = ~28 slots)

```js
import { makeItemBase, makeSpellBaseFields, makeThemedBundle } from './_shared.mjs'

class MysticismDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      ...makeSpellBaseFields(),
      elysium: new fields.SchemaField({
        discipline: new fields.StringField({ initial: '' }),
        tier:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        powerCost:  new fields.NumberField({ integer: true, initial: 0 }),
        apCost:     new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill:  new fields.StringField({ initial: '' }),
        ...makeThemedBundle(),
        // _doc DROPPED
      }),
    }
  }
}
```

### arcane.mjs (17 spell + mem + base + 17 elysium + 6 compendium-only = ~42 slots)

```js
class ArcaneDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      ...makeSpellBaseFields(),
      mem: new fields.BooleanField({ initial: false }),  // arcane-only spell-base extra

      // Compendium-driven legacy (side-finding #14)
      cost:        new fields.StringField({ initial: '' }),  // duplicates pcost — see #14
      pcost:       new fields.NumberField({ integer: true, initial: 0 }),
      magicChosen: new fields.BooleanField({ initial: false }),
      mpCurr:      new fields.NumberField({ integer: true, initial: 0 }),
      mpMax:       new fields.NumberField({ integer: true, initial: 0 }),
      spellCat:    new fields.StringField({ initial: '' }),  // duplicates elysium.school — see #15

      elysium: new fields.SchemaField({
        school:        new fields.StringField({ initial: '' }),
        validSchools:  new fields.ArrayField(new fields.StringField(), { initial: [] }),
        techniques:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        forms:         new fields.ArrayField(new fields.StringField(), { initial: [] }),
        requiredSL:    new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        basePP:        new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        isDamageSpell: new fields.BooleanField({ initial: false }),
        damageType:    new fields.StringField({ initial: '' }),
        forbidden:     new fields.BooleanField({ initial: false }),
        baseline: new fields.SchemaField({
          range:    new fields.NumberField({ integer: true, initial: 0 }),
          duration: new fields.NumberField({ integer: true, initial: 0 }),
          targets:  new fields.NumberField({ integer: true, initial: 0 }),
          area:     new fields.NumberField({ integer: true, initial: 0 }),
        }),
        isReactive:  new fields.BooleanField({ initial: false }),
        isSustained: new fields.BooleanField({ initial: false }),
        isRitual:    new fields.BooleanField({ initial: false }),
        isPermanent: new fields.BooleanField({ initial: false }),
        powerCost:   new fields.NumberField({ integer: true, initial: 0 }),
        apCost:      new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill:   new fields.StringField({ initial: '' }),
      }),
    }
  }
}
```

### sorcery.mjs (9 own + base + 27 elysium + 1 compendium-only = ~38 slots — largest in P6.4)

```js
class SorceryDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      mem:     new fields.BooleanField({ initial: false }),
      range:   new fields.StringField({ initial: '' }),
      pppl:    new fields.StringField({ initial: '1' }),     // STRING per template
      powCost: new fields.StringField({ initial: '0' }),     // STRING per template
      maxLvl:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      currLvl: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      memLvl:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      var:     new fields.BooleanField({ initial: false }),

      // Compendium-driven (side-finding #14)
      subType: new fields.StringField({ initial: '' }),

      elysium: new fields.SchemaField({
        essence:        new fields.StringField({ initial: '' }),
        essenceRarity:  new fields.StringField({ initial: 'common' }),
        isConfluence:   new fields.BooleanField({ initial: false }),
        isRestricted:   new fields.BooleanField({ initial: false }),
        abilityType:    new fields.StringField({ initial: 'spell' }),
        tierIndex:      new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        unlockExpCost:  new fields.NumberField({ integer: true, initial: 0 }),
        isFreeAbility:  new fields.BooleanField({ initial: false }),
        currentSkillPct: new fields.NumberField({ integer: true, initial: 0 }),
        baseStatA:      new fields.StringField({ initial: 'int' }),
        baseStatB:      new fields.StringField({ initial: 'pow' }),
        // thresholds: 5 fixed named tiers, each {min, max}
        thresholds: new fields.SchemaField({
          nascent:      new fields.SchemaField({
            min: new fields.NumberField({ integer: true, initial: 1 }),
            max: new fields.NumberField({ integer: true, initial: 49 }),
          }),
          developing:   new fields.SchemaField({
            min: new fields.NumberField({ integer: true, initial: 50 }),
            max: new fields.NumberField({ integer: true, initial: 69 }),
          }),
          established:  new fields.SchemaField({
            min: new fields.NumberField({ integer: true, initial: 70 }),
            max: new fields.NumberField({ integer: true, initial: 84 }),
          }),
          potent:       new fields.SchemaField({
            min: new fields.NumberField({ integer: true, initial: 85 }),
            max: new fields.NumberField({ integer: true, initial: 94 }),
          }),
          transcendent: new fields.SchemaField({
            min: new fields.NumberField({ integer: true, initial: 95 }),
            max: new fields.NumberField({ integer: true, initial: 999 }),
          }),
        }),
        powerCost:      new fields.NumberField({ integer: true, initial: 2 }),
        apCost:         new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill:      new fields.StringField({ initial: '' }),
        baseTier:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        maxTier:        new fields.NumberField({ integer: true, initial: 5, min: 0 }),
        apCostByTier:   new fields.ArrayField(new fields.NumberField({ integer: true }),
          { initial: [1, 1, 1, 1, 1] }),
        effectByTier: new fields.SchemaField({
          '1': new fields.StringField({ initial: '' }),
          '2': new fields.StringField({ initial: '' }),
          '3': new fields.StringField({ initial: '' }),
          '4': new fields.StringField({ initial: '' }),
          '5': new fields.StringField({ initial: '' }),
        }),
        isDamageSpell:      new fields.BooleanField({ initial: false }),
        damageType:         new fields.StringField({ initial: '' }),
        isSustained:        new fields.BooleanField({ initial: false }),
        maintainPPPerRound: new fields.NumberField({ integer: true, initial: 0 }),
        forbidden:          new fields.BooleanField({ initial: false }),
        damageByTier:       new fields.ArrayField(new fields.StringField(),
          { initial: ['', '', '', '', ''] }),
        locationsByTier:    new fields.ArrayField(new fields.NumberField({ integer: true }),
          { initial: [1, 1, 1, 1, 1] }),
        casterChoosesLocation: new fields.BooleanField({ initial: false }),
      }),
    }
  }
}
```

## init.mjs

4 imports, 4 registrations.

## ability.mjs refactor

Replace the inline `activation/benefits/drawbacks/addOns` declarations with
`...makeThemedBundle()`. The shape is bit-identical so no validation behavior changes.

## Smoke test plan

Same shape as P6.3:
1. Boot — all 4 DataModels registered with expected counts
2. Create — all 4 types create cleanly
3. Defaults — spot-check fixed-length-5 arrays, the 5-key effectByTier object, the
   5-named-key thresholds object, deep nesting (sorcery.elysium.thresholds.transcendent.max),
   compendium-only field defaults
4. Persistence — writes covering: NumberField, StringField (free), BooleanField, HTMLField,
   ArrayField<String>, ArrayField<Number>, nested SchemaField (effectByTier.1),
   deep-nested SchemaField (thresholds.developing.max), the themed-bundle reused fields
5. **Compendium drop test** — drop one of each of 4 magic types from compendium onto a
   character. Critical for arcane (6 compendium-only fields) and sorcery (1 compendium-only +
   the deeply nested thresholds/effectByTier).
6. Regression: ability still works (the refactored themed bundle), P6.1–P6.3 still work
7. Cleanup

## Side findings

- **#14** — Six arcane compendium-only fields + one sorcery field, all zero-readers.
  Same pattern as the v0.21.0 ballistic-armor legacy. P6.6 candidate.
- **#15** — `arcane.spellCat` duplicates `arcane.elysium.school`. P12 dedup.
- **#16** — `divine.domain` (top-level) duplicates `divine.elysium.domain`. P12 dedup.
