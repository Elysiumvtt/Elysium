// Auto-extracted from module/elysium/hooks/register-hooks.mjs
// (v0.21.0 register-hooks refactor).
//
// Combat tracker render hook: paints a small shield badge next to the name
// of any combatant currently bracing (flags.elysium.braced === true).
// V14 passes the HTMLElement directly; V13 passed jQuery — we handle both
// shapes since some integration code may still come through the older path.

export function onRenderCombatTracker (app, html, data) {
  const root = html instanceof Element ? html : html?.[0] || html
  if (!root) return
  const combat = game.combat
  if (!combat) return
  for (const c of combat.combatants) {
    if (!c.flags?.['elysium']?.braced) continue
    const row = root.querySelector(`[data-combatant-id="${c.id}"]`)
    if (!row) continue
    if (row.querySelector('.elysium-brace-badge')) continue
    const nameEl = row.querySelector('.token-name, .combatant-name, .name') || row
    const badge = document.createElement('i')
    badge.className = 'fas fa-shield elysium-brace-badge'
    badge.dataset.tooltip = `${c.name} is bracing — knockback excess halved.`
    nameEl.appendChild(badge)
  }
}
