/**
 * NPCDataModel — schema for actors of type 'npc'.
 *
 * Per P5 design (docs/datamodel-design.md) and P5 prep audit
 * (docs/p5-prep-audit.md): STORED-SCHEMA-ONLY. No prepareDerivedData
 * override here — ElysiumActor.prepareDerivedData (and the dispatched
 * _prepareNpcData → _prepStats → _prepDerivedStats chain) continues to
 * populate derived fields (label, total, deriv, visible, formula, etc.)
 * on the live data object. Those derived fields are stamped onto the
 * runtime data and dropped by Foundry's clean step on save.
 *
 * Sparse-field strategy (P3 Decision 3): NPC declares only the
 * elysium-partition fields it actually uses. Character-only fields
 * (expDice, buildPoints, skillPoints, patron, essences, schoolMastery,
 * statNaturalMax, ancestryId, companion) are intentionally omitted —
 * NPCs do not need them.
 *
 * Field set is per docs/p5-prep-audit.md, with three corrections made
 * during P5.1 implementation grep:
 *   - res5 KEPT: actor.mjs:486-487 populates labels; templates read it
 *   - health.daily KEPT: live writes in damage.mjs reset to 0; removing
 *     would break those updates under strict-schema validation
 *   - power.battVal/battMax DROPPED: zero readers, grep-confirmed
 */

import {
  makeStats,
  makeHealth,
  makePower,
  makeFatigue,
  makeActionPoints,
  makeResourcePair,
  STAT_KEYS,
} from './_shared.mjs'

const fields = foundry.data.fields

export class NPCDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      // === From base template ===========================================
      stats:          makeStats(),
      health:         makeHealth(),
      power:          makePower(),
      fatigue:        makeFatigue(),
      actionPoints:   makeActionPoints(),
      tempHP:         makeResourcePair(0, 0),
      luckPoints:     makeResourcePair(0, 0),
      sanity:         makeResourcePair(0, 0),
      res5:           makeResourcePair(0, 0),
      dmgmodTier:     new fields.StringField({ initial: '+0' }),
      wealthValue:    new fields.NumberField({ integer: true, initial: 0 }),

      // Coinage tracker (P9 cluster 3 / alpha.33) — discrete coin
      // counts for PP/GP/SP/CP. Bit-identical to CharacterDataModel
      // declaration. Top-level (not under .elysium) because coins are
      // generic TTRPG state, not Elysium-fork-specific. NPC sheet
      // surfaces the same items-tab coinage card.
      coins: new fields.SchemaField({
        pp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        gp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        sp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        cp: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      }),

      // === Sparse elysium partition (NPC-relevant fields only) ==========
      // P3 Decision 3: character-only elysium fields (expDice, buildPoints,
      // skillPoints, statNaturalMax, patron, essences, schoolMastery,
      // ancestryId, companion) are NOT declared on NPC.
      elysium: new fields.SchemaField({
        creatureType: new fields.StringField({
          initial: 'humanoid',
          choices: ['humanoid', 'beast', 'undead', 'construct',
                    'spirit', 'elemental', 'plant', 'aberration'],
        }),
        creatureSubtype: new fields.StringField({ initial: 'human' }),
        creatureTags:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        languages:       new fields.ArrayField(new fields.StringField(), { initial: [] }),
      }),

      // === NPC's own fields (19 — matches template.json npc block) ======
      description:    new fields.HTMLField({ initial: '' }),
      extDesc:        new fields.HTMLField({ initial: '' }),
      majorWnd:       new fields.BooleanField({ initial: false }),
      minorWnd:       new fields.BooleanField({ initial: false }),
      moveTitle:      new fields.StringField({ initial: 'Move' }),
      move:           new fields.NumberField({ integer: true, initial: 0 }),
      altMoveTitle:   new fields.StringField({ initial: 'Alt Move' }),
      altMove:        new fields.NumberField({ integer: true, initial: 0 }),
      lock:           new fields.BooleanField({ initial: false }),
      // viewTab: no choices constraint — tab values have evolved across
      // versions and locking would break older saved NPCs. See P3 risk note
      // and docs/datamodel-design.md "Medium risk" section.
      viewTab:        new fields.StringField({ initial: '2' }),
      showNotes:      new fields.BooleanField({ initial: false }),
      sanLoss:        new fields.StringField({ initial: '' }),
      sanDesc:        new fields.StringField({ initial: '' }),
      movDesc:        new fields.StringField({ initial: '' }),
      ap:             new fields.NumberField({ integer: true, initial: 0 }),
      apRnd:          new fields.StringField({ initial: '' }),

      // baseStats: keyed-by-stat-name (8 stats including edu, per template).
      // Values are {average: dice-string, random: dice-string}.
      // TypedObjectField gives us the "values share this shape" pattern
      // without enumerating each key in the schema.
      baseStats: new fields.TypedObjectField(
        new fields.SchemaField({
          average: new fields.StringField({ initial: '' }),
          random:  new fields.StringField({ initial: '' }),
        })
      ),

      // hp: NPC HP-derivation formula. Two stats + multiplier.
      hp: new fields.SchemaField({
        multi: new fields.NumberField({ initial: 0.5 }),
        stat1: new fields.StringField({ initial: 'siz' }),
        stat2: new fields.StringField({ initial: 'con' }),
      }),

      // mod: NPC-specific modifier toggles. Currently just strdb (strength-
      // based damage bonus override).
      mod: new fields.SchemaField({
        strdb: new fields.BooleanField({ initial: false }),
      }),
    }
  }
}
