/**
 * Divine casting (v0.18.0).
 *
 * Multi-AP cast pipeline with cast-time tier choice. Supersedes the
 * v0.17.0 single-roll, single-AP design.
 *
 * Pipeline:
 *   1. beginDivineCast(actor, spell) — opens tier-choice dialog, validates,
 *      writes active-cast state to actor flag.
 *   2. spendDivineCastAP(actor) — called once per turn (or AP-tick) by the
 *      character sheet's "spend AP on cast" button. Decrements remaining
 *      AP count. On the LAST AP, fires the Channeling roll and resolves.
 *   3. abandonDivineCast(actor, reason) — called when the cleric takes any
 *      action that would cost an AP (forced parry, weapon attack, etc.).
 *      PP refunded, spent APs lost, flag cleared.
 *
 * Cast resolution flow (only on last AP):
 *   - Channeling roll: d100 vs Channeling skill total
 *     - Fail → cast fizzles. PP refunded. Spent APs lost. No wild magic.
 *     - Critical fumble → same as fail (locked design)
 *   - Channel succeeded → if Faith < 100, roll d100 vs Faith
 *     - Faith fail → patron twists; roll Divine Wild Magic table
 *     - Faith success or Faith=100 → spell happens cleanly at the
 *       chosen tier
 *
 * Active-cast state (stored in flags.elysium.activeCast):
 *   {
 *     tradition: 'divine',
 *     spellId, spellName,
 *     chosenTier: 1-5,
 *     apTotal: number,    // total APs the cast will cost
 *     apSpent: number,    // APs spent so far (starts at 0)
 *     ppCommitted: number,
 *     messageId: string,  // chat card to update as APs are spent
 *   }
 *
 * See `elysium/docs/DESIGN-divine-v0.18.0.md` for the full design statement.
 */

import { payPP, refundPP, spendAP, rollD100, rollMagicTable, postCastCard, classifyRoll, findSkill, getActiveCast, setActiveCast, clearActiveCast } from './cast-shared.mjs'
import { TierChoiceDialog } from './tier-choice-dialog.mjs'// v0.19.0: divine sustained spells (Spiritual Weapon, Spirit Guardians,
// Investiture of Flame) use the shared sustain registry — they share
// the per-round upkeep mechanic with arcane sustains, just at a fixed
// 1 PP/round cost instead of the arcane "full cast cost per round."
import { addSustain } from './sustain.mjs'
const CHANNELING_SUBGROUP = 'divine'

/**
 * Tier band thresholds, matching Mythras grade thresholds (and the
 * locked design's Faith band rewrite).
 */
const TIER_THRESHOLDS = {
  1: 1,    // Untested
  2: 50,   // Devotee
  3: 70,   // Anointed
  4: 85,   // Chosen
  5: 95,   // Saint
}

/**
 * Compute the highest tier the cleric can cast at, given Channeling and
 * Faith totals. Returns 0 if neither qualifies for tier 1.
 */
export function maxCastableTier (channelTotal, faithTotal) {
  let max = 0
  for (let t = 1; t <= 5; t++) {
    const threshold = TIER_THRESHOLDS[t]
    if (channelTotal >= threshold && faithTotal >= threshold) {
      max = t
    }
  }
  return max
}

/**
 * v0.19.0: apply temporary POW reduction at cast completion for spells
 * that carry a `powCostByTier` ladder (currently only Resurrection).
 *
 * Mechanism: decrement `system.stats.pow.effects` by the per-tier amount.
 * The `effects` field is summed into the stat total during prepareData
 * (line 467 of actor.mjs), so this propagates automatically to derived
 * values like PP-max and the various stat-based skill rolls.
 *
 * Recovery rate: 1 POW per full day of rest. v0.19.0 does NOT yet
 * implement automatic recovery — GM tracks the recovery interval and
 * either manually edits the stat back up, or uses a future "rest"
 * mechanic that consumes flags on the actor.
 *
 * A chat notice is posted so players can see the loss.
 *
 * @param {Actor}  actor
 * @param {string} spellName  — for the chat notice
 * @param {number} chosenTier — 1-5
 * @param {Array<number>} powCostByTier — from spell.system.elysium.powCostByTier
 * @returns {Promise<number>} the amount of POW lost (0 if no loss applies)
 */
async function applyDivinePOWLoss (actor, spellName, chosenTier, powCostByTier) {
  if (!Array.isArray(powCostByTier) || powCostByTier.length < 5) return 0
  const idx = Math.max(0, Math.min(4, chosenTier - 1))
  const cost = Number(powCostByTier[idx]) || 0
  if (cost <= 0) return 0

  const currentEffects = Number(actor.system?.stats?.pow?.effects) || 0
  const newEffects = currentEffects - cost
  await actor.update({ 'system.stats.pow.effects': newEffects })

  const body = `${game.i18n.format('Elysium.Chat.PowLossBody', {
    actor: `<strong>${actor.name}</strong>`,
    cost: `<strong>${cost} POW</strong>`,
    spell: spellName,
  })}<br><em>${game.i18n.localize('Elysium.Chat.PowLossRecovery')}</em>`

  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'mind', title: game.i18n.localize('Elysium.Chat.PowLossTitle'), icon: 'heart-broken', body }
  )
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: html,
  })

  return cost
}

/**
 * Begin a divine cast. Validates pre-conditions, opens the tier-choice
 * dialog, and on player confirmation, writes active-cast state.
 *
 * @param {Actor} actor
 * @param {Item} spell
 * @returns {Promise<void>}
 */
export async function beginDivineCast (actor, spell) {
  // Conflict check — only one active cast at a time across all traditions.
  const existing = getActiveCast(actor)
  if (existing) {
    ui.notifications?.warn(
      `${actor.name} already has an active ${existing.tradition || 'arcane'} cast ` +
      `(${existing.spellName}). Finish or abandon it first.`)
    return
  }

  // Step 1: Faith allegiance.
  const faiths = actor.items.filter(i =>
    i.type === 'allegiance' && /faith/i.test(i.name || ''))
  if (faiths.length === 0) {
    ui.notifications?.warn(
      `${actor.name} has no Faith allegiance.`)
    return
  }
  const faith = faiths[0]
  const faithTotal = Number(faith.system?.allegPoints) || 0

  // Step 2: Channeling skill.
  const channeling = findSkill(actor, { subgroup: CHANNELING_SUBGROUP })
  if (!channeling) {
    ui.notifications?.warn(
      `${actor.name} has no Channeling skill. Drag it from the Skills compendium.`)
    return
  }
  const channelTotal = Number(channeling.system?.grandTotal ?? channeling.system?.total ?? 0) || 0

  // Step 3: Determine castable tier range for this spell.
  const baseTier = Number(spell.system?.elysium?.baseTier ?? spell.system?.elysium?.tier ?? 1) || 1
  const maxTier = Number(spell.system?.elysium?.maxTier ?? 5) || 5
  const playerMax = maxCastableTier(channelTotal, faithTotal)

  if (playerMax < baseTier) {
    ui.notifications?.warn(
      `${actor.name} cannot cast ${spell.name} — minimum tier is ${baseTier}, ` +
      `but Channeling/Faith only qualify up to tier ${playerMax}.`)
    return
  }

  const effectiveMax = Math.min(maxTier, playerMax)
  // Available tiers: from baseTier up to effectiveMax inclusive.
  const availableTiers = []
  for (let t = baseTier; t <= effectiveMax; t++) availableTiers.push(t)

  // Step 4: Open tier-choice dialog. Player picks chosenTier; cancel returns null.
  const apCostByTier = spell.system?.elysium?.apCostByTier ?? [1, 1, 2, 2, 3]
  const effectByTier = spell.system?.elysium?.effectByTier ?? {}
  const chosen = await TierChoiceDialog.open({
    actor, spell,
    availableTiers,
    apCostByTier,
    effectByTier,
    channelTotal,
    faithTotal,
  })
  if (!chosen) return

  const chosenTier = chosen.tier
  const apTotal = Number(apCostByTier[chosenTier - 1]) || 1

  // Step 5: PP cost. Charged upfront; refunded on Channel fail or abandon.
  const ppCost = Number(spell.system?.elysium?.powerCost ?? spell.system?.cost ?? 1) || 1
  const ppResult = await payPP(actor, ppCost, true)
  if (ppResult.fizzled) {
    ui.notifications?.warn(`${actor.name} could not pay PP cost. Cast aborted.`)
    return
  }

  // Step 6: Spend the FIRST AP of the cast. This is the cleric committing
  // to the prayer this round.
  const ok = await spendAP(actor, 1)
  if (!ok) {
    // Couldn't spend AP — refund PP, abort.
    await refundPP(actor, ppResult.ppSpent)
    return
  }

  // Step 7: Post initial in-progress chat card.
  const inProgressMsg = await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: spell.id,
    spellName: spell.name,
    tradition: 'divine',
    schoolName: spell.system?.elysium?.domain ?? '',
    schoolSkillName: channeling.name,
    schoolSkillTotal: channelTotal,
    inProgress: apTotal > 1,
    completed: apTotal === 1 ? null : false,  // placeholder; resolved below
    abandoned: false,
    requiredSL: apTotal,        // re-using the SL bar to display AP progress
    accumulatedSL: 1,
    apSpent: 1,
    ppSpent: ppResult.ppSpent,
    fatigueAdded: ppResult.fatigueAdded,
    chosenTier,
    description: apTotal === 1
      ? ''  // single-AP cast resolves immediately below
      : `<p><em>Beginning prayer at tier ${chosenTier}. ${apTotal - 1} more AP required to complete.</em></p>`,
  })

  // Step 8: If single-AP, resolve immediately. Otherwise stash state.
  if (apTotal === 1) {
    await _resolveDivineCast(actor, spell, {
      chosenTier, channelTotal, faithTotal, channeling, faith,
      ppCommitted: ppResult.ppSpent, totalAPSpent: 1,
      messageId: inProgressMsg?.id,
    })
    return
  }

  // Multi-AP — write state and wait for spendDivineCastAP calls.
  await setActiveCast(actor, {
    tradition: 'divine',
    spellId: spell.id,
    spellName: spell.name,
    chosenTier,
    apTotal,
    apSpent: 1,
    ppCommitted: ppResult.ppSpent,
    messageId: inProgressMsg?.id,
  })
}

/**
 * Spend one more AP on an in-progress divine cast. Called by the sheet's
 * "spend AP on cast" button.
 *
 * @param {Actor} actor
 */
export async function spendDivineCastAP (actor) {
  const cast = getActiveCast(actor)
  if (!cast || cast.tradition !== 'divine') {
    ui.notifications?.warn('No in-progress divine cast.')
    return
  }
  const ok = await spendAP(actor, 1)
  if (!ok) return  // sheet already warned

  const newApSpent = cast.apSpent + 1

  if (newApSpent < cast.apTotal) {
    // Still mid-cast.
    await setActiveCast(actor, { ...cast, apSpent: newApSpent })
    return
  }

  // Last AP — resolve.
  // Re-find the spell, channeling, faith for the resolution call.
  const spell = actor.items.get(cast.spellId)
  if (!spell) {
    ui.notifications?.warn('Cast spell no longer found on actor; abandoning.')
    await clearActiveCast(actor)
    return
  }
  const channeling = findSkill(actor, { subgroup: CHANNELING_SUBGROUP })
  const channelTotal = Number(channeling?.system?.grandTotal ?? channeling?.system?.total ?? 0) || 0
  const faith = actor.items.find(i => i.type === 'allegiance' && /faith/i.test(i.name || ''))
  const faithTotal = Number(faith?.system?.allegPoints) || 0

  await _resolveDivineCast(actor, spell, {
    chosenTier: cast.chosenTier,
    channelTotal, faithTotal, channeling, faith,
    ppCommitted: cast.ppCommitted, totalAPSpent: newApSpent,
    messageId: cast.messageId,
  })

  await clearActiveCast(actor)
}

/**
 * Abandon an in-progress divine cast. Called when the cleric takes an
 * AP-costing action other than cast progression. PP is refunded fully;
 * spent APs are lost; cast state is cleared.
 *
 * @param {Actor} actor
 * @param {string} reason - human-readable reason (e.g., 'attack', 'parry', 'self-cancel')
 */
export async function abandonDivineCast (actor, reason = 'self-cancel') {
  const cast = getActiveCast(actor)
  if (!cast || cast.tradition !== 'divine') return

  await refundPP(actor, cast.ppCommitted)
  await clearActiveCast(actor)

  await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: cast.spellId,
    spellName: cast.spellName,
    tradition: 'divine',
    completed: false,
    abandoned: true,
    apSpent: cast.apSpent,
    ppSpent: 0,            // refunded
    fatigueAdded: 0,
    description: `<p><em>Cast abandoned (${reason}). Spent APs lost; PP refunded.</em></p>`,
  })
}

/**
 * Resolve a divine cast — fired on the LAST AP spent. Single Channeling
 * roll, conditional Faith roll for wild magic.
 */
async function _resolveDivineCast (actor, spell, ctx) {
  const { chosenTier, channelTotal, faithTotal, channeling, faith,
          ppCommitted, totalAPSpent, messageId } = ctx

  // Channeling roll.
  const { value: channelRollValue } = await rollD100()
  const channelOutcome = classifyRoll(channelTotal, channelRollValue)
  const channelSucceeded = channelRollValue <= channelTotal

  if (!channelSucceeded) {
    await refundPP(actor, ppCommitted)
    await postCastCard({
      casterDoc: actor,
      casterName: actor.name,
      spellId: spell.id,
      spellName: spell.name,
      tradition: 'divine',
      schoolName: spell.system?.elysium?.domain ?? '',
      schoolSkillName: channeling?.name ?? 'Channeling',
      schoolSkillTotal: channelTotal,
      completed: false,
      abandoned: false,
      finalRoll: channelRollValue,
      apSpent: totalAPSpent,
      ppSpent: 0,
      fatigueAdded: 0,
      chosenTier,
      description: `<p><em>The prayer was malformed. ${channelOutcome === 'fumble'
        ? 'Critical fumble — the cleric stumbled badly.'
        : 'Channeling check failed; the patron did not hear.'} ` +
        `PP refunded; ${totalAPSpent} AP consumed.</em></p>`,
    })
    return
  }

  // Faith check (Channel succeeded).
  let wildMagic = null
  let faithRollValue = null
  let succeeded = true
  if (faithTotal < 100) {
    const fr = await rollD100()
    faithRollValue = fr.value
    if (faithRollValue > faithTotal) {
      succeeded = false
      wildMagic = await rollMagicTable('divineWildMagic')
    }
  }

  // Per-tier effect description.
  const effectByTier = spell.system?.elysium?.effectByTier ?? {}
  const tierEffect = effectByTier[String(chosenTier)] ?? effectByTier[chosenTier] ?? ''
  const damageType = spell.system?.elysium?.damageType ?? ''
  const isDamageSpell = !!spell.system?.elysium?.isDamageSpell

  const description = succeeded
    ? `<p><strong>Tier ${chosenTier} effect:</strong> ${tierEffect}</p>${spell.system?.description ?? ''}`
    : `<p><strong>Tier ${chosenTier} attempted; patron has twisted the prayer.</strong></p>` +
      `<p><em>See Wild Magic effect.</em></p>`

  await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: spell.id,
    spellName: spell.name,
    tradition: 'divine',
    schoolName: spell.system?.elysium?.domain ?? '',
    schoolSkillName: channeling?.name ?? 'Channeling',
    schoolSkillTotal: channelTotal,
    completed: succeeded,
    abandoned: !!wildMagic,
    finalRoll: channelRollValue,
    resistanceValue: succeeded ? channelRollValue : null,
    saveSkill: spell.system?.elysium?.saveSkill ?? '',
    apSpent: totalAPSpent,
    ppSpent: ppCommitted,
    fatigueAdded: 0,
    wildMagic,
    chosenTier,
    faithRollValue,
    faithTotal,
    isDamageSpell,
    damageType,
    description,
  })

  // v0.19.0 Phase C: post-success effects (sustain registration, POW loss).
  // Gated on `succeeded` — a twisted prayer (Wild Magic) does NOT start a
  // sustain or trigger POW loss. The cleric got punished enough already.
  if (succeeded) {
    // Register sustain entry for Spiritual Weapon, Spirit Guardians,
    // Investiture of Flame (and any future sustained divine spell).
    const isSustained = !!spell.system?.elysium?.isSustained
    if (isSustained) {
      const maintain = Number(spell.system?.elysium?.maintainPPPerRound) || 1
      await addSustain(actor, {
        spellId: spell.id,
        spellName: spell.name,
        ppPerRound: maintain,
        schoolName: spell.system?.elysium?.domain ?? 'Divine',
      })
    }

    // Apply POW loss for Resurrection (and any future POW-ritual spell).
    const powCostByTier = spell.system?.elysium?.powCostByTier
    if (Array.isArray(powCostByTier)) {
      await applyDivinePOWLoss(actor, spell.name, chosenTier, powCostByTier)
    }
  }
}

// Backward-compat: keep the v0.17.0 `castDivine` name as a thin wrapper
// so existing sheet bindings continue to work. They route through the
// new beginDivineCast pipeline.
export async function castDivine (actor, spell) {
  return beginDivineCast(actor, spell)
}
