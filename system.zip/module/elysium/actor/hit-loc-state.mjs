/**
 * Elysium — Hit-location state derivation
 *
 * Owns the derived state of each actor's hit-locations:
 *   - currHP, derived as max(0, maxHP - sum of wound-item values for this loc)
 *   - per-location condition flags (injured / incapacitated / unconscious)
 *     based on currHP < 1, written explicitly both ways
 *   - actor-level cascade flags (union of per-location states)
 *   - actor.system.health.value (the flat-HP pool used by the Temp HP display)
 *
 * Runs unconditionally for every actor type. Both characters and NPCs use
 * the same wound-item model (damage applied via `Item.create({type: 'wound',
 * system: {locId, value}}, {parent: actor})` in `module/combat/damage.mjs`).
 * There is no actor-type branching here.
 *
 * Sequenced after ElysiumMythrasHP.applyToActor in the prepareDerivedData
 * wrapper, because this module reads each hit-location's maxHP that
 * MythrasHP just wrote. MythrasHP's responsibility is the Mythras maxHP
 * formula only; this module does everything else hit-loc-related.
 *
 * History:
 *   - v0.22.0-alpha.5: extracted from mythras-hp.mjs + actor.mjs. Replaces
 *     the BRP-classic hit-loc loops in `_prepareCharacterData` and
 *     `_prepareNpcData` plus the wound-subtraction + condition-flag logic
 *     that was bolted onto MythrasHP.applyToActor in alpha.1-.4. Restores
 *     mythras-hp.mjs to its original focused scope (maxHP formula only).
 */

export class ElysiumHitLocState {

  /**
   * Derive currHP and condition state on every hit-location of the actor,
   * and update the actor-level cascade flags + flat-HP pool.
   *
   * Mutates `actor.system` and `item.system` in place; does not write to
   * the database (this runs inside prepareDerivedData like BRP-base's own prep).
   *
   * Side effects on actor:
   *   - actor.system.injured (boolean — union of per-loc injured)
   *   - actor.system.incapacitated (boolean — union of per-loc incapacitated)
   *   - actor.system.unconscious (boolean — union of per-loc unconscious)
   *   - actor.system.health.value (number — health.max - totalDamage)
   *
   * Side effects on each hit-location item:
   *   - item.system.currHP (number — clamped at 0)
   *   - item.system.injured (boolean, limb/abdomen)
   *   - item.system.incapacitated (boolean, chest)
   *   - item.system.unconscious (boolean, head)
   *
   * Does NOT touch: maxHP (MythrasHP owns it), bleeding, severed, dead
   * (these are written by the damage flow and survive through prep).
   */
  static applyToActor (actor) {
    if (!actor?.items?.size) return

    // Reset actor-level cascade flags. The per-location loop below
    // OR-accumulates them, so they need to start clean each prep cycle.
    actor.system.injured = false
    actor.system.incapacitated = false
    actor.system.unconscious = false

    // Build a map of locId → totalDamage by iterating wound items once.
    // O(W + L) where W = wounds, L = hit-locations. Avoids the nested
    // O(W * L) scan the original BRP-classic loop did.
    const damageByLoc = new Map()
    for (const w of actor.items) {
      if (w.type !== 'wound') continue
      const locId = w.system?.locId
      if (!locId) continue
      const value = Number(w.system?.value) || 0
      damageByLoc.set(locId, (damageByLoc.get(locId) || 0) + value)
    }

    // Apply to each hit-location. Track the total damage across all
    // locations for the flat-HP pool update below.
    let totalDamage = 0
    for (const item of actor.items) {
      if (item.type !== 'hit-location') continue

      const maxHP = Number(item.system?.maxHP) || 0
      const damage = damageByLoc.get(item.id) || 0
      const currHP = Math.max(0, maxHP - damage)

      item.system.currHP = currHP
      totalDamage += damage

      // Per-location condition flags. Write explicitly both ways so a
      // healed wound (or a max-increase via Withered removal etc.) clears
      // the flag when currHP rises back above 0.
      const isWounded = currHP < 1
      const locType = item.system?.locType || 'limb'

      if (locType === 'limb') {
        item.system.injured = isWounded
        if (isWounded) actor.system.injured = true
      } else if (locType === 'abdomen') {
        item.system.injured = isWounded
        if (isWounded) actor.system.injured = true
      } else if (locType === 'chest') {
        item.system.incapacitated = isWounded
        if (isWounded) actor.system.incapacitated = true
      } else if (locType === 'head') {
        item.system.unconscious = isWounded
        if (isWounded) actor.system.unconscious = true
      }
      // 'general' and any other locType: no per-location flag, no cascade.
    }

    // Flat-HP pool. Used by the "Temp HP" display on the actor header and
    // NPC sheet. Not used by game logic (per-location currHP and the
    // critical-hit thresholds in damage.mjs drive death/incap/etc.) but
    // displayed in several places, so it must be kept current.
    if (actor.system?.health) {
      const max = Number(actor.system.health.max) || 0
      actor.system.health.value = max - totalDamage
    }
  }
}
