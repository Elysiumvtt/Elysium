# P6.3 Prep Audit — Combat Item DataModels

Companion to `p6-prep-audit.md`. Captured 2026-05-13 against the v1.0.0-alpha.5 source tree
and ElysiumCompendium content. Covers: `weapon`, `armor`, `hit-location`.

## Compendium content

| Type | Pack | Item count |
|---|---|---|
| weapon | weapons.db | 53 |
| armor | armor.db | 26 |
| hit-location | hit-locations.db | 23 |

All three types have substantial live data; the audit-versus-template divergence is the
biggest single source of risk for P6.3.

## Schema-shape findings

### weapon: template-vs-compendium type mismatch on `elysium.force`

- **Template default**: `"M"` (string)
- **Compendium**: `int` in 53/53 items, values 0-7
- Schema MUST use `NumberField({integer: true, initial: 1, min: 0})`. Template's default
  is wrong; the DataModel's initial overrides it for fresh weapons.
- **Side finding #12 (P12)**: template.json's `weapon.elysium.force = "M"` default is
  incorrect. Pre-existing template bug. Doesn't affect P6.3 (DataModel takes precedence)
  but compendium-regenerate should fix the template at the same time.

### armor: compendium-only legacy ballistic-armor fields

These appear on all 26 armor compendium items but NO code reads them (per actor.mjs:125
comment: "v0.21.0: itm.system.av2/avr2 (BRP-classic ballistic armor) removed."):

- `av2: int` (template missing)
- `avr2: string` (template missing)
- `armBal: boolean` (template missing)
- `armVar: boolean` (template missing)

Schema MUST declare these to accept compendium drops. Same pattern as the P6.2
compendium-driven fields. Mark legacy in comments; P12 candidate: regenerate compendium
without these fields, then drop the schema declarations.

### hit-location: compendium-only legacy fields + base-template discrepancy

Compendium fields not in template:
- `bap: int` (legacy ballistic-AP — paired with the av2/avr2 family per the v0.21.0
  removal comment)
- `bapRnd: string` (legacy ballistic-AP-round, string-typed like `apRnd`)

Compendium also populates `description: ""` on every hit-location, but template.json
declares `hit-location` with `"templates": []` (no base template). Two reconciliations
possible: (a) declare description/gmDescription on hit-location's schema regardless of
template ("base"); (b) leave them off and accept that compendium drops will silently
drop the empty description. Going with **(a) — declare description + gmDescription via
makeItemBase()**. This is the cheapest fix and matches what the compendium expects;
zero code consumes hit-location.description so the only effect is "accept the data we
get". P12 candidate to align template.

### Other compendium-driven type pinning

- `weapon.enc`: 51 int + 2 float — NumberField (non-integer)
- `armor.enc`: 26 float — NumberField (non-integer)
- `armor.cost`: 26 int — NumberField (non-integer to be safe; gear.cost is non-integer
  per P6.2 audit and template.json says int 0 default which Foundry coerces fine)
- `armor.elysium.castingPenaltyOverride`: 26/26 null — NumberField with `nullable: true,
  initial: null`
- `hit-location.elysium.criticalEntry`: 23/23 null — ObjectField with `nullable: true,
  initial: null` (criticalEntry shape unknown when populated; permissive)

### Documentation-only fields (DROP — not real data)

Eight `_doc` keys in template.json that are documentation strings:

- `weapon.elysium._reloadType_doc`
- `weapon.elysium._damageBonusMultiplier_doc`
- `armor.elysium._layer_doc`
- `armor.elysium._wornStratum_doc`
- `armor.elysium._apMax_doc`
- `hit-location.elysium._bodyPart_doc`
- `hit-location.elysium._side_doc`
- `hit-location.elysium._index_doc`

Schema does NOT declare these; cleanData drops any stored values.

### Field-shape decisions for permissive fields

| Field | Shape | Reason |
|---|---|---|
| `weapon.elysium.special` | `ArrayField<StringField>` | Template default `[]`; zero compendium content has non-empty; zero code reads. Permissive but typed. |
| `hit-location.wounds` | `ArrayField<ObjectField>` | Template default `[]`; compendium has `[]`; live wounds embed via the damage system at runtime — shape is the WoundDataModel object but stored at runtime, not at content-load. Use permissive ObjectField. |
| `hit-location.elysium.criticalRolls` | `ArrayField<ObjectField>` | Empty in all 23 compendium. P12 to tighten. |
| `hit-location.elysium.creatureTags` | `ArrayField<StringField>` | Mirrors `npc.elysium.creatureTags` and `character.elysium.creatureTags` from P5. Per P5 audit. |
| `hit-location.elysium.locationConditions` | `ArrayField<ObjectField>` | Template default `[]`; no compendium content; no code references. P12 to tighten. |

## String-enum locking decisions

With audit data I can lock more confidently than P6.2 (where everything was content-creator-
extensible). Lock criteria: ≤4 values, mechanically driven, template default in list.

### LOCKED choices

| Field | Choices | Initial |
|---|---|---|
| `weapon.weaponType` | `['melee', 'ranged']` | `''` (template uses empty string but compendium always has one of these — initial preserves template-empty) |
| `weapon.hands` | `['1H', '2H']` | `'1H'` |
| `weapon.elysium.weaponSize` | `['S', 'M', 'L']` | `'M'` |
| `weapon.elysium.damageType` | `['bludgeoning', 'piercing', 'slashing']` | `'slashing'` |
| `weapon.elysium.reloadType` | `['none', 'quick', 'standard', 'slow']` | `'none'` |
| `armor.elysium.flexibility` | `['flexible', 'inflexible']` | `'flexible'` |
| `armor.elysium.layer` | `['worn', 'natural', 'magical']` | `'worn'` (per _layer_doc; compendium has worn+magical, 'natural' from doc) |
| `armor.elysium.wornStratum` | `['soft', 'mail', 'plate']` | `'soft'` |
| `hit-location.locType` | `['abdomen', 'chest', 'general', 'head', 'limb']` | `'limb'` |

**`weapon.weaponType` edge case**: template default is `''` but the compendium always populates
a real value. If I lock with `''` in choices, that allows the unset value; if I don't include
`''`, then the default `''` would itself be invalid. Decision: include `''` in choices to
allow the unset state. Choices: `['', 'melee', 'ranged']`.

### NOT LOCKED (intentionally free)

| Field | Reason |
|---|---|
| `weapon.elysium.reach` | 4 values observed (S/M/L/VL) but extensible (XL, etc. plausible) |
| `weapon.elysium.force` | 0-7 in compendium; mechanic could extend the range |
| `weapon.range1/2/3` | Single-char codes; templates use '' for range2/3; not worth locking |
| `weapon.skill1/skill2` | i.skill.* UUID-shaped strings; never lock UUIDs |
| `weapon.ammoType` | Unknown range; content-extensible |
| `armor.elysium.material` | 14 observed values; content-creator-extensible |
| `armor.elysium.castingLocation` | Only 'arm' observed; insufficient ground-truth to lock |
| `armor.equipStatus`, `weapon.equipStatus` | Side-finding #8 from P6.2: normalizer corrects legacy values POST-validation, so locking choices rejects legacy-content drops before the normalizer can run. Free. |
| `hit-location.creatureType` | 6 values observed; mirrors `npc.elysium.creatureType` and `character.elysium.creatureType` which were locked in P5. **Consistency note**: P5 locked these; P6.3 should too. After consultation: lock to the union of compendium values + the P5-locked actor values. |

### CORRECTION on hit-location.creatureType after the actor-side check

P5 NPCDataModel locked `creatureType` to `['humanoid', 'beast', 'undead', 'construct',
'spirit', 'elemental', 'plant', 'aberration']`. Compendium hit-locations use a slightly
different but overlapping set: `['amorphous', 'generic', 'hexapod', 'humanoid', 'quadruped',
'serpentine']`. Two issues:
1. Compendium has values P5 didn't lock ('amorphous', 'generic', 'hexapod', 'quadruped', 'serpentine')
2. P5 has values compendium doesn't use ('beast', 'undead', 'construct', 'spirit', 'elemental', 'plant', 'aberration')

These are different concepts despite sharing a field name — actor.creatureType is the
**actor's** creature type for tagging purposes; hit-location.creatureType is the **template
set** the location belongs to (e.g. all humanoid hit locations have creatureType='humanoid'
to be auto-assigned when creating a humanoid actor). The proper fix is to rename one of
them. P12 candidate. For P6.3: leave hit-location.creatureType as a free StringField (no
choices lock) to avoid breaking compendium drops. **Side finding #13.**

## Field-by-field schema spec

### hit-location.mjs (20 own + 12 elysium = ~32 slots; declares base despite template)

```js
import { makeItemBase } from './_shared.mjs'

class HitLocationDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),  // description + gmDescription; declared despite template `templates: []`
      displayName:    new fields.StringField({ initial: '' }),
      creatureType:   new fields.StringField({ initial: '' }),  // FREE — see #13
      lowRoll:        new fields.NumberField({ integer: true, initial: 0 }),
      highRoll:       new fields.NumberField({ integer: true, initial: 0 }),
      fractionHP:     new fields.NumberField({ initial: 1 }),    // non-integer (could be 0.5)
      fractionENC:    new fields.NumberField({ initial: 1 }),    // non-integer
      map:            new fields.NumberField({ integer: true, initial: 0 }),
      hide:           new fields.BooleanField({ initial: true }),
      locType:        new fields.StringField({ initial: 'limb', choices: ['abdomen', 'chest', 'general', 'head', 'limb'] }),
      bleeding:       new fields.BooleanField({ initial: false }),
      dead:           new fields.BooleanField({ initial: false }),
      severed:        new fields.BooleanField({ initial: false }),
      incapacitated:  new fields.BooleanField({ initial: false }),
      currHP:         new fields.NumberField({ integer: true, initial: 0 }),
      maxHP:          new fields.NumberField({ integer: true, initial: 0 }),
      // wounds: array of stored wound objects (separate from the wound DataModel which is per-item)
      wounds:         new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
      adj:            new fields.NumberField({ integer: true, initial: 0 }),
      apRnd:          new fields.StringField({ initial: '0' }),  // string per template
      ap:             new fields.NumberField({ integer: true, initial: 0, min: 0 }),

      // Legacy ballistic fields (compendium-driven; pre-v0.21.0 removal; no code reads)
      bapRnd:         new fields.StringField({ initial: '0' }),  // compendium-only
      bap:            new fields.NumberField({ integer: true, initial: 0, min: 0 }),  // compendium-only

      elysium: new fields.SchemaField({
        creatureSubtype: new fields.StringField({ initial: '' }),
        creatureTags:    new fields.ArrayField(new fields.StringField(), { initial: [] }),
        criticalRolls:   new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
        criticalEntry:   new fields.ObjectField({ nullable: true, initial: null }),
        locationConditions: new fields.ArrayField(new fields.ObjectField(), { initial: [] }),
        maxHPModifier:   new fields.NumberField({ integer: true, initial: 0 }),
        bodyPart:        new fields.StringField({ initial: '' }),
        side:            new fields.StringField({ initial: '' }),
        index:           new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // _bodyPart_doc, _side_doc, _index_doc DROPPED — documentation only
      }),
    }
  }
}
```

### armor.mjs (21 own + 4 compendium-only legacy + base + 8 elysium = ~35 slots)

```js
class ArmorDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      av1:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      avr1:       new fields.StringField({ initial: '' }),
      burden:     new fields.StringField({ initial: '' }),
      enc:        new fields.NumberField({ initial: 0 }),           // non-integer
      mnplmod:    new fields.NumberField({ integer: true, initial: 0 }),
      percmod:    new fields.NumberField({ integer: true, initial: 0 }),
      physmod:    new fields.NumberField({ integer: true, initial: 0 }),
      stealthmod: new fields.NumberField({ integer: true, initial: 0 }),
      sizRng:     new fields.NumberField({ integer: true, initial: 0 }),
      time:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      quantity:   new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      ppMax:      new fields.NumberField({ integer: true, initial: 0 }),
      ppCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      price:      new fields.StringField({ initial: '' }),
      cost:       new fields.NumberField({ initial: 0 }),           // non-integer
      hitlocID:   new fields.StringField({ initial: '' }),
      equipStatus: new fields.StringField({ initial: 'stowed' }),   // FREE per #8
      coverage:   new fields.StringField({ initial: '' }),
      pSCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      pSMax:      new fields.NumberField({ integer: true, initial: 0 }),

      // Legacy ballistic-armor fields (compendium-driven; pre-v0.21.0 removal)
      av2:        new fields.NumberField({ integer: true, initial: 0 }),
      avr2:       new fields.StringField({ initial: '' }),
      armBal:     new fields.BooleanField({ initial: false }),
      armVar:     new fields.BooleanField({ initial: false }),

      elysium: new fields.SchemaField({
        flexibility:           new fields.StringField({ initial: 'flexible', choices: ['flexible', 'inflexible'] }),
        material:              new fields.StringField({ initial: 'cloth' }),  // FREE
        layerOrder:            new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        castingLocation:       new fields.StringField({ initial: 'arm' }),    // FREE
        castingPenaltyOverride: new fields.NumberField({ nullable: true, initial: null }),
        containedIn:           new fields.StringField({ initial: '' }),
        layer:                 new fields.StringField({ initial: 'worn', choices: ['worn', 'natural', 'magical'] }),
        wornStratum:           new fields.StringField({ initial: 'soft', choices: ['soft', 'mail', 'plate'] }),
        apMax:                 new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // _layer_doc, _wornStratum_doc, _apMax_doc DROPPED
      }),
    }
  }
}
```

### weapon.mjs (51 own + base + 14 elysium = ~67 slots)

```js
class WeaponDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    return {
      ...makeItemBase(),
      weaponType: new fields.StringField({ initial: '', choices: ['', 'melee', 'ranged'] }),
      skill1:     new fields.StringField({ initial: 'none' }),  // i.skill.*-shaped UUIDs
      skill2:     new fields.StringField({ initial: 'none' }),
      dmg1:       new fields.StringField({ initial: '0' }),     // dice formula
      dmg2:       new fields.StringField({ initial: '' }),
      dmg3:       new fields.StringField({ initial: '' }),
      special:    new fields.StringField({ initial: '' }),      // free-text; NOT elysium.special
      // 14 damage-type flags
      burst:      new fields.BooleanField({ initial: false }),
      stun:       new fields.BooleanField({ initial: false }),
      entangle:   new fields.BooleanField({ initial: false }),
      explosive:  new fields.BooleanField({ initial: false }),
      fire:       new fields.BooleanField({ initial: false }),
      pierce:     new fields.BooleanField({ initial: false }),
      sonic:      new fields.BooleanField({ initial: false }),
      choke:      new fields.BooleanField({ initial: false }),
      cold:       new fields.BooleanField({ initial: false }),
      emp:        new fields.BooleanField({ initial: false }),
      poison:     new fields.BooleanField({ initial: false }),
      disease:    new fields.BooleanField({ initial: false }),
      acid:       new fields.BooleanField({ initial: false }),
      constrict:  new fields.BooleanField({ initial: false }),
      spclDmg:    new fields.BooleanField({ initial: false }),

      db:         new fields.NumberField({ integer: true, initial: 0 }),  // damage bonus
      att:        new fields.NumberField({ integer: true, initial: 0 }),  // attack mod
      range1:     new fields.StringField({ initial: 'S' }),
      range2:     new fields.StringField({ initial: '' }),
      range3:     new fields.StringField({ initial: '' }),
      hands:      new fields.StringField({ initial: '1H', choices: ['1H', '2H'] }),
      crew:       new fields.StringField({ initial: '' }),
      hp:         new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      ap:         new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      hpCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      ammoType:   new fields.StringField({ initial: '' }),
      ammo:       new fields.NumberField({ integer: true, initial: 0 }),
      ammoCurr:   new fields.NumberField({ integer: true, initial: 0 }),
      mal:        new fields.NumberField({ integer: true, initial: 0 }),
      rof:        new fields.NumberField({ integer: true, initial: 0 }),
      radius:     new fields.NumberField({ integer: true, initial: 0 }),
      parry:      new fields.BooleanField({ initial: true }),
      str:        new fields.NumberField({ integer: true, initial: 0 }),  // STR requirement
      dex:        new fields.NumberField({ integer: true, initial: 0 }),  // DEX requirement
      enc:        new fields.NumberField({ initial: 0 }),                  // non-integer
      price:      new fields.StringField({ initial: '' }),
      cost:       new fields.NumberField({ initial: 0 }),                  // non-integer
      equipStatus: new fields.StringField({ initial: 'stowed' }),          // FREE per #8
      coverage:   new fields.StringField({ initial: '' }),
      quantity:   new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      npcVal:     new fields.NumberField({ integer: true, initial: 0 }),
      pSCurr:     new fields.NumberField({ integer: true, initial: 0 }),
      pSMax:      new fields.NumberField({ integer: true, initial: 0 }),

      elysium: new fields.SchemaField({
        isMelee:        new fields.BooleanField({ initial: true }),
        weaponSize:     new fields.StringField({ initial: 'M', choices: ['S', 'M', 'L'] }),
        reach:          new fields.StringField({ initial: 'M' }),         // FREE — extensible (XL)
        // CRITICAL: force is INT in compendium (0-7), not string. Template's "M" default is wrong.
        force:          new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        rangeClose:     new fields.NumberField({ integer: true, initial: 0 }),
        rangeEffective: new fields.NumberField({ integer: true, initial: 0 }),
        rangeLong:      new fields.NumberField({ integer: true, initial: 0 }),
        damageType:     new fields.StringField({ initial: 'slashing', choices: ['bludgeoning', 'piercing', 'slashing'] }),
        thrownPenalty:  new fields.NumberField({ integer: true, initial: 0 }),
        special:        new fields.ArrayField(new fields.StringField(), { initial: [] }),  // permissive
        containedIn:    new fields.StringField({ initial: '' }),
        reloadType:     new fields.StringField({ initial: 'none', choices: ['none', 'quick', 'standard', 'slow'] }),
        damageBonusMultiplier: new fields.NumberField({ initial: 1.0 }),  // non-integer (0.5, 2.0 documented)
        // _reloadType_doc, _damageBonusMultiplier_doc DROPPED
      }),
    }
  }
}
```

## init.mjs

Three imports + three registrations.

## Smoke test plan

Same shape as P6.2 + augmented compendium drop:
1. Boot — 3 new DataModels with field counts: weapon ~52, armor ~24, hit-location ~22 (depending on count method).
2. Create — `Item.create({type, name})` for each.
3. Defaults — spot-check enum-locked defaults, the legacy compendium-only fields,
   nullable fields (`armor.elysium.castingPenaltyOverride === null`,
   `hit-location.elysium.criticalEntry === null`).
4. Persistence roundtrips:
   - NumberField (positive + negative + float): weapon.dex, armor.percmod (negative ok),
     armor.enc = 0.8 (float)
   - StringField (free): weapon.dmg1 = '2d6+1', armor.material = 'mithral'
   - StringField with choices (valid): weapon.weaponType = 'ranged'
   - StringField with choices (invalid): weapon.weaponType = 'magical' → reject
   - BooleanField: weapon.parry = false
   - HTMLField: armor.description = '<p>Plate</p>'
   - Deep nested: weapon.elysium.weaponSize = 'L'
   - ArrayField<String>: weapon.elysium.special = ['parry-modifier']
   - Nullable NumberField: armor.elysium.castingPenaltyOverride = -5, then null
   - Compendium-driven new field: armor.armBal = true (legacy field), bap on hit-loc
5. **Compendium drop test** — drop 3 items (1 weapon, 1 armor, 1 hit-location) onto a
   character; expect zero validation errors. Verify the `force: int` survives roundtrip,
   the `armBal`/`armVar` legacy fields persist, the null criticalEntry stays null.
6. Regression: P6.1 + P6.2 still work; actors still work.
7. Cleanup.

## Side findings

- **#12** — template.json's `weapon.elysium.force = "M"` default is type-incorrect (compendium
  uses int 0-7). Schema overrides with NumberField; template fix is P12.
- **#13** — `hit-location.creatureType` and actor-side `creatureType` are different concepts
  with same field name (compendium uses humanoid/quadruped/etc as template-set tags; actor-side
  uses humanoid/beast/undead/etc as creature classification). P12 should rename one.

## Three side findings continued from P6.2/P6.1 still pending

#6 (htmlFields=gmNotes), #7 (wound.created), #8 (equipStatus normalizer), #9 (statMods case),
#10 (permissive ancestry inner shapes), #11 (favouredEnemy typo). All deferred to P12 or P6.6.
