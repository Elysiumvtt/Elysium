/**
 * Elysium Rules Module — entry point
 * 
 * This module extends the BRP system with the Elysium ruleset.
 * All rules are toggleable via settings unless they form mechanical
 * load-bearing extensions (e.g. data model fields).
 * 
 * Architecture:
 *   - Settings register all toggles (one menu per category)
 *   - Hooks attach Elysium logic to BRP events without modifying BRP
 *   - Active Effect templates implement the buff/debuff/condition system
 *   - Data extensions live in flags.elysium on items and actors
 *   - Critical tables, conditions, fatigue and ancestry use module data
 */

import { ELYSIUM } from './config/config.mjs'
import { registerSettings } from './settings/register-settings.mjs'
import { registerHooks } from './hooks/register-hooks.mjs'
import { registerHandlebarsHelpers } from './helpers/handlebars.mjs'
import { ElysiumActorExtension } from './actor/actor-extension.mjs'
import { ElysiumActiveEffectFactory } from './active-effects/factory.mjs'
import { ElysiumCriticalRoller } from './critical/critical-roller.mjs'
import { ElysiumFatigueManager } from './fatigue/fatigue-manager.mjs'
import { ElysiumAncestryDrop } from './actor/ancestry-drop.mjs'
import { ElysiumMagic } from './magic/magic.mjs'
import { ElysiumCombatExtension } from './combat/combat-extension.mjs'
import { ElysiumCharacterCreation } from './creation/creation.mjs'

Hooks.once('init', () => {
  console.log('Elysium Rules | Initialising')

  // Expose globals
  CONFIG.ELYSIUM = ELYSIUM
  game.elysium = {
    config: ELYSIUM,
    activeEffects: ElysiumActiveEffectFactory,
    criticalRoller: ElysiumCriticalRoller,
    fatigue: ElysiumFatigueManager,
    ancestryDrop: ElysiumAncestryDrop,
    magic: ElysiumMagic,
    combat: ElysiumCombatExtension,
    creation: ElysiumCharacterCreation,
  }

  // Register all settings
  registerSettings()

  // Register handlebars helpers
  registerHandlebarsHelpers()

  // Register all hooks
  registerHooks()

  console.log('Elysium Rules | Initialised')
})

Hooks.once('ready', () => {
  console.log('Elysium Rules | Ready')

  // Compatibility check
  if (game.system.id !== 'brp') {
    ui.notifications.error(
      'Elysium Rules requires the BRP (Basic Role Playing) system.'
    )
    return
  }

  // Verify settings are coherent
  ElysiumActorExtension.verifyAllActors()
})
