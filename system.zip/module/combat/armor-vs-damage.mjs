/**
 * Elysium — Armor vs Damage Type resolution (v0.19.0)
 *
 * Implements the cross-tradition damage-vs-armor interaction table locked
 * in DESIGN-sorcery-v0.19.0.md. Every damage type interacts with every
 * armor material category differently:
 *
 *   FULL AP        — armor protects fully against this damage type
 *   HALF AP        — armor protects at half value (round down)
 *   NO AP          — armor doesn't reduce this damage at all
 *   DAMAGES ARMOR  — armor protects fully but is itself damaged
 *
 * Armor pieces declare their material via `system.elysium.material`:
 *   'cloth'  — gambeson, robes, padded — flexible insulation
 *   'chain'  — chain mail, scale shirt — flexible metal
 *   'scale'  — scale armor — semi-rigid metal
 *   'plate'  — half plate, full plate — rigid metal
 *
 * Damage types are the locked v0.19.0 list:
 *   slashing, piercing, bludgeoning, force            — full AP universally
 *   fire, cold                                         — half AP vs metal, full vs cloth
 *   lightning                                          — full AP vs cloth, NO AP vs metal
 *   corrosive                                          — full AP (no special wear; deprecated alpha.9)
 *   sonic, poison, necrotic, psychic, radiant,         — bypass armor universally
 *     distortion
 *
 * Usage from cast pipelines:
 *
 *   import { applyArmorToDamage } from '../combat/armor-vs-damage.mjs'*
 *   const { final, breakdown } = applyArmorToDamage(
 *     rawDamage,      // number — pre-armor damage roll
 *     damageType,     // string — one of the locked types
 *     targetActor,    // Actor — the receiving actor
 *     hitLocationId,  // string — the targeted hit-location item _id
 *   )
 *
 * Returns:
 *   {
 *     final: number,            // post-armor damage (≥ 0)
 *     totalEffectiveAP: number, // total AP applied
 *     breakdown: Array<{
 *       pieceName: string,
 *       material: string,
 *       rawAP: number,
 *       category: 'full' | 'half' | 'none',
 *       effectiveAP: number,
 *     }>,
 *   }
 *
 * The breakdown supports chat-card display: "Lightning bolt 16 damage,
 * Chain Hauberk av 3 bypassed (lightning conducts), final 16 to chest."
 */

/**
 * Damage-type-to-armor-interaction category lookup.
 *
 * Each entry is a function `(material) => category` returning one of:
 *   'full'      — armor's full av applies
 *   'half'      — armor's av/2 applies (round down)
 *   'none'      — armor doesn't reduce damage
 *
 * Materials: 'cloth', 'chain', 'scale', 'plate'. Defaults to 'full'
 * for unknown materials (defensive — most safe assumption).
 */
/**
 * Bucket the material into a damage-resolution class. Reads from
 * ELYSIUM.ARMOR_MATERIALS.<name>.damageBucket if available; otherwise
 * falls back to the v0.19.x simple cloth/non-cloth split for backward
 * compat with old records.
 *
 *   'organic' — cloth, leather, fur, hide. Insulates against fire/cold,
 *               non-conductive (full AP vs lightning).
 *   'metal'   — bronze, iron, steel, mythril, adamantite. Conducts
 *               electricity (none vs lightning), half AP vs fire/cold.
 *   'rigid'   — bone, dragonscale. Non-conductive (full AP vs lightning)
 *               but half AP vs fire/cold like metal.
 *   'natural' — intrinsic body armor; treated as 'organic' for thermal.
 */
function _materialBucket (material) {
  const m = String(material || '').toLowerCase().trim()
  const def = globalThis.CONFIG?.ELYSIUM?.ARMOR_MATERIALS?.[m]
  if (def?.damageBucket) return def.damageBucket
  // Fallback for legacy records that just had material='cloth' vs anything else
  if (m === 'cloth' || m === 'leather' || m === 'fur' || m === 'hide' || m === 'natural') return 'organic'
  if (m === 'bone' || m === 'dragonscale') return 'rigid'
  return 'metal'
}

/**
 * Damage-type-to-armor-interaction category lookup.
 *
 * Each entry is a function `(material) => category` returning one of:
 *   'full'      — armor's full av applies
 *   'half'      — armor's av/2 applies (round down)
 *   'none'      — armor doesn't reduce damage
 *   'corrosive' — full av applies, but armor takes wear (handled separately)
 */
/**
 * Damage-type-to-armor-interaction category lookup.
 *
 * Each entry is a function `(material) => category` returning one of:
 *   'full'      — armor's full av applies
 *   'half'      — armor's av/2 applies (round down)
 *   'none'      — armor doesn't reduce damage
 */
const DAMAGE_VS_ARMOR = {
  // FULL AP universally — physical impact damage
  slashing:    () => 'full',
  piercing:    () => 'full',
  bludgeoning: () => 'full',
  force:       () => 'full',

  // FIRE / COLD — organic insulates (full AP); metal and rigid conduct heat
  // through the armor (half AP).
  fire: (material) => (_materialBucket(material) === 'organic' ? 'full' : 'half'),
  cold: (material) => (_materialBucket(material) === 'organic' ? 'full' : 'half'),

  // LIGHTNING — bypasses metal (conductor); organic and rigid block fully.
  lightning: (material) => (_materialBucket(material) === 'metal' ? 'none' : 'full'),

  // CORROSIVE — v0.22.0-alpha.9: no longer has special armor-wear effect.
  // Now treated as full AP like other physical types. Armor only takes
  // damage from critical hits (handled in armor-wear.mjs, alpha.10+).
  corrosive: () => 'full',

  // BYPASS types — armor doesn't reduce.
  sonic:      () => 'none',
  poison:     () => 'none',
  necrotic:   () => 'none',
  psychic:    () => 'none',
  radiant:    () => 'none',
  distortion: () => 'none',
}

/**
 * Apply armor reduction to a raw damage value per the v0.19.0
 * damage-vs-armor table. See module header docs.
 *
 * @param {number} rawDamage     — pre-armor damage (positive integer)
 * @param {string} damageType    — one of the locked damage types
 * @param {Actor}  targetActor   — the damaged actor
 * @param {string} hitLocationId — the targeted hit-location item _id
 * @returns {{final: number, totalEffectiveAP: number, breakdown: Array}}
 */
export function applyArmorToDamage (rawDamage, damageType, targetActor, hitLocationId) {
  // Defensive: zero/negative input passes through unchanged
  if (!rawDamage || rawDamage <= 0) {
    return { final: 0, totalEffectiveAP: 0, breakdown: [] }
  }

  // If we can't identify the damage type, treat as full AP (safer default).
  // This protects against authoring typos like 'sonic ' or 'Slashing'.
  const dtKey = String(damageType || '').toLowerCase().trim()
  const interactionFn = DAMAGE_VS_ARMOR[dtKey] || (() => 'full')

  // Defensive: missing actor/location → no armor data, raw damage passes
  if (!targetActor || !hitLocationId) {
    return { final: rawDamage, totalEffectiveAP: 0, breakdown: [] }
  }

  // Find the targeted hit-location item
  const hitLoc = targetActor.items.get(hitLocationId)
  if (!hitLoc || hitLoc.type !== 'hit-location') {
    return { final: rawDamage, totalEffectiveAP: 0, breakdown: [] }
  }

  // Identify which armor pieces cover this location and are equipped.
  // BRP-base convention: armor.system.hitlocID matches hit-location._id; only
  // pieces with equipStatus === 'equipped' actually protect.
  const armorPieces = targetActor.items.filter(itm =>
    itm.type === 'armor' &&
    itm.system?.hitlocID === hitLocationId &&
    itm.system?.equipStatus === 'equipped'
  )

  // Compute effective AP per piece per the table
  let totalEffectiveAP = 0
  const breakdown = []

  for (const piece of armorPieces) {
    const rawAP = Number(piece.system?.av1) || 0
    if (rawAP === 0) continue

    const material = String(piece.system?.elysium?.material || '').toLowerCase() || 'cloth'
    const category = interactionFn(material)

    let effectiveAP = 0
    switch (category) {
      case 'full':
        effectiveAP = rawAP
        break
      case 'half':
        effectiveAP = Math.floor(rawAP / 2)
        break
      case 'none':
        effectiveAP = 0
        break
    }

    totalEffectiveAP += effectiveAP
    breakdown.push({
      pieceName: piece.name,
      material,
      rawAP,
      category,
      effectiveAP,
      source: 'armor',
    })
  }

  // v0.22.0-alpha.7: passive-block AP from equipped weapons/shields
  // covering this hit-location. Stacks with worn armor; applied as
  // flat AP (no damage-type interaction — passive block works like
  // cover, which Mythras core does not subject to material-vs-damage
  // adjustments). Each contributing item adds its `system.ap` to the
  // breakdown with source='passive-block' for chat-card display.
  try {
    const csApi = game.system?.api?.elysium?.coveringStance
    if (csApi?.getPassivelyBlockingItemsForLocation) {
      const pbItems = csApi.getPassivelyBlockingItemsForLocation(targetActor, hitLocationId)
      for (const it of pbItems) {
        const ap = Number(it.system?.ap) || 0
        if (ap === 0) continue
        totalEffectiveAP += ap
        breakdown.push({
          pieceName: it.name,
          material: '',
          rawAP: ap,
          category: 'full',
          effectiveAP: ap,
          source: 'passive-block',
        })
      }
    }
  } catch (err) {
    console.warn('Elysium | covering-stance AP gather failed:', err)
  }

  const final = Math.max(0, rawDamage - totalEffectiveAP)
  return { final, totalEffectiveAP, breakdown }
}

/**
 * Format a breakdown for chat-card display. Returns an HTML string.
 * Designed for inclusion in cast-card chat templates.
 *
 * @param {Array} breakdown — from applyArmorToDamage
 * @param {number} rawDamage — original damage
 * @param {number} final     — post-armor damage
 * @returns {string} HTML
 */
export function formatArmorBreakdownHTML (breakdown, rawDamage, final) {
  if (!breakdown?.length) {
    return `<div class="elysium-armor-breakdown">No armor on hit location · ${rawDamage} damage</div>`
  }

  const rows = breakdown.map(b => {
    const label =
      b.category === 'full' ? `${b.effectiveAP} AP` :
      b.category === 'half' ? `${b.effectiveAP} AP (half of ${b.rawAP}, ${b.material} vs damage type)` :
      b.category === 'none' ? `bypassed (${b.material} vs damage type)` :
      `${b.effectiveAP} AP`
    return `<li><strong>${b.pieceName}</strong> — ${label}</li>`
  }).join('')

  return `
    <div class="elysium-armor-breakdown">
      <p>Damage ${rawDamage} → after armor ${final}</p>
      <ul>${rows}</ul>
    </div>
  `
}

/**
 * Roll a random hit location on the given actor. Returns the matching
 * hit-location item (or null if the actor has no locations).
 *
 * The roll is a d20 mapped through each location's `lowRoll`/`highRoll`
 * range. If the actor's locations don't cover the full 1-20 range, an
 * unmapped roll falls through to the closest location by sort order.
 *
 * @param {Actor} actor
 * @returns {Promise<Item|null>}
 */
export async function rollRandomHitLocation (actor) {
  if (!actor) return null
  const locs = actor.items.filter(i => i.type === 'hit-location')
  if (locs.length === 0) return null
  if (locs.length === 1) return locs[0]

  const roll = await new Roll('1d20').roll()
  const value = roll.total

  // Try to find a location whose range covers this d20 roll.
  for (const loc of locs) {
    const low = Number(loc.system?.lowRoll) || 0
    const high = Number(loc.system?.highRoll) || 0
    if (value >= low && value <= high) return loc
  }

  // No match (incomplete location table?) — return the highest-range
  // location as a fallback. Sort by lowRoll descending and take the first.
  const sorted = [...locs].sort((a, b) =>
    (Number(b.system?.lowRoll) || 0) - (Number(a.system?.lowRoll) || 0)
  )
  return sorted[0]
}

/**
 * Roll N distinct random hit locations on the given actor.
 *
 * If N >= location count, returns all locations. Otherwise rolls N times,
 * de-duplicating on the fly. Capped at 20 attempts to prevent infinite
 * loops on weird location tables.
 *
 * @param {Actor} actor
 * @param {number} count
 * @returns {Promise<Array<Item>>}
 */
export async function rollMultipleHitLocations (actor, count) {
  if (!actor || !count || count <= 0) return []
  const allLocs = actor.items.filter(i => i.type === 'hit-location')
  if (allLocs.length === 0) return []
  if (count >= allLocs.length) return allLocs

  const picked = []
  const seen = new Set()
  let attempts = 0
  while (picked.length < count && attempts < 20) {
    attempts++
    const loc = await rollRandomHitLocation(actor)
    if (!loc) break
    if (seen.has(loc._id)) continue
    seen.add(loc._id)
    picked.push(loc)
  }
  return picked
}
