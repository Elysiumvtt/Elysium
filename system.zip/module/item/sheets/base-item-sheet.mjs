import { ElysiumIDEditor } from '../../elysiumid/elysiumid-editor.mjs'

const { api, sheets } = foundry.applications;

export class ElysiumItemSheetV2 extends api.HandlebarsApplicationMixin(sheets.ItemSheetV2) {
  constructor(options = {}) {
    super(options);
  }

  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'sheet', 'item'],
    position: {
      width: 520,
      height: 620
    },
    window: {
      resizable: true,
    },
    tag: "form",
    form: {
      submitOnChange: true,
    },
    actions: {
      onEditImage: this._onEditImage,
      editElysiumID: this._onEditElysiumID,
      itemToggle: this._onItemToggle,
    }
  }

  /**
   * Sub-classes override to declare their tab ordering. If null, the sheet
   * is single-page (no tabs strip, header + details only). Description and
   * gmNotes inclusion is implicit in the array when present.
   *
   * Example tabbed: static TAB_ORDER = ['header', 'tabs', 'details', 'effects', 'description'];
   * (gmNotes auto-appended for GMs when PARTS.gmNotes is defined.)
   *
   * Example single-page: static TAB_ORDER = null;
   *
   * P10 cluster 2 (alpha.39) addition.
   */
  static TAB_ORDER = null;

  /**
   * Hoisted base implementation. Single-page mode (TAB_ORDER null) emits
   * only header + details. Tabbed mode emits TAB_ORDER and appends gmNotes
   * for GMs when defined in PARTS.
   *
   * P10 cluster 4 (alpha.42) resilience fix REVERTED for diagnostic.
   *
   * Sub-classes that need finer control may still override this method.
   */
  _configureRenderOptions(options) {
    super._configureRenderOptions(options);
    if (this.constructor.TAB_ORDER) {
      options.parts = [...this.constructor.TAB_ORDER];
      if (game.user.isGM
          && this.constructor.PARTS?.gmNotes
          && !options.parts.includes('gmNotes')) {
        options.parts.push('gmNotes');
      }
    } else {
      options.parts = ['header', 'details'];
    }
  }

  /**
   * Build the tabs context map driven by TAB_ORDER. Returns empty object
   * for single-page sheets. Each tab gets {id, label, group, cssClass}.
   * Sub-classes can add type-specific tabs (e.g. allegiance.benefits) by
   * overriding _preparePartContext for those parts.
   */
  _getTabs(parts) {
    if (!this.constructor.TAB_ORDER) return {};
    const tabGroup = 'primary';
    if (!this.tabGroups[tabGroup]) {
      if (game.settings.get('elysium', 'defaultTab')) {
        this.tabGroups[tabGroup] = 'description';
      } else {
        this.tabGroups[tabGroup] = 'details';
      }
    }
    return parts.reduce((tabs, partId) => {
      const tab = {
        cssClass: '',
        group: tabGroup,
        id: '',
        icon: '',
        label: 'Elysium.',
      };
      switch (partId) {
        case 'header':
        case 'tabs':
          return tabs;
        case 'details':
          tab.id = 'details';
          tab.label += 'details';
          break;
        case 'effects':
          tab.id = 'effects';
          tab.label += 'effects';
          break;
        case 'description':
          tab.id = 'description';
          tab.label += 'description';
          break;
        case 'gmNotes':
          tab.id = 'gmNotes';
          tab.label += 'gmNotes';
          break;
        case 'benefits':
          tab.id = 'benefits';
          tab.label += 'benefits';
          break;
        default:
          // Unknown part — sub-classes may override to handle their own
          tab.id = partId;
          tab.label += partId;
      }
      if (this.tabGroups[tabGroup] === tab.id) tab.cssClass = 'active';
      tabs[partId] = tab;
      return tabs;
    }, {});
  }

  /**
   * Default _preparePartContext for the 6 standard shell parts. Wires
   * context.tab from context.tabs (when tabbed) and enriches description /
   * gmNotes / benefits HTMLFields.
   *
   * Sub-classes call super._preparePartContext(...) then layer their own
   * cases on top (or omit super-call when overriding entirely).
   */
  async _preparePartContext(partId, context) {
    switch (partId) {
      case 'details':
        if (context.tabs?.[partId]) context.tab = context.tabs[partId];
        // Single-page sheets inline description + gmnotes inside their
        // details body, so the enrichment must happen on the 'details'
        // part. Tabbed sheets enrich via the 'description' / 'gmNotes'
        // cases below where the PARTs run independently.
        if (!this.constructor.TAB_ORDER) {
          context.enrichedDescription = await this._enrichField('description');
          if (game.user.isGM) {
            context.enrichedGMDescription = await this._enrichField('gmDescription');
          }
        }
        break;
      case 'effects':
        if (context.tabs?.[partId]) context.tab = context.tabs[partId];
        break;
      case 'description':
        if (context.tabs?.[partId]) context.tab = context.tabs[partId];
        context.enrichedDescription = await this._enrichField('description');
        break;
      case 'gmNotes':
        if (context.tabs?.[partId]) context.tab = context.tabs[partId];
        context.enrichedGMDescription = await this._enrichField('gmDescription');
        break;
      case 'benefits':
        if (context.tabs?.[partId]) context.tab = context.tabs[partId];
        context.enrichedBenefits = await this._enrichField('benefits');
        break;
    }
    return context;
  }

  /**
   * Helper — enrich a system HTMLField for ProseMirror display.
   */
  async _enrichField(fieldName) {
    return foundry.applications.ux.TextEditor.implementation.enrichHTML(
      this.item.system[fieldName] ?? '',
      {
        secrets: this.document.isOwner,
        rollData: this.document.getRollData(),
        relativeTo: this.document,
      }
    );
  }

  //Add ElysiumID Editor Button as seperate icon on the Window header
  async _renderFrame(options) {
    const frame = await super._renderFrame(options);
    //define button
    const sheetElysiumID = this.item.flags?.elysium?.elysiumidFlag;
    const noId = (typeof sheetElysiumID === 'undefined' || typeof sheetElysiumID.id === 'undefined' || sheetElysiumID.id === '');
    //add button
    const label = game.i18n.localize("Elysium.ElysiumIDFlag.id");
    const elysiumidEditor = `<button type="button" class="header-control icon fa-solid fa-fingerprint ${noId ? 'edit-elysiumid-warning' : 'edit-elysiumid-exisiting'}"
        data-action="editElysiumID" data-tooltip="${label}" aria-label="${label}"></button>`;
    let el = this.window.close;
    while (el.previousElementSibling.localName === 'button') {
      el = el.previousElementSibling;
    }
    el.insertAdjacentHTML("beforebegin", elysiumidEditor);
    return frame;
  }

  async _prepareContext(options) {
    return {
      editable: this.isEditable,
      owner: this.document.isOwner,
      limited: this.document.limited,
      item: this.item,
      flags: this.item.flags,
      system: this.item.system,
      hasOwner: this.item.isEmbedded === true,
      isGM: game.user.isGM,
      itemType: game.i18n.localize('TYPES.Item.' + this.item.type),
      headerDisplay: false,
      useWealth: true,
      wealthLabel: "Gold",
    }
  }

  //------------ACTIONS-------------------

  // Change Image
  static async _onEditImage(event, target) {
    const attr = target.dataset.edit;
    const current = foundry.utils.getProperty(this.document, attr);
    const { img } = this.document.constructor.getDefaultArtwork?.(this.document.toObject()) ??
      {};
    const fp = new foundry.applications.apps.FilePicker({
      current,
      type: 'image',
      redirectToRoot: img ? [img] : [],
      callback: (path) => {
        this.document.update({ [attr]: path });
      },
      top: this.position.top + 39,
      left: this.position.left + 9,
    });
    return fp.browse();
  }

  // Handle editElysiumID action
  static _onEditElysiumID(event, target) {
    event.stopPropagation(); // Don't trigger other events
    if (event.detail > 1) return; // Ignore repeated clicks
    new ElysiumIDEditor({ document: this.document }, {}).render(true, { focus: true })
  }

  // Toggle something on the item.
  //
  // Two paths supported:
  //   1. `data-property` only (e.g. "improve", "chosen") — legacy flat path.
  //      Storage path becomes `system.${prop}`. Used by all the original
  //      hit-location / skill / weapon / mutation / persTrait flags.
  //   2. `data-property` + `data-property-path` (e.g. property="isRitual"
  //      property-path="system.elysium.isRitual") — explicit nested path.
  //      Used by spell flags which live under `system.elysium.*` per their
  //      DataModel definitions. Introduced in P10 cluster 4 (alpha.42) when
  //      smoke caught that divine's isRitual/isReactive/isDamageSpell chips
  //      from cluster 3a were writing to a junk flat path (`system.isRitual`)
  //      rather than the real storage path (`system.elysium.isRitual`).
  //
  // The `data-property` value is still used for the allow-list lookup (so
  // permissions live on the property name, not the path) — even when an
  // explicit path is provided, the property name must be in the allow-list.
  static _onItemToggle(event, target) {
    event.preventDefault();
    const prop = target.dataset.property
    const explicitPath = target.dataset.propertyPath
    // GM-only toggles. Non-GM clicks short-circuit. P10 cluster 3a (alpha.40)
    // additions: isRitual / isReactive / isDamageSpell (divine spell authoring).
    // P10 cluster 4 (alpha.42) additions: isPermanent (arcane), isSustained /
    // forbidden / casterChoosesLocation (sorcery).
    // P10 cluster 5 (alpha.43) additions: isMelee (weapon default attack mode).
    if (['minorOnly', 'basic','noXP', 'specialism', 'variable', 'group', 'chosen', 'combat', 'var', 'parry','burst', 'stun', 'choke',
      'entangle', 'fire', 'pierce', 'sonic', 'poison', 'explosive', 'emp', 'disease', 'spclDmg','cold','acid','constrict',
      'isRitual', 'isReactive', 'isDamageSpell',
      'isPermanent', 'isSustained', 'forbidden', 'casterChoosesLocation',
      'isMelee'].includes(prop) && !game.user.isGM) {
        return
    };

    // Writable toggle property allow-list. P10 cluster 3a (alpha.40)
    // additions: isRitual / isReactive / isDamageSpell (divine, also in
    // GM-only list above) + injured / incapacitated / unconscious
    // (hit-location combat status, player-writable on owned actor).
    // P10 cluster 4 (alpha.42) additions: isPermanent (arcane),
    // isSustained / forbidden / casterChoosesLocation (sorcery).
    // P10 cluster 5 (alpha.43) additions: isMelee (weapon).
    if (!['allegEnemy', 'allegApoth', 'allegAllied', 'improve', 'dead', 'severed', 'bleeding', 'mem', 'minorOnly', 'minor', 'oppimprove',
       'perLvl', 'noXP', 'specialism', 'variable', 'group', 'chosen', 'basic', 'combat','var', 'parry','burst', 'stun', 'choke', 'entangle', 'fire', 'pierce', 'sonic',
       'poison', 'explosive', 'emp', 'disease', 'spclDmg', 'cold','acid','constrict', 'treated',
       'isRitual', 'isReactive', 'isDamageSpell', 'injured', 'incapacitated', 'unconscious',
       'isPermanent', 'isSustained', 'forbidden', 'casterChoosesLocation',
       'isMelee'].includes(prop)) return

    // Resolve storage path. Default to flat `system.${prop}`; honor explicit
    // path when the template specifies one (spell flags route here).
    const path = explicitPath || `system.${prop}`
    const current = foundry.utils.getProperty(this.item, path)
    let checkProp = { [path]: !current }

    // Pre-existing special-case: sorcery's `var` flag also resets currLvl/memLvl.
    if (prop === 'var' && this.item.type === 'sorcery') {
      if (this.item.system.var) {
        checkProp = {
          'system.var': false,
          'system.currLvl': this.item.system.maxLvl,
          'system.memLvl': this.item.system.maxLvl,
        }
      }
    }
    this.item.update(checkProp)
  }
}

