# P9 cluster 5 (magic family + smart consolidation) — prep audit

Captured 2026-05-14, after alpha.35 smoke pass. Final P9 cluster.
Closes the P9 phase.

## Context

The original P9 prep audit (Q14 lock) committed to "smart consolidation":

> When exactly one magic tradition is active on the actor, that tradition
> gets its direct chip (`Arcane` / `Divine` / etc.). When two or more are
> active, the chips collapse into a single `Magic` gutter chip whose
> content body holds sub-tabs (one per active tradition).
> **Mutations** and **Super** are NOT magic disciplines — they stay as
> direct chips regardless of count.

The 4 magic disciplines that participate in consolidation:
`arcane` / `divine` / `mysticism` / `sorcery`.

The 2 powers that DON'T participate (always direct chips):
`mutations` / `super`.

## Phase scope

Two functional concerns:

1. **Magic-tab content rebuild** — the 4 discipline content templates
   today are partially v1.0.0-styled (varies from arcane at ~41
   elysium-* references to sorcery at ~8). Need a shared scaffold so
   they're consistent.
2. **Smart consolidation** — when ≥2 disciplines active, the gutter
   shows ONE Magic chip; clicking it opens a single content surface
   that internally switches between disciplines via a sub-tab group.

Plus the lingering super tab rebuild — visually adjacent, simpler scope.

## Per-discipline tab inventory

### Current state (legacy → v1.0.0 partial conversion)

| Tab | Lines | v1.0.0 chrome | Distinct functional blocks |
|---|---:|---|---|
| arcane | 233 | 41 elysium-* refs | School skill summary, spell list, sustained-spells panel, custom-spell builder |
| divine | 122 | already styled with `elysium-magic-section-*` | Channeling skill, Faith allegiance, divine spell list |
| mysticism | 151 | 17 elysium-* refs | Mysticism skill, feat list, talent list, spell list |
| sorcery | 66 | 8 elysium-* refs | Sorcery skill, spell list with mem toggle |
| super | 42 | 0 elysium-* refs (fully legacy) | Powers list, failings list |

### Common skeleton across the 4 magic disciplines

Every magic tab has the same coarse layout:
1. **Casting skill summary** (one or N skills) — rollable percentage,
   improve checkbox
2. **Spell/power list** (the body) — N rows with discipline-specific
   columns (range / duration / cost / cast button / level / etc.)
3. **Optional sub-blocks** — Faith allegiances (divine only), sustained
   spells (arcane only), feat/talent list (mysticism), custom-spell
   builder (arcane)

The `elysium-magic-section`/`elysium-magic-section-header`/
`elysium-magic-section-body` triad already exists and is used across
all 4 disciplines (with varying coverage). We standardize on it.

## Architectural decisions

### (1) Consolidation mechanism — Foundry V14 nested tabGroups

Foundry V14 sheets already support named `tabGroups`. The current code
uses `tabGroups['primary']`. For sub-tabs under Magic, we add a SECOND
named group `tabGroups['magic']`:

- The primary gutter shows the consolidated `Magic` chip (when ≥2
  disciplines active).
- Clicking that chip activates a primary-group tab whose content
  template (`character.magic.hbs`) renders a sub-tab nav strip + the
  currently-active discipline's body.
- The sub-tab nav uses `data-action="tab" data-group="magic"
  data-tab="arcane"|"divine"|"mysticism"|"sorcery"`. Foundry's
  built-in `tab` action handler then sets `tabGroups['magic']` and
  re-renders.

Mechanism is fully native; no new action handlers needed for sub-tab
switching.

### (2) Which content templates ship vs which become orphans

When 2+ disciplines active and consolidation kicks in:
- The 4 individual discipline tab content templates (`character.arcane.hbs`,
  `character.divine.hbs`, etc.) need to render INSIDE `character.magic.hbs`
  as sub-content. The wrapper template iterates active disciplines and
  invokes each as a partial.
- This means the individual templates need to be CALLABLE AS PARTIALS,
  not just registered as PARTS. The cleanest approach: each discipline
  body becomes a shared partial under `templates/actor/parts/magic/`,
  and BOTH the standalone tab template (single-tradition mode) AND
  the consolidated wrapper invoke the same shared partial.
- Single-discipline mode: `character.<discipline>.hbs` is a thin
  wrapper that emits the section element + invokes the shared body
  partial.
- Consolidated mode: `character.magic.hbs` renders the section element
  + sub-tab strip + invokes the active discipline's body partial.

Same partial, same context shape, two consuming surfaces.

### (3) Render-options gating logic

`_configureRenderOptions` currently pushes one tab per active
discipline. New logic:

```
const activeMagic = [];
if (system.arcane    !== "") activeMagic.push('arcane');
if (system.divine    !== "") activeMagic.push('divine');
if (system.mysticism !== "") activeMagic.push('mysticism');
if (system.sorcery   !== "") activeMagic.push('sorcery');

if (activeMagic.length === 1) {
  options.parts.push(activeMagic[0]);  // direct chip
} else if (activeMagic.length >= 2) {
  options.parts.push('magic');           // consolidated wrapper
}
// 0 active → no chip
```

When `magic` is pushed instead of a discipline, the `_getTabs` logic
also needs adjustment: `magic` is a tab with the `fa-hat-wizard` icon
(or a new dedicated one) and label "Magic"; the actual discipline
PARTS aren't separate tabs because they're nested under `magic`'s
content. They DO need to be registered as PARTS though, so the
template files load — they just don't appear in the gutter.

**Question for design**: when `magic` is consolidated, does the
character STILL get a chip per discipline somewhere, or is the only
discipline navigation the sub-tab strip inside the Magic content?
Per the audit's smart-consolidation lock-in: only the sub-tab strip.
The gutter shows one Magic chip.

### (4) Default sub-tab + persistence

`tabGroups['magic']` needs an initial value. P9 audit Q14
"magic-1" locked: **alphabetic default**. So:
- Active disciplines `[arcane, divine]` → default sub-tab = `arcane`.
- Active disciplines `[divine, mysticism, sorcery]` → default sub-tab
  = `divine`.

Persistence within a session: `tabGroups['magic']` persists per-sheet-
instance, same as `tabGroups['primary']`. Across sessions: Foundry
doesn't persist tab-group state, so each sheet re-open starts on the
alphabetic default. That's acceptable.

### (5) Icon choice for the consolidated Magic chip

Current TAB_ICONS:
- arcane → fa-hat-wizard
- divine → fa-cross
- mysticism → fa-eye
- sorcery → fa-fire

For consolidated Magic, options:
- (a) Keep fa-hat-wizard (arcane's icon) — risks confusion with arcane
- (b) Use fa-wand-sparkles (generic magic) — clean, distinct
- (c) Use fa-star-of-life (mystical generic) — distinctive but less
  intuitive
- **Recommendation: (b) fa-wand-sparkles.** Generic, immediately reads
  as "magic of any kind."

### (6) Super and Mutations — out of consolidation, but cluster 5 still touches super

Mutations already shipped in cluster 1 (alpha.30). Super is the last
remaining legacy-styled tab. Per P9 audit's cluster 5 plan, super
rebuilds in this same cluster because it's visually adjacent.

Super has two sections (powers, failings) and uses the same row
shape as combat weapons (without the equip toggle). New partials
needed: `super-row.hbs` (powers list) and `failing-row.hbs` (failings
list — name only, or shortDesc fallback).

## New shared partials

### Magic body partials (under `templates/actor/parts/magic/`)

| Partial | Purpose | Single-tab use | Consolidated use |
|---|---|---|---|
| `arcane-body.hbs` | Arcane content (school skill, spell list, sustained panel, custom builder) | character.arcane.hbs invokes | character.magic.hbs invokes when sub-tab=arcane |
| `divine-body.hbs` | Divine content (channeling skill, Faith allegiances, divine spell list) | character.divine.hbs | character.magic.hbs (sub-tab=divine) |
| `mysticism-body.hbs` | Mysticism content (skill, feat list, talent list, spell list) | character.mysticism.hbs | character.magic.hbs (sub-tab=mysticism) |
| `sorcery-body.hbs` | Sorcery content (skill, spell list with mem toggle) | character.sorcery.hbs | character.magic.hbs (sub-tab=sorcery) |

### Sub-row partials (shared across disciplines)

| Partial | Purpose |
|---|---|
| `spell-row.hbs` | One spell with name + range/duration/cost/cast — common shape across arcane/divine/mysticism with minor parameter differences |
| `magic-skill-summary.hbs` | One casting skill row — name + total% + improve checkbox |
| `magic-section-frame.hbs` | The header+body card frame already used everywhere (count badge + chevron) |

### Super-tab partials

| Partial | Purpose |
|---|---|
| `super-row.hbs` | One superpower row (name + range + duration + cost + level) |
| `failing-row.hbs` | One failing row (name or shortDesc) |

### Sub-tab strip (consolidation only)

| Partial | Purpose |
|---|---|
| `magic-subtab-strip.hbs` | Horizontal sub-tab nav rendered inside the consolidated Magic content surface |

Total new partials: ~10. All registered in `init.mjs:2a`.

### Out of scope: arcane custom-spell builder

Custom-spell builder is its own complex sub-surface inside the arcane
tab. P9 prep audit decision arcane-1 was: **restyle in-place**. We
preserve the existing inline structure and apply v1.0.0 token-driven
chrome around it. No structural rebuild.

## Ship sequence

### Alpha A (alpha.36) — Magic shared scaffold + single-tradition rebuild

1. Add the 4 discipline-body partials + sub-row partials +
   super-row + failing-row to `templates/actor/parts/magic/` and
   `templates/actor/parts/`.
2. Register all new partials in `init.mjs:2a`.
3. Rebuild the 4 magic tab templates as thin wrappers over the
   discipline-body partials.
4. Rebuild super tab template + add the 2 new super partials.
5. CSS additions (~250 lines estimated).
6. Pre-flight sweep + smoke. Single-tradition test character must
   render each magic discipline cleanly (when alpha A ships, no
   consolidation logic yet — multi-tradition characters still see
   N separate chips, same as today).

### Alpha B (alpha.37) — Smart consolidation

1. Create `character.magic.hbs` consolidated wrapper.
2. Modify `_configureRenderOptions`: when ≥2 disciplines active,
   push `magic` PART instead of individual disciplines. When exactly
   1, push that discipline directly. When 0, push nothing magic-y.
3. Modify `_getTabs`: add the `magic` case with fa-wand-sparkles +
   "Magic" label + tooltip listing active disciplines.
4. Modify `_prepareContext` / `_preparePartContext`: build
   `context.activeMagicDisciplines = ['arcane', 'divine', ...]`,
   prepare a `context.magicTab.subTabGroup = 'magic'` and the active
   sub-tab from `this.tabGroups['magic']` with alphabetic default.
5. Add `magic-subtab-strip.hbs` partial.
6. Add PARTS entry for `magic` (template:
   character.magic.hbs).
7. CSS additions for sub-tab strip (~60 lines).
8. Smoke: test character with 0 / 1 / 2 / 3 / 4 disciplines active;
   verify gutter chips correct in each scenario and consolidated
   navigation works.

This is the most behavior-changing alpha of P9 — best to keep alpha A
and alpha B separate so any bugs from each can be isolated.

## Data dependencies — verified

```
context.arcanes[]      — sorted by name
context.divines[]       — sorted
context.mysticisms[]    — sorted, with grandTotal computed
context.sorceries[]     — sorted
context.superpowers[]   — sorted
context.failings[]      — sorted

context.system.arcane   — string, non-empty means active
context.system.divine, .mysticism, .sorcery, .mutation, .super
                        — same convention

context.arcaneLabel, .divineLabel, .mysticismLabel, .sorceryLabel,
        .superLabel, .mutationLabel — settings-driven label strings

context.elysiumDivineTab.{channelingSkills, faiths}
context.elysiumMagicTab.{schools, sustains}  (likely; need to verify)
context.elysiumMysticismTab.{skills, feats, talents}  (likely)
context.elysiumSorceryTab.{skills}  (likely)

context.passionsArcane  — already filtered in context-prep (cluster 3
                          had a note about this)
```

Need to verify the `elysiumMagicTab` / `elysiumMysticismTab` /
`elysiumSorceryTab` namespaces during the alpha A ship — they're hinted
at by the divine tab's `elysiumDivineTab.*` pattern.

## Action handlers — already registered

All magic action handlers already exist:
- castArcane, castDivine, castSorcery, castMysticism — discipline casts
- castSpendAP, castAbandon, castUndoPP — cast lifecycle
- dropSustain — drop a sustained spell
- castCustomSpell — arcane custom-spell builder
- powImprove — power-list improve toggle

No new handlers needed.

## CSS additions estimated

- Spell row grid + cast button styling: ~50 lines
- Magic-skill-summary row: ~30 lines
- Magic section frame variants (already partly defined): ~40 lines
- Sustained spells panel: ~30 lines (arcane only)
- Custom-spell builder chrome (restyle existing structure): ~30 lines
- Super tab rows: ~40 lines
- Sub-tab strip (alpha B): ~60 lines

Total: ~280 lines for alpha A, ~60 for alpha B.

## Out of scope for cluster 5

- Casting integration (Faith allegPoints gating, opposed-roll
  channeling) — deferred per the divine template's own note ("deferred
  to v0.7.x")
- Custom-spell builder structural redesign — restyle only
- NPC magic surface — NPC sheets don't typically have these tabs; P9
  doesn't touch NPC
- Item sheet rebuilds (arcane/divine/mysticism/sorcery/super items) — P10

## Smoke risks specific to cluster 5

1. **Consolidation gating bugs**: getting `activeMagic.length` wrong
   could ship a sheet with EITHER duplicate tabs (consolidation +
   individual disciplines both shown) OR missing tabs (consolidation
   logic fires but content template doesn't exist). The render-options
   logic gets explicit unit-style tests via offline-render: build
   contexts with 0, 1, 2, 3, 4 active disciplines and assert the parts
   list matches expected.
2. **Sub-tab state persistence within sheet**: `tabGroups['magic']`
   should survive a re-render within the same sheet instance. If a
   bug clears it on render, the sub-tab selection resets to alphabetic
   default every time the actor data updates. Tested via simulating
   two renders in sequence.
3. **Empty-state when 0 disciplines active**: the gutter shouldn't
   show any magic-related chip. Easy to assert.
4. **Existing tab strip layout**: adding a new "magic" PART means the
   tab strip gets one more (or one fewer) chip depending on context.
   Visual regression check: the chip vertical alignment stays correct.

## Open questions requiring lock-in before ship

1. **magic-cluster5-1**: Consolidated Magic chip icon —
   (a) fa-hat-wizard, (b) fa-wand-sparkles, (c) fa-star-of-life.
   Recommendation: **(b) fa-wand-sparkles**.

2. **magic-cluster5-2**: When `activeMagic.length === 0`, no magic
   chip rendered. Confirmed by audit logic. No question really.

3. **magic-cluster5-3**: Sub-tab default = alphabetic per the P9
   audit's `magic-1`. Confirm? Recommendation: **confirm**.

4. **magic-cluster5-4**: Should the consolidated Magic chip's
   tooltip list the active disciplines (e.g. "Magic — Arcane,
   Divine") or just say "Magic"? Recommendation: **list active
   disciplines** so the player can see what's inside without clicking.

5. **magic-cluster5-5**: Ship sequencing — A then B in separate
   alphas (recommended), or combined? Recommendation: **separate
   alphas**. Alpha A is pure content rebuild + restyle; alpha B is
   the behavior change. Easier to bisect bugs.

6. **magic-cluster5-6**: Test character setup — does the test world
   currently have ANY magic disciplines active? Per smoke at alpha.32
   the actor had no traditions. **Need to enable arcane (and possibly
   divine) on the test actor before smoke**. Alpha A only needs 1
   discipline active; alpha B needs ≥2. Both setups via
   `actor.update({'system.arcane': 'gold', 'system.divine': 'order'})`.

## Ready-to-go checklist

- [x] Legacy templates inspected
- [x] V1.0.0 chrome state assessed per discipline
- [x] Architectural approach validated (nested tabGroups, native V14)
- [x] Action handlers verified present
- [ ] User decision on 6 questions (5 have recommendations + 1
      already-locked from prior audit)
- [ ] elysium*Tab context namespaces verified during alpha A ship
- [ ] Test actor magic setup before alpha A smoke
