/**
 * SorceryDataModel — schema for items of type 'sorcery'.
 *
 * Per P6.4 spec. Stored-schema-only. 264 compendium items in
 * abilities-sorcery.db — the most-populous item type in the game.
 *
 * The deepest schema in the system at ~38 slots, including:
 *   - 5-named-tier `thresholds` SchemaField (nascent/developing/established/
 *     potent/transcendent), each `{min, max}`
 *   - 5-fixed-key `effectByTier` SchemaField (same shape as divine)
 *   - Three fixed-length-5 arrays: apCostByTier, damageByTier,
 *     locationsByTier
 *
 * Schema decisions:
 *   - One compendium-only field: `subType` (StringField, always '' in
 *     264 items). Zero code reads. Declared to accept drops; P6.6
 *     candidate to drop.
 *   - `var` is a JS reserved word — use `var:` in the schema object
 *     (property names can be reserved words in object literals).
 *     Compendium data preserves this name as-is.
 *   - `pppl` and `powCost` are StringFields per template (string
 *     numerics, same pattern as super.cpc).
 *   - `apCostByTier`, `damageByTier`, `locationsByTier` are fixed-length-5
 *     arrays (logical constraint, not schema-enforced).
 *   - `effectByTier` is a 5-key SchemaField with explicit "1".."5" keys.
 *   - `thresholds` is a 5-named-key SchemaField, each tier is a nested
 *     {min: int, max: int} SchemaField.
 *   - All string enums (essence, essenceRarity, abilityType, baseStatA/B,
 *     damageType, saveSkill) FREE per content extensibility.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

/** Reusable inner shape for a sorcery threshold tier: {min, max} ints. */
function makeThresholdTier (defaultMin, defaultMax) {
  return new fields.SchemaField({
    min: new fields.NumberField({ integer: true, initial: defaultMin }),
    max: new fields.NumberField({ integer: true, initial: defaultMax }),
  })
}

export class SorceryDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),

      // Top-level fields per template
      mem:     new fields.BooleanField({ initial: false }),
      range:   new fields.StringField({ initial: '' }),
      pppl:    new fields.StringField({ initial: '1' }),     // STRING per template
      powCost: new fields.StringField({ initial: '0' }),     // STRING per template
      maxLvl:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      currLvl: new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      memLvl:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      // `var` is a JS reserved word, but valid as an object property key.
      // Compendium and template preserve this name; schema preserves it too.
      var:     new fields.BooleanField({ initial: false }),

      // v1.0.0-alpha.11 (side-finding #14): vestigial `subType` removed.
      // Zero code readers; compendium regenerated to drop the ride-along.

      elysium: new fields.SchemaField({
        essence:         new fields.StringField({ initial: '' }),
        essenceRarity:   new fields.StringField({ initial: 'common' }),
        isConfluence:    new fields.BooleanField({ initial: false }),
        isRestricted:    new fields.BooleanField({ initial: false }),
        abilityType:     new fields.StringField({ initial: 'spell' }),
        tierIndex:       new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        unlockExpCost:   new fields.NumberField({ integer: true, initial: 0 }),
        isFreeAbility:   new fields.BooleanField({ initial: false }),
        currentSkillPct: new fields.NumberField({ integer: true, initial: 0 }),
        baseStatA:       new fields.StringField({ initial: 'int' }),
        baseStatB:       new fields.StringField({ initial: 'pow' }),

        // thresholds: 5 fixed named tiers, each {min, max} integers.
        // All 264 compendium items use exactly these 5 keys.
        thresholds: new fields.SchemaField({
          nascent:      makeThresholdTier(1, 49),
          developing:   makeThresholdTier(50, 69),
          established:  makeThresholdTier(70, 84),
          potent:       makeThresholdTier(85, 94),
          transcendent: makeThresholdTier(95, 999),
        }),

        powerCost: new fields.NumberField({ integer: true, initial: 2 }),
        apCost:    new fields.NumberField({ integer: true, initial: 1 }),
        saveSkill: new fields.StringField({ initial: '' }),
        baseTier:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        maxTier:   new fields.NumberField({ integer: true, initial: 5, min: 0 }),

        // Fixed-length-5 arrays (logical, not schema-enforced)
        apCostByTier: new fields.ArrayField(
          new fields.NumberField({ integer: true }),
          { initial: [1, 1, 1, 1, 1] },
        ),

        // Fixed 5-key SchemaField for tier-effect descriptions ("1".."5").
        effectByTier: new fields.SchemaField({
          '1': new fields.StringField({ initial: '' }),
          '2': new fields.StringField({ initial: '' }),
          '3': new fields.StringField({ initial: '' }),
          '4': new fields.StringField({ initial: '' }),
          '5': new fields.StringField({ initial: '' }),
        }),

        isDamageSpell:      new fields.BooleanField({ initial: false }),
        damageType:         new fields.StringField({ initial: '' }),
        isSustained:        new fields.BooleanField({ initial: false }),
        maintainPPPerRound: new fields.NumberField({ integer: true, initial: 0 }),
        forbidden:          new fields.BooleanField({ initial: false }),

        // Fixed-length-5 arrays: per-tier damage formulas + hit-location counts
        damageByTier: new fields.ArrayField(
          new fields.StringField(),
          { initial: ['', '', '', '', ''] },
        ),
        locationsByTier: new fields.ArrayField(
          new fields.NumberField({ integer: true }),
          { initial: [1, 1, 1, 1, 1] },
        ),

        casterChoosesLocation: new fields.BooleanField({ initial: false }),
      }),
    }
  }
}
