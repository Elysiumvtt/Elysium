// =====================================================================
// ELYSIUM | Covering Stance — unified Passive Block + Ward Location
// =====================================================================
//
// Two Mythras-core mechanics share a common shape: the character holds
// a weapon or shield in a static stance that covers specific hit-
// locations, without spending AP, at the cost of being unable to
// actively parry with that item while in the stance. They differ only
// in how incoming damage is modified:
//
//   passive-block  — adds the item's AP to the location (cover-style).
//                    Open-ended; persists until explicitly dropped.
//
//   ward           — downgrades incoming damage by the parry-size
//                    table (Mythras core p.103):
//                      warder Size ≥ attacker weapon Size: all damage
//                                                          deflected
//                      warder one Size smaller:            ½ damage
//                                                          (floor)
//                      warder two+ Sizes smaller:          no deflection
//                    Persists until the warding weapon attacks or
//                    actively parries (currently a manual drop — see
//                    "Auto-cancel deferred" below).
//
// Note on naming: "Combat Stance" is an existing ability in Elysium.
// We use "covering stance" here to keep terminology distinct.
//
// State storage (per-item, singular — mutual exclusion natural):
//
//   item.flags['elysium'].coveringStance = {
//     type: 'passive-block' | 'ward',
//     locationIds: [hitLocId, ...],
//     crouching: bool,
//   }
//
// Activating one stance type on an item that's already in the other
// clears the previous stance first; the dialog surfaces this so the
// player can confirm.
//
// Shared capacity rules (both stance types):
//   - Weapon (non-shield): covers exactly 1 location
//   - Shield, T/S/M/L/H: 1/2/3/4/5 locations
//   - Crouching shield: doubles
//
// Shared adjacency soft-validation: covered locations should form a
// connected subgraph through head ↔ chest ↔ {arm, abdomen} ↔ leg.
// Disconnected combinations raise a warning surfaced in a confirm
// dialog; the GM has final say.
//
// Damage flow integration:
//   - Passive-block: automatic. applyArmorToDamage queries this module
//     for passively-blocking items covering the hit location and
//     appends their AP to its breakdown with source='passive-block'.
//   - Ward: manual via chat-card "Apply Ward" button. The defender
//     picks the attacker's weapon Size; the module computes the
//     downgrade and posts the result. We don't auto-apply because
//     applyArmorToDamage doesn't know the attacker's weapon Size.
//
// Auto-cancel deferred:
//   The rules say "ward continues until the dedicated weapon is used
//   to attack or actively parry." We currently rely on manual drop
//   (tooltip on the badge reminds the player). Automation is
//   scheduled as an extensive feature update for a future release —
//   it requires patching the weapon-roll path, which doesn't have a
//   clean chokepoint in Elysium.
//
// History:
//   - alpha.7: shipped as separate passive-block.mjs
//   - alpha.8: unified with ward into covering-stance.mjs (this file).
//     Replaces passive-block.mjs.
// =====================================================================

const FLAG_NS = 'elysium'
const FLAG_KEY = 'coveringStance'
const LEGACY_PASSIVE_BLOCK_KEY = 'passiveBlock'   // alpha.7 flag key, migrated on read

// Shield size → number of locations covered (upright stance)
const SIZE_TO_COVERAGE = {
  T: 1,
  S: 2,
  M: 3,
  L: 4,
  H: 5,
}

// Adjacency graph for soft validation. Maps bodyPart → adjacent
// bodyParts. The covered locations must form a connected subgraph
// through this graph for a "no warning" result.
const ADJACENCY = {
  head:    ['chest'],
  chest:   ['head', 'abdomen', 'arm'],
  abdomen: ['chest', 'leg'],
  arm:     ['chest'],
  leg:     ['abdomen'],
}

// Stance type constants
export const STANCE_PASSIVE_BLOCK = 'passive-block'
export const STANCE_WARD = 'ward'

// Weapon size order used by ward damage downgrade math
const SIZE_ORDER = ['T', 'S', 'M', 'L', 'H', 'E']

// ---------------------------------------------------------------------
// State accessors (pure helpers)
// ---------------------------------------------------------------------

/**
 * Read the covering-stance flag on an item. Returns null if the item
 * isn't currently in any stance.
 *
 * Also handles the alpha.7 legacy `passiveBlock` flag by promoting it
 * to a `{type: 'passive-block', ...}` shape transparently. The
 * underlying flag is only rewritten if the caller subsequently calls
 * setStance / clearStance — read-only access doesn't migrate.
 *
 * @param {Item} item
 * @returns {{type: string, locationIds: string[], crouching: boolean} | null}
 */
export function getStance (item) {
  const flags = item?.flags?.[FLAG_NS]
  if (!flags) return null
  const flag = flags[FLAG_KEY]
  if (flag && Array.isArray(flag.locationIds) && flag.locationIds.length > 0) {
    return {
      type: flag.type || STANCE_PASSIVE_BLOCK,
      locationIds: flag.locationIds.slice(),
      crouching: !!flag.crouching,
    }
  }
  // Legacy: alpha.7 stored passive-block under a different flag key
  const legacy = flags[LEGACY_PASSIVE_BLOCK_KEY]
  if (legacy && Array.isArray(legacy.locationIds) && legacy.locationIds.length > 0) {
    return {
      type: STANCE_PASSIVE_BLOCK,
      locationIds: legacy.locationIds.slice(),
      crouching: !!legacy.crouching,
    }
  }
  return null
}

/**
 * True if the item is currently in any covering stance. Doesn't check
 * equipStatus — callers should also gate on equipped for damage
 * resolution.
 */
export function isItemInCoveringStance (item) {
  return getStance(item) !== null
}

/**
 * True if the item is in passive-block specifically.
 */
export function isItemPassivelyBlocking (item) {
  const s = getStance(item)
  return s !== null && s.type === STANCE_PASSIVE_BLOCK
}

/**
 * True if the item is in ward specifically.
 */
export function isItemWarding (item) {
  const s = getStance(item)
  return s !== null && s.type === STANCE_WARD
}

/**
 * Return all equipped items on `actor` that are currently in any
 * covering stance over the given hit-location. Optionally filter by
 * stance type.
 *
 * @param {Actor} actor
 * @param {string} locationId
 * @param {string} [filterType] — STANCE_PASSIVE_BLOCK or STANCE_WARD;
 *                                if omitted, returns all
 * @returns {Item[]}
 */
export function getCoveringItemsForLocation (actor, locationId, filterType) {
  if (!actor || !locationId) return []
  const out = []
  for (const it of actor.items) {
    if (it.type !== 'weapon') continue
    if (it.system?.equipStatus !== 'equipped') continue
    const s = getStance(it)
    if (!s) continue
    if (filterType && s.type !== filterType) continue
    if (s.locationIds.includes(locationId)) out.push(it)
  }
  return out
}

/**
 * Convenience: passively-blocking items covering a location. Kept as a
 * named export for compatibility with the alpha.7 API surface.
 */
export function getPassivelyBlockingItemsForLocation (actor, locationId) {
  return getCoveringItemsForLocation(actor, locationId, STANCE_PASSIVE_BLOCK)
}

/**
 * Convenience: warding items covering a location.
 */
export function getWardingItemsForLocation (actor, locationId) {
  return getCoveringItemsForLocation(actor, locationId, STANCE_WARD)
}

/**
 * Sum the AP of all equipped passively-blocking items covering the
 * location. Each contributes its `system.ap` (the BRP-classic numeric
 * armor value on weapons/shields).
 */
export function getTotalPassiveAP (actor, locationId) {
  const items = getPassivelyBlockingItemsForLocation(actor, locationId)
  return items.reduce((s, it) => s + (Number(it.system?.ap) || 0), 0)
}

/**
 * True if any equipped item on `actor` is currently passively blocking
 * the given location.
 */
export function isLocationPassivelyBlocked (actor, locationId) {
  return getPassivelyBlockingItemsForLocation(actor, locationId).length > 0
}

/**
 * True if any equipped item on `actor` is currently warding the
 * given location.
 */
export function isLocationWarded (actor, locationId) {
  return getWardingItemsForLocation(actor, locationId).length > 0
}

// ---------------------------------------------------------------------
// Capacity & shield identification
// ---------------------------------------------------------------------

export function isShield (item) {
  return item?.type === 'weapon' && item?.system?.weaponType === 'shield'
}

/**
 * Maximum number of hit-locations this item can cover, accounting for
 * crouching when applicable.
 *
 *   - Non-shield weapon: 1 (crouching has no effect)
 *   - Shield: per-size table, doubled when crouching
 */
export function getMaxLocations (item, crouching) {
  if (!isShield(item)) return 1
  const size = item.system?.elysium?.weaponSize || 'M'
  const base = SIZE_TO_COVERAGE[size] ?? 3
  return crouching ? base * 2 : base
}

// ---------------------------------------------------------------------
// Ward damage downgrade (Mythras parry-size table)
// ---------------------------------------------------------------------

/**
 * Compute the damage that would pass through a ward given the
 * warder's Size and the attacker's weapon Size.
 *
 *   warder >= attacker Size: 0 damage through (full deflection)
 *   warder one Size smaller: floor(damage / 2)
 *   warder two+ Sizes smaller: damage unchanged (no deflection)
 *
 * Returns { finalDamage, downgrade, category } where:
 *   finalDamage - damage after ward applied
 *   downgrade   - amount removed (rawDamage - finalDamage)
 *   category    - 'full' | 'half' | 'none'
 *
 * @param {number} rawDamage
 * @param {string} attackerSize  - 'T'/'S'/'M'/'L'/'H'/'E'
 * @param {string} warderSize
 * @returns {{finalDamage: number, downgrade: number, category: string}}
 */
export function wardDamageDowngrade (rawDamage, attackerSize, warderSize) {
  const dmg = Math.max(0, Number(rawDamage) || 0)
  if (dmg === 0) return { finalDamage: 0, downgrade: 0, category: 'none' }

  const aIdx = SIZE_ORDER.indexOf(attackerSize || 'M')
  const wIdx = SIZE_ORDER.indexOf(warderSize || 'M')
  if (aIdx < 0 || wIdx < 0) {
    // Unknown sizes — be conservative, no deflection
    return { finalDamage: dmg, downgrade: 0, category: 'none' }
  }

  const stepsSmaller = aIdx - wIdx
  if (stepsSmaller <= 0) {
    // Warder equal-or-larger: full deflection
    return { finalDamage: 0, downgrade: dmg, category: 'full' }
  }
  if (stepsSmaller === 1) {
    // One size smaller: half damage (floor)
    const final = Math.floor(dmg / 2)
    return { finalDamage: final, downgrade: dmg - final, category: 'half' }
  }
  // Two or more smaller: no deflection
  return { finalDamage: dmg, downgrade: 0, category: 'none' }
}

// ---------------------------------------------------------------------
// Adjacency validation
// ---------------------------------------------------------------------

/**
 * Validate a proposed set of covered locations against the rules.
 * Returns { valid, errors, warnings }. Hard errors block submission;
 * warnings surface a confirm-dialog but allow override.
 */
export function validateLocationSelection (actor, item, locationIds, crouching) {
  const errors = []
  const warnings = []
  const ids = Array.from(new Set(locationIds || []))

  const capacity = getMaxLocations(item, crouching)
  if (ids.length === 0) {
    errors.push('Pick at least one location.')
  } else if (ids.length > capacity) {
    errors.push(`This ${isShield(item) ? 'shield' : 'weapon'} covers at most ${capacity} location(s); you picked ${ids.length}.`)
  } else if (ids.length < capacity && isShield(item)) {
    warnings.push(`This shield can cover up to ${capacity} locations; you only picked ${ids.length}.`)
  }

  const locs = ids.map(id => actor?.items?.get(id)).filter(Boolean)
  if (locs.length !== ids.length) {
    errors.push('One or more picked locations could not be resolved on this actor.')
    return { valid: false, errors, warnings }
  }

  if (isShield(item)) {
    const hasArm = locs.some(l => l.system?.elysium?.bodyPart === 'arm')
    if (!hasArm) {
      warnings.push('Shields normally cover the wielding arm. None of the picked locations is an arm — confirm with the GM.')
    }
  }

  // Connected-subgraph check via BFS over body parts
  if (locs.length > 1) {
    const parts = locs.map(l => l.system?.elysium?.bodyPart || 'unknown')
    const visited = new Set([0])
    const queue = [0]
    while (queue.length) {
      const i = queue.shift()
      const part = parts[i]
      const neighbors = ADJACENCY[part] || []
      for (let j = 0; j < parts.length; j++) {
        if (visited.has(j)) continue
        if (neighbors.includes(parts[j])) {
          visited.add(j)
          queue.push(j)
        }
      }
    }
    if (visited.size !== locs.length) {
      const unreachable = locs.filter((_, i) => !visited.has(i)).map(l => l.name).join(', ')
      warnings.push(`Locations not connected through adjacent body parts: ${unreachable}. The GM may allow it on tactical merit.`)
    }
  }

  return { valid: errors.length === 0, errors, warnings }
}

// ---------------------------------------------------------------------
// Mutators
// ---------------------------------------------------------------------

/**
 * Activate a covering stance on an item. Validates first and clears
 * any legacy passiveBlock flag along the way.
 *
 * @param {Item} item
 * @param {string} stanceType  - STANCE_PASSIVE_BLOCK or STANCE_WARD
 * @param {string[]} locationIds
 * @param {boolean} crouching
 */
export async function setStance (item, stanceType, locationIds, crouching) {
  const actor = item.parent
  if (!actor) throw new Error('Item must be owned by an actor.')
  if (stanceType !== STANCE_PASSIVE_BLOCK && stanceType !== STANCE_WARD) {
    throw new Error(`Unknown stance type: ${stanceType}`)
  }
  const v = validateLocationSelection(actor, item, locationIds, crouching)
  if (!v.valid) {
    throw new Error(v.errors.join(' '))
  }
  await item.update({
    [`flags.${FLAG_NS}.${FLAG_KEY}`]: {
      type: stanceType,
      locationIds: locationIds.slice(),
      crouching: !!crouching,
    },
    // Clear legacy alpha.7 flag if present
    [`flags.${FLAG_NS}.${LEGACY_PASSIVE_BLOCK_KEY}`]: null,
  })
}

/**
 * Clear the covering stance on an item. Also clears any legacy flag.
 */
export async function clearStance (item) {
  await item.update({
    [`flags.${FLAG_NS}.${FLAG_KEY}`]: null,
    [`flags.${FLAG_NS}.${LEGACY_PASSIVE_BLOCK_KEY}`]: null,
  })
}

// ---------------------------------------------------------------------
// Dialog
// ---------------------------------------------------------------------

/**
 * Open the covering-stance configuration dialog for an item. The
 * dialog has a stance-type selector at the top (defaulting to the
 * type passed in via `defaultType`, or the existing stance type if
 * any, or passive-block).
 */
export async function openStanceDialog (actor, item, defaultType) {
  if (item.type !== 'weapon') {
    ui.notifications?.warn('Covering stance is only available on weapons and shields.')
    return
  }
  if (item.system?.equipStatus !== 'equipped') {
    ui.notifications?.warn(`${item.name} must be equipped to enter a covering stance.`)
    return
  }

  const hitLocs = actor.items.filter(i => i.type === 'hit-location')
  if (hitLocs.length === 0) {
    ui.notifications?.warn(`${actor.name} has no hit-locations to cover.`)
    return
  }

  const shield = isShield(item)
  const existing = getStance(item)
  const initialType = defaultType ||
                      existing?.type ||
                      STANCE_PASSIVE_BLOCK

  const sortedLocs = hitLocs.slice().sort((a, b) => {
    const x = Number(a.system?.lowRoll) || 0
    const y = Number(b.system?.lowRoll) || 0
    return x - y
  })

  const locCheckboxes = sortedLocs.map(loc => {
    const checked = existing?.locationIds?.includes(loc.id) ? ' checked' : ''
    return `
      <label style="display:flex;align-items:center;gap:6px;padding:2px 0;">
        <input type="checkbox" name="loc:${loc.id}"${checked}>
        <span>${loc.name}</span>
      </label>
    `
  }).join('')

  const stanceTypeRow = `
    <div class="form-group" style="margin-bottom:8px;">
      <label style="display:block;margin-bottom:4px;"><b>Stance Type</b></label>
      <label style="display:inline-flex;align-items:center;gap:4px;margin-right:12px;">
        <input type="radio" name="stanceType" value="${STANCE_PASSIVE_BLOCK}"${initialType === STANCE_PASSIVE_BLOCK ? ' checked' : ''}>
        <span>Passive Block (adds AP)</span>
      </label>
      <label style="display:inline-flex;align-items:center;gap:4px;">
        <input type="radio" name="stanceType" value="${STANCE_WARD}"${initialType === STANCE_WARD ? ' checked' : ''}>
        <span>Ward (downgrades damage)</span>
      </label>
    </div>
  `

  const crouchRow = shield
    ? `<div class="form-group" style="margin-top:8px;">
         <label style="display:flex;align-items:center;gap:6px;">
           <input type="checkbox" name="crouching"${existing?.crouching ? ' checked' : ''}>
           <span>Crouching (doubles locations covered)</span>
         </label>
       </div>`
    : ''

  const capacityLine = shield
    ? `<p style="margin:0 0 8px 0;font-size:11px;font-style:italic;opacity:0.8;">
         Coverage: ${getMaxLocations(item, false)} location(s) upright,
         ${getMaxLocations(item, true)} when crouching.
       </p>`
    : `<p style="margin:0 0 8px 0;font-size:11px;font-style:italic;opacity:0.8;">
         A weapon covers exactly 1 location.
       </p>`

  const wMod = item.system?.elysium?.weaponSize || 'M'
  const sizeLabels = CONFIG.ELYSIUM?.WEAPON_SIZES || {}
  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:12px;">
        <b>${item.name}</b> (Size ${sizeLabels[wMod] || wMod}, AP ${item.system?.ap || 0})
        will be held statically over the chosen location(s). While in a
        covering stance, this item cannot actively parry.
      </p>
      ${stanceTypeRow}
      ${capacityLine}
      <div style="max-height:240px;overflow-y:auto;border:1px solid var(--color-border-light-tertiary, #555);padding:6px;border-radius:3px;">
        ${locCheckboxes}
      </div>
      ${crouchRow}
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Covering Stance — ${item.name}` },
    content,
    ok: {
      label: existing ? 'Update' : 'Activate',
      callback: (event, button) => {
        const form = button.form
        const stanceType = form.querySelector('[name="stanceType"]:checked')?.value || STANCE_PASSIVE_BLOCK
        const locationIds = []
        for (const loc of sortedLocs) {
          if (form.querySelector(`[name="loc:${loc.id}"]`).checked) {
            locationIds.push(loc.id)
          }
        }
        const crouching = shield && !!form.querySelector('[name="crouching"]')?.checked
        return { stanceType, locationIds, crouching }
      },
    },
  }).catch(() => null)

  if (!result) return

  const v = validateLocationSelection(actor, item, result.locationIds, result.crouching)
  if (!v.valid) {
    ui.notifications?.error(v.errors.join(' '))
    return
  }
  if (v.warnings.length > 0) {
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: 'Confirm Covering Stance' },
      content: `
        <p>The chosen locations triggered the following warning(s):</p>
        <ul style="margin:6px 0;">${v.warnings.map(w => `<li>${w}</li>`).join('')}</ul>
        <p>Proceed anyway?</p>
      `,
    }).catch(() => false)
    if (!confirmed) return
  }

  await setStance(item, result.stanceType, result.locationIds, result.crouching)
  await _postStanceCard(actor, item, 'activated')
}

/**
 * Drop the covering stance on an item.
 */
export async function dropStance (actor, item) {
  const prev = getStance(item)
  await clearStance(item)
  if (prev) await _postStanceCard(actor, item, 'dropped', prev)
}

async function _postStanceCard (actor, item, mode, prevState) {
  let body
  if (mode === 'activated') {
    const pb = getStance(item)
    if (!pb) return
    const locs = pb.locationIds.map(id => actor.items.get(id)?.name || '?').join(', ')
    const crouch = pb.crouching ? ' (crouching)' : ''
    const typeLabel = pb.type === STANCE_WARD ? 'wards' : 'raises as passive cover for'
    const effectNote = pb.type === STANCE_WARD
      ? `Size ${item.system?.elysium?.weaponSize || 'M'}; damage downgraded per parry-size table.`
      : `AP ${item.system?.ap || 0}.`
    body = `<b>${actor.name}</b> ${typeLabel} <b>${item.name}</b>: ${locs}${crouch}. ${effectNote}`
  } else {
    const typeLabel = prevState?.type === STANCE_WARD ? 'ward' : 'passive-block stance'
    body = `<b>${actor.name}</b> drops the ${typeLabel} with <b>${item.name}</b>.`
  }
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', icon: 'shield', body: `<p>${body}</p>` }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor }),
    flags: { [FLAG_NS]: { coveringStanceCard: true } },
  })
}

// ---------------------------------------------------------------------
// Combat chat-card integration
// ---------------------------------------------------------------------

/**
 * Post the "applied to chat card" notation showing passive-block AP
 * contribution. Same shape as alpha.7's notePassiveBlockOnCard.
 */
export async function notePassiveBlockOnCard (messageId, defenderActorId, locationId) {
  const msg = game.messages?.get(messageId)
  if (!msg) return
  const defender = game.actors?.get(defenderActorId)
  if (!defender) return
  const items = getPassivelyBlockingItemsForLocation(defender, locationId)
  if (items.length === 0) {
    ui.notifications?.warn(`${defender.name} has no passive-block coverage on this location.`)
    return
  }
  const total = items.reduce((s, it) => s + (Number(it.system?.ap) || 0), 0)
  const names = items.map(it => `${it.name} (AP ${it.system?.ap || 0})`).join(', ')
  const location = defender.items.get(locationId)
  const locName = location?.name || 'location'

  const body = `<p>${game.i18n.format('Elysium.Chat.PassiveBlockApplied', {
    defender: `<b>${defender.name}</b>`,
    location: `<b>${locName}</b>`,
    items: names,
    total,
  })}</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', icon: 'shield-halved', body }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor: defender }),
    flags: { [FLAG_NS]: { passiveBlockApplied: true } },
  })
}

/**
 * Open a small dialog asking for the attacker's weapon Size and raw
 * damage, then compute the ward downgrade and post the result.
 *
 * @param {string} defenderActorId
 * @param {string} locationId
 */
export async function applyWardOnCard (defenderActorId, locationId) {
  const defender = game.actors?.get(defenderActorId)
  if (!defender) return
  const items = getWardingItemsForLocation(defender, locationId)
  if (items.length === 0) {
    ui.notifications?.warn(`${defender.name} has no warding weapon covering this location.`)
    return
  }

  const location = defender.items.get(locationId)
  const locName = location?.name || 'location'
  const sizeLabels = CONFIG.ELYSIUM?.WEAPON_SIZES || {}
  const sizeOpts = SIZE_ORDER.map(s => `<option value="${s}">${sizeLabels[s] || s}</option>`).join('')

  const warderRows = items.map(it => {
    const wSize = it.system?.elysium?.weaponSize || 'M'
    return `<li><b>${it.name}</b> (Size ${sizeLabels[wSize] || wSize})</li>`
  }).join('')

  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:12px;">
        <b>${defender.name}</b> wards on <b>${locName}</b> with:
      </p>
      <ul style="margin:4px 0 8px 18px;font-size:12px;">${warderRows}</ul>
      <div class="form-group">
        <label>Attacker's Weapon Size</label>
        <select name="attackerSize">${sizeOpts}</select>
      </div>
      <div class="form-group">
        <label>Raw Damage</label>
        <input type="number" name="rawDamage" value="0" min="0" step="1">
      </div>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Apply Ward — ${defender.name}` },
    content,
    ok: {
      label: 'Resolve',
      callback: (event, button) => {
        const form = button.form
        return {
          attackerSize: form.querySelector('[name="attackerSize"]').value,
          rawDamage: Number(form.querySelector('[name="rawDamage"]').value) || 0,
        }
      },
    },
  }).catch(() => null)

  if (!result) return

  // Use the BEST warder (largest size) for the contest — multiple
  // warding items on the same location is unusual but possible;
  // largest gives the most favorable downgrade.
  let best = items[0]
  let bestIdx = SIZE_ORDER.indexOf(best.system?.elysium?.weaponSize || 'M')
  for (const it of items) {
    const idx = SIZE_ORDER.indexOf(it.system?.elysium?.weaponSize || 'M')
    if (idx > bestIdx) { best = it; bestIdx = idx }
  }
  const warderSize = best.system?.elysium?.weaponSize || 'M'

  const downgrade = wardDamageDowngrade(result.rawDamage, result.attackerSize, warderSize)
  const catLabel = downgrade.category === 'full' ? 'all damage deflected'
                  : downgrade.category === 'half' ? 'half damage deflected'
                  : 'no deflection (warder too small)'

  const body = `<p><b>${defender.name}</b> wards on <b>${locName}</b> with
      <b>${best.name}</b> (Size ${sizeLabels[warderSize] || warderSize})
      vs attacker Size ${sizeLabels[result.attackerSize] || result.attackerSize}.</p>
    <p>Raw damage <b>${result.rawDamage}</b> → ${catLabel} →
      <b>${downgrade.finalDamage}</b> damage gets through to the location.</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', icon: 'shield', body }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor: defender }),
    flags: { [FLAG_NS]: { wardApplied: true } },
  })
}

// ---------------------------------------------------------------------
// Chat-card delegation
// ---------------------------------------------------------------------

export function wireCoveringStanceChatHandlers () {
  document.body.addEventListener('click', async (ev) => {
    // Passive-block apply button — same data-action as alpha.7 so
    // existing chat cards still work if any are in the log
    const pbBtn = ev.target.closest('[data-elysium-pb-action]')
    if (pbBtn) {
      ev.preventDefault()
      const action = pbBtn.dataset.elysiumPbAction
      if (action === 'apply') {
        const messageId = pbBtn.dataset.pbMessageId
        const defenderActorId = pbBtn.dataset.pbDefenderId
        const locationId = pbBtn.dataset.pbLocationId
        await notePassiveBlockOnCard(messageId, defenderActorId, locationId)
      }
      return
    }

    // Ward apply button
    const wBtn = ev.target.closest('[data-elysium-ward-action]')
    if (wBtn) {
      ev.preventDefault()
      const action = wBtn.dataset.elysiumWardAction
      if (action === 'apply') {
        const defenderActorId = wBtn.dataset.wardDefenderId
        const locationId = wBtn.dataset.wardLocationId
        await applyWardOnCard(defenderActorId, locationId)
      }
    }
  })
}

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

export const ElysiumCoveringStance = {
  // Stance types
  STANCE_PASSIVE_BLOCK,
  STANCE_WARD,

  // State accessors
  getStance,
  isItemInCoveringStance,
  isItemPassivelyBlocking,
  isItemWarding,
  getCoveringItemsForLocation,
  getPassivelyBlockingItemsForLocation,
  getWardingItemsForLocation,
  getTotalPassiveAP,
  isLocationPassivelyBlocked,
  isLocationWarded,
  isShield,
  getMaxLocations,
  validateLocationSelection,
  wardDamageDowngrade,

  // Mutators
  setStance,
  clearStance,

  // Flow
  openStanceDialog,
  dropStance,
  notePassiveBlockOnCard,
  applyWardOnCard,

  // Integration
  wireCoveringStanceChatHandlers,
}
