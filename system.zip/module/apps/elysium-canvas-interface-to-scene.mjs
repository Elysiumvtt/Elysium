import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfaceToScene extends ElysiumCanvasInterface {
  static get PERMISSIONS () {
    return {
      ALWAYS: 'Elysium.ElysiumCanvasInterface.Permission.Always',
      GM: 'Elysium.ElysiumCanvasInterface.Permission.GM',
      SEE_TILE: 'Elysium.ElysiumCanvasInterface.Permission.SeeTile'
    }
  }

  static get icon () {
    return 'fa-solid fa-map'
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.ToScene.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.ToScene.Button.Hint'
      }),
      permission: new fields.StringField({
        blank: false,
        choices: Object.keys(ElysiumCanvasInterfaceToScene.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceToScene.PERMISSIONS[k]); return c }, {}),
        initial: 'GM',
        label: 'Elysium.ElysiumCanvasInterface.ToScene.Permission.Title',
        hint: 'Elysium.ElysiumCanvasInterface.ToScene.Permission.Hint',
        required: true
      }),
      sceneUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.ToScene.Scene.Title',
        hint: 'Elysium.ElysiumCanvasInterface.ToScene.Scene.Hint',
        type: 'Scene'
      }),
      tileUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.ToScene.Tile.Title',
        hint: 'Elysium.ElysiumCanvasInterface.ToScene.Tile.Hint',
        type: 'Tile'
      })
    }
  }

  async _handleMouseOverEvent () {
    switch (this.permission) {
      case 'ALWAYS':
        return true
      case 'GM':
        return game.user.isGM
      case 'SEE_TILE':
        if (game.user.isGM) {
          return true
        }
        if (this.tileUuid) {
          return !(await fromUuid(this.tileUuid)).hidden
        }
    }
    return false
  }

  async #handleClickEvent () {
    const doc = await fromUuid(this.sceneUuid)
    if (doc) {
      setTimeout(() => {
        doc.view()
      }, 100)
    } else {
      console.error('Scene ' + this.sceneUuid + ' not loaded')
    }
  }

  async _handleLeftClickEvent() {
    if (this.sceneUuid && this.triggerButton === ElysiumCanvasInterface.triggerButton.Left) {
      this.#handleClickEvent()
    }
  }

  async _handleRightClickEvent() {
    if (this.sceneUuid && this.triggerButton === ElysiumCanvasInterface.triggerButton.Right) {
      this.#handleClickEvent()
    }
  }
}
