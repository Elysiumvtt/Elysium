# P10 cluster 2 — 8 simple item types (prep audit)

Captured 2026-05-14 after cluster 1 (alpha.38) smoke pass.
**Audit-then-stop**: no code shipped from this document.

## Scope

Cluster 2 covers the 8 simplest item types per the top-level P10 audit's
audit-7 sequencing. By audit-2 lock-in, **6 go single-page** (no tabs)
and **2 keep tabs**:

| Type | Per audit-2 | Detail LOC | Special features |
|---|---|--:|---|
| reputation | single-page | 10 | trivial 1-field (only when owned) |
| failing    | single-page | 15 | GM/player split; description-input + shortDesc |
| wound      | single-page | 17 | itemToggle treated/untreated; has effects tab today |
| passion    | single-page | 20 | itemToggle improve; only renders body when owned |
| powerMod   | single-page | 20 | GM/player split; itemToggle perLvl; shortDesc input |
| mutation   | single-page | 30 | catOptions select; itemToggle minorOnly + minor; cat label |
| persTrait  | **keep tabs** | 47 | opposed-trait, basic toggle; full scores block; 2× itemToggle |
| allegiance | **keep tabs** | 49+13 | extra benefits tab (HTMLField); multiple itemToggles; conditional `isOr`/`isAnd` blocks |

### Width plan per audit-3

All 8 sit in the 560×640 default tier — no wide-variant items here.
Each sheet class's `DEFAULT_OPTIONS.position.width/height` gets updated.
Current widths range 480-600; cluster 2 normalizes all 8 to 560×640.

### Action handlers in use (cluster 2)

Per template grep:
- `itemToggle` with property `treated` (wound), `improve` (passion, persTrait, allegiance), `oppimprove` (persTrait), `basic` (persTrait), `minorOnly`/`minor` (mutation), `perLvl` (powerMod), `allegAllied`/`allegApoth`/`allegEnemy` (allegiance)
- `onEditImage` (header — all 8)
- `editBRPid` (frame button — all 8 inherit from base)
- `addItemEffect` / `openActiveEffect` (wound only — has effects PART)

All already registered. **Zero new handlers needed.**

## 1. Single-page mode design

The 6 single-page items lose their tabs / description / gmNotes / effects
PARTS. Their sheet becomes a 2-PART sheet:

```
PARTS = {
  header:  '...item-shell-header.hbs',
  details: '<itemType>.detail.hbs',
}
```

The `<itemType>.detail.hbs` template embeds:
1. Type-specific fields (the existing detail content, rebuilt with v1.0.0 partials)
2. Description (inline, below the fields) — both editable input and read-only enriched render
3. GM notes (inline, only when `isGM`)
4. Effects display (only for wound — preserves the v1.0.0 effects partial inline)

This implies the `single-page detail template` invokes the
`item-shell-description` and (where applicable) `item-shell-gmnotes` and
`item-shell-effects` partials inline rather than as separate PARTS. The
shell partials don't care whether they're invoked as a PART or as an
inline partial — they emit `<section>` with `data-tab=...` etc., which
on a single-page sheet has no consumer for the data-tab attribute (no
tabs strip to click), but doesn't actively break anything.

**Refinement**: for cleanliness, the partials' `<section class="item tab
description data-tab='description'">` markers are only really meaningful
when there's a tab strip to activate them. On single-page sheets we want
the sections to render **without** the tab activation chrome — they're
always visible.

Two ways to handle this:

### Decision (c2-A) — single-page partial variants vs context flag

**Option A**: Add a `singlePage` context flag and have the partials
conditionally drop the `tab.cssClass` / `data-tab` attributes. Pros:
single partial does double duty. Cons: pollutes the partials.

**Option B**: Create dedicated single-page variants (e.g.
`item-singlepage-description.hbs`, `item-singlepage-effects.hbs`) that
render just the content body without the section.tab wrapper. Pros:
clean separation. Cons: more partials to register.

**Option C**: Keep the existing partials as-is; they emit
`<section class="tab">` but on single-page sheets we want the section to
ALWAYS be visible. Add a `single-page-mode` class on the OUTER sheet
that overrides `section.tab` visibility for nested content sections.
Pros: zero new partials. Cons: relies on CSS specificity tricks.

**Recommendation: Option B** — dedicated single-page variants. Two new
partials (`item-singlepage-description.hbs` for description + gmNotes
combined, `item-singlepage-effects.hbs` for the effects display).
Single-page items invoke these directly inline from their detail
template. Multi-tab items continue invoking the existing
`item-shell-description/gmnotes/effects` partials at the PART level.

The pattern stays explicit and grep-able. Cluster-2 audit recommends
**Option B**.

## 2. Tabbed mode — persTrait + allegiance

Both keep their existing PARTS structure, just with new partial paths:

```
PARTS = {
  header:      '...item-shell-header.hbs',
  tabs:        '...item-shell-tabs.hbs',
  details:     '<itemType>.detail.hbs',
  description: '...item-shell-description.hbs',
  gmNotes:     '...item-shell-gmnotes.hbs',
}
```

Allegiance additionally:
```
  benefits: '<itemType>.benefits.hbs'  // its own per-type tab
```

The benefits tab is unique to allegiance. Its template needs the same
v1.0.0 ProseMirror treatment as description; cluster 2 also restyles
`allegiance.benefits.hbs` to use a `elysium-item-tab-content` outer
section + the ProseMirror block. Class hooks unchanged.

## 3. Header chips per cluster-2 item type

Per audit-6's "defer chip set to the cluster that ships that item":

| Type | Chips when not owned | Chips when owned |
|---|---|---|
| reputation | (none — no data when unowned) | Base score |
| failing | CPC mod (GM-only? — chips show regardless of perm) | (same) |
| wound | Damage value | Damage value + treated/untreated state |
| passion | (none — no data when unowned) | Base + XP + Total |
| powerMod | CPC mod | (same) |
| mutation | Impact category | Impact + minor/major when owned |
| persTrait | Opposed-trait name | Opposed-trait + Total + Opposed Total |
| allegiance | Opposed-allegiance | Opposed + Title + Allegiance Total |

**Recommendation (c2-B)**: lock the table above. Some chips (e.g. "Total"
for passion/persTrait/allegiance) are computed values; the sheet class's
`_prepareContext` reads them and adds to `itemHeaderChips`.

## 4. Hoisting — base-sheet shared methods

Cluster 1 deferred this. After cluster 1 + cluster 2's 8 sheets we'd
have 9 data points; 7 of those use nearly identical `_getTabs`,
`_preparePartContext`, `_configureRenderOptions`. The pattern:

```js
// Duplicated across 7 sheets (the tabbed ones — gear, allegiance, persTrait,
// and 6 of clusters 3-6) — same shape, different PARTS list, possibly
// different per-tab cases.
_getTabs(parts) { ... }
async _preparePartContext(partId, context) { ... }
_configureRenderOptions(options) {
  super._configureRenderOptions(options);
  options.parts = [...this.constructor.TAB_ORDER];
  if (game.user.isGM) options.parts.push('gmNotes');
}
```

### Decision (c2-C) — hoist or don't

**Option A**: Hoist into `base-item-sheet.mjs`. Each subclass overrides
only `TAB_ORDER` (an array of PART names in render order). Base
implementation handles tab construction, GM gating, ProseMirror
enrichment for description/gmNotes, default-tab selection.

**Option B**: Don't hoist; each sheet keeps its own duplicated methods.

**Recommendation: Option A** — hoist now. We have 2 data points (gear +
the cluster-1 architecture) plus 19 more sheets coming in clusters 2-6.
Hoisting saves ~50 LOC per sheet × ~20 sheets = ~1000 LOC of duplication,
and centralizes the tab/context lifecycle so future patterns (like
changing the ProseMirror config) happen in one place.

**Single-page sheets** are simpler still — they get a different base
method that just sets `options.parts = ['header', 'details']` and
doesn't build a tabs object. The base provides BOTH modes via a
sheet-class flag (e.g. `static SINGLE_PAGE = true`).

Proposed base-class additions:

```js
class ElysiumItemSheetV2 {
  // Sub-classes override to declare their tab ordering. If null, sheet
  // is single-page (no tabs PART). Description and gmNotes inclusion is
  // implicit when tabs ordering includes them.
  static TAB_ORDER = null;

  _configureRenderOptions(options) {
    super._configureRenderOptions(options);
    if (this.constructor.TAB_ORDER) {
      options.parts = [...this.constructor.TAB_ORDER];
      if (game.user.isGM && this.constructor.TAB_ORDER.includes('gmNotes')) {
        // Already in list — no-op
      } else if (game.user.isGM && this.constructor.PARTS.gmNotes) {
        options.parts.push('gmNotes');
      }
    } else {
      // Single-page mode
      options.parts = ['header', 'details'];
    }
  }

  _getTabs(parts) {
    if (!this.constructor.TAB_ORDER) return {};
    // ... existing _getTabs logic, including per-tab label customization
    // via this.constructor.TAB_LABEL_OVERRIDES (optional subclass override)
  }

  async _preparePartContext(partId, context) {
    // Default handling for the 5 shell parts (header/tabs/details/
    // description/gmNotes/effects). Sub-classes can override for
    // type-specific tabs (e.g. allegiance.benefits).
    switch (partId) {
      case 'details':
      case 'effects':
        if (context.tabs) context.tab = context.tabs[partId];
        break;
      case 'description':
        if (context.tabs) context.tab = context.tabs[partId];
        context.enrichedDescription = await this._enrichField('description');
        break;
      case 'gmNotes':
        if (context.tabs) context.tab = context.tabs[partId];
        context.enrichedGMDescription = await this._enrichField('gmDescription');
        break;
    }
    return context;
  }

  async _enrichField(fieldName) {
    return foundry.applications.ux.TextEditor.implementation.enrichHTML(
      this.item.system[fieldName],
      {
        secrets: this.document.isOwner,
        rollData: this.document.getRollData(),
        relativeTo: this.document,
      }
    );
  }
}
```

Sub-class override pattern (after hoist):
```js
class ElysiumGearSheet extends ElysiumItemSheetV2 {
  static TAB_ORDER = ['header', 'tabs', 'details', 'effects',
                       'description'];  // gmNotes appended by base
  static PARTS = { header: ..., tabs: ..., details: ..., effects: ...,
                   description: ..., gmNotes: ... };
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    // Type-specific context (chips, options, etc.)
    context.itemHeaderChips = [...];
    return context;
  }
  // No _getTabs / _preparePartContext / _configureRenderOptions override
}
```

Per-sheet line counts after hoist: ~70-90 LOC instead of ~140-200.

**Migration plan**:
1. Cluster 2 ships the hoisted methods in `base-item-sheet.mjs`.
2. Cluster 2 ALSO migrates gear (from cluster 1) to the hoisted pattern
   as a clean-up — proves the hoist works against the validator first.
3. Then migrates the 8 cluster-2 sheets to the hoisted pattern.

This is a slight scope expansion to cluster 2 (gear cleanup), but it's
the right time — better to migrate one extra sheet now than have 6 more
clusters land with the un-hoisted pattern.

### c2-C recommendation: **hoist, migrate gear + the 8 cluster-2 sheets in this ship.**

## 5. New partials needed in cluster 2

Per c2-A Option B recommendation:
- `templates/item/parts/item-singlepage-description.hbs` (~15 lines):
  description + optional GM-only notes inline, no section.tab wrapper.
- `templates/item/parts/item-singlepage-effects.hbs` (~50 lines):
  effects display without the section.tab wrapper. Used by single-page
  wound.

Both registered in `init.mjs:2a` with a "P10 cluster 2 (alpha.39)"
comment.

## 6. Templates to rewrite (8 + allegiance.benefits = 9 templates)

| Template | Current LOC | Estimated new LOC | Mode |
|---|--:|--:|---|
| reputation.detail.hbs | 10 | ~30 | single-page (1 field + inline desc) |
| failing.detail.hbs    | 15 | ~40 | single-page |
| wound.detail.hbs      | 17 | ~55 | single-page (incl. effects) |
| passion.detail.hbs    | 20 | ~50 | single-page |
| powerMod.detail.hbs   | 20 | ~45 | single-page |
| mutation.detail.hbs   | 30 | ~55 | single-page |
| persTrait.detail.hbs  | 47 | ~75 | tabbed |
| allegiance.detail.hbs | 49 | ~90 | tabbed |
| allegiance.benefits.hbs | 13 | ~20 | tabbed (restyle ProseMirror) |

Total new: ~460 LOC across 9 templates.

## 7. Sheet class edits (8 + gear cleanup = 9 sheets)

After hoist:

| Sheet class | Current LOC | Estimated new LOC | Notes |
|---|--:|--:|---|
| gear.mjs (cluster-1 cleanup) | 167 | ~85 | migrate to hoisted base |
| reputation.mjs | 123 | ~65 | single-page; remove _getTabs/_preparePartContext/_configureRenderOptions; add chips |
| failing.mjs    | 123 | ~65 | single-page |
| wound.mjs      | 106 | ~75 | single-page; preserves effects context-prep |
| passion.mjs    | 124 | ~65 | single-page |
| powerMod.mjs   | 121 | ~65 | single-page |
| mutation.mjs   | 129 | ~80 | single-page; keeps catOptions/catName/skillCatOptions prep |
| persTrait.mjs  | 121 | ~70 | tabbed; chip context |
| allegiance.mjs | 136 | ~85 | tabbed; adds `benefits` case to _preparePartContext (sub-class override) |

Plus `base-item-sheet.mjs` gains ~80 LOC of hoisted methods.

Net effect: 1133 LOC of sheet classes (today) → ~735 LOC + 80 LOC base
= ~815 LOC after cluster 2. Reduction of ~318 LOC, plus the shared
methods are now in one place.

## 8. CSS additions

The cluster-1 CSS already covers most of cluster 2's needs (field row,
chip, header, tabs, description). New rules needed in cluster 2:

- **Single-page section spacing** — `.elysium-item-singlepage-section`
  divider between the detail block, description block, gmnotes block,
  effects block on single-page sheets. ~15 lines.
- **Inline GM notes call-out** — visual distinction for the GM-only
  notes block when rendered inline on a single-page sheet (so the GM
  can see it's an internal note vs the player-visible description).
  Subtle dashed border + muted text color. ~20 lines.
- **`.elysium-item-toggle`** — for the various `itemToggle` patterns
  (treated/untreated, minorOnly, basic, improve, allegAllied etc.).
  Replaces legacy `toggle-active` (34 refs). ~25 lines.
- **Improve checkbox icon styling** — the existing `improve-checkbox`
  partial (from P9) handles actor-side; item-side has its own
  `fa-square` / `fa-square-check` icons in several sheets. We layer a
  `.elysium-item-improve-checkbox` class on them. ~15 lines.

Estimated +75 lines / +9 brace pairs.

## 9. Smoke risks specific to cluster 2

1. **Hoisting introduces a base-class regression** — if the hoisted
   `_preparePartContext` doesn't perfectly match all 9 sheets'
   existing behavior, those sheets break. Mitigation: thorough audit
   of each sheet's current method before hoisting (done in §4 above),
   and gear smoke-tests the hoist first since gear is already known
   to work.

2. **Single-page wound effects must still bind activateListeners** —
   `ElysiumActiveEffectSheet.activateListeners(this)` is called from
   `wound.mjs::_onRender`. The legacy class hook
   `active-effect-change-edit` must be preserved in the new
   `item-singlepage-effects.hbs` (audit-5 lock applies cluster-wide).

3. **isOr/isAnd helpers used by allegiance** — already registered in
   `handlebar-helper.mjs:4-10`. The v1.0.0 template should continue to
   use them; no helper changes.

4. **`shortDesc` input on failing + powerMod** — looks like a
   secondary description distinct from system.description. The
   legacy template renders it inline as a single-line input. The
   new single-page template should keep this as a field row, not
   collapse into the inline description block.

5. **Chip context for items with no `system.X.Y` value** — some
   chips (e.g. allegiance Title, persTrait opposed-trait) read string
   fields that may be empty. Apply the same em-dash fallback pattern
   gear's chip-build code uses (cluster 1 mid-smoke fix).

6. **wound's existing PARTS includes `effects`** — sheet currently
   has `header` + `tabs` + `details` + `effects` (no description /
   gmNotes). When moving to single-page (per audit-2), the wound sheet
   should NOT lose effects display — it inlines them via the new
   `item-singlepage-effects` partial below the detail.

7. **Passion + persTrait gate their main content on `{{#if hasOwner}}`**
   — the unowned sheets render essentially-empty bodies. The header
   chips are also gated on hasOwner. Pre-flight smoke: unowned passion
   renders header + empty body cleanly.

## 10. Cluster 2 open questions for user lock-in

1. **c2-1 (Option B vs A vs C for single-page partials)**: confirm
   Option B — dedicated single-page partials.

2. **c2-2 (header chip sets per item)**: lock the §3 table or flip
   specific rows.

3. **c2-3 (hoist now or later)**: confirm Option A — hoist in cluster 2,
   migrate gear + the 8 cluster-2 sheets in this ship.

4. **c2-4**: Sheet width — all 8 fit 560×640. Confirm or flip any.

5. **c2-5**: Failing + powerMod expose a `shortDesc` field. Confirm
   keeping it as an inline single-line input (separate from
   `system.description` ProseMirror), OR fold it into the description?
   Recommendation: **keep as inline single-line field** — it's a
   short-form summary distinct from the long-form description per
   schema.

## 11. Ship plan

1. Hoist shared methods into `base-item-sheet.mjs`.
2. Migrate gear.mjs to the hoisted pattern (cluster-1 cleanup).
3. Create 2 new single-page partials in `templates/item/parts/`.
4. Rewrite 9 detail templates (8 cluster-2 + allegiance.benefits).
5. Update 8 cluster-2 sheet classes (single-page or tabbed mode).
6. Append CSS (~75 lines).
7. Register new partials in `init.mjs:2a`.
8. Pre-flight sweep.
9. Package + present.
10. Smoke test live.

## 12. Smoke list for cluster 2

After install:

a. **Gear regression** — open the cluster-1 gear; verify it still
   renders with all the same chips and field grids as alpha.38, now via
   the hoisted base. Tab switching still works.
b. **Each of the 6 single-page item types** — create one of each in
   the world; open the sheet; verify:
   - 560×640 width, new 3-zone header, chips per c2-B table.
   - NO tabs strip rendered.
   - Detail body present.
   - Description block inline below detail (ProseMirror in edit mode).
   - GM Notes block inline below description WHEN viewing as GM.
   - Wound: effects display inline below detail; legacy class hook
     preserved; clicking add-effect still works (regression check on
     audit-5 lock).
c. **persTrait** — open the sheet; verify tabs render
   (Details/Description/GM Notes); header chips per c2-B; itemToggle
   for basic/improve/oppimprove still flips state.
d. **allegiance** — open the sheet; verify 4 tabs render
   (Details/Benefits/Description/GM Notes); benefits tab renders
   ProseMirror; itemToggle for allegAllied/allegApoth/allegEnemy/
   improve still flips state.
e. **22-sheet regression** — open one item type from EACH of the
   non-cluster-2-non-gear types (e.g. weapon, armor, super, arcane,
   skill, etc. — 14 types); verify they all render via legacy paths
   without errors. Cluster isolation check.

## 13. Ready-to-go checklist

- [x] 8 sheet classes audited for prepareContext + _getTabs +
      _preparePartContext shape
- [x] 8 templates audited for content + legacy class usage + action
      handlers + isOr/isAnd helper use
- [x] Single-page vs tabbed mode locked per item (audit-2 inheritance)
- [x] Width plan locked (all 8 → 560×640)
- [x] Header chip plans drafted per item type
- [x] Hoist strategy designed
- [x] New partial design (2 single-page variants)
- [x] CSS plan estimated
- [x] Smoke risks enumerated (7 distinct)
- [ ] User decision on 5 cluster-2 open questions (all have
      recommendations)
- [ ] Approval to ship cluster 2 (alpha.39)

---

**Audit posture**: read-only until user locks the 5 open questions.
