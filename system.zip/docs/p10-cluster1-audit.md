# P10 cluster 1 — shell scaffold + gear validator (prep audit)

Captured 2026-05-14, after P10 prep audit lock-in.
**Audit-then-stop**: no code shipped from this document. Lock the open
decisions in §3 to open the cluster 1 ship.

## Context

P10 cluster 1 is the **shared shell scaffold** for all 23 item sheets,
validated against **gear** (audit-3 lock).

Cluster 1 ships:
1. The 5 v1.0.0 shell partials that every item sheet consumes (header,
   tabs, description, gmnotes, active-effects).
2. The 4 supporting v1.0.0 utility partials for repeating row/grid/chip
   patterns (deferred from §4 of the top-level audit; cluster 1 ships
   the ones gear depends on).
3. Token additions for item-sheet width (560/720 two-tier).
4. The gear sheet rebuilt to use the new scaffold (the validator).
5. CSS additions to `elysium-sheets.css`.

Cluster 1 does NOT touch the other 22 item types' templates or sheets.
Their sheets continue to render against legacy CSS through cluster 1
because they still invoke the legacy `item.header.hbs`,
`tab-navigation.hbs`, `item.description.hbs`, `item.gmnotes.hbs`,
`item.active-effects.hbs` paths — which are kept alive at the legacy
paths (we add NEW v1.0.0 partials at NEW paths rather than overwriting
the old ones).

## 1. Validator — gear inspection

`templates/item/gear.detail.hbs` (39 lines) renders:
- **Block 1** (always shown): 4 fields — encumbrance, price (select),
  pSCurr, pSMax — laid out in a 2-column "armor-scores" grid (3 rows
  of label + value).
- **Block 2** (only when `hasOwner`, i.e. item belongs to a character):
  3 fields — quantity (input), actlEnc (read-only computed), status
  (select).

Sheet class context (`gear.mjs:30-47`):
- `burdenOptions` (unused in template — defensively present)
- `priceOptions` (used in block 1 select)
- `hitLocOptions` (unused in template — defensively present)
- `equippedOptions` (used in block 2 select)
- `priceName` / etc. (unused in template — used in legacy item rows)
- `effects` / `effectKeys` / `effectChanges` (consumed by active-effects
  tab)

PARTS: standard 5-PART (header, tabs, details, effects, description,
gmNotes-conditional). 6 actual parts when GM, 5 when player.

### Why gear is the right validator
- Non-trivial detail (2 blocks, 7 fields, select+input+read-only mix).
- Uses every shared shell partial (header, tabs, desc, gmnotes,
  active-effects).
- Has the `hasOwner` conditional branch — exercises layout in 2 modes.
- Sheet class is small (143 LOC), easy to validate the migration
  pattern.
- Action handlers used: `onEditImage`, `editBRPid`, `addItemEffect`,
  `openActiveEffect`. No specialized handlers. Good baseline.

## 2. Shell partials — designs locked

All new shell partials live in `templates/item/parts/`. The legacy
partials at `templates/item/item.*.hbs` and
`templates/global/parts/tab-navigation.hbs` are LEFT UNTOUCHED so
non-rebuilt sheets continue to render. Cluster 1 introduces the new
parallel paths; each subsequent cluster swaps consumers over.

### Partial 1 — `parts/item-shell-header.hbs` (~20 lines)

3-zone header per audit-6 lock:

```
┌───────────────────────────────────────────────────────────────┐
│ IMG  │ NAME (display font, large, inline editable when allowed)│
│ 64   │ TYPE LABEL                                              │
│  ×64 │ HEADER CHIPS (per-type: cost / equip / cast / range)    │
└───────────────────────────────────────────────────────────────┘
```

Markup:
```html
<header class="elysium-item-header">
  <img class="elysium-item-header-image" ... data-action="onEditImage">
  <div class="elysium-item-header-text">
    {{#if editable}}
      <input class="elysium-item-header-name" name="name" ...>
    {{else}}
      <div class="elysium-item-header-name">{{item.name}}</div>
    {{/if}}
    <div class="elysium-item-header-type">{{itemType}}</div>
    {{#if itemHeaderChips}}
      <div class="elysium-item-header-chips">
        {{#each itemHeaderChips as |chip|}}
          <span class="elysium-item-header-chip"
                {{#if chip.tooltip}}data-tooltip="{{chip.tooltip}}"{{/if}}>
            {{#if chip.icon}}<i class="{{chip.icon}}"></i>{{/if}}
            <span class="elysium-item-header-chip-label">{{chip.label}}</span>
            {{#if chip.value}}<span class="elysium-item-header-chip-value">{{chip.value}}</span>{{/if}}
          </span>
        {{/each}}
      </div>
    {{/if}}
  </div>
</header>
```

`context.itemHeaderChips` is populated by each sheet class (e.g. gear
sets `[{label: 'ENC', value: 1.5}, {label: 'Status', value: 'Equipped'}]`).
When the array is absent or empty, no chips zone renders. Single
source of truth; sheet classes own which chips fire.

### Partial 2 — `parts/item-shell-tabs.hbs` (~15 lines)

Mirror of the actor's primary tab strip pattern, horizontal at the top
of the sheet (vertical strips are for actor sheets only):

```html
<nav class="tabs elysium-item-tabs" aria-label="...">
  {{#each tabs as |tab|}}
    <a class="elysium-item-tab-chip {{tab.cssClass}}"
       data-action="tab" data-group="{{tab.group}}" data-tab="{{tab.id}}"
       {{#if tab.tooltip}}data-tooltip="{{tab.tooltip}}"{{/if}}>
      {{#if tab.icon}}<i class="{{tab.icon}}"></i>{{/if}}
      <span class="elysium-item-tab-chip-label">{{localize tab.label}}</span>
    </a>
  {{/each}}
</nav>
```

The `tabs` outer class is required for Foundry V14 `changeTab`
selector resolution (alpha.18 lesson).

### Partial 3 — `parts/item-shell-description.hbs` (~15 lines)

```html
<section class="item tab description elysium-item-tab-content {{tab.cssClass}}"
         data-group="primary" data-tab="description">
  {{#if editable}}
    <prose-mirror name="system.description" value="{{system.description}}"
                  editable="{{editable}}" toggled="false">
      {{{enrichedDescription}}}
    </prose-mirror>
  {{else}}
    <div class="elysium-item-description-readonly">{{{enrichedDescription}}}</div>
  {{/if}}
</section>
```

Note: drops the legacy `<div class="bold">Description</div>` label.
The tab chip already says "Description"; the label was redundant.

### Partial 4 — `parts/item-shell-gmnotes.hbs` (~12 lines)

Same shape as description, but for `system.gmDescription`. Tab
content; rendered only when user is GM (sheet class continues to
gate `gmNotes` PART on `game.user.isGM`).

### Partial 5 — `parts/item-shell-effects.hbs` (~50 lines)

This is the trickiest shell partial because of audit-5's
restyle-only constraint: `ElysiumActiveEffectSheet.activateListeners`
binds JS on legacy class hooks. **Preserved legacy class
hooks** (confirmed via inspection of `module/sheets/elysium-active-effect-sheet.mjs:`):

- `div.active-effect-change-edit` (each change row — required)
- Within each change row: `select`, `input`, `.fa-trash`

The v1.0.0 markup LAYERS new classes on top:
```html
<div class="elysium-effect-change-row active-effect-change-edit">
  ...
</div>
```

This is the same pattern P9 cluster 4 used for bio-section CRUD
(alpha.35). Active-effects-to-V14-actions migration → P12.

The data-action attrs (`addItemEffect`, `openActiveEffect`) keep
firing because they are V14 actions; the JS-bound class listeners
on `.active-effect-change-edit *` are the surface that needs the
legacy class preserved.

### Partials 6-9 — body utility partials

These are the building blocks for item DETAIL templates (used by
gear in cluster 1; used by every other item template in clusters 2-6).

**`parts/item-field-row.hbs`** (~10 lines):
A label + input/display pair. Replaces the most-common pattern
(`skill-display` + `stat-input`, 172+71 legacy refs together):

```html
<div class="elysium-item-field-row">
  <label class="elysium-item-field-label"
         {{#if tooltip}}data-tooltip="{{tooltip}}"{{/if}}>{{label}}</label>
  <div class="elysium-item-field-value">{{> @partial-block}}</div>
</div>
```

The partial uses Handlebars' `@partial-block` so callers can
inject any input/select/display markup. The callers in
`gear.detail.hbs` will be:

```handlebars
{{#> "systems/elysium/templates/item/parts/item-field-row.hbs"
      label=(localize 'Elysium.enc')}}
  <input name="system.enc" type="text" value="{{item.system.enc}}" data-dtype="Number">
{{/inline}}
```

**`parts/item-field-grid.hbs`** — a flex/grid wrapper:
```html
<div class="elysium-item-field-grid {{#if cols}}elysium-item-field-grid--{{cols}}-col{{/if}}">
  {{> @partial-block}}
</div>
```

Defaults to 2-column. Caller can pass `cols=3` etc.

**`parts/item-chip.hbs`** — read-only value pill (replaces
`boxed centre`, 79+147 legacy refs):
```html
<span class="elysium-item-chip {{#if variant}}elysium-item-chip--{{variant}}{{/if}}">
  {{#if icon}}<i class="{{icon}}"></i>{{/if}}
  {{value}}
</span>
```

**`parts/item-section-card.hbs`** — a complete section card with
header + body, alias to the actor-sheet section-card pattern:
```html
<section class="elysium-tab-section-card">
  {{> "systems/elysium/templates/actor/parts/tab-section-card-header.hbs"
        title=title countLabel=countLabel}}
  <div class="elysium-tab-section-card-body">
    {{> @partial-block}}
  </div>
</section>
```

Reuses the alpha.36 `tab-section-card-header` from the actor surface.

### Where utility partials live

`templates/item/parts/` is the new home. Distinct from
`templates/actor/parts/` (which is actor-specific) and
`templates/global/parts/` (which is the legacy junk drawer — left as-is
until P12).

### Total cluster 1 partials

5 shell + 4 utility = 9 new partials, all registered in
`init.mjs:2a` `loadTemplates([...])` with a `// Cluster 1 (alpha.38)`
comment block.

## 3. Open questions for cluster 1 lock-in

1. **c1-1**: Single-page items in cluster 2 will skip the
   tabs/desc/gmnotes/effects PARTS entirely (their detail template
   embeds description inline). Cluster 1 needs to decide: does the
   `item-shell-header.hbs` partial render usefully on a single-page
   sheet? Recommendation: **yes** — the header always renders, the
   tabs strip is what's omitted. Standalone validation: just confirm
   that gear's header renders identically whether tabs are present or
   not.

2. **c1-2**: Gear's header chip set — recommended chips:
   - Encumbrance value (`{{system.actlEnc}}` if `hasOwner`, else
     `{{system.enc}}`)
   - Price label (`{{priceName}}`)
   - Equip status (`{{equippedName}}` if `hasOwner`)
   Recommendation: **3 chips when owned, 2 chips when not**.

3. **c1-3**: Sheet-width tokens — proposed names
   `--ely-item-sheet-width` (560), `--ely-item-sheet-width-wide` (720),
   `--ely-item-sheet-height` (640), `--ely-item-sheet-height-wide`
   (720). Each item-sheet class's `DEFAULT_OPTIONS.position` reads
   from these via JS (not CSS — Foundry V14 position values are
   numeric and resolved before any CSS applies). Recommendation:
   define tokens in `elysium-tokens.css` for self-documentation, but
   use literal numbers in `DEFAULT_OPTIONS.position` since CSS vars
   can't reach there. Alternative: skip the tokens and use literals
   throughout. **Recommendation: use literals, defer token-file
   addition to P12** (the audit-3 lock specified the 560/720 model,
   not specifically tokens).

4. **c1-4**: `_getTabs` and `_preparePartContext` and
   `_configureRenderOptions` — gear's are 3 separate methods that
   are duplicated across nearly every item sheet (often line-for-line
   identical except for the PARTS list). Could be hoisted into
   `base-item-sheet.mjs` as a shared default. Cluster 1
   recommendation: **don't hoist yet**; rebuild gear in-place
   first to confirm the new scaffold works, then evaluate hoisting
   in cluster 2 once we have more data points. Cluster 1 just
   rebuilds gear's three methods to use the new partial paths.

5. **c1-5**: ProseMirror enrichment paths — the
   `description`/`gmNotes` PARTS' `_preparePartContext` does an
   `enrichHTML` call. That logic is ALSO duplicated across nearly
   every sheet. Same hoist question. Recommendation: same as c1-4
   — defer hoisting to cluster 2 once we've seen two implementations
   and can confirm the pattern.

## 4. Smoke risks specific to cluster 1

1. **Header-chip context plumbing** — if a sheet class forgets to
   set `context.itemHeaderChips`, the partial silently renders no
   chips (the `{{#if itemHeaderChips}}` block falls through). This is
   correct behavior but means missing chips look identical to
   intentional empty-chips. Mitigation: cluster 1 documents the
   chip context contract; cluster 2 audits include a checklist
   step for "header chips defined" per sheet class.

2. **Active-effects legacy class breakage** — if I rename
   `active-effect-change-edit` to a v1.0.0 BEM modifier, the JS
   listeners go silent. Mitigation: audit-5 lock; legacy class is
   PRESERVED, v1.0.0 class is LAYERED. Pre-flight check: grep the
   active-effects file for `active-effect-change-edit` after
   the rebuild.

3. **Tab strip ancestor `.tabs` class** — alpha.18/alpha.37
   lesson. The new `item-shell-tabs.hbs` MUST include `tabs` in the
   outer nav class list, otherwise Foundry's `changeTab` selector
   resolution fails. Already noted in §2 partial 2 spec; pre-flight
   check on the rendered template.

4. **Existing item sheets continuing to render correctly** — the
   22 sheets that DON'T get rebuilt in cluster 1 must keep rendering.
   Risk: if I edit any of the legacy paths
   (`templates/item/item.header.hbs` etc.) inadvertently, those 22
   sheets break. Mitigation: cluster 1 ADDS partials at NEW paths
   (`templates/item/parts/item-shell-*.hbs`); the legacy paths are
   untouched. Pre-flight: `diff` the unchanged legacy files at
   ship time.

5. **Width change visible on gear** — gear's sheet class will
   override `DEFAULT_OPTIONS.position.width` from 520 to 560.
   Visual change is small (40px wider). Not really a regression
   risk; just a noticeable diff in the smoke screenshot if anyone
   compares against pre-alpha.38.

## 5. Ship plan

1. New partials: 5 shell + 4 utility (described in §2).
2. Register all 9 in `init.mjs:2a` `loadTemplates([...])`.
3. Rebuild **gear** to use the new partials:
   - `templates/item/gear.detail.hbs` rewritten to use
     `item-field-row` + `item-field-grid`.
   - `module/item/sheets/gear.mjs` updates:
     - `PARTS` paths swapped to the new shell partials.
     - `DEFAULT_OPTIONS.position.width = 560`, `height = 640`.
     - `_prepareContext` adds `context.itemHeaderChips = [...]`
       per c1-2.
4. CSS additions to `styles/elysium-sheets.css`:
   - Item shell header (3-zone layout)
   - Item shell tabs (horizontal strip variant)
   - Item shell tab-content sections
   - Item field row + grid
   - Item chip (variant set)
   - Item section card body (extends the actor section-card)
   - Item effects tab restyled (preserving legacy `active-effect-change-edit` hook)
   Estimated +180 LOC, ~22 rule blocks.
5. Pre-flight: CSS brace balance, token resolution sweep, Handlebars
   block balance, `node --check` on the touched .mjs, `system.json`
   parse.
6. Package + present.
7. Live smoke after install.

## 6. Smoke list for cluster 1

After install:

a. Open a Gear item via the items directory (create one if needed).
   Verify:
   - Sheet width is 560×640 (vs the legacy 520×600).
   - Header shows IMG + NAME + TYPE LABEL + chips (3 when owned).
   - Tab strip horizontal across the top: Details / Effects /
     Description / GM Notes (last only when GM).
   - Click each tab → content swaps. Tab styling rides framework's
     `.active` toggle (alpha.37 lesson — bare `.active` class, not
     BEM).
   - Details tab: 2-column grid with all 4 always-shown fields;
     `hasOwner` block adds 3 more fields if the gear is on an actor.
   - Effects tab: change-row markup includes both
     `elysium-effect-change-row` (new) AND `active-effect-change-edit`
     (legacy preserved). Click on the `addItemEffect` button → new
     change row appears. Click `.fa-trash` on a change row → row
     removes. Both fired through the legacy class hooks.
   - Description tab: ProseMirror renders, edits save on blur.
   - GM Notes tab (as GM): same as Description for the
     `system.gmDescription` field.
   - ElysiumID fingerprint button in header frame: clickable, opens
     ElysiumID editor.
b. Open a WEAPON item (cluster-1 NOT-rebuilt). Verify:
   - Renders identically to pre-alpha.38 (no regressions on
     non-cluster-1 sheets).
c. Open an ARMOR item. Same regression check as weapon.
d. Pre-flight regression on all 22 non-rebuilt item types: render
   sheet of each, console clean.

## 7. Ready-to-go checklist

- [x] Gear inspected (template + sheet class + actions)
- [x] Shell partial designs locked
- [x] Utility partial designs locked
- [x] Active-effects preservation strategy locked (audit-5)
- [x] Width strategy locked (audit-3, 560 baseline for gear)
- [x] Smoke list drafted
- [ ] User decision on 5 cluster-1 open questions (all have
      recommendations)
- [ ] Approval to ship cluster 1 (alpha.38)
