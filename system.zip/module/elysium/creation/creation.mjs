/**
 * Elysium Character Creation
 *
 * Provides:
 *   - 4D6 drop lowest stat rolling
 *   - Stat assignment dialog
 *   - Build Point/Skill Point pool tracking
 *   - Stat advance via EXP dice (gamble or guaranteed)
 *
 * The full character creation flow uses a wizard-style dialog,
 * but the underlying methods can be called individually from macros.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
export class ElysiumCharacterCreation {

  /**
   * Roll seven stats (4D6 drop lowest).
   * Returns an array of seven values to assign.
   */
  static async rollSevenStats () {
    const method = getSetting('statRollMethod', '4d6dl')
    const rolls = []

    for (let i = 0; i < 7; i++) {
      let result
      if (method === '4d6dl') {
        const r = await new Roll('4d6kh3').evaluate()
        result = r.total
      } else if (method === '3d6') {
        const r = await new Roll('3d6').evaluate()
        result = r.total
      } else if (method === '2d6+6') {
        const r = await new Roll('2d6+6').evaluate()
        result = r.total
      } else {
        result = 10
      }
      rolls.push(result)
    }
    return rolls.sort((a, b) => b - a)    // sorted descending
  }

  /**
   * Roll a single stat
   */
  static async rollOneStat (formula = '4d6kh3') {
    const r = await new Roll(formula).evaluate()
    return r.total
  }

  /**
   * Open the stat assignment dialog after rolling.
   */
  static async assignRolledStats (actor, rolls) {
    const stats = ['str', 'con', 'siz', 'int', 'pow', 'dex', 'cha']

    const optionsHtml = rolls.map((r, idx) =>
      `<option value="${idx}">${r}</option>`).join('')

    const formRows = stats.map(stat => `
      <div class="form-group">
        <label>${game.i18n.localize(`Elysium.Stats.${stat}`)}</label>
        <select name="${stat}">${optionsHtml}</select>
      </div>
    `).join('')

    // DialogV2.wait resolves with whatever the per-button callback returns
    // (or the action string if no callback). On window-X close, returns
    // null because rejectClose:false.
    const result = await foundry.applications.api.DialogV2.wait({
      window: { title: game.i18n.localize('Elysium.Creation.AssignStats') },
      content: `
        <div class="elysium-creation-stats">
          <p>${game.i18n.localize('Elysium.Creation.AssignStatsHint')}</p>
          <p>${game.i18n.localize('Elysium.Creation.RolledValues')}: ${rolls.join(', ')}</p>
          ${formRows}
        </div>
      `,
      buttons: [
        { action: 'cancel', label: game.i18n.localize('Cancel') },
        { action: 'apply', label: game.i18n.localize('Apply'), default: true,
          callback: async (event, button, dialog) => {
            const assignments = {}
            for (const stat of stats) {
              const select = dialog.element.querySelector(`select[name="${stat}"]`)
              const idx = parseInt(select?.value || 0)
              assignments[stat] = rolls[idx]
            }
            await this._applyAssignedStats(actor, assignments)
            return assignments
          }},
      ],
      rejectClose: false,
    })
    // The cancel button returns its action string ('cancel'); apply returns the
    // assignments object; window-close returns null. Normalise: only the
    // object form represents a real result.
    return (typeof result === 'object' && result !== null) ? result : null
  }

  static async _applyAssignedStats (actor, assignments) {
    const update = {}
    for (const stat in assignments) {
      update[`system.stats.${stat}.base`] = assignments[stat]
    }
    await actor.update(update)
  }

  /**
   * Increase a stat using EXP dice — Gamble method.
   * Returns: { success, rolled, dice, increased }
   */
  static async gambleStatIncrease (actor, stat) {
    const current = this._statBaseValue(actor, stat)
    // v1.0.0-alpha.11 (side-finding #1): read from system.elysium.*,
    // matching the writer in ancestry-drop._adjustStatMaxima and the
    // CharacterDataModel's TypedObjectField declaration. Previously read
    // from flags.elysium.* which the writers don't populate — silent
    // empty-read.
    const naturalMax = (actor.system?.elysium?.statNaturalMax?.[stat] ||
                        ELYSIUM.STAT_NATURAL_MAX_BASE)

    if (current >= naturalMax) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.AtMax', {
        stat, max: naturalMax,
      }))
      return { success: false, atMax: true }
    }

    const expDice = actor.system?.elysium?.expDice?.available || 0
    if (expDice < 1) {
      ui.notifications.warn(game.i18n.localize('Elysium.Stats.NoExpDice'))
      return { success: false, noDice: true }
    }

    // Spend 1 EXP die, roll 3D6 vs current score
    const roll = await new Roll('3d6').evaluate()
    const success = roll.total > current

    const newDice = expDice - 1
    const updates = {
      [`system.elysium.expDice.available`]: newDice,
    }

    if (success) {
      updates[`system.stats.${stat}.exp`] = (actor.system.stats[stat]?.exp || 0) + 1
    }

    await actor.update(updates)

    const gaBody = `<p>${stat.toUpperCase()}: ${current} (target > ${current})</p>
      <p>${game.i18n.localize('Elysium.Roll')} 3d6: <strong>${roll.total}</strong></p>
      <p>${success
        ? game.i18n.format('Elysium.Stats.IncreasedTo', { stat, value: current + 1 })
        : game.i18n.localize('Elysium.Stats.NoIncrease')}</p>`
    const gaHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
      {
        variant: success ? 'success' : 'danger',
        title: `${actor.name} — ${game.i18n.localize('Elysium.Stats.GambleAdvance')}`,
        icon: 'dice',
        body: gaBody,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: gaHtml,
    })

    return { success, rolled: roll.total, dice: 1, increased: success ? 1 : 0 }
  }

  /**
   * Increase a stat using EXP dice — Guaranteed method.
   * Costs EXP dice equal to current score.
   */
  static async guaranteedStatIncrease (actor, stat) {
    const current = this._statBaseValue(actor, stat)
    // v1.0.0-alpha.11 (side-finding #1): see gambleStatIncrease comment.
    const naturalMax = (actor.system?.elysium?.statNaturalMax?.[stat] ||
                        ELYSIUM.STAT_NATURAL_MAX_BASE)

    if (current >= naturalMax) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.AtMax', {
        stat, max: naturalMax,
      }))
      return { success: false, atMax: true }
    }

    const expDice = actor.system?.elysium?.expDice?.available || 0
    if (expDice < current) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.NotEnoughDice', {
        required: current, available: expDice,
      }))
      return { success: false, noDice: true }
    }

    await actor.update({
      [`system.elysium.expDice.available`]: expDice - current,
      [`system.stats.${stat}.exp`]: (actor.system.stats[stat]?.exp || 0) + 1,
    })

    const guBody = `<p>${stat.toUpperCase()} ${current} → ${current + 1}</p>
      <p>${game.i18n.format('Elysium.Stats.SpentDice', { count: current })}</p>`
    const guHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      {
        variant: 'success',
        title: `${actor.name} — ${game.i18n.localize('Elysium.Stats.GuaranteedAdvance')}`,
        icon: 'arrow-up',
        body: guBody,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: guHtml,
    })

    return { success: true, dice: current, increased: 1 }
  }

  /**
   * Award EXP dice to an actor (GM action)
   */
  static async awardExpDice (actor, count = 1) {
    const current = actor.system?.elysium?.expDice?.available || 0
    await actor.update({
      'system.elysium.expDice.available': current + count,
    })
    ui.notifications.info(game.i18n.format('Elysium.Exp.Awarded', {
      actor: actor.name, count,
    }))
  }

  // === HELPERS ======================================================

  static _statBaseValue (actor, stat) {
    const s = actor.system.stats?.[stat]
    if (!s) return 0
    return (s.base || 0) + (s.redist || 0) + (s.culture || 0) +
           (s.exp || 0) + (s.age || 0) + (s.effects || 0)
  }
}
