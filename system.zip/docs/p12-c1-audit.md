# P12 cluster 1 prep audit — mechanical CSS + attribute cleanup

**Status**: PENDING
**Target alpha**: alpha.51
**Scope**: P12's first sub-cluster per the P12 prep audit Option B sequencing. Covers items 1.2 (`data-handle-change` retirement), 1.3 (`darkred` retoken), 1.4 (island cleanup), 1.5 (brace-badge retirement), 1.7 (legacy CSS orphaning sweep), per the P12 prep audit §5 recommendation.
**Inheritance from**: P12 prep audit (D1 Option B sub-cluster split, D2 `darkred` target locked, D4 brace-badge target locked, D6 orphan-scope locked); cluster-3 audit (hitloc-tag retoken methodology — directly applicable to brace-badge); cluster-6 audit (1-rgba + 36-px findings — partial scope, see Finding F1 below).

**Scope expansion warning from baseline measurement**: cluster-6's island-only rgba sweep found 1 rgba leak. The corresponding full-tree sweep at alpha.50 baseline finds **130 rgba/rgb literals in `styles/elysium.css`** alone. This audit confronts that gap. See §3 F1 for the decision.

---

## 1. Items inherited from P12 prep audit

For each item, this section captures the live state at alpha.50 baseline (re-measured, not relied on from prior audits) and itemises the exact work.

### 1.A — `data-handle-change` attribute retirement

**Live measurement at alpha.50**: 38 occurrences across 14 templates. Zero JS consumers in `module/`. Per-file distribution:

| Count | File |
|---|---|
| 8 | `templates/item/weapon.detail.hbs` |
| 7 | `templates/item/skill.detail.hbs` |
| 3 | `templates/item/hit-location.detail.hbs` |
| 3 | `templates/item/armor.detail.hbs` |
| 3 | `templates/dialog/parts/dialog-row.hbs` |
| 2 | `templates/item/skillcat.detail.hbs` |
| 2 | `templates/item/gear.detail.hbs` |
| 2 | `templates/item/divine.detail.hbs` |
| 2 | `templates/item/career.wealth.hbs` |
| 2 | `templates/actor/npcV2.main.hbs` |
| 1 | `templates/item/mysticism.detail.hbs` |
| 1 | `templates/item/mutation.detail.hbs` |
| 1 | `templates/item/ability.detail.hbs` |
| 1 | `templates/dialog/difficulty.hbs` |
| **38** | **Total across 14 files** |

**Attribute syntax verified**: always a standalone valueless boolean attribute on `<select>` or `<input>` elements, always followed by `name=`. No values, no event handlers, no conditional rendering. Pattern: `data-handle-change name="..."`.

**Doc-comment in `dialog/parts/dialog-row.hbs:7-9` flags this**: "data-handle-change attribute on every field (vestigial decorator with zero JS consumers; preserved verbatim per c5-4 — flagged for P12 sweep)". Cluster-5 explicitly anticipated this work.

**Risk**: zero. V14 ApplicationV2 form-data extraction doesn't read this attribute.

**Work shape**: 38 string replacements. Each replacement: `data-handle-change name=` → `name=` (removes the attribute + its trailing space). Mechanical sed-equivalent across 14 files.

### 1.B — `darkred` retoken

**Live measurement at alpha.50**: 3 sites total.

1. `css/legacy.css:1384` — `.elysium .darkred { color: var(--ely-legacy-colour-secondary); }` — rule body
2. `templates/elysiumid/elysiumid-editor.hbs:52` — class consumer
3. `templates/elysiumid/elysiumid-editor.hbs:74` — class consumer

**Token target locked** (P12 prep audit D2): `--ely-accent-danger`. Defined in `styles/elysium-tokens.css:202` as `#c44040`.

**Class name decision** (P12 prep audit D2): keep `.darkred` class name in templates and rule selector; retoken only the rule body. Reasoning recap: renaming the class is template-surface churn for no functional benefit; the class IS the design intent (a danger-tinted icon), the class name is historical.

**Migration target rule body**:

```css
/* Pre-v1.0.0 BRP-era class. Despite the literal-color name, the design
 * intent is "danger-tinted icon" — semantic, not literal. Retokenned to
 * the v1.0.0 danger accent at P12-c1 (alpha.51) per P12 prep audit D2. */
.elysium .darkred {
  color: var(--ely-accent-danger);
}
```

**Risk**: low. Two warning-triangle icons in the BRP-ID editor will shift from `rgb(68,7,4)` (deep red, almost maroon) to `#c44040` (saturated medium red). The new color is brighter and more saturated — visually a stronger warning signal, which is appropriate for warning-triangle icon use.

**Live-verify needed**: post-install spot-check that the BRP-ID editor's warning triangles look correct (sufficiently red, contrasts against background).

### 1.C — Island cleanup (cluster-6 deferred F1 + F2)

#### 1.C.1 — Island rgba (cluster-6 F1)

**Live measurement at alpha.50**: 1 rgba in island-scoped rules.

| File | Line | Rule | Literal |
|---|---|---|---|
| `styles/elysium.css` | 2841 | `.elysium-tier-choice-dialog .tcd-tier-selected .tcd-tier-cost` | `background: rgba(255, 255, 255, 0.18);` |

**Migration target**: subtle translucent-white overlay on a SELECTED tier card's cost pill. The token vocabulary doesn't have a native "subtle overlay" token; options:
1. Use `color-mix(in srgb, white 18%, transparent)` — modern CSS, expresses intent directly
2. Define a new token `--ely-overlay-subtle: rgba(255, 255, 255, 0.18)` in `elysium-tokens.css`, reference here
3. Use existing `var(--ely-surface-raised)` if its actual value approximates this overlay

**Recommendation**: option 2 (new token). The pattern (translucent-white wash for "selected" state) is reusable and deserves a named semantic. Add to `elysium-tokens.css` in the existing Surface section.

#### 1.C.2 — Island px literals (cluster-6 F2)

**Live measurement at alpha.50**: 36 px values across 4 islands. Per-line breakdown:

**cast-card (1)**:
- L1328: `border: 1px solid var(--ely-border-decorative);` → keep (1px border is standard)

**manipulation (21)**: see full per-line table in §6 audit appendix. Categorised:
- 1px borders (8 occurrences) → retoken to `var(--ely-border-width-1)` (defined as `1px`)
- 2px gaps + spacing (4 occurrences) → retoken to `var(--ely-space-0)` or `var(--ely-border-width-2)`
- 3px borders + margins (4 occurrences) → retoken to `var(--ely-border-width-3)`
- 10px font-size (2 occurrences) → retoken to `var(--ely-font-size--1)` if defined, else keep
- 22px icon dimensions (2 occurrences) → retoken to `var(--ely-size-icon-1)` if defined, else keep
- 9px radius (1 occurrence) → `var(--ely-radius-3)` (defined as `8px`) — slight visual delta of 1px
- 7px padding (1 in `padding: 1px 7px`) → keep (7px is not in token scale)
- 24px min-width (1 occurrence) → keep (component-layout constant)

**csb (9)**: see appendix.
**tcd (5)**: see appendix.

**Approach**: per-literal review using existing tokens (`--ely-border-width-*`, `--ely-radius-*`, `--ely-space-*`). Where no token matches within ~1px, keep the literal but add a code-comment justifying it as a layout constant. Where existing tokens exist but produce a visual delta (e.g. 9px → 8px), live-verify the delta is acceptable.

**Risk**: low-medium. Most retokens are 1px → 1px (zero visual change). The 9px → 8px radius and any token-rounding cases need live-verify.

### 1.D — Brace-badge inline-style retirement (cluster-7 F3)

**Live state at alpha.50**: confirmed unchanged from cluster-7 audit measurement.

`module/elysium/hooks/render-combat-tracker.mjs:21-23`:
```js
badge.className = 'fas fa-shield elysium-brace-badge'
badge.dataset.tooltip = `${c.name} is bracing — knockback excess halved.`
badge.style.cssText = 'margin-left:6px;color:#0066aa;'
```

**Migration**:

1. Add CSS rule. File question (§3 Q3): the brace-badge is a combat-tracker DOM element — the cluster-7 audit recommended `styles/elysium-tracker.css` IF the broader tracker restyle ships. With the broader restyle deferred (D5), there's no `elysium-tracker.css` file. Options:
   - Add the rule to an existing file (e.g. `styles/elysium-chat.css` despite the surface mismatch)
   - Create `styles/elysium-tracker.css` as a small foundation file, add to `system.json` styles array, populate with only the brace-badge rule
   - Add to `styles/elysium.css` (where most v1.0.0 island rules live)

   **Recommendation**: option 2 (new `styles/elysium-tracker.css`). The file is small (~15 LOC initial with the comment block) but reserves the surface for a future v1.1.0 tracker restyle without requiring a file-creation ship. Add the file to `system.json` `styles` array.

2. Token target (P12 prep audit D4): `--ely-accent-info` (`#5a7aa0`). The legacy `#0066aa` is a saturated medium blue conveying "defensive bracing" status; `--ely-accent-info` is the v1.0.0 semantic match. Live-verify contrast against the tracker background at ship time; fallback `--ely-text-link` (`#d4a040`, the bonus-gold).

3. Margin retoken: `margin-left: 6px` → `margin-left: var(--ely-space-1)` (matches existing chat-card chip spacing pattern from cluster-3).

4. JS change: delete line 23 (`badge.style.cssText = ...`). Keep the class and tooltip set.

**Lock list addition** (P12 prep audit §7): `.elysium-brace-badge` becomes audit-locked after this ship (JS-imperative — used as double-injection guard at line 18).

### 1.E — Legacy CSS orphaning sweep

**Live measurement at alpha.50**: 65 truly-orphan classes out of 184 distinct classes in `css/legacy.css` `.elysium`-prefixed selectors. Verified 23/24 spot-checks return zero consumers anywhere.

**Scope locked** (P12 prep audit D6): retire ONLY the 65 true orphans. The 40 low-use rules deserve per-rule review (some are intentional shared utilities like `italics`, `boxed`, `fade`); defer to a separate pass or v1.1.0.

**Work shape**: per-orphan,
1. Re-grep the class name across templates + module/ + non-legacy CSS to confirm zero consumers (catches false-positives like the `itemIcon` case)
2. Locate the rule block in `css/legacy.css`
3. Delete the rule block (1-15 LOC depending on declaration count)
4. If the rule is part of a multi-selector group (e.g. `.elysium .a, .elysium .b { ... }`), remove just the orphan selector, keep the rest

**Estimated diff**: legacy.css shrinks from 1626 LOC → ~1540-1570 LOC (-55 to -90 LOC), brace count drops 220 → ~155-180.

**Risk**: low if re-grep verification holds. Each retirement should re-verify zero consumers immediately before deletion, in case the multi-source consumer scan missed something subtle (inline-HTML strings, dynamic class construction).

---

## 2. New finding surfaced by alpha.50 baseline measurement

### F1 — `styles/elysium.css` has 130 rgba/rgb color literals (NOT 1)

**Critical scope question.** The cluster-6 audit measured rgba count "1, in island scope." That measurement was accurate for its scope but **misleading at the system level**. Full-tree measurement at alpha.50:

| File | rgba/rgb literal count |
|---|---|
| `styles/elysium.css` | **130** |
| `css/legacy.css` | 51 (legacy file, retires whole in P12+) |
| `styles/elysium-tokens.css` | 5 (token definitions — expected) |
| `styles/elysium-sheets.css` | 3 |
| `css/npc.css` | 2 |
| `styles/elysium-chat.css` | 0 |
| `styles/elysium-base.css` | 0 |
| `styles/elysium-components.css` | 0 |
| `styles/elysium-reset.css` | 0 |

The P11 work was clean (zero rgba in any new v1.0.0 file). The P7 foundation was clean. But `styles/elysium.css` — the main v1.0.0 stylesheet — carries 130 hardcoded color literals.

Spot-sample of the leaks (first 10 of 130):

| Line | Rule (truncated) | Literal |
|---|---|---|
| 67 | `*` (some general rule) | `rgba(212, 175, 55, 0.03)` |
| 114 | (some bonus-themed rule) | `rgba(0, 0, 0, 0.04)` |
| 119 | (some danger-themed rule) | `rgba(196, 68, 68, 0.05)` |
| 130 | (some warning-themed rule) | `rgba(255, 136, 0, 0.05)` |
| 135 | (some info-themed rule) | `rgba(102, 194, 255, 0.05)` |
| 192 | (some border rule) | `rgba(0, 0, 0, 0.2)` |
| 270 | (some background rule) | `rgba(0, 0, 0, 0.04)` |
| 346 | (some background rule) | `rgba(0, 0, 0, 0.1)` |
| 354 | (some background rule) | `rgba(0, 0, 0, 0.25)` |
| 375 | (some border rule) | `rgba(0, 0, 0, 0.2)` |

The literals are mostly:
- Translucent-black washes (`rgba(0, 0, 0, X)`) for subtle backgrounds, borders, shadows — these are semantically "overlay-subtle / overlay-medium / overlay-strong" patterns that lack tokens
- Translucent chromatic washes (gold/red/orange/blue) at very low opacity (0.03-0.1) for accent-tinted backgrounds — these correspond to the chromatic accent families but at sub-token saturation
- A handful of opaque-color leaks (1px borders, accent strokes) that should retoken directly

**Why the cluster-6 audit missed them**: cluster-6 scoped to 4 island marker selectors (`.elysium-cast-card`, `.elysium-manip-dialog`, `.elysium-tier-choice-dialog`, `.elysium-custom-spell-builder`). The 130 leaks are in non-island v1.0.0 rules — sheet rules, header rules, tab rules, etc. — that don't carry island markers but ARE v1.0.0.

**Implication**: P12-c1's island cleanup as scoped in the prep audit (1 rgba + 36 px) addresses ~1% of the actual leakage in v1.0.0 CSS. The honest scope is much larger.

**Three response options:**

**Option α — c1 stays as-prep-audit-scoped (1 rgba + 36 px)**
- Ship c1 with the original island-only scope
- Add the 129 other rgba leaks as a new P12-c4 item (between c1 and c2, or after c3)
- Pros: c1 ships fast and clean, the audit-then-stop discipline catches the scope expansion cleanly
- Cons: leaves the user with an inaccurate understanding of remaining work for P12

**Option β — c1 absorbs the full rgba sweep**
- Add F1 (130 rgba) to c1's scope alongside the original items
- c1 becomes a larger ship (~150-200 retokens vs the original ~40)
- Pros: closes the rgba retoken in one pass
- Cons: c1's diff balloons; smoke matrix needs to cover much more of the v1.0.0 surface; risks visual regressions if any retoken target is wrong

**Option γ — c1 absorbs only the OPAQUE color leaks, defer rgba-overlay retokens**
- Sub-categorise the 130: the obvious opaque-color leaks (e.g. `rgba(0,0,0,0.2)` border colors that should be `var(--ely-border-subtle)`) retoken in c1; the very-low-opacity chromatic-wash patterns (`rgba(196,68,68,0.05)` etc.) defer to v1.1.0 or a later cluster because they need a new token-family (`--ely-overlay-danger-faint` etc.)
- Pros: scope expansion contained to the unambiguous retokens
- Cons: requires per-literal sub-classification before the ship; another step of analysis

**Recommendation**: **Option α**. Reasoning:
- Audit-then-stop discipline values predictable scope per ship
- The 130 leaks need their own scoping audit (which would discover that ~40 of them are genuine overlay-token gaps that need new token-family additions, not just retokens)
- c1's prep-audit-scoped work is mechanical and shippable in one cycle
- Honesty: the discovery moves the P12 phase from 3 clusters to ≥4 clusters. The next P12 prep-audit-style decision belongs at the phase level, not folded into a sub-cluster.

**Decision routing**: this is one of the audit's blocking open questions (Q1 in §4).

---

## 3. Files affected (summary)

If recommendation Option α is locked, c1's diff surface:

| File | Change |
|---|---|
| 14 templates (per 1.A) | 38 `data-handle-change` attribute removals |
| `css/legacy.css` | `.darkred` rule body retoken; ~65 orphan rule deletions |
| 2 templates in `elysiumid/` | (none — class name preserved per D2) |
| `styles/elysium-tokens.css` | +1 new token (`--ely-overlay-subtle` or equivalent if option 2 for the TCD rgba is chosen) |
| `styles/elysium.css` | line 2841 rgba retoken; ~30 px literal retokens (per 1.C.2 sub-categorisation, ~6 stay literal as layout constants) |
| `module/elysium/hooks/render-combat-tracker.mjs` | 1 line deletion (the inline-style line) |
| **NEW** `styles/elysium-tracker.css` | +15 LOC foundation file with brace-badge rule |
| `system.json` | +1 entry in `styles` array (the new tracker.css); version bump alpha.50 → alpha.51 |
| `CHANGELOG.md` | new entry |
| `ROADMAP-v1.0.0.md` | new execution log entry + P12 row update |

**Estimated net LOC**: -90 to -130 (legacy.css orphan retirements dominate; new tracker.css and CHANGELOG additions are smaller).

---

## 4. Open questions

### Q1 (blocking) — F1 scope response

Per §2 F1 above, the cluster-6 island scope addressed ~1% of the v1.0.0 rgba leakage. Three response options laid out in F1. **Recommended: Option α — c1 stays as-scoped, F1 becomes its own scoping audit (a likely future P12-c4)**.

Override syntax:
- `proceed with α` → recommended; c1 ships with original island-only rgba/px scope
- `proceed with β` → c1 absorbs all 130 rgba leaks (large ship)
- `proceed with γ` → c1 absorbs only the unambiguous opaque-color leaks, classification first

### Q2 (blocking) — TCD rgba retoken target

Per §1.C.1, three options for migrating `rgba(255, 255, 255, 0.18)`:
1. `color-mix(in srgb, white 18%, transparent)` (modern CSS, no new token)
2. New token `--ely-overlay-subtle: rgba(255, 255, 255, 0.18)` (named semantic)
3. Existing `var(--ely-surface-raised)` (if value approximates)

**Recommendation**: option 2. The pattern (translucent-white wash for selected-state) is named-semantic-worthy.

### Q3 (blocking) — Brace-badge CSS file location

Per §1.D, three options:
1. Add the brace-badge rule to an existing file (`styles/elysium-chat.css` — wrong surface)
2. Create new `styles/elysium-tracker.css` (small foundation file, reserves surface)
3. Add to `styles/elysium.css` (where most v1.0.0 island rules live)

**Recommendation**: option 2 (new tracker.css). Reserves surface for v1.1.0 tracker restyle without requiring another file-creation ship.

### Q4 (non-blocking) — Manipulation island 9px radius

Per §1.C.2, `border-radius: 9px` at L1857 retokens to `var(--ely-radius-3)` which is `8px` — a 1px visual delta. Live-verify acceptable, or keep 9px as literal?

**Recommendation**: retoken to `var(--ely-radius-3)` (1px is below visual-perception threshold for radius), live-verify post-install. If the delta is objectionable, revert to literal 9px in a follow-up.

### Q5 (non-blocking) — Per-orphan re-grep automation

Per §1.E, each of 65 orphans should be re-grepped immediately before deletion to catch any consumer source the bulk-analysis missed. Automate via shell loop or do per-rule manually?

**Recommendation**: automate via shell loop. Script: for each class in the orphan list, grep templates + module + non-legacy CSS, exit non-zero if any match. Run before each batch of deletions.

### Q6 (non-blocking) — Pre-flight sweep adjustments for c1

The standard sweep (JS parse, JSON, CSS braces, Handlebars, i18n, tokens, lang parity) covers c1 well. Additions:
- **Class-consumer re-verification**: after retiring orphans, re-grep `templates/` + `module/` for any of the retired class names; should return zero
- **Visual diff spot-check**: brace-badge before/after screenshot; warning-triangle before/after screenshot
- **Token consumer verification**: confirm any new tokens (`--ely-overlay-subtle` if Q2 option 2) are added to elysium-tokens.css before c1 ship

### Q7 (non-blocking) — Smoke fixtures

c1 doesn't introduce new chat-card or dialog templates, but it modifies existing dialog-row partial. Standard smoke against the c5 fixtures should remain green. Add:
- BRP-ID editor render fixture (warning-triangle visual verify)
- Combat-tracker render with at-least-one-bracing combatant (brace-badge visual verify)
- TCD render with at-least-one-tier-selected (selected-cost rgba visual verify)

---

## 5. Recommendation

Lock the c1 scope as the P12 prep audit defined it:

- **1.A** `data-handle-change` retire (38 occurrences, 14 templates)
- **1.B** `darkred` retoken to `--ely-accent-danger`, class name kept
- **1.C** Island cleanup: 1 rgba (TCD, new token per Q2 option 2) + 36 px retokens (per sub-categorisation, ~6 stay literal)
- **1.D** Brace-badge: new `styles/elysium-tracker.css` (Q3 option 2), `--ely-accent-info` color, `var(--ely-space-1)` margin, JS inline-style line deleted
- **1.E** Legacy CSS orphan sweep: 65 true orphans deleted, low-use deferred

**F1 disposition (Q1)**: stays out of c1 scope per recommendation α. The 130 elysium.css rgba leaks become a P12-c4 scoping question once c1-c3 ship. The phase audit's 3-cluster plan grows to 4-cluster.

**Per-criterion verification at c1 ship time**:
- [ ] `data-handle-change` count across `templates/` = 0
- [ ] `.darkred` rule body uses `--ely-accent-danger`
- [ ] Line 2841 rgba retokenned; new `--ely-overlay-subtle` defined in tokens
- [ ] Island px count reduced from 36 to ~6 layout-constant exceptions
- [ ] `render-combat-tracker.mjs` inline-style line removed; brace-badge rule in tracker.css
- [ ] `system.json` styles array includes `styles/elysium-tracker.css`
- [ ] `css/legacy.css` LOC reduced by ≥55 from orphan sweep
- [ ] Pre-flight sweep green
- [ ] Class-consumer re-verification clean (no retired class still referenced anywhere)

---

## 6. Audit appendix — per-line island px breakdown

Full per-line table for the 36 island px literals (1.C.2):

### Cast-card (1)
| Line | Declaration | Retoken target |
|---|---|---|
| 1328 | `border: 1px solid var(--ely-border-decorative);` | `var(--ely-border-width-1)` (or keep — 1px border is standard) |

### Manipulation (21)
| Line | Declaration | Retoken target |
|---|---|---|
| 1679 | `gap: 2px;` | `var(--ely-border-width-2)` or keep |
| 1682 | `border-left: 3px solid var(--ely-border-decorative);` | `var(--ely-border-width-3)` |
| 1708 | `border-bottom: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 1715 | `border-bottom: 1px dashed var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 1727 | `width: 22px;` | keep (icon dimension constant) |
| 1728 | `height: 22px;` | keep (icon dimension constant) |
| 1730 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 1744 | `transform: translateY(1px);` | keep (pixel-precise visual nudge) |
| 1747 | `font-size: 10px;` | check for `--ely-font-size--1` token; else keep |
| 1752 | `min-width: 24px;` | keep (layout constant) |
| 1764 | `border-left: 3px solid var(--ely-accent-info);` | `var(--ely-border-width-3)` |
| 1787 | `border-top: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 1793 | `gap: 2px;` | `var(--ely-border-width-2)` or keep |
| 1818 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 1854 | `padding: 1px 7px;` (×2 px literals) | keep (component-specific padding) |
| 1856 | `border: 1px solid var(--ely-accent-info);` | `var(--ely-border-width-1)` |
| 1857 | `border-radius: 9px;` | `var(--ely-radius-3)` = 8px (Q4) |
| 1862 | `font-size: 10px;` | check for `--ely-font-size--1` token; else keep |
| 1863 | `margin-right: 3px;` | `var(--ely-border-width-3)` or keep |
| 1868 | `margin-top: 2px;` | `var(--ely-border-width-2)` or keep |

### CSB (9)
| Line | Declaration | Retoken target |
|---|---|---|
| 2561 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2593 | `flex: 0 0 100px;` | keep (layout constant) |
| 2602 | `padding: 3px var(--ely-space-1);` | mixed; `--ely-border-width-3` for first or keep |
| 2603 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2610 | `flex: 0 0 80px;` | keep (layout constant) |
| 2615 | `grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));` | keep (layout constant) |
| 2621 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2652 | `border-top: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2658 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |

### TCD (5)
| Line | Declaration | Retoken target |
|---|---|---|
| 2733 | `border-bottom: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2776 | `border: 1px solid var(--ely-border-subtle) !important;` | `var(--ely-border-width-1)` |
| 2834 | `padding: 2px var(--ely-space-2);` | mixed; first value `--ely-border-width-2` or keep |
| 2860 | `border-top: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |
| 2866 | `border: 1px solid var(--ely-border-subtle);` | `var(--ely-border-width-1)` |

**Summary**: of 36 px literals,
- ~18 retoken to `--ely-border-width-1` (1px border standardisation)
- ~5 retoken to `--ely-border-width-2` / `-3` (small gap/border standardisation)
- ~1 retoken to `--ely-radius-3` (8px radius, Q4)
- ~12 STAY as literals (icon dimensions, layout constants, sub-pixel nudges, component-specific paddings)

**Net retoken**: ~24 of 36 px literals retoken; ~12 documented as intentional literals via code comment.

---

## 7. Cross-references

- `docs/p12-prep-audit.md`: D1 sub-cluster split, D2 darkred target, D4 brace-badge target, D6 orphan scope
- `docs/p11-cluster3-audit.md`: hitloc-tag retoken — direct methodology template for brace-badge
- `docs/p11-cluster6-audit.md`: F1 island rgba + F2 island px — partial scope, see §2 F1 of this audit for full-tree expansion
- `docs/p11-cluster7-audit.md`: F3 brace-badge anti-pattern recommendation Option B
- `styles/elysium-tokens.css`: border-width, radius, accent-danger, accent-info token definitions
- `module/elysium/hooks/render-combat-tracker.mjs:21-23`: brace-badge inline-style site

---

## 8. Pre-decision checklist

Before responding `proceed with recommended`:

- [ ] Accept §2 F1 finding: alpha.50 baseline has 130 rgba leaks in `styles/elysium.css`, NOT 1 — cluster-6 measured only the island subset
- [ ] Accept Q1 Option α recommendation: c1 stays as-prep-audit-scoped; F1 becomes its own P12-c4 (phase plan grows from 3 to 4 clusters)
- [ ] Accept Q2: new `--ely-overlay-subtle` token added for TCD rgba
- [ ] Accept Q3: new `styles/elysium-tracker.css` file created, added to `system.json` styles array
- [ ] Accept Q4: 9px → 8px retoken with live-verify
- [ ] Accept Q5: automate per-orphan re-grep via shell loop
- [ ] Accept Q6/Q7 sweep + smoke additions

If overriding F1 response, name option: `proceed with β` (absorb all rgba in c1) or `proceed with γ` (absorb only opaque rgba in c1).
