import { BRPPowerRuleSettings } from "./settings-powerRules.mjs";
import { BRPOptionalRuleSettings } from "./settings-optionalRules.mjs";
import { BRPDiceSettings } from "./settings-diceOptions.mjs";
import { BRPCombatRuleSettings } from "./settings-combatOptions.mjs";
import { BRPXPSettings } from "./settings-xpOptions.mjs";
import { BRPNPCSettings } from "./settings-NPCOptions.mjs";
import { BRPCharSettings } from "./settings-charOptions.mjs";
import { BRPGameModifiers } from "./settings-gameModifiers.mjs";
import { BRPDisplaySettings } from "./settings-displayOptions.mjs";
import { BRPElysiumidSettings } from './settings-elysiumidOptions.mjs';


export async function registerSettings() {

  //Game Settings Menu Buttons-----------------------------------------------
  //Power Menu Button
  game.settings.registerMenu('elysium', 'powerRules', {
    name: 'BRP.Settings.powerRulesHint',
    label: 'BRP.Settings.powerRules',
    icon: 'fas fa-cloud-bolt',
    type: BRPPowerRuleSettings,
    restricted: true
  })
  BRPPowerRuleSettings.registerSettings()

  //Optional Rules Menu Button
  game.settings.registerMenu('elysium', 'optionalRules', {
    name: 'BRP.Settings.optionalRulesHint',
    label: 'BRP.Settings.optionalRules',
    icon: 'fas fa-book',
    type: BRPOptionalRuleSettings,
    restricted: true
  })
  BRPOptionalRuleSettings.registerSettings()

  //Dice Options Menu Button
  game.settings.registerMenu('elysium', 'diceOptions', {
    name: 'BRP.Settings.diceOptionsHint',
    label: 'BRP.Settings.diceOptions',
    icon: 'fas fa-dice',
    type: BRPDiceSettings,
    restricted: true
  })
  BRPDiceSettings.registerSettings()

  //Combat Options Menu Button
  game.settings.registerMenu('elysium', 'combatOptions', {
    name: 'BRP.Settings.combatOptionsHint',
    label: 'BRP.Settings.combatOptions',
    icon: 'fas fa-swords',
    type: BRPCombatRuleSettings,
    restricted: true
  })
  BRPCombatRuleSettings.registerSettings()

  //XP Options Menu Button
  game.settings.registerMenu('elysium', 'xpOptions', {
    name: 'BRP.Settings.xpOptionsHint',
    label: 'BRP.Settings.xpOptions',
    icon: 'fas fa-file-certificate',
    type: BRPXPSettings,
    restricted: true
  })
  BRPXPSettings.registerSettings()

  //NPC Options Menu Button
  game.settings.registerMenu('elysium', 'npcOptions', {
    name: 'BRP.Settings.npcOptionsHint',
    label: 'BRP.Settings.npcOptions',
    icon: 'fas fa-hood-cloak',
    type: BRPNPCSettings,
    restricted: true
  })
  BRPNPCSettings.registerSettings()

  //Character Options Menu Button
  game.settings.registerMenu('elysium', 'charOptions', {
    name: 'BRP.Settings.charOptionsHint',
    label: 'BRP.Settings.charOptions',
    icon: 'fas fa-helmet-battle',
    type: BRPCharSettings,
    restricted: true
  })
  BRPCharSettings.registerSettings()

  //Game Modifiers Menu Button
  game.settings.registerMenu('elysium', 'gameMods', {
    name: 'BRP.Settings.gameModsHint',
    label: 'BRP.Settings.gameMods',
    icon: 'fas fa-abacus',
    type: BRPGameModifiers,
    restricted: true
  })
  BRPGameModifiers.registerSettings()

  //Display Settings Button
  game.settings.registerMenu('elysium', 'displayOptions', {
    name: 'BRP.Settings.displayOptionsHint',
    label: 'BRP.Settings.displayOptions',
    icon: 'fas fa-palette',
    type: BRPDisplaySettings,
    restricted: true
  })
  BRPDisplaySettings.registerSettings()

  //BRPID Settings Button
  game.settings.registerMenu('elysium', 'brpidOptions', {
    name: 'BRP.Settings.brpidOptionsHint',
    label: 'BRP.Settings.brpidOptions',
    icon: 'fas fa-fingerprint',
    type: BRPElysiumidSettings,
    restricted: true
  })
  BRPElysiumidSettings.registerSettings()


  //Individual Game Settings---------------------------------------------------
  game.settings.register('elysium', "switchShift", {
    name: "BRP.Settings.switchShift",
    hint: "BRP.Settings.switchShiftHint",
    scope: "client",
    config: true,
    type: Boolean,
    default: false
  });

  game.settings.register('elysium', "defaultTab", {
    name: "BRP.Settings.defaultTab",
    hint: "BRP.Settings.defaultTabHint",
    scope: "client",
    config: true,
    type: Boolean,
    default: false
  });

  //Invisible Game Settings----------------------------------------------------
  game.settings.register('elysium', "development", {
    name: "",
    hint: "",
    scope: "world",
    requiresReload: false,
    config: false,
    type: Boolean,
    default: false
  });

  game.settings.register('elysium', "beastiary", {
    name: "",
    hint: "",
    scope: "world",
    requiresReload: false,
    config: false,
    type: Boolean,
    default: false
  });

  game.settings.register('elysium', "gameVersion", {
    name: "",
    hint: "",
    scope: "world",
    requiresReload: false,
    config: false,
    type: String,
    default: "12.1.36"
  });

}

