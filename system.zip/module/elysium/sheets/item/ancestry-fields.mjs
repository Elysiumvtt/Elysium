// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { getSetting } from '../../settings/register-settings.mjs'

export function injectAncestryFields (html, item) {
    if (!getSetting('enableAncestrySystem', true)) return
    const target = html.querySelector('.tab.details') ||
                   html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return
    if (target.querySelector('.elysium-ancestry-fields')) return

    const a = item.system?.elysium?.ancestry || {}
    const currentSet = a.hitLocationSet || 'humanoid'
    const setLabels = ELYSIUM.HIT_LOCATION_SET_LABELS || {}
    const setOptions = Object.entries(setLabels).map(
      ([key, label]) =>
        `<option value="${key}"${key === currentSet ? ' selected' : ''}>${label}</option>`
    ).join('')

    const html_ = `
      <fieldset class="elysium-ancestry-fields">
        <legend>${game.i18n.localize('Elysium.Ancestry.Fields')}</legend>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.BaseMove')}</label>
          <input type="number" name="system.elysium.ancestry.baseMove"
                 value="${a.baseMove || 30}" min="0" max="120">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.FlyMove')}</label>
          <input type="number" name="system.elysium.ancestry.flyMove"
                 value="${a.flyMove || 0}" min="0" max="120">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.BuildPoints')}</label>
          <input type="number" name="system.elysium.ancestry.buildPoints"
                 value="${a.buildPoints || 0}" min="-50" max="50">
        </div>
        <div class="form-group">
          <label>${game.i18n.localize('Elysium.Ancestry.SkillPoints')}</label>
          <input type="number" name="system.elysium.ancestry.skillPoints"
                 value="${a.skillPoints || 0}" min="-50" max="50">
        </div>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Ancestry.HitLocationSetHint')}">${game.i18n.localize('Elysium.Ancestry.HitLocationSet')}</label>
          <select name="system.elysium.ancestry.hitLocationSet">${setOptions}</select>
        </div>
        <p class="hint">${game.i18n.localize('Elysium.Ancestry.AdvancedHint')}</p>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }
