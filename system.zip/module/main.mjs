/**
 * Elysium — system entry point.
 *
 * Foundry loads this module exactly once at world load. All hook
 * registrations live inside `init` (runs first, before any sheets render)
 * or `ready` (runs after the world is fully loaded). This keeps the
 * load-time side effects to a single import-chain pass; everything
 * mutable goes through proper hooks.
 *
 * Load order:
 *   1. Foundry fires `init` → Init() registers settings, document classes,
 *      CONFIG, and all render-time hooks via _registerLifecycleHooks().
 *   2. Foundry fires `ready` → _onReady() loads compendium-backed select
 *      lists, configures the initiative formula, and runs world-version
 *      migration if needed.
 *
 * The Elysium subsystem (module/elysium/elysium.mjs) registers its own
 * `init` hook independently. Both run during Foundry's init phase.
 */

import { ElysiumCharacterSheet } from './actor/sheets/character.mjs'
import { ElysiumHooks } from './hooks/index.mjs'
import { ElysiumSystemSocket } from './apps/socket.mjs'
import { ElysiumUtilities } from './apps/utilities.mjs'
import { ElysiumMenu } from './setup/menu.mjs'
import Init from './hooks/init.mjs'
import renderSceneControls from './hooks/render-scene-controls.mjs'
import RenderRegionConfig from './hooks/render-region-config.mjs'
import RenderJournalEntryPageTextSheet from './hooks/render-journal-entry-page-text-sheet.mjs'
import RenderJournalEntrySheet from './hooks/render-journal-entry-sheet.mjs'
import createToken from './hooks/create-token.mjs'
import { ElysiumSelectLists } from './apps/select-lists.mjs'
import RenderRollTableSheet from './hooks/render-roll-table-sheet.mjs'

// === Lifecycle ====================================================

Hooks.once('init', () => {
  Init()
  _registerLifecycleHooks()
})

Hooks.once('ready', _onReady)

// === Implementation ================================================

function _registerLifecycleHooks () {
  // Render-time hooks: sheet decorations, journal formatting, scene controls.
  // Registered here (not at module top-level) so that anything depending on
  // game.elysium / CONFIG.Elysium is guaranteed initialised first.
  Hooks.on('getSceneControlButtons', ElysiumMenu.getButtons)
  Hooks.on('renderSceneControls',    renderSceneControls)
  Hooks.on('renderActorSheet',       ElysiumCharacterSheet.renderSheet)
  Hooks.on('renderRegionConfig',     RenderRegionConfig)
  Hooks.on('createToken',            createToken)
  Hooks.on('renderJournalEntryPageTextSheet', RenderJournalEntryPageTextSheet)
  Hooks.on('renderJournalEntrySheet',         RenderJournalEntrySheet)
  Hooks.on('renderRollTableSheet',            RenderRollTableSheet)

  // Per-subsystem listen() chain (dialog/note/chat formatting).
  ElysiumHooks.listen()
}

async function _onReady () {
  // 1. Open the socket channel for system-internal messaging.
  game.socket.on('system.elysium', data => ElysiumSystemSocket.callSocket(data))

  // 2. Preload compendium-backed select-list categories so item sheets
  //    don't block on first open.
  game.elysium.categories = ElysiumSelectLists.preLoadCategoriesCategories()

  // 3. Configure the initiative formula from settings. The default is
  //    `@stats.dex.total + initMod`; users can override via settings menu.
  _configureInitiative()

  // 4. Hotbar drop: route to ElysiumUtilities.createMacro. Registered here
  //    (not in init) because game.user must exist.
  Hooks.on('hotbarDrop', (bar, data, slot) => ElysiumUtilities.createMacro(bar, data, slot))

  // v0.21.0: World-version migration removed. The migration in
  // module/setup/update.mjs was a BRP-classic legacy path that migrated
  // from BRP 13.1.53 to V2 Application format. Per the v0.20.0 design
  // decision ("no migration, new world required"), this path is dead.
  // The `gameVersion` setting was also removed along with it.
}

function _configureInitiative () {
  const initForm = game.settings.get('elysium', 'initStat')
  let   initMod  = game.settings.get('elysium', 'initMod')

  // Normalize the modifier so it's safe to string-concat.
  if (!['+', '-', '*', '/'].includes(initMod.charAt(0))) {
    initMod = '+' + initMod
  }

  // initForm 'fixed' means no stat term — just the modifier on its own.
  const statTerm = (initForm === 'fixed') ? '' : `@stats.${initForm}.total`
  let formula = statTerm + initMod

  if (!Roll.validate(formula)) {
    ui.notifications.error(game.i18n.format('Elysium.initError', { formula }))
    formula = '@stats.dex.total+0'
  }

  CONFIG.Combat.initiative = { formula, decimals: 0 }
}
