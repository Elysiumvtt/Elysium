import { ElysiumCharacterSheet } from '../actor/sheets/character.mjs'
import { ElysiumNPCSheetV2 } from '../actor/sheets/npcV2.mjs'
import { ElysiumGearSheet } from '../item/sheets/gear.mjs'
import { ElysiumSkillSheet } from '../item/sheets/skill.mjs'
import { ElysiumHitLocSheet } from '../item/sheets/hit-location.mjs'
import { ElysiumPersonalitySheet } from '../item/sheets/personality.mjs'
import { ElysiumCareerSheet } from '../item/sheets/career.mjs'
import { ElysiumArcaneSheet } from '../item/sheets/arcane.mjs'
import { ElysiumDivineSheet } from '../item/sheets/divine.mjs'
import { ElysiumMysticismSheet } from '../item/sheets/mysticism.mjs'
import { ElysiumMutationSheet } from '../item/sheets/mutation.mjs'
import { ElysiumSorcerySheet } from '../item/sheets/sorcery.mjs'
import { ElysiumSuperSheet } from '../item/sheets/super.mjs'
import { ElysiumFailingSheet } from '../item/sheets/failing.mjs'
import { ElysiumPowerModSheet } from '../item/sheets/powerMod.mjs'
import { ElysiumArmorSheet } from '../item/sheets/armor.mjs'
import { ElysiumWeaponSheet } from '../item/sheets/weapon.mjs'
import { ElysiumWoundSheet } from '../item/sheets/wound.mjs'
import { ElysiumAllegianceSheet } from '../item/sheets/allegiance.mjs'
import { ElysiumPassionSheet } from '../item/sheets/passion.mjs'
import { ElysiumAbilitySheet } from '../item/sheets/ability.mjs'
import { ElysiumPersTraitSheet } from '../item/sheets/persTrait.mjs'
import { ElysiumReputationSheet } from '../item/sheets/reputation.mjs'
import { ElysiumSkillCategory } from '../item/sheets/skillcat.mjs'
import { ElysiumCultureSheet } from '../item/sheets/culture.mjs'
export function registerSheets() {

  const { sheets } = foundry.applications;
  const { collections } = foundry.documents;

  foundry.documents.collections.Actors.unregisterSheet("core", foundry.appv1.sheets.ActorSheet);
  foundry.documents.collections.Actors.registerSheet('elysium', ElysiumCharacterSheet, {
    types: ['character'],
    makeDefault: true
  })

  foundry.documents.collections.Actors.registerSheet('elysium', ElysiumNPCSheetV2, {
    types: ['npc'],
    makeDefault: true
  })

  foundry.documents.collections.Items.unregisterSheet('core', foundry.appv1.sheets.ItemSheet)
  collections.Items.unregisterSheet("core", sheets.ItemSheetV2);
  foundry.documents.collections.Items.registerSheet('elysium', ElysiumGearSheet, {
    types: ['gear'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumSkillSheet, {
    types: ['skill'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumHitLocSheet, {
    types: ['hit-location'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumPersonalitySheet, {
    types: ['personality'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumCareerSheet, {
    types: ['career'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumArcaneSheet, {
    types: ['arcane'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumDivineSheet, {
    types: ['divine'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumMutationSheet, {
    types: ['mutation'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumMysticismSheet, {
    types: ['mysticism'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumSorcerySheet, {
    types: ['sorcery'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumSuperSheet, {
    types: ['super'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumFailingSheet, {
    types: ['failing'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumPowerModSheet, {
    types: ['powerMod'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumArmorSheet, {
    types: ['armor'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumWeaponSheet, {
    types: ['weapon'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumWoundSheet, {
    types: ['wound'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumAllegianceSheet, {
    types: ['allegiance'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumPassionSheet, {
    types: ['passion'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumAbilitySheet, {
    types: ['ability'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumPersTraitSheet, {
    types: ['persTrait'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumReputationSheet, {
    types: ['reputation'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumSkillCategory, {
    types: ['skillcat'],
    makeDefault: true
  })

  foundry.documents.collections.Items.registerSheet('elysium', ElysiumCultureSheet, {
    types: ['culture'],
    makeDefault: true
  })

  // v0.21.0: ElysiumRollTableConfig sheet registration removed — the class
  // file (module/sheets/legacy-roll-table-config.mjs) was deleted alongside
  // this commented-out block. The class extended the core RollTableSheet
  // only to override img to icons/svg/d20.svg and add a ElysiumID header
  // button. Foundry's default RollTableSheet is used directly now;
  // ElysiumID buttons live on the entries we own (items/actors), not on the
  // GM-only RollTable config.
}
