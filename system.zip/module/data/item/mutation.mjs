/**
 * MutationDataModel — schema for items of type 'mutation'.
 *
 * Per P6.2 spec. Stored-schema-only. 69 compendium items in mutations.db.
 *
 * Compendium content populates only `description` + `elysium.{visionType,
 * visionRange, abilityTier}`. The template-only fields {impact, minorOnly,
 * minor} default-initialize from schema.
 *
 * `impact` is left as a free StringField (no choices lock) — template
 * default is 'adv' but compendium has no examples; future content may
 * extend the set. Same risk profile as the design's `viewTab` decision.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class MutationDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      impact:    new fields.StringField({ initial: 'adv' }),
      minorOnly: new fields.BooleanField({ initial: false }),
      minor:     new fields.BooleanField({ initial: true }),
      elysium: new fields.SchemaField({
        visionType:   new fields.StringField({ initial: '' }),
        visionRange:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        abilityTier:  new fields.NumberField({ integer: true, initial: 1, min: 1 }),
      }),
    }
  }
}
