/**
 * v0.11.0 — Characteristic Improvement subsystem
 *
 * Players mark stats for improvement via the headline-panel checkboxes
 * (click = mark, Shift+Click = roll immediately). Improvement rolls are
 * 3d6-over-current-stat; on success, the stat increases by 1 and the
 * fail-counter resets. On failure, the fail-counter increments; when it
 * hits 10, the stat auto-improves and the counter resets.
 *
 * At-cap (current >= 18 + ancestry mod): clicking the checkbox posts a
 * GM approval chat card. GM clicks Approve → capOverride flag set, the
 * checkbox toggles on, player can roll. GM clicks Decline → no change.
 *
 * Storage:
 *   system.stats.<key>.improve     — boolean marker
 *   system.stats.<key>.failCounter — int 0-9, resets on success
 *   system.stats.<key>.exp         — int, total +1s applied (display only)
 *   system.stats.<key>.capOverride — bool, set on GM approval, cleared on
 *                                     successful improvement
 */

const STAT_KEYS = ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha']
const AUTO_IMPROVE_THRESHOLD = 10

/**
 * Get the cap for a given stat (18 + ancestry mod).
 */
export function getStatCap (actor, statKey) {
  const caps = actor.flags?.['elysium']?.derived?.statCaps
  if (caps && caps[statKey] != null) return caps[statKey]
  // Fallback if derived data not yet computed
  const ancestryMod = Number(actor.system?.stats?.[statKey]?.culture) || 0
  return 18 + ancestryMod
}

/**
 * Get the current total for a stat.
 */
export function getStatTotal (actor, statKey) {
  const stat = actor.system?.stats?.[statKey]
  if (!stat) return 0
  // The total field may not exist if data hasn't been prepared; compute fallback
  if (stat.total != null) return Number(stat.total)
  return (Number(stat.base) || 0)
       + (Number(stat.redist) || 0)
       + (Number(stat.culture) || 0)
       + (Number(stat.exp) || 0)
       + (Number(stat.effects) || 0)
       + (Number(stat.age) || 0)
}

/**
 * Whether a stat is at or above its cap.
 */
export function isAtCap (actor, statKey) {
  const total = getStatTotal(actor, statKey)
  const cap = getStatCap(actor, statKey)
  return total >= cap
}

/**
 * Toggle the improve marker on a stat. If the stat is at cap and no
 * capOverride is set, posts a GM approval card instead of toggling.
 *
 * Called by the click handler on the headline checkbox.
 */
export async function markForImprovement (actor, statKey) {
  if (!STAT_KEYS.includes(statKey)) return
  const stat = actor.system.stats[statKey]
  const currentlyMarked = !!stat.improve
  const hasOverride = !!stat.capOverride

  // If currently marked, just unmark — no cap check needed.
  if (currentlyMarked) {
    await actor.update({ [`system.stats.${statKey}.improve`]: false })
    return
  }

  // Trying to mark. Check cap.
  if (isAtCap(actor, statKey) && !hasOverride) {
    await postCapApprovalCard(actor, statKey)
    return
  }

  // Not at cap (or has override) — mark normally.
  await actor.update({ [`system.stats.${statKey}.improve`]: true })
}

/**
 * Roll an improvement attempt for a stat. Called by Shift+Click on the
 * checkbox or by the per-tab Roll Improvements button.
 *
 * Mechanic: 3d6 over current stat to succeed. On success: +1 to stat.exp,
 * counter resets, capOverride clears. On failure: counter increments;
 * if counter reaches 10, auto-improve (+1 to stat.exp), counter resets.
 *
 * If at cap without override, posts the GM approval card and returns
 * without rolling.
 */
export async function rollImprovement (actor, statKey) {
  if (!STAT_KEYS.includes(statKey)) return
  const stat = actor.system.stats[statKey]

  // Gate 1: stat must be marked for improvement before rolling.
  if (!stat.improve) {
    ui.notifications?.warn(
      `${statKey.toUpperCase()} is not marked for improvement. Click the checkbox first to mark it.`
    )
    return
  }

  // Gate 2: at cap requires GM approval (separate flag).
  if (isAtCap(actor, statKey) && !stat.capOverride) {
    await postCapApprovalCard(actor, statKey)
    return
  }

  // Gate 3: each attempt costs 1 EXP die. If 0 dice, ask GM for a one-shot
  // override (lets the player roll once without spending a die).
  const expFlag = actor.system?.elysium?.expDice ?? {}
  const diceAvailable = Number(expFlag.available) || 0
  const hasDiceOverride = !!actor.system?.elysium?.expDiceOverride

  if (diceAvailable < 1 && !hasDiceOverride) {
    await postExpDiceApprovalCard(actor, statKey)
    return
  }

  const currentTotal = getStatTotal(actor, statKey)
  const roll = await new Roll('3d6').evaluate()
  const result = roll.total
  const succeeded = result > currentTotal

  const updates = {}
  let outcomeText = ''
  let autoTriggered = false

  // EXP die accounting — every attempt costs 1 die unless the GM granted
  // a one-shot override. Override is consumed on any roll (success or fail).
  let dieSpentText = ''
  if (hasDiceOverride) {
    updates['system.elysium.expDiceOverride'] = false
    dieSpentText = '<em>GM-approved free attempt</em> · '
  } else {
    updates['system.elysium.expDice.available'] = diceAvailable - 1
    dieSpentText = `Spent 1 EXP die (${diceAvailable - 1} remaining) · `
  }

  if (succeeded) {
    // Success → +1 to exp, reset counter, clear improve marker & cap override.
    const newExp = (Number(stat.exp) || 0) + 1
    updates[`system.stats.${statKey}.exp`] = newExp
    updates[`system.stats.${statKey}.failCounter`] = 0
    updates[`system.stats.${statKey}.improve`] = false
    updates[`system.stats.${statKey}.capOverride`] = false
    outcomeText = `Success — ${statKey.toUpperCase()} increased by 1 (now ${currentTotal + 1}).`
  } else {
    // Failure → increment counter, check for auto-improve.
    const newCounter = (Number(stat.failCounter) || 0) + 1
    if (newCounter >= AUTO_IMPROVE_THRESHOLD) {
      // Auto-improve: counter resets, exp+1, marker and override clear.
      const newExp = (Number(stat.exp) || 0) + 1
      updates[`system.stats.${statKey}.exp`] = newExp
      updates[`system.stats.${statKey}.failCounter`] = 0
      updates[`system.stats.${statKey}.improve`] = false
      updates[`system.stats.${statKey}.capOverride`] = false
      autoTriggered = true
      outcomeText = `Failed — but ${AUTO_IMPROVE_THRESHOLD} consecutive failures triggers auto-improve. ${statKey.toUpperCase()} increased by 1 (now ${currentTotal + 1}).`
    } else {
      updates[`system.stats.${statKey}.failCounter`] = newCounter
      const remaining = AUTO_IMPROVE_THRESHOLD - newCounter
      outcomeText = `Failed — fail counter ${newCounter}/${AUTO_IMPROVE_THRESHOLD} (${remaining} until auto-improve).`
    }
  }

  await actor.update(updates)

  // Post chat card.
  const body =
    `<p>Current value: <strong>${currentTotal}</strong></p>` +
    `<p>3d6 rolled: <strong>${result}</strong> ${succeeded ? '&gt; ' : '&le; '}${currentTotal} ${succeeded ? '✓' : '✗'}</p>` +
    `<p>${dieSpentText}</p>` +
    `<p>${outcomeText}</p>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
    {
      variant: (succeeded || autoTriggered) ? 'success' : 'danger',
      title: `${actor.name} — ${statKey.toUpperCase()} improvement`,
      icon: 'dice',
      body,
    }
  )
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    rolls: [roll],
    rollMode: game.settings.get('core', 'rollMode'),
    content: html,
  })
}

/**
 * Post a chat card to the GM asking whether to approve a player's request
 * to push a stat past its cap. Approve sets capOverride=true and marks the
 * improve flag; Decline does nothing.
 */
async function postCapApprovalCard (actor, statKey) {
  const total = getStatTotal(actor, statKey)
  const cap = getStatCap(actor, statKey)
  const ancestryMod = cap - 18
  const ancestrySign = ancestryMod >= 0 ? '+' : ''
  // Per c2 audit D4: this is an edge case — the buttons use class-based
  // dispatch (`.elysium-cap-approve` / `.elysium-cap-decline`) read by
  // `chat-card.mjs:200` wireCapOverrideButtons, plus a parent-class probe
  // (`.elysium-stat-cap-card` / `.elysium-stat-dice-card`) for card-type
  // routing. Preserve those classes verbatim (audit-5 lock) by passing a
  // caller-built body to the chat-card-notice partial.
  const body = `
    <div class="elysium-stat-cap-card">
      <p><strong>${actor.name}</strong> is requesting to mark
      <strong>${statKey.toUpperCase()}</strong> for improvement past its current cap.</p>
      <p>Current value: <strong>${total}</strong> · Cap: <strong>${cap}</strong>
         (18 + ancestry mod ${ancestrySign}${ancestryMod})</p>
      <p class="elysium-stat-cap-buttons">
        <button type="button" class="elysium-cap-btn elysium-cap-approve"
                data-actor-id="${actor.id}" data-stat-key="${statKey}">
          <i class="fas fa-check"></i> Approve
        </button>
        <button type="button" class="elysium-cap-btn elysium-cap-decline"
                data-actor-id="${actor.id}" data-stat-key="${statKey}">
          <i class="fas fa-times"></i> Decline
        </button>
      </p>
    </div>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', title: 'Cap-override request', icon: 'shield-halved', body }
  )
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    whisper: ChatMessage.getWhisperRecipients('GM'),
    content: html,
  })
}

/**
 * Handler for GM clicks on Approve / Decline buttons. Called from the
 * chat-card delegation in register-hooks.
 */
export async function handleCapApproval (actor, statKey, approved) {
  if (!STAT_KEYS.includes(statKey)) return
  if (approved) {
    await actor.update({
      [`system.stats.${statKey}.capOverride`]: true,
      [`system.stats.${statKey}.improve`]: true,
    })
    ui.notifications?.info(`${actor.name}: ${statKey.toUpperCase()} cap-override approved.`)
  } else {
    ui.notifications?.info(`${actor.name}: ${statKey.toUpperCase()} cap-override declined.`)
  }
}

/**
 * Post a chat card to the GM asking whether to approve a player's request
 * to roll improvement when they have no EXP dice available. Approve sets
 * a one-shot expDiceOverride flag that's consumed by the next roll;
 * Decline does nothing.
 */
async function postExpDiceApprovalCard (actor, statKey) {
  // Per c2 audit D4: edge case — preserve `.elysium-stat-cap-card`
  // + `.elysium-stat-dice-card` + `.elysium-cap-approve` / `-decline`
  // class hooks for chat-card.mjs:200 wireCapOverrideButtons handler.
  const body = `
    <div class="elysium-stat-cap-card elysium-stat-dice-card">
      <p><strong>${actor.name}</strong> is requesting to attempt
      <strong>${statKey.toUpperCase()}</strong> improvement with no EXP dice available.</p>
      <p>Approving grants a one-shot free attempt (no EXP die spent).
      The override is consumed by the next roll, success or failure.</p>
      <p class="elysium-stat-cap-buttons">
        <button type="button" class="elysium-cap-btn elysium-cap-approve elysium-dice-approve"
                data-actor-id="${actor.id}" data-stat-key="${statKey}">
          <i class="fas fa-check"></i> Approve
        </button>
        <button type="button" class="elysium-cap-btn elysium-cap-decline elysium-dice-decline"
                data-actor-id="${actor.id}" data-stat-key="${statKey}">
          <i class="fas fa-times"></i> Decline
        </button>
      </p>
    </div>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', title: 'EXP Dice override request', icon: 'dice-d6', body }
  )
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    whisper: ChatMessage.getWhisperRecipients('GM'),
    content: html,
  })
}

/**
 * Handler for GM clicks on the EXP-dice override Approve / Decline buttons.
 * Approve sets a one-shot flag; Decline does nothing.
 */
export async function handleExpDiceApproval (actor, statKey, approved) {
  if (!STAT_KEYS.includes(statKey)) return
  if (approved) {
    await actor.update({
      'system.elysium.expDiceOverride': true,
    })
    ui.notifications?.info(`${actor.name}: free EXP-dice override approved (one attempt).`)
  } else {
    ui.notifications?.info(`${actor.name}: EXP-dice override declined.`)
  }
}

/**
 * Roll improvement for all currently-marked stats on the actor.
 * Used by a "Roll Marked Improvements" button at downtime/session end.
 */
export async function rollAllMarkedImprovements (actor) {
  const marked = STAT_KEYS.filter(k => actor.system.stats[k]?.improve)
  if (marked.length === 0) {
    ui.notifications?.warn(`${actor.name}: no stats marked for improvement.`)
    return
  }
  for (const key of marked) {
    await rollImprovement(actor, key)
  }
}
