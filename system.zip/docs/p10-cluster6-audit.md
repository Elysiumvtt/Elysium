# P10 Cluster 6 prep audit — career sheet rebuild

**Status**: PENDING — closes P10
**Target alpha**: alpha.44
**Scope**: 1 item type — career
**Inheritance from**: P10 cluster 3b (ElysiumDragDropItemSheet) + cluster 1 (shell partials + item-field-row/grid) + cluster 3b (item-skill-row)

After cluster 6: **23 of 23 item types** on v1.0.0 (100%); P10 closes.

---

## Current state inventory

### Sheet class — `module/item/sheets/career.mjs` (417 LOC)

Direct extension of `ElysiumItemSheetV2` (NOT yet on the cluster-3b `ElysiumDragDropItemSheet` base). Carries 248 LOC of duplicated drag/drop + collection-management boilerplate that already lives on the cluster-3b base:

- 8 drag/drop methods (`_canDragStart`/`_canDragDrop`/`_onDragStart`/`_onDragOver`/`_onDropItem`/`_onDropFolder`/`get dragDrop`/`#createDragDropHandlers`): **64 LOC** (lines 351-414)
- 4 collection-management methods (`_onItemDelete`/`_onGroupItemDelete`/`_onItemView`/`_onGroupControl`): **~73 LOC** (lines 277-348) — `_onGroupControl` materially identical to base; `_onItemDelete` and `_onGroupItemDelete` STILL use legacy `.closest('.item')` selectors (NOT widened in alpha.41 — career was untouched by cluster 3b)
- 1 distinct method: `_onPowersDelete` (lines 316-327, 12 LOC) — same shape as `_onItemDelete` but operates on `powers` collection instead of `skills`

Sheet uses MULTIPLE tabs (skills + powers + wealth + description + gmNotes), not single-page details. Has `_preparePartContext` switch for the 4 content tabs + gmNotes (description text enrichment) — a pattern that's been hoisted to the base in `parts/item-shell-description.hbs` / `parts/item-shell-gmnotes.hbs` post-cluster 1.

Form handler `myCareerHandler` is materially identical to `myPersonalityHandler` (groups array rehydration). 16 LOC.

`_onDrop` is the most complex on the system: 3 drop target routing branches via `currentTarget.classList.contains()`:
- `.optional-skills` → group skills (per group index)
- `.main-powers` → powers collection
- (else) → main skills collection

Plus dup-detection + the "remove from groups when added to main" logic that personality has.

`PARTS` uses the LEGACY paths still:
- `item.header.hbs` (not the v1.0.0 `parts/item-shell-header.hbs`)
- `global/parts/tab-navigation.hbs` (not `parts/item-shell-tabs.hbs`)
- `item.description.hbs` / `item.gmnotes.hbs` (not the v1.0.0 shell partials)

### Templates (3 files, 120 lines total)
- `career.skills.hbs` (79 lines) — main skill list + groups (with add-group control + per-group remove-group + per-group options input); uses inline skill row markup (now superseded by cluster-3b `item-skill-row.hbs`)
- `career.powers.hbs` (20 lines) — main powers list; inline power row markup
- `career.wealth.hbs` (21 lines) — `hitlocgrid` markup for min/max wealth selects

All 3 templates ride 18 legacy classes (`horizontalboxed`, `wealth-display`, `main-skills`, `main-powers`, `optional-skills`, `optGroup`, `brpform-group`, `group-label`, `item-power-delete`, plus more generic `item`, `flexrow`, `boxed`, `centre`, `font14`, etc.). Eight of these are career-ONLY (confirmed via grep: zero non-career consumers).

### DataModel — `module/data/item/career.mjs` (80 LOC)
- `skills: ArrayField<{uuid, elysiumid}>` — main skill list (drop target)
- `groups: ArrayField<{options: int, skills: ArrayField<{uuid, elysiumid}>}>` — optional skill groups (same shape as personality)
- `powers: ArrayField<ObjectField>` — main powers list (drop target; uses same `{uuid, elysiumid}` shape inside the ObjectField)
- `minWealth`/`maxWealth: NumberField<int>` — wealth bracket selects
- 4 compendium-only fields (`commonSkills`, `careerSkills`, `culture`, `cultureBonus`) — UNTOUCHED, still consumed by character-creator (P12 work)
- `elysium` sub-schema with 11 fields (tier, group sizes, BP cost, magic-system access, starting equipment/abilities/wealth, themes, isElysiumCareer flag) — character-creator-driven, NOT exposed on the sheet

The DataModel-exposed UI is just: skills/groups/powers/min+maxWealth. The 11 `elysium.*` fields and the 4 compendium-only fields are character-creator territory.

### LOC reduction projection
- career.mjs: 417 → ~180 = **-237 LOC** (-57%) via base-class hoist + collection-method delegation
- Templates: 120 lines current; rewrite probably similar line count (rebuilding for cluster-1 partials adds verbosity per field but skill row partial removes ~30 LOC of inline markup)

Cumulative cluster 1-6 net: -1401 (after cluster 5) + ~-237 (cluster 6 sheet hoist) = **~-1638 LOC across 22 sheet rebuilds**.

---

## 13 decisions for cluster 6

### c6-1: Base class — extend `ElysiumDragDropItemSheet` (cluster-3b)

**Recommendation**: Extend cluster-3b's `ElysiumDragDropItemSheet`. Mirrors what cluster 5 did for skill. The 64 LOC of drag/drop boilerplate + ~47 LOC of default `_onItemDelete`/`_onItemView`/`_onGroupItemDelete`/`_onGroupControl` go away. Just override `_onDrop` for the 3-target routing logic.

Cluster 5 already proved this pattern works on skill — career is structurally identical except for the extra `powers` collection.

**Trade-off**: Career's `_onItemDelete` works on `skills` (base default — already correct); career's `_onGroupItemDelete` works on the same `groups` shape personality uses (base default — already correct). Only `_onPowersDelete` needs to live in the subclass because the base doesn't know about a third collection.

### c6-2: Tabs structure — keep 3 content tabs OR consolidate to single-page

**Recommendation**: Keep current 3 content tabs (skills + powers + wealth). The sheet has 3 functionally distinct surfaces with different drop-target semantics. Consolidating would require nested section-headers + creates a long scrolling sheet that hides the wealth selects. The audit-then-stop principle from cluster 5 applies — don't restructure UX semantics during a migration ship.

PARTS structure: `header / tabs / skills / powers / wealth / description / gmNotes` — matches existing.
TAB_ORDER = `['header', 'tabs', 'skills', 'powers', 'wealth', 'description', 'gmNotes']`.

### c6-3: PARTS path migration — swap to v1.0.0 shell partials

**Recommendation**: Same swap done in clusters 1-5:
- `item.header.hbs` → `parts/item-shell-header.hbs`
- `global/parts/tab-navigation.hbs` → `parts/item-shell-tabs.hbs`
- `item.description.hbs` → `parts/item-shell-description.hbs`
- `item.gmnotes.hbs` → `parts/item-shell-gmnotes.hbs`

Drop the manual `enrichedDescription` / `enrichedGMDescription` building in `_preparePartContext` — the shell partials are self-sufficient (build their own enriched HTML from `system.description` / `system.gmDescription`).

### c6-4: Sheet size — keep 520×520 OR widen to standard 720×640

**Recommendation**: Widen to standard tier (560×720). The 520×520 footprint is the smallest in the system; with 3 content tabs (skills/powers/wealth) all needing list real estate, 520 wide is too narrow for the skill rows + delete controls. 560 matches personality/culture (also 560×640) which share the same skill-list pattern.

Height 720 vs 640: 720 because career has BOTH skills AND powers lists (personality has only skills). 640 would force scrolling earlier.

### c6-5: Header chips — 3 chips per audit pattern

**Recommendation**: 3 chips for the header summary:
- **Min Wealth** — `Elysium.minWealth` label, wealth-level localized value
- **Max Wealth** — `Elysium.maxWealth` label, wealth-level localized value
- **Tier** — `Elysium.tier` label, `system.elysium.tier` value (basic/journeyman/master/etc.)

Tier surfaces the v0.19+ Elysium-fork concept that legacy didn't expose on the sheet (only in compendium data). Adding it makes the chip line useful at a glance for character creators.

### c6-6: Skills tab — reuse cluster-3b skill list pattern

**Recommendation**: Mirror personality exactly. Section card with main skill list + section card with groups. All skill rows use the cluster-3b `item-skill-row.hbs` partial. The legacy career.skills.hbs has near-identical structure to personality.detail.hbs — the migration is a near-mechanical port.

Class hooks preserved per audit-5 lock: `item-list`, `droppable`, `optional-skills`, `group-control`, `add-group`, `remove-group`, `item-delete`, `group-item-delete`. The base class binds these in `_onRender`.

### c6-7: Powers tab — new powers list pattern

**Recommendation**: Section card with the powers list. Power rows are simpler than skill rows (just name + delete control — no variable/group/bonus formatting). No need for a new shared partial — inline markup is fine for a single consumer.

Drop zone class `main-powers` is the routing contract `_onDrop` needs to distinguish powers drops from skills drops. PRESERVE this class hook on the drop zone div.

Power delete is via `.item-power-delete` class (NOT `.item-delete` — different collection). The cluster-3b base binds `.item-delete` only; career's `_onRender` must extend base to also bind `.item-power-delete` to `_onPowersDelete`. ~3 LOC sub-class addition.

Alternative considered: route powers delete through `_onItemDelete` with `data-collection="powers"` attribute. Decided against because (a) it'd require changing the base class to read `data-collection` (adds complexity benefiting only career), (b) the 3-LOC sub-class extension is the cleaner pattern given career is the only multi-collection drop sheet.

### c6-8: Wealth tab — section card with item-field-row pattern

**Recommendation**: Single section card with 2 rows for min/max wealth selects via `item-field-row.hbs` partial (cluster 1). Replaces the legacy `hitlocgrid` + `wealth-display` markup. ~25 lines vs current 21.

### c6-9: `_onDrop` override — 3-target routing preserved

**Recommendation**: Override `_onDrop` in career sheet. Same 3-target routing as legacy:
1. `optional-skills` class on event currentTarget → group skills + dup-detect against main AND that group
2. `main-powers` class → powers collection + dup-detect
3. (else) → main skills collection + dup-detect against main AND remove-from-groups

Logic is preserved verbatim from legacy career.mjs:205-273; only the surrounding boilerplate is hoisted away.

### c6-10: `_onPowersDelete` — sub-class addition

**Recommendation**: Keep `_onPowersDelete` as a sub-class method since the base has no concept of a 3rd collection. Use the widened `[data-item-id]` selector pattern from cluster 3b (NOT the legacy `.closest('.item')`) for forward-compatibility with the v1.0.0 markup.

### c6-11: Form handler — `myCareerHandler` preserved (with cleanup)

**Recommendation**: Keep `myCareerHandler` static method bound to `form.handler` in DEFAULT_OPTIONS. The groups-array rehydration logic is the same as personality/culture/skill. Optional cleanup: also rehydrate `powers` array since formData submits don't preserve array shape — currently legacy career relies on never having a form field that submits `system.powers`, which is a fragile assumption. Adding the rehydration is the same defensive pattern.

### c6-12: Legacy CSS retirement (post-rebuild)

**Recommendation**: Retire 8 career-only legacy CSS blocks (pre-flight grep confirmed zero non-career consumers):
- `.horizontalboxed` — likely in legacy.css line 1033
- `.wealth-display` — legacy.css line 1064
- `.group-label` — legacy.css line 1043
- `.optGroup` — legacy.css line 1459
- `.main-skills` — likely no CSS block (purely a contract hook); REPLACE if found
- `.main-powers` — PRESERVE since `_onDrop` uses it as routing contract; KEEP class on template
- `.brpform-group` — no CSS block, just markup pattern
- `.item-power-delete` — no CSS block, just an event hook

Run final consumer audit after rebuild to confirm; preserve any class still consumed by non-career templates.

### c6-13: Smoke checklist (9 tests for a thinner ship)

Career is single-item-type, so a shorter checklist than cluster 5:

a. Game ready, version=1.0.0-alpha.44
b. Career sheet opens; v1.0.0 header renders with 3 chips (Min Wealth / Max Wealth / Tier)
c. Skills tab: main skill drop adds to `system.skills`; group skill drop adds to that group's `skills` array; group skill drop into MAIN removes from any group
d. Powers tab: power-type item drop adds to `system.powers`; non-power-type drop rejected
e. Wealth tab: min/max selects round-trip via `item.update()`
f. add-group / remove-group buttons add and remove `groups[]` entries
g. Item-delete / group-item-delete / item-power-delete each remove only the right row
h. Console clean of system errors after full sheet interaction
i. Cluster 1-5 regression: open one of each (gear/armor/personality/sorcery/skill/weapon) — all render identically to alpha.43

---

## i18n additions estimate

- `Elysium.tier` (header chip label — verify if exists)
- `Elysium.powers` (already exists from cluster 4 — used by character magic tab)
- Career section labels: `careerSkillsSection`, `careerGroupsSection`, `careerPowersSection`, `careerWealthSection` — 4 new
- Hint texts: `careerSkillsHint`, `careerGroupsHint`, `careerPowersHint`, `careerWealthHint` — 4 new (optional, recommend for accessibility)

Estimated **~8 new keys × 3 langs = 24 entries**. Smaller than cluster 5's 41 since career has fewer distinct UI fields.

---

## Risk + isolation

**Risks**:
- Career has been on the LEGACY stack through every cluster — its 3 listener bindings (`item-delete`, `item-view`, `item-power-delete`, `group-item-delete`, `group-control`) all use `.closest('.item')` patterns. The cluster-3b base widens to `.closest('[data-item-id]')` / `.closest('[data-group]')` — career's listener bindings will need the widened selectors via the base, which is the entire point of the hoist.
- `_onDrop` has the 3-target logic that's the most complex single method in the item-sheet system. Preserve verbatim from legacy.
- Form handler `myCareerHandler` needs the powers rehydration addition (c6-11) — small defensive change but worth verifying nothing breaks.

**Cluster isolation**: This is the LAST item-type migration. After this ship, every item type is on v1.0.0. The 4 compendium-only fields (`commonSkills`/`careerSkills`/`culture`/`cultureBonus`) are STILL not exposed on the sheet — character-creator territory. The 11 `elysium.*` fields likewise. P12 should consider whether to surface any of these on the sheet for inspection (right now they're invisible at item-edit time).

---

## After P10 closes

P10 phase summary post-cluster-6:
- **23/23 item types on v1.0.0 (100%)**
- **-1638 net LOC** across 22 sheet rebuilds
- **9 shared partials** (5 shell + 4 utility from cluster 1, plus cluster-3b skill-row + specialism-header, plus cluster 4's toggle-row + ap-grid + tier-effect-row)
- **1 intermediate base class** (`ElysiumDragDropItemSheet`)
- **One latent-bug fix** (alpha.42 itemToggle path-shape support)

P10 complete enables P11 (legacy.css final retirement sweep — any remaining orphan blocks) and P12 (polish: cast-card rebuild, statistics tab fold, DataModel cleanup, lang-parity gap, etc.).
