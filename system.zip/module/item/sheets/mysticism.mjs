import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Mysticism feat item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Feats are cast through the actor's Focus skill (modified by tier).
 * Tier 1 = full %; each tier above 1 imposes -10%. Flat 8-field
 * GM-edit / player-readonly layout.
 *
 * Per c3-mysticism-1: migrated from `elysium-spell-*` legacy classes
 * to v1.0.0 item-field-grid + item-field-row partials.
 * Per c3-mysticism-2: saveSkill select now driven by
 * ElysiumSelectLists.getSpellSaveSkillOptions().
 */
export class ElysiumMysticismSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['mysticism'],
    position: { width: 720, height: 720 },  // wide tier per audit-3
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/mysticism.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    context.itemType = game.i18n.localize('Elysium.mysticism')

    // Save-skill select + display name
    context.saveSkillOptions = await ElysiumSelectLists.getSpellSaveSkillOptions()
    const saveSkillRaw = this.item.system?.elysium?.saveSkill ?? ''
    const saveSkillKey = saveSkillRaw === ''
      ? 'Elysium.saveSkillNone'
      : 'Elysium.saveSkill' + saveSkillRaw.charAt(0).toUpperCase() + saveSkillRaw.slice(1)
    context.saveSkillName = game.i18n.localize(saveSkillKey)

    // Header chips per c3-2: Discipline + Tier + Power Cost
    const discipline = this.item.system?.elysium?.discipline ?? ''
    const tier = this.item.system?.elysium?.tier ?? 1
    const powerCost = this.item.system?.elysium?.powerCost ?? 0
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.discipline'), value: discipline === '' ? '—' : discipline },
      { label: game.i18n.localize('Elysium.tier'),       value: String(tier) },
      { label: game.i18n.localize('Elysium.powerCost'),  value: String(powerCost) },
    ]

    return context
  }
}
