# P11 Cluster 3 prep audit — singleton-roll cards (roll-result / roll-damage / roll-armor / quick-combat)

**Status**: PENDING
**Target alpha**: alpha.47
**Scope**: 4 chat templates — `roll-result.html`, `roll-damage.html`, `roll-armor.html`, `quick-combat.html`.
**Inheritance from**: P11 prep audit, cluster 1 audit, cluster 2 audit, and the 6 chat partials shipped in clusters 1+2 (chat-card-shell, chat-card-participant-row, chat-card-success-pip, chat-card-tooltip-rows, chat-card-resolve-footer, chat-card-grouproll).

Cluster 3 is the cluster where the cluster-1 partials get exercised through **composition** (option B from cluster 2 §6) rather than through inlining inside a per-cluster umbrella partial. The 4 cluster-3 cards have less internal variation than the group-roll quartet, so they should fit the cluster-1 signatures directly.

---

## 1. Current-state inventory

### Template sizes

| Template | LOC | Card types |
|---|---|---|
| `roll-result.html` | 87 | NO / RE / PP / CM (4-way branch on rollType+cardType) |
| `roll-damage.html` | 32 | IM / DM (2-way branch on rollType) |
| `roll-armor.html` | 27 | AR |
| `quick-combat.html` | 71 | QC |
| **Total** | **217** | |

### Per-card structural diff vs cluster-2 group-roll cards

The 4 cluster-3 cards share these traits NOT present on the group-roll quartet:

- **No buttons**. No resolve, no close, no per-row remove. These are read-only result cards.
- **Always closed-state** — no pending state for singleton rolls.
- **No bottom summary** (no h3 chat-dice element).
- **No crown indicator**.
- **`chatCard` always has length 1** (one participant per roll for these card types — the array shape is preserved for symmetry with group-roll cards, but only `chatCard[0]` is ever populated).

The 4 cluster-3 cards share these traits WITH the group-roll quartet (already-supported by cluster-1 partials):

- `<form class="elysium gr-card">` wrapper (audit-5 lock — Phase D mount-point selector; only CM-rollType result cards actually receive injection, but the class is preserved on all 4 for consistency).
- Bold title localized from `Elysium.card.<TYPE>`.
- `dice-roll` + `actor-roll` + `roll-details` per-participant structure.
- `owner-only` tooltip block per participant.

### Per-card variation matrix

| Card | Title key(s) | Pip strip | Healing annotation | Hitloc tag | Malfunction | Footer | Tooltip-row mode |
|---|---|---|---|---|---|---|---|
| `roll-result` (NO/RE/PP/CM) | 4-way branch from `rollType` + `cardType` | YES (5-level) with `rollVal` | YES — `[N]` after rollVal inside pip span when `healing != 0` | YES — `{{c.hitLocationName}}` rendered as `.elysium-hitloc-tag` (audit-5 lock per cluster-1 c1-3) | YES — when `c.malfunction < 0`, render `<span class="bold result-fail">Elysium.malfunction</span>` | none | `attribute-resistance` from cluster-1 (already handles all 5 mode rows: targetScore / rawScore / [resistance OR difficulty] / flatMod / optional healing / dice or dice+description) |
| `roll-damage` (IM/DM) | 2-way branch from `rollType` | NO — single `<span class="pending">{{c.rollVal}}</span>` with optional spec/critical label appended | NO | NO | NO | none | `damage` from cluster-1 (impact / dice / resultLabel) |
| `roll-armor` (AR) | `Elysium.card.AR` | NO — single `<span class="pending">{{c.rollVal}}</span>` | NO | NO | NO | none | `armor` from cluster-1 (armor / diceRoll) |
| `quick-combat` (QC) | `Elysium.card.QC` | YES (5-level) with `rollVal` | NO | NO | YES (same as roll-result) | **Per-participant damage row** outside the dice-roll: `<div class="quick-combat centre" data-tooltip="...">{{dmgCrit}}/{{dmgSpec}}/{{dmgNorm}}</div>` when `resultLevel > 1` | `attribute-resistance` from cluster-1 (uses dmgCritForm/dmgSpecForm/dmgNormForm branch — already handled by partial) |

### Cluster-1 partial fit assessment

| Partial | Fits cluster 3 directly? |
|---|---|
| `chat-card-shell.hbs` | YES — single title slot, body slot, no footer for the 4 cards. Title text built wrapper-side (especially the roll-result 4-way + roll-damage 2-way branches; the wrappers pre-resolve the title key into a `titleKey` variable and pass it in). |
| `chat-card-participant-row.hbs` | YES with the resultMode set per-card: `pip-strip` for roll-result and quick-combat, `flat-value` for roll-damage and roll-armor. **`flat-value`'s optional label append** (roll-damage's critical/special label) is the one extension needed. |
| `chat-card-success-pip.hbs` | YES for the 5-level rollVal pip. **One extension needed**: optional `healingAnnotation` parameter for roll-result's `[healing]` text. |
| `chat-card-tooltip-rows.hbs` | YES — all 4 cards' tooltip-row patterns are already encoded in the partial's 4 rollMode branches (`attribute-resistance`, `damage`, `armor`). The `attribute-resistance` branch's nested logic (resistance-or-difficulty + optional healing + dmgCritForm-or-description-or-dicereoll) already handles all of roll-result's variations. |
| `chat-card-resolve-footer.hbs` | NOT USED — singleton cards have no buttons. |
| `chat-card-grouproll.hbs` | NOT USED — that was cluster 2's umbrella partial. |

**Two minor extensions needed** to make cluster-1 partials fit cluster 3 cleanly:

1. **`chat-card-success-pip.hbs`** — add optional `healingAnnotation` parameter rendered inline next to `rollValue` (e.g., `{{rollValue}}{{#if healingAnnotation}} [{{healingAnnotation}}]{{/if}}`). Backward-compatible: existing cluster-2 consumers don't pass it.

2. **`chat-card-participant-row.hbs`** — in the `flat-value` resultMode, support an optional `entry.flatValueLabel` field for the spec/critical text appended after the rollVal (roll-damage). The current partial's flat-value mode renders just `{{entry.rollVal}}`; we extend to `{{entry.rollVal}}{{#if entry.flatValueLabel}} {{entry.flatValueLabel}}{{/if}}`. Backward-compatible.

The alternative — adding new `resultMode` values like `'pip-strip-with-healing'` and `'flat-value-with-label'` — would multiply the partial's branch count without adding expressivity. The opt-in field approach keeps the signature stable and the partial small.

---

## 2. JS-imperative class-hook contract — cluster-3 surface

For cluster 3 specifically, the audit-5 lock list applies as follows:

- `form.elysium.gr-card` — Phase D mount-point. **Required on `roll-result.html` ONLY** (Phase D filters on `rollType === 'CM'` at runtime; cluster 3 preserves the class on all 4 cards for hook-contract uniformity).
- `.cardbutton` — NOT USED in cluster 3 (no buttons on singleton cards).
- `.owner-only` + `data-partic-id` + `data-partic-type` — preserved on all 4 tooltip blocks via cluster-1 tooltip-rows partial.
- `.elysium-hitloc-tag` — `roll-result.html` ONLY. Preserved as class hook for `applyHitLocationVisibility(root)` in `chat-card.mjs`. The inline `style="margin-left:6px;padding:1px 6px;border-radius:3px;background:#604030;color:#fff;font-size:11px;"` is RETIRED and replaced by a CSS rule using the cluster-1 placeholder `.elysium-chat-card .elysium-hitloc-tag.elysium-chat-chip` (per c1-3 reservation).
- `[data-hit-loc-id]` — preserved on the hitloc-tag (consumed by Phase D resolve flow for crit-armor button).
- `.elysium-chat-card` — new c11-1 scoping marker, layered alongside `elysium gr-card`.

---

## 3. Architectural decisions for cluster 3

### c3-1: Composition vs umbrella partial — option B

Cluster 2's umbrella `chat-card-grouproll.hbs` made sense for the group-roll quartet because they share a strong central concept (per-participant pip strip with consistent structural shape) and the variation crossed many dimensions of the same surface.

Cluster 3's 4 cards diverge more (some have pips, some don't; one has hitloc tags; one has a footer damage row; one has a healing annotation). Building a unified `chat-card-singleton.hbs` would create a partial with more branching than cluster 2's grouproll partial without saving meaningful LOC.

**Recommendation**: Option B — each card becomes a thin per-card wrapper that composes the cluster-1 partials (shell, participant-row, success-pip via participant-row, tooltip-rows). Wrappers handle their own per-card branching wrapper-side.

### c3-2: Title key resolution — wrapper-side

`roll-result.html` has a 4-way title branch (CM if rollType=CM; else RE/PP/NO based on cardType). `roll-damage.html` has a 2-way branch (IM vs DM on rollType). The cleanest pattern:

```hbs
{{!-- roll-result.html --}}
{{#if (eq rollType 'CM')}}
  <div class="elysium-chat-card__title">{{localize 'Elysium.card.CM'}}</div>
{{else if (eq cardType 'RE')}}
  <div class="elysium-chat-card__title">{{localize 'Elysium.card.RE'}}</div>
{{else if (eq cardType 'PP')}}
  <div class="elysium-chat-card__title">{{localize 'Elysium.card.PP'}}</div>
{{else}}
  <div class="elysium-chat-card__title">{{localize 'Elysium.card.NO'}}</div>
{{/if}}
```

**Recommendation**: Use this pattern (preserving the legacy 4-way conditional verbatim, just with the new `__title` class hook and dropping the legacy `bold` class as it now flows through the marker rule). Same for `roll-damage`'s 2-way branch.

### c3-3: Per-card data-card-type attribute

The cluster-1 `elysium-chat-card` marker pairs with `data-card-type` for Section D card-type accents. For roll-result the runtime cardType varies (NO / RE / PP / CM); each rendered card carries its own value. For roll-damage runtime is IM or DM; for roll-armor it's always AR; for quick-combat it's always QC.

**Recommendation**:
- `roll-result.html` — `<form ... data-card-type="{{cardType}}">` (dynamic; pulls from chatMsgData.cardType)
- `roll-damage.html` — `<form ... data-card-type="{{cardType}}">` (IM or DM)
- `roll-armor.html` — `<form ... data-card-type="AR">` (static)
- `quick-combat.html` — `<form ... data-card-type="QC">` (static)

This means the dynamic-cardType cards (roll-result, roll-damage) automatically pick up the right Section D accent rule based on what the JS pipeline emits.

### c3-4: Section D card-type accents to populate

Cluster 2 populated CB / OP / GR / CO. Cluster 3 populates the remaining 7:

| Card type | Roll | Recommended accent token | Rationale |
|---|---|---|---|
| NO | Normal roll | `--ely-accent-bonus` (gold) | Generic skill check — neutral, mildly positive |
| RE | Resistance | `--ely-accent-mind` (purple) | Magical/willpower roll — mind-flavored |
| PP | POW vs POW | `--ely-accent-mind` (purple) | Same family as RE |
| CM | Combat manoeuvre | `--ely-accent-action` (crimson) | Combat — match CB's crimson |
| IM | Impact (damage subtype) | `--ely-accent-fire` (orange-red) | Damage — match the visceral feel |
| DM | Damage | `--ely-accent-fire` (orange-red) | Same family as IM |
| AR | Armor | `--ely-accent-bonus` (gold) | Protective — defensive gold |
| QC | Quick combat | `--ely-accent-action` (crimson) | Combat — match CM |

All tokens already defined; no new tokens needed.

**Recommendation**: Apply as recommended. ~21 LOC added to Section D (7 selectors × 3 lines each).

### c3-5: Hitloc-tag inline-style retirement

Legacy `roll-result.html:51`: `<span class="elysium-hitloc-tag" data-hit-loc-id="{{c.hitLocationId}}" style="margin-left:6px;padding:1px 6px;border-radius:3px;background:#604030;color:#fff;font-size:11px;">→ {{c.hitLocationName}}</span>`

The `style="..."` attribute is hardcoded color literals. Cluster-1 reserved `.elysium-chat-card .elysium-hitloc-tag.elysium-chat-chip` for this migration (line 370 of `styles/elysium-chat.css`).

**Recommendation**: Rebuilt markup:
```hbs
<span class="elysium-hitloc-tag elysium-chat-chip elysium-chat-chip--accent" data-hit-loc-id="{{c.hitLocationId}}">→ {{c.hitLocationName}}</span>
```

`elysium-chat-chip--accent` is the bonus-tinted variant (gold/parchment-like), which gives the hitloc tag a warm parchment feel matching its legacy brown-on-cream look without using hardcoded colors. The `--ely-accent-bonus-subtle` background and `--ely-accent-bonus` border are token-driven.

The cluster-1 placeholder rule `.elysium-chat-card .elysium-hitloc-tag.elysium-chat-chip` (intentionally empty per c1's note) stays as documentation; no rule additions needed because the chip-class base already does the work.

### c3-6: Pip-strip healing annotation extension

Legacy `roll-result.html` lines 28/32/36/44 each include `{{#unless (eq healing 0)}} [{{healing}}]{{/unless}}` inside the success/failure span (only in the level-4/3/2/0 branches; level-1 lacks it). The annotation appears next to `rollVal` like: `Critical: 15 [-5]`.

Note the inconsistency: the level-1 (Failure) branch doesn't include `[{{healing}}]`. Could be intentional (no healing on a failure) or could be a legacy oversight. Either way, **preserve verbatim** — the cluster-1 partial extension makes this opt-in per-call.

**Recommendation**: Extend `chat-card-success-pip.hbs` with an optional `healingAnnotation` parameter:

```hbs
{{!-- inside each pip-level branch (4, 3, 2, 0 but NOT 1) --}}
<span class="...">{{resultLabel}}: {{rollValue}}{{#if healingAnnotation}} [{{healingAnnotation}}]{{/if}}<i ...></i>...</span>
```

Roll-result's wrapper passes `healingAnnotation=(unless (eq c.healing 0) c.healing)` — but the `(unless ...)` form is a block helper not an inline one. Simpler: pass `healingAnnotation=c.healing` if `c.healing != 0`, else omit. Easiest is wrapper-side: `{{#unless (eq c.healing 0)}} ... healingAnnotation=c.healing ... {{else}} ... no healingAnnotation ...{{/unless}}` — but that doubles the partial call site.

Cleaner: pass `c.healing` always, and let the partial test for truthiness/non-zero inside. Since Handlebars `{{#if value}}` treats 0 as falsy, just `{{#if healingAnnotation}}` correctly suppresses when healing is 0.

**Recommendation refined**: Roll-result wrapper passes `healingAnnotation=c.healing` always (no branching). Partial gates with `{{#if healingAnnotation}}`. **Watch out for legitimate `healing=-5` cases**: `{{#if -5}}` is truthy, so the bracket appears. That matches the legacy behavior (which used `(eq healing 0)` to specifically exclude zero, allowing negative). Confirmed compatible.

### c3-7: Flat-value participant-row label extension (roll-damage)

Legacy `roll-damage.html:19`:
```hbs
<span class="pending">{{c.rollVal}} {{#if (eq c.resultLevel "4")}} {{localize 'Elysium.critical' }}-{{c.specLabel}} {{/if}} {{#if (eq c.resultLevel "3")}}{{c.specLabel}} {{/if}}</span>
```

When resultLevel is 4 (critical), append " Critical-{specLabel}". When 3 (special), append "{specLabel}". Otherwise just the rollVal.

**Recommendation**: Extend `chat-card-participant-row.hbs`'s `flat-value` resultMode with optional `entry.flatValueLabel` field:
```hbs
{{#if (eq resultMode "flat-value")}}
  <span class="pending">{{entry.rollVal}}{{#if entry.flatValueLabel}} {{entry.flatValueLabel}}{{/if}}</span>
{{/if}}
```

Roll-damage wrapper builds the label wrapper-side:
```hbs
{{!-- roll-damage.html --}}
{{#each chatCard as |c key|}}
  {{!-- Append the spec/critical label based on resultLevel --}}
  {{#if (eq c.resultLevel "4")}}
    {{!-- wrapper builds entry.flatValueLabel for the partial somehow --}}
  {{/if}}
{{/each}}
```

PROBLEM: wrappers can't mutate iteration entries in Handlebars. Two options:

- **(A) Add a Handlebars helper** `damageSpecLabel(c)` that returns the right label per resultLevel.
- **(B) Inline the label-build logic into the wrapper template itself**: skip composing `participant-row` and inline the row markup.
- **(C) Push the label-build into the JS pipeline**: have `check.mjs` compute `c.flatValueLabel` before passing to `renderTemplate`.

Option C is the cleanest long-term (no new helper, no inlining, no partial signature change), but it changes JS — the chat-data structure — and we've been keeping cluster scope to markup+CSS only.

Option B is the cluster-2 pattern (inline because variation > partial signature) and would mean roll-damage doesn't actually compose `chat-card-participant-row` at all — it inlines a simple `<li class="actor-roll">...<span class="pending">{{c.rollVal}} ...</span></li>` structure.

Option A adds a helper but the helper is single-purpose and trivially testable.

**Recommendation**: Option B — for roll-damage and roll-armor specifically. Inlining 8-10 LOC of participant row markup is simpler than extending the partial OR adding a one-off helper. roll-result and quick-combat (which DO use pip-strip) still compose `chat-card-success-pip` directly via inline rendering of the row's outer structure. This is a slight retreat from "compose 100%" but cleaner than introducing data-mutation gymnastics.

**Compromise to preserve composition**: Where roll-result and quick-combat naturally fit cluster-1 partials, compose them. Where roll-damage/roll-armor don't, inline. Trade-off accepted: cluster-3's 4 wrappers won't all look identical (some compose, some inline), but each is small.

### c3-8: Per-participant footer damage row (quick-combat)

Legacy `quick-combat.html:66-68`:
```hbs
{{#if (gt c.resultLevel 1)}}
  <div class='quick-combat centre' data-tooltip="{{localize 'Elysium.damagesAbbrHint'}}">{{localize 'Elysium.damagesAbbr'}}: {{dmgCrit}}/{{dmgSpec}}[{{specLabel}}]/{{dmgNorm}}</div>
{{/if}}
```

This sits per-participant (inside `{{#each chatCard}}` and inside the `dice-roll` div). Note: `dmgCrit`, `dmgSpec`, `dmgNorm`, `specLabel` are all TOP-LEVEL fields on the chatMsgData (not under `c.`), but `c.resultLevel` is per-participant.

Since `chatCard` always has length 1 for these card types (singleton roll), the top-level vs per-participant distinction doesn't matter in practice — there's exactly one row, and one set of damage values.

**Recommendation**: Preserve verbatim in the quick-combat wrapper. The `quick-combat centre` class is a legacy class hook that's currently styled via `css/legacy.css`. The `centre` class is generic — leave it for now and tag the wrapper as a P12 opportunistic cleanup if we want to retoken it to a token-driven `--ely-accent-fire-subtle` background.

Actually — let me check if `quick-combat centre` has dedicated CSS:

```
[Investigation deferred to coding-time grep — if no dedicated CSS, the centre class is purely cosmetic and inert; if there IS dedicated CSS, document it for P12]
```

### c3-9: Malfunction inline tag

Legacy `roll-result.html:46-48` and `quick-combat.html:34-36` both have:
```hbs
{{#if (lt c.malfunction 0)}}
  <span class="bold result-fail"> {{localize 'Elysium.malfunction'}}</span>
{{/if}}
```

Renders inline after the pip strip, before the closing `</span>`. The legacy outer `<span class="pending roll-*">` doesn't get a closing tag inside the if-branch — the closing `</span>` happens at the end on line 49 (roll-result) and 37 (quick-combat). It's mal-formed HTML but the browser parses it.

The cluster-1 success-pip partial fully closes each branch's `<span>`. To preserve the malfunction inline, the wrapper has to render the malfunction OUTSIDE the success-pip's span (after it).

**Recommendation**: Render the malfunction marker as a sibling element after the success-pip call:
```hbs
{{> "systems/elysium/templates/chat/parts/chat-card-success-pip.hbs"
    resultLevel=c.resultLevel
    resultLabel=c.resultLabel
    rollValue=c.rollVal
    healingAnnotation=c.healing
    showCrown=false}}
{{#if (lt c.malfunction 0)}}
  <span class="bold result-fail"> {{localize 'Elysium.malfunction'}}</span>
{{/if}}
```

Visual: identical (the malfunction span renders right after the closing pip span). Better-formed HTML (no orphaned span tag). Same legacy class hooks.

### c3-10: Wrapper structure — one canonical shape

Each cluster-3 wrapper structure:

```hbs
<form class="elysium gr-card elysium-chat-card" data-card-type="...">
  <div class="elysium-chat-card__title">...</div>
  <ol class="gr-list">
    {{#each chatCard as |c key|}}
      <div class="dice-roll" data-action="expandRoll">
        <li class="actor-roll">
          <img class="open-actor" .../>
          <div class="roll-details">
            <div class="header roll-truncate">
              <div class="name"><span class="tag">{{c.label}} ({{c.targetScore}}%)</span></div>
            </div>
            {{!-- Pip strip OR flat-value, per card --}}
            {{!-- Optional malfunction marker --}}
            {{!-- Optional hitloc tag (roll-result only) --}}
          </div>
        </li>
        {{> "systems/elysium/templates/chat/parts/chat-card-tooltip-rows.hbs"
            entry=c cardType=../cardType rollMode="..."}}
      </div>
      {{!-- Optional per-participant footer (quick-combat only) --}}
    {{/each}}
  </ol>
</form>
```

The 4 wrappers share this skeleton; the bits in `{{!-- ... --}}` differ per card. ~30-40 LOC per wrapper.

The image, name-strip header, and per-participant tag are inlined (rather than composing participant-row) because participant-row's pre-built pip-strip body doesn't quite cover roll-result's healing + malfunction + hitloc combination cleanly. Compromise per c3-7.

### c3-11: Legacy CSS retirement

Cluster 3 retires:
- The inline-style attribute on `.elysium-hitloc-tag` (replaced by `.elysium-chat-chip` cascade per c3-5).
- The orphan `roll-truncate` legacy CSS rule if it exists separately — but it appears in `css/legacy.css` too, and is still consumed by other (non-cluster-3) chat surfaces. Hold for cluster 4.

**Recommendation**: Just the hitloc inline-style. Zero legacy CSS file rules retired in cluster 3 (orphaning candidates documented for P12 final sweep).

### c3-12: i18n keys

Existing keys consumed across cluster 3:
- `Elysium.card.NO`, `Elysium.card.RE`, `Elysium.card.PP`, `Elysium.card.CM`, `Elysium.card.IM`, `Elysium.card.DM`, `Elysium.card.AR`, `Elysium.card.QC`
- `Elysium.rawScore`, `Elysium.targetScore`, `Elysium.difficulty`, `Elysium.resistVal`, `Elysium.flatMod`, `Elysium.healing`, `Elysium.diceRoll`, `Elysium.description`, `Elysium.impact`, `Elysium.dice`, `Elysium.armor`, `Elysium.critical`, `Elysium.special`, `Elysium.normal`, `Elysium.malfunction`, `Elysium.damagesAbbr`, `Elysium.damagesAbbrHint`

All verified resolved during the cluster 1 + 2 i18n sweep. **Zero new keys in cluster 3.**

### c3-13: Smoke methodology

**Offline-render coverage**: 4 templates × multiple state variations = ~15 fixtures:
- `roll-result` × 4 cardTypes (NO / RE / PP / CM) × {with healing, without healing} × {with hitloc, without hitloc} × {with malfunction, without malfunction} — that's 32 combinations; we'll sample ~6 distinctive ones.
- `roll-damage` × 2 rollTypes (IM, DM) × {resultLevel 4 critical with specLabel, resultLevel 3 special with specLabel, resultLevel ≤ 2 plain} = 6 combinations; sample 3.
- `roll-armor` × 1 (no variation) = 1 fixture.
- `quick-combat` × 5 result levels × {with malfunction, without} = 10 combinations; sample 4.

Total: ~14 distinct fixtures.

**Audit-5 contract checks per fixture**:
- `<form class="elysium gr-card elysium-chat-card" data-card-type="X">` present
- `.owner-only` block with correct `data-partic-id` + `data-partic-type`
- Hitloc tag class hooks preserved (`.elysium-hitloc-tag` + `data-hit-loc-id`) on roll-result CM
- Hitloc tag inline-style ABSENT (verifies c3-5 retirement)
- Pip class hooks preserved on roll-result + quick-combat (`pending roll-succ` / `roll-fail` / `roll-fumb`, `result-success` / `result-fail` / `result-yellow`)
- No `.cardbutton` element (singleton cards have no buttons)
- No `.chat-dice` element (singleton cards have no bottom summary)

**Live smoke**: post a CM-rollType roll-result card in the test world and verify:
- Phase D injection fires (GM action panel appears below the form)
- Hitloc tag renders with chip styling (token-driven look)
- Hitloc visibility setting still respected (`applyHitLocationVisibility` works)
- Click the hitloc tag — should still trigger the crit-armor button binding if Phase D is active

---

## 4. Cluster-3 ship summary

**Files modified — 2 cluster-1 partial extensions**:

1. `templates/chat/parts/chat-card-success-pip.hbs` — add optional `healingAnnotation` parameter; render inline next to `rollValue` when truthy. Each of the 5 level-branches gets `{{#if healingAnnotation}} [{{healingAnnotation}}]{{/if}}` inserted after `{{rollValue}}`.

2. `templates/chat/parts/chat-card-participant-row.hbs` — in `flat-value` mode, support optional `entry.flatValueLabel` appended after `{{entry.rollVal}}`. One-line change.

**Files modified — 4 templates rewritten**:

- `templates/chat/roll-result.html` 87 → ~45 LOC (4-way title branch, pip strip via success-pip, hitloc retoken, malfunction sibling, attribute-resistance tooltip via tooltip-rows)
- `templates/chat/roll-damage.html` 32 → ~28 LOC (2-way title branch, flat-value with wrapper-built label, damage tooltip)
- `templates/chat/roll-armor.html` 27 → ~22 LOC (single title, flat-value, armor tooltip)
- `templates/chat/quick-combat.html` 71 → ~50 LOC (single title, pip strip via success-pip, malfunction sibling, attribute-resistance tooltip, per-participant footer damage row preserved)

**Files modified — styles**:

- `styles/elysium-chat.css` — populate Section D card-type accents for NO/RE/PP/CM/IM/DM/AR/QC (7 selectors; CM and QC reuse `--ely-accent-action`, RE+PP reuse `--ely-accent-mind`, IM+DM reuse `--ely-accent-fire`, NO+AR reuse `--ely-accent-bonus`). ~21 LOC.

**Files modified — i18n + JS**: NONE. Zero new i18n keys; zero JS changes.

**Net LOC**: ~217 → ~145 across templates (-72 LOC); +~10 LOC across the 2 partial extensions; +~21 LOC CSS. **Net: -41 LOC across all files** + the visible improvements (hitloc tag retokened, 8 new card-type accents, all 11 chat templates other than cluster 4+5 stuff now on v1.0.0).

---

## 5. Out of scope for cluster 3

- The 3 chat micro-cards (cluster 4): `XP-result.html`, `rollStats.html`, `itemDescription.html`
- The 10 generic dialogs (cluster 5): `templates/dialog/*.hbs`
- The 51 inline-HTML `ChatMessage.create({content:...})` callsites (out of P11 per c11-8)
- Legacy CSS file retirement (orphaning candidates only; deletion is P12 per c11-13)
- `quick-combat centre` class re-styling (P12 candidate — verify if dedicated CSS exists at code-time)
- The damage-type taxonomy alignment between data (`select-lists:getSorceryDamageTypeOptions`), CSS (`.elysium-damage-*`), and tokens (P12 per c1-9)

---

## 6. Open questions for user lock-in

1. **Cluster-1 partial extensions (c3-6 + c3-7)** — `chat-card-success-pip.hbs` gains an optional `healingAnnotation` param; `chat-card-participant-row.hbs`'s `flat-value` mode gains an optional `entry.flatValueLabel`. Both backward-compatible (cluster-2 callers don't pass them). Alternative: keep cluster-1 partials frozen and INLINE the variation in cluster-3 wrappers (like cluster-2 did). Recommendation: extend (small, additive, makes the partials genuinely reusable across clusters 3-5).

2. **Section D accent color choices (c3-4)** — proposed: NO=gold, RE/PP=purple, CM/QC=crimson (match CB), IM/DM=fire orange, AR=gold. Alternatives:
   - **(a)** As recommended.
   - **(b)** Make CM purple to distinguish it from CB (CB is the unresolved combat ROLL; CM is the resolved manoeuvre with hit-location); recommendation against because the post-resolution card visually inheriting the combat-roll color creates a coherent CB→CM accent story.
   - **(c)** No accent on the read-only card types (NO/RE/PP/AR) to differentiate "this card has no Phase D action" from "this card does"; recommendation against because the accent serves as card-type identifier, not action-availability indicator.
   Recommendation: (a).

3. **Hitloc tag retoken approach (c3-5)** — replace inline-style with `elysium-chat-chip--accent` (bonus-tinted) class composition. Alternative:
   - **(a)** As recommended (chip + chip--accent classes).
   - **(b)** Custom dedicated `.elysium-hitloc-tag` rule in `elysium-chat.css` rather than reusing the chip family (more idiomatic but more LOC).
   - **(c)** Defer retirement of the inline style to P12 (keeps c3 markup-minimal).
   Recommendation: (a) — the cluster-1 placeholder was reserved for exactly this.

4. **Roll-damage composition shape (c3-7)** — option B (inline a simple `<li>...</li>` row + composed tooltip-rows partial). Recommendation: option B. Alternative: option A (add a helper). Confirm.

5. **Cluster-3 to cluster-4 sequencing** — Cluster 4 is `XP-result.html`, `rollStats.html`, `itemDescription.html` — the small chat micro-cards. They have very different shapes (XP card is a "+1 XP" notification; rollStats shows opening-roll stats; itemDescription is a static-content card emitted by item-sheet helpers). They probably DON'T compose cluster-1 partials cleanly (no participants, no pip strips). Cluster 4 may be a "rebuild each as its own small template" effort. Confirm: ship cluster 3 first as alpha.47, then audit cluster 4?

---

## 7. Ready-to-go checklist (cluster 3 ships when all green)

- [ ] User confirms decisions c3-1 through c3-13
- [ ] User answers the 5 open questions in §6
- [ ] User accepts scope-cut list in §5
- [ ] User accepts smoke-risk mitigations in §3 (under each decision)

Once locked, cluster 3 coding begins.
