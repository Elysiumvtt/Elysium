import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

export class ElysiumMutationSheet extends ElysiumItemSheetV2 {
  constructor(options = {}) {
    super(options)
  }

  static DEFAULT_OPTIONS = {
    classes: ['mutation'],
    position: {
      width: 560,
      height: 640
    },
  }

  static PARTS = {
    header: { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template: 'systems/elysium/templates/item/mutation.detail.hbs',
      scrollable: ['']
    },
  }

  static TAB_ORDER = null

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    // v1.0.0-alpha.11 (side-finding #20): removed unregistered
    // 'elysium.mutationLabel' setting read; context.itemType falls back
    // to base sheet's i18n-driven 'TYPES.Item.mutation' label.
    context.catOptions = await ElysiumSelectLists.getMutationCatOptions();
    context.catName = game.i18n.localize("Elysium." + this.item.system.impact);
    context.skillCatOptions = await ElysiumSelectLists.getCategoryOptions();

    // Header chips per c2-2 lock — Impact category always; minor/major when owned.
    const chips = [{
      label: game.i18n.localize('Elysium.impact'),
      value: context.catName && context.catName !== ('Elysium.' + this.item.system.impact)
        ? context.catName
        : '—',
    }];
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.mutationStr'),
        value: this.item.system.minor
          ? game.i18n.localize('Elysium.minor')
          : game.i18n.localize('Elysium.major'),
      });
    }
    context.itemHeaderChips = chips;

    return context
  }

  _onRender(context, _options) {
  }
}
