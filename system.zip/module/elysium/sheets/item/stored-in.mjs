// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

export function injectStoredInSelector (html, item) {
    if (!item.parent) return    // unowned items have no containers to choose from

    const target = html.querySelector('.tab.details') ||
                   html.querySelector('.tab.description') ||
                   html.querySelector('.window-content')
    if (!target) return
    if (target.querySelector('.elysium-stored-in')) return

    // Only show containers on the same actor
    const containers = item.parent.items.filter(i =>
      i.id !== item.id &&
      i.type === 'gear' &&
      i.system?.elysium?.isContainer === true
    )

    // Hide the selector entirely if the actor has no containers — nothing
    // to choose from, no point showing an empty dropdown.
    if (containers.length === 0) return

    const currentContainer = item.system?.elysium?.containedIn || ''
    const opts = [`<option value="" ${!currentContainer ? 'selected' : ''}>— ${game.i18n.localize('Elysium.Gear.Loose') || 'Loose (not in a container)'} —</option>`]
      .concat(containers.map(c =>
        `<option value="${c.id}" ${currentContainer === c.id ? 'selected' : ''}>${c.name}</option>`
      ))
      .join('')

    const html_ = `
      <fieldset class="elysium-stored-in">
        <legend>${game.i18n.localize('Elysium.Gear.StoredIn') || 'Stored In'}</legend>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Gear.StoredInHint') || 'Place this item inside a container on the same actor (a backpack, pouch, etc.).'}">
            ${game.i18n.localize('Elysium.Gear.Container') || 'Container'}
          </label>
          <select name="system.elysium.containedIn">
            ${opts}
          </select>
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }
