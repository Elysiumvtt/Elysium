/**
 * Elysium Effect Grade Modifier — v0.14.0
 * ----------------------------------------
 * Ability effects (Aura's Resistance buff, Crippling Strike's debuffs,
 * Combat Stance's grade modifiers, etc.) shift target rolls by ±10% per
 * grade. This is DISTINCT from the Mythras difficulty grades (which use
 * multipliers ×3 / ×2 / ×1.5 / ×1 / ×0.5 / ×0.25 / ×0.1).
 *
 * The two systems stack:
 *   Mythras multiplier first  → modifies skill by × factor
 *   Elysium effect grades     → adds ±10% per grade additively after
 *
 * Effect grades are aggregated from all active sources on the actor (and
 * potentially the target, for opposed rolls). The rules module collects
 * applicable effects and converts them into a flatMod adjustment passed
 * to the system fork's roll system.
 *
 * Best-of-Same-Effect rule (v0.14.0):
 * Same-axis effects don't stack — the highest-magnitude source applies.
 * This module groups effects by axis (a string tag like 'resistance-buff'
 * or 'parry-grade') and returns only the best-of-each-axis value.
 */

const ELYSIUM_EFFECT_GRADE_PERCENT = 10  // ±10% per grade

/**
 * Aggregate all active grade modifiers on an actor into a flatMod offset.
 *
 * @param {Actor} actor - The rolling actor
 * @param {string} rollType - 'attack', 'defense', 'resistance', 'skill', etc.
 *   Used to filter which grade effects apply to this roll. Effects are
 *   tagged with rollTypes they affect.
 * @param {string|null} skillName - The specific skill being rolled, if any.
 *   Used for skill-specific effects (e.g. "+1 grade to Lore against Nemesis").
 * @returns {number} - The aggregated flatMod offset, in skill percentage points.
 */
export function aggregateEffectGrades(actor, rollType, skillName = null) {
  if (!actor) return 0

  // Collect grade modifiers from active abilities/effects on the actor.
  // Each modifier is { axis, grades, rollType, skillName?, condition? }
  // where:
  //   axis        — string tag for the Best-of-Same-Effect rule
  //   grades      — signed integer (+1 = +10%, -2 = -20%, etc.)
  //   rollType    — array of roll types this affects ['defense', 'resistance', etc.]
  //   skillName   — if set, only applies when rolling that specific skill
  //   condition   — function returning bool; only applies when condition is met
  const allMods = collectGradeModifiers(actor)

  // Filter to only those that match this roll
  const applicable = allMods.filter(mod => {
    if (mod.rollType && !mod.rollType.includes(rollType)) return false
    if (mod.skillName && mod.skillName !== skillName) return false
    if (mod.condition && !mod.condition(actor)) return false
    return true
  })

  // Group by axis, take best-of-each (Best-of-Same-Effect rule)
  const byAxis = new Map()
  for (const mod of applicable) {
    const axis = mod.axis || `${mod.rollType?.join(',') || 'general'}-${mod.grades > 0 ? 'buff' : 'debuff'}`
    const existing = byAxis.get(axis)
    // For positive grades, take the higher (best buff). For negative, take the lower (worst debuff).
    if (existing === undefined ||
        (mod.grades > 0 && mod.grades > existing) ||
        (mod.grades < 0 && mod.grades < existing)) {
      byAxis.set(axis, mod.grades)
    }
  }

  // Sum across axes (different axes DO stack with each other; only same-axis
  // effects use best-of)
  let totalGrades = 0
  for (const grades of byAxis.values()) {
    totalGrades += grades
  }

  return totalGrades * ELYSIUM_EFFECT_GRADE_PERCENT
}

/**
 * Walk an actor's active abilities/items and collect grade modifiers.
 *
 * For v0.14.0, this reads grade-modifier metadata from items with tagged
 * activation states. Future enhancements: status-effect-driven mods,
 * dynamically-active abilities (Aura, Combat Stance), etc.
 *
 * @param {Actor} actor
 * @returns {Array} - Array of grade modifier objects
 */
function collectGradeModifiers(actor) {
  const mods = []

  for (const item of actor.items) {
    // Items can declare grade modifiers in their elysium block:
    //   item.system.elysium.gradeModifiers = [
    //     { axis, grades, rollType, skillName?, condition? }
    //   ]
    const gms = item.system?.elysium?.gradeModifiers
    if (!Array.isArray(gms)) continue

    // Only collect if the item is in an active state (activation type matters):
    //   - passive abilities: always active
    //   - sustained abilities: only when activated (status flag set)
    //   - triggered abilities: only when triggered this round
    const activation = item.system?.elysium?.activation
    if (activation?.type === 'sustained' || activation?.type === 'triggered') {
      const isActive = actor.flags?.['elysium']?.activeAbilities?.[item.id]
      if (!isActive) continue
    }

    for (const gm of gms) {
      mods.push(gm)
    }
  }

  return mods
}

/**
 * Convenience wrapper: get the integer grade-difference applied to a roll.
 * Useful for display / chat-card output ("Aura +1 grade").
 */
export function getEffectGradeCount(actor, rollType, skillName = null) {
  return Math.round(aggregateEffectGrades(actor, rollType, skillName) / ELYSIUM_EFFECT_GRADE_PERCENT)
}
