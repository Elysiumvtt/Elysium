import { ElysiumActorDetails } from './actorDetails.mjs'
import { ElysiumUtilities } from './utilities.mjs'
export class ElysiumCharDev {

  //Toggle GM Devevlopment Phase off and on
  static async developmentPhase(toggle) {
    const state = await game.settings.get('elysium', 'development')
    await game.settings.set('elysium', 'development', !state)
    ui.notifications.info(
      state
        ? game.i18n.localize('Elysium.devPhaseOff')
        : game.i18n.localize('Elysium.devPhaseOn')
    )
    game.socket.emit('system.elysium', {
      type: 'updateChar'
    })
    ElysiumUtilities.updateCharSheets(true)
  }

  //Do XP improve for all items in actor
  static async onXPGainAll(actor, token, rollType) {
    const success = []
    let results = {}
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor);
    for (let i of partic.items) {
      if (i.system.improve) {
        results = await ElysiumCharDev.xpCheck(actor, token, i._id, rollType, false);
        success.push(results)
      }
      if (i.type === "persTrait") {
        if (i.system.oppimprove) {
          results = await ElysiumCharDev.xpCheck(actor, token, i._id, rollType, true);
          success.push(results)
        }
      }
    }
    await ElysiumCharDev.xpOutput(success, partic)
    return;
  }

  //Prep a single XP check
  static async onXPGainSingle(itemId, actor, token, rollType, opp) {
    const success = []
    let results = {}
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor);
    const item = partic.items.get(itemId)
    if (opp === 'false' && !item.system.improve) { return }
    if (opp === 'true' && !item.system.oppimprove) { return }
    results = await ElysiumCharDev.xpCheck(actor, token, itemId, rollType, opp);
    success.push(results)
    await ElysiumCharDev.xpOutput(success, partic)
    return;
  }

  //Make XP check and if appropriate calc/roll XP gain
  static async xpCheck(actor, token, itemId, type, opp) {
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor);
    let improvVal = 0
    const item = partic.items.get(itemId)
    let name = item.name
    let score = item.system.total
    //Exclude system.effects from the improvement score
    if (['skill', 'arcane', 'mysticism'].includes(item.type)) {
      score = score - item.system.effects
    }

    if (opp) {
      score = item.system.opptotal
      name = item.system.oppName
    }

    if (!opp && !item.system.improve) { return }
    if (opp && !item.system.oppimprove) { return }
    const result = await ElysiumCharDev.xpRoll(score, actor.system.xpBonus)
    if (result.level === 1) {
      if (type === 'fixed') {
        improvVal = game.settings.get('elysium', 'xpFixed')
      } else {
        const roll = new Roll(game.settings.get('elysium', 'xpFormula'))
        await roll.evaluate();
        improvVal = roll.total
        if (game.settings.get('elysium', 'xpRollDice') && game.modules.get('dice-so-nice')?.active) {
          game.dice3d.showForRoll(roll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
        }
      }
    }

    if (!opp) {
      await item.update({
        'system.improve': false,
        'system.xp': item.system.xp + improvVal
      })
    } else {
      await item.update({
        'system.oppimprove': false,
        'system.xp': item.system.xp - improvVal
      })

    }
    return ({
      name: name,
      level: result.level,
      diceRoll: result.diceRoll,
      rollResult: result.rollResult,
      score: score,
      improvVal,
    })
  }

  //XP Check Dice Roll & return success level
  static async xpRoll(target, bonus) {
    let resultLevel = 0
    const roll = new Roll('1D100')
    await roll.evaluate();
    target = Math.min(target, 100)
    if (Number(roll.total) + bonus > target) {
      resultLevel = 1
    }
    //If Game Settings and Dice So Nice then show dice roll
    if (game.settings.get('elysium', 'xpRollDice') && game.modules.get('dice-so-nice')?.active) {
      game.dice3d.showForRoll(roll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
    }

    return ({
      'level': resultLevel,
      'diceRoll': Number(roll.total) + bonus,
      'rollResult': Number(roll.total)
    })
  }

  //Get ready to produce the XP check Output
  static async xpOutput(success, partic) {
    const html = await ElysiumCharDev.xpChatCard(success, partic.name, partic.img);
    const msg = await ElysiumCharDev.showXPChat(html, partic)
  }

  //Prepare XP Roll Chat Card
  static async xpChatCard(success, actorName, actrImg) {
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: actorName }),
      actrImage: actrImg,
      success: success
    }
    const messageTemplate = 'systems/elysium/templates/chat/XP-result.html'
    const html = await foundry.applications.handlebars.renderTemplate(messageTemplate, messageData);
    return html;
  }

  // Display the XP chat card
  static async showXPChat(html, actor) {
    // F15 (rc.7): legacy `const chatType = CONST.CHAT_MESSAGE_STYLES.OTHER`
    // path retired — V14 ChatMessage.type expects a string ("base"/"ic"/"ooc"/
    // "emote"/"whisper"/"roll"). The legacy numeric constant (=0) fails V14
    // DataModelValidation. Dropping the `type` field entirely lets V14 use its
    // default ("base"), which is correct for XP-output chat cards. Latent
    // since V14 migration; F13 fix made the surrounding path reachable.
    const chatData = {
      user: game.user.id,
      content: html,
      speaker: {
        actor: actor._id,
        alias: actor.name,
      },
    }
    const msg = await ChatMessage.create(chatData);
    foundry.audio.AudioHelper.play({ src: CONFIG.sounds.dice }, true)
    return
  }

  //POW Improvement Check
  static async powImprov(actor, token, type) {
    const partic = await ElysiumActorDetails._getParticipantPriority(token, actor);
    const max = 21   //TODO - replace this with variable based on culture
    const score = partic.system.stats.pow.total
    const chance = (max - score) * 5
    let resultLevel = 0
    const roll = new Roll('1D100')
    let improvVal = 0
    await roll.evaluate();
    //If Game Settings and Dice So Nice then show dice roll
    if (game.settings.get('elysium', 'xpRollDice') && game.modules.get('dice-so-nice')?.active) {
      game.dice3d.showForRoll(roll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
    }

    if (roll.total <= chance) {
      resultLevel = 1
      if (type === "fixed") {
        improvVal = 1
      } else if (type != "fixed") {
        const impRoll = new Roll('1D3-1')
        await impRoll.evaluate()
        improvVal = impRoll.total
        //If Game Settings and Dice So Nice then show dice roll
        if (game.settings.get('elysium', 'xpRollDice') && game.modules.get('dice-so-nice')?.active) {
          game.dice3d.showForRoll(impRoll, game.user, true, null, false)  //Roll,user,sync,whispher,blind
        }
      }
    }
    const success = []
    success.push({
      name: game.i18n.localize('Elysium.StatsPowAbbr'),
      level: resultLevel,
      diceRoll: roll.total,
      rollResult: roll.total,
      score: chance,
      improvVal,
    })
    await ElysiumCharDev.xpOutput(success, partic)

    await partic.update({
      'system.stats.pow.exp': partic.system.stats.pow.exp + improvVal,
      'system.stats.pow.improve': false
    })
    return;
  }
}
