import { ElysiumActiveEffectSheet } from '../../sheets/elysium-active-effect-sheet.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Weapon item sheet — P10 cluster 5 / alpha.43 rewrite.
 *
 * Wide-tier (720×720) split into 5 logical section cards:
 *   1. Damage — dmg1/dmg2/dmg3 + range bands (reach + close/effective/long)
 *   2. Type & Skills — weaponType, damageBonus, skill1/skill2, attack/special
 *   3. Combat Profile — hands or crew, ap/hp, STR/DEX requirements,
 *      ammo + ROF (when isAmmo), malfunction, price, encumbrance,
 *      Mythras Size/Force/Melee, PP store, coverage (shields), radius (explosives)
 *   4. Damage Flags — 15 boolean toggles (acid/burst/choke/cold/constrict/disease/
 *      emp/entangle/explosive/fire/pierce/poison/sonic/stun/spclDmg) +
 *      parry toggle (the only non-damage-flag toggle here for grouping)
 *   5. Owner-only — actual ENC + status + hpCurr/ammoCurr + quantity (+ npcVal)
 *
 * Sheet-extension `injectWeaponFields` continues to attach engagement-info
 * + weapon HP + Wielded Modifiers fieldset into `.tab.details` post-render.
 *
 * Active-effects PART rendered separately (audit-5 lock preserved):
 * ElysiumActiveEffectSheet.activateListeners bound in _onRender; the
 * `active-effect-change-edit` legacy class hook flows through the
 * shared shell-effects partial.
 *
 * Header chips per c5-4: Weapon Type / Size / Reach / Damage.
 * 16 flag chips total (15 damage flags + parry). 15 use FLAT property
 * paths (`system.<flag>`) since they're not under `system.elysium`;
 * the alpha.42 itemToggle fix supports both flat and nested paths
 * via the optional `data-property-path` attribute.
 */
export class ElysiumWeaponSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['weapon'],
    position: { width: 720, height: 720 },  // wide tier per c5-4
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/weapon.detail.hbs',
      scrollable: [''],
    },
    effects:     { template: 'systems/elysium/templates/item/parts/item-shell-effects.hbs' },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'effects', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const sys = this.item.system

    // npcOwner used only when owning actor is NPC (different ENC ratio
    // for npcVal display). Preserved from legacy.
    context.npcOwner = !!(context.hasOwner && this.item.parent?.type === 'npc')

    // Option maps for selects
    context.priceOptions    = await ElysiumSelectLists.getPriceOptions()
    context.equippedOptions = await ElysiumSelectLists.getEquippedOptions(this.document.type)
    context.weaponOptions   = await ElysiumSelectLists.getWpnCategoryOptions()
    context.damOptions      = await ElysiumSelectLists.getDamBonusOptions()
    context.specialOptions  = await ElysiumSelectLists.getSpecialOptions()
    context.handedOptions   = await ElysiumSelectLists.getHandedOptions()
    context.wpnSkillOptions1 = await ElysiumSelectLists.getWeaponSkillOptions('1')
    context.wpnSkillOptions2 = await ElysiumSelectLists.getWeaponSkillOptions(sys.skill1)

    // Mythras Size / Reach / Force scales (from CONFIG.ELYSIUM with safe defaults)
    const cfg = CONFIG?.ELYSIUM || {}
    const DEFAULT_SIZES = { T: 'Tiny', S: 'Small', M: 'Medium', L: 'Large', H: 'Huge', E: 'Enormous' }
    const DEFAULT_REACHES = { T: 'Touch', S: 'Short', M: 'Medium', L: 'Long', VL: 'Very Long', H: 'Huge' }
    context.elysiumSizeOptions  = cfg.WEAPON_SIZES   || DEFAULT_SIZES
    context.elysiumReachOptions = cfg.WEAPON_REACHES || DEFAULT_REACHES
    context.elysiumForceOptions = cfg.WEAPON_SIZES   || DEFAULT_SIZES  // Force uses Size tier scale

    // Display names for readonly mode
    context.priceName     = game.i18n.localize('Elysium.' + sys.price)
    context.equippedName  = game.i18n.localize('Elysium.' + sys.equipStatus)
    context.weaponCatName = game.i18n.localize('Elysium.' + sys.weaponType)
    context.damName       = game.i18n.localize('Elysium.' + sys.db)
    context.handedName    = game.i18n.localize('Elysium.' + sys.hands)
    context.specName      = game.i18n.localize('Elysium.' + sys.special)

    // Skill name resolution via elysiumid lookup
    if (sys.skill1 === 'none') {
      context.skill1Name = game.i18n.localize('Elysium.none')
    } else {
      const skill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: sys.skill1 }))[0]
      context.skill1Name = skill ? skill.name : ''
    }
    if (sys.skill2 === 'none') {
      context.skill2Name = game.i18n.localize('Elysium.none')
    } else {
      const skill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: sys.skill2 }))[0]
      context.skill2Name = skill ? skill.name : ''
    }

    // isAmmo flag — gates ROF + ammo type/capacity UI
    context.isAmmo = ['firearm', 'energy', 'artillery', 'missile', 'heavy'].includes(sys.weaponType)

    // Active-effects context (audit-5 lock)
    context.effects = ElysiumActiveEffectSheet.getItemEffectsFromSheet(this.document)
    const changesActiveEffects = ElysiumActiveEffectSheet.getEffectChangesFromSheet(this.document)
    context.effectKeys = changesActiveEffects.effectKeys
    context.effectChanges = changesActiveEffects.effectChanges

    // Header chips per c5-4 (4 chips)
    context.itemHeaderChips = [
      {
        label: game.i18n.localize('Elysium.weaponType'),
        value: context.weaponCatName || '—',
      },
      {
        label: game.i18n.localize('Elysium.size'),
        value: context.elysiumSizeOptions[sys.elysium.weaponSize] || sys.elysium.weaponSize,
      },
      {
        label: game.i18n.localize('Elysium.reach'),
        value: context.elysiumReachOptions[sys.elysium.reach] || sys.elysium.reach,
      },
      {
        label: game.i18n.localize('Elysium.damage'),
        value: sys.dmg1 || '—',
      },
    ]

    // Flag chips per c5-5 (16 chips: parry + 15 damage types).
    // All use FLAT property paths (system.<flag>) since these are
    // top-level booleans, not under system.elysium. The alpha.42
    // itemToggle fix accepts both flat and nested paths.
    const flagDefs = [
      ['parry',     'Elysium.parry',     'Elysium.parryHint'],
      ['acid',      'Elysium.acid',      null],
      ['burst',     'Elysium.burst',     null],
      ['choke',     'Elysium.choke',     null],
      ['cold',      'Elysium.cold',      null],
      ['constrict', 'Elysium.constrict', null],
      ['disease',   'Elysium.disease',   null],
      ['emp',       'Elysium.emp',       null],
      ['entangle',  'Elysium.entangle',  null],
      ['explosive', 'Elysium.explosive', null],
      ['fire',      'Elysium.fire',      null],
      ['pierce',    'Elysium.pierce',    null],
      ['poison',    'Elysium.poison',    null],
      ['sonic',     'Elysium.sonic',     null],
      ['stun',      'Elysium.stun',      null],
      ['spclDmg',   'Elysium.special',   null],
    ]
    context.flagChips = flagDefs.map(([prop, labelKey, tipKey]) => ({
      property:     prop,
      propertyPath: `system.${prop}`,
      active:       !!sys[prop],
      label:        game.i18n.localize(labelKey),
      tooltip:      tipKey ? game.i18n.localize(tipKey) : null,
    }))

    // isMelee chip lives separately because it's under system.elysium
    // and is more of a "default attack mode" property than a damage flag.
    // Kept inline in the detail template as a single chip via toggle row.
    context.meleeChip = [{
      property:     'isMelee',
      propertyPath: 'system.elysium.isMelee',
      active:       !!sys.elysium.isMelee,
      label:        game.i18n.localize('Elysium.melee'),
      tooltip:      game.i18n.localize('Elysium.meleeWeaponHint'),
    }]

    return context
  }

  /** Active-effects listener wiring (audit-5 lock from cluster 3a). */
  _onRender(context, _options) {
    ElysiumActiveEffectSheet.activateListeners(this)
  }
}
