/**
 * PersTraitDataModel — schema for items of type 'persTrait'.
 *
 * Per P6.2 spec. Stored-schema-only. No compendium content. Matches
 * template.json exactly.
 *
 * Personality traits have a "two-sided" structure: each trait has an
 * opposite (`oppName`) with its own improve flag (`oppimprove`). The
 * `basic` flag marks pre-defined/baseline personality traits.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class PersTraitDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      oppName:     new fields.StringField({ initial: '' }),
      base:        new fields.NumberField({ integer: true, initial: 0 }),
      improve:     new fields.BooleanField({ initial: false }),
      oppimprove:  new fields.BooleanField({ initial: false }),
      xp:          new fields.NumberField({ integer: true, initial: 0 }),
      basic:       new fields.BooleanField({ initial: false }),
    }
  }
}
