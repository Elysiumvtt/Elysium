/**
 * ReputationDataModel — schema for items of type 'reputation'.
 *
 * Reputation items hold a single numeric reputation score for a faction
 * or social group. Smallest item type in the system.
 *
 * Per P6 design: STORED-SCHEMA-ONLY. Uses the shared makeItemBase() for
 * description/gmDescription.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class ReputationDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      base: new fields.NumberField({ integer: true, initial: 0 }),
    }
  }
}
