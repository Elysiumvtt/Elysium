# P12 cluster 3 prep audit — lang completion + behavioural acceptance

**Status**: PENDING
**Target alpha**: alpha.53
**Scope**: Two distinct items per the P12 prep audit's D1 Option B and the cluster-2 audit's c2-Q1 closure:
1. **Lang completion**: address the es / fr translation gaps that have accumulated across P5-P12 (P11 cluster 5 widened the gap by 1 with a latent-bug fix; cluster 2 widened it by 86 c2 stubs). c3 closes as much of this as is feasible without compromising quality.
2. **Behavioural acceptance testing**: live-verify the v1.0.0 surface against alpha.52 to catch any regressions before v1.0.0-rc.1. P5-P12 has shipped 48 cumulative alphas; testing has been per-cluster smoke + post-install live-verify, but no cumulative end-to-end pass.

**Inheritance from**: P12 prep audit D1 sequencing; P11 cluster 5 audit (the flatModHint latent-bug-fix that widened the gap by 1); P12 c2 audit Q1 (the 86 Chat.* stubs awaiting c3 sweep).

---

## 1. Live measurement at alpha.52 baseline

### 1.1 Lang gap structure — actual numbers

Earlier ship documentation said "es-gap=206, fr-gap=206". That's the **structural gap** (keys missing from es/fr that exist in en). It is accurate but it isn't the whole picture. **Live measurement at alpha.52 reveals the full picture**:

| Metric | es | fr |
|---|---|---|
| Total en keys | 1346 | 1346 |
| Keys present in target lang | 1144 | 1144 |
| **Structural gap (key missing)** | **206** | **206** |
| **Stub gap (key present, byte-equal to en)** | **167** | **223** |
| **Total strings to handle** | **373** | **429** |

The stub gap is hidden — the keys exist in the lang files but contain English text, so Foundry's i18n system reports them as "translated" while in practice the user sees English. This kind of stub-gap accumulates from:
- The 86 c2 stubs added in alpha.52 (Elysium.Chat.*)
- Earlier ships that added en keys + matching stub-English entries to es/fr to maintain structural parity
- 21 `Elysium.ChaosiumCanvasInterface.*Hint` keys are **empty strings in en** — they're hint placeholders the en file doesn't fill either. These should NOT be translated.

### 1.2 Stub-gap breakdown — what actually needs translation

| Stub category | es count | Translation strategy |
|---|---|---|
| `Elysium.Chat.*` (c2 new) | 86 | Translate. Mechanical + prose mix. |
| `TYPES.Actor.*` + `TYPES.Item.*` | 24 | Translate. Item type labels. |
| `Elysium.ChaosiumCanvasInterface.*Hint` (empty strings in en) | 21 | **No translation needed** — empty strings parity-match. |
| `Elysium.ElysiumIDFlag.*` | 3 | Translate. Short technical labels. |
| Stat abbreviations (`StatsConAbbr`=CON, `StatsIntAbbr`=INT, etc.) | ~6 | Convention: leave as-is in es/fr (mechanical abbreviations are universal). |
| Other (Item.*, abdomen, base, etc.) | ~27 | Mixed — review per key. |

**Actual translation work for es**: 86 + 24 + 3 + ~20 = **~133 stub strings**, plus 206 missing keys = **~340 strings of meaningful translation work**.

**For fr**: 223 stubs follows the same pattern but adds ~56 stubs from earlier ships that drifted from es parity (fr-specific stub accumulation). Total fr translation work: **~395 strings**.

### 1.3 Missing-key namespace distribution

The 206 missing keys cluster around recent feature additions:

| Namespace | es missing |
|---|---|
| Elysium.Fatigue | 24 |
| Elysium.Settings | 22 |
| Elysium.Ancestry | 17 |
| Elysium.Stats | 15 |
| Elysium.Gear | 11 |
| Elysium.Luck | 11 |
| Elysium.Arcane | 10 |
| Elysium.Magic | 9 |
| Elysium.Armor | 8 |
| Elysium.Skill | 8 |
| Elysium.Ability | 6 |
| Elysium.Modifiers | 6 |
| Elysium.Critical | 5 |
| Elysium.Divine | 5 |
| Elysium.Weapon | 5 |
| Other (Bonus, Body, Combat, etc.) | ~54 |

This maps to the Elysium-specific mechanical surfaces added between P5 and P12. Most of these are short labels (≤3 words, 140 of 206) — buttons, tooltips, headers. Only 14 keys are prose (16+ words) and need genuine localization care.

### 1.4 Missing-key length breakdown

| Length category | es count | Translation difficulty |
|---|---|---|
| Short (≤3 words: labels, button text) | 140 | Trivial — high machine-translation quality |
| Medium (4-15 words: tooltips, short hints) | 52 | Tractable — needs game-context care |
| Long (16+ words: prose explanations, warnings) | 14 | Hard — needs human review |

The short-+-medium category (192 strings) is well-suited to machine translation with a domain glossary; the long category (14 strings) merits flagging for human review or careful prompted translation.

---

## 2. Behavioural acceptance surface

### 2.1 Cumulative v1.0.0 surface

P5 through P12 has shipped 48 alphas. The cumulative v1.0.0 surface needs end-to-end verification before any v1.0.0-rc.1 candidate. Per-cluster smoke + post-install live-verify ran during each ship, but a **cumulative acceptance pass** hasn't run. The risk of cumulative regression is real:
- Cluster-1 retired 62 legacy.css rules (potential silent visual regressions if any consumer was missed)
- Cluster-2 migrated 45 ChatMessage.create callsites — JS hook integrity verified per-callsite, but not all 45 paths have been triggered live yet
- Multiple alphas modified hook patches and event delegation
- Some i18n keys are referenced at runtime via dynamic concatenation (`Elysium.advSkillCat.${slot}`) — never lint-checkable

### 2.2 Acceptance test categories (16)

1. **Sheet rendering — actor surface**: character + NPC sheets load without console error at all viewport sizes; alpha.50 scroll fix intact; FA icons render via FA7 Pro font (alpha.50 fix); tab navigation works.

2. **Sheet rendering — item surface**: all 23 item types open in their respective sheets without console error: `gear`, `skill`, `hit-location`, `personality`, `career`, `arcane`, `divine`, `mysticism`, `mutation`, `sorcery`, `super`, `failing`, `powerMod`, `armor`, `weapon`, `wound`, `allegiance`, `passion`, `ability`, `persTrait`, `reputation`, `skillcat`, `culture`.

3. **CRUD**: create/read/update/delete on both actor types and all 23 item types; data-handle-change retirement doesn't break form-data submission (alpha.51 verification).

4. **Chat-card surface**: every cluster-1-5 chat-card type renders correctly: combat-roll, opposed-roll, group-roll, cooperative, NO/RE/PP, CM/IM/DM, AR/QC, XP-result, rollStats, itemDescription.

5. **Cluster-2 partial surface**: every Archetype A/B/C partial renders via live game action: notice (sustain/fatigue/pow-loss/weaponWear/armorWear/etc.), roll (criticalCard/statImprove/learn/etc.), prompt (charge/changeRange/knockback).

6. **Dialog surface**: all 10 generic dialogs from P11 cluster 5 render and dispatch correctly: selectPower, getValue, hitLocChoice, npcTokenCreate, selectItem, skillSelect, newWound, treatWound, damageDiff, difficulty.

7. **Combat mechanics — engagement**: engagement establish + change-range + engagement-warning display + outmanoeuvre flow + held-at-bay / encroached state detection.

8. **Combat mechanics — charge + knockback**: charge prompt fires → defender response button → resolveCharge → knockback dialog → resolveKnockback. All 3 D6-locked attribute family hooks (`data-elysium-charge-action`, `-kb-action`) read correctly.

9. **Casting — arcane**: cast spell → SL accumulation → success/fumble outcomes; spell learning roll with success/fail/fumble paths.

10. **Casting — divine + mysticism + sorcery**: POW sacrifice on divine cast posts pow-loss notice; mysticism cast; sorcery damage with target/no-target paths.

11. **Stat improvement**: improve roll with success/fail/auto-improve paths; cap-override prompt + GM approval; EXP dice prompt + GM approval. All `.elysium-cap-btn` class hooks read by chat-card.mjs:wireCapOverrideButtons fire correctly.

12. **Stat advance (creation)**: gambleStatIncrease + guaranteedStatIncrease both post their respective chat cards via the migrated chat-card-roll / chat-card-notice partials.

13. **Wear / wound**: armor wear (major wound + attack crit) + weapon wear (fumble + crit-parry) + temp HP absorption + ongoing damage. All posts via migrated chat-card-notice partials.

14. **Critical system + luck**: critical-roll → critical-card; luck save dialog → spending luck posts notice card; permanent / ongoing flag visibility.

15. **Fatigue**: setLevel → fatigue-update notice via refactored `_formatChat` helper (D5 of c2 audit); effortRoll → fatigue-roll card; recovery via decrement; mythras-skillgrade / AP-penalty / move-penalty / initiative-pen visible.

16. **Passive defense**: covering stance toggle + chat notice; passive block application notice; ward dialog + ward-applied notice.

### 2.3 Visual/CSS acceptance

Beyond functional tests:
- alpha.50 sheet-scroll fix intact (window-content `overflow-y: auto`)
- alpha.50 FA icon fix intact (sheet header icons render in FA7 Pro)
- alpha.51 `--ely-overlay-subtle` token resolves correctly
- alpha.51 brace-badge `.elysium-brace-badge { margin-left: var(--ely-space-1); color: var(--ely-accent-info); }` cascades
- alpha.52 8 variant accent rules cascade (action / danger / success / info / bonus / bonus-dark / fire / mind)
- Dark-bone-crimson design identity intact across sheets
- All 62 retired legacy classes (alpha.51) absent from live DOM on representative sheets

### 2.4 i18n acceptance

- Every Elysium.* key referenced from module/.mjs resolves in en.json
- Spot-check: switch world language to es, render sheet, verify no `Elysium.X.Y` raw-string fallbacks (acceptable: en string falling through where es is empty-equal-to-en stub)
- Same for fr
- The dynamic-key cases (`Elysium.advSkillCat.${slot}`, `Elysium.careerTier.*`, `Elysium.wealthLevel.*`, `Elysium.resultLevel.*`) all resolve at runtime to defined keys

---

## 3. Findings

### F1 — Translation gap is ~2× what the bare "gap=206" number suggests

Per §1.1: structural gap of 206 is accurate but the stub gap of 167-223 (visible-to-user English-where-translation-expected) brings total per-lang work to 373-429 strings. The earlier ships' choice to add English stubs rather than skip-the-keys preserved structural parity (Foundry doesn't warn about empty/missing keys), but accumulated hidden translation debt.

c3 has two honest framings:
- **"Close the structural gap only"**: address the 206 missing keys, leave stubs as-is (since they at least render in English rather than as raw key strings). Smaller scope; user-visible improvement modest.
- **"Close the meaningful translation surface"**: address structural gap + the ~133-167 stubs that genuinely should be translated. Larger scope; meaningfully better UX for es/fr users.

### F2 — Machine translation has limits for TTRPG terminology

Game-mechanics terminology has nuance machine translation handles poorly:
- "Fatigue level" in MMO context vs "Fatigue" in Mythras has subtly different connotations
- "Skill grade" is a Mythras-specific term with mechanical meaning
- "Endurance roll" / "Willpower save" map to specific game-mechanics nouns in fr/es TTRPG communities
- Cards-as-UI labels ("Resisted (kept reach)", "Allowed (reach changes)") need short translations that fit button widths

**A domain-glossary-driven translation pass** can do better than naive machine translation. Even better: a single-shot translation prompt that fronts the glossary and provides bulk strings. This is well-suited to using Claude itself via the API for translation, with structured input/output.

### F3 — Acceptance testing has been per-cluster, not cumulative

48 cumulative alphas across P5-P12. Each ship had per-cluster smoke + live-verify, but the cumulative surface has never been end-to-end exercised in one pass. The risk of accumulated regression is real but bounded — each per-cluster verify caught what it could see, but cross-feature interactions (e.g., does the cluster-2 charge-prompt still trigger correctly after cluster-1 retired 62 legacy CSS rules?) haven't been verified.

### F4 — Some stubs are PROPERLY left as-is in es/fr

Several stub-gap entries are conventionally NOT translated:
- `StatsConAbbr` = "CON" — stat abbreviations are universal in TTRPGs (Spanish/French Mythras editions use "CON" too)
- `Elysium.ElysiumIDFlag.id` = "BRPID" — technical identifier label, universal
- 21 `ChaosiumCanvasInterface.*Hint` keys are empty strings in en — empty parity-match is correct, no translation needed
- `TYPES.Actor.character` = "Character" — debatable; some es localizations use "Personaje" (translate), some keep "Character"

These need a per-key judgment, not blind machine translation. Total stub-keep entries: ~21 empty + ~6 abbrev = **~27 entries that legitimately stay English-equal in es/fr**.

### F5 — Acceptance testing depth varies by category

Some categories (sheet rendering, CRUD) are trivially testable via test-world automation. Others (combat mechanics, casting flow) require multi-step interactions that are tedious to automate. A pragmatic split:
- **Auto-testable** (~10 categories): sheet rendering, item-type CRUD, chat-card render, partial render, visual/CSS, i18n key resolution. Drive via Chrome bridge + js_tool.
- **Manual verification** (~6 categories): full combat flow, full casting flow, full stat improvement flow, multi-actor interactions. These need a human to play through a scenario and confirm.

### F6 — There is no existing acceptance test fixture suite

The project has no `test/` fixtures for behavioural acceptance, just for visual baselines (`test/baselines/`). A simple text-based acceptance checklist that a human (or Claude via bridge) can execute step-by-step is what c3 needs — not a formal test framework.

### F7 — Adding 86 Chat.* stubs widened the visible-stub gap

Per c2 audit Q1, c2 deliberately added English stubs to es/fr for the 86 new Chat.* keys, with c3 picking up the translation. This is now c3's job. The stubs are mechanically present so user-visible es/fr UX during the c2 → c3 interval is "shows English" rather than "shows raw key string". That's the better failure mode but it IS visible English to es/fr users for the alpha.52 → alpha.53 interval.

---

## 4. Cluster-3 options

### Option A — Lang only, full sweep

Translate the full surface (340 strings es + 395 strings fr) using a Claude-API-driven translation pass with a domain glossary. Defer acceptance testing to a c3b or post-rc.1 follow-up.

**Pros**: tractable scope; one focused deliverable; clears the lang debt cleanly.
**Cons**: defers the cumulative acceptance pass, which is genuinely needed before rc.1. Doesn't surface any latent regressions.

### Option B — Acceptance only

Run the cumulative acceptance pass against alpha.52; document findings; defer lang completion to a c3b or post-rc.1.

**Pros**: surfaces cumulative regressions before rc.1; smaller diff (mostly documentation + bug fixes if regressions surface).
**Cons**: leaves the lang debt unaddressed; es/fr users still see English on 373/429 strings; we lose c3 as the lang-completion checkpoint.

### Option C — Bothlang + acceptance, structural gap only (RECOMMENDED)

Address the structural gap (206 missing keys) with high-quality translation via Claude-API + domain glossary. Leave the 167-223 stub gap for c3b / a future cluster. Run the cumulative acceptance pass concurrently — the lang completion and acceptance work don't conflict.

**Pros**: meaningful lang improvement (closes structural gap, fixes the "key not found" risk for the 206 missing); acceptance pass surfaces any regressions; tractable scope.
**Cons**: doesn't close the full lang surface — stub gap (167-223 strings) remains.

### Option D — Both, complete

Address structural + stub gaps + run acceptance pass. ~340 strings × 2 langs translated + full acceptance + any bug fixes from acceptance findings.

**Pros**: closes the entire P12 surface in one ship; if no regressions surface, c3 closes P12 and v1.0.0-rc.1 follows immediately.
**Cons**: large ship; translation quality risk multiplied; if acceptance surfaces bugs, ship has to absorb them too.

---

## 5. Decisions (lockable now)

### D1 — Sub-cluster scope: Option C

Recommended. Close the **structural gap** (206 missing keys × 2 langs = 412 strings) with high-quality translation. Run the **cumulative acceptance pass** concurrently. Leave the 167-223 stub gap for a future ship (could be c3b or absorbed into rc.1 polish). Acceptance findings either route to in-cluster bug fixes (small) or get flagged as separate alpha targets (large).

### D2 — Translation methodology: Claude-API + domain glossary

Use the Anthropic API directly from a translation script. Submit batches of 20-30 strings at a time with:
- A system-prompt-equivalent fronting a domain glossary (key Mythras / Elysium / BRP terms with their established es/fr conventions)
- Bulk input as a list of (key, en_string) tuples
- Structured output as a JSON array
- Per-batch human-review checkpoint where the script writes a `pending-translations-{lang}.json` file that a human (or Claude itself reviewing) can audit before committing to lang/{lang}.json

Empty-string keys (21 ChaosiumCanvasInterface.*Hint) and convention-keep keys (stat abbrev) get auto-skipped from translation by the script.

### D3 — Domain glossary location

Build the glossary as `docs/i18n-glossary-es.md` and `docs/i18n-glossary-fr.md`. Maintain in version control; the translation script reads from these. ~50 key terms × 2 langs ~= 100 mappings.

### D4 — Acceptance test fixture: a markdown checklist

Single `docs/v1.0.0-acceptance-checklist.md` file. 16 categories × ~3-8 test points each = ~80-120 individual checks. Each check is human-runnable in the test world via UI interaction, with the expected outcome stated. The author of the checklist (this cluster) checks each item via Chrome bridge OR documents how a human would verify if bridge automation isn't tractable for that check.

### D5 — Translation script lives in a new docs/ file, not in module/

The translation script is a one-shot utility, not a system feature. It lives in `docs/c3-translation-script.md` as a runnable code block + inputs. It's NOT shipped in system.zip (per cluster norm — audit + script docs stay out of the system distribution).

### D6 — Stub gap handling

Per D1: deferred. Document the 167-223 stub gap in CHANGELOG and ROADMAP as known limitation for alpha.53 → v1.0.0-rc.1. If c3 finishes early or rc.1 polish reveals capacity, sweep then.

---

## 6. Open questions

### Q1 (blocking) — Option C lock?

Per D1: yes, recommended. Override paths: `proceed with option A` (lang-only, defer acceptance), `proceed with option B` (acceptance-only, defer lang), `proceed with option D` (do everything, larger scope risk).

### Q2 (blocking) — Translation depth: structural gap only, or also TYPES + Chat stubs?

Per D1: structural only in c3. The 86 Chat.* stubs from c2 are the strongest candidate to fold in (they're recent + high-quality-needed); the 24 TYPES stubs are debatable; the 27 "other" stubs need per-key judgment.

Override paths:
- `proceed +chat` — fold in the 86 Chat.* stubs (gap → 292 strings × 2 langs)
- `proceed +chat+types` — fold in TYPES too (~316 × 2)
- `proceed full sweep` — Option D

### Q3 (non-blocking) — Translation quality safeguard

A second-pass quality check by Claude reviewing its own translations against the glossary. Adds ~10% overhead, reduces error rate meaningfully. Recommended.

### Q4 (non-blocking) — Per-cluster acceptance, or single-pass cumulative?

Cumulative single-pass is what's needed before rc.1 — running the 16-category checklist once against alpha.52's full surface. Per-cluster passes already ran during each ship.

### Q5 (non-blocking) — Acceptance findings routing

If acceptance surfaces:
- **CSS-only bugs**: hotfix in-cluster (alpha.53 absorbs)
- **JS bugs (small)**: hotfix in-cluster
- **JS bugs (large)**: flag for alpha.54 (next cluster)
- **Architectural issues**: defer to v1.1.0 with documented finding

### Q6 (non-blocking) — Domain glossary scope

Recommended terms in glossary:
- BRP mechanical terms: skill, characteristic, hit location, armor points, hit points, MP/PP/power points, EXP dice
- Mythras-specific: action points, reach, encroached, held at bay, sustain, ward, brace, charge, knockback
- Roll outcomes: critical success, success, special, failure, fumble
- Stats: STR/CON/SIZ/INT/POW/DEX/CHA/EDU (preserve abbreviations)
- Elysium-specific: stat-improvement, fatigue level labels (Fresh / Winded / Tired / Weary / Exhausted / Spent / Collapsed), tier names

~50 terms total; finalize at code time.

### Q7 (non-blocking) — Acceptance pass output format

`docs/v1.0.0-acceptance-results.md` is generated at end of cluster, with per-check pass/fail status + screenshot links (if visual) + any findings logged.

---

## 7. Recommendation

Lock c3 scope per D1-D6:

- **D1 Option C**: structural lang gap (206 × 2 = 412 strings) + cumulative acceptance pass
- **D2 Claude-API translation with domain glossary**, per-batch review checkpoint
- **D3** Glossary files in `docs/i18n-glossary-{es,fr}.md`
- **D4** Acceptance checklist in `docs/v1.0.0-acceptance-checklist.md` (markdown, human-runnable, ~80-120 checks across 16 categories)
- **D5** Translation script lives in `docs/c3-translation-script.md` (not shipped)
- **D6** Stub gap (167-223 strings) deferred to c3b or rc.1 polish

**Estimated c3 ship contents**:
- `lang/es.json`: +206 new keys translated
- `lang/fr.json`: +206 new keys translated
- `docs/i18n-glossary-es.md`: new ~50-term glossary
- `docs/i18n-glossary-fr.md`: new ~50-term glossary
- `docs/c3-translation-script.md`: new script + harness
- `docs/v1.0.0-acceptance-checklist.md`: new ~80-120 check items
- `docs/v1.0.0-acceptance-results.md`: filled in during cluster execution
- Any bug fixes surfaced during acceptance (size unknown until run)
- system.json version bump
- CHANGELOG entry
- ROADMAP execution log + tracker update

**Risk assessment**: medium. The acceptance pass might surface latent regressions; the translation pass might produce uneven quality on long-prose entries. Both risks are bounded — acceptance issues route per Q5, translation issues flag for manual review.

**Net diff estimate**:
- Translation: +5-10 KB to es.json + fr.json
- Docs (5 new): +30-50 KB
- Bug fixes: 0-N LOC (unknown)
- Overall structural diff to the system is small

---

## 8. Cluster-3 lock list additions (post-ship)

- No new audit-5 class-hook locks expected (c3 is lang + testing; not surface migration)
- The acceptance checklist itself becomes the canonical pre-rc.1 verification document

---

## 9. Cross-references

- `docs/p12-prep-audit.md`: D1 c3 sequencing (3rd cluster of 4)
- `docs/p12-c2-audit.md`: Q1 lock on Chat.* stubs deferred to c3
- `docs/p11-cluster5-audit.md`: latent flatModHint bug-fix widened the gap by 1
- `lang/en.json`: 1346-key source of truth
- `lang/es.json`, `lang/fr.json`: 1144-key target files

---

## 10. Pre-decision checklist

Before responding `proceed with recommended`:

- [ ] Confirm the lang gap is structurally 206 + stub 167-223, not just 206
- [ ] Accept D1 Option C: structural gap + acceptance pass (not full stub sweep)
- [ ] Accept D2 Claude-API translation methodology (vs. external translation service or manual)
- [ ] Accept D3 glossary files
- [ ] Accept D4 acceptance checklist as a markdown doc (not a test framework)
- [ ] Accept D5 translation script as a docs/ utility (not shipped)
- [ ] Accept D6 stub gap deferred

If overriding: `proceed with option A` / `B` / `D` / `proceed +chat` / `proceed +chat+types` / etc.

---

## 11. Phase-plan position

c3 is the **second-to-last** cluster of P12. After c3 ships:
- **c4 (alpha.54)**: F1 130-rgba scoping audit + retoken sweep (the deferred cluster-1 discovery)
- **After c4**: P12 closes. Move to v1.0.0-rc.1.

If c3 surfaces blocking regressions, the ship sequence may need to insert a hotfix alpha before c4 — depending on severity.

The cumulative acceptance pass in c3 is the critical pre-rc.1 verification step. If it comes back clean, v1.0.0 is on a 2-cluster runway. If it surfaces issues, those issues drive the rest of P12 scope.
