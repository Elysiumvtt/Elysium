/**
 * AbilityDataModel — schema for items of type 'ability'.
 *
 * Per P6.2 spec. Stored-schema-only. 47 compendium items in abilities.db.
 *
 * COMPENDIUM-DRIVEN FIELD: `elysium.arcaneParent` is NOT in template.json
 * but is present on compendium items (used to reference an arcane
 * parent spell/school). Schema MUST declare it or compendium drops will
 * fail strict validation. Same pattern as expDiceOverride from P5.2.
 *
 * DROPPED FIELDS: template.json's `elysium.activation._doc` and
 * `elysium._addOnSchema_doc` are documentation-only strings — not real
 * fields. Schema does not declare them; cleanData drops any stored values.
 *
 * String enums (abilityType, category, theme, activation.type) left free
 * per audit — content-extensibility risk too high for choices lock.
 */

import { makeItemBase, makeThemedBundle } from './_shared.mjs'

const fields = foundry.data.fields

export class AbilityDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      base:               new fields.NumberField({ integer: true, initial: 0 }),
      xp:                 new fields.NumberField({ integer: true, initial: 0 }),
      improve:            new fields.BooleanField({ initial: false }),
      noXP:               new fields.BooleanField({ initial: false }),
      effectText:         new fields.HTMLField({ initial: '' }),
      prerequisitesText:  new fields.HTMLField({ initial: '' }),
      elysium: new fields.SchemaField({
        abilityType:   new fields.StringField({ initial: 'static' }),
        category:      new fields.StringField({ initial: 'general' }),
        theme:         new fields.StringField({ initial: '' }),
        // arcaneParent: NOT in template.json — required by compendium items
        // that link an ability to an arcane parent. Strict validation
        // would reject these writes without this declaration.
        arcaneParent:  new fields.StringField({ initial: '' }),
        // Themed-bundle fields shared with MysticismDataModel (P6.4):
        // activation, benefits, drawbacks, addOns. Factored to _shared.mjs
        // after P6.4 audit found bit-identical shape across the two types.
        ...makeThemedBundle(),
        // _doc field inside activation DROPPED — template-only documentation string.
        // _addOnSchema_doc DROPPED — template-only documentation string.
      }),
    }
  }
}
