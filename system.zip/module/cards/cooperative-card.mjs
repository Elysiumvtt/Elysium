import { ElysiumCheck } from '../apps/check.mjs'
import { OPCard } from './opposed-card.mjs'
export class COCard {

  //Resolve a cooperative card - roll dice, update and close
  static async COResolve(config) {
    const targetMsg = await game.messages.get(config.targetChatId)
    let card = ""
    const chatCards = targetMsg.flags.elysium.chatCard
    if (chatCards.length < 2) {
      ui.notifications.warn(game.i18n.localize('Elysium.resolveMore'))
      return
    }

    let maxRes = -99
    let minRes = 99
    for (let i = 1; i < chatCards.length; i++) {
      card = chatCards[i]
      maxRes = Math.max(maxRes, card.resultLevel)
      minRes = Math.min(minRes, card.resultLevel)
    }
    let adjVal = 0
    if (minRes === 0) { adjVal = -50 }
    else if (maxRes === 1) { adjVal = -10 }
    else if (maxRes === 2) { adjVal = 20 }
    else if (maxRes === 3) { adjVal = 30 }
    else if (maxRes === 4) { adjVal = 50 }
    card = chatCards[0]
    card.flatMod = card.flatMod + adjVal
    card.targetScore = card.targetScore + adjVal
    const newConfig = {
      rollFormula: "1D100",
      targetScore: card.targetScore
    }
    await ElysiumCheck.makeRoll(newConfig)

    card.resultLevel = newConfig.resultLevel
    card.roll = newConfig.roll
    card.rollResult = newConfig.rollResult
    card.rollVal = newConfig.rollVal
    card.targetScore = newConfig.targetScore
    card.resultLabel = game.i18n.localize('Elysium.resultLevel.' + newConfig.resultLevel)

    const newchatCards = []
    newchatCards.push(card)
    for (let i = 1; i < chatCards.length; i++) {
      card = chatCards[i]
      newchatCards.push(card)
      await OPCard.showDiceRoll(card)
    }
    await OPCard.showDiceRoll(chatCards[0])

    await targetMsg.update({
      'flags.elysium.chatCard': newchatCards,
      'flags.elysium.successLevel': newConfig.resultLevel,
      'flags.elysium.successLabel': game.i18n.localize('Elysium.resultLevel.' + newConfig.resultLevel),
      'flags.elysium.successRoll': newConfig.rollVal,
      'flags.elysium.state': 'closed',
    })
    const pushhtml = await ElysiumCheck.startChat(targetMsg.flags.elysium)
    await targetMsg.update({ content: pushhtml })
    if (newConfig.resultLevel > 1) {
      await ElysiumCheck.tickXP(targetMsg.flags.elysium)
    }
    return
  }

}
