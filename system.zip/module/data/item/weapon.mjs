/**
 * WeaponDataModel — schema for items of type 'weapon'.
 *
 * Per P6.3 spec. Stored-schema-only. 53 compendium items in weapons.db.
 * The largest schema in P6.3 (~67 slots).
 *
 * CRITICAL TYPE-CORRECTION: template.json defaults
 * `weapon.elysium.force = "M"` (string) — but compendium has force as
 * INT in 53/53 items (values 0-7). DataModel uses NumberField; the
 * template's default is type-incorrect. Side-finding #12 for P12.
 *
 * Schema decisions:
 *   - LOCKED choices on five fields:
 *     * weaponType ∈ {'', 'melee', 'ranged'} — '' included to allow
 *       template's empty-string default
 *     * hands ∈ {'1H', '2H'}
 *     * elysium.weaponSize ∈ {'S', 'M', 'L'}
 *     * elysium.damageType ∈ {'bludgeoning', 'piercing', 'slashing'}
 *     * elysium.reloadType ∈ {'none', 'quick', 'standard', 'slow'} per
 *       _reloadType_doc
 *   - FREE on: reach (extensible — VL observed, XL plausible), force
 *     (numeric range 0-7 may extend), range1/2/3 (single-char codes,
 *     not worth locking), skill1/skill2 (i.skill.* UUIDs — never lock
 *     UUIDs), ammoType (content-extensible), equipStatus (per #8).
 *   - `enc` and `cost` are non-integer NumberFields (2/53 weapons have
 *     float enc).
 *   - `elysium.special` is `ArrayField<StringField>` — template default
 *     is []; zero compendium content has non-empty; zero code reads.
 *     Permissive shape; P12 to tighten if usage emerges.
 *   - `elysium.damageBonusMultiplier` is non-integer NumberField (0.5,
 *     1.0, 2.0 documented in template comment).
 *   - DROPS two `_doc` keys: _reloadType_doc, _damageBonusMultiplier_doc.
 */

import { makeItemBase, migrateLegacyEquipStatus } from './_shared.mjs'

const fields = foundry.data.fields

export class WeaponDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),

      weaponType: new fields.StringField({
        initial: '',
        // blank:true required since '' is in choices — Foundry V14's
        // StringField defaults blank:false even when '' appears in choices.
        blank: true,
        choices: ['', 'melee', 'ranged'],
      }),
      // skill1/skill2: i.skill.* UUID-shaped strings. Never lock.
      skill1:    new fields.StringField({ initial: 'none' }),
      skill2:    new fields.StringField({ initial: 'none' }),
      // dmg1/2/3: dice formulas (e.g. '1d8+1').
      dmg1:      new fields.StringField({ initial: '0' }),
      dmg2:      new fields.StringField({ initial: '' }),
      dmg3:      new fields.StringField({ initial: '' }),
      special:   new fields.StringField({ initial: '' }),  // free-text; NOT same as elysium.special

      // 15 damage-type flags (template defaults all false).
      burst:     new fields.BooleanField({ initial: false }),
      stun:      new fields.BooleanField({ initial: false }),
      entangle:  new fields.BooleanField({ initial: false }),
      explosive: new fields.BooleanField({ initial: false }),
      fire:      new fields.BooleanField({ initial: false }),
      pierce:    new fields.BooleanField({ initial: false }),
      sonic:     new fields.BooleanField({ initial: false }),
      choke:     new fields.BooleanField({ initial: false }),
      cold:      new fields.BooleanField({ initial: false }),
      emp:       new fields.BooleanField({ initial: false }),
      poison:    new fields.BooleanField({ initial: false }),
      disease:   new fields.BooleanField({ initial: false }),
      acid:      new fields.BooleanField({ initial: false }),
      constrict: new fields.BooleanField({ initial: false }),
      spclDmg:   new fields.BooleanField({ initial: false }),

      db:        new fields.NumberField({ integer: true, initial: 0 }),
      att:       new fields.NumberField({ integer: true, initial: 0 }),
      range1:    new fields.StringField({ initial: 'S' }),  // FREE
      range2:    new fields.StringField({ initial: '' }),
      range3:    new fields.StringField({ initial: '' }),
      hands: new fields.StringField({
        initial: '1H',
        choices: ['1H', '2H'],
      }),
      crew:      new fields.StringField({ initial: '' }),
      hp:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      ap:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      hpCurr:    new fields.NumberField({ integer: true, initial: 0 }),
      ammoType:  new fields.StringField({ initial: '' }),  // FREE
      ammo:      new fields.NumberField({ integer: true, initial: 0 }),
      ammoCurr:  new fields.NumberField({ integer: true, initial: 0 }),
      mal:       new fields.NumberField({ integer: true, initial: 0 }),
      rof:       new fields.NumberField({ integer: true, initial: 0 }),
      radius:    new fields.NumberField({ integer: true, initial: 0 }),
      parry:     new fields.BooleanField({ initial: true }),
      str:       new fields.NumberField({ integer: true, initial: 0 }),  // STR requirement
      dex:       new fields.NumberField({ integer: true, initial: 0 }),  // DEX requirement
      enc:       new fields.NumberField({ initial: 0 }),                  // non-integer (2/53 are float)
      price:     new fields.StringField({ initial: '' }),
      cost:      new fields.NumberField({ initial: 0 }),                  // non-integer
      equipStatus: new fields.StringField({
        initial: 'stowed',
        choices: ['stowed', 'equipped'],   // v1.0.0-alpha.11 (#8)
      }),
      coverage:  new fields.StringField({ initial: '' }),
      quantity:  new fields.NumberField({ integer: true, initial: 1, min: 0 }),
      npcVal:    new fields.NumberField({ integer: true, initial: 0 }),
      pSCurr:    new fields.NumberField({ integer: true, initial: 0 }),
      pSMax:     new fields.NumberField({ integer: true, initial: 0 }),

      elysium: new fields.SchemaField({
        isMelee:        new fields.BooleanField({ initial: true }),
        weaponSize:     new fields.StringField({
          initial: 'M',
          choices: ['S', 'M', 'L'],
        }),
        reach:          new fields.StringField({ initial: 'M' }),  // FREE — extensible
        // CRITICAL: force is INT in compendium (0-7). Template's "M" default is type-incorrect.
        force:          new fields.NumberField({ integer: true, initial: 1, min: 0 }),
        rangeClose:     new fields.NumberField({ integer: true, initial: 0 }),
        rangeEffective: new fields.NumberField({ integer: true, initial: 0 }),
        rangeLong:      new fields.NumberField({ integer: true, initial: 0 }),
        damageType: new fields.StringField({
          initial: 'slashing',
          choices: ['bludgeoning', 'piercing', 'slashing'],
        }),
        thrownPenalty:  new fields.NumberField({ integer: true, initial: 0 }),
        // elysium.special: permissive array of strings (template default []; no compendium content; no code readers)
        special:        new fields.ArrayField(new fields.StringField(), { initial: [] }),
        containedIn:    new fields.StringField({ initial: '' }),
        reloadType: new fields.StringField({
          initial: 'none',
          choices: ['none', 'quick', 'standard', 'slow'],
        }),
        // damageBonusMultiplier: 0.5/1.0/2.0 documented. Non-integer.
        damageBonusMultiplier: new fields.NumberField({ initial: 1.0 }),
        // _reloadType_doc, _damageBonusMultiplier_doc DROPPED — documentation only
      }),
    }
  }

  /**
   * v1.0.0-alpha.11 (side-finding #8): pre-validation normalizer for the
   * legacy compendium values 'carried' and 'worn' on equipStatus.
   * Runs before cleanData's choices check.
   */
  static migrateData (source) {
    return migrateLegacyEquipStatus(source)
  }
}
