/**
 * Arcane Manipulation Dialog (v0.10.0; magnitude removed in v0.16.0).
 *
 * Opens at the start of an Arcane cast. Player adjusts the spell's
 * baseline parameters (range, duration, targets, area) upward by spending
 * from a per-round INT pool of `floor(INT / 2)` points (was full INT
 * pre-v0.16.0). Each parameter touched also adds +1 to required SL
 * (computed at completion, not here).
 *
 * Damage commitment row is shown when the spell flags itself as
 * damage-dealing via `system.elysium.isDamageSpell` (replacing the legacy
 * `magnitude` field which has been removed from the schema). Damage at
 * resolution is computed as `ppCommitted × ARCANE_DAMAGE_PER_PP`
 * (hardcoded constant since v0.19.0, was a world setting before).
 *
 * Also serves as the custom-spell builder when invoked with
 * `options.custom = true` — same widget, baseline starts at zero,
 * F/T list is filtered by what the caster has on their sheet, and the
 * isDamageSpell toggle is exposed for the player to choose. Custom
 * spells can be saved to the actor's sheet after a successful cast.
 *
 * Returns: Promise<ManipulationProfile | null>
 *   ManipulationProfile = {
 *     deltas: { range, duration, targets, area },
 *     ppCommitted: number,             // PP committed for damage scaling
 *     manipulationCostSpent: number,   // INT-pool points spent
 *     parametersTouched: number,       // counts deltas > 0
 *   }
 *   null = player cancelled.
 */

import { manipulationCost, summariseManipulation, ARCANE_DAMAGE_PER_PP } from './cast-shared.mjs'
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api

const PARAMS = ['range', 'duration', 'targets', 'area']

export class ArcaneManipulationDialog extends HandlebarsApplicationMixin(ApplicationV2) {

  constructor (options = {}) {
    super(options)
    this._actor   = options.actor
    this._spell   = options.spell
    this._custom  = !!options.custom
    this._skillTotal = Number(options.skillTotal) || 0
    this._intMax = Number(options.intMax) || 0
    // v0.16.0: per-round INT-pool tracking. The dialog persists spend
    // back to the actor flag after the cast resolves, so subsequent casts
    // in the same round see the reduced pool.
    this._fullIntPool = Number(options.fullIntPool) || this._intMax
    this._spentThisRound = Number(options.spentThisRound) || 0

    // Working state — adjusted by stepper buttons.
    // v0.16.0: magnitude removed; was 5 params, now 4 (range, duration, targets, area).
    this._deltas = { range: 0, duration: 0, targets: 0, area: 0 }
    this._ppCommitted = Number(this._spell?.system?.elysium?.basePP) || 0

    // Resolution mechanism — cast-pipeline awaits this promise.
    this._resolve = null
    this._promise = new Promise(res => { this._resolve = res })
    this._resolved = false
  }

  static DEFAULT_OPTIONS = {
    id: 'elysium-arcane-manipulation',
    classes: ['elysium', 'arcane-manipulation'],
    tag: 'div',
    window: {
      title: 'Elysium.Arcane.Manipulation.Title',
      icon: 'fas fa-wand-magic-sparkles',
      resizable: false,
    },
    position: { width: 540, height: 'auto' },
    actions: {
      stepUp:    ArcaneManipulationDialog._onStepUp,
      stepDown:  ArcaneManipulationDialog._onStepDown,
      ppUp:      ArcaneManipulationDialog._onPPUp,
      ppDown:    ArcaneManipulationDialog._onPPDown,
      cast:      ArcaneManipulationDialog._onCast,
      castAsWritten: ArcaneManipulationDialog._onCastAsWritten,
      cancel:    ArcaneManipulationDialog._onCancel,
    },
  }

  static PARTS = {
    body: { template: 'systems/elysium/templates/casting/manipulation-dialog.hbs' },
  }

  /** Public API: open and await a profile (or null on cancel). */
  static async open (actor, spell, options = {}) {
    const skillTotal = Number(options.skillTotal) || 0

    // v0.16.0: INT-pool is half INT (floor), refreshing per combat round.
    // Out of combat, every cast gets a fresh pool. In combat, the pool is
    // shared across all casts within a single round — track via an actor
    // flag scoped to the current combat round id.
    const fullIntPool = Math.floor((Number(actor?.system?.stats?.int?.total) || 0) / 2)
    const inCombat = !!game.combat?.combatants?.find(c => c.actorId === actor?.id)
    let spentThisRound = 0
    if (inCombat) {
      const flag = actor?.flags?.['elysium']?.intPool ?? null
      const currentRoundId = `${game.combat?.id ?? 'noid'}:${game.combat?.round ?? 0}`
      if (flag?.roundId === currentRoundId) {
        spentThisRound = Number(flag.spent) || 0
      }
    }
    const intMax = Math.max(0, fullIntPool - spentThisRound)

    const dialog = new ArcaneManipulationDialog({
      actor, spell, skillTotal, intMax,
      // v0.16.0: pass these so the dialog can persist spend back to the actor
      // after the cast resolves.
      fullIntPool,
      spentThisRound,
      custom: options.custom ?? false,
    })
    dialog.render(true)
    return dialog._promise
  }

  // ===== Context for template =========================================

  async _prepareContext (_options) {
    const baseline = this._effectiveBaseline()
    const summary = summariseManipulation(this._deltas, this._skillTotal)

    const rows = PARAMS.map(p => ({
      key: p,
      label: this._labelFor(p),
      base: baseline[p] ?? 0,
      delta: this._deltas[p],
      effective: (baseline[p] ?? 0) + this._deltas[p],
      stepCost: manipulationCost(p, this._skillTotal),
      lineCost: summary.perParam[p].cost,
    }))

    const intRemaining = this._intMax - summary.totalCost
    const overspent = intRemaining < 0
    const requiredSLBase = Number(this._spell?.system?.elysium?.requiredSL) || 1
    const requiredSLNew = requiredSLBase + summary.parametersTouched

    // v0.16.0: damage PP commitment is shown when the spell flags itself
    // damage-dealing via `isDamageSpell`. The custom-spell builder also
    // always shows it (the player chooses damage/no-damage there).
    const isDamageSpell = !!this._spell?.system?.elysium?.isDamageSpell
    const showPPCommit = this._custom || isDamageSpell

    const damagePerPP = ARCANE_DAMAGE_PER_PP
    const projectedDamage = (this._ppCommitted * damagePerPP)

    // v0.10.0: surface AP economics for reactive spells. The reactive
    // spell will draw `apCost` AP from reactive-first pool, then regular.
    const isReactive = !!this._spell?.system?.elysium?.isReactive
    const apCost = this._spell?.system?.elysium?.apCost ?? 1
    const apReactValue = Number(this._actor?.system?.actionPoints?.reactValue) || 0
    const apRegularValue = Number(this._actor?.system?.actionPoints?.value) || 0

    return {
      spellName: this._custom ? 'Custom spell' : (this._spell?.name ?? 'Spell'),
      schoolName: this._spell?.system?.elysium?.school ?? '',
      schoolSkillTotal: this._skillTotal,
      discount: this._discountLabel(),
      rows,
      summary,
      intMax: this._intMax,
      intRemaining,
      overspent,
      requiredSLBase,
      requiredSLNew,
      requiredSLAdded: summary.parametersTouched,
      basePP: this._spell?.system?.elysium?.basePP ?? 0,
      ppCommitted: this._ppCommitted,
      ppMax: this._actor?.system?.power?.value ?? 0,   // soft display cap; overcast at completion
      showPPCommit,
      damagePerPP,
      projectedDamage,
      isCustom: this._custom,
      // v0.10.0 reactive surfacing
      isReactive,
      apCost,
      apReactValue,
      apRegularValue,
      apInsufficient: isReactive && (apCost > apReactValue + apRegularValue),
    }
  }

  /**
   * Resolve the spell's effective baseline. For a normal cast that's the
   * spell's stored baseline; for the custom-spell builder we start at all-
   * zero so the player builds the whole profile from scratch.
   */
  _effectiveBaseline () {
    if (this._custom) {
      return { range: 0, duration: 0, targets: 0, area: 0 }
    }
    const b = this._spell?.system?.elysium?.baseline ?? {}
    return {
      range:    Number(b.range)    || 0,
      duration: Number(b.duration) || 0,
      targets:  Number(b.targets)  || 0,
      area:     Number(b.area)     || 0,
    }
  }

  _labelFor (p) {
    return {
      range:    game.i18n.localize('Elysium.Arcane.Manipulation.Range'),
      duration: game.i18n.localize('Elysium.Arcane.Manipulation.Duration'),
      targets:  game.i18n.localize('Elysium.Arcane.Manipulation.Targets'),
      area:     game.i18n.localize('Elysium.Arcane.Manipulation.Area'),
    }[p] ?? p
  }

  _discountLabel () {
    const s = this._skillTotal
    if (s >= 95) return 'Mastery 95%+ — base cost −4'
    if (s >= 85) return 'Mastery 85–94% — base cost −3'
    if (s >= 70) return 'Mastery 70–84% — base cost −2'
    if (s >= 50) return 'Mastery 50–69% — base cost −1'
    return 'Mastery <50% — no discount'
  }

  // ===== Action handlers ==============================================

  static _onStepUp (event, target) {
    const param = target?.dataset?.param
    if (!param || !PARAMS.includes(param)) return
    this._deltas[param] = (this._deltas[param] ?? 0) + 1
    this.render()
  }

  static _onStepDown (event, target) {
    const param = target?.dataset?.param
    if (!param || !PARAMS.includes(param)) return
    this._deltas[param] = Math.max(0, (this._deltas[param] ?? 0) - 1)
    this.render()
  }

  static _onPPUp () {
    this._ppCommitted = Math.max(0, this._ppCommitted + 1)
    this.render()
  }

  static _onPPDown () {
    this._ppCommitted = Math.max(0, this._ppCommitted - 1)
    this.render()
  }

  static _onCast () {
    const summary = summariseManipulation(this._deltas, this._skillTotal)
    if (summary.totalCost > this._intMax) {
      ui.notifications?.warn(
        `Manipulation cost ${summary.totalCost} exceeds INT pool ${this._intMax}. ` +
        `Reduce some adjustments before casting.`)
      return
    }
    // v0.10.0: reactive AP availability check
    const isReactive = !!this._spell?.system?.elysium?.isReactive
    if (isReactive) {
      const apCost = this._spell?.system?.elysium?.apCost ?? 1
      const apReact = Number(this._actor?.system?.actionPoints?.reactValue) || 0
      const apReg = Number(this._actor?.system?.actionPoints?.value) || 0
      if (apCost > apReact + apReg) {
        ui.notifications?.warn(
          `Insufficient AP for reaction: need ${apCost}, have ` +
          `${apReact} reactive + ${apReg} regular = ${apReact + apReg}.`)
        return
      }
    }
    this._resolveWith({
      deltas: { ...this._deltas },
      ppCommitted: this._ppCommitted,
      manipulationCostSpent: summary.totalCost,
      parametersTouched: summary.parametersTouched,
    })
  }

  static _onCastAsWritten () {
    // Shortcut: zero out all deltas and confirm. Equivalent to setting
    // every stepper to 0 and clicking Cast.
    this._deltas = { range: 0, duration: 0, targets: 0, area: 0 }
    this._resolveWith({
      deltas: { ...this._deltas },
      ppCommitted: this._ppCommitted,
      manipulationCostSpent: 0,
      parametersTouched: 0,
    })
  }

  static _onCancel () {
    this._resolveWith(null)
  }

  _resolveWith (profile) {
    if (this._resolved) return
    this._resolved = true

    // v0.16.0: persist INT-pool spend to actor flag for per-round tracking.
    // Only persist when a real cast happened (non-null profile with manipulation
    // spend). Don't persist on cancel (null profile) or on cast-as-written
    // (profile.manipulationCostSpent is 0 — no need to update flag).
    if (profile && profile.manipulationCostSpent > 0 && game.combat) {
      const inCombat = !!game.combat?.combatants?.find(c => c.actorId === this._actor?.id)
      if (inCombat) {
        const currentRoundId = `${game.combat.id}:${game.combat.round}`
        const newSpent = this._spentThisRound + profile.manipulationCostSpent
        // Fire-and-forget; don't block the resolve on this update
        this._actor?.update({
          'flags.elysium.intPool': {
            roundId: currentRoundId,
            spent: newSpent,
          },
        }).catch(err => console.error('Elysium | INT-pool flag update failed:', err))
      }
    }

    this._resolve(profile)
    this.close()
  }

  // If the user closes the window without choosing, count it as cancel.
  async _onClose (options) {
    if (!this._resolved) {
      this._resolved = true
      this._resolve(null)
    }
    return super._onClose?.(options)
  }
}

/** Convenience entry point used by the cast pipeline. */
export async function openManipulationDialog (actor, spell, options = {}) {
  return ArcaneManipulationDialog.open(actor, spell, options)
}
