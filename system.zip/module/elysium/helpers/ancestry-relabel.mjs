/**
 * Elysium — Ancestry Relabel
 *
 * Re-labels the "Culture" terminology to whatever the user has
 * configured (Culture / Ancestry / Race / Species).
 *
 * Mechanism:
 *   1. On i18nInit (after Foundry loads system translations), we cache
 *      the original "Culture" strings in `_originals`.
 *   2. apply() always restores from cache first, then substitutes for
 *      the current setting. This makes setting changes round-trip
 *      cleanly — switching from Race back to Culture really does
 *      restore the original.
 *   3. After applying, we re-render any open sheets so labels refresh.
 *
 * Historical note: pre-v1.0.0 this file referenced the `BRP` i18n
 * namespace. v1.0.0 merged BRP and Elysium namespaces into a single
 * Elysium namespace; this file was rewritten in P4 of the rebuild.
 */

import { getSetting } from '../settings/register-settings.mjs'

const TERM_MAP = {
  culture: {
    full:   'Culture',
    short:  'Cltr',
    plural: 'Cultures',
  },
  ancestry: {
    full:   'Ancestry',
    short:  'Ancs',
    plural: 'Ancestries',
  },
  race: {
    full:   'Race',
    short:  'Race',
    plural: 'Races',
  },
  species: {
    full:   'Species',
    short:  'Spcs',
    plural: 'Species',
  },
}

export class ElysiumAncestryRelabel {

  // Cache of original strings (snapshot taken once)
  static _originals = null
  static _initialised = false

  static initialise () {
    if (this._initialised) return
    this._cacheOriginals()
    this._initialised = true
    this.apply()
  }

  static apply () {
    if (!this._initialised) return
    this._restore()

    if (getSetting('enableAncestrySystem', true)) {
      const choice = getSetting('ancestryLabel', 'ancestry')
      if (choice !== 'culture') {
        const terms = TERM_MAP[choice] || TERM_MAP.ancestry
        this._substitute(terms)
        console.log(`Elysium | Ancestry term set to "${terms.full}"`)
      }
    }

    this._substituteXP()
  }

  static _cacheOriginals () {
    const t = game.i18n.translations
    if (!t) return

    this._originals = {
      Elysium: {},
      TYPES: {},
    }

    if (t.Elysium) {
      const cultureKeys = ['culture', 'cultureAbbr', 'cultureBonus',
                    'deleteCulture', 'cultures',
                    'addCulture', 'editCulture', 'newCulture',
                    'cultureName', 'cultureType']
      for (const key of cultureKeys) {
        if (typeof t.Elysium[key] === 'string') {
          this._originals.Elysium[key] = t.Elysium[key]
        }
      }

      for (const [key, value] of Object.entries(t.Elysium)) {
        if (typeof value === 'string' &&
            /culture/i.test(value) &&
            !this._originals.Elysium.hasOwnProperty(key)) {
          this._originals.Elysium[key] = value
        }
      }

      const xpKeys = ['xp', 'experience', 'totalXP', 'xpBonus']
      for (const key of xpKeys) {
        if (typeof t.Elysium[key] === 'string') {
          this._originals.Elysium[key] = t.Elysium[key]
        }
      }
    }

    if (t.TYPES?.Item?.culture) {
      this._originals.TYPES.culture = t.TYPES.Item.culture
    }
  }

  static _restore () {
    if (!this._originals) return
    const t = game.i18n.translations

    if (t.Elysium && this._originals.Elysium) {
      for (const [key, value] of Object.entries(this._originals.Elysium)) {
        t.Elysium[key] = value
      }
    }
    if (t.TYPES?.Item && this._originals.TYPES?.culture) {
      t.TYPES.Item.culture = this._originals.TYPES.culture
    }
  }

  static _substitute (terms) {
    const t = game.i18n.translations
    if (!t.Elysium) return

    const directMap = {
      culture:       terms.full,
      cultureAbbr:   terms.short,
      cultureBonus:  `${terms.full} skill bonus/penalty`,
      deleteCulture: `Delete ${terms.full}`,
      cultures:      terms.plural,
      addCulture:    `Add ${terms.full}`,
      editCulture:   `Edit ${terms.full}`,
      newCulture:    `New ${terms.full}`,
      cultureName:   `${terms.full} Name`,
      cultureType:   `${terms.full} Type`,
    }

    for (const [key, newValue] of Object.entries(directMap)) {
      if (this._originals.Elysium[key] !== undefined) {
        t.Elysium[key] = newValue
      }
    }

    for (const [key, original] of Object.entries(this._originals.Elysium)) {
      if (directMap.hasOwnProperty(key)) continue
      if (typeof original === 'string' && /culture/i.test(original)) {
        t.Elysium[key] = original
          .replace(/Cultures/g, terms.plural)
          .replace(/Culture/g, terms.full)
          .replace(/cultures/g, terms.plural.toLowerCase())
          .replace(/culture/g, terms.full.toLowerCase())
      }
    }

    if (t.TYPES?.Item?.culture) {
      t.TYPES.Item.culture = terms.full
    }
  }

  /**
   * Apply XP → EXP relabel.
   * Renames Elysium.xp → "EXP" and CHAR tab "Total XP" → "EXP Dice".
   */
  static _substituteXP () {
    const t = game.i18n.translations
    if (!t.Elysium) return

    if (this._originals.Elysium.xp !== undefined) {
      t.Elysium.xp = 'EXP'
    }

    if (this._originals.Elysium.totalXP !== undefined) {
      t.Elysium.totalXP = 'EXP Dice'
    }
  }
}
