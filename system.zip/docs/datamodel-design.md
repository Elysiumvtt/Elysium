# Elysium v1.0.0 — DataModel Design

Design specification for migrating from `template.json` to Foundry V14+ DataModels.

**Status**: P3 of v1.0.0 rebuild — design only, no code. P5 and P6 implement against this spec.

**Authored**: 2026-05-12

---

## Why migrate

1. **Foundry V14 deprecates `template.json`**, V16 will remove it. Migration is forced eventually.
2. **DataModels give us typed, validated fields** with per-field defaults and migration hooks. `template.json` is just JSON literals — no validation, no migration support, no derived field declarations.
3. **The v0.20.0 `system.elysium.*` partition is a fork-isolation pattern** that's no longer needed. DataModels are the right time to flatten it.
4. **Some fields are genuinely cruft** — accumulated during BRP→Elysium evolution but no longer read. Migration is the right time to drop them.

## Current state audit

Captured 2026-05-12 from `template.json` (1000 lines):

| Category | Count | Notes |
|---|---|---|
| Actor types | 2 | `character`, `npc` |
| Item types | 23 | gear, skill, hit-location, personality, profession, arcane, divine, mysticism, sorcery, mutation, super, failing, powerMod, armor, weapon, wound, allegiance, passion, ability, persTrait, reputation, skillcat, culture |
| Actor base template | 12 top-level keys, ~156 field paths | shared by character + npc |
| Item base template | 2 keys (description, gmDescription) | minimal — most logic lives in each item type |
| Largest item type | `weapon` — 51 own fields | + base template |
| Smallest item type | `reputation` — 1 own field (base) | + base template |
| Types with NO base template | `hit-location`, `wound` | standalone |
| Types with `elysium` partition | 15 of 23 item types + actor base | the v0.20.0 fork-isolation pattern |

Field-counting full list:

| Item type | Own fields | Has `elysium`? | `elysium.*` keys |
|---|---|---|---|
| gear | 8 | yes | 3 (isContainer, containedIn, capacity) |
| skill | 25 | yes | 2 (skillCategory, skillSubgroup) |
| hit-location | 20 | yes | 9 (creatureSubtype, bodyPart, side, ...) |
| personality | 2 | no | — |
| profession | 6 | yes | 11 (tier, primaryGroupSize, ...) |
| arcane | 19 | yes | 17 (school, validSchools, techniques, ...) |
| divine | 6 | yes | 21 (domain, tier, apCostByTier, ...) |
| mysticism | 18 | yes | 9 (discipline, tier, powerCost, ...) |
| sorcery | 9 | yes | 27 (essence, isConfluence, ...) — **largest elysium block** |
| mutation | 4 | yes | 3 (visionType, abilityTier, ...) |
| super | 13 | yes | 10 (tier, prerequisite, theme, ...) |
| failing | 2 | no | — |
| powerMod | 3 | no | — |
| armor | 21 | yes | 9 (flexibility, material, layerOrder, ...) |
| weapon | 51 | yes | 13 (isMelee, weaponSize, reach, ...) |
| wound | 4 | no | — |
| allegiance | 9 | no | — |
| passion | 4 | yes | 4 (isSpecialism, parentName, ...) |
| ability | 7 | yes | 7 (abilityType, category, theme, ...) |
| persTrait | 6 | no | — |
| reputation | 1 | no | — |
| skillcat | 3 | no | — |
| culture | 5 | yes | 1 (ancestry) |

## Foundry DataModel API primer

Foundry's DataModel system (introduced in V10, refined through V13/V14) replaces the `template.json` schema declaration with class-based, typed field declarations. Reference: [`foundry.data.fields.*`](https://foundryvtt.com/api/classes/foundry.data.fields.DataField.html).

### Anatomy of a DataModel

```js
class CharacterDataModel extends foundry.abstract.TypeDataModel {
  static defineSchema () {
    const fields = foundry.data.fields
    return {
      stats: new fields.SchemaField({
        str: new fields.SchemaField(makeStatBlock()),
        con: new fields.SchemaField(makeStatBlock()),
        // ...
      }),
      health: new fields.SchemaField({
        value: new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        max:   new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        // ...
      }),
      // ...
    }
  }

  // Derived fields — computed from schema fields, not stored
  prepareDerivedData () {
    super.prepareDerivedData()
    this.health.value = this.health.max - this.parent.items
      .filter(i => i.type === 'wound')
      .reduce((sum, w) => sum + w.system.value, 0)
  }
}
```

Registration via `system.json`:

```json
"documentTypes": {
  "Actor": {
    "character": {},
    "npc": { "htmlFields": ["description"] }
  },
  "Item": {
    "weapon": {},
    "armor": {}
  }
}
```

And class registration via `Hooks.on('init', ...)`:

```js
CONFIG.Actor.dataModels.character = CharacterDataModel
CONFIG.Actor.dataModels.npc       = NPCDataModel
CONFIG.Item.dataModels.weapon     = WeaponDataModel
// ... etc for all 25 types
```

### Field types we'll use

| Foundry field class | When to use | Default in `template.json` becomes |
|---|---|---|
| `NumberField({initial, integer, min, max})` | Any numeric. Use `integer: true` for counts; omit for fractional values. | `0` → `initial: 0` |
| `StringField({initial, blank, choices, required})` | Any string. `choices` for enums; `blank: false` to forbid empty. | `""` → `initial: ""` |
| `BooleanField({initial})` | Flags. | `false` → `initial: false` |
| `ArrayField(elementField, {initial})` | Lists. The `elementField` is itself a Field instance describing each element's shape. | `[]` → `initial: []` |
| `SchemaField(schema, {initial})` | Nested object with known structure. The `schema` is a plain object of fields. | `{}` → fields define their own initials |
| `ObjectField({initial})` | Nested object with **unknown/dynamic** structure. Escape hatch. Use sparingly. | `{}` → `initial: {}` |
| `HTMLField({initial, blank})` | Rich text (biography, description). Foundry renders these with TinyMCE/Prosemirror. | `""` → `initial: ""` |
| `ForeignDocumentField(DocClass, {idOnly: true})` | Reference to another document by id. Currently we use strings; this is the principled version. | `""` → `idOnly: true` recommended |
| `DocumentIdField()` | A bare Foundry document id (16-char alphanumeric). | `""` |
| `FilePathField({categories, initial})` | An image/audio/video path. Foundry validates the extension. | `"path/to.png"` |
| `ColorField()` | A CSS color string. | `"#000000"` |
| `IntegerSortField()` | Sort order indices. | `0` |

### Field type decision matrix

For each `template.json` leaf type, the DataModel mapping:

| Source shape | DataModel field |
|---|---|
| `0` (int literal) | `NumberField({ initial: 0, integer: true })` |
| `0` (used for IDs) | `DocumentIdField()` if it's a doc id; else NumberField |
| `""` (string literal) | `StringField({ initial: "" })` |
| `""` (where blank is invalid) | `StringField({ initial: "", blank: false })` |
| `false` / `true` | `BooleanField({ initial: false })` |
| `[]` | `ArrayField(elementField, { initial: [] })` — and we MUST decide `elementField` |
| `{}` (empty placeholder) | `ObjectField({ initial: {} })` — escape hatch; flag for follow-up cleanup |
| `{a: ..., b: ...}` (known shape) | `SchemaField({ a: ..., b: ... })` |
| HTML body text | `HTMLField({ initial: "" })` |
| `"path/to.png"` (image path) | `FilePathField({ categories: ["IMAGE"], initial: "..." })` |
| `null` | usually means "TBD"; add `{ nullable: true, initial: null }` to whichever field type fits |

## Design decisions

### Decision 1: Flatten `system.elysium.*` into `system.*`

**Decision**: YES, flatten.

The `system.elysium.*` partition was a fork-isolation pattern from when Elysium was a separate Foundry module wrapping the BRP system. It allowed Elysium to attach data to BRP items without colliding with BRP's own fields. As of v0.20.0 Elysium is the system itself — there's no parent to isolate from anymore.

**Migration**: every `system.elysium.<x>` field becomes `system.<x>` at its current name (unless that collides with a `system.<x>` already in use, in which case rename — see decision 5).

**Impact**: ~200+ references in code (`item.system.elysium.bodyPart` etc.) need to become `item.system.bodyPart`. Done as part of the P4 rename codemod.

### Decision 2: Drop the Actor base `templates` mechanism

**Decision**: YES, drop.

`template.json` supports a `templates` block for shared field groups. We have one: `base`, shared by `character` and `npc`. With DataModels, sharing is done by **class inheritance** or **explicit composition** in `defineSchema()`. We'll use explicit composition (more flexible than inheritance for divergent types).

Implementation: `module/data/actor/_shared.mjs` exports `makeStatBlock()`, `makeBaseFields()` functions that return field-object literals; `CharacterDataModel.defineSchema()` and `NPCDataModel.defineSchema()` each spread these into their own schema with their own additions.

### Decision 3: Sparse fields for divergent actor types

**Decision**: Each actor/item DataModel declares ONLY the fields it actually uses.

In `template.json`, `npc` inherits the full actor `base` template even though some fields (e.g. `wealthValue`, `elysium.expDice`) are character-only concepts. We could keep this pattern but it bloats NPC data. With DataModels, sparse declaration is free.

**Effect**: NPC documents stop carrying ~30 unused stat-progression fields.

### Decision 4: Use `IntegerField` constraints aggressively

Many fields are stored as numbers in `template.json` but are semantically integer-only (stat values, HP, AP, dice counts, IDs). Use `NumberField({ integer: true, min: 0 })` consistently — this catches "negative HP wrote to disk" bugs at validation time.

### Decision 5: Field name collisions to resolve

When flattening `system.elysium.<x>` into `system.<x>`, three potential collisions exist:

| Actor or item | Existing `system.<x>` | Flattening `system.elysium.<x>` | Resolution |
|---|---|---|---|
| Actor `creatureType` (on `hit-location.elysium`) | n/a — no collision; `hit-location` template owns the top-level name | Renamed at item level not actor level | OK — flatten to `system.creatureType` on hit-location items |
| `tier` (appears in `profession.elysium`, `divine.elysium`, `mysticism.elysium`, `super.elysium`) | No top-level collisions in those types | Flattens cleanly | OK |
| `category` (`arcane.elysium`, `divine`, `mysticism`, `super.elysium`) | `divine` has top-level `category` AND `elysium.category` — collision | The `system.elysium.category` on divine clashes with `system.category` | **Action**: P5/P6 must audit and rename one; flag during divine DataModel implementation |

### Decision 6: Drop legacy fields confirmed unused

P5/P6 will audit per-type. Pre-audit candidates I expect to be unused:

- `actor.system.health.daily` — daily-resource model that doesn't appear in any code path I scanned
- `actor.system.power.battVal`, `battMax` — battery model from a deprecated BRP power-pool flavor
- `actor.system.res5` — a 5th resource pool; vestigial. (verified zero refs in code)
- `actor.system.sanity` — exists in template but no character sheet exposes it (BRP/CoC carry-over)
- `actor.system.fatigue.recoveryType` — string field; never read

P5 audit will confirm; if used, they stay.

### Decision 7: HTMLField for rich-text bodies

These fields are clearly rich-text:

- `actor.system.biography`, `background`, `backstory`, `description`
- `actor.system.elysium.patron` is a small object — keep as SchemaField, but maybe a `description` HTMLField inside it
- `item.system.description`, `gmDescription` (the base template fields)

Currently these are strings; DataModel migration makes them `HTMLField({ initial: "" })`.

### Decision 8: Foreign references typed properly

These are document-id strings today:

- `actor.system.elysium.ancestryId` → reference to an Item
- `actor.system.elysium.companion.companionActorId` → reference to an Actor
- `wound.system.locId` → reference to a hit-location Item embedded on the actor
- `gear.system.elysium.containedIn` → reference to another gear Item

Two options:
- Keep as `StringField` (simplest; current behavior)
- Use `ForeignDocumentField(DocClass, { idOnly: true })` (typed; Foundry validates the id format and helps with derived hydration)

**Decision**: use `ForeignDocumentField` where the target collection is clear (Actor / Item). Stick with `StringField` for `wound.locId` since it points at an embedded item, not a world doc (ForeignDocumentField is meant for top-level collection refs).

### Decision 9: Plain ObjectField is an escape hatch with a budget

Anywhere we use `ObjectField({ initial: {} })` is a confession that the data is dynamic. Each such usage gets a `// TODO(p3-followup):` comment with the field name. The total count of these escape hatches across the v1.0.0 release should be **single digits**. If we exceed that, we've under-designed somewhere.

Candidates I expect to be ObjectField:

- `actor.system.elysium.statNaturalMax` — appears to be `{str: 18, con: 19, ...}` keyed by stat — could be SchemaField with all 7 stats; needs P5 audit
- `actor.system.elysium.schoolMastery` — keyed by school name; legitimately dynamic
- `arcane.elysium.techniques`, `forms`, `validSchools` — appear to be either lists or dicts; needs audit
- `divine.elysium.apCostByTier`, `effectByTier` — keyed by tier int; could be ArrayField if tiers are 1..N

### Decision 10: Migration approach

Per the project scope decision (no campaign data to preserve, fresh world will be created), **migration is "create the new schema with sensible defaults; existing data flows through Foundry's automatic schema-merge."**

We do NOT need:
- Data migration scripts
- Schema versioning beyond Foundry's built-in
- Backward-compat fallbacks in the DataModel

We DO need:
- Compendium data audit — does the shipped compendium content parse cleanly against new DataModels? (Run as part of P6 acceptance.)

## Per-type implementation plan

### Phase P5 — Actor DataModels

Order (smallest → largest, lowest-risk first):

**P5.1 — NPC DataModel** (smaller surface)
- Owns 19 fields directly + base template
- Drop: `res5`, `sanity` (unused per pre-audit), `health.daily`, `power.battVal`/`battMax`, `fatigue.recoveryType`
- Keep: `stats`, `health.value/max/mod/mjrwnd`, `power.value/max/mod`, `fatigue.value/max/mod/level`, `actionPoints` (full), `luckPoints`, `dmgmodTier`, `wealthValue`, `description`, `extDesc`, `majorWnd`, `minorWnd`, `moveTitle`, `move`, `altMoveTitle`, `altMove`, `lock`, `viewTab`, `showNotes`, `sanLoss` (?), `sanDesc`, `movDesc`, `ap`, `apRnd`, `baseStats`, `hp`, `mod`
- Final field count target: ~50 down from ~80

**P5.2 — Character DataModel**
- Owns 22 fields directly + base template + the larger `elysium` partition
- Same base template treatment as NPC
- Adds character-only: `biography`, `background`, `backstory`, `stories`, `gender`, `culture`, `religion`, etc. (as HTMLField where appropriate)
- The `system.elysium.expDice`, `buildPoints`, `skillPoints`, `creatureType`, `creatureSubtype`, `creatureTags`, `languages`, `statNaturalMax`, `patron`, `essences`, `schoolMastery`, `ancestryId`, `companion` — all flatten into `system.*`
- Final field count target: ~80

**P5.3 — Acceptance**
- Visual regression baseline captured: character + npc sheet states match P5 pre-change snapshots
- Foundry console: no schema validation warnings on actor create/load
- World creates, actor creates, sheet renders, save+reload roundtrips

### Phase P6 — Item DataModels

23 item types. Order by complexity (simplest first to build confidence; complex magic types last):

**P6.1** — Simple field-only items: `wound`, `reputation`, `failing`, `powerMod`, `skillcat`, `personality` (5–10 fields each)

**P6.2** — Standard items: `passion`, `culture`, `persTrait`, `allegiance`, `mutation`, `super`, `ability`, `gear` (small `elysium` partitions or none)

**P6.3** — Combat items: `weapon`, `armor`, `hit-location` (largest after magic; high test-surface from v0.22.0 rules work)

**P6.4** — Magic items: `arcane`, `divine`, `mysticism`, `sorcery` (largest `elysium` partitions; most complex schemas; deferred to last)

**P6.5** — Profession + skill: `profession`, `skill` (depend on having other item types defined since they reference them)

**P6.6** — Acceptance
- All 23 item types create/render/save/reload
- Compendium pack content imports without schema warnings
- `template.json` deleted
- Visual regression baselines updated

## Risks and concerns

### High risk

- **`armor.system.elysium.material`, `weapon.system.elysium.damageType`, `weapon.system.elysium.weaponSize`** etc. are likely string-enums that should use `choices` on the StringField. P6.3 must audit the actual values used in compendium content and lock the choices list.
- **`actionPoints` has 6 sub-fields** (value/max/reactValue/reactMax/attackValue/attackMax) implementing the v0.18.0 sub-pool system — keep all six; this is hot path.
- **`stats.<stat>` has 12 sub-fields each** (base/redist/culture/exp/age/effects/cost/formula/improve/failCounter/capOverride + total computed). Confirmed used via bracket notation. Keep all.
- **Compendium content compatibility.** The `module.zip` ElysiumCompendium pack ships 53 weapons, dozens of armor pieces, etc. all written against the current schema. After DataModel migration, compendium imports must succeed without warnings. Test as part of P6.6.

### Medium risk

- **`viewTab` on NPC** stores the active tab as a string. Tab values evolved during v0.22.0 work. Locking down the `choices` list might break if a saved NPC has an outdated tab id; better to leave as plain StringField with no choices.
- **`personality.skills`, `personality.groups`** — what shape? Lists of skill ids? Lists of objects? Needs P6.2 audit.
- **`profession.skills`, `profession.groups`, `profession.powers`** — similar.

### Low risk

- All numeric stat/health/power fields — these are straightforward NumberField with integer constraints.
- All boolean flags (`improve`, `noXP`, `lock`, etc.) — BooleanField with `initial: false`.

## What this document does NOT contain

Deliberately:
- No actual DataModel code — that's P5/P6
- No per-field NumberField/StringField mappings for all ~400 fields — that's P5/P6 grinding work
- No migration scripts — not needed per project scope
- No light-theme decision — that's P12
- No template/HBS template touches — that's P7+

## What P5/P6 should do BEFORE writing the schema

For each type:

1. Grep all references to `actor.system.<x>` or `item.system.<x>` in `module/` and `templates/`
2. For each schema field, classify: definite-use / probable-use / unused
3. If unused, drop in the new DataModel. If probable, keep with a `// TODO(p6-audit):` comment.
4. For each field, pick the right `foundry.data.fields.*` class based on Decision 1 + decision matrix
5. For enums, lock the `choices` list against actual data in compendium
6. Write the schema
7. Smoke test: create item, set every field, save, reload, read every field
8. Update visual regression baselines

## References

- Foundry V14 DataModel docs: https://foundryvtt.com/article/system-data-models/
- Field classes API: https://foundryvtt.com/api/classes/foundry.data.fields.DataField.html
- Migration example (PF2e public source): https://github.com/foundryvtt/pf2e (good real-world reference)
- Our own `template.json` audit (this document, sections above)
- ROADMAP-v1.0.0.md project tracker
