/**
 * Elysium Data Helper
 *
 * Resolves Elysium-specific data fields that may live in:
 *   1. system.elysium.*   (when ElysiumBRP system fork is installed — preferred)
 *   2. flags.elysium.*    (when on stock BRP — fallback)
 *
 * For item persistent data (weapon Size, armour flexibility, ancestry data),
 * the system location is preferred. For dynamic actor state (fatigue level,
 * AP pool, luck points), flags is always used.
 *
 * This helper makes the rules module work with or without the system fork.
 */

export class ElysiumData {

  /**
   * Get the Elysium data block for a document.
   * Returns the merged view: system.elysium (if present) + flags.elysium (overrides).
   */
  static get (doc) {
    if (!doc) return {}
    const sys = doc.system?.elysium || {}
    const flag = doc.flags?.elysium || {}
    return foundry.utils.mergeObject(
      foundry.utils.deepClone(sys),
      flag,
      { inplace: false }
    )
  }

  /**
   * Get a specific path from the Elysium data, e.g.
   *   ElysiumData.path(weaponItem, 'weaponSize')  → 'medium'
   *   ElysiumData.path(armourItem, 'armorHP.value') → 10
   */
  static path (doc, path, defaultValue = undefined) {
    const data = this.get(doc)
    return foundry.utils.getProperty(data, path) ?? defaultValue
  }

  /**
   * Set a value on the Elysium data block.
   * For item persistent fields, prefers system.elysium when system fork is detected.
   * Otherwise writes to flags.elysium.
   */
  static async set (doc, path, value, options = {}) {
    if (!doc) return

    const useSystem = options.useSystem ?? this._isElysiumBRPSystem(doc)
    const root = useSystem ? 'system.elysium.' : 'flags.elysium.'

    return await doc.update({
      [`${root}${path}`]: value,
    }, { render: options.render ?? true })
  }

  /**
   * Always read/write to flags — used for transient actor state
   * regardless of whether the system fork is installed.
   */
  static async setFlag (doc, path, value, options = {}) {
    if (!doc) return
    return await doc.update({
      [`flags.elysium.${path}`]: value,
    }, { render: options.render ?? true })
  }

  /**
   * Check if ElysiumBRP system fork is active.
   * Detected by presence of system.elysium template fields.
   */
  static _isElysiumBRPSystem (doc) {
    return doc?.system?.elysium !== undefined
  }

  /**
   * Convenience: is the system fork installed?
   */
  static isSystemForkActive () {
    return game.system?.title?.includes('Elysium') ?? false
  }
}
