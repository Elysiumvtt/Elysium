/**
 * Elysium Rules — Hook registration
 *
 * All hook handlers live in sibling modules; this file is the wiring point
 * that ties Foundry events to handlers. The hooks delegate to manager
 * classes (ElysiumActorExtension, ElysiumCombatExtension, etc.), which
 * check settings before acting.
 *
 * v0.21.0 restructure: this file used to be 730 lines holding both the
 * dispatcher and every handler body. The handlers have been extracted into
 * focused modules (actor.mjs, item.mjs, combat.mjs, render-actor-sheet.mjs,
 * render-item-sheet.mjs, render-combat-tracker.mjs, chat-card.mjs) — this
 * dispatcher just imports them and wires Hooks.on calls.
 */

import { _onCreateActor, _onUpdateActor, _onPreUpdateActor }       from './actor.mjs'
import {
  _onPreCreateItem, _onCreateItem, _onDeleteItem,
  _onPreUpdateItem, _onUpdateItem,
}                                                                    from './item.mjs'
import {
  _onCombatStart, _onCombatRound, _onCombatTurn, _onCombatEnd,
}                                                                    from './combat.mjs'
import { _onRenderActorSheet }                                       from './render-actor-sheet.mjs'
import { _onRenderItemSheet }                                        from './render-item-sheet.mjs'
import { onRenderCombatTracker }                                     from './render-combat-tracker.mjs'
import { onRenderChatMessageHTML }                                   from './chat-card.mjs'

export function registerHooks () {
  // Actor data preparation — adds Elysium derived stats
  // v0.20.0: preCreateActor hook removed — flags.elysium defaults now come
  // from template.json and the pre-create initialization step the original
  // handler did is no longer needed.
  Hooks.on('createActor', _onCreateActor)

  // Hook into prepareDerivedData via wrapping
  Hooks.on('updateActor', _onUpdateActor)

  // Item drop on actor — intercept ancestry, career, etc.
  Hooks.on('preCreateItem', _onPreCreateItem)
  Hooks.on('createItem', _onCreateItem)
  Hooks.on('deleteItem', _onDeleteItem)

  // Sheet rendering — extend BRP-base sheets with Elysium UI
  Hooks.on('renderActorSheetV2', _onRenderActorSheet)
  Hooks.on('renderItemSheetV2', _onRenderItemSheet)

  // Combat — initiative, AP tracking, fatigue ticks
  Hooks.on('combatStart', _onCombatStart)
  Hooks.on('combatRound', _onCombatRound)
  Hooks.on('combatTurn', _onCombatTurn)
  Hooks.on('deleteCombat', _onCombatEnd)

  // HP changes — wound thresholds and critical table rolls
  Hooks.on('preUpdateActor', _onPreUpdateActor)
  Hooks.on('preUpdateItem', _onPreUpdateItem)
  Hooks.on('updateItem', _onUpdateItem)

  // Engagement: combat-tracker context menu is patched in directly
  // via ElysiumEngagementUI.patchCombatTrackerContextMenu (called from
  // the setup hook in elysium.mjs). V14 doesn't fire a public hook for
  // tracker entry context, so we monkey-patch _getEntryContextOptions.

  // Combat tracker render: paint a small shield badge next to the name
  // of any combatant currently bracing (flags.elysium.braced === true).
  Hooks.on('renderCombatTracker', onRenderCombatTracker)

  // v0.9.0 — cast chat-card button delegation.
  // Cards posted by the casting subsystem have buttons that need to
  // operate on the caster (Spend AP, Abandon, Undo PP). The buttons
  // carry data-cast-action and data-actor-id; we delegate clicks here.
  // Casting helpers are exposed on game.system.api.casting (set by
  // the system fork's init hook).
  // V14: hook is renderChatMessageHTML; second arg is HTMLElement directly.
  Hooks.on('renderChatMessageHTML', onRenderChatMessageHTML)
}
