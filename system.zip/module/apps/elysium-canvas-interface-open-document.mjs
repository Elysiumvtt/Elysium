import ElysiumCanvasInterface from "./elysium-canvas-interface.mjs";

export default class ElysiumCanvasInterfaceOpenDocument extends ElysiumCanvasInterface {
  static get PERMISSIONS () {
    return {
      ALWAYS: 'Elysium.ElysiumCanvasInterface.Permission.Always',
      DOCUMENT: 'Elysium.ElysiumCanvasInterface.Permission.Document',
      SEE_TILE: 'Elysium.ElysiumCanvasInterface.Permission.SeeTile',
      GM: 'Elysium.ElysiumCanvasInterface.Permission.GM'
    }
  }

  static get icon () {
    return 'fa-solid fa-book-atlas'
  }

  static defineSchema () {
    const fields = foundry.data.fields
    return {
      triggerButton: new fields.NumberField({
        choices: ElysiumCanvasInterface.triggerButtons,
        initial: ElysiumCanvasInterface.triggerButton.Left,
        label: 'Elysium.ElysiumCanvasInterface.OpenDocument.Button.Title',
        hint: 'Elysium.ElysiumCanvasInterface.OpenDocument.Button.Hint'
      }),
      permission: new fields.StringField({
        blank: false,
        choices: Object.keys(ElysiumCanvasInterfaceOpenDocument.PERMISSIONS).reduce((c, k) => { c[k] = game.i18n.localize(ElysiumCanvasInterfaceOpenDocument.PERMISSIONS[k]); return c }, {}),
        initial: 'GM',
        label: 'Elysium.ElysiumCanvasInterface.OpenDocument.Permission.Title',
        hint: 'Elysium.ElysiumCanvasInterface.OpenDocument.Permission.Hint',
        required: true
      }),
      documentUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.OpenDocument.Document.Title',
        hint: 'Elysium.ElysiumCanvasInterface.OpenDocument.Document.Hint'
      }),
      anchor: new fields.StringField({
        initial: '',
        label: 'Elysium.ElysiumCanvasInterface.OpenDocument.Anchor.Title',
        hint: 'Elysium.ElysiumCanvasInterface.OpenDocument.Anchor.Hint'
      }),
      tileUuid: new fields.DocumentUUIDField({
        label: 'Elysium.ElysiumCanvasInterface.OpenDocument.Tile.Title',
        hint: 'Elysium.ElysiumCanvasInterface.OpenDocument.Tile.Hint',
        type: 'Tile'
      })
    }
  }

  async _handleMouseOverEvent () {
    switch (this.permission) {
      case 'ALWAYS':
        return true
      case 'GM':
        return game.user.isGM
      case 'DOCUMENT':
        if (game.user.isGM) {
          return true
        }
        if (this.documentUuid) {
          return (await fromUuid(this.documentUuid)).testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED) ?? false
        }
        break
      case 'SEE_TILE':
        if (game.user.isGM) {
          return true
        }
        if (this.tileUuid && this.documentUuid) {
          return !(await fromUuid(this.tileUuid)).hidden && ((await fromUuid(this.documentUuid)).testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED) ?? false)
        }
        break
    }
    return false
  }

  async #handleClickEvent () {
    const doc = await fromUuid(this.documentUuid)
    if (doc?.testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED)) {
      if (doc instanceof JournalEntryPage) {
        doc.parent.sheet.render(true, { pageId: doc.id, anchor: this.anchor })
      } else {
        doc.sheet.render(true)
      }
    } else {
      console.error('Document ' + this.documentUuid + ' not loaded')
    }
  }

  async _handleLeftClickEvent () {
    if (this.documentUuid && this.triggerButton === ElysiumCanvasInterface.triggerButton.Left) {
      this.#handleClickEvent()
    }
  }

  async _handleRightClickEvent () {
    if (this.documentUuid && this.triggerButton === ElysiumCanvasInterface.triggerButton.Right) {
      this.#handleClickEvent()
    }
  }
}
