// =====================================================================
// ELYSIUM | Charge UI
// =====================================================================
//
// Combat-tracker context-menu entries:
//   - Charge…       (declare a charge against a target)
//   - Brace        (toggle Brace combat action — flag on combatant)
//   - Knockback…   (apply knockback math to a combatant)
//
// Charge flow:
//   1. Initiator picks target + weapon (default: equipped) + closing reach
//   2. Chat card shows charge bonuses (Damage Mod, weapon Size, difficulty)
//      and posts response buttons for the defender:
//        - Parry
//        - Evade
//        - Counterattack
//   3. GM clicks the response, chat card updates with the resolution
//      (engagement is established at the closing reach if not already)
//
// Brace flow:
//   - Toggles flags.elysium.braced on the combatant
//   - Knockback math reads this flag and halves the excess damage
//
// Knockback flow:
//   1. User invokes via context menu, enters raw damage in dialog
//   2. Chat card shows the math: damage > SIZ → feet of knockback
//   3. Defender rolls Acrobatics (Easy) or Athletics (Standard) externally
//   4. GM clicks "Stayed up" or "Fell prone" to commit the outcome
// =====================================================================

import { ELYSIUM } from '../config/config.mjs'
import { computeChargeBonuses, computeKnockback } from './charge.mjs'
import { getEngagements, getEngagementWith } from './engagement.mjs'
/**
 * Append charge/brace/knockback entries to a combatant context-menu
 * options array. Called from registerEngagementContextMenu (we extend
 * the same array rather than building a separate menu).
 */
export function registerChargeContextMenu (html, options) {
  const elOf = (li) => (li?.[0] instanceof Element ? li[0] : li)

  options.push(
    {
      name: 'Elysium: Charge…',
      icon: '<i class="fas fa-bolt"></i>',
      condition: (li) => {
        const combat = game.combat
        return !!combat && combat.combatants.size > 1
      },
      callback: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (combatant) openChargeDialog(combatant)
      },
    },
    {
      name: 'Elysium: Toggle Brace',
      icon: '<i class="fas fa-shield"></i>',
      condition: () => !!game.combat,
      callback: async (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (!combatant) return
        const next = !combatant.flags?.['elysium']?.braced
        await combatant.update({ 'flags.elysium.braced': next })
        ui.notifications?.info(
          `${combatant.name} ${next ? 'is now bracing' : 'stopped bracing'}.`
        )
      },
    },
    {
      name: 'Elysium: Apply Knockback…',
      icon: '<i class="fas fa-person-falling"></i>',
      condition: () => !!game.combat,
      callback: (li) => {
        const el = elOf(li)
        const combatantId = el?.dataset?.combatantId
        const combatant = game.combat?.combatants.get(combatantId)
        if (combatant) openKnockbackDialog(combatant)
      },
    },
  )
}

/**
 * Charge dialog — pick target combatant, weapon, and closing reach.
 */
async function openChargeDialog (initiator) {
  const combat = game.combat
  if (!combat) return

  // Targets: anyone in combat except self
  const targets = combat.combatants.filter(c => c.id !== initiator.id)
  if (targets.length === 0) {
    ui.notifications?.warn('No targets available to charge.')
    return
  }

  // Equipped weapons on the initiator
  const myWeapons = initiator.actor?.items.filter(i =>
    i.type === 'weapon' && i.system?.equipStatus === 'equipped'
  ) || []
  if (myWeapons.length === 0) {
    ui.notifications?.warn(`${initiator.name} has no equipped weapons.`)
    return
  }

  const targetOpts = targets.map(c =>
    `<option value="${c.id}">${c.name}</option>`
  ).join('')
  const wpnOpts = myWeapons.map(w => {
    const reach = w.system?.elysium?.reach || 'M'
    const reachLabel = (ELYSIUM.WEAPON_REACHES || {})[reach] || reach
    return `<option value="${w.id}">${w.name} (Reach ${reachLabel})</option>`
  }).join('')
  const reachOpts = Object.entries(ELYSIUM.WEAPON_REACHES || {}).map(([k, label]) =>
    `<option value="${k}">${label}</option>`
  ).join('')

  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:11px;font-style:italic;opacity:0.85;">
        Charge requires a full Combat Round of running/sprinting prior to
        contact (GM judgement). Bonuses: +1 step Damage Mod, +1 step
        weapon Size, +1 difficulty grade on attack roll.
      </p>
      <div class="form-group">
        <label>Target</label>
        <select name="targetId">${targetOpts}</select>
      </div>
      <div class="form-group">
        <label>Weapon</label>
        <select name="weaponId">${wpnOpts}</select>
      </div>
      <div class="form-group">
        <label data-tooltip="Reach the charge will resolve at. Defaults to the attacker's weapon reach.">
          Closing Reach
        </label>
        <select name="reach">
          <option value="">— Auto (your weapon's reach) —</option>
          ${reachOpts}
        </select>
      </div>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Charge — ${initiator.name}` },
    content,
    ok: {
      label: 'Begin Charge',
      callback: (event, button) => {
        const form = button.form
        return {
          targetId: form.querySelector('[name="targetId"]').value,
          weaponId: form.querySelector('[name="weaponId"]').value,
          reach:    form.querySelector('[name="reach"]').value,
        }
      },
    },
  }).catch(() => null)

  if (!result?.targetId || !result?.weaponId) return

  await initiateCharge(initiator, result.targetId, result.weaponId, result.reach)
}

/**
 * Post the charge chat card with bonuses + defender response buttons.
 */
async function initiateCharge (initiator, targetId, weaponId, overrideReach) {
  const target = game.combat?.combatants.get(targetId)
  if (!target) return

  const weapon = initiator.actor?.items.get(weaponId)
  if (!weapon) return

  const reachLabels = ELYSIUM.WEAPON_REACHES || {}
  const sizeLabels  = ELYSIUM.WEAPON_SIZES   || {}

  const closingReach = overrideReach || weapon.system?.elysium?.reach || 'M'
  const bonuses      = computeChargeBonuses(initiator.actor, weapon)
  const baseDmgMod   = initiator.actor?.system?.dmgmodTier || '+0'
  const baseSize     = weapon.system?.elysium?.weaponSize || 'M'

  // Migration: chat-card-prompt Archetype C. Buttons preserve
  // data-elysium-charge-action verbatim (audit-5 hook for resolveCharge).
  const body = `<p>${game.i18n.format('Elysium.Chat.ChargeDescription', {
      initiator: `<b>${initiator.name}</b>`,
      target: `<b>${target.name}</b>`,
      weapon: `<b>${weapon.name}</b>`,
      reach: reachLabels[closingReach] || closingReach,
    })}</p>
    <p><strong>${game.i18n.localize('Elysium.Chat.ChargeBonusesLabel')}</strong></p>
    <ul>
      <li>${game.i18n.localize('Elysium.Chat.ChargeBonusAttack')}</li>
      <li>${game.i18n.format('Elysium.Chat.ChargeBonusDamage', {
        base: baseDmgMod, boosted: bonuses.damageMod,
      })} <em>${bonuses.legs >= 4
        ? game.i18n.localize('Elysium.Chat.ChargeBonusNoteQuadruped')
        : game.i18n.localize('Elysium.Chat.ChargeBonusNoteBiped')}</em></li>
      <li>${game.i18n.format('Elysium.Chat.ChargeBonusSize', {
        base: sizeLabels[baseSize] || baseSize,
        boosted: sizeLabels[bonuses.weaponSize] || bonuses.weaponSize,
      })} <em>${game.i18n.localize('Elysium.Chat.ChargeBonusNoteSize')}</em></li>
    </ul>`
  const hint = game.i18n.format('Elysium.Chat.ChargeResponsePrompt', { target: target.name })
  const buttonDataAttrs = {
    'charge-initiator': initiator.id,
    'charge-target': targetId,
    'charge-weapon': weaponId,
    'charge-reach': closingReach,
  }
  const buttons = [
    { action: 'parry',   label: game.i18n.localize('Elysium.Chat.ChargeBtnParry'),
      tooltip: game.i18n.localize('Elysium.Chat.ChargeBtnParryTip'),
      dataAttrs: buttonDataAttrs },
    { action: 'evade',   label: game.i18n.localize('Elysium.Chat.ChargeBtnEvade'),
      tooltip: game.i18n.localize('Elysium.Chat.ChargeBtnEvadeTip'),
      dataAttrs: buttonDataAttrs },
    { action: 'counter', label: game.i18n.localize('Elysium.Chat.ChargeBtnCounter'),
      tooltip: game.i18n.localize('Elysium.Chat.ChargeBtnCounterTip'),
      dataAttrs: buttonDataAttrs },
  ]
  const content = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-prompt.hbs',
    {
      variant: 'action',
      title: game.i18n.localize('Elysium.Chat.ChargeTitle'),
      icon: 'bolt',
      body,
      hint,
      actionAttr: 'data-elysium-charge-action',
      buttons,
    }
  )

  await ChatMessage.create({
    content,
    speaker: ChatMessage.getSpeaker({ actor: initiator.actor }),
    flags: { elysium: { charge: true } },
  })
}

/**
 * Resolve a charge response. Establishes engagement if not already
 * present, posts a confirmation chat card with reminder text.
 */
export async function resolveCharge (action, initiatorId, targetId, weaponId, closingReach) {
  const combat = game.combat
  if (!combat) return

  const initiator = combat.combatants.get(initiatorId)
  const target    = combat.combatants.get(targetId)
  if (!initiator || !target) return

  const reachLabels = ELYSIUM.WEAPON_REACHES || {}
  const reachLabel  = reachLabels[closingReach] || closingReach

  // Establish engagement if not already (charge into contact ends in
  // engagement)
  const existingForward  = getEngagementWith(initiator, targetId)
  const existingBackward = getEngagementWith(target, initiatorId)
  if (!existingForward) {
    const aList = [...getEngagements(initiator)]
    aList.push({ withId: targetId, reach: closingReach, weaponId })
    await initiator.update({ 'flags.elysium.engagements': aList })
  }
  if (!existingBackward) {
    // Auto-pick first equipped weapon for target
    const tWpn = target.actor?.items.find(i =>
      i.type === 'weapon' && i.system?.equipStatus === 'equipped'
    )
    const bList = [...getEngagements(target)]
    bList.push({
      withId:   initiatorId,
      reach:    closingReach,
      weaponId: tWpn?.id || '',
    })
    await target.update({ 'flags.elysium.engagements': bList })
  }

  let summary = ''
  let icon = ''
  let color = '#444'
  if (action === 'parry') {
    icon = 'fa-shield-halved'
    color = '#664400'
    summary = `<b>${target.name}</b> attempts to <b>parry</b> the charge. Resolve the attack roll with charging modifiers (+1 difficulty, +1 step Damage Mod, +1 step weapon Size). Knockback risk if blow lands or if parry-weapon Size differs significantly. Engagement established at <b>${reachLabel}</b>.`
  } else if (action === 'evade') {
    icon = 'fa-person-running'
    color = '#445566'
    summary = `<b>${target.name}</b> attempts to <b>evade</b> — opposed Evade vs <b>${initiator.name}</b>'s combat skill. If defender wins, throws clear (no damage). If attacker wins, blow lands; level-of-success differences trigger Special Effects. Engagement established at <b>${reachLabel}</b> on hit.`
  } else if (action === 'counter') {
    icon = 'fa-swords'
    color = '#882929'
    summary = `<b>${target.name}</b> <b>counterattacks</b> the charge. Both treated as failed parries; longer-Reach weapon strikes first. Set/braced impaling weapons may substitute the defender's Damage Mod for the charging attacker's. Engagement established at <b>${reachLabel}</b>.`
  } else {
    summary = `Charge resolved: ${action}.`
  }

  // Strip 'fa-' prefix for partial's icon param convention.
  const iconKey = icon.replace(/^fa-/, '')
  // Variant maps to per-action token: parry=bonus-dark (defensive), evade=info, counter=danger
  const variant = action === 'parry'   ? 'bonus-dark'
                : action === 'evade'   ? 'info'
                : action === 'counter' ? 'danger'
                : 'action'

  const body = `<p>${summary}</p>`
  const footer = `<em>All charge benefits are lost after the first attack.</em>`
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-roll.hbs',
    {
      variant,
      title: game.i18n.localize('Elysium.Chat.ChargeResolved'),
      icon: iconKey,
      body,
      footer,
    }
  )
  await ChatMessage.create({
    content: html,
    speaker: ChatMessage.getSpeaker({ actor: initiator.actor }),
  })

  // Re-render any open weapon sheets so the engagement display updates
  for (const actor of [initiator.actor, target.actor]) {
    if (!actor) continue
    for (const item of actor.items) {
      if (item.type === 'weapon' && item.sheet?.rendered) {
        item.sheet.render(false)
      }
    }
    if (actor.sheet?.rendered) actor.sheet.render(false)
  }
}

/**
 * Knockback dialog — enter raw damage and defender's SIZ, get math.
 */
async function openKnockbackDialog (defender) {
  const defenderSIZ = Number(defender.actor?.system?.stats?.siz?.total) ||
                      Number(defender.actor?.system?.stats?.siz?.value) ||
                      Number(defender.actor?.system?.stats?.siz) ||
                      0
  const braced = !!defender.flags?.['elysium']?.braced

  const content = `
    <form>
      <p style="margin:0 0 8px 0;font-size:11px;font-style:italic;opacity:0.85;">
        Mythras knockback: raw damage (before parry/armor) exceeding
        the defender's SIZ knocks them back 1m per 5 damage over.
        ${braced ? '<br><b>Bracing</b>: excess damage halved before knockback math.' : ''}
      </p>
      <div class="form-group">
        <label>Raw Damage Rolled</label>
        <input type="number" name="rawDamage" value="0" min="0" max="999"
               data-tooltip="Damage rolled, BEFORE any parry/armor reduction.">
      </div>
      <div class="form-group">
        <label>Defender SIZ</label>
        <input type="number" name="defenderSIZ" value="${defenderSIZ}" min="1" max="40"
               data-tooltip="Defender's SIZ characteristic.">
      </div>
      <div class="form-group">
        <label>Bracing?</label>
        <input type="checkbox" name="braced" ${braced ? 'checked' : ''}
               data-tooltip="If checked, halves the excess damage before knockback math (Brace combat action).">
      </div>
    </form>
  `

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Knockback — ${defender.name}` },
    content,
    ok: {
      label: 'Compute',
      callback: (event, button) => {
        const form = button.form
        return {
          rawDamage:   Number(form.querySelector('[name="rawDamage"]').value) || 0,
          defenderSIZ: Number(form.querySelector('[name="defenderSIZ"]').value) || 0,
          braced:      form.querySelector('[name="braced"]').checked,
        }
      },
    },
  }).catch(() => null)

  if (!result) return

  const kb = computeKnockback(result.rawDamage, result.defenderSIZ, result.braced)

  if (kb.feet === 0) {
    const nkBody = `<p>${game.i18n.format('Elysium.Chat.KnockbackNoDamage', {
      defender: `<b>${defender.name}</b>`,
      raw: result.rawDamage,
      defenderSIZ: result.defenderSIZ,
    })}</p>`
    const nkHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'info', icon: 'person-falling', body: nkBody }
    )
    await ChatMessage.create({
      content: nkHtml,
      speaker: ChatMessage.getSpeaker({ actor: defender.actor }),
    })
    return
  }

  // Post the knockback prompt with prone-or-stay buttons via Archetype C
  const kbBody = `<p><b>${defender.name}</b>: ${result.rawDamage} damage vs SIZ ${result.defenderSIZ}
      ${result.braced ? '<em>(braced, excess halved)</em>' : ''}</p>
    <p>Knocked back <b>${kb.feet}ft</b> (${kb.squares} ${kb.squares === 1 ? 'square' : 'squares'})
      <em>(excess ${kb.excess})</em></p>`
  const kbHint = 'Roll Acrobatics (Easy) or Athletics (Standard) to avoid going prone:'
  const kbButtons = [
    { action: 'stayed', label: 'Stayed up',
      tooltip: 'Defender succeeded the roll — knocked back but stays upright.',
      dataAttrs: { 'kb-defender': defender.id } },
    { action: 'prone',  label: 'Fell prone',
      tooltip: 'Defender failed the roll — prone after knockback.',
      dataAttrs: { 'kb-defender': defender.id } },
  ]
  const content2 = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-prompt.hbs',
    {
      variant: 'action',
      title: game.i18n.localize('Elysium.Chat.KnockbackTitle'),
      icon: 'person-falling',
      body: kbBody,
      hint: kbHint,
      actionAttr: 'data-elysium-kb-action',
      buttons: kbButtons,
    }
  )
  await ChatMessage.create({
    content: content2,
    speaker: ChatMessage.getSpeaker({ actor: defender.actor }),
    flags: { elysium: { knockback: true } },
  })
}

/**
 * Resolve knockback prone-or-not from chat-card click.
 */
export async function resolveKnockback (action, defenderId) {
  const defender = game.combat?.combatants.get(defenderId)
  if (!defender) return

  if (action === 'stayed') {
    const sBody = `<p>${game.i18n.format('Elysium.Chat.KnockbackStayed', {
      defender: `<b>${defender.name}</b>`,
    })}</p>`
    const sHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'success', icon: 'person-walking', body: sBody }
    )
    await ChatMessage.create({
      content: sHtml,
      speaker: ChatMessage.getSpeaker({ actor: defender.actor }),
    })
  } else if (action === 'prone') {
    // Apply Foundry's prone status if available
    const proneEffectId = CONFIG.statusEffects?.find(e => e.id === 'prone')?.id
    if (proneEffectId && defender.actor) {
      try {
        await defender.actor.toggleStatusEffect(proneEffectId, { active: true })
      } catch (err) {
        console.warn('Elysium | Could not toggle prone status:', err)
      }
    }
    const pBody = `<p>${game.i18n.format('Elysium.Chat.KnockbackProne', {
      defender: `<b>${defender.name}</b>`,
    })}</p>`
    const pHtml = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      { variant: 'danger', icon: 'person-falling', body: pBody }
    )
    await ChatMessage.create({
      content: pHtml,
      speaker: ChatMessage.getSpeaker({ actor: defender.actor }),
    })
  }
}

/**
 * Wire delegated click handlers on chat log for charge/knockback buttons.
 * Called from the ready hook alongside the change-range handler.
 */
export function wireChargeChatHandlers () {
  document.body.addEventListener('click', async (ev) => {
    const chargeBtn = ev.target.closest('[data-elysium-charge-action]')
    if (chargeBtn) {
      ev.preventDefault()
      if (!game.user.isGM && !game.user.hasPermission?.('SETTINGS_MODIFY')) {
        ui.notifications?.warn('Only the GM can resolve Charge outcomes.')
        return
      }
      await resolveCharge(
        chargeBtn.dataset.elysiumChargeAction,
        chargeBtn.dataset.chargeInitiator,
        chargeBtn.dataset.chargeTarget,
        chargeBtn.dataset.chargeWeapon,
        chargeBtn.dataset.chargeReach,
      )
      return
    }

    const kbBtn = ev.target.closest('[data-elysium-kb-action]')
    if (kbBtn) {
      ev.preventDefault()
      if (!game.user.isGM && !game.user.hasPermission?.('SETTINGS_MODIFY')) {
        ui.notifications?.warn('Only the GM can resolve Knockback outcomes.')
        return
      }
      await resolveKnockback(
        kbBtn.dataset.elysiumKbAction,
        kbBtn.dataset.kbDefender,
      )
    }
  })
}

export const ElysiumChargeUI = {
  registerContextMenu: registerChargeContextMenu,
  openChargeDialog,
  openKnockbackDialog,
  resolveCharge,
  resolveKnockback,
  wireChargeChatHandlers,
}
