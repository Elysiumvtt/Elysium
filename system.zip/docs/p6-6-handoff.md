# P6.6 Handoff — Final Phase: template.json Cleanup + Acceptance

Companion to `p6-prep-audit.md`. Captured 2026-05-13 at session end after shipping
P6.1 through P6.5 over a single working day (alpha.4 through alpha.9, with one hotfix
at alpha.7).

This doc is the bootstrapping document for whoever (Claude in a new session, or human
collaborator) picks up the final P6 sub-phase. It captures the current state, the
remaining work, and the discipline that's been used throughout the rebuild.

---

## Current state at handoff

**Version**: `1.0.0-alpha.9`
**Date**: 2026-05-13
**Tree**: `/home/claude/work/system/` — read-only after this session ends; the new
session will start from the packaged `system.zip` in `/mnt/user-data/outputs/`.

**Item DataModels**: 23 of 23 complete and live-verified in test-2 world (Foundry 14.361):
- ability, allegiance, arcane, armor, culture, divine, failing, gear, hit-location,
  mutation, mysticism, passion, persTrait, personality, powerMod, profession,
  reputation, skill, skillcat, sorcery, super, weapon, wound

**Actor DataModels**: 2 of 2 complete (character, npc) — shipped in P5.

**Test world status**: 4 actors, 0 items (cleaned after P6.5 smoke).

**Syntax sweep**: 185/185 `node --check` clean. 5/5 JSON parses clean.
3/3 visual regression baselines parse clean.

---

## What P6.6 ships (alpha.10)

This is the smallest sub-phase in P6. Four work items:

### 1. Delete the entire Item block from template.json

template.json currently contains BOTH the (now-orphaned) Item block and any
residual schemas. The Item block has been progressively obsoleted as P6.1–P6.5
declared each type's DataModel. The Actor block was already removed in P5.3.

**Action**: read `/home/claude/work/system/template.json`. Confirm `Actor` block
is absent (should have been deleted in P5.3 — verify). Delete the `Item` block.
The file should end up with empty `{}` or just a `Document` block if any exists.

Side findings that auto-resolve via this deletion:
- **#17** (skill.category 'cmmnmod' typo) — template gone, can't have typo
- **#15** (arcane.spellCat duplicates elysium.school) — template gone
- **#16** (divine.domain duplicates elysium.domain) — same
- **#12** (weapon.elysium.force "M" string default mismatch) — same

### 2. Fix system.json side-finding #6 (htmlFields phantom field)

`system.json`'s `documentTypes.Item.<type>.htmlFields` declarations reference
`gmNotes` rather than `gmDescription`. This is a pre-existing manifest bug from
the v0.20.0 rules-module-fold era. The stored field has always been
`gmDescription`; the manifest entries point at a phantom field that doesn't
exist on any DataModel.

**Action**: grep `system.json` for `gmNotes`. For each occurrence in `htmlFields`
arrays, either:
- (a) replace with `gmDescription` (the actual field name); OR
- (b) remove `gmNotes` from the array if `description` is the only other field

Decision criterion: option (a) is safer — Foundry uses htmlFields to know which
fields to invoke the ProseMirror editor on. Both `description` and `gmDescription`
are real HTMLFields per `makeItemBase()`, so both should be in htmlFields.

23/23 item type declarations affected. Affects no DataModels — purely manifest cleanup.

### 3. Capture visual regression baselines for representative item sheets

Per the P5.3 pattern: render representative item sheets and snapshot them via the
`test/visual-regression/` harness for future-version diff detection.

**Representative sheets to capture** (1 per major category):
- 1 weapon (e.g., compendium "Longsword" dropped onto a character)
- 1 armor (e.g., compendium "Cloak of Resistance")
- 1 skill (e.g., compendium "Athletics")
- 1 spell (suggest: compendium arcane "Magic Missile" — exercises the deepest schema)

Snapshot filenames following P5.3 convention:
- `test/visual-regression/baseline/alpha10-weapon-detail-dark.snapshot.json`
- `test/visual-regression/baseline/alpha10-armor-detail-dark.snapshot.json`
- `test/visual-regression/baseline/alpha10-skill-detail-dark.snapshot.json`
- `test/visual-regression/baseline/alpha10-arcane-detail-dark.snapshot.json`

**Bridge caveat**: the Claude-in-Chrome bridge wedges when ProseMirror-rendered sheets
are left open across javascript_tool calls (side-finding #5 from P6.0 audit).
Workflow: render + snapshot + close in the same eval. The P5.3 actor-sheet captures
used this pattern successfully.

### 4. Final acceptance pass

The "did we actually finish P6" gate:

1. **Full type creation sweep** — create one of each of 23 item types + 2 actor
   types; all 25 `instanceof <Type>DataModel` checks pass.
2. **Render sweep** — render-and-close the sheet for one of each item type to
   verify no template/handlebars errors fire. (Console clear, then render, then
   check console for errors.)
3. **Persistence sweep** — write one field per type, read back. Sample one per
   category (top-level Number, top-level String, elysium.X nested, deep nested
   for the magic types).
4. **Compendium drop sweep across all 23 types** — one of each from compendium
   onto a fresh character. Zero validation errors. The exhaustive version of the
   per-phase compendium drop tests.
5. **Existing-world load** — confirm that the 4 pre-existing actors load cleanly
   (no validation errors at boot). This catches any P5-era schema gaps that
   missed earlier audits.

If all 5 pass: P6 is COMPLETE. Update ROADMAP P6 row from "queued" to "✅".

---

## Project discipline (carries forward)

These are the rules that have produced 5 clean sub-phases in one day. Worth keeping
for P6.6.

- **"Best long-term over fastest"** — verify-each-step. Each sub-phase ships its own
  alpha, gets a smoke test, hands off cleanly.
- **Stored-schema-only DataModels** (P3/P5 decision) — DataModels declare the stored
  shape, nothing else. `ElysiumActor.prepareDerivedData` and per-sheet
  `_prepareContext` continue to populate derived fields. Do NOT move them.
- **Sparse field declarations per type** — declare each field with its real type
  (NumberField/StringField/BooleanField/etc.) not generic ObjectField unless the
  shape is genuinely unknown.
- **TypedObjectField (or fixed-key SchemaField) for dynamic-shape objects** —
  but use fixed-key SchemaField when audit confirms a stable key set (effectByTier,
  thresholds, baseFormula).
- **Stop and check in after each sub-phase smoke-test passes.** Bumping versions
  per sub-phase makes rollback trivial.
- **Side findings are documented but NOT fixed during their scope phase**
  (orthogonal work). 18 logged for P12.
- **Audit BEFORE coding.** Every P6.* sub-phase has a prep audit doc. Audits caught:
  - 11 compendium-only fields (would have caused production drop failures)
  - 1 critical type mismatch (weapon.elysium.force "M" string vs int)
  - 1 template typo (skill.category cmmnmod vs comnmod)
  - 8 documentation-only fields that don't belong in schemas
  - 1 latent P5 issue (#18 ancestryMove silent drop)

---

## Side findings logged for P12 (or P6.6 auto-resolution)

The 18 cumulative side findings flagged across P5/P6 sessions. None are
functional defects in the new code; all represent pre-existing tech debt
documented as `P12: Schema-Wide Audit Sweep` work.

| # | Finding | Resolution Path |
|---|---|---|
| 1 | patron.standing/statNaturalMax flags.elysium write paired with system.elysium write (silent no-op) | P12 |
| 2 | dropped character-elysium fields theoretical migration risk | P12 |
| 3 | distincitve typo dropped | already resolved |
| 4 | capture.mjs uses CHARACTER_SHEET_MARKERS for any Actor type — NPC matches only 1/10 | P12 |
| 5 | Chrome bridge wedge pattern characterized | environmental, no action |
| 6 | system.json htmlFields references phantom gmNotes | **P6.6 fixes this** |
| 7 | wound.created dead field — dropped | already resolved |
| 8 | equipStatus normalizer/choices interaction — free StringField | P12 (Foundry-feature-dependent) |
| 9 | culture.elysium.ancestry.statMods uppercase vs actor lowercase | P12 |
| 10 | culture.elysium.ancestry.{naturalWeapons, resistances, subraces} permissive shapes | P12 |
| 11 | super.favouredEnemy.isfavouredEnemy typo preserved | P12 (rename + migration shim) |
| 12 | weapon.elysium.force template default "M" type-incorrect | **P6.6 auto-resolves via template deletion** |
| 13 | creatureType field-name collision (actor vs hit-location) | P12 (rename one) |
| 14 | Compendium-only zero-reader fields across many types | P6.6 or beyond (regenerate compendium) |
| 15 | arcane.spellCat duplicates arcane.elysium.school | **P6.6 auto-resolves via template deletion** |
| 16 | divine.domain (top) duplicates divine.elysium.domain | **P6.6 auto-resolves via template deletion** |
| 17 | template skill.category typo 'cmmnmod' (correct: 'comnmod') | **P6.6 auto-resolves via template deletion** |
| 18 | CharacterDataModel doesn't declare elysium.ancestryMove but ancestry-drop.mjs:367 writes to it | P12 |

**Five findings auto-resolve via P6.6's template deletion.** The others stay logged
for P12.

---

## Reference: phase-specific audit docs (carried forward in system tree)

Each P6.* sub-phase produced its own audit doc. They contain the specific design
reasoning for every schema decision. For deep questions on any specific type, read
the matching audit doc:

- `docs/datamodel-design.md` — overall design principles (from P3)
- `docs/p5-prep-audit.md` — actor audit
- `docs/p5-2-handoff.md` — character DataModel spec
- `docs/p6-prep-audit.md` — overall P6 audit + crosscutting decisions
- `docs/p6-2-handoff.md` — P6.2 audit (8 standard items)
- `docs/p6-3-handoff.md` — P6.3 audit (combat items)
- `docs/p6-4-handoff.md` — P6.4 audit (magic items, the deepest schemas)
- `docs/p6-5-handoff.md` — P6.5 audit (profession + skill)
- This doc (`p6-6-handoff.md`) — P6.6 plan

There is no `p6-1-handoff.md` per se — P6.1 was rolled in with the P6.0 prep audit.

---

## Environment & tooling notes

- **Live test world**: https://elysiumvtt.com/game (test-2 world, Foundry 14.361, GM
  logged in)
- **Source tree**: `/home/claude/work/system/`
- **Compendium tree** (read-only audit reference):
  `/home/claude/work/compendium/extracted/packs/`
- **Packaging output**: `/mnt/user-data/outputs/system.zip` + `system.json` siblings
- **Smoke test pattern**: Boot → Create → Defaults → Persistence →
  Compendium-drop → Regression → Cleanup. Each step its own `javascript_exec`
  to avoid bridge wedge.
- **Critical bridge limitation**: rendering sheets in a long-lived eval wedges
  the bridge. Workaround for visual regression: capture + close in the same eval.

---

## How smoke tests have been structured

Per-phase pattern that worked well across 5 phases:

1. **Boot**: confirm version, registrations, field counts via
   `CONFIG.Item.dataModels[type].schema.fields`
2. **Create**: `Item.create({type, name: 'P6.N Smoke <type>'})` for each new
   type; `instanceof` checks
3. **Defaults**: spot-check spec'd values per type
4. **Persistence**: write per field-class type (Number/String/Bool/HTML/SchemaField/
   ArrayField variants/nullable); covered each phase
5. **Compendium drop test** (the critical one): drop one of each compendium-having
   type from compendium onto a fresh character via `createEmbeddedDocuments`;
   ZERO validation errors expected; verify data integrity for compendium-only
   fields
6. **Regression**: prior phases' types + actor types still create and work
7. **Cleanup**: delete all P6.N-prefixed items + actors, leave the world clean

For P6.6 the structure is similar but the "Create" + "Persistence" steps become
exhaustive (all 23 types, not just new ones) and the new step is "Render".

---

## Recent CHANGELOG sections (in `CHANGELOG.md`)

```
## [1.0.0-alpha.9] — P6.5 final-pair item DataModels (profession + skill)
## [1.0.0-alpha.8] — P6.4 magic-item DataModels
## [1.0.0-alpha.7] — P6.3 hotfix: weaponType blank-string acceptance
## [1.0.0-alpha.6] — P6.3 combat-item DataModels (superseded by alpha.7)
## [1.0.0-alpha.5] — P6.2 standard-complexity item DataModels
## [1.0.0-alpha.4] — P6.0 audit + P6.1 trivial-item DataModels
## [1.0.0-alpha.3] — P5.3 Actor acceptance
## [1.0.0-alpha.2] — P5.2 Character DataModel
## [1.0.0-alpha.1] — Foundation
```

---

## What's next after P6 (for context only — NOT P6.6 work)

P6 is the second-to-last major phase of the v1.0.0 rebuild. After P6:
- **P7**: ActiveEffect rebuild (separate effort)
- **P8-P11**: each addresses one major subsystem (combat, damage, magic, etc.)
- **P12**: Schema-wide audit sweep — resolves the 18 logged side findings
- **P13**: v1.0.0-rc.1 release candidate

The current pace suggests P12 alone is 2-3 days of focused work, since each
side finding requires its own audit + fix + migration consideration.

---

## Bookmark for the next session

Pick up here:
1. Read this doc completely.
2. Read `docs/p6-prep-audit.md` for the overall P6 context.
3. Confirm the source tree contents match the manifest at the top of this doc.
4. Run the P6.6 plan in order (template deletion → htmlFields fix → visual
   regression baselines → acceptance pass).
5. Bump version to `1.0.0-alpha.10`. Ship.

P6 closes when alpha.10 is green.
