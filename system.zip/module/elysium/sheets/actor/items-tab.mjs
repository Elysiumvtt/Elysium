// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

export function injectContainerNesting (html, actor) {
    // Find every equipment list on the sheet (currently one, but the
    // selector is defensive in case sub-tabs ever split it).
    const lists = html.querySelectorAll('ol.gr-list')
    if (!lists.length) return

    for (const list of lists) {
      // Idempotency guard
      if (list.dataset.elysiumNested === 'true') continue

      // Collect rows + classify
      const rows = Array.from(list.querySelectorAll('li.item[data-item-id]'))
      if (rows.length === 0) continue

      // Build a lookup of {itemId → {row, item, containedIn, isContainer}}
      const entries = []
      const renderedIds = new Set()
      for (const row of rows) {
        const itemId = row.dataset.itemId
        if (!itemId) continue
        const item = actor.items.get(itemId)
        if (!item || item.type !== 'gear') continue
        const sys = item.system?.elysium || {}
        entries.push({
          row,
          item,
          itemId,
          containedIn: sys.containedIn || '',
          isContainer: sys.isContainer === true,
        })
        renderedIds.add(itemId)
      }
      if (entries.length === 0) continue

      // Walk entries: any row whose containedIn references a rendered
      // container becomes a "child" of that container.
      // Build parent→children map.
      const childrenByParent = new Map()
      const orphans = []
      const containers = []
      for (const e of entries) {
        if (e.containedIn && renderedIds.has(e.containedIn)) {
          if (!childrenByParent.has(e.containedIn)) {
            childrenByParent.set(e.containedIn, [])
          }
          childrenByParent.get(e.containedIn).push(e)
        } else if (e.isContainer) {
          containers.push(e)
        } else {
          orphans.push(e)
        }
      }

      // Sort each child group alphabetically (matches BRP-base's default sort)
      for (const kids of childrenByParent.values()) {
        kids.sort((a, b) => a.item.name.localeCompare(b.item.name))
      }
      containers.sort((a, b) => a.item.name.localeCompare(b.item.name))
      orphans.sort((a, b) => a.item.name.localeCompare(b.item.name))

      // Build the new ordering:
      //   container, ...its children, container, ...its children, ...orphans
      // We rebuild by moving DOM nodes in place — they keep their event
      // listeners since we use appendChild on the same parent.
      const newOrder = []
      for (const container of containers) {
        newOrder.push(container)
        const kids = childrenByParent.get(container.itemId) || []
        for (const kid of kids) {
          newOrder.push(kid)
        }
      }
      // Children whose parent isn't a container in the rendered list
      // (rare — possibly orphaned references). Append them as orphans
      // so they don't disappear from the UI.
      for (const [parentId, kids] of childrenByParent.entries()) {
        const parentRendered = containers.some(c => c.itemId === parentId)
        if (!parentRendered) {
          orphans.push(...kids)
        }
      }
      for (const orphan of orphans) {
        newOrder.push(orphan)
      }

      // Apply: move each row to the end of the list in the desired order.
      // Stamp depth class for indentation.
      for (const e of newOrder) {
        // Remove any prior indent class (defensive on re-renders)
        e.row.classList.remove('elysium-gear-nested')
        e.row.classList.remove('elysium-gear-container')
        // Container rows get an icon class (CSS adds a folder glyph)
        if (e.isContainer) {
          e.row.classList.add('elysium-gear-container')
        }
        // Children get the indent class
        if (e.containedIn && renderedIds.has(e.containedIn)) {
          e.row.classList.add('elysium-gear-nested')
          // Tooltip on the name cell showing the container
          const nameCell = e.row.querySelector('.font14')
          if (nameCell) {
            const container = entries.find(x => x.itemId === e.containedIn)
            if (container) {
              nameCell.dataset.elysiumContainer = container.item.name
            }
          }
        }
        list.appendChild(e.row)
      }

      list.dataset.elysiumNested = 'true'
    }
  }
