import { BRPactorItemDrop } from './actor-itemDrop.mjs'
import { BRPID } from '../elysiumid/elysiumid.mjs';

export class BRPActor extends Actor {

  prepareData() {
    super.prepareData();
  }

  prepareBaseData() {
    this.system.elysiumidFlagItems = {}
    for (const i of this.items) {
      if (i.flags.elysium?.elysiumidFlag?.id) {
        const parts = i.flags.elysium?.elysiumidFlag?.id.match(/^([^\.]+)\.([^\.]+)\.([^\.]+)$/)
        if (parts) {
          if (typeof this.system.elysiumidFlagItems[parts[1]] === 'undefined') {
            this.system.elysiumidFlagItems[parts[1]] = {}
          }
          if (typeof this.system.elysiumidFlagItems[parts[1]][parts[2]] === 'undefined') {
            this.system.elysiumidFlagItems[parts[1]][parts[2]] = {}
          }
          this.system.elysiumidFlagItems[parts[1]][parts[2]][parts[3]] = i
        }
      }
    }
  }

  prepareDerivedData() {
    const actorData = this;
    const systemData = actorData.system;
    const flags = actorData.flags.boilerplate || {};

    //Prepare data for different actor types
    this._prepareCharacterData(actorData);
    this._prepareNpcData(actorData);
  }

  //Prepare Character specific data
  async _prepareCharacterData(actorData) {
    if (actorData.type !== 'character') return;
    const systemData = actorData.system;
    this._prepStats(actorData)
    this._prepDerivedStats(actorData)

    systemData.health.value = systemData.health.max;

    //Initialise Powers IDs
    systemData.magic = "";
    systemData.mutation = "";
    systemData.psychic = "";
    systemData.sorcery = "";
    systemData.super = "";

    //Initialise health statuses and other values
    systemData.dead = false;
    systemData.severed = false;
    systemData.unconscious = false;
    systemData.injured = false;
    systemData.incapacitated = false;
    systemData.bleeding = false
    systemData.enc = 0;
    systemData.av1 = 0;
    systemData.av2 = 0;
    systemData.avr1 = "";
    systemData.avr2 = "";
    systemData.psCurr = 0;
    systemData.psMax = 0;

    //Set Hit Location AP to zero
    for (let itm of actorData.items) {

      if (itm.type === 'hit-location') {
        itm.system.av1 = 0
        itm.system.av2 = 0
        itm.system.avr1 = ""
        itm.system.avr2 = ""
        itm.system.enc = 0
        itm.system.ppCurr = 0
        itm.system.pSCurr = 0
        itm.system.mnplmod = 0
        itm.system.percmod = 0
        itm.system.physmod = 0
        itm.system.stealthmod = 0
      }
    }

    //Calculate Skill Category Bonuses
    for (let itm of actorData.items) {
      if (itm.type === 'skillcat') {
        let bonus = 0;
        if (game.settings.get('elysium', 'skillBonus') === "1" && itm.system.stat != 'none') {
          bonus = Math.ceil(systemData.stats[itm.system.stat].total / 2);
        } else if (game.settings.get('elysium', 'skillBonus') === "2") {
          for (let [key, value] of Object.entries(itm.system.attrib)) {
            if (key === 'edu' && !game.settings.get('elysium', 'useEDU')) { continue }

            switch (value) {
              case "0":    //No adjustment
                break;
              case "1":    //Primary
                bonus += this._categoryprimary(systemData.stats[key].total)
                break;
              case "2":    //Secondary
                bonus += this._categorysecondary(systemData.stats[key].total)
                break;
              case "3":    //Negative
                bonus += this._categorynegative(systemData.stats[key].total)
                break;
              case "4":    //Negative Secondary
                bonus += this._categorynegsec(systemData.stats[key].total)
                break;
            }
          }
        }
        itm.system.bonus = bonus
        itm.system.total = itm.system.bonus + itm.system.mod
        let key = itm.flags.elysium.elysiumidFlag.id
        systemData.skillcategory[key] = itm.system.total;
      }
    }
    let effects = actorData.effects.map(i=> {return {origin: i.origin} })
    //Calcualte/adjust scores for items (itm)
    for (let itm of actorData.items) {

      /*Replaced with code below as not correctly applying to weapons
      //Does the item have transferrable effects
      if (['gear', 'armour', 'weapon','wound'].includes(itm.type)) {
        if (itm.transferredEffects.length > 0) {
          itm.system.hasEffects = true;
        } else {
          itm.system.hasEffects = false;
        }
      }*/

      //Does the item have transferrable effects
      if (['gear', 'armour', 'weapon','wound'].includes(itm.type)) {
          itm.system.hasEffects = false;
        for (let effect of effects) {
          if (effect.origin === itm.uuid) {
            itm.system.hasEffects = true;
          }
        }
      }

      //If skill, magic or psychic calculate the total score and record the category bonus
      if (itm.type === 'skill' || itm.type === 'magic' || itm.type === 'psychic') {
        itm.system.total = itm.system.base + itm.system.xp + itm.system.effects + itm.system.profession + itm.system.personality + itm.system.personal + itm.system.culture
        itm.system.catBonus = systemData.skillcategory[itm.system.category]

        //If Allegiance the set total and potential Ally status
      } else if (itm.type === 'allegiance') {
        itm.system.total = itm.system.allegPoints + itm.system.xp
        itm.system.potAlly = false

        //If Passion the set total
      } else if (itm.type === 'passion') {
        itm.system.total = itm.system.base + itm.system.xp

        //If Personality Trait the set total
      } else if (itm.type === 'persTrait') {
        itm.system.total = Math.max(0, Math.min(100, itm.system.base + itm.system.xp))
        itm.system.opptotal = 100 - itm.system.total

        //If Reputation set total
      } else if (itm.type === 'reputation') {
        itm.system.total = itm.system.base

        //If gear/weapon, calculates the encumbrance
      } else if (['gear', 'weapon'].includes(itm.type)) {
        if (itm.system.equipStatus === 'carried') {
          itm.system.actlEnc = itm.system.quantity * itm.system.enc
          systemData.enc = Number(systemData.enc + itm.system.actlEnc)
        } else { itm.system.actlEnc = 0 }

        if (itm.system.equipStatus != 'stored') {
          if (itm.system.pSCurr > 0) { systemData.psCurr = systemData.psCurr + itm.system.pSCurr }
          if (itm.system.pSMax > 0) { systemData.psMax = systemData.psMax + itm.system.pSMax }
        }



        //If armour
      } else if (itm.type === 'armour') {
        //Calc encumbrance based on carry status and if using HPL
        itm.system.actlEnc = 0
        if (itm.system.equipStatus === 'carried') {
          if (game.settings.get('elysium', 'useHPL')) {
            itm.system.actlEnc = Math.round(itm.system.quantity * itm.system.enc / actorData.items.get(itm.system.hitlocID).system.fractionENC * 10) / 10
          } else {
            itm.system.actlEnc = Number(itm.system.quantity * itm.system.enc)
          }
          //If not carried then zero ENC
        }
        systemData.enc = systemData.enc + itm.system.actlEnc
        if (itm.system.equipStatus != 'stored') {
          if (itm.system.pSCurr > 0) { systemData.psCurr = systemData.psCurr + itm.system.pSCurr }
          if (itm.system.pSMax > 0) { systemData.psMax = systemData.psMax + itm.system.pSMax }
          if (game.settings.get('elysium', 'useHPL')) {
            let hitLoc = actorData.items.get(itm.system.hitlocID)
            hitLoc.system.ppCurr += itm.system.ppCurr
            hitLoc.system.pSCurr += Number(itm.system.pSCurr)
          }
        }

        //Add penalty mods when worn (regardless of layering)
        if (itm.system.equipStatus === 'worn') {
          if (game.settings.get('elysium', 'useHPL')) {
            let hitLoc = actorData.items.get(itm.system.hitlocID)
            hitLoc.system.mnplmod   += itm.system.mnplmod
            hitLoc.system.percmod   += itm.system.percmod
            hitLoc.system.physmod   += itm.system.physmod
            hitLoc.system.stealthmod += itm.system.stealthmod
          }
        }

        if (game.settings.get('elysium', 'useHPL')) {
          let hitLoc = actorData.items.get(itm.system.hitlocID)
          hitLoc.system.enc += itm.system.actlEnc
        }
        //If power then record the ID against the category
      } else if (itm.type === 'power') {
        systemData[itm.system.category] = itm._id;
      } else if (itm.type === 'profession') {
        systemData.profession = itm.name
        systemData.professionId = itm._id;
        //If hit locations calculation HPL max and current and statuses
      } else if (itm.type === 'hit-location' && game.settings.get('elysium', 'useHPL')) {
        itm.system.injured = false;
        itm.system.maxHP = Math.max((Math.ceil(systemData.health.max / itm.system.fractionHP) + itm.system.adj), 0);
        itm.system.currHP = itm.system.maxHP
        //Loop through items (wnd) to find wounds
        for (let wnd of actorData.items) {
          if (wnd.type === 'wound' && wnd.system.locId === itm._id) {
            itm.system.currHP = itm.system.currHP - wnd.system.value
          }
        }
        if (itm.system.currHP < 1 && itm.system.locType === 'limb') {
          itm.system.injured = true
        } else if (itm.system.currHP < 1 && itm.system.locType === 'abdomen') {
          itm.system.injured = true
          systemData.injured = true
        } else if (itm.system.currHP < 1 && itm.system.locType === 'chest') {
          itm.system.incapacitated = true
          systemData.incapacitated = true
        } else if (itm.system.currHP < 1 && itm.system.locType === 'head') {
          itm.system.unconscious = true
          systemData.unconscious = true
        }
        if (itm.system.bleeding) { systemData.bleeding = true }
        if (itm.system.unconscious) { systemData.unconscious = true }
        if (itm.system.incapacitated) { systemData.incapacitated = true }
        if (itm.system.severed) { systemData.severed = true }
        if (itm.system.dead) { systemData.dead = true }
        //If wound calculate total HPL
      } else if (itm.type === 'wound') {
        systemData.health.value = systemData.health.value - itm.system.value
      }

    }

    // ── WFRP 4E Armour Layering Pass ────────────────────────────────────────
    // Rules (per WFRP 4E core):
    //   • Flexible armour worn UNDER inflexible on the same location contributes
    //     only 1 AP (regardless of its actual AV).
    //   • Two inflexible pieces on the same location: only the best (highest AV)
    //     counts; the lesser is ignored entirely.
    //   • Flexible + Flexible: both contribute fully.
    //   • layerOrder field: lower number = closer to skin (worn first).
    //     If layerOrder is equal, inflexible beats flexible for priority.
    this._applyWfrpArmourLayering(actorData)

    //Calculate allegiance target
    let allegiances = actorData.items.filter(itm => itm.type === 'allegiance')
    allegiances.sort(function (a, b) {
      let x = a.system.total;
      let y = b.system.total;
      if (x < y) { return 1 };
      if (x > y) { return -1 };
      return 0;
    });
    //If there is one allegiance
    let ally = ""
    if (allegiances.length === 1 && allegiances[0].system.total >= 20) {
      actorData.items.get(allegiances[0]._id).system.potAlly = true
    } else if (allegiances.length > 1 && (allegiances[0].system.total - allegiances[1].system.total) >= 20) {
      actorData.items.get(allegiances[0]._id).system.potAlly = true
    }


    //Round ENC to 2 decimals and then adjust fatigue
    systemData.enc = (systemData.enc).toFixed(2)
    systemData.fatigue.max = Math.ceil(systemData.stats.str.total + systemData.stats.con.total - systemData.enc + systemData.fatigue.mod + (systemData.fatigue.effects ?? 0));

    //Derive Health Statuses from total HP
    if (systemData.health.value < 1) {
      systemData.dead = true;
    } else if (systemData.health.value < 3) {
      systemData.unconscious = true;
    }



  }

  //Prepare NPC specific data.
  async _prepareNpcData(actorData) {
    if (actorData.type !== 'npc') return;
    const systemData = actorData.system;
    this._prepStats(actorData)
    this._prepDerivedStats(actorData)

    for (let [key, stat] of Object.entries(actorData.system.baseStats)) {
      stat.label = game.i18n.localize(CONFIG.Elysium.stats[key]) ?? key;
      stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
      //Mark all stats as visible except for EDU where it's not being used
      stat.visible = true;
      if (key === 'edu' && !game.settings.get('elysium', 'useEDU')) { stat.visible = false }
    }


    let damage = 0
    systemData.fatigue.max = Math.ceil(systemData.stats.str.total + systemData.stats.con.total + systemData.fatigue.mod + (systemData.fatigue.effects ?? 0));

    for (let itm of actorData.items) {
      if (['skill', 'psychic', 'magic', 'passion', 'reputation'].includes(itm.type)) {
        itm.system.total = itm.system.base + (itm.system.effects ?? 0);
      } else if (['allegiance'].includes(itm.type)) {
        itm.system.total = itm.system.allegPoints;
      } else if (['persTrait'].includes(itm.type)) {
        itm.system.total = itm.system.base;
        itm.system.opptotal = 100 - itm.system.base;
      }
      else if (itm.type === 'hit-location' && (game.settings.get('elysium', 'useHPL') || game.settings.get('elysium', 'beastiary'))) {
        itm.system.injured = false;
        itm.system.maxHP = Math.max((Math.ceil(systemData.health.max / itm.system.fractionHP) + itm.system.adj), 0);
        damage = damage + Math.max(itm.system.maxHP - itm.system.currHP, 0)
      }
    }

    //If using HPL then set current health
    if (game.settings.get('elysium', 'useHPL') || game.settings.get('elysium', 'beastiary')) {
      systemData.health.value = systemData.health.max - damage
    }
  }


  getRollData() {
    const data = super.getRollData();

    // Prepare character roll data.
    this._getCharacterRollData(data);
    this._getNpcRollData(data);

    return data;
  }

  // Prepare character roll data.
  _getCharacterRollData(data) {
    if (this.type !== 'character') return;

    // Copy the ability scores to the top level
    if (data.stats) {
      for (let [k, v] of Object.entries(data.stats)) {
        data[k] = foundry.utils.deepClone(v);
      }
    }
  }

  // Prepare NPC roll data
  _getNpcRollData(data) {
    if (this.type !== 'npc') return;
  }


  //Prepare Stats
  _prepStats(actorData) {
    // Loop through ability scores, calculating total and derived scores
    actorData.system.redistInc = 0
    actorData.system.redistDec = 0
    for (let [key, stat] of Object.entries(actorData.system.stats)) {
      stat.label = game.i18n.localize(CONFIG.Elysium.stats[key]) ?? key;
      stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
      stat.labelDeriv = game.i18n.localize(CONFIG.Elysium.statsDerived[key]) ?? key;
      stat.total = Number(stat.base) + Number(stat.redist) + Number(stat.culture) + Number(stat.exp) + Number(stat.effects) + Number(stat.age);
      stat.deriv = stat.total * 5;
      if (stat.redist < 0) { actorData.system.redistDec = actorData.system.redistDec + stat.redist }
      if (stat.redist > 0) { actorData.system.redistInc = actorData.system.redistInc + stat.redist }

      //Mark all stats as visible except for EDU where it's not being used
      stat.visible = true;
      if (key === 'edu' && !game.settings.get('elysium', 'useEDU')) { stat.visible = false }
    }
    if (actorData.type === 'npc')
      for (let [key, stat] of Object.entries(actorData.system.baseStats)) {
        stat.labelShort = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[key]) ?? key;
        //Mark all stats as visible except for EDU where it's not being used
        stat.visible = true;
        if (key === 'edu' && !game.settings.get('elysium', 'useEDU')) { stat.visible = false }
      }
    actorData.system.redistTotal = actorData.system.redistInc + actorData.system.redistDec
  }

  // Calculate derived scores
  _prepDerivedStats(actorData) {
    let systemData = actorData.system
    if (actorData.type === 'character') {
      systemData.health.max = Math.ceil((systemData.stats.con.total + systemData.stats.siz.total) * game.settings.get('elysium', 'hpMod') / 2) + systemData.health.mod + (systemData.health.effects ?? 0);
    } else {
      let health = 0
      let formula = ""
      let statCount = 0
      if (systemData.hp.stat1 != 'none') {
        health += systemData.stats[systemData.hp.stat1].total
        statCount++
        formula = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[systemData.hp.stat1])
      }
      if (systemData.hp.stat2 != 'none') {
        health += systemData.stats[systemData.hp.stat2].total
        statCount++
        if (statCount === 2) { formula = formula + " + " }
        formula = formula + game.i18n.localize(CONFIG.Elysium.statsAbbreviations[systemData.hp.stat2])
      }
      health = Math.ceil(health * systemData.hp.multi)
      if (statCount === 1) {
        formula = "(" + formula + " * " + systemData.hp.multi + ")"
      } else if (statCount === 2) {
        formula = "((" + formula + ") * " + systemData.hp.multi + ")"
      }
      if (systemData.health.mod < 0) {
        formula = formula + " " + systemData.health.mod
      } else if (systemData.health.mod > 0) {
        formula = formula + " + " + systemData.health.mod
      }
      systemData.hp.formula = formula
      systemData.health.max = health + (systemData.health.mod ?? 0) + (systemData.health.effects ?? 0);
    }
    systemData.health.mjrwnd = Math.ceil(systemData.health.max / 2);
    systemData.power.max = systemData.stats.pow.total + systemData.power.mod + (systemData.power.effects ?? 0);
    systemData.xpBonus = Math.ceil(systemData.stats.int.total / 2);
    systemData.dmgBonus = this._damageBonus(systemData.stats.str.total + systemData.stats.siz.total)
    systemData.dmgSpecBonus = this._damageBonus(systemData.stats.str.total * 2)

    //Set Resource Labels
    if (game.settings.get('elysium', 'ppLabelLong')) {
      systemData.power.label = game.settings.get('elysium', 'ppLabelLong')
    } else {
      systemData.power.label = game.i18n.localize('BRP.pp')
    }
    if (game.settings.get('elysium', 'ppLabelShort')) {
      systemData.power.labelAbbr = game.settings.get('elysium', 'ppLabelShort')
    } else {
      systemData.power.labelAbbr = game.i18n.localize('BRP.ppShort')
    }
    if (game.settings.get('elysium', 'hpLabelLong')) {
      systemData.health.label = game.settings.get('elysium', 'hpLabelLong')
    } else {
      systemData.health.label = game.i18n.localize('BRP.health')
    }
    if (game.settings.get('elysium', 'hpLabelShort')) {
      systemData.health.labelAbbr = game.settings.get('elysium', 'hpLabelShort')
    } else {
      systemData.health.labelAbbr = game.i18n.localize('BRP.hp')
    }
    if (game.settings.get('elysium', 'fpLabelLong')) {
      systemData.fatigue.label = game.settings.get('elysium', 'fpLabelLong')
    } else {
      systemData.fatigue.label = game.i18n.localize('BRP.fatigue')
    }
    if (game.settings.get('elysium', 'fpLabelShort')) {
      systemData.fatigue.labelAbbr = game.settings.get('elysium', 'fpLabelShort')
    } else {
      systemData.fatigue.labelAbbr = game.i18n.localize('BRP.fp')
    }
    if (game.settings.get('elysium', 'sanLabelLong')) {
      systemData.sanity.label = game.settings.get('elysium', 'sanLabelLong')
    } else {
      systemData.sanity.label = game.i18n.localize('BRP.sanity')
    }
    if (game.settings.get('elysium', 'sanLabelShort')) {
      systemData.sanity.labelAbbr = game.settings.get('elysium', 'sanLabelShort')
    } else {
      systemData.sanity.labelAbbr = game.i18n.localize('BRP.san')
    }
    if (game.settings.get('elysium', 'sanLabelLoss')) {
      systemData.sanity.labelLoss = game.settings.get('elysium', 'sanLabelLoss')
    } else {
      systemData.sanity.labelLoss = game.i18n.localize('BRP.sanLoss')
    }
    if (game.settings.get('elysium', 'res5LabelLong')) {
      systemData.res5.label = game.settings.get('elysium', 'res5LabelLong')
    } else {
      systemData.res5.label = game.i18n.localize('BRP.res5')
    }
    if (game.settings.get('elysium', 'res5LabelShort')) {
      systemData.res5.labelAbbr = game.settings.get('elysium', 'res5LabelShort')
    } else {
      systemData.res5.labelAbbr = game.i18n.localize('BRP.res5Abbr')
    }
  }

  //Used for Rolling NPCs when token dropped
  get hasRollableCharacteristics() {
    for (const [, value] of Object.entries(this.system.baseStats)) {
      if (isNaN(Number(value.random))) return true
      if (isNaN(Number(value.average))) return true
    }
    return false
  }

  //Roll Random Stats
  async rollCharacteristicsValue() {
    const stats = {}
    for (const [key, value] of Object.entries(this.system.baseStats)) {
      if (value.random && !value.random.startsWith('@')) {
        const r = new Roll(value.random)
        await r.evaluate()
        if (r.total) {
          stats[`system.stats.${key}.base`] = Math.floor(
            r.total
          )
        }
      }
    }
    await this.update(stats)
    await this.updateVitals()
  }

  //Roll Average Stats
  async averageCharacteristicsValue() {
    const stats = {}
    for (const [key, value] of Object.entries(this.system.baseStats)) {
      if (value.average && !value.average.startsWith('@')) {
        const r = new Roll(value.average)
        await r.evaluate()
        if (r.total) {
          stats[`system.stats.${key}.base`] = Math.floor(
            r.total
          )
        }
      }
    }
    await this.update(stats)
    await this.updateVitals()
  }

  //Update Current HP, FP etc and HPL when Rolled or Average Roll
  async updateVitals() {
    let checkProp = {
      'system.health.value': this.system.health.max,
      'system.power.value': this.system.power.max,
      'system.fatigue.value': this.system.fatigue.max,
      'system.sanity.value': this.system.sanity.max
    }
    await this.update(checkProp)
    if (game.settings.get('elysium', 'useHPL')) {
      let hitLocs = this.items.filter(itm => itm.type === 'hit-location').map(itm => {
        return { _id: itm.id, 'system.currHP': itm.system.maxHP }
      })
      await Item.updateDocuments(hitLocs, { parent: this })
    }
  }

  //Create a new actor - When creating an actor set basics including tokenlink, bars, displays sight
  static async create(data, options = {}) {
    //If dropping from compendium check to see if the actor already exists in game.actors and if it does then get the game.actors details rather than create a copy
    if (options.fromCompendium) {
      let tempActor = await (game.actors.filter(actr => actr.flags?.brp?.elysiumidFlag?.id === data.flags.elysium.elysiumidFlag.id && actr.flags?.brp?.elysiumidFlag?.priority === data.flags.elysium.elysiumidFlag.priority))[0]
      if (tempActor) { return tempActor }
    }


    if (data.type === 'character') {
      data.prototypeToken = foundry.utils.mergeObject({
        actorLink: true,
        lockRotation: true,
        disposition: 1,
        displayName: CONST.TOKEN_DISPLAY_MODES.ALWAYS,
        displayBars: CONST.TOKEN_DISPLAY_MODES.ALWAYS,
        sight: {
          enabled: true,
          range: 30,
          visionMode:"basic"
        }
      }, data.prototypeToken || {})
    } else if (data.type === 'npc') {
      data.prototypeToken = foundry.utils.mergeObject({
        lockRotation: true,
        sight: {
          enabled: true,
          range: 30,
          visionMode:"basic"
        }
      }, data.prototypeToken || {})
    }

    let actor = await super.create(data, options)

    //Add BRPID based on actor name if the game setting is flagged.
    if (game.settings.get('elysium', "actorBRPID")) {
      let tempID = await BRPID.guessId(actor)
      if (tempID) {
        await actor.update({ 'flags.elysium.elysiumidFlag.id': tempID })
        const html = $(actor.sheet.element).find('header.window-header a.header-button.edit-brpid-warning,header.window-header a.header-button.edit-brpid-exisiting')
        if (html.length) {
          html.css({
            color: (tempID ? 'orange' : 'red')
          })
        }
        actor.render()
      }
    }


    //Set up a general hit location for a new actor if using HPL
    if (actor.type === 'character' && game.settings.get('elysium', 'useHPL')) {
      let brpid = "i.hit-location.general"

      const itemData = [{
        name: game.i18n.localize('BRP.general'),
        type: 'hit-location',
        img: 'systems/elysium/assets/Icons/arm-bandage.svg',
        flags: { elysium: { elysiumidFlag: { id: "i.hit-location.general" } } },
        system: {
          "fractionHP": 1,
          "fractionENC": 1,
          "lowRoll": 0,
          "highRoll": 0,
          "locType": "general"
        }
      }];
      const newItem = await Item.createDocuments(itemData, { parent: actor });
    }

    //Add Starter Skills if toggled on
    if (actor.type === 'character' && game.settings.get('elysium', 'starterSkills')) {
      let newSkills = []
      let skillList = (await game.system.api.elysiumid.fromBRPIDRegexBest({ brpidRegExp: new RegExp('^i.skill'), type: 'i' })).filter(itm => itm.system.basic)
      for (let itm of skillList) {
        if (actor.items.filter(nitm => nitm.flags.elysium.elysiumidFlag.id === itm.flags.elysium.elysiumidFlag.id).length < 1) {
          itm.system.base = await BRPactorItemDrop._calcBase(itm, actor);
          newSkills.push(itm);
        }
      }
      await Item.createDocuments(newSkills, { parent: actor });
      await BRPActor.charBaseSkillScores(actor);
    }

    //Add Starter Traits if toggled on
    if (actor.type === 'character' && game.settings.get('elysium', 'starterTraits') && game.settings.get('elysium', 'usePersTrait')) {
      let newTraits = []
      let traitList = (await game.system.api.elysiumid.fromBRPIDRegexBest({ brpidRegExp: new RegExp('^i.persTrait'), type: 'i' })).filter(itm => itm.system.basic)
      for (let itm of traitList) {
        if (actor.items.filter(nitm => nitm.flags.elysium.elysiumidFlag.id === itm.flags.elysium.elysiumidFlag.id).length < 1) {
          newTraits.push(itm);
        }
      }
      await Item.createDocuments(newTraits, { parent: actor });
    }



    //Add Skill Categories
    if (actor.type === 'character') {
      let newSkillCats = []
      let skillCatList = (await game.system.api.elysiumid.fromBRPIDRegexBest({ brpidRegExp: new RegExp('^i.skillcat'), type: 'i' }))
      for (let itm of skillCatList) {
        if (actor.items.filter(nitm => nitm.flags.elysium.elysiumidFlag.id === itm.flags.elysium.elysiumidFlag.id).length < 1) {
          newSkillCats.push(itm)
        }
      }
      await Item.createDocuments(newSkillCats, { parent: actor })
    }
    return actor
  }

  //Recalculate all skill base scores
  static async charBaseSkillScores(actor) {
    let change = []
    for (let itm of actor.items) {
      if (itm.type != 'skill') { continue }
      let baseScore = await BRPactorItemDrop._calcBase(itm, actor)
      change.push({ _id: itm._id, "system.base": baseScore })
    }
    await Item.updateDocuments(change, { parent: actor })
  }

  // Primary Skills Bonus
  _categoryprimary(statvalue) {
    var bonus = statvalue - 10;
    return bonus;
  }

  // Secondary Skills Bonus
  _categorysecondary(statvalue) {
    var bonus = (statvalue - 10) / 2
    if (bonus < 0) {
      bonus = Math.ceil(bonus);
    } else {
      bonus = Math.floor(bonus);
    }
    return bonus;
  }

  // Negative Skills Bonus
  _categorynegative(statvalue) {
    var bonus = 10 - statvalue;
    return bonus;
  }

  // Negative Secondary Skills Bonus
  _categorynegsec(statvalue) {
    var bonus = (10 - statvalue) / 2
    if (bonus < 0) {
      bonus = Math.ceil(bonus);
    } else {
      bonus = Math.floor(bonus);
    }
    return bonus;
  }

  // ── WFRP 4E Armour Layering ──────────────────────────────────────────────
  // Called after the main item loop so all worn armour is already catalogued.
  // Operates on both HPL mode (per hit-location) and non-HPL mode (global AV).
  _applyWfrpArmourLayering(actorData) {
    const systemData = actorData.system
    const useHPL = game.settings.get('elysium', 'useHPL')

    // Collect all worn armour pieces
    const wornArmour = actorData.items.filter(
      itm => itm.type === 'armour' && itm.system.equipStatus === 'worn'
    )

    if (useHPL) {
      // ── HPL mode: resolve per hit-location ──────────────────────────────
      // Reset hit-location AVs – the layering pass will repopulate them correctly
      for (const itm of actorData.items) {
        if (itm.type === 'hit-location') {
          itm.system.av1   = 0
          itm.system.av2   = 0
          itm.system.avr1  = ""
          itm.system.avr2  = ""
        }
      }

      // Group worn armour by hit-location ID
      const byLocation = {}
      for (const piece of wornArmour) {
        const locId = piece.system.hitlocID
        if (!locId) continue
        if (!byLocation[locId]) byLocation[locId] = []
        byLocation[locId].push(piece)
      }

      for (const [locId, pieces] of Object.entries(byLocation)) {
        const hitLoc = actorData.items.get(locId)
        if (!hitLoc) continue

        const resolved = BRPActor._resolveLayeredAV(pieces)
        hitLoc.system.av1  += resolved.av1
        hitLoc.system.av2  += resolved.av2
        if (resolved.avr1) hitLoc.system.avr1 += (hitLoc.system.avr1 ? "+" : "") + resolved.avr1
        if (resolved.avr2) hitLoc.system.avr2 += (hitLoc.system.avr2 ? "+" : "") + resolved.avr2

        // Stamp each piece with its effective AV so the sheet can display it
        for (const piece of pieces) {
          piece.system.effectiveAv1 = resolved.effectiveMap.get(piece._id)?.av1 ?? 0
          piece.system.layeringNote = resolved.effectiveMap.get(piece._id)?.note ?? ""
        }
      }

    } else {
      // ── Non-HPL mode: single global AV ──────────────────────────────────
      // Reset global AVs
      systemData.av1  = 0
      systemData.av2  = 0
      systemData.avr1 = ""
      systemData.avr2 = ""

      if (wornArmour.length === 0) return

      const resolved = BRPActor._resolveLayeredAV(wornArmour)
      systemData.av1  = resolved.av1
      systemData.av2  = resolved.av2
      systemData.avr1 = resolved.avr1
      systemData.avr2 = resolved.avr2

      for (const piece of wornArmour) {
        piece.system.effectiveAv1   = resolved.effectiveMap.get(piece._id)?.av1 ?? 0
        piece.system.layeringNote   = resolved.effectiveMap.get(piece._id)?.note ?? ""
      }
    }
  }

  // ── Static helper: resolve AV total from a set of armour pieces on one location
  // Returns { av1, av2, avr1, avr2, effectiveMap }
  // effectiveMap: Map<itemId, { av1, note }>  – what each piece actually contributes
  static _resolveLayeredAV(pieces) {
    // Sort by layerOrder ascending (lower = worn closer to skin), then flexible before inflexible
    const sorted = [...pieces].sort((a, b) => {
      const oa = a.system.layerOrder ?? 0
      const ob = b.system.layerOrder ?? 0
      if (oa !== ob) return oa - ob
      // Same order: flexible inner, inflexible outer
      const fa = a.system.flexibility === 'flexible' ? 0 : 1
      const fb = b.system.flexibility === 'flexible' ? 0 : 1
      return fa - fb
    })

    let totalAv1 = 0
    let totalAv2 = 0
    let totalAvr1 = ""
    let totalAvr2 = ""
    const effectiveMap = new Map()

    // Track whether an inflexible piece has already been applied on this location
    let hasInflexible = false

    for (const piece of sorted) {
      const flex = piece.system.flexibility ?? 'inflexible'
      let effectiveAv1 = piece.system.av1
      let note = ""

      if (flex === 'inflexible') {
        if (hasInflexible) {
          // Two inflexibles: the second (lower AV) is ignored entirely
          effectiveAv1 = 0
          note = game.i18n.localize('BRP.armourLayering.blockedByInflexible')
        } else {
          hasInflexible = true
          // Full AV applies
        }
      } else {
        // flexible piece
        if (hasInflexible) {
          // Worn under (or alongside) inflexible: capped at 1 AP
          if (effectiveAv1 > 1) {
            note = game.i18n.localize('BRP.armourLayering.reducedUnderInflexible')
          }
          effectiveAv1 = Math.min(effectiveAv1, 1)
        }
        // flexible under flexible: full AV (no restriction)
      }

      effectiveMap.set(piece._id, { av1: effectiveAv1, note })
      totalAv1 += effectiveAv1

      // av2 (ballistic) mirrors the same layering logic
      let effectiveAv2 = piece.system.av2 ?? 0
      if (flex === 'inflexible' && effectiveMap.get(piece._id).av1 === 0) {
        effectiveAv2 = 0  // blocked inflexible piece contributes nothing
      } else if (flex === 'flexible' && hasInflexible) {
        effectiveAv2 = Math.min(effectiveAv2, 1)
      }
      totalAv2 += effectiveAv2

      // Random AV strings
      if (piece.system.avr1 && effectiveAv1 > 0) {
        totalAvr1 += (totalAvr1 ? "+" : "") + piece.system.avr1
      }
      if (piece.system.avr2 && effectiveAv2 > 0) {
        totalAvr2 += (totalAvr2 ? "+" : "") + piece.system.avr2
      }
    }

    return { av1: totalAv1, av2: totalAv2, avr1: totalAvr1, avr2: totalAvr2, effectiveMap }
  }

  //Damage Bonus
  _damageBonus(value) {
    let dmgBonus = {}
    if (value < 13) {
      dmgBonus.dbl = '-2D6'
      dmgBonus.full = '-1D6'
      dmgBonus.half = '-1D3'
    } else if (value < 17) {
      dmgBonus.dbl = '-2D4'
      dmgBonus.full = '-1D4'
      dmgBonus.half = '-1D2'
    } else if (value < 25) {
      dmgBonus.dbl = '+0'
      dmgBonus.full = '+0'
      dmgBonus.half = '+0'
    } else if (value < 33) {
      dmgBonus.dbl = '+2D4'
      dmgBonus.full = '+1D4'
      dmgBonus.half = '+1D2'
    } else if (value < 41) {
      dmgBonus.dbl = '+2D6'
      dmgBonus.full = '+1D6'
      dmgBonus.half = '+1D3'
    } else {
      dmgBonus.dbl = "+" + 2*(Math.ceil((value - 40) / 16) + 1) + "D6"
      dmgBonus.full = "+" + (Math.ceil((value - 40) / 16) + 1) + "D6"
      dmgBonus.half = "+" + (Math.ceil((value - 40) / 16) + 1) + "D3"
    }
    return dmgBonus
  }
}
