import { ElysiumChat } from '../apps/chat.mjs'
export function listen() {
  Hooks.on('renderChatMessageHTML', (app, html, data) => {
    ElysiumChat.renderMessageHook(app, html, data)
    ui.chat.scrollBottom();
  })
}
