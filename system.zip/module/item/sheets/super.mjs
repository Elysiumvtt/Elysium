import { ElysiumUtilities } from '../../apps/utilities.mjs'
import { ElysiumDragDropItemSheet } from './base-dragdrop-item-sheet.mjs'

/**
 * Super-power item sheet — P10 cluster 3b / alpha.41 rewrite.
 *
 * Specialism-aware naming (mainName + specName synthesized into
 * item.name via mySuperHandler). PowerMod drop list with embedded-item
 * semantics (drops create new items, not references).
 *
 * Inherits 8 drag/drop boilerplate methods + 2 collection-management
 * methods (_onGroupItemDelete + _onGroupControl, unused here but
 * harmless) from ElysiumDragDropItemSheet. Overrides _onItemDelete
 * (deletes embedded sub-item) + _onItemView (resolves via uuid not
 * elysiumid).
 *
 * Per c3b-super-1: uses new item-shell-header-specialism partial
 * (legacy skill.header.hbs retired in this ship).
 */
export class ElysiumSuperSheet extends ElysiumDragDropItemSheet {

  static DEFAULT_OPTIONS = {
    classes: ['super'],
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }],
    position: { width: 560, height: 640 },
    form: { handler: ElysiumSuperSheet.mySuperHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header-specialism.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/super.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const actor = this.item.parent

    // Resolve powerMod references into displayable item snapshots
    const powerMods = []
    if (actor) {
      for (const itm of this.item.system.powerMod) {
        const tempItm = fromUuidSync(itm.uuid)
        if (tempItm) powerMods.push(tempItm)
      }
    }
    context.powerMods = powerMods.sort(ElysiumUtilities.sortByNameKey)

    // Ensure mainName is populated (first-render seeding from item.name)
    if (this.item.system.mainName === '') {
      this.item.update({ 'system.mainName': this.item.name })
    }

    // Header chips per audit-3-cluster-3: Range + Duration + Power Cost + (when owned) Level
    const range = this.item.system.range || ''
    const duration = this.item.system.duration || ''
    const ppCost = this.item.system.pppl ?? 0
    const chips = [
      { label: game.i18n.localize('Elysium.range'),    value: range    === '' ? '—' : range },
      { label: game.i18n.localize('Elysium.duration'), value: duration === '' ? '—' : duration },
      { label: game.i18n.localize('Elysium.ppCost', { label: this.item.system.powerLabelAbbr }),
        value: String(ppCost) },
    ]
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.level'),
        value: String(this.item.system.level ?? 0),
      })
    }
    context.itemHeaderChips = chips

    return context
  }

  // -----------------------------------------------------------------
  // OVERRIDES — super-specific behavior
  // -----------------------------------------------------------------

  /**
   * Override base default: super embeds sub-items on drop (does not
   * just reference). So _onItemDelete must ALSO delete the embedded
   * Item document, not just splice the collection.
   */
  async _onItemDelete(event, collectionName = 'powerMod') {
    event.preventDefault()
    event.stopImmediatePropagation()
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const itemId = row.dataset.itemId
    const list = this.item.system[collectionName]
    if (!Array.isArray(list)) return
    const itemIndex = list.findIndex(i => itemId && i.uuid === itemId)
    if (itemIndex < 0) return
    const collection = foundry.utils.duplicate(list)
    collection.splice(itemIndex, 1)
    await this.item.update({ [`system.${collectionName}`]: collection })
    const oldItem = fromUuidSync(itemId)
    if (oldItem) await oldItem.delete()
  }

  /**
   * Override base default: super resolves via uuid (the powerMod was
   * created as an embedded actor item via drop, so the uuid points
   * directly at an existing document — no elysiumid lookup needed).
   */
  async _onItemView(event) {
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const itemId = row.dataset.itemId
    const item = await fromUuid(itemId)
    if (item) item.sheet.render(true)
  }

  /**
   * Override base default: super-style drop CREATES an embedded sub-item
   * (powerMod) on the parent actor, then stores the new item's uuid in
   * the super's powerMod collection. Different from personality/culture
   * which just store references to existing skills.
   */
  async _onDrop(event, type = 'powerMod', collectionName = 'powerMod') {
    event.preventDefault()
    event.stopPropagation()
    if (!this.item.parent) return  // unowned: drop is no-op
    const dataList = await ElysiumUtilities.getDataFromDropEvent(event, 'Item')
    const collection = this.item.system[collectionName]
      ? foundry.utils.duplicate(this.item.system[collectionName])
      : []

    for (const item of dataList) {
      if (!item || !item.system) continue
      if (![type].includes(item.type)) continue

      // F10 (rc.2) defensive guard — see career.mjs for rationale.
      if (!item.flags?.elysium?.elysiumidFlag?.id) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      // Skip if already in the collection
      if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      // Create an embedded copy on the parent actor; reference it
      const actor = this.item.parent
      const itemData = foundry.utils.duplicate(item)
      const newItem = await Item.create(itemData, { parent: actor })
      collection.push({
        uuid: newItem.uuid,
        elysiumid: newItem.flags.elysium.elysiumidFlag.id,
      })
    }
    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  // -----------------------------------------------------------------
  // FORM HANDLER — specialism-aware name synthesis (cluster 5 will
  // hoist this; for cluster 3b super keeps its own inline copy).
  // -----------------------------------------------------------------
  static async mySuperHandler(event, form, formData) {
    const skillName = formData.object['system.mainName'] || this.item.system.mainName
    if (this.item.system.specialism) {
      const specialization = formData.object['system.specName'] || this.item.system.specName
      formData.object.name = skillName + ' (' + specialization + ')'
    } else {
      formData.object.name = skillName
    }
    await this.document.update(formData.object)
  }
}
