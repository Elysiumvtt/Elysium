import { ElysiumUtilities } from '../../apps/utilities.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * ElysiumDragDropItemSheet — intermediate base for item sheets with
 * drag/drop and collection-management infrastructure.
 *
 * Introduced in P10 cluster 3b (alpha.41) to hoist ~248 LOC of
 * bit-identical drag/drop boilerplate across super, personality,
 * culture (and eventually skill in cluster 5). Plus ~80 LOC of
 * personality/culture-style collection-management defaults that
 * super partially overrides.
 *
 * Sub-classes that need drag/drop:
 *  1. Declare `dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }]`
 *     in DEFAULT_OPTIONS (V14 reads this).
 *  2. Inherit the 8 drag/drop boilerplate methods automatically.
 *  3. Override `_onDrop(event, type, collectionName)` with type-specific
 *     semantics (super-style "create embedded item" vs personality-style
 *     "reference existing skill" vs culture-style "reference + bonus dialog").
 *
 * Sub-classes get sensible defaults for the 4 collection-management
 * methods (`_onItemDelete`, `_onItemView`, `_onGroupItemDelete`,
 * `_onGroupControl`) that match personality/culture's behavior. Super
 * overrides 2 (`_onItemDelete` to also `.delete()` the embedded sub-item,
 * `_onItemView` to resolve via uuid not elysiumid).
 *
 * The 4 collection-management methods bind via legacy class hooks
 * (`.item-delete`, `.item-view`, `.group-item-delete`, `.group-control`)
 * in `_onRender`. Per cluster-3 audit-5 lock: these class hooks are
 * preserved through cluster 3b; V14-actions migration deferred to P12.
 *
 * Sub-class `_onRender` should call super._onRender(context, options)
 * to inherit the listener bindings + drag/drop wiring.
 */
export class ElysiumDragDropItemSheet extends ElysiumItemSheetV2 {

  constructor(options = {}) {
    super(options)
    this.#dragDrop = this.#createDragDropHandlers()
  }

  /**
   * Default _onRender wires the 4 imperative listeners on the legacy
   * class hooks. Sub-classes calling super._onRender() inherit these.
   * Sheets that need different selectors can override entirely.
   */
  _onRender(context, _options) {
    this.#dragDrop.forEach((d) => d.bind(this.element))
    this.element.querySelectorAll('.item-delete')
      .forEach(n => n.addEventListener('click', this._onItemDelete.bind(this)))
    this.element.querySelectorAll('.item-view')
      .forEach(n => n.addEventListener('click', this._onItemView.bind(this)))
    this.element.querySelectorAll('.group-item-delete')
      .forEach(n => n.addEventListener('click', this._onGroupItemDelete.bind(this)))
    this.element.querySelectorAll('.group-control')
      .forEach(n => n.addEventListener('click', this._onGroupControl.bind(this)))
  }

  // -----------------------------------------------------------------
  // Collection management — personality/culture-style defaults.
  // Super overrides _onItemDelete + _onItemView.
  // -----------------------------------------------------------------

  /**
   * Delete a skill from the main collection. Locates the row via
   * `[data-item-id]` (cluster-3b widening — alpha.33/.34 lesson:
   * `.closest('.item')` would fail on v1.0.0 markup that doesn't
   * carry the legacy `.item` class).
   */
  async _onItemDelete(event, collectionName = 'skills') {
    event.preventDefault()
    event.stopImmediatePropagation()
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const itemId = row.dataset.itemId
    const list = this.item.system[collectionName]
    if (!Array.isArray(list)) return
    const itemIndex = list.findIndex(i => itemId && i.uuid === itemId)
    if (itemIndex < 0) return
    const collection = foundry.utils.duplicate(list)
    collection.splice(itemIndex, 1)
    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  /**
   * Delete a skill from one of the optional groups. Locates row +
   * containing group via widened selectors.
   */
  async _onGroupItemDelete(event) {
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const groupOl = row.closest('[data-group]')
    if (!groupOl) return
    const group = Number(groupOl.dataset.group)
    const groups = foundry.utils.duplicate(this.item.system.groups)
    if (typeof groups[group] === 'undefined') return
    const itemId = row.dataset.itemId
    const itemIndex = groups[group].skills.findIndex(i => itemId && i.uuid === itemId)
    if (itemIndex < 0) return
    groups[group].skills.splice(itemIndex, 1)
    await this.item.update({ 'system.groups': groups })
  }

  /**
   * Open the source skill's sheet from a row view click. Personality/
   * culture flavor: resolve via elysiumid (the reference is to a
   * world/compendium skill, not an embedded item). Super overrides
   * this to resolve via uuid.
   */
  async _onItemView(event) {
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const elysiumid = row.dataset.elysiumid
    const tempItem = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid }))[0]
    if (tempItem) tempItem.sheet.render(true)
  }

  /**
   * Handle add/remove buttons on the optional-skill-group controls.
   * Caller's template marks add/remove buttons with `.group-control`
   * + a sub-class (`.add-group` / `.remove-group`).
   */
  async _onGroupControl(event) {
    event.preventDefault()
    const a = event.currentTarget
    if (a.classList.contains('add-group')) {
      const groups = this.item.system.groups
        ? foundry.utils.duplicate(this.item.system.groups)
        : []
      const newGroups = groups.concat([{ options: 1, skills: [] }])
      await this.item.update({ 'system.groups': newGroups })
      return
    }
    if (a.classList.contains('remove-group')) {
      const groups = this.item.system.groups
        ? foundry.utils.duplicate(this.item.system.groups)
        : []
      const groupOl = a.closest('[data-group]')
      if (!groupOl) return
      groups.splice(Number(groupOl.dataset.group), 1)
      await this.item.update({ 'system.groups': groups })
    }
  }

  // -----------------------------------------------------------------
  // Drag/drop boilerplate — hoisted from super/personality/culture/skill.
  // All 4 sheets had bit-identical implementations of these 8 methods.
  // -----------------------------------------------------------------

  _canDragStart(_selector) { return this.isEditable }

  _canDragDrop(_selector) { return this.isEditable }

  _onDragStart(event) {
    const li = event.currentTarget
    if ('link' in event.target.dataset) return
    let dragData = null
    if (li.dataset.effectId) {
      const effect = this.item.effects.get(li.dataset.effectId)
      dragData = effect.toDragData()
    }
    if (!dragData) return
    event.dataTransfer.setData('text/plain', JSON.stringify(dragData))
  }

  _onDragOver(_event) { }

  async _onDropItem(_event, _data) {
    if (!this.item.isOwner) return false
  }

  async _onDropFolder(_event, _data) {
    if (!this.item.isOwner) return []
  }

  /**
   * Default `_onDrop` — sub-classes MUST override. Provided here only
   * so that drag/drop wiring doesn't blow up if a subclass forgets it.
   */
  async _onDrop(event, _type, _collectionName) {
    event.preventDefault()
    event.stopPropagation()
    console.warn('ElysiumDragDropItemSheet._onDrop: subclass should override this method')
  }

  get dragDrop() {
    return this.#dragDrop
  }

  #dragDrop

  #createDragDropHandlers() {
    return this.options.dragDrop.map((d) => {
      d.permissions = {
        dragstart: this._canDragStart.bind(this),
        drop: this._canDragDrop.bind(this),
      }
      d.callbacks = {
        dragstart: this._onDragStart.bind(this),
        dragover: this._onDragOver.bind(this),
        drop: this._onDrop.bind(this),
      }
      return new foundry.applications.ux.DragDrop.implementation(d)
    })
  }
}
