/**
 * Elysium subsystem — Settings registration
 *
 * v0.20.0: massive cleanup. Tier-1 structural-pretender toggles (masterEnable,
 * enableActionPoints, enableWoundThresholds, enableCriticalTables,
 * enableMythrasFatigue, enableArmorLayering, enableTempHP,
 * enableArmorCastingPenalty) are GONE — they guarded code paths whose off-state
 * was either never implemented or actively broken. Tier-3 zero-read dead settings
 * (enableDivine, enableSorcery, enableSuperpowers, enableSpecialEffects,
 * enableShieldPassiveBlocking, enableCharacterCreation, showDifficultyGradeNames)
 * are also gone. Per-tradition magic toggles (enableArcane, enableMysticism)
 * are gone — campaigns gate magic access through what spells exist in the
 * compendium, not via a global flag. EXP-dice false toggles (enableExpDiceSystem,
 * sessionExpDicePool, expFumbleImmediateAdvance, expAdvancementTiming) are gone.
 *
 * Remaining settings are properly-wired alternate-ruleset toggles, campaign
 * tuning numerics, and pure-cosmetic UI flags.
 *
 * Settings live under the 'elysium' system namespace (set via
 * ELYSIUM.MODULE_ID in config/config.mjs). All getSetting() reads route through
 * that constant.
 */

import { ELYSIUM } from '../config/config.mjs'
import { registerArmorHpMigrationSetting } from '../migrations/armor-hp-schema-v0220a9.mjs'
const M = ELYSIUM.MODULE_ID

/**
 * Shared onChange callback that re-renders any open actor and item
 * sheets so a setting change is reflected immediately without a reload.
 */
function _refreshSheets () {
  // V14 application instances
  if (foundry.applications?.instances) {
    for (const app of foundry.applications.instances.values()) {
      try { app.render(false) } catch (e) {}
    }
  }
  // V13/legacy fallback
  for (const app of Object.values(ui.windows || {})) {
    try { app.render(false) } catch (e) {}
  }
}

export function registerSettings () {

  // === ALTERNATE-RULESET TOGGLES ====================================
  // These properly gate their feature on/off with no half-wired paths.

  game.settings.register(M, 'enableMythrasHealingRate', {
    name:    'Elysium.Settings.enableMythrasHealingRate',
    hint:    'Elysium.Settings.enableMythrasHealingRateHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
    onChange: _refreshSheets,
  })

  game.settings.register(M, 'enableLuckPoints', {
    name:    'Elysium.Settings.enableLuckPoints',
    hint:    'Elysium.Settings.enableLuckPointsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
    onChange: _refreshSheets,
  })

  game.settings.register(M, 'enableOvercasting', {
    name:    'Elysium.Settings.enableOvercasting',
    hint:    'Elysium.Settings.enableOvercastingHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  game.settings.register(M, 'requireSpellLearningRoll', {
    name:    'Elysium.Settings.requireSpellLearningRoll',
    hint:    'Elysium.Settings.requireSpellLearningRollHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: false,
  })

  game.settings.register(M, 'autoApplyConditions', {
    name:    'Elysium.Settings.autoApplyConditions',
    hint:    'Elysium.Settings.autoApplyConditionsHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
  })

  // === CAMPAIGN TUNING ==============================================

  // Scales every hit-location's maxHP by this factor. Default 1.0 = vanilla
  // Mythras values. Lower for gritty/deadly play (0.5 = half HP); higher
  // for heroic/forgiving play (2.0+ = more durable). Applied in
  // ElysiumMythrasHP.hpForLocation() as Math.max(1, Math.ceil(raw * multiplier)).
  game.settings.register(M, 'hpMultiplier', {
    name:    'Elysium.Settings.hpMultiplier',
    hint:    'Elysium.Settings.hpMultiplierHint',
    scope:   'world',
    config:  true,
    type:    Number,
    default: 1.0,
    range:   { min: 0.5, max: 4.0, step: 0.25 },
    onChange: _refreshSheets,
  })

  // === ANCESTRY / TERMINOLOGY ======================================

  game.settings.register(M, 'enableAncestrySystem', {
    name:    'Elysium.Settings.enableAncestrySystem',
    hint:    'Elysium.Settings.enableAncestrySystemHint',
    scope:   'world',
    config:  true,
    type:    Boolean,
    default: true,
    onChange: () => {
      import('../helpers/ancestry-relabel.mjs').then(m => {
        m.ElysiumAncestryRelabel.apply()
        _refreshSheets()
      })
    },
  })

  game.settings.register(M, 'ancestryLabel', {
    name:    'Elysium.Settings.ancestryLabel',
    hint:    'Elysium.Settings.ancestryLabelHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      'culture':  'Culture (BRP default)',
      'ancestry': 'Ancestry',
      'race':     'Race',
      'species':  'Species',
    },
    default: 'ancestry',
    onChange: () => {
      import('../helpers/ancestry-relabel.mjs').then(m => {
        m.ElysiumAncestryRelabel.apply()
        _refreshSheets()
      })
    },
  })

  // === CHARACTER CREATION TUNING ====================================

  game.settings.register(M, 'statRollMethod', {
    name:    'Elysium.Settings.statRollMethod',
    hint:    'Elysium.Settings.statRollMethodHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      '4d6dl':   '4d6 drop lowest (Elysium default)',
      '3d6':     '3d6 (BRP default for STR/CON/DEX/POW/CHA)',
      '2d6+6':   '2d6+6 (BRP default for SIZ/INT)',
      'pointBuy':'Point buy',
    },
    default: '4d6dl',
  })

  // v0.20.0: statNaturalMaxBase and startingSkillCap settings deleted.
  // Both were placebos — registered as settings but never read. The actual
  // values come from ELYSIUM.STAT_NATURAL_MAX_BASE and ELYSIUM.STARTING_SKILL_CAP
  // in config/config.mjs. If per-campaign tuning becomes a real need, the
  // settings can be re-added alongside readers that consult them.

  // === COSMETIC ======================================================

  game.settings.register(M, 'showFatigueOnSheet', {
    name:    'Elysium.Settings.showFatigueOnSheet',
    hint:    'Elysium.Settings.showFatigueOnSheetHint',
    scope:   'client',
    config:  true,
    type:    Boolean,
    default: true,
    onChange: _refreshSheets,
  })

  // v0.22.0-alpha.12: hit location rolled at attack time on CM rolls.
  // Visibility toggle: by default the rolled location is GM-only info
  // (hidden from players on the chat card via inline display:none).
  // Setting this to 'everyone' shows the location to all viewers — useful
  // for transparent / Mythras-style play. Data is always stored on the
  // chatCard entry regardless; this controls only the visible tag.
  game.settings.register(M, 'hitLocationVisibility', {
    name:    'Elysium.Settings.hitLocationVisibility',
    hint:    'Elysium.Settings.hitLocationVisibilityHint',
    scope:   'world',
    config:  true,
    type:    String,
    choices: {
      'gm-only':  'GM only (default — hide rolled location from players)',
      'everyone': 'Everyone (transparent rolling)',
    },
    default: 'gm-only',
  })

  // === MIGRATION FLAGS (hidden) ======================================
  // One-way latches that record whether one-time data migrations have
  // already run on this world. Hidden from the UI; managed entirely by
  // the migration modules themselves.

  registerArmorHpMigrationSetting()
}

/**
 * Helper: get a setting value with defaults.
 *
 * Uses defensive try/catch so that callers can read settings before
 * they're registered (e.g. during early init). The defaultValue parameter
 * is the fallback used if the setting hasn't been registered yet.
 */
export function getSetting (key, defaultValue = null) {
  try {
    return game.settings.get(ELYSIUM.MODULE_ID, key)
  } catch (e) {
    return defaultValue
  }
}
