import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Divine power item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Cast at any tier between baseTier and maxTier (subject to
 * Channeling/Faith gate). AP cost and effect text scale per tier.
 *
 * Per c3-divine-1: hardcoded English labels migrated to i18n keys.
 * Per c3-divine-2: damageType + saveSkill selects driven by
 * ElysiumSelectLists helpers.
 * Per c3-divine-4: 3 native checkboxes (isRitual / isReactive /
 * isDamageSpell) migrated to elysium-item-toggle chips.
 *
 * Custom form handler resyncs `name` from localized category.
 */
export class ElysiumDivineSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['divine'],
    position: { width: 720, height: 720 },  // wide tier per audit-3
    form: { handler: ElysiumDivineSheet.myPowerHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/divine.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    context.itemType = game.i18n.localize('Elysium.divine')

    context.catOptions = await ElysiumSelectLists.getPowerCatOptions()
    context.catName    = game.i18n.localize('Elysium.' + this.item.system.category)
    context.lvlOptions = await ElysiumSelectLists.getPowerLvlOptions()
    context.lvlName    = game.i18n.localize('Elysium.' + this.item.system.level)

    // Save-skill + damage-type select options (cluster-3a c3-5 helpers)
    context.saveSkillOptions = await ElysiumSelectLists.getSpellSaveSkillOptions()
    const saveSkillRaw = this.item.system?.elysium?.saveSkill ?? ''
    const saveSkillKey = saveSkillRaw === ''
      ? 'Elysium.saveSkillNone'
      : 'Elysium.saveSkill' + saveSkillRaw.charAt(0).toUpperCase() + saveSkillRaw.slice(1)
    context.saveSkillName = game.i18n.localize(saveSkillKey)

    context.damageTypeOptions = await ElysiumSelectLists.getDivineDamageTypeOptions()
    const damageTypeRaw = this.item.system?.elysium?.damageType ?? ''
    const damageTypeKey = damageTypeRaw === ''
      ? 'Elysium.damageNone'
      : 'Elysium.damage' + damageTypeRaw.charAt(0).toUpperCase() + damageTypeRaw.slice(1)
    context.damageTypeName = game.i18n.localize(damageTypeKey)

    // Header chips per c3-2: Domain + Tier Band + Power Cost
    const domain = this.item.system?.elysium?.domain ?? ''
    const baseTier = Math.max(1, Number(this.item.system?.elysium?.baseTier) || 1)
    const maxTier  = Math.min(5, Math.max(baseTier, Number(this.item.system?.elysium?.maxTier) || 5))
    const tierBand = baseTier === maxTier ? `T${baseTier}` : `T${baseTier}–T${maxTier}`
    const powerCost = this.item.system?.elysium?.powerCost ?? 0
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.domain'),    value: domain === '' ? '—' : domain },
      { label: game.i18n.localize('Elysium.tier'),      value: tierBand },
      { label: game.i18n.localize('Elysium.powerCost'), value: String(powerCost) },
    ]

    // P10 cluster 4 (alpha.42): flag chips array driving the shared
    // item-toggle-row partial. Each chip names its actual storage path
    // (system.elysium.*) so the cluster-4 enhanced _onItemToggle handler
    // writes to the correct nested location. Cluster 3a's bare
    // `data-property="isRitual"` markup was writing to the wrong path
    // (`system.isRitual` flat) — this was the latent bug surfaced by
    // cluster-4 smoke and fixed in this ship.
    const ely = this.item.system?.elysium ?? {}
    context.flagChips = [
      { property: 'isRitual',      propertyPath: 'system.elysium.isRitual',
        active: !!ely.isRitual,      label: game.i18n.localize('Elysium.ritual') },
      { property: 'isReactive',    propertyPath: 'system.elysium.isReactive',
        active: !!ely.isReactive,    label: game.i18n.localize('Elysium.reactive') },
      { property: 'isDamageSpell', propertyPath: 'system.elysium.isDamageSpell',
        active: !!ely.isDamageSpell, label: game.i18n.localize('Elysium.damageSpell') },
    ]

    return context
  }

  /** @override — builds per-tier rows for the details body. */
  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context)
    if (partId === 'details') {
      const ely = this.item.system?.elysium ?? {}
      const baseTier = Math.max(1, Number(ely.baseTier) || 1)
      const maxTier  = Math.min(5, Math.max(baseTier, Number(ely.maxTier) || 5))
      const apCostByTier = Array.isArray(ely.apCostByTier) ? ely.apCostByTier : [1, 1, 2, 2, 3]
      const effectByTier = (ely.effectByTier && typeof ely.effectByTier === 'object') ? ely.effectByTier : {}

      // Active tier rows for the Effects by Tier section
      const effectsByTierList = []
      for (let t = baseTier; t <= maxTier; t++) {
        effectsByTierList.push({
          tier: t,
          apCost: Number(apCostByTier[t - 1]) || 1,
          text: effectByTier[String(t)] ?? effectByTier[t] ?? '',
        })
      }
      context.effectsByTierList = effectsByTierList

      // Full T1-T5 cell list for the AP-cost grid
      const apCostByTierList = []
      for (let i = 0; i < 5; i++) {
        apCostByTierList.push({
          tier: i + 1,
          cost: Number(apCostByTier[i]) || 1,
          idx: i,
        })
      }
      context.apCostByTierList = apCostByTierList
    }
    return context
  }

  /**
   * Form-submission handler. Resyncs `item.name` from the localized
   * category label so power names stay consistent with category changes.
   */
  static async myPowerHandler(event, form, formData) {
    formData.object.name = game.i18n.localize('Elysium.' + formData.object['system.category'])
    await this.document.update(formData.object)
  }
}
