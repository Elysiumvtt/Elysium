/**
 * Elysium Magic System Manager
 *
 * Handles mechanics shared across the five magic systems:
 *   - Power Points pool (universal resource)
 *   - SL accumulation tracking (Arcane multi-round casts)
 *   - MP allocation logic
 *   - School efficiency lookup
 *   - Overcasting damage
 *   - Scroll/Permanent Rune POW management
 *   - Casting penalty application
 *   - Patron standing for Divine
 *   - Sorcery essence growth thresholds
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'
export class ElysiumMagic {

  // === POWER POINTS =================================================

  /**
   * Spend PP from actor pool.
   * If overcasting is enabled and PP would go negative, the deficit
   * advances Fatigue levels per Mythras (overcasting drains the caster's
   * stamina rather than vitality). Default ratio: 1 fatigue level per
   * excess PP. Pass options.overcastMultiplier to scale.
   */
  static async spendPP (actor, amount, options = {}) {
    if (amount <= 0) return true

    const current = actor.system.power?.value || 0
    const overcastEnabled = getSetting('enableOvercasting', true)

    if (current >= amount) {
      // Normal spend
      await actor.update({
        'system.power.value': current - amount,
      })
      return true
    }

    // Insufficient PP
    if (!overcastEnabled) {
      ui.notifications.warn(game.i18n.format('Elysium.Magic.InsufficientPP', {
        actor: actor.name, current, required: amount,
      }))
      return false
    }

    // Overcasting: PP debt advances Fatigue (Mythras semantics)
    const deficit = amount - current
    const multiplier = options.overcastMultiplier ?? 1
    const fatigueLevels = Math.max(1, Math.ceil(deficit * multiplier))

    // Drain remaining PP, then advance fatigue
    await actor.update({ 'system.power.value': 0 })

    if (game.system.api?.elysium?.fatigue) {
      try {
        await game.system.api.elysium.fatigue.increment(actor, fatigueLevels, 'magical', 'overcast')
      } catch (err) {
        console.error('Elysium | Overcast fatigue advance failed:', err)
      }
    }

    const body = `<p>${game.i18n.format('Elysium.Magic.OvercastFatigue', {
      deficit, fatigueLevels,
    })}</p>`
    const html = await foundry.applications.handlebars.renderTemplate(
      'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
      {
        variant: 'danger',
        title: `${actor.name} — ${game.i18n.localize('Elysium.Magic.Overcast')}`,
        icon: 'fire',
        body,
      }
    )
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })

    return true
  }

  /**
   * Recover PP — call once per hour of game time per the rules
   */
  static async recoverPP (actor, asleep = false, hours = 1) {
    const current = actor.system.power?.value || 0
    const max = actor.system.power?.max || ElysiumActorExtension.calculatePowerPointsMax(actor)

    let recovery = hours * 1
    if (asleep) {
      const hr = actor.flags?.['elysium']?.derived?.healingRate || 1
      recovery = hours * hr
    }

    const newValue = Math.min(max, current + recovery)
    await actor.update({
      'system.power.value': newValue,
    })

    return newValue
  }

  // === ARCANE: SUCCESS LEVELS / MP =================================

  /**
   * Calculate Success Levels from a casting roll.
   * SL = tens(skill) - tens(roll)
   */
  static calculateSL (rollTotal, skillTotal) {
    if (rollTotal > skillTotal) return 0    // failure → 0 SL
    const tensRoll  = Math.floor(rollTotal / 10)
    const tensSkill = Math.floor(skillTotal / 10)
    return Math.max(0, tensSkill - tensRoll)
  }

  /**
   * Determine MP cost for a school given user's school skill %.
   * Returns reduction object: { manaReduction, slReduction }
   */
  static getSchoolEfficiency (schoolSkillPct) {

    for (const tier of ELYSIUM.ARCANE.schoolEfficiency) {
      if (schoolSkillPct >= tier.thresholdMin && schoolSkillPct <= tier.thresholdMax) {
        return tier
      }
    }
    return { manaReduction: 0, slReduction: 0 }
  }

  /**
   * Cast a spell from the Arcane system.
   * Returns the cast outcome.
   */
  static async castArcane (actor, spell, options = {}) {

    const technique = options.techniqueSkill || 0
    const form      = options.formSkill || 0
    const school    = options.schoolSkill || 0
    const mpAllocated = options.mp || 1

    const schoolBonus = (school > 50) ? Math.floor((school - 50) / 10) * 5 : 0
    const castSkill = Math.min(technique, form) + schoolBonus

    // Apply casting penalty (always-on as of v0.20.0). The penalty value is
    // sourced from `flags['elysium'].modifiers.castingPenalty`, populated
    // by Active Effects on worn armor and active conditions. Foundry's AE
    // engine handles aggregation; the value here is simply the resulting sum.
    // If no armor or conditions impose a penalty, the modifier reads 0 and
    // skill is unchanged.
    let finalSkill = castSkill
    const cp = Number(actor.flags?.['elysium']?.modifiers?.castingPenalty) || 0
    if (cp) finalSkill += cp

    // Difficulty
    if (options.improvised) finalSkill -= 20

    finalSkill = Math.max(1, finalSkill)

    const roll = await new Roll('1d100').evaluate()
    const sl = this.calculateSL(roll.total, finalSkill)
    // v0.14.0: fumble formula aligned with apps/check.mjs.
    // Fumble: roll >= 91 + floor(skill/10), clamped to 100.
    // High-skill casters fumble less; 00 always fumbles.
    const fumbleThreshold = Math.min(100, 91 + Math.floor(finalSkill / 10))
    const isFumble = roll.total >= fumbleThreshold

    const efficiency = this.getSchoolEfficiency(school)
    const requiredSL = Math.max(1, mpAllocated - efficiency.slReduction)
    const ppCost = Math.max(0, mpAllocated - efficiency.manaReduction)
                  + (options.improvised ? ELYSIUM.ARCANE.improvisedManaSurcharge : 0)

    const succeeded = (sl >= requiredSL) && !isFumble

    if (isFumble) {
      // Fumble: all SL lost
      const body = `<p>⚠ ${game.i18n.localize('Elysium.Magic.ArcaneFumble')} — ${spell.name}</p>`
      const html = await foundry.applications.handlebars.renderTemplate(
        'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
        { variant: 'danger', icon: 'triangle-exclamation', body }
      )
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: html,
      })
      return { succeeded: false, fumble: true, roll: roll.total, sl: 0, ppCost: 0 }
    }

    if (succeeded) {
      await this.spendPP(actor, ppCost)
    }

    return {
      succeeded,
      roll: roll.total,
      sl,
      requiredSL,
      ppCost,
      finalSkill,
    }
  }

  // === DIVINE: STANDING =============================================

  /**
   * Get current PP recovery rate based on Patron standing
   */
  static getDivineRecoveryRate (actor) {
    const standing = actor.flags?.['elysium']?.patron?.standing || 'faithful'
    return ELYSIUM.DIVINE.ppRecoveryStanding[standing]
  }

  /**
   * Set patron standing (GM action).
   * v1.0.0-alpha.11 (side-finding #1): writes to flags.elysium.patron.standing
   * to match the reader at getDivineRecoveryRate above. Previously wrote to
   * system.elysium.patron.standing which CharacterDataModel doesn't declare;
   * Foundry silently dropped the write.
   */
  static async setPatronStanding (actor, standing) {
    if (!ELYSIUM.DIVINE.standings.includes(standing)) {
      ui.notifications.error(`Invalid standing: ${standing}`)
      return false
    }
    await actor.update({
      'flags.elysium.patron.standing': standing,
    })
    return true
  }

  // === SORCERY: ESSENCE GROWTH =====================================

  /**
   * Lookup growth tier for an essence skill %
   */
  static getEssenceGrowthTier (essenceSkillPct) {
    if (essenceSkillPct >= 100) return 'transcendent'
    if (essenceSkillPct >= 76)  return 'potent'
    if (essenceSkillPct >= 51)  return 'established'
    if (essenceSkillPct >= 26)  return 'developing'
    return 'nascent'
  }

  /**
   * Get resistance difficulty against a sorcery ability
   */
  static getSorceryResistanceDifficulty (essenceSkillPct) {
    if (essenceSkillPct >= 91) return 'extremelyDifficult'
    if (essenceSkillPct >= 76) return 'veryDifficult'
    if (essenceSkillPct >= 51) return 'difficult'
    return 'standard'
  }

  // === MYSTICISM: MEDITATION =======================================

  /**
   * Recover PP through meditation. Mythras p79: a character can recover
   * Magic Points equal to their POW characteristic over a 24-hour rest
   * period. Meditation accelerates this — 1 PP per hour of focused
   * meditation, up to the natural cap (full POW per day combined with
   * passive recovery).
   *
   * v0.20.0: dropped the legacy _powBonus table — Mythras uses a simple
   * fixed per-hour rate. POW gates the max pool (system.power.max) but
   * doesn't scale recovery rate.
   *
   * Cannot be combined with sleep — the player should choose one or the
   * other for a given rest period (GM enforced).
   */
  static async meditate (actor, hours = 1) {

    const current = actor.system.power?.value || 0
    const max = actor.system.power?.max || 0
    const recovery = Math.max(0, Math.floor(hours))   // 1 PP per hour
    const newValue = Math.min(max, current + recovery)

    await actor.update({
      'system.power.value': newValue,
    })

    return { recovered: newValue - current, total: newValue }
  }

  // === SCROLLS & PERMANENT RUNES ===================================

  /**
   * Inscribe a scroll — costs temporary POW
   */
  static async inscribeScroll (actor, spellMP, options = {}) {
    const tempPow = (actor.flags?.['elysium']?.tempPowSacrificed || 0)
    await actor.update({
      'flags.elysium.tempPowSacrificed': tempPow + ELYSIUM.ARCANE.scrollPowSacrifice,
    })

    return {
      cost: ELYSIUM.ARCANE.scrollPowSacrifice,
      total: tempPow + ELYSIUM.ARCANE.scrollPowSacrifice,
    }
  }

  /**
   * Permanent rune — 1 POW per 5 MP permanent
   */
  static calculateRunePowCost (totalMP) {
    return Math.ceil(totalMP / ELYSIUM.ARCANE.permanentRunePerMP)
  }
}
