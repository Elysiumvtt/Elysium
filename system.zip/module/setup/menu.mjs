import { ElysiumCharDev } from '../apps/charDev.mjs'
class ElysiumMenuLayer extends (foundry.canvas?.layers?.PlaceablesLayer ?? PlaceablesLayer) {
  constructor () {
    super()
    this.objects = {}
  }

  static get layerOptions () {
    return foundry.utils.mergeObject(super.layerOptions, {
      name: 'elysiummenu',
      zIndex: 60
    })
  }

  static get documentName () {
    return 'Token'
  }

  get placeables () {
    return []
  }
}

export class ElysiumMenu {
  static getButtons (controls) {
    canvas.elysiumgmtools = new ElysiumMenuLayer()
    const isGM = game.user.isGM
    const menu = {
      name: 'elysiummenu',
      title: 'Elysium.gmTools',
      layer: 'elysiumgmtools',
      icon: 'fas fa-tools',
      activeTool: 'elysiumdummy',
      visible: isGM,
      onChange: (event, active) => {
      },
      onToolChange: (event, tool) => {
      },
      tools: {
        elysiumdummy: {
          icon: '',
          name: 'elysiumdummy',
          active: false,
          title: '',
          onChange: () => {
          }
        },
        development: {
          toggle: true,
          icon: 'fas fa-chevrons-up',
          name: 'development',
          active: game.settings.get('elysium', 'development'),
          title: 'Elysium.developmentPhase',
          onChange: async toggle => await ElysiumCharDev.developmentPhase(toggle)
        },
      }
    }
    if (Array.isArray(controls)) {
      menu.tools = Object.keys(menu.tools).reduce((c, i) => {
        if (i === 'elysiumdummy') {
          return c
        }
        c.push(menu.tools[i])
        return c
      }, [])
      controls.push(menu)
    } else {
      controls.elysiummenu = menu
    }
  }

  static renderControls (app, html, data) {
    const isGM = game.user.isGM
    const gmMenu = html.querySelector('.fa-solid fa-hammer')?.parentNode
    if (gmMenu && !gmMenu.classList.contains('elysiummenu')) {
      gmMenu.classList.add('elysiummenu')
      if (isGM) {
        const menuLi = document.createElement('li')
        const menuButton = document.createElement('button')
        menuButton.classList.add('control', 'ui-control', 'tool', 'icon', 'elysiummenu')
        menuButton.type = 'button'
      }
    }
  }
}
