// Auto-extracted from module/elysium/hooks/register-hooks.mjs by tools/extract-functions.mjs
// (v0.21.0 register-hooks refactor).
//
// Top-level Foundry hook handlers extracted from the central registerHooks
// dispatcher. Each function is exported by name; the dispatcher imports them
// and wires them via Hooks.on(eventName, handler).



import { ElysiumActiveEffectFactory } from '../active-effects/factory.mjs'
import { syncEquipState } from '../active-effects/item-modifiers.mjs'
import { ElysiumActorExtension } from '../actor/actor-extension.mjs'
import { ElysiumAncestryDrop } from '../actor/ancestry-drop.mjs'
import { ElysiumCriticalRoller } from '../critical/critical-roller.mjs'
import { ElysiumArmorWear } from '../mechanics/armor-wear.mjs'
import { checkArmorLayerConflict } from '../mechanics/armor-layering.mjs'
import { getSetting } from '../settings/register-settings.mjs'

export function _onPreCreateItem (item, data, options, userId) {

  // Wound interception MUST run synchronously and first because Foundry V14
  // does not await async pre-create hooks — only a sync `return false`
  // actually cancels creation. This branch handles its own cancel/mutate
  // logic synchronously.
  if (item.type === 'wound' ) {
    return _absorbWithTempHP(item, data, options, userId)
  }

  // v1.0.0-alpha.11 (side-finding #8): the post-construct equipStatus
  // normalizer that previously lived here is gone. Pre-validation
  // normalization now happens at the schema layer via each affected
  // DataModel's `static migrateData(source)` hook — see
  // armor.mjs / weapon.mjs / gear.mjs and the helper
  // `migrateLegacyEquipStatus` in data/item/_shared.mjs. That approach
  // is correct because cleanData's choices check runs AFTER migrateData,
  // so the legacy 'carried'/'worn' values are normalized to 'stowed'
  // before the choices lock evaluates them.

  // v0.10.3: Arcane spell drop → route through learnArcaneSpell when the
  // requireSpellLearningRoll setting is on. Cancel the direct create; the
  // learning helper handles its own creation if the roll succeeds.
  // Skip when options.elysiumLearnedSpell is set (so learnArcaneSpell's
  // own createEmbeddedDocuments call doesn't recurse).
  if (item.type === 'arcane'
      && getSetting('requireSpellLearningRoll', false)
      && item.parent.documentName === 'Actor'
      && !options.elysiumLearnedSpell) {
    const api = game.system.api?.casting
    if (api?.learnArcaneSpell) {
      // Fire and forget — the helper posts its own chat card.
      // Pass the source data plus a flag the recursive create can detect.
      const spellData = item.toObject()
      Promise.resolve().then(async () => {
        try {
          await api.learnArcaneSpell(item.parent, spellData, { elysiumLearnedSpell: true })
        } catch (err) {
          console.error('Elysium: spell-learning failed', err)
        }
      })
      return false  // cancel the direct create
    }
  }

  // For the ancestry/armor branches, cancellation isn't critical to
  // gameplay correctness — they validate and apply effects. The async
  // work runs in the background. (If we ever need them to cancel
  // synchronously we'd need to refactor the same way as wound.)
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    ElysiumAncestryDrop.handlePreCreate(item, data, options, userId)
      .catch(err => console.error('Elysium | ancestry preCreate failed:', err))
    return
  }

  if (item.type === 'armor' ) {
    Promise.resolve(ElysiumActorExtension.validateArmorLayer(item))
      .catch(err => console.error('Elysium | armor validate failed:', err))
    return
  }
}

export async function _onCreateItem (item, options, userId) {
  if (game.userId !== userId) return

  // Apply ancestry effects (mutations, AEs, mods) on creation
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    return await ElysiumAncestryDrop.handlePostCreate(item, options, userId)
  }

  // Item-modifier AEs come embedded on the item when it's dropped from
  // a compendium or copied; their default-disabled state may not match
  // the item's actual equip state. Sync once on creation.
  if (item.type === 'armor' || item.type === 'weapon' || item.type === 'gear') {
    syncEquipState(item).catch(err =>
      console.error('Elysium | item-modifier equip sync (create) failed:', err))
  }

  // Hit-location HP is computed in prepareDerivedData by the Mythras
  // patch; just re-render the sheet so the new location appears with
  // the correct HP straight away. Guard against world-scope creation
  // where item.parent is null (side-finding #19, fixed in v1.0.0-alpha.11).
  if (item.type === 'hit-location') {
    if (item.parent?.sheet?.rendered) item.parent.sheet.render(false)
  }

  // Wound created → check if the affected hit-location is now at 0 HP
  // and fire a critical roll. We re-prep the actor's data so currHP is
  // current after the new wound is included, then read the location.
  if (item.type === 'wound' ) {
    const actor = item.parent
    const locId = item.system?.locId
    if (!locId) return

    // Defer briefly so the BRP-base prep cycle has a chance to recompute currHP
    // from the new wound. Without this, item.system.currHP still reflects
    // pre-wound state.
    setTimeout(() => {
      const loc = actor.items.get(locId)
      if (!loc || loc.type !== 'hit-location') return
      const curr = loc.system?.currHP ?? 0
      const max  = loc.system?.maxHP  ?? 0
      if (max > 0 && curr <= 0) {
        ElysiumCriticalRoller.rollCritical(actor, loc).catch(err =>
          console.error('Elysium | Critical roll failed:', err))

        // v0.22.0-alpha.10: Major Wound also damages armor on the
        // location. Per the flat-AP rules, each equipped armor piece
        // loses 1 AP; broken at 0.
        ElysiumArmorWear.applyCritDamageToArmorAtLocation(actor, locId, 'major-wound')
          .catch(err => console.error('Elysium | Armor wear (major-wound) failed:', err))
      }
    }, 50)
  }

  // v0.10.6: wound-created disruption prompt. Any path that creates a
  // wound (sheet button, macro, manual item-create, ongoing-bleed) gets
  // checked for active sustains and posts the disruption prompt. This
  // is more reliable than the previous hook in ElysiumDamage.addDamage,
  // which only fired for the specific sheet-button path.
  if (item.type === 'wound') {
    const actor = item.parent
    if (!actor) return
    const api = game.system.api?.casting
    const sustains = api?.getActiveSustains?.(actor) ?? []
    console.debug('Elysium wound-created disruption check:', {
      actorName: actor.name,
      sustainCount: sustains.length,
      damage: item.system?.value,
    })
    if (sustains.length > 0) {
      const buttons = sustains.map(s =>
        `<button type="button" class="elysium-disrupt-btn"
                data-actor-id="${actor.id}"
                data-spell-id="${s.spellId}"
                data-spell-name="${s.spellName}">
           Disrupt: ${s.spellName}
         </button>`).join(' ')
      // Per c2 audit D4: edge case — `.elysium-disrupt-btn` class is JS-imperative
      // (audit-5 hook in chat-card.mjs:225). Caller-built body preserves the
      // button class verbatim.
      const body = `<p><strong>${actor.name}</strong> took damage while sustaining
        ${sustains.length === 1 ? 'a spell' : `${sustains.length} spells`}.</p>
        <div class="elysium-disrupt-buttons">${buttons}</div>`
      foundry.applications.handlebars.renderTemplate(
        'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
        { variant: 'danger', icon: 'bolt', body }
      ).then(html =>
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: html,
        })
      ).catch(err => console.error('Elysium | disruption chat post failed:', err))
    }

    // v0.16.0: active-cast disruption. If the actor is mid-cast on a
    // multi-turn arcane spell (with accumulated SL), post a Willpower
    // save prompt. The player rolls themselves; on failure, accumulated
    // SL is reduced by wound severity (1 minor / 2 serious / all critical).
    const disruption = api?.checkActiveCastDisruption?.(actor, item)
    if (disruption) {
      const slLossText = disruption.slLoss === 'all'
        ? 'all accumulated SL'
        : `${disruption.slLoss} SL`
      const willpowerHint = disruption.willpower.found
        ? `Willpower ${disruption.willpower.total}%`
        : `no Willpower skill — automatic failure`
      // Per c2 audit D4: edge case — `.elysium-cast-disrupt-btn` class is
      // JS-imperative (audit-5 hook in chat-card.mjs:170). Caller-built body
      // preserves the button class verbatim.
      const body = `<p><strong>${actor.name}</strong> took damage mid-cast
          (${disruption.activeCast.spellName} — SL ${disruption.activeCast.accumulatedSL}/${disruption.activeCast.requiredSL}).</p>
        <p>Roll Willpower (${willpowerHint}) to keep concentration. Failure costs ${slLossText}.</p>
        <div class="elysium-cast-disrupt-buttons">
          <button type="button" class="elysium-cast-disrupt-btn"
                  data-actor-id="${actor.id}"
                  data-wound-id="${item.id}"
                  data-severity="${disruption.severity}"
                  data-sl-loss="${disruption.slLoss}"
                  data-damage="${disruption.damage}">
            Roll Willpower vs. Disruption
          </button>
        </div>`
      foundry.applications.handlebars.renderTemplate(
        'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
        { variant: 'danger', icon: 'bolt', body }
      ).then(html =>
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: html,
        })
      ).catch(err => console.error('Elysium | cast-disrupt chat post failed:', err))
    }
  }
}

export async function _onDeleteItem (item, options, userId) {

  // Clean up ancestry-related items when ancestry removed
  if (item.type === 'culture' && getSetting('enableAncestrySystem', true)) {
    return await ElysiumAncestryDrop.handlePostDelete(item, options, userId)
  }

  // No special-case for armor deletion: the item's modifier AEs
  // are embedded on the item, so they cease to exist when the item
  // does. Foundry will re-derive actor flags automatically.
}

export function _onPreUpdateItem (item, change, options, userId) {
  if (!item.parent) return

  // (Hit location HP isn't updated directly by BRP-base — currHP is derived
  // from wound items in prepareDerivedData. Critical threshold detection
  // happens in _onCreateItem when a new wound is added; see below.)

  // Weapon Mythras-fields sync: when system.elysium.{reach, rangeClose,
  // rangeEffective, rangeLong} change, update system.range1/2/3 strings
  // so existing BRP-base consumers (Combat tab display, NPC sheet, attack
  // chat card) read sensible values without changes.
  //
  //   range1 = melee reach letter (T/S/M/L/VL/H) OR close band number
  //   range2 = effective band number (ranged or throwable)
  //   range3 = long band number (ranged or throwable)
  //
  // For pure melee weapons (no range bands), range1 = reach and range2/3
  // are blank. For pure ranged, range1 = close band. For throwable
  // melee+ranged weapons, range1 = reach (the melee context wins for
  // the display string), and range2/3 are the throwable bands.
  if (item.type === 'weapon' && change.system?.elysium) {
    const cur = item.system?.elysium || {}
    const next = foundry.utils.mergeObject(
      foundry.utils.deepClone(cur),
      change.system.elysium,
      { inplace: false }
    )
    const isMelee = next.isMelee !== false
    const reach   = next.reach || 'M'
    const rc = Number(next.rangeClose) || 0
    const re = Number(next.rangeEffective) || 0
    const rl = Number(next.rangeLong) || 0
    const hasRangeBands = rc > 0 || re > 0 || rl > 0

    let r1, r2, r3
    if (isMelee && !hasRangeBands) {
      // Pure melee — show reach letter
      r1 = reach
      r2 = ''
      r3 = ''
    } else if (isMelee && hasRangeBands) {
      // Throwable melee weapon — reach letter, then thrown bands
      r1 = reach
      r2 = re > 0 ? String(re) : (rc > 0 ? String(rc) : '')
      r3 = rl > 0 ? String(rl) : ''
    } else {
      // Ranged — three numeric bands
      r1 = rc > 0 ? String(rc) : ''
      r2 = re > 0 ? String(re) : ''
      r3 = rl > 0 ? String(rl) : ''
    }
    foundry.utils.setProperty(change, 'system.range1', r1)
    foundry.utils.setProperty(change, 'system.range2', r2)
    foundry.utils.setProperty(change, 'system.range3', r3)
  }

  // Armor layering enforcement (WFRP 4e rules): when an armor piece is being
  // equipped, validate against the existing worn pieces on the same location.
  //
  // Rules:
  //   - Natural layer items stack freely (intrinsic armor).
  //   - Magical layer: one piece per location.
  //   - Worn layer: stratified into soft (leather/padded), mail (chain/scale),
  //     and plate (rigid steel). One piece per stratum per location, and total
  //     worn AP per location capped at 5 (1 soft + 2 mail + 2 plate).
  //   - The legacy 'flexibility' field maps to wornStratum if not explicitly set:
  //     'flexible' → soft, 'inflexible' → plate, 'natural' → natural layer.
  if (item.type === 'armor' &&
      change.system?.equipStatus === 'equipped' &&
      item.system?.equipStatus !== 'equipped' ) {

    const conflict = checkArmorLayerConflict(item)
    if (conflict) {
      ui.notifications.warn(conflict)
      return false    // sync false — actually cancels the update in V14
    }
  }
}

export async function _onUpdateItem (item, change, options, userId) {
  if (game.userId !== userId) return

  // Item equipStatus changed → sync the enable state of all item-modifier
  // AEs on this item. When the item is worn/wielded the AEs apply; when
  // it's not, they're disabled. This replaces the previous derived-stat
  // recalc, since modifiers now live as real AEs rather than cached flags.
  if ((item.type === 'armor' || item.type === 'weapon' || item.type === 'gear')
      && change.system?.equipStatus !== undefined) {
    syncEquipState(item).catch(err =>
      console.error('Elysium | item-modifier equip sync failed:', err))
  }

  // Hit-location bleeding flag changed → write a Bleeding entry to the
  // location's locationConditions list (v0.6.0 source of truth).
  //
  // BRP-base damage.mjs sets `system.bleeding: true` on hit-locations at
  // certain damage thresholds. We hook that and route it through the
  // factory's per-location API so the round-tick and Status-column
  // rendering pick it up.
  //
  // No actor-level AE is created — the chip aggregator
  // (factory.getLocationConditionsByName) walks every location.
  if (item.type === 'hit-location' && change.system?.bleeding !== undefined) {
    const actor = item.parent
    const isBleeding = change.system.bleeding === true

    if (isBleeding) {
      ElysiumActiveEffectFactory.applyLocationCondition(
        actor, item.id, 'Bleeding',
        { source: 'damage-threshold' }
      ).catch(err => console.error('Elysium | per-location Bleeding apply failed:', err))
    } else {
      ElysiumActiveEffectFactory.removeLocationCondition(actor, item.id, 'Bleeding')
        .catch(err => console.error('Elysium | per-location Bleeding remove failed:', err))
    }
  }
}

export function _absorbWithTempHP (woundItem, data, options, userId) {
  const actor = woundItem.parent
  if (!actor) return
  if (game.userId !== userId) return    // only the issuing client adjusts THP

  const tempHP = actor.system?.tempHP?.value || 0
  if (tempHP <= 0) return    // nothing to absorb with

  const damage = Number(woundItem.system?.value || 0)
  if (damage <= 0) return

  const absorbed = Math.min(tempHP, damage)
  const remainingTempHP = tempHP - absorbed
  const remainingDamage = damage - absorbed

  // Fire-and-forget: update THP pool and post chat card. We don't await
  // these — the hook return value is what cancels/allows the wound.
  // If the user spams damage faster than these promises resolve, we
  // might briefly read a stale THP value on the next absorption, but
  // the actor.update is queued so the persisted state stays correct.
  actor.update({ 'system.tempHP.value': remainingTempHP },
               { render: false })
    .catch(err => console.error('Elysium | THP update failed:', err))

  const body = `<p><strong>${actor.name}</strong>: Temp HP absorbed ${absorbed} damage `
             + `(${remainingTempHP} Temp HP remaining`
             + (remainingDamage > 0 ? `; ${remainingDamage} damage carries through to hit location` : '')
             + `).</p>`
  foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/parts/chat-card-notice.hbs',
    { variant: 'info', icon: 'shield-heart', body }
  ).then(html =>
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: html,
    })
  ).catch(err => console.error('Elysium | THP chat card failed:', err))

  if (remainingDamage <= 0) {
    // Fully absorbed — cancel wound creation. Returning false from a
    // sync hook is what Foundry actually checks.
    return false
  }

  // Partial absorption — mutate the pending wound's source data
  // synchronously so it persists at the new value when Foundry
  // proceeds with the create.
  woundItem.updateSource({ 'system.value': remainingDamage })
  return undefined    // allow creation to proceed
}
