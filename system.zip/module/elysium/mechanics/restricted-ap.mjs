/**
 * Elysium Restricted Action Points — v0.14.0
 * --------------------------------------------
 * The actor.system.actionPoints schema has multiple AP pools:
 *   - value / max:          general AP, usable for any action
 *   - attackValue / attackMax:  AP usable only for attacks
 *   - defenseValue / defenseMax: AP usable only for parry/evade/defensive
 *   - reactValue / reactMax:    AP usable only for reactions
 *
 * Abilities like Combat Stance grant restricted AP. This module provides
 * helpers for granting/removing restricted AP at activation/deactivation,
 * and for spending AP intelligently from the right pool when an action
 * type is declared.
 *
 * Spending priority:
 *   - For an attack: attackValue → value (restricted is preferred so
 *     general AP is preserved for other purposes)
 *   - For a defense: defenseValue → value
 *   - For a reaction: reactValue → value
 *   - For unrestricted: value only
 */

/**
 * Grant restricted AP to an actor. Used by ability activation hooks.
 *
 * @param {Actor} actor
 * @param {'attack'|'defense'|'react'|'general'} restriction
 * @param {number} amount - typically 1
 */
export async function grantRestrictedAP(actor, restriction, amount = 1) {
  const ap = actor.system.actionPoints || {}
  const updates = {}

  switch (restriction) {
    case 'attack':
      updates['system.actionPoints.attackValue'] = (ap.attackValue || 0) + amount
      updates['system.actionPoints.attackMax']   = (ap.attackMax || 0) + amount
      break
    case 'defense':
      updates['system.actionPoints.defenseValue'] = (ap.defenseValue || 0) + amount
      updates['system.actionPoints.defenseMax']   = (ap.defenseMax || 0) + amount
      break
    case 'react':
      updates['system.actionPoints.reactValue'] = (ap.reactValue || 0) + amount
      updates['system.actionPoints.reactMax']   = (ap.reactMax || 0) + amount
      break
    case 'general':
      updates['system.actionPoints.value'] = (ap.value || 0) + amount
      updates['system.actionPoints.max']   = (ap.max || 0) + amount
      break
    default:
      console.warn(`[elysium] grantRestrictedAP: unknown restriction '${restriction}'`)
      return
  }

  await actor.update(updates)
}

/**
 * Remove restricted AP from an actor. Used by ability deactivation hooks.
 *
 * @param {Actor} actor
 * @param {'attack'|'defense'|'react'|'general'} restriction
 * @param {number} amount - typically 1
 */
export async function removeRestrictedAP(actor, restriction, amount = 1) {
  const ap = actor.system.actionPoints || {}
  const updates = {}

  switch (restriction) {
    case 'attack':
      updates['system.actionPoints.attackValue'] = Math.max(0, (ap.attackValue || 0) - amount)
      updates['system.actionPoints.attackMax']   = Math.max(0, (ap.attackMax || 0) - amount)
      break
    case 'defense':
      updates['system.actionPoints.defenseValue'] = Math.max(0, (ap.defenseValue || 0) - amount)
      updates['system.actionPoints.defenseMax']   = Math.max(0, (ap.defenseMax || 0) - amount)
      break
    case 'react':
      updates['system.actionPoints.reactValue'] = Math.max(0, (ap.reactValue || 0) - amount)
      updates['system.actionPoints.reactMax']   = Math.max(0, (ap.reactMax || 0) - amount)
      break
    case 'general':
      updates['system.actionPoints.value'] = Math.max(0, (ap.value || 0) - amount)
      updates['system.actionPoints.max']   = Math.max(0, (ap.max || 0) - amount)
      break
    default:
      console.warn(`[elysium] removeRestrictedAP: unknown restriction '${restriction}'`)
      return
  }

  await actor.update(updates)
}

/**
 * Spend AP from the appropriate pool based on action type.
 * Tries restricted pool first, falls back to general value pool.
 *
 * @param {Actor} actor
 * @param {'attack'|'defense'|'react'|'general'} actionType
 * @param {number} amount - typically 1
 * @returns {Promise<boolean>} - true if spent, false if not enough AP available
 */
export async function spendActionPoint(actor, actionType, amount = 1) {
  const ap = actor.system.actionPoints || {}
  const updates = {}

  // First try the restricted pool matching the action type
  let remaining = amount
  switch (actionType) {
    case 'attack':
      if (ap.attackValue >= remaining) {
        updates['system.actionPoints.attackValue'] = ap.attackValue - remaining
        remaining = 0
      } else if (ap.attackValue > 0) {
        updates['system.actionPoints.attackValue'] = 0
        remaining -= ap.attackValue
      }
      break
    case 'defense':
      if (ap.defenseValue >= remaining) {
        updates['system.actionPoints.defenseValue'] = ap.defenseValue - remaining
        remaining = 0
      } else if (ap.defenseValue > 0) {
        updates['system.actionPoints.defenseValue'] = 0
        remaining -= ap.defenseValue
      }
      break
    case 'react':
      if (ap.reactValue >= remaining) {
        updates['system.actionPoints.reactValue'] = ap.reactValue - remaining
        remaining = 0
      } else if (ap.reactValue > 0) {
        updates['system.actionPoints.reactValue'] = 0
        remaining -= ap.reactValue
      }
      break
  }

  // Fall back to general value pool for whatever's left
  if (remaining > 0) {
    if ((ap.value || 0) < remaining) {
      // Not enough AP; revert and report failure
      return false
    }
    updates['system.actionPoints.value'] = ap.value - remaining
  }

  await actor.update(updates)
  return true
}

/**
 * Reset all restricted AP pools to their max at the start of a new round.
 *
 * Called from the combat round-start hook. Restricted AP doesn't carry
 * over between rounds — it refreshes alongside the general pool.
 *
 * @param {Actor} actor
 */
export async function refreshActionPoints(actor) {
  const ap = actor.system.actionPoints || {}
  const updates = {}

  if (ap.max != null) {
    updates['system.actionPoints.value'] = ap.max
  }
  if (ap.attackMax != null) {
    updates['system.actionPoints.attackValue'] = ap.attackMax
  }
  if (ap.defenseMax != null) {
    updates['system.actionPoints.defenseValue'] = ap.defenseMax
  }
  if (ap.reactMax != null) {
    updates['system.actionPoints.reactValue'] = ap.reactMax
  }

  await actor.update(updates)
}
