import { ElysiumMenu } from '../setup/menu.mjs'
export default function (app, html, data) {
  if (typeof html.querySelector === 'function') {
    html.querySelector('button[data-tool="elysiumdummy"]')?.closest('li').remove()
  }
  ElysiumMenu.renderControls(app, html, data)
}
