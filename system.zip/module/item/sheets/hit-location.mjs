import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Hit-location item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Single-page mode (TAB_ORDER = null) per c3-hitloc-1: the legacy
 * sheet had only the details tab anyway; the degenerate 1-chip tab
 * strip is now eliminated.
 *
 * PARTS: header + details only (no description, no gmNotes — this
 * sheet has no narrative content).
 *
 * Form handler synthesizes `item.name` from displayName + bodyPlan
 * so the sheet header (which writes name="system.displayName") and
 * the actor's hit-location grid (which reads `item.name`) stay in
 * sync.
 */
export class ElysiumHitLocSheet extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['hit-location'],
    position: { width: 560, height: 640 },
    form: { handler: ElysiumHitLocSheet.myHitLocHandler },
  }

  static PARTS = {
    header:  { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    details: {
      template:  'systems/elysium/templates/item/hit-location.detail.hbs',
      scrollable: [''],
    },
  }

  static TAB_ORDER = null  // single-page

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    context.locTypeOptions = await ElysiumSelectLists.getHitLocType()
    context.hitLocName = game.i18n.localize('Elysium.' + this.item.system.locType)

    // Header chips per c3-2: Location Type + (when owned) HP Adjustment
    const chips = [
      { label: game.i18n.localize('Elysium.hitLocType'), value: context.hitLocName },
    ]
    if (context.hasOwner) {
      chips.push({
        label: game.i18n.localize('Elysium.hpAdj', { label: this.item.system.healthLabelAbbr }),
        value: String(this.item.system.adj ?? 0),
      })
    }
    context.itemHeaderChips = chips

    return context
  }

  /**
   * Sheet form-submission handler. Synthesizes the item's `name` from
   * displayName + bodyPlan so a unique key exists for inheritance
   * lookups when the same location appears across multiple species.
   */
  static async myHitLocHandler(event, form, formData) {
    const displayName = formData.object['system.displayName'] || this.item.system.displayName
    const bodyPlan = formData.object['system.bodyPlan'] || this.item.system.bodyPlan
    formData.object.name = bodyPlan === ''
      ? displayName
      : displayName + ' (' + bodyPlan + ')'
    await this.document.update(formData.object)
  }
}
