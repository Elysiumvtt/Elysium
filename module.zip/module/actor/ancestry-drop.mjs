/**
 * Elysium Ancestry Drop Handler
 *
 * Hooks into the BRP culture item drop sequence to:
 *   - Confirm replacement if existing ancestry present
 *   - Apply stat modifiers as Active Effects
 *   - Apply BP/SP adjustments
 *   - Create Mutation items for racial traits
 *   - Apply natural armour/weapons
 *   - Apply resistance Active Effects
 *   - Add starting languages
 *   - Adjust stat natural maxima
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'
import { ElysiumData } from '../helpers/data.mjs'

export class ElysiumAncestryDrop {

  static async handlePreCreate (item, data, options, userId) {
    // Only handle if this is being added to an actor and has elysium flag
    if (!item.parent) return true
    const ancestryData = ElysiumData.path(item, 'ancestry')
    if (!ancestryData) return true   // not an Elysium ancestry, leave to BRP

    const actor = item.parent

    // Check for existing ancestry on the actor
    const existing = actor.items.find(i =>
      i.type === 'culture' &&
      ElysiumData.path(i, 'ancestry') &&
      i.id !== item.id
    )

    if (existing) {
      // Show replacement dialog
      const confirmed = await this._confirmReplacement(actor, existing, item)
      if (!confirmed) return false

      // Remove existing ancestry items, AEs, mutations
      await this._cleanupAncestry(actor, existing.id)
      await existing.delete()
    }

    // Check for subraces
    if (ancestryData.subraces?.length > 0) {
      const subraceChoice = await this._chooseSubrace(item)
      if (!subraceChoice) return false
      // Store choice for post-create
      options.elysiumSubraceUuid = subraceChoice
    }

    return true
  }

  static async handlePostCreate (item, options, userId) {
    if (!item.parent) return
    const ancestry = ElysiumData.path(item, 'ancestry')
    if (!ancestry) return

    const actor = item.parent

    // 1. Apply stat modifiers as Active Effects
    if (ancestry.statMods?.length > 0) {
      await this._applyStatModifiers(actor, item, ancestry.statMods)
    }

    // 2. Adjust BP/SP pools
    if (ancestry.buildPoints || ancestry.skillPoints) {
      await this._adjustPointPools(actor, ancestry)
    }

    // 3. Create racial trait Mutations
    if (ancestry.traits?.length > 0) {
      await this._createTraitMutations(actor, item, ancestry.traits)
    }

    // 4. Apply natural armour
    if (ancestry.naturalArmour?.ap > 0) {
      await this._applyNaturalArmour(actor, item, ancestry.naturalArmour)
    }

    // 5. Apply natural weapons
    if (ancestry.naturalWeapons?.length > 0) {
      await this._applyNaturalWeapons(actor, item, ancestry.naturalWeapons)
    }

    // 6. Apply resistance AEs
    if (ancestry.resistances) {
      await this._applyResistances(actor, item, ancestry.resistances)
    }

    // 7. Apply starting languages
    if (ancestry.languages?.length > 0) {
      await this._applyLanguages(actor, ancestry.languages)
    }

    // 8. Adjust natural stat maxima
    await this._adjustStatMaxima(actor, ancestry.statMods)

    // 9. Update move stats from ancestry
    await this._applyAncestryMove(actor, ancestry)

    // 10. Process subrace if selected
    if (options.elysiumSubraceUuid) {
      const subraceItem = await fromUuid(options.elysiumSubraceUuid)
      if (subraceItem) {
        const subraceData = subraceItem.toObject()
        subraceData.flags.elysium = subraceData.flags.elysium || {}
        subraceData.flags.elysium.ancestry = subraceData.flags.elysium.ancestry || {}
        subraceData.flags.elysium.ancestry.parentId = item.id
        subraceData.flags.elysium.ancestry.isSubrace = true
        await actor.createEmbeddedDocuments('Item', [subraceData])
      }
    }

    // Record ancestry on actor
    await actor.update({
      'flags.elysium.ancestryId': item.id
    }, { render: false })

    ui.notifications.info(
      game.i18n.format('Elysium.Ancestry.Applied', { name: item.name })
    )
  }

  static async handlePostDelete (item, options, userId) {
    if (!item.parent) return
    if (!ElysiumData.path(item, 'ancestry')) return
    await this._cleanupAncestry(item.parent, item.id)
  }


  // === IMPLEMENTATION ===============================================

  static async _confirmReplacement (actor, existing, newItem) {
    return new Promise(resolve => {
      const content = `
        <div class="elysium-dialog">
          <p>${game.i18n.localize('Elysium.Ancestry.ReplaceWarning')}</p>
          <ul>
            <li><strong>${game.i18n.localize('Elysium.Ancestry.Current')}:</strong> ${existing.name}</li>
            <li><strong>${game.i18n.localize('Elysium.Ancestry.New')}:</strong> ${newItem.name}</li>
          </ul>
          <p>${game.i18n.localize('Elysium.Ancestry.ReplaceConsequences')}</p>
        </div>
      `
      new foundry.applications.api.DialogV2({
        window: { title: game.i18n.localize('Elysium.Ancestry.ReplaceTitle') },
        content,
        buttons: [
          { action: 'cancel', label: game.i18n.localize('Cancel'),
            callback: () => resolve(false) },
          { action: 'confirm', label: game.i18n.localize('Elysium.Ancestry.Replace'),
            default: true, callback: () => resolve(true) },
        ],
      }).render(true)
    })
  }

  static async _chooseSubrace (item) {
    return new Promise(resolve => {
      const subraces = item.flags.elysium.ancestry.subraces
      const options = subraces.map(s => `<option value="${s.uuid}">${s.name}</option>`).join('\n')

      new foundry.applications.api.DialogV2({
        window: { title: game.i18n.localize('Elysium.Ancestry.ChooseSubrace') },
        content: `
          <div class="elysium-dialog">
            <p>${game.i18n.localize('Elysium.Ancestry.ChooseSubraceHint')}</p>
            <select id="subrace-select">${options}</select>
          </div>
        `,
        buttons: [
          { action: 'cancel', label: game.i18n.localize('Cancel'),
            callback: () => resolve(null) },
          { action: 'apply', label: game.i18n.localize('Apply'),
            default: true,
            callback: (event, button, dialog) => {
              const select = dialog.element.querySelector('#subrace-select')
              resolve(select?.value || null)
            }},
        ],
      }).render(true)
    })
  }

  static async _applyStatModifiers (actor, ancestryItem, statMods) {
    const effects = []
    for (const mod of statMods) {
      effects.push({
        name: `${ancestryItem.name}: ${mod.stat.toUpperCase()} ${mod.value >= 0 ? '+' : ''}${mod.value}`,
        icon: 'icons/svg/aura.svg',
        origin: ancestryItem.uuid,
        flags: {
          elysium: {
            ancestryMod: true,
            ancestryId:  ancestryItem.id,
            statMod:     true,
          }
        },
        changes: [{
          key:   `system.stats.${mod.stat.toLowerCase()}.culture`,
          mode:  CONST.ACTIVE_EFFECT_MODES.ADD,
          value: String(mod.value),
        }],
        disabled: false,
        transfer: false,
      })
    }
    if (effects.length > 0) {
      await actor.createEmbeddedDocuments('ActiveEffect', effects)
    }
  }

  static async _adjustPointPools (actor, ancestry) {
    const flags = actor.flags?.elysium || {}
    const buildPoints = flags.buildPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    const skillPoints = flags.skillPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }

    buildPoints.ancestry += (ancestry.buildPoints || 0)
    skillPoints.ancestry += (ancestry.skillPoints || 0)

    buildPoints.remaining = buildPoints.total + buildPoints.ancestry - buildPoints.spent
    skillPoints.remaining = skillPoints.total + skillPoints.ancestry - skillPoints.spent

    await actor.update({
      'flags.elysium.buildPoints': buildPoints,
      'flags.elysium.skillPoints': skillPoints,
    }, { render: false })
  }

  static async _createTraitMutations (actor, ancestryItem, traits) {
    const itemsToCreate = []
    for (const trait of traits) {
      try {
        const sourceItem = await fromUuid(trait.uuid)
        if (!sourceItem) {
          console.warn(`Elysium | Could not load mutation ${trait.uuid}`)
          continue
        }
        const data = sourceItem.toObject()
        data.flags.elysium = data.flags.elysium || {}
        data.flags.elysium.ancestryMod = true
        data.flags.elysium.ancestryId = ancestryItem.id
        itemsToCreate.push(data)
      } catch (e) {
        console.warn(`Elysium | Error loading trait ${trait.uuid}: ${e.message}`)
      }
    }
    if (itemsToCreate.length > 0) {
      await actor.createEmbeddedDocuments('Item', itemsToCreate)
    }
  }

  static async _applyNaturalArmour (actor, ancestryItem, naturalArmour) {
    const data = {
      name: `${ancestryItem.name} (Natural Armour)`,
      type: 'armour',
      img:  ancestryItem.img || 'icons/svg/aura.svg',
      system: {
        av1: naturalArmour.ap || 0,
        enc: 0,
        equipStatus: 'worn',
        coverage: naturalArmour.locations || 'all',
      },
      flags: {
        elysium: {
          flexibility:   'natural',
          layerOrder:    0,
          material:      'natural',
          ancestryMod:   true,
          ancestryId:    ancestryItem.id,
          armorHP:       { value: 999, max: 999 },   // natural armour effectively unbreakable
        }
      }
    }
    await actor.createEmbeddedDocuments('Item', [data])
  }

  static async _applyNaturalWeapons (actor, ancestryItem, weapons) {
    const items = []
    for (const w of weapons) {
      try {
        const source = await fromUuid(w.uuid || w)
        if (!source) continue
        const data = source.toObject()
        data.flags.elysium = data.flags.elysium || {}
        data.flags.elysium.ancestryMod = true
        data.flags.elysium.ancestryId  = ancestryItem.id
        items.push(data)
      } catch (e) {
        console.warn(`Elysium | natural weapon load fail: ${e.message}`)
      }
    }
    if (items.length > 0) await actor.createEmbeddedDocuments('Item', items)
  }

  static async _applyResistances (actor, ancestryItem, resistances) {
    const effects = []
    for (const dmgType in resistances) {
      const tier = resistances[dmgType]
      effects.push({
        name: `${ancestryItem.name}: ${dmgType} ${tier}`,
        icon: 'icons/svg/aura.svg',
        origin: ancestryItem.uuid,
        flags: {
          elysium: {
            ancestryMod: true,
            ancestryId:  ancestryItem.id,
            resistance:  { damageType: dmgType, tier },
          }
        },
        changes: [],   // logical only — read by damage resolver
        disabled: false,
        transfer: false,
      })
    }
    if (effects.length > 0) {
      await actor.createEmbeddedDocuments('ActiveEffect', effects)
    }
  }

  static async _applyLanguages (actor, languages) {
    const current = actor.flags?.elysium?.languages || []
    const merged = Array.from(new Set([...current, ...languages]))
    await actor.update({
      'flags.elysium.languages': merged
    }, { render: false })
  }

  static async _adjustStatMaxima (actor, statMods) {
    if (!statMods?.length) return
    const maxima = actor.flags?.elysium?.statNaturalMax || {}
    for (const mod of statMods) {
      const stat = mod.stat.toLowerCase()
      const baseMax = ELYSIUM.STAT_NATURAL_MAX_BASE
      maxima[stat] = baseMax + mod.value
    }
    await actor.update({
      'flags.elysium.statNaturalMax': maxima
    }, { render: false })
  }

  static async _applyAncestryMove (actor, ancestry) {
    if (typeof ancestry.baseMove === 'number') {
      await actor.update({
        'system.move': ancestry.baseMove,
        'flags.elysium.ancestryMove': {
          baseMove: ancestry.baseMove,
          flyMove:  ancestry.flyMove || 0,
          swimMove: ancestry.swimMove || 0,
        }
      }, { render: false })
    }
  }

  static async _cleanupAncestry (actor, ancestryId) {
    // Remove items with this ancestry mod flag
    const itemsToDelete = actor.items
      .filter(i => i.flags?.elysium?.ancestryId === ancestryId)
      .map(i => i.id)
    if (itemsToDelete.length > 0) {
      await actor.deleteEmbeddedDocuments('Item', itemsToDelete)
    }

    // Remove AEs with this ancestry mod flag
    const effectsToDelete = actor.effects
      .filter(e => e.flags?.elysium?.ancestryId === ancestryId)
      .map(e => e.id)
    if (effectsToDelete.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', effectsToDelete)
    }

    // Reset point pool ancestry adjustments
    const flags = actor.flags?.elysium || {}
    const buildPoints = flags.buildPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    const skillPoints = flags.skillPoints || { total: 0, ancestry: 0, spent: 0, remaining: 0 }
    buildPoints.ancestry = 0
    skillPoints.ancestry = 0
    buildPoints.remaining = buildPoints.total - buildPoints.spent
    skillPoints.remaining = skillPoints.total - skillPoints.spent

    await actor.update({
      'flags.elysium.buildPoints': buildPoints,
      'flags.elysium.skillPoints': skillPoints,
      'flags.elysium.ancestryId': '',
      'flags.elysium.statNaturalMax': {},
    }, { render: false })
  }
}
