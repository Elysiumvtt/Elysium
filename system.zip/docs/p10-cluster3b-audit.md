# P10 cluster 3b — 3 drag/drop item types (prep audit)

Captured 2026-05-14 after cluster 3a (alpha.40) smoke pass.
**Audit-then-stop**: no code shipped from this document.

## Scope

Cluster 3b covers the 3 drag/drop sheets deferred from cluster 3a per c3-8 split:

| Type | Sheet LOC | Detail LOC | Mode | Key features |
|---|--:|--:|---|---|
| super | 278 | 70 | tabbed (560×640) | Custom header (skill.header.hbs); custom form handler (name from mainName+specName when specialism); drag/drop for powerMod items; 2 toggle chips; powerMod drop list with item-view + item-delete listeners |
| personality | 354 | 80 | tabbed (560×640) | Skill collection + optional groups; ElysiumUtilities.fromElysiumIDBest lookup; add/remove group buttons; 4 legacy class-hook listeners |
| culture | 397 | 126 | tabbed (560×640) | All of personality++ PLUS stat-formula 2-col grid PLUS per-skill cultural bonus (ElysiumDialog.input on drop) |

Total surface: **~1029 LOC of sheet classes + ~276 LOC of templates**.

### Width plan

All 3 stay 560×640 per cluster 3 audit-3 (none in the wide-tier bracket).

## 1. Major hoisting opportunities

### 1.1 Drag/drop boilerplate hoist

All 3 cluster-3b sheets (super, personality, culture) PLUS skill (cluster 5)
share these 8 identical methods, bit-identical across all 4:

- `_canDragStart(selector)` — returns `this.isEditable`
- `_canDragDrop(selector)` — returns `this.isEditable`
- `_onDragStart(event)` — extracts effectId; sets dataTransfer with effect.toDragData()
- `_onDragOver(event)` — no-op
- `_onDropItem(event, data)` — returns `false` unless owner
- `_onDropFolder(event, data)` — returns `[]` unless owner
- `get dragDrop()` — returns `#dragDrop`
- `#createDragDropHandlers()` — maps `options.dragDrop` to V14 DragDrop instances

Per c3-isolation-1 decision: **hoist into a new `ElysiumDragDropItemSheet`
intermediate base class** between `ElysiumItemSheetV2` and the 3
cluster-3b sheets. Skill is NOT touched in cluster 3b (cluster isolation).
Cluster 5 will then re-parent skill onto this intermediate base too.

Decision: **`ElysiumDragDropItemSheet extends ElysiumItemSheetV2`**.
File: `module/item/sheets/base-dragdrop-item-sheet.mjs`. Constructor
calls `#createDragDropHandlers()`; all 8 methods live there.

Sub-classes that need drag/drop:
1. Add `dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }]` to DEFAULT_OPTIONS (V14 reads this).
2. Inherit the 8 methods automatically.
3. Override `_onDrop` with type-specific semantics (super-style "create
   embedded item" vs personality-style "reference existing" vs
   culture-style "reference + bonus dialog").

LOC saved: ~62 lines per sheet × 3 = ~186 LOC. (Skill will save another
~62 in cluster 5.)

### 1.2 Specialism-aware header partial

Per c3-super-1: `templates/item/skill.header.hbs` (17 lines) is shared
by super + skill. v1.0.0 rebuild needs a v1.0.0 version. Decision: new
`templates/item/parts/item-shell-header-specialism.hbs` partial.

Structure: same 3-zone layout as `item-shell-header.hbs` (image / name+type / chips)
PLUS conditional specialism inputs that replace the single name input
when `system.specialism === true`:

```hbs
{{#if item.system.specialism}}
  <div class="elysium-item-header-name-pair">
    <input class="elysium-item-header-name elysium-item-header-name--main"
           name="system.mainName" type="text" value="{{item.system.mainName}}"
           placeholder="{{localize 'Elysium.name'}}">
    <span class="elysium-item-header-name-separator">/</span>
    <input class="elysium-item-header-name elysium-item-header-name--spec"
           name="system.specName" type="text" value="{{item.system.specName}}"
           placeholder="{{localize 'Elysium.specName'}}">
  </div>
{{else}}
  <input class="elysium-item-header-name"
         name="system.mainName" type="text" value="{{item.system.mainName}}"
         placeholder="{{localize 'Elysium.name'}}">
{{/if}}
```

Critical: the underlying `item.name` is COMPUTED by the form handler
(`mySuperHandler` / `mySkillHandler` synthesize `name = mainName + ' (' + specName + ')'`).
The header DOES NOT bind `name="name"`. This is why the header partial
needs `system.mainName` + `system.specName` (NOT `item.name`).

Used by: super (cluster 3b), skill (cluster 5). The shared
`mainName + specName` form handler logic is also hoistable — see §1.4.

### 1.3 Item skill-row partial

Per c3-personality-2: extract the skill-row markup (lines 43-65 and
97-119 of culture.detail.hbs, plus lines 7-26 and 53-73 of
personality.detail.hbs).

New partial: `templates/item/parts/item-skill-row.hbs`.

Structure (consolidated from current culture pattern, since culture is
the superset):

```hbs
<div class="elysium-item-skill-row"
     data-item-id="{{skill.uuid}}"
     data-elysiumid="{{skill.elysiumid}}">
  <div class="elysium-item-skill-row-name item-view" data-tooltip="{{skill.elysiumid}}">
    {{skill.name}}
    {{#if skill.variable}}
      <span class="elysium-item-skill-row-modifier">({{localize 'Elysium.var'}})</span>
    {{else}}{{#if skill.group}}
      <span class="elysium-item-skill-row-modifier">({{localize 'Elysium.grp'}})</span>
    {{else}}
      <span class="elysium-item-skill-row-modifier">({{skill.base}}%)</span>
    {{/if}}{{/if}}
    {{#if showBonus}}
      <span class="elysium-item-skill-row-bonus">
        {{localize 'Elysium.culturalBonus'}}:
        {{#if (lt skill.bonus 0)}}{{skill.bonus}}{{else}}+{{skill.bonus}}{{/if}}%
      </span>
    {{/if}}
  </div>
  {{#if isGM}}
    <div class="elysium-item-skill-row-controls">
      <a class="elysium-item-skill-row-delete {{deleteClass}}"
         data-tooltip="{{localize 'Elysium.deleteItem'}}">
        <i class="fas fa-trash"></i>
      </a>
    </div>
  {{/if}}
</div>
```

Params:
- `skill` — REQUIRED skill data object (uuid, elysiumid, name, variable, group, base, optional bonus)
- `isGM` — gate delete control
- `showBonus` — optional, defaults false; when true (culture only), renders the cultural bonus span
- `deleteClass` — caller specifies the legacy hook for the imperative listener:
  - `'item-delete'` for main-list rows (personality + culture both)
  - `'group-item-delete'` for grouped rows (personality + culture both)
  - Audit-5 lock: legacy class hooks preserved through cluster 3b; V14-actions migration deferred to P12

Note on `item-view`: per personality's `_onItemView` (line 282-287), the
legacy listener was bound on `.item-view` class on the name span — NOT
on a separate icon. Modern V14 action handlers can sit on a name span
just fine, but per audit-5 we preserve the legacy class hook on the
SAME element it bound to (the name span itself). The new partial keeps
`item-view` on the name span; cluster 3b's `_onRender` continues to bind
the same listener to the same selector. No behavior change.

Used by: personality (cluster 3b), culture (cluster 3b), future career
(cluster 6). Three consumers means partial extraction earns its weight.

### 1.4 Shared specialism form-handler hoist (deferred to cluster 5)

`mySuperHandler` (super.mjs:146-155) and the first 8 lines of
`mySkillHandler` (skill.mjs:198-205) are bit-identical. The naming
synthesis is the shared logic. The full hoist into
`ElysiumDragDropItemSheet` makes sense — but skill is cluster 5.
**Decision: keep super's handler inline in alpha.41**. Cluster 5 will
hoist when migrating skill. Same isolation principle as §1.1.

### 1.5 Shared collection-management methods hoist (personality + culture)

Personality and culture share IDENTICAL:
- `_onItemDelete(event, collectionName = 'skills')` — splice main collection
- `_onGroupItemDelete(event)` — splice group's skills array
- `_onItemView(event)` — resolves via elysiumid → render sheet
- `_onGroupControl(event)` — add/remove group buttons

Per c3-cluster3b-1: hoist all 4 into `ElysiumDragDropItemSheet`. Sub-class
can still override (e.g. super's `_onItemDelete` ALSO calls
`oldItem.delete()` to clean up the embedded item; super's `_onItemView`
resolves via uuid not elysiumid). **Implementation**: base class provides
the personality/culture flavor as the default; super overrides both.

LOC saved: another ~40 lines per sheet × 2 (personality + culture) = ~80 LOC.

## 2. Per-type ship plan

### 2.1 super (278 → ~140 LOC)

**Structure**: tabbed, specialism-aware header, 4 numeric fields, 2
toggle chips, owner-only level/cpcSpent + powerMod drop list.

**Long-term cleanup decisions**:

1. **c3b-super-1**: Use new `item-shell-header-specialism.hbs` partial
   for header. Replaces legacy `skill.header.hbs` consumption.
   Skill (cluster 5) keeps consuming `skill.header.hbs` until its own
   migration; alternatively, we can swap skill's PARTS reference NOW
   to point at the new partial (since the new one is a strict superset
   of the legacy structure). **Recommendation: swap skill.mjs's
   PARTS.header reference too**, even though we're not rebuilding
   skill's detail template. This is a minimal targeted edit (1 line)
   that retires `skill.header.hbs` entirely, lets cluster 5 work with
   a unified partial set, and aligns skill's header presentation with
   v1.0.0 styling early. Pre-flight smoke: verify skill renders with
   the new specialism header.

   Alternative: keep `skill.header.hbs` alive until cluster 5; super
   uses new partial; skill uses legacy. Two parallel implementations
   live in the tree, more drift risk.

   **Recommendation: swap skill now (1-line PARTS change + 1-line
   form-handler swap if mySkillHandler is hoisted; otherwise just
   the PARTS change).** Cleanest path.

2. **c3b-super-2**: Preserve all 7 powerMod drop-list legacy class
   hooks (`item-list`, `item-name`, `item-view`, `item-delete`,
   `flexrow`, `item-controls`, `droppable`). Per audit-5, listeners
   bind on these classes via imperative `_onRender`. v1.0.0 markup
   layers BEM classes ON TOP without removing the legacy ones.

3. **c3b-super-3**: 2 toggle chips (specialism, chosen) already use
   `data-action="itemToggle" data-property=...`. Migrate to
   `.elysium-item-toggle` BEM class, preserving the action wiring.
   Same pattern as cluster 2's mutation/passion toggles.

4. **c3b-super-4 (existing chip plan)**: Header chips per audit-3-cluster-3:
   Range + Duration + Power Cost + (when owned) Level.

### 2.2 personality (354 → ~135 LOC)

**Structure**: tabbed, standard header, skill collection (main list) +
optional skill groups (each with their own drop target + remove
button), 4 imperative listeners.

**Long-term cleanup decisions**:

5. **c3b-personality-1**: Use new `item-skill-row.hbs` partial for
   main-list rows AND grouped rows. Saves ~40 inline template lines.

6. **c3b-personality-2**: Use `item-shell-header.hbs` (standard, no
   specialism). Personality's `name` is user-typed normally.

7. **c3b-personality-3**: Preserve all 5 legacy class hooks:
   `item-delete`, `item-view`, `group-item-delete`, `group-control`,
   `droppable`, `item-list`, `item-list.group`. Listeners bind on
   these.

8. **c3b-personality-4 (existing chip plan)**: Header chips per
   audit-3-cluster-3: (when owned) Skill Count.

### 2.3 culture (397 → ~170 LOC)

**Structure**: personality++ with stat-formula 2-column grid + per-skill
cultural bonus.

**Long-term cleanup decisions**:

9. **c3b-culture-1**: Use new `item-skill-row.hbs` with
   `showBonus=true` for both main-list and grouped rows. Replaces 
   ~50 inline template lines.

10. **c3b-culture-2**: Replace hardcoded `Cultural Bonus: ` string
    with `{{localize 'Elysium.culturalBonus'}}:` (key already added in
    alpha.40). Carried into the new item-skill-row partial design.

11. **c3b-culture-3**: Build the stat-formula row-pair structure in
    `_prepareContext` (`statPairs[]`) so the template doesn't need
    `newrow` flag gymnastics. Cleaner data shape:
    ```js
    context.statPairs = [
      [{key:'str', ...}, {key:'siz', ...}],  // row 1
      [{key:'con', ...}, {key:'int', ...}],  // row 2
      // ...
    ];
    ```
    Template loops `{{#each statPairs as |pair|}}` and renders 2 stat
    cells per row. Drops the legacy `newrow` flag and the `&nbsp` filler.

12. **c3b-culture-4**: ElysiumDialog.input prompt-on-drop for cultural
    bonus is INTERACTION logic (preserved as-is in `_onDrop` and the
    `enterValue` helper); not display. The skill-row partial just
    renders the stored bonus value.

13. **c3b-culture-5 (existing chip plan)**: Header chips per
    audit-3-cluster-3: (when owned) Skill Count + Stat Formula Count.

## 3. Action handlers / behavior preservation

| Handler | Class hook | Sheets | Notes |
|---|---|---|---|
| `itemToggle` (V14 action) | `data-action="itemToggle"` | super | specialism, chosen — registered on `ElysiumItemSheetV2` base |
| `_onItemDelete` (imperative) | `.item-delete` | super, personality, culture | super deletes embedded sub-item; personality/culture splice reference |
| `_onItemView` (imperative) | `.item-view` | super, personality, culture | super resolves via uuid; personality/culture resolve via elysiumid |
| `_onGroupItemDelete` (imperative) | `.group-item-delete` | personality, culture | splice group's skills array |
| `_onGroupControl` (imperative) | `.group-control.add-group` / `.group-control.remove-group` | personality, culture | add/remove optional skill group |
| `_onDrop` (drag/drop callback) | `.droppable` element | super, personality, culture | per-type drop semantics |

Per audit-5 cluster isolation: ALL legacy class hooks preserved in
v1.0.0 markup. V14-actions migration deferred to P12.

## 4. New shared assets

### 4.1 New partials (2)

- `templates/item/parts/item-shell-header-specialism.hbs` — used by super
  (cluster 3b), skill (cluster 5 / immediate PARTS-swap in 3b if c3b-super-1
  recommendation accepted).
- `templates/item/parts/item-skill-row.hbs` — used by personality
  (cluster 3b), culture (cluster 3b), future career (cluster 6).

Both registered in `init.mjs:2a`.

### 4.2 New i18n keys

| Key | en | es | fr | Notes |
|---|---|---|---|---|
| `Elysium.specName` | "specify" | "especificar" | "spécifier" | Placeholder for the spec-name input on specialism-aware header |
| `Elysium.skillCount` | "Skill Count" | "Número de Habilidades" | "Nombre de Compétences" | Header chip on personality + culture |
| `Elysium.statFormulaCount` | "Stat Formulas" | "Fórmulas de Características" | "Formules de Caractéristiques" | Header chip on culture |

`Elysium.culturalBonus` already added in alpha.40; reused here.

### 4.3 New base class

`module/item/sheets/base-dragdrop-item-sheet.mjs` —
`ElysiumDragDropItemSheet extends ElysiumItemSheetV2`. ~120 LOC:
constructor + 8 drag/drop boilerplate methods + 4 collection-management
defaults (personality/culture flavor) for overridable inheritance.

### 4.4 CSS additions (~120 lines estimated)

- `.elysium-item-header-name-pair` — flex row with main name / separator / spec name (specialism variant)
- `.elysium-item-header-name-separator` — the "/" between main and spec name
- `.elysium-item-header-name--main` / `--spec` — variant inputs (main wider than spec? layout-determined)
- `.elysium-item-skill-row` — flex row layout for the new partial
- `.elysium-item-skill-row-name`
- `.elysium-item-skill-row-modifier` — small grey badge for `(var)` / `(grp)` / `(N%)`
- `.elysium-item-skill-row-bonus` — culture-only bonus span (negative red, positive green)
- `.elysium-item-skill-row-controls` — trash icon
- `.elysium-item-skill-list` — wraps the `<ol>` (replaces legacy `horizontalboxed main-skills` etc.)
- `.elysium-item-skill-group` — wraps each optional group (`<ol class="item-list group">`)
- `.elysium-item-group-controls` — wraps the add/remove buttons + options input
- `.elysium-item-stat-formula-grid` (culture only) — 2-column stat formula grid

## 5. Smoke risks specific to cluster 3b

1. **Imperative listener binding through new BEM markup** — listeners
   bind on legacy class names (`.item-delete`, `.item-view`,
   `.group-item-delete`, `.group-control`, `.droppable`, `.item-list`).
   New partials MUST emit these alongside new BEM classes. Pre-flight
   grep each rebuilt template for every class name.

2. **V14 DragDrop options** — `options.dragDrop` is read at construct
   time. The new `ElysiumDragDropItemSheet` must call
   `this.#createDragDropHandlers()` after super-constructor completes
   (so `this.options` is initialized). Pre-flight: verify in browser
   that drag/drop fires on the rebuilt sheets.

3. **Specialism header switching** — currently when `specialism`
   toggles from false→true, the form re-renders, which redraws the
   header (V14 re-renders all PARTS on submitOnChange). New partial
   has conditional rendering for the name pair vs single name. Smoke:
   toggle specialism on, off, on — verify header rebuilds correctly
   each time.

4. **Cultural bonus dialog timing** — `enterValue` calls
   `ElysiumDialog.input` synchronously in the drop loop. Dialog is
   modal blocking. If the user cancels, `usage` is undefined and
   `cultureBonus` stays at 0, so the drop is skipped (line 215-216 /
   241-242 of culture.mjs). Preserve this behavior on rewrite.

5. **Per-skill cultural-bonus negative vs positive sign** — currently
   the template emits `+{{bonus}}%` when ≥0 and `{{bonus}}%` when <0
   (raw negative gets natural minus sign). Preserve in the new
   item-skill-row partial.

6. **`item-view` listener target selector** — current pattern:
   listener binds on `.item-view` element (a `<div>` containing the
   skill name). Personality's `_onItemView` calls
   `event.currentTarget.closest('.item').dataset.elysiumid` to resolve
   the parent `<li data-item-id data-elysiumid>` (or now `<div>` in
   v1.0.0). The new partial's outer wrapper uses `data-item-id` +
   `data-elysiumid` per the existing pattern. **CRITICAL**: must keep
   the `.item` class on the wrapper too, otherwise `closest('.item')`
   returns null (same buried-bug pattern as alpha.33's itemToggle and
   alpha.34's `_getEmbeddedDocument` lookups). Pre-flight: grep
   personality.mjs + culture.mjs for `.closest('.item')` and ensure
   the new partial emits class `item` on the row wrapper.

   **OR**: widen the `closest()` lookup to use `[data-item-id]`
   instead. Same fix as alphas .33 / .34. **Recommendation: widen
   the closest() lookup pattern** rather than carrying the legacy
   `.item` class — cleaner long-term, removes one more legacy
   class-hook dependency. Personality + culture + super each have 2-3
   such lookups; widening all of them is a small surgical edit.

7. **`skill.header.hbs` retirement** (if c3b-super-1 accepted) — file
   becomes orphaned after super + skill PARTS both swap to the new
   partial. Per cluster 1 retirement-of-orphans pattern (P9
   `character.skills.hbs` etc.), delete the file in this ship after
   confirming zero remaining references. Pre-flight: grep verifies 0
   refs before deletion.

8. **`ElysiumDragDropItemSheet` constructor binding race** — V14
   ApplicationV2 has a specific constructor lifecycle: super() runs
   first, then `this.options` is populated. The drag/drop handlers
   need to bind AFTER `this.options.dragDrop` is set. Current code
   binds in the sub-class constructor; hoisted code should do the
   same. Implementation: `constructor(options)` in the new base calls
   `super(options)` then `this.#dragDrop = this.#createDragDropHandlers()`.

## 6. Cluster 3b open questions for user lock-in

1. **c3b-1** — confirm all 13 cleanup decisions (numbered
   c3b-super-1 through c3b-culture-5 inline above).

2. **c3b-2** — confirm the 2 new shared partials
   (item-shell-header-specialism + item-skill-row) and the new
   base class `ElysiumDragDropItemSheet`.

3. **c3b-3** — confirm i18n key additions:
   `Elysium.specName`, `Elysium.skillCount`, `Elysium.statFormulaCount`
   (3 new keys × 3 langs = 9 entries).

4. **c3b-4 (skill PARTS swap)** — per c3b-super-1: should we swap
   skill.mjs's PARTS.header to the new specialism partial NOW (1-line
   targeted edit; retires skill.header.hbs file early), or keep skill
   on legacy `skill.header.hbs` until cluster 5 rebuilds it?
   **Recommendation: swap now** — minimal edit, cleaner tree, unifies
   the partial set.

5. **c3b-5 (closest() widening)** — per smoke risk 6: should we widen
   the `event.currentTarget.closest('.item')` lookups in personality +
   culture + super (`_onItemDelete`, `_onItemView`, `_onGroupItemDelete`)
   to use `closest('[data-item-id]')` instead, retiring the legacy
   `.item` class dependency? Same fix pattern as alphas 33/34.
   **Recommendation: yes** — small surgical edit, removes a
   class-hook dependency, no behavior change. Carries skill (cluster
   5) along since skill has the same pattern.

6. **c3b-6 (skill.header.hbs retirement)** — per smoke risk 7: if
   c3b-super-1 + c3b-4 accepted, retire the orphan file in this ship.
   **Recommendation: yes** — orphan retirement is part of cluster
   isolation pattern.

7. **c3b-7 (per-sheet LOC reduction targets)**:
   - super 278 → ~140 (-138)
   - personality 354 → ~135 (-219)
   - culture 397 → ~170 (-227)
   - Total cluster 3b: 1029 → ~445 (**-584 LOC, -57%**)
   Plus the new `ElysiumDragDropItemSheet` adds ~120 LOC. Net effect:
   1029 → 565 = **-464 LOC, -45%**.

## 7. Ready-to-go checklist

- [x] 3 sheet classes inspected (PARTS, _prepareContext, _onRender, drag/drop)
- [x] 3 detail templates inspected
- [x] Specialism header consumers identified (super + skill)
- [x] Skill-row repeated pattern identified (4 sites across personality + culture)
- [x] Per-item width plan (all 3 at 560×640)
- [x] Header chip plan per item
- [x] Cleanup decisions enumerated (13 c3b-*-N decisions)
- [x] New shared partial designs (specialism header, item-skill-row)
- [x] New base class design (ElysiumDragDropItemSheet hoisting 8 drag/drop methods + 4 collection methods)
- [x] i18n keys to add (3 new keys)
- [x] Smoke risks enumerated (8 distinct)
- [ ] User decision on 7 cluster-3b open questions
- [ ] Approval to ship cluster 3b (alpha.41)

---

**Audit posture**: read-only until user locks the 7 open questions.
