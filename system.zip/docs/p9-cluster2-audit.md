# P9 cluster 2 (combat tab) — prep audit

Captured 2026-05-14, after alpha.31 smoke pass. Source-of-truth document
ahead of the combat-tab rebuild ship.

## Decisions inherited from P9 prep audit + cluster 1 smoke

- **Combat-1**: expand-detail-row pattern for trimmed columns (locked).
- **Combat-2**: wound indicator inline on hit-location row + separate
  "Active Wounds" detail card below the hit-locations table (locked).
- All cluster 1 shared partials available: `tab-section-card-header.hbs`,
  `improve-checkbox.hbs`, `section-card-header-button.hbs`. New partials
  introduced here MUST be added to `init.mjs:2a` `loadTemplates` array
  (lesson from alpha.31 hotfix).
- Offline-render smoke pattern from alpha.31 is the default; live-render
  reserved for interactivity verification (click handler firing, focus
  state, etc.).

## Carry-forward to HANDOFF.md (documentation deltas from cluster 1)

These two notes belong in the next HANDOFF.md update at the end of P9;
captured here so they don't get lost:

1. **Offline-render smoke pattern**. Bridge wedges reliably when reading
   rendered character sheet DOM (4 ProseMirror iframes per side finding
   #5). The cluster 1 working pattern:
   ```js
   const sheet = new SheetClass({document: actor});
   const options = {};
   sheet._configureRenderOptions(options);
   const ctx = await sheet._prepareContext(options);
   for (const partId of options.parts) {
     const partCtx = await sheet._preparePartContext(partId, {...ctx});
     const html = await foundry.applications.handlebars.renderTemplate(
       sheet.constructor.PARTS[partId].template, partCtx);
     // inspect via DOMParser; never attach to live document
   }
   ```
   Use this for any P9+ structural smoke. Reserve `actor.sheet.render(true)`
   for interactivity-required tests only (click handlers firing, focus
   states, form submission).

2. **Partial registration discipline**. Every shared partial in cluster
   2+ MUST be added to the `foundry.applications.handlebars.loadTemplates`
   call in `module/hooks/init.mjs:2a`. Foundry V14's ApplicationV2
   auto-registers ONLY templates declared in a sheet's `static PARTS`
   block. Shared partials invoked via `{{> "path"}}` from inside other
   templates are NOT auto-registered and must be explicitly loaded.
   Symptom of forgetting: "The partial ... could not be found" at first
   render.

---

## Combat tab scope

### Current legacy template

`templates/actor/character.combat.hbs`, 159 lines, three logical blocks:

1. **Weapons table** (lines 1–73): 13-column grid header + N weapon rows.
   Per-weapon row currently shows: name, chance%, damage, dmg-bonus,
   range, attacks, hands/crew, PP store (current/max in 2 cells), HP/AP
   (current/max in 2 cells), encumbrance, ammo input, equipStatus toggle.
2. **Hit-locations table** (lines 76–148): 8-column grid header + N
   hit-location rows. Per-row: add-wound button, location name, hit-range
   (low–high), curr HP, `/`, max HP, AP (rollable when `useAVRand`),
   status icons (dead/severed/unconscious), inline wound badges.
3. **Healing actions row** (lines 152–158): two large icons —
   `healing/natural` and `healing/all`.

Legacy classes used: `weapon-tab-grid`, `hitloc-tab-grid`, `gr-list`,
`diff-label`, `centre`, `font14`, `weapon-name`, `damage-name`,
`combat-input-small`, `hitloc-name`, `wound-name`, `wound-item`,
`untreated`, `mediumIcon`, `largeIcon`, `item-control`, `rollable`,
`inline-edit`, `italics`, `bold`. Total 27 distinct legacy classes per
P9 audit.

### Data dependencies (verified against `character.mjs`)

```
context.weapons[]      — sorted alphabetically
  weapon.name
  weapon.system.sourceID            (data-skill-id)
  weapon.system.hasEffects          (bold/italics decoration trigger)
  weapon.system.skillName           (chance tooltip)
  weapon.system.skillScore          (chance value)
  weapon.system.specialDmg          (suppresses damage-roll click)
  weapon.system.dmgName             (damage display)
  weapon.system.damageHint
  weapon.system.dbName/dbNameHint   (damage bonus)
  weapon.system.rangeName           (range display)
  weapon.system.rof                 (attacks tooltip)
  weapon.system.att                 (attacks value)
  weapon.type === 'artillery'       (switches hands → crew)
  weapon.system.crew
  weapon.system.hands               (1/2 hands)
  weapon.system.pSMax / pSCurr      (PP storage current/max — many weapons have 0)
  weapon.system.hp / hpCurr         (item HP)
  weapon.system.actlEnc             (encumbrance display value)
  weapon.system.quantity            (encumbrance tooltip)
  weapon.system.ammo                (ammo capacity; 0/null = no ammo)
  weapon.system.ammoCurr
  weapon.system.equipStatus         ('stowed' | 'equipped')
  weapon.system.equippedName        (equipStatus tooltip)

context.hitlocs[]      — per hit-location item
  hitloc.system.displayName
  hitloc.system.locType             ('general' = summary row, no values)
  hitloc.system.lowRoll / highRoll  (hit roll range; equal → single value)
  hitloc.system.currHP / maxHP      (per-location HP)
  hitloc.system.av1                 (AP — fixed)
  hitloc.system.avr1                (AP — rolled, when useAVRand)
  hitloc.system.dead | severed | unconscious  (status flags)

context.wounds[]       — wounds across all locations
  wound.system.locId                (matches to hitloc._id)
  wound.system.treated              (untreated → highlight)
  wound.system.value                (severity display)

context.useAVRand      — game setting
context.system.health.label/labelAbbr
context.system.power.label/labelAbbr
```

### Action handlers (all already registered in `base-actor-sheet.mjs`)

```
weaponRoll       — chance% click → opposed/standard roll dialog
damageRoll       — damage value click → roll damage formula
armorRoll        — AP click (useAVRand only) → roll armor value
addDamage        — "+ wound" button per hit-location
viewWound        — inline wound badge click
viewDoc          — weapon/hit-location name click → open item sheet
createDoc        — "+ weapon" button
itemToggle       — equipStatus, dead, severed, unconscious flips
healing          — natural/all healing buttons (data-prop)
```

No new handlers needed. No `.mjs` changes required for cluster 2 (same as cluster 1).

---

## Target v1.0.0 design

### Three section cards stacked

Each is a separate `.elysium-tab-section-card`:

1. **Weapons** — main card. Header has add-weapon button.
2. **Hit Locations** — second card. Header has no add-button (hit
   locations come from ancestry drop; never user-created via the combat
   tab).
3. **Healing Actions** — third card. Header is just the title; body has
   two large action buttons in a horizontal row.

The legacy template has an "Active Wounds" detail card per combat-2
decision; on review, the wound badges inline-per-location convey severity
+ count well enough that a separate detail card would be redundant
unless wounds carry narrative metadata. Inspected: wounds carry
`{value, treated, locId}` only — no narrative fields. **Folding the
detail card**: drop the planned "Active Wounds" detail card; surface
wound treatment via the existing badge hover (tooltip) and the existing
`viewWound` click handler which already opens the wound sheet. One less
card to maintain, no information lost. *Audit revision: replaces
combat-2 decision; see "Open questions" below.*

### Weapons table — expand-detail-row pattern (combat-1 locked)

**Visible by default — 8 columns**: name, chance%, damage, range,
attacks, hands/crew, equipStatus toggle, expand-detail toggle.

**Hidden behind expand toggle — 5 columns** moved to an indented detail
sub-row that renders below the row when expanded:
- dmg-bonus
- PP storage (current/max with editable input)
- item HP (current/max with editable input)
- encumbrance
- ammo (input when applicable)

This matches the D&D Beyond aesthetic — clean header table with
on-demand detail.

**Open expand-detail by default for**: weapons that have non-default
PP storage, HP, or ammo. Most simple weapons (sword, shield) have all
three at 0/null so the detail row stays collapsed; complex weapons
(firearm with ammo, magical staff with PP storage) auto-expand on first
render so the user immediately sees the state that matters.

**Visual decoration**: weapons with `system.hasEffects` get a small icon
chip next to the name (replaces legacy bold-italics treatment which
doesn't carry meaning in the new identity). New icon: `fa-sparkles` in
`--ely-accent-bonus` gold.

**Equipped state**: `equipStatus === 'equipped'` shows a filled
crimson-pill bg behind the equip-toggle button; stowed shows hollow.
Currently shows fa-hand-fist vs fa-bag-shopping icons; keep the icons,
add the pill background.

### Hit-locations — refined per-row layout

**Per-row visible columns** (7):
- Add-wound button (left, the `+` from legacy)
- Hit-location name (clickable to open item sheet)
- Hit range chip (e.g. "1–3" or "11" in a small chip; not raw text)
- HP — rendered as a small progress fill: filled portion = currHP/maxHP,
  numeric label `5/8` overlaid. Background `--ely-surface-base`; fill
  `--ely-accent-bonus` when ≥50%, `--ely-accent-danger` when <50%.
- AP value (rollable when `useAVRand`)
- Status icon row (dead/severed/unconscious — icons stay, restyled in
  the new identity)
- Wound badges (inline; one per wound matching this locId)

**General-type hit-locations**: rows with `locType === 'general'` render
as a card-subheader strip (location name only, no values) — used by
non-humanoid creatures to group sub-locations. Currently renders empty
cells; in v1.0.0 it becomes a small visual divider with the location
name centered.

**Wound badge styling**: small crimson chip with severity number, hover
tooltip shows treatment status. Untreated wounds get a thin
crimson-bone outline that pulses subtly (CSS animation, 2-second cycle,
respects `prefers-reduced-motion`). Treated wounds are flat.

### Healing actions

Two `elysium-button-primary` chips in a horizontal row. Natural healing
gets `fa-clock` icon + "Natural Healing" label; all-heal gets
`fa-staff-snake` icon + "Heal All" label. No raw icons floating in the
DOM as in legacy.

---

## New shared partials for cluster 2

| Partial | Purpose | Registered in init.mjs |
|---|---|---|
| `weapon-row.hbs` | Single weapon row with collapsed/expanded states | YES — add to loadTemplates |
| `hit-location-row.hbs` | Single hit-location row | YES |
| `wound-badge.hbs` | Inline wound severity chip | YES |
| `chip-range.hbs` | Hit-range numeric chip (e.g. "1-3", "11") | YES — reuse for damage range / spell range in cluster 5 |
| `hp-progress.hbs` | Mini HP bar with overlaid `N/M` label | YES — reuse for actor health in P10 if needed |

The two main row partials encapsulate the rendering complexity per row,
keeping the parent `character.combat.hbs` template thin and focused on
the section-card scaffold.

**NPC adaptation notes**:
- `weapon-row.hbs` — pass `editable=false` to NPC sheet for read-only
  rendering; collapses pSCurr/hpCurr/ammoCurr inputs to spans.
- `hit-location-row.hbs` — NPC uses different status flag set (no
  `unconscious` typically); needs `statusFlags` parameter.
- `wound-badge.hbs` — NPC reuses as-is.
- `chip-range.hbs` — fully generic, NPC reuses as-is.
- `hp-progress.hbs` — fully generic.

---

## New CSS additions

Estimated ~180 lines added to `styles/elysium-sheets.css`. Rule blocks:

- `.elysium-weapon-row` + variants (collapsed, expanded, equipped state)
- `.elysium-weapon-row-name` + decorations (has-effects sparkle)
- `.elysium-weapon-detail-row` (the expanded portion)
- `.elysium-equip-toggle` (pill-bg when equipped)
- `.elysium-hit-location-row` grid
- `.elysium-hit-location-general` (separator strip variant)
- `.elysium-hp-progress` (bar with overlay text)
- `.elysium-chip-range` (variant of existing `.elysium-chip`)
- `.elysium-wound-badge` + `--untreated` variant (with reduced-motion guard)
- `.elysium-healing-actions` (button row)
- `.elysium-button-primary` (if not already in elysium-components.css —
  CHECK during ship; reuse rather than redefine)

**Token reuse check**: every new rule MUST resolve against existing
`--ely-*` tokens. Pre-flight grep of token names will run before
elysium-sheets.css edit, per the alpha.30 lesson.

---

## Out of scope for cluster 2

- **Weapon item sheet rebuild** — P10.
- **Hit-location item sheet rebuild** — P10.
- **Wound item sheet rebuild** — P10.
- **New combat handlers** — none needed; reuse existing 9 handlers.
- **Active Wounds detail card** — folded into inline wound badges per
  audit revision above.
- **Per-location condition icons** — surfaced via right-rail conditions
  card (P8), not on the combat tab itself. No change.

---

## Open questions requiring lock-in before ship

1. **Audit revision: drop "Active Wounds" detail card.** Inspection
   shows wounds carry only `{value, treated, locId}` — no narrative
   metadata. A separate detail card would only repeat what the inline
   badges show. Recommendation: drop the planned card, surface treatment
   via existing badge tooltip + viewWound handler. Need your sign-off
   to override the original combat-2 lock.

2. **Auto-expand-detail-row default rule.** Recommendation: weapons with
   any of (`pSMax > 0`, `hp > 0`, `ammo > 0`) auto-expand on first
   render; user toggle persists per-session via a `Set` on `this.sheet`
   (not persisted to actor data — avoids schema churn). Acceptable?

3. **HP progress bar threshold.** Recommendation: gold ≥50%, crimson
   <50%. Some systems use 3 tiers (green/yellow/red); Mythras has no
   canonical mid-tier so two tiers stays clean. Acceptable, or three
   tiers wanted?

4. **Untreated wound pulse animation.** Recommendation: 2-second cycle,
   subtle 0.6→1.0 opacity, respects `prefers-reduced-motion`. Some
   users dislike all motion; the media query handles that. Acceptable?

5. **`hasEffects` sparkle icon.** Currently the legacy template makes
   the weapon name bold-italic. Sparkle icon is cleaner visually but
   means one more icon load. Recommendation: ship with sparkle. If
   visually noisy, drop in a follow-up smoke patch. Acceptable?

---

## Proposed ship sequence

Single alpha (alpha.32). Cluster 2 is one tab; one ship.

1. Add 5 shared partials to `init.mjs:2a` first (so registration is in
   place before render).
2. Write `weapon-row.hbs`, `hit-location-row.hbs`, `wound-badge.hbs`,
   `chip-range.hbs`, `hp-progress.hbs`.
3. Rewrite `character.combat.hbs` against the new scaffold + new partials.
4. Append CSS to `elysium-sheets.css`.
5. Pre-flight: `node --check init.mjs`; CSS brace balance; JSON parse;
   token resolution sweep on new CSS.
6. Package + present.
7. Live smoke: offline-render the combat part, verify structural shape +
   counts. CSS verification via offscreen-element pattern. If structural
   smoke passes, optionally do one short live-render eval to check the
   wound-badge pulse animation actually renders (the only visual that
   can't be captured via offline render).

After smoke pass: cluster 3 (items + social + pers) opens.

---

## Ready-to-go checklist

- [x] Combat handlers exist in `base-actor-sheet.mjs` — verified
- [x] Data context fields exist in `character.mjs:_prepareContext` — verified
- [x] `useAVRand` setting flows correctly — verified
- [x] All cluster 1 shared partials registered and verified
- [x] Offline-render smoke pattern proven on alpha.31
- [ ] User sign-off on 5 open questions
- [ ] Pre-ship token-resolution sweep (runs as part of cluster 2 ship)
