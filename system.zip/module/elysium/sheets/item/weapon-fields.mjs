// Auto-extracted from module/elysium/sheets/sheet-extension.mjs by
// tools/extract-methods.mjs (v0.21.0 refactor).
//
// This module exports a slice of the original ElysiumSheetExtension class
// as plain functions. The dispatcher (module/elysium/sheets/sheet-extension.mjs)
// imports and calls them in the same order with the same try/catch wrapping.
//
// Calls between sibling methods (originally `this._foo(...)`) have been
// rewritten to direct function calls (`foo(...)`) since all extracted methods
// share this module scope.

import { ELYSIUM } from '../../config/config.mjs'
import { injectItemModifiers } from './item-modifiers.mjs'

export function injectWeaponFields (html, item) {
    const detailsTab = html.querySelector('.tab.details') ||
                       html.querySelector('.tab.description')
    if (!detailsTab) return

    // v0.5.3+: the system fork's weapon.detail.hbs renders all Mythras
    // fields (Size / Reach / Force / Range bands / Melee toggle) natively
    // in BRP-base's grid layout — no separate Elysium fieldset needed any more.
    //
    // Add an inline note above the Wielded Modifiers showing effective
    // Size at each active engagement (Mythras encroachment rules).
    injectEngagementInfo(html, item, detailsTab)

    // v0.22.0-alpha.11: weapon HP / broken-state / Repair button
    // (mirror of armor sheet's Max AP / Current AP / BROKEN / Repair).
    injectWeaponHP(html, item, detailsTab)

    // The only other injection we still do here is the Wielded Modifiers
    // fieldset, which is conceptually distinct from weapon stats (it's
    // active-effect plumbing, not weapon properties).
    injectItemModifiers(html, item, detailsTab)
  }

export function injectEngagementInfo (html, item, target) {
    if (!item.parent) return       // only owned weapons
    if (target.querySelector('.elysium-engagement-info')) return

    const engagement = game.system.api?.elysium?.engagement
    if (!engagement) return

    const records = engagement.getActorEngagements(item.parent)
    // Filter to engagements that name THIS weapon (or no specific
    // weapon — older records may not have weaponId set)
    const relevant = records.filter(({ engagement: eng }) =>
      !eng.weaponId || eng.weaponId === item.id
    )
    if (relevant.length === 0) return

    const sys = item.system?.elysium || {}
    const baseSize  = sys.weaponSize || 'M'
    const baseReach = sys.reach || 'M'

    const sizeLabels  = ELYSIUM.WEAPON_SIZES   || {}
    const reachLabels = ELYSIUM.WEAPON_REACHES || {}

    const rows = relevant.map(({ combatant, engagement: eng }) => {
      const opp = game.combat?.combatants.get(eng.withId)
      const oppName = opp?.name || '?'
      const eReach  = eng.reach || 'M'
      const effSize = engagement.getEffectiveSize(item, eReach)
      const heldAtBay = engagement.getHeldAtBaySteps(baseReach, eReach) > 0
      const encroached = engagement.getEncroachmentSteps(baseReach, eReach) > 0
      const damageCap = engagement.getMaxDamage(item, eReach)

      let stateLabel = ''
      let stateClass = 'elysium-eng-normal'
      if (heldAtBay) {
        stateLabel = `Held at bay — cannot directly attack`
        stateClass = 'elysium-eng-bay'
      } else if (encroached) {
        stateLabel = `Encroached — Size ${sizeLabels[effSize] || effSize}, damage capped at ${damageCap}`
        stateClass = 'elysium-eng-encroached'
      } else {
        stateLabel = `Normal engagement — Size ${sizeLabels[baseSize] || baseSize}`
      }

      return `
        <div class="elysium-eng-row ${stateClass}">
          <span class="elysium-eng-vs">vs ${oppName}</span>
          <span class="elysium-eng-reach">@ ${reachLabels[eReach] || eReach}</span>
          <span class="elysium-eng-state">${stateLabel}</span>
        </div>
      `
    }).join('')

    const html_ = `
      <fieldset class="elysium-engagement-info">
        <legend>Active Engagements (Mythras Reach)</legend>
        ${rows}
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }

export function injectWeaponHP (html, item, target) {
    if (!target) return
    if (target.querySelector('.elysium-weapon-hp-fields')) return

    const hpMax  = Number(item.system?.hp)     || 0
    const hpCurr = Number(item.system?.hpCurr) || 0
    const broken = hpMax > 0 && hpCurr === 0

    const brokenStyle = broken ? 'style="color:#a04040;font-weight:bold;"' : ''
    const brokenBadge = broken
      ? '<span class="elysium-weapon-broken-badge" style="margin-left:8px;background:#a04040;color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;">BROKEN</span>'
      : ''
    const repairDisabled = (hpCurr >= hpMax) ? 'disabled' : ''

    const html_ = `
      <fieldset class="elysium-weapon-hp-fields">
        <legend>${game.i18n.localize('Elysium.Weapon.HPFields')}</legend>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Weapon.HPBaseHint')}">
            ${game.i18n.localize('Elysium.Weapon.HPBase')}
          </label>
          <input type="number" name="system.hp"
                 value="${hpMax}" min="0" max="999">
        </div>
        <div class="form-group">
          <label data-tooltip="${game.i18n.localize('Elysium.Weapon.HPCurrentHint')}">
            ${game.i18n.localize('Elysium.Weapon.HPCurrent')}
          </label>
          <input type="number" name="system.hpCurr"
                 value="${hpCurr}" min="0" max="999"
                 ${brokenStyle}>
          <span> / </span>
          <span class="elysium-weapon-hp-max">${hpMax}</span>
          ${brokenBadge}
          <button type="button"
                  class="elysium-weapon-repair-btn"
                  data-elysium-weapon-action="repair"
                  data-item-id="${item.id}"
                  style="margin-left:6px;padding:1px 8px;border-radius:3px;font-size:11px;cursor:pointer;"
                  ${repairDisabled}
                  data-tooltip="Restore 1 HP (up to Max HP).">
            Repair +1
          </button>
        </div>
      </fieldset>
    `
    const wrapper = document.createElement('div')
    wrapper.innerHTML = html_
    target.appendChild(wrapper.firstElementChild)
  }
