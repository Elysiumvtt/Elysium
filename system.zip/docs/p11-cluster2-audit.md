# P11 Cluster 2 prep audit — group-roll quartet (combat / opposed / combined / cooperative)

**Status**: PENDING
**Target alpha**: alpha.46
**Scope**: 4 chat templates — `roll-combat.html`, `roll-opposed.html`, `roll-combined.html`, `roll-cooperative.html`. Plus the new shared `chat-card-grouproll.hbs` partial.
**Inheritance from**: P11 prep audit (c11-1 through c11-14 + audit-0), cluster 1 audit (c1-1 through c1-11), and the 5 cluster-1 partials (chat-card-shell, participant-row, success-pip, tooltip-rows, resolve-footer).

Cluster 2 is the **first cluster that exercises the cluster-1 partials on Phase D-targeted templates**. Every smoke risk surfaces here for the first time live.

---

## 1. Current-state inventory

### Template diffs across the 4 cards

`roll-combat.html` (75 LOC) and `roll-opposed.html` (75 LOC) are **byte-for-byte identical except 2 lines**:

```diff
- <div class="bold">{{localize 'Elysium.card.CB'}}</div>
+ <div class="bold">{{localize 'Elysium.card.OP'}}</div>
- <button ... data-preset='resolve-cb-card' ...>
+ <button ... data-preset='resolve-op-card' ...>
```

`roll-combined.html` (88 LOC) and `roll-cooperative.html` (97 LOC) diverge more substantively:

```diff
TITLE: Elysium.card.GR  vs  Elysium.card.CO
RESOLVE: data-preset='resolve-gr-card'  vs  'resolve-co-card'
PER-PARTICIPANT PIP: combined OMITS c.rollVal in the pip;  cooperative INCLUDES it
BOTTOM SUMMARY: combined shows an h3 with one of three text labels
                  ('Elysium.resultLevel.1', 'Elysium.resultLevel.2', 'Elysium.partial')
                  driven by successLevel ∈ {0, 1, partial-as-fraction}, plus rollResult.
                cooperative shows a pip-strip with successLabel + successRoll, driven
                  by successLevel ∈ {0..4} integer.
```

### The 4-card variation matrix

| Card | Title key | Resolve preset | Show crown? | Pip value source | Resolve-button class | Bottom-summary mode |
|---|---|---|---|---|---|---|
| Combat (CB) | `Elysium.card.CB` | `resolve-cb-card` | YES (on entry 0) | `entry.rollResult` | `gm-visible-only` | NONE |
| Opposed (OP) | `Elysium.card.OP` | `resolve-op-card` | YES (on entry 0) | `entry.rollResult` | `gm-visible-only` | NONE |
| Combined (GR) | `Elysium.card.GR` | `resolve-gr-card` | NO | none (label only) | `owner-only` | `text-summary` (h3 with localized successLevel-fraction label + rollResult) |
| Cooperative (CO) | `Elysium.card.CO` | `resolve-co-card` | NO | `entry.rollVal` | `owner-only` | `pip-strip` (pip-style with successLabel + successRoll, integer successLevel 0-4) |

Variation axes: **5 dimensions** (title / preset / crown / pip value / resolve class) + **3 bottom-summary modes** (`none` / `text-summary` / `pip-strip`).

### Pre-rendered combined-card data shape

From `module/cards/combined-card.mjs:87-93`:

```js
'flags.elysium.chatCard': newchatCards,   // [{particId, particName, particImg, particType, label, targetScore, rollResult, rollVal, diceRolled, resultLevel, resultLabel, flatMod, diffLabel, ...}]
'flags.elysium.state': 'closed',
'flags.elysium.successLevel': successes,  // FRACTION: 0 = all failed, 1 = all succeeded, between = partial
'flags.elysium.rollResult': rollResult,   // single d100 roll shared by all participants
```

Combined-card uniqueness: ALL participants share ONE rollResult (computed once); their individual `resultLevel` is derived from comparing that single roll vs their own `targetScore`. Hence the partial template doesn't show `c.rollVal` per-participant (it would just repeat the same number on every row).

### Pre-rendered cooperative-card data shape

From `module/cards/cooperative-card.mjs:53-58`:

```js
'flags.elysium.chatCard': newchatCards,   // [{... per-participant rolled separately ...}]
'flags.elysium.successLevel': newConfig.resultLevel,  // INTEGER 0-4 (first participant's result level)
'flags.elysium.successLabel': game.i18n.localize('Elysium.resultLevel.' + newConfig.resultLevel),
'flags.elysium.successRoll': newConfig.rollVal,
'flags.elysium.state': 'closed',
```

Cooperative: each participant rolls separately; the "first participant's result" drives the cooperative outcome. Per-participant pip strip can show each participant's own `rollVal`.

### Discovered latent bug

**`module/cards/combined-card.mjs:104`**:
```js
'flgs.elysium.successLevel': -1,   // typo: 'flgs' instead of 'flags'
```

In `GRClose()` (the close-without-resolving handler), the typo writes a junk top-level `flgs` flag rather than updating `flags.elysium.successLevel` to the sentinel `-1`. The legacy template at `roll-combined.html:74` tests `{{#unless (eq successLevel -1)}}` to decide whether to show the bottom-row summary — since the value never reaches -1, force-closing a combined card leaves the (now-stale) summary visible.

This is a JS bug, not a markup bug, but it sits adjacent to the cluster 2 surface and is a one-character fix.

---

## 2. JS-imperative class-hook contract — cluster-2 surface

The full audit-5 lock list applies here (from prep audit §3). For cluster 2 specifically, every preserved hook is exercised:

- `.cardbutton` — every group-roll card has 2-3 cardbuttons (resolve, close, per-row remove)
- `.owner-only` + `data-partic-id` + `data-partic-type` — visibility gate on every participant tooltip
- `.gm-visible-only` — combat/opposed resolve+close buttons; per-row remove on all 4
- `form.elysium.gr-card` — Phase D mount-point (combat-card-buttons.mjs:94) — ALL 4 cards are Phase D targets
- `.elysium-hitloc-tag` — surfaces on resolved weapon-type cards (only on `roll-result.html` per cluster 3, not on group-roll cards; but the chat-card-participant-row partial already supports `showHitLocTag` flag — we don't use it on group-roll, but it's in the partial's contract)
- `data-preset` values: `resolve-cb-card`, `resolve-op-card`, `resolve-gr-card`, `resolve-co-card`, `close-card`, `remove-gr-roll`
- `data-rank` on the per-row remove (X) button
- `data-particType` (camelCase legacy spelling) on combined/cooperative resolve buttons

The cluster-1 `chat-card-resolve-footer.hbs` partial already handles all of this. The cluster-1 `chat-card-participant-row.hbs` already supports the `showRemoveButton` + `data-rank` flow.

---

## 3. Architectural decisions for cluster 2

### c2-1: Single shared partial vs per-card thin wrappers — confirm prep-audit c11-5 option A

Prep audit c11-5 recommended option A: ONE shared `chat-card-grouproll.hbs` partial driven by per-card context flags. Cluster-1 partial-context discovery validated this: the 5 cluster-1 partials already encode the per-row + per-pip variations. The 4 group-roll cards reduce to **thin per-card .html wrappers** that:

1. Build a per-card context (title key, resolve preset, crown flag, pip-value-source flag, resolve-class, bottom-summary mode)
2. Include the shared `chat-card-grouproll.hbs` partial
3. The shared partial iterates `chatCard` calling `chat-card-participant-row.hbs` per entry, then renders the optional bottom summary

**Recommendation**: Option A locked. One new partial added in c2 (`chat-card-grouproll.hbs`); 4 per-card templates reduced to ~10-line wrappers each.

### c2-2: Per-participant pip-value-source — three modes vs participant-row resultMode extension

`chat-card-participant-row.hbs` currently exposes `resultMode` ∈ {'pip-strip', 'flat-value', 'closed-or-diff'}. The group-roll cards introduce a new wrinkle: when the card is closed, the pip's rollValue should be:
- **combat/opposed**: `entry.rollResult` (the legacy template's choice — same int as `rollVal` for these card types)
- **combined**: empty (the legacy hides per-participant rollVal because all participants share one roll)
- **cooperative**: `entry.rollVal` (per-participant rolled separately)

Two options:

- **(A) Pass the resolved value via context** — Compute `pipValue` per-participant in the grouproll partial's per-iteration context preparation, then pass `rollValue=pipValue` to `chat-card-success-pip.hbs`. Cluster-1's success-pip already accepts `rollValue` as a generic parameter.
- **(B) Extend participant-row resultMode** — Add `'closed-or-diff-no-value'` mode for the combined case, plus a new mode for cooperative.

**Recommendation**: Option A. Keep `chat-card-participant-row.hbs` and `chat-card-success-pip.hbs` signatures stable; do the per-card value-source logic inside the new `chat-card-grouproll.hbs` partial. The participant-row's existing `closed-or-diff` mode handles combat/opposed correctly with `entry.rollResult`. For combined/cooperative we'll inline the pip render (one extra `{{#if}}` block in the new grouproll partial) rather than try to torture the partial signature into one-size-fits-all.

Concretely: `chat-card-grouproll.hbs` renders each entry as:
- if `pipValueSource === 'rollResult'`: use `participant-row` with `resultMode='closed-or-diff'`
- if `pipValueSource === 'rollVal'`: use `participant-row` with `resultMode='closed-or-diff'` BUT pass a context entry where `rollResult` has been pre-aliased to `rollVal` (one-line context tweak in the new partial)
- if `pipValueSource === 'none'`: use `participant-row` with `resultMode='closed-or-diff'` but pass an entry where `rollResult` is an empty string (success-pip handles empty `rollValue` gracefully — it just renders `{{rollValue}}` empty)

That keeps the partial-extension to ZERO and pushes all 3-way variation into the per-card data shape passed to the partial.

### c2-3: Bottom-summary modes — three distinct outputs

Combat + opposed: no bottom summary. Combined: h3 text-summary. Cooperative: pip-strip summary. These are 3 distinct visual outputs that can't merge cleanly.

**Recommendation**: Inline the 3 modes inside `chat-card-grouproll.hbs` driven by a `bottomSummaryMode` context flag ∈ {`'none'`, `'text-summary'`, `'pip-strip'`}. For `'text-summary'`, the partial renders the legacy `<h3 class="chat-dice">` block (already styled in cluster-1's `elysium-chat-card .chat-dice` rule). For `'pip-strip'`, reuse `chat-card-success-pip.hbs` with the card-level `successLevel` / `successLabel` / `successRoll`.

The `-1` sentinel test (`{{#unless (eq successLevel -1)}}`) is applied OUTSIDE the inner branch, so all modes consistently hide the bottom row when the card was force-closed (regardless of combined's typo bug; the cooperative side works correctly).

### c2-4: Crown indicator — show on entry 0 when `showCrown=true`

`chat-card-success-pip.hbs` already supports `showCrown`. The new grouproll partial sets `showCrown = (cardLevel === 'combat-or-opposed' && @index === 0)` per iteration.

**Recommendation**: Apply as described. No partial extension needed.

### c2-5: Resolve-button class — `gm-visible-only` vs `owner-only` per-card

`chat-card-resolve-footer.hbs` already supports both modes via the `resolveButtonClass` parameter (cluster 1, c1-2). Combat/opposed pass `'gm-visible-only'`; combined/cooperative pass `'owner-only'` plus `initiatorId` + `initiatorType`.

**Recommendation**: Apply as described.

### c2-6: Per-row remove button — `data-rank` flow on pending state

When `state !== 'closed'`, each participant row should render a per-row remove (X) button anchored to `data-rank="{{@index}}"`. The `triggerChatButton` dispatcher reads `data-rank` to know which row to remove from the `chatCard` array.

`chat-card-participant-row.hbs` already supports `showRemoveButton` (cluster 1). Pass `showRemoveButton = (state !== 'closed')` per iteration.

**Recommendation**: Apply as described.

### c2-7: Tooltip-rows mode — `attribute-difficulty` for all 4 group-roll cards

The 4 group-roll templates' tooltip blocks (`{{#if (eq ../state 'closed')}}<div class="actor-roll dice-tooltip">...`) all render the same set of rows: `rawScore`, `difficulty`, `flatMod`, optional `origResult`, and `diceRoll`. This matches `chat-card-tooltip-rows.hbs`'s `rollMode='attribute-difficulty'`.

Combined-card's tooltip lacks the `origResult` row (combined doesn't track origResLevel because the participants share one roll); combat/opposed include it. The tooltip-rows partial handles this via `{{#if entry.origResLabel}}` — combined's entries simply lack the field, so it omits the row automatically.

**Recommendation**: All 4 cards use `rollMode='attribute-difficulty'` on the cluster-1 tooltip-rows partial. No partial extension needed.

### c2-8: Card-type accents in Section D of `elysium-chat.css`

Cluster 1 left Section D as commented placeholders. Cluster 2 populates them for CB / OP / GR / CO. The four cards already differentiate themselves via the title text, but a subtle accent (e.g. a colored left border on the card, or a tinted title underline) adds at-a-glance recognizability.

**Recommendation**: Apply a 3px left border in the card-type accent color:
- CB (Combat): `var(--ely-accent-action)` — crimson (combat = aggressive)
- OP (Opposed): `var(--ely-accent-danger)` — bright red (opposed = adversarial)
- GR (Combined): `var(--ely-accent-info)` — desaturated blue (combined = cooperative-but-mechanical)
- CO (Cooperative): `var(--ely-accent-success)` — green (cooperative = collaborative)

Cluster 3 will populate the remaining 7 card-type accents (NO / RE / PP / CM / IM / DM / AR / QC) when those templates land.

Each accent is one CSS rule. Total: ~12 LOC added to Section D.

### c2-9: Latent bug fix — `flgs` typo in combined-card GRClose

`module/cards/combined-card.mjs:104` has `'flgs.elysium.successLevel': -1` — a typo that writes a junk top-level `flgs` flag instead of updating the real `flags.elysium.successLevel` sentinel. Per Rule 1 (no band-aids; fix root causes), this gets fixed in cluster 2 alongside the markup work.

**Recommendation**: One-character fix (`flgs` → `flags`). Documented in CHANGELOG as a side-finding fix similar to alpha.42's itemToggle latent bug discovery.

### c2-10: Legacy CSS retirement

The 4 group-roll templates no longer use the legacy `<form class="elysium gr-card">` direct-styling chain — the cluster-1 marker rule and Section B partial styles take over. However, the `gr-card` class is **preserved on the markup** (Phase D mount-point + JS hook per c11-3b), so the rules in `css/legacy.css` that target `.elysium .gr-card` / `.elysium .actor-roll` / `.elysium .pending` etc. now have TWO consumers: this cluster's rebuilt markup (where they're overridden by `elysium-chat-card` rules) AND any non-rebuilt chat-card markup that might still hit them (other clusters' targets).

**Recommendation**: Zero legacy CSS retired in cluster 2. Mark the rules as orphaning-candidates after cluster 3 closes (when the legacy `gr-card`-using cards are all replaced); final retirement in P12 per c11-13. Document the orphaning-candidates list in the CHANGELOG.

### c2-11: i18n keys

Existing keys consumed: `Elysium.card.CB`, `Elysium.card.OP`, `Elysium.card.GR`, `Elysium.card.CO`, `Elysium.remove`, `Elysium.grTag`, `Elysium.difficulty`, `Elysium.resolveCard`, `Elysium.closeCard`, `Elysium.malfunction`, `Elysium.partial`, `Elysium.resultLevel.0` / `.1` / `.2` / `.3` / `.4`, `Elysium.rawScore`, `Elysium.flatMod`, `Elysium.origResult`, `Elysium.diceRoll`. All resolve in `en.json` (verified during cluster 1's i18n sweep).

**No new i18n keys in cluster 2.**

### c2-12: Smoke methodology — offline-render + live Phase D test

Cluster 2 is the **first time Phase D button injection encounters a rebuilt template**. The mount-point selector `form.elysium.gr-card` must continue to find its target on each of the 4 rebuilt cards.

Smoke pattern:
1. Offline-render the 4 cards through Handlebars with fixture contexts covering both `state='pending'` and `state='closed'` (8 renders total).
2. Verify each output contains `<form class="elysium gr-card elysium-chat-card`. (The first 3 classes are the Phase D + `.cardbutton` audit-5 hooks; the 4th is the c11-1 scoping marker.)
3. Verify the resolve preset on closed combat/opposed cards is `resolve-cb-card`/`resolve-op-card` respectively, and on closed combined/cooperative is `resolve-gr-card`/`resolve-co-card`.
4. Verify `.cardbutton` class present on each resolve/close/remove button.
5. **Live smoke** (critical, not deferrable): post a fresh combat roll via the console:
   ```js
   await CONFIG.Combat.documentClass.create({})  // create dummy combat
   // then trigger a CM-card via an existing weapon
   ```
   Verify the Phase D GM-action panel renders below the resolved card. If it doesn't, the mount-point selector regressed — STOP, debug, fix in the same alpha (not bumped).
6. Click each card's resolve and close buttons; verify they fire `triggerChatButton` and the right `presetType` dispatcher runs.

Smoke risks for cluster 2 specifically:
1. **Phase D mount-point regression** (high impact) — Mitigation: step 5 above.
2. **`.cardbutton` selector miss** — Mitigation: step 6 (click test).
3. **`data-rank` flow miss on per-row remove** — Mitigation: open a pending card with 2+ participants; click the X button on row 1; verify row 1 (and only row 1) disappears.
4. **`owner-only` vs `gm-visible-only` visibility regression** — Mitigation: smoke as both GM and non-GM player; verify the resolve+close buttons hide correctly.

---

## 4. Cluster-2 ship summary

**Files added** (1):
- `templates/chat/parts/chat-card-grouproll.hbs` (~70 LOC) — the unified group-roll partial; iterates `chatCard` calling `chat-card-participant-row.hbs` per entry, then renders the optional bottom summary via `chat-card-success-pip.hbs` (cooperative mode) or inline h3 markup (combined mode) or nothing (combat/opposed mode).

**Files modified** (8):
- `templates/chat/roll-combat.html` — 75 → ~12 LOC (thin wrapper)
- `templates/chat/roll-opposed.html` — 75 → ~12 LOC (thin wrapper)
- `templates/chat/roll-combined.html` — 88 → ~14 LOC (thin wrapper)
- `templates/chat/roll-cooperative.html` — 97 → ~14 LOC (thin wrapper)
- `styles/elysium-chat.css` — populate Section D card-type accents for CB / OP / GR / CO (~12 LOC added)
- `module/hooks/init.mjs` — register `chat-card-grouproll.hbs` partial (1 line)
- `module/cards/combined-card.mjs` — `flgs` → `flags` typo fix (1 character)
- `system.json` — version bump alpha.45 → alpha.46
- `CHANGELOG.md` — alpha.46 entry
- `ROADMAP-v1.0.0.md` — execution-log + progress-tracker line update

**Net LOC**: -250 across templates, +70 partial, +12 CSS, +1 mjs fix = **-167 LOC net**. Close to the prep-audit c11-5 estimate of "~340 → ~150".

---

## 5. Out of scope for cluster 2

- The 11 other chat templates (cluster 3 + 4 work)
- Cast-card vocabulary harmonisation (deferred to optional c6 per c11-3)
- Combat-tracker restyle (c7 or P12)
- Inline-HTML `ChatMessage.create({content:...})` callsites (out of P11 per c11-8)
- `combined-card.mjs`'s `successLevel` semantic conflict with `cooperative-card.mjs`'s `successLevel` (one is fraction, one is int — design wart pre-existing the P11 rebuild; not in scope to unify)
- Legacy CSS retirement in `css/legacy.css` and `styles/elysium.css` (orphaning happens here; deletion is P12 per c11-13)

---

## 6. Open questions for user lock-in

1. **Card-type accent direction (c2-8)** — The recommended 3px left-border scheme uses crimson / red / blue / green for CB / OP / GR / CO. Alternatives:
   - **(a)** As recommended: 3px left border in the accent color.
   - **(b)** Tinted title underline only (more subtle).
   - **(c)** Tinted card-corner ribbon (more decorative; more LOC).
   - **(d)** No card-type accent in c2; defer to c3 when more card types land.
   Recommendation: (a).

2. **Latent bug fix in `combined-card.mjs` (c2-9)** — Fix the `flgs` → `flags` typo in this cluster's ship, or defer to a standalone hotfix? Recommendation: fix here (one-character change adjacent to cluster scope; same pattern as alpha.42 itemToggle absorption).

3. **Live Phase D smoke (c2-12 step 5)** — Pre-flight is offline-render; live Phase D test requires you actually post a combat card in the test world. Are you available to drive the live test post-ship, or should I attempt it via the Chrome bridge?

4. **Cluster-2 to cluster-3 sequencing** — Cluster 3 is the singleton-roll cards (`roll-result.html`, `roll-damage.html`, `roll-armor.html`, `quick-combat.html`). These share less structure with the group-roll quartet but reuse `chat-card-shell.hbs` + `chat-card-tooltip-rows.hbs`. Confirm: ship cluster 2 first as alpha.46, then audit cluster 3? Or any concern with that ordering?

---

## 7. Ready-to-go checklist (cluster 2 ships when all green)

- [ ] User confirms decisions c2-1 through c2-12
- [ ] User answers the 4 open questions in §6
- [ ] User confirms scope-cut list in §5
- [ ] User accepts smoke-risk mitigations in §3 (under each decision)

Once locked, cluster 2 coding begins.
