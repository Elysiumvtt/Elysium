/**
 * Arcane casting (v0.10.0).
 *
 * Pipeline:
 *   1. Manipulation dialog opens. Player adjusts baseline (range,
 *      duration, targets, area), commits PP for damage
 *      scaling. Each parameter touched adds +1 to required SL.
 *      → Cancel returns immediately, no cost, no card.
 *   2. School-skill check (which school) — single-school spells skip;
 *      multi-school spells prompt the player. (TODO step 8 — currently
 *      uses the spell's `school` field directly.)
 *   3. F/T checks roll silently (GM-whispered). Outcomes are stashed on
 *      the active-cast state. The player sees nothing about F/T at this
 *      stage. Failures are revealed only when the spell completes.
 *   4. Reactive spells (`isReactive`): hard-coded requiredSL=1, AP=0,
 *      single roll, immediate completion. (Wired in step 11.)
 *   5. Normal cast: open active-cast, post in-progress card. Each
 *      Spend-AP: roll school skill, computeSL, accumulate.
 *      - Critical: auto-fill remaining SL → spell completes
 *      - Fumble (100): roll Arcane Critical Fumble table, lose all SL,
 *        cast ends (does NOT reveal F/T — fumble overrides)
 *      - Failure: 0 SL gained, AP lost
 *      - Success: SL added; if accumulated >= required → completes
 *   6. Completion path: pay PP (= ppCommitted from dialog), then check
 *      stashed F/T failures:
 *      - No failures → normal completion, post effect description.
 *      - Has failures → corrupted completion, roll wild magic table now,
 *        post wild-magic effect instead of normal description, full PP
 *        still paid (per design call: player did the work).
 */

import { computeSL, payPP, spendAP, rollD100, findSkill, findFormOrTechnique, rollMagicTable, postCastCard, updateCastCard, getActiveCast, setActiveCast, clearActiveCast, ARCANE_DAMAGE_PER_PP } from './cast-shared.mjs'
import { openManipulationDialog } from './manipulation-dialog.mjs'
import { addSustain } from './sustain.mjs'
const SCHOOL_TO_SUBGROUP = 'arcane'

/**
 * Begin casting an Arcane spell. Called when the player clicks the
 * Cast button on a spell row.
 */
export async function beginArcaneCast (actor, spell) {
  // ----- 0. Don't double-cast.
  const existing = getActiveCast(actor)
  if (existing) {
    ui.notifications?.warn(
      `${actor.name} is already casting ${existing.spellName}. ` +
      `Complete or abandon that cast first.`)
    return
  }

  // ----- 1. Resolve school skill on the actor.
  // For multi-school spells (validSchools[] non-empty), prompt the
  // player to pick which school they want to cast through. Filtered
  // to schools the actor has the skill for. Single-school spells skip
  // this step entirely.
  let schoolName = spell.system?.elysium?.school || ''
  const validSchools = spell.system?.elysium?.validSchools ?? []
  if (Array.isArray(validSchools) && validSchools.length > 1) {
    const chosen = await _chooseSchool(actor, validSchools, schoolName)
    if (chosen === null) return    // player cancelled the chooser
    schoolName = chosen
  }

  let schoolSkill = null
  if (schoolName) {
    schoolSkill = findSkill(actor, { name: schoolName })
  }
  if (!schoolSkill) {
    schoolSkill = findSkill(actor, { subgroup: SCHOOL_TO_SUBGROUP })
  }
  if (!schoolSkill) {
    ui.notifications?.warn(
      `${actor.name} has no Arcane school skill (looking for "${schoolName}"). ` +
      `Drag the skill from the Skills compendium first.`)
    return
  }
  const skillTotal = schoolSkill.system?.total ?? schoolSkill.system?.base ?? 0

  // ----- 2. Manipulation dialog. Player commits to spell shape now.
  const profile = await openManipulationDialog(actor, spell, { skillTotal })
  if (profile === null) {
    // Player cancelled — no cost, no card.
    return
  }

  // ----- 3. Compute final required SL (base + parameters touched).
  const baseRequiredSL = spell.system?.elysium?.requiredSL ?? 1
  const requiredSL = baseRequiredSL + (profile.parametersTouched ?? 0)

  // ----- 4. Reactive spells: short-circuit. One AP from reactive-first
  // pool, one roll, immediate completion. Skip the SL-accumulation loop
  // entirely. requiredSL is forced to 1.
  const isReactive = !!spell.system?.elysium?.isReactive
  if (isReactive) {
    return _resolveReactiveCast({
      actor, spell, schoolName, schoolSkill, skillTotal,
      profile, baseRequiredSL,
    })
  }

  // ----- 5. Run F/T checks silently. Stash on active-cast for completion.
  const ftFailures = await runFormTechniqueChecksSilent(actor, spell)

  // ----- 6. Open the active-cast slot.
  await setActiveCast(actor, {
    spellId: spell.id,
    spellName: spell.name,
    schoolSkillId: schoolSkill.id,
    schoolSkillName: schoolSkill.name,
    skillTotal,
    requiredSL,
    baseRequiredSL,
    accumulatedSL: 0,
    basePP: spell.system?.elysium?.basePP ?? 1,
    apSpent: 0,
    attempts: [],
    saveSkill: spell.system?.elysium?.saveSkill ?? '',
    isReactive,
    // v0.10.0
    manipulation: profile,
    pendingFTFailures: ftFailures,    // empty array if all passed
    schoolName,
  })

  // ----- 7. Post the initial in-progress card. F/T failures NOT shown.
  const msg = await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: spell.id,
    spellName: spell.name,
    tradition: 'arcane',
    schoolName,
    schoolSkillName: schoolSkill.name,
    schoolSkillTotal: skillTotal,
    requiredSL,
    accumulatedSL: 0,
    attempts: [],
    description: spell.system?.description ?? '',
    inProgress: true,
    apSpent: 0,
    ppSpent: 0,
    saveSkill: spell.system?.elysium?.saveSkill ?? '',
    manipulationSummary: humanReadableManipulation(profile, spell),
  })

  // Stash the message ID on the active cast so subsequent AP attempts
  // can find and update the card in place.
  await setActiveCast(actor, {
    ...getActiveCast(actor),
    messageId: msg?.id,
  })
}

/**
 * Spend 1 AP to attempt to advance an in-progress Arcane cast.
 */
export async function spendCastAP (actor) {
  const cast = getActiveCast(actor)
  if (!cast) {
    ui.notifications?.warn(`${actor.name} has no active cast in progress.`)
    return
  }

  const ok = await spendAP(actor, 1)
  if (!ok) return

  const { value: rollValue } = await rollD100({ flavor: `Casting ${cast.spellName}` })
  const result = computeSL(cast.skillTotal, rollValue)

  const newAttempt = {
    apNumber: cast.apSpent + 1,
    rollValue,
    skillTotal: cast.skillTotal,
    sl: result.sl,
    outcome: result.outcome,
  }
  const attempts = [...cast.attempts, newAttempt]
  let accumulatedSL = cast.accumulatedSL + result.sl

  // Special outcomes.
  let fumble = null
  if (result.outcome === 'fumble') {
    fumble = await rollMagicTable('arcaneFumble')
    accumulatedSL = 0
  } else if (result.outcome === 'critical') {
    accumulatedSL = cast.requiredSL
  }

  const completed = accumulatedSL >= cast.requiredSL && result.outcome !== 'fumble'
  const abandonedByFumble = result.outcome === 'fumble'

  const updatedCast = {
    ...cast,
    apSpent: cast.apSpent + 1,
    attempts,
    accumulatedSL,
  }

  if (completed) {
    await resolveCompletion(actor, updatedCast, newAttempt)
  } else if (abandonedByFumble) {
    await resolveFumble(actor, updatedCast, fumble)
  } else {
    // Still in progress — mark this card as "spent for this turn" and
    // store the flag on activeCast so the next-turn re-post can clear it.
    const updatedCastWithSpent = { ...updatedCast, cardSpent: true }
    await setActiveCast(actor, updatedCastWithSpent)
    const ctx = {
      casterDoc: actor,
      casterName: actor.name,
      spellId: cast.spellId,
      spellName: cast.spellName,
      tradition: 'arcane',
      schoolName: cast.schoolName,
      schoolSkillName: cast.schoolSkillName,
      schoolSkillTotal: cast.skillTotal,
      requiredSL: cast.requiredSL,
      accumulatedSL,
      attempts,
      inProgress: true,
      cardSpent: true,            // v0.10.3 — disable Spend AP button on this card
      apSpent: updatedCast.apSpent,
      ppSpent: 0,
      saveSkill: cast.saveSkill,
      description: await getSpellDescription(actor, cast.spellId),
      manipulationSummary: humanReadableManipulation(cast.manipulation,
        actor.items.get(cast.spellId)),
    }
    await updateCastCard(cast.messageId, ctx)
  }
}

/**
 * Spell completes — required SL reached. Reveal F/T outcome and resolve.
 */
async function resolveCompletion (actor, cast, finalAttempt) {
  const spell = actor.items.get(cast.spellId)
  const ftFailed = (cast.pendingFTFailures ?? []).length > 0
  const ppToPay = cast.manipulation?.ppCommitted ?? cast.basePP

  // Always pay PP at completion — full cost, even on F/T-corrupted (the
  // player did the work). Overcast → fatigue.
  const ppResult = await payPP(actor, ppToPay, true)

  let wildMagic = null
  if (ftFailed) {
    wildMagic = await rollMagicTable('arcaneWildMagic')
  }

  const damagePerPP = ARCANE_DAMAGE_PER_PP
  const projectedDamage = computeProjectedDamage(spell, cast.manipulation, damagePerPP)
  // v0.10.3: heal-vs-damage label distinction. Spells with Heal in
  // their Techniques are restorative; the cast card swaps "Damage" for
  // "Healing" in the result block.
  const techniques = spell?.system?.elysium?.techniques ?? []
  const isHealing = techniques.some(t => String(t).toLowerCase() === 'heal')

  const ctx = {
    casterDoc: actor,
    casterName: actor.name,
    spellId: cast.spellId,
    spellName: cast.spellName,
    tradition: 'arcane',
    schoolName: cast.schoolName,
    schoolSkillName: cast.schoolSkillName,
    schoolSkillTotal: cast.skillTotal,
    requiredSL: cast.requiredSL,
    accumulatedSL: cast.accumulatedSL,
    attempts: cast.attempts,
    completed: true,
    corrupted: ftFailed,
    finalRoll: finalAttempt.rollValue,
    resistanceValue: finalAttempt.rollValue,
    saveSkill: cast.saveSkill,
    apSpent: cast.apSpent,
    ppSpent: ppResult.ppSpent,
    fatigueAdded: ppResult.fatigueAdded,
    description: ftFailed ? '' : (spell?.system?.description ?? ''),
    ftFailures: ftFailed ? cast.pendingFTFailures : [],
    wildMagic,
    manipulationSummary: humanReadableManipulation(cast.manipulation, spell),
    ppCommitted: cast.manipulation?.ppCommitted ?? 0,
    projectedDamage,
    damagePerPP,
    isHealing,
  }
  await updateCastCard(cast.messageId, ctx)
  await clearActiveCast(actor)

  // v0.10.0: register sustain on successful (non-corrupted) completion.
  if (!ftFailed && spell?.system?.elysium?.isSustained) {
    await addSustain(actor, {
      spellId: cast.spellId,
      spellName: cast.spellName,
      ppPerRound: ppToPay,
      schoolName: cast.schoolName,
      manipulationSummary: humanReadableManipulation(cast.manipulation, spell),
    })
  }
}

/**
 * Reactive-spell short-circuit pathway (v0.10.0).
 *
 * No SL-accumulation loop. The reaction fires now, on the opponent's
 * turn or in response to a trigger. One AP spent (drained from the
 * reactive-only pool first, then regular). One roll. Immediate
 * resolution with effective requiredSL=1 — manipulation can still raise
 * it, since "+1 SL per parameter touched" applies to all Arcane casts,
 * but in practice reactive spells are usually cast plain.
 *
 * F/T failures are stashed silently and revealed at completion (same
 * rule as the SL-loop path). PP cost is paid at completion. Fumble on
 * the cast roll triggers the Arcane Fumble table; PP is then NOT paid.
 */
async function _resolveReactiveCast ({
  actor, spell, schoolName, schoolSkill, skillTotal,
  profile, baseRequiredSL,
}) {
  // 1. AP cost — reactive draws from reactive-first pool.
  const apCost = spell.system?.elysium?.apCost ?? 1
  const ok = await spendAP(actor, apCost, { reactiveAllowed: true })
  if (!ok) return

  // 2. Required SL = 1 (reaction baseline) + parameters touched.
  // baseRequiredSL on the spell is informational only for reactives;
  // section 4.5 hard-codes reactive requiredSL to 1 for the *baseline*.
  const requiredSL = 1 + (profile.parametersTouched ?? 0)

  // 3. Roll F/T checks silently — same rule as the loop path.
  const ftFailures = await runFormTechniqueChecksSilent(actor, spell)

  // 4. Roll the school skill once.
  const { value: rollValue } = await rollD100({ flavor: `Reaction: ${spell.name}` })
  const result = computeSL(skillTotal, rollValue)

  // 5. Resolution. Reactive uses the loop's same outcome categories,
  // but maps them to immediate completion / fumble / failure rather
  // than continuing.
  if (result.outcome === 'fumble') {
    const fumble = await rollMagicTable('arcaneFumble')
    await postCastCard({
      casterDoc: actor,
      casterName: actor.name,
      spellId: spell.id,
      spellName: spell.name,
      tradition: 'arcane',
      schoolName,
      schoolSkillName: schoolSkill.name,
      schoolSkillTotal: skillTotal,
      requiredSL,
      accumulatedSL: 0,
      attempts: [{ apNumber: 1, rollValue, sl: 0, outcome: 'fumble' }],
      completed: false,
      abandoned: true,
      fumble,
      apSpent: apCost,
      ppSpent: 0,
      description: 'Reactive spell collapsed — see Fumble effect below.',
      manipulationSummary: humanReadableManipulation(profile, spell),
    })
    return
  }

  // Critical or success-meeting-required-SL → completes; otherwise fails.
  // For requiredSL=1 + 0 manipulation, any non-failure non-fumble succeeds.
  // For requiredSL>1 (manipulated), need critical OR enough SL in one roll.
  let accumulatedSL = result.sl
  if (result.outcome === 'critical') accumulatedSL = requiredSL

  if (result.outcome === 'failure' || accumulatedSL < requiredSL) {
    // Reaction missed. AP spent, no PP cost, no effect.
    await postCastCard({
      casterDoc: actor,
      casterName: actor.name,
      spellId: spell.id,
      spellName: spell.name,
      tradition: 'arcane',
      schoolName,
      schoolSkillName: schoolSkill.name,
      schoolSkillTotal: skillTotal,
      requiredSL,
      accumulatedSL,
      attempts: [{
        apNumber: 1, rollValue, sl: result.sl,
        outcome: result.outcome === 'failure' ? 'failure' : 'success',
      }],
      completed: false,
      abandoned: true,
      apSpent: apCost,
      ppSpent: 0,
      description: 'Reaction failed — the spell did not manifest in time.',
      manipulationSummary: humanReadableManipulation(profile, spell),
    })
    return
  }

  // Completion path — same as resolveCompletion but inlined since we
  // have no active-cast state to thread through. Pay PP, reveal F/T,
  // post completed card.
  const ppToPay = profile.ppCommitted ?? (spell.system?.elysium?.basePP ?? 1)
  const ppResult = await payPP(actor, ppToPay, true)

  const ftFailed = ftFailures.length > 0
  const wildMagic = ftFailed ? await rollMagicTable('arcaneWildMagic') : null

  const damagePerPP = ARCANE_DAMAGE_PER_PP
  const projectedDamage = computeProjectedDamage(spell, profile, damagePerPP)
  const reactiveTechs = spell?.system?.elysium?.techniques ?? []
  const reactiveIsHealing = reactiveTechs.some(t => String(t).toLowerCase() === 'heal')

  await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: spell.id,
    spellName: spell.name,
    tradition: 'arcane',
    schoolName,
    schoolSkillName: schoolSkill.name,
    schoolSkillTotal: skillTotal,
    requiredSL,
    accumulatedSL,
    attempts: [{
      apNumber: 1, rollValue, sl: result.sl,
      outcome: result.outcome,
    }],
    completed: true,
    corrupted: ftFailed,
    finalRoll: rollValue,
    resistanceValue: rollValue,
    saveSkill: spell.system?.elysium?.saveSkill ?? '',
    apSpent: apCost,
    ppSpent: ppResult.ppSpent,
    fatigueAdded: ppResult.fatigueAdded,
    description: ftFailed ? '' : (spell.system?.description ?? ''),
    ftFailures: ftFailed ? ftFailures : [],
    wildMagic,
    manipulationSummary: humanReadableManipulation(profile, spell),
    ppCommitted: profile.ppCommitted ?? 0,
    projectedDamage,
    damagePerPP,
    isHealing: reactiveIsHealing,
  })

  // v0.10.0: register sustain on successful (non-corrupted) reactive completion.
  if (!ftFailed && spell?.system?.elysium?.isSustained) {
    await addSustain(actor, {
      spellId: spell.id,
      spellName: spell.name,
      ppPerRound: ppToPay,
      schoolName,
      manipulationSummary: humanReadableManipulation(profile, spell),
    })
  }
}

/**
 * Cast ends in fumble. Per v0.10.0 design: fumble overrides F/T —
 * we don't roll wild magic on top, the fumble effect is enough.
 * No PP cost (player didn't reach completion).
 */
async function resolveFumble (actor, cast, fumble) {
  const ctx = {
    casterDoc: actor,
    casterName: actor.name,
    spellId: cast.spellId,
    spellName: cast.spellName,
    tradition: 'arcane',
    schoolName: cast.schoolName,
    schoolSkillName: cast.schoolSkillName,
    schoolSkillTotal: cast.skillTotal,
    requiredSL: cast.requiredSL,
    accumulatedSL: 0,
    attempts: cast.attempts,
    completed: false,
    abandoned: true,
    fumble,
    apSpent: cast.apSpent,
    ppSpent: 0,
    description: 'Spell collapsed — see Fumble effect below.',
  }
  await updateCastCard(cast.messageId, ctx)
  await clearActiveCast(actor)
}

/**
 * Abandon an in-progress Arcane cast. No PP, no F/T reveal.
 */
export async function abandonCast (actor) {
  const cast = getActiveCast(actor)
  if (!cast) return
  const ctx = {
    casterDoc: actor,
    casterName: actor.name,
    spellId: cast.spellId,
    spellName: cast.spellName,
    tradition: 'arcane',
    schoolName: cast.schoolName,
    schoolSkillName: cast.schoolSkillName,
    schoolSkillTotal: cast.skillTotal,
    requiredSL: cast.requiredSL,
    accumulatedSL: cast.accumulatedSL,
    attempts: cast.attempts,
    completed: false,
    abandoned: true,
    apSpent: cast.apSpent,
    ppSpent: 0,
    description: 'Cast abandoned. PP unpaid; accumulated SL forfeit.',
  }
  await updateCastCard(cast.messageId, ctx)
  await clearActiveCast(actor)
}

/**
 * Re-post a fresh in-progress cast card on the caster's next turn (v0.10.3).
 *
 * The previous card stays in chat as a frozen historical record (its
 * "Spend 1 AP" button is replaced by an inert notice via cardSpent=true).
 * This posts a NEW card with the carried-forward state so the player
 * doesn't have to scroll back through chat to find their active cast.
 *
 * Called from combat-extension.onTurn for the actor whose turn just began.
 * No-ops if the actor has no active cast or the existing card hasn't been
 * "spent" yet (the cast was just begun this very turn — keep the existing card).
 */
export async function repostCastCard (actor) {
  const cast = getActiveCast(actor)
  if (!cast) return
  // If the previous card hasn't been spent (e.g. the cast just started
  // this turn or was abandoned then resumed somehow), don't re-post.
  if (!cast.cardSpent) return

  const spell = actor.items.get(cast.spellId)
  const ctx = {
    casterDoc: actor,
    casterName: actor.name,
    spellId: cast.spellId,
    spellName: cast.spellName,
    tradition: 'arcane',
    schoolName: cast.schoolName,
    schoolSkillName: cast.schoolSkillName,
    schoolSkillTotal: cast.skillTotal,
    requiredSL: cast.requiredSL,
    accumulatedSL: cast.accumulatedSL,
    attempts: cast.attempts,
    inProgress: true,
    cardSpent: false,                      // fresh card — button live again
    apSpent: cast.apSpent,
    ppSpent: 0,
    saveSkill: cast.saveSkill,
    description: spell?.system?.description ?? '',
    manipulationSummary: humanReadableManipulation(cast.manipulation, spell),
  }
  const msg = await postCastCard(ctx)

  // Update activeCast to point at the new card and clear the cardSpent flag.
  await setActiveCast(actor, {
    ...cast,
    messageId: msg?.id,
    cardSpent: false,
  })
}

/**
 * Roll F/T checks silently to GM. For each Form or Technique listed
 * on the spell where the caster's value is below 100%, roll vs the
 * F/T %. Failures returned (for stashing on active-cast); successes
 * not returned. Wild magic is NOT rolled here — that happens at
 * completion, only if any failure was stashed.
 */
async function runFormTechniqueChecksSilent (actor, spell) {
  const failures = []
  // v0.10.4: filter empty entries — the per-row dropdown UI can leave
  // placeholder ("—") entries as empty strings in the array if the spell
  // was created without saving. Treat those as "not present" rather than
  // auto-failing the cast.
  const forms = (spell.system?.elysium?.forms ?? []).filter(f => f && String(f).trim().length > 0)
  const techniques = (spell.system?.elysium?.techniques ?? []).filter(t => t && String(t).trim().length > 0)
  const checks = []

  // v0.15.0: F/T are now skills (was passions). findFormOrTechnique returns
  // a skill item; we still read system.total for the percentage and we still
  // treat null as "not learned -> auto-fail." Variable name updated from
  // 'passion' to 'ftSkill' for clarity.
  for (const f of forms) {
    const ftSkill = findFormOrTechnique(actor, 'Form', capitalise(f))
    checks.push({ kind: 'Form', value: f, ftSkill })
  }
  for (const t of techniques) {
    const ftSkill = findFormOrTechnique(actor, 'Technique', capitalise(t))
    checks.push({ kind: 'Technique', value: t, ftSkill })
  }

  for (const c of checks) {
    if (!c.ftSkill) {
      // Not learned — auto-fail. No dice rolled, no chat noise.
      failures.push({
        ftName: `${c.kind} (${capitalise(c.value)})`,
        ftValue: 0,
        rollValue: null,
        success: false,
        missing: true,
      })
      continue
    }
    const ftTotal = c.ftSkill.system?.total ?? 0
    if (ftTotal >= 100) continue   // 100%+ skips the check entirely

    // GM-private roll: rollMode 'gmroll' whispers the dice trace to GMs.
    const { value: rollValue } = await rollD100({
      flavor: `[Hidden] ${c.ftSkill.name} check for ${actor.name}`,
      rollMode: 'gmroll',
    })
    const success = rollValue <= ftTotal
    if (!success) {
      failures.push({
        ftName: c.ftSkill.name,
        ftValue: ftTotal,
        rollValue,
        success: false,
        missing: false,
      })
    }
  }

  return failures
}

function capitalise (s) {
  if (!s) return ''
  return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase()
}

async function getSpellDescription (actor, spellId) {
  const spell = actor.items.get(spellId)
  return spell?.system?.description ?? ''
}

/**
 * Build a human-readable summary of a manipulation profile for the
 * cast card. e.g. "Range +2, Targets +1 · 5 INT spent" or empty
 * string if no manipulation was applied and no extra PP committed.
 */
function humanReadableManipulation (profile, spell) {
  if (!profile) return ''
  const d = profile.deltas ?? {}
  const bits = []
  for (const param of ['range', 'duration', 'targets', 'area']) {
    const n = Number(d[param]) || 0
    if (n > 0) bits.push(`${capitalise(param)} +${n}`)
  }
  const parts = [...bits]
  if (profile.manipulationCostSpent > 0) {
    parts.push(`${profile.manipulationCostSpent} INT spent`)
  }
  const basePP = spell?.system?.elysium?.basePP ?? 0
  if ((profile.ppCommitted ?? 0) > basePP) {
    parts.push(`${profile.ppCommitted} PP committed`)
  }
  return parts.join(' · ')
}

/**
 * Flat damage projection: ppCommitted × ARCANE_DAMAGE_PER_PP, only for
 * spells flagged `isDamageSpell: true`. Pre-v0.16.0 this gated on
 * `baseline.magnitude > 0` (OR manipulation deltas), but magnitude was
 * removed in favor of an explicit boolean — predefined spells now have
 * a fixed damage/no-damage identity. Healing spells set `isDamageSpell`
 * (true) and `isHealingSpell` (true via author-supplied flag if/when
 * added); chat card shows "Damage" today. Custom-spell builder lets the
 * player choose isDamageSpell at cast time. Constant lives in cast-shared
 * (since v0.19.0; was a world setting before).
 */
function computeProjectedDamage (spell, manipulation, damagePerPP) {
  if (!spell || !manipulation) return 0
  const isDamageSpell = !!spell?.system?.elysium?.isDamageSpell
  if (!isDamageSpell) return 0
  return (Number(manipulation.ppCommitted) || 0) * damagePerPP
}

/**
 * Multi-school chooser dialog (v0.10.0).
 *
 * Filters validSchools to schools the actor actually has the skill for.
 * Returns the chosen school name string, or null if cancelled.
 *
 * If only one school remains after filtering, returns it directly
 * without showing a dialog (silent auto-resolution).
 *
 * @param {Actor}    actor
 * @param {string[]} validSchools - the spell's valid-schools list
 * @param {string}   defaultSchool - the spell's default `school` field
 * @returns {Promise<string | null>}
 */
async function _chooseSchool (actor, validSchools, defaultSchool) {
  // Filter to schools the actor has skills for.
  const available = validSchools.filter(name => findSkill(actor, { name }))

  if (available.length === 0) {
    ui.notifications?.warn(
      `${actor.name} has no school skill matching this spell's valid schools ` +
      `(${validSchools.join(', ')}).`)
    return null
  }

  // Auto-resolve when only one school is available — no dialog needed.
  if (available.length === 1) {
    return available[0]
  }

  // Build buttons for each available school.
  const buttons = available.map(name => ({
    action: name,
    label: name,
    default: name === defaultSchool,
  }))

  // DialogV2 prompt — returns the action string or null on dismissal.
  try {
    const choice = await foundry.applications.api.DialogV2.wait({
      window: { title: 'Choose School' },
      content: `<p>Cast <strong>through which school</strong>?</p>`,
      buttons,
      rejectClose: false,
    })
    return choice ?? null
  } catch (err) {
    return null
  }
}

