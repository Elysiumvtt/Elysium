/**
 * AllegianceDataModel — schema for items of type 'allegiance'.
 *
 * Per P6.2 spec. Stored-schema-only. 1 compendium item (Faith) which
 * uses all 10 declared fields. Schema matches template.json + compendium.
 *
 * The `alleg*` fields define a faction relationship system: allegAllied
 * vs allegEnemy vs allegApoth (apothecary/healer affinity?), with
 * opposeAlleg naming the opposing faction by string. `benefits` is a
 * free-text description of mechanical benefits.
 */

import { makeItemBase } from './_shared.mjs'

const fields = foundry.data.fields

export class AllegianceDataModel extends foundry.abstract.TypeDataModel {

  static defineSchema () {
    return {
      ...makeItemBase(),
      allegPoints:  new fields.NumberField({ integer: true, initial: 0 }),
      opposeAlleg:  new fields.StringField({ initial: '' }),
      allegTitle:   new fields.StringField({ initial: '' }),
      improve:      new fields.BooleanField({ initial: false }),
      allegEnemy:   new fields.BooleanField({ initial: false }),
      allegAllied:  new fields.BooleanField({ initial: false }),
      allegApoth:   new fields.BooleanField({ initial: false }),
      // benefits: template default is "" (plain string); not HTMLField.
      benefits:     new fields.StringField({ initial: '' }),
      xp:           new fields.NumberField({ integer: true, initial: 0 }),
    }
  }
}
