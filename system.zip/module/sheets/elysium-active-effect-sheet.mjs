export class ElysiumActiveEffectSheet {
  static getItemEffectsFromSheet(document) {
    //Changed from hasOwner to isOwned in V13
    if (document.isOwned) {
      return document.parent.effects.reduce((c, i) => {
        if (i.origin === document.uuid) {
          c.push({
            uuid: i.uuid,
            name: i.name
          })
        }
        return c
      }, [])
    }
    return document.effects.reduce((c, i) => {
      c.push({
        uuid: i.uuid,
        name: i.name
      })
      return c
    }, [])
  }

  static getAutoEffect(document) {
    if (document.parent) {
      if (document.parent.parent?.actorLink === false && document.parent.parent.actor) {
        return {
          effect: document.parent.parent.actor.effects.find(e => e.origin === document.uuid && (e.flags.elysium?.autoActiveEffect ?? false)),
          document: document.parent.parent.actor,
        }
      }
      return {
        effect: document.parent.effects.find(e => e.origin === document.uuid && (e.flags.elysium?.autoActiveEffect ?? false)),
        document: document.parent,
      }
    }
    return {
      effect: document.effects.find(e => e.flags.elysium?.autoActiveEffect ?? false),
      document: document
    }
  }

  static getEffectChangesFromSheet(document) {
    const effectChanges = []
    const effectKeys = foundry.utils.duplicate(CONFIG.Elysium.keysActiveEffects)
    const effectData = ElysiumActiveEffectSheet.getAutoEffect(document)
    if (effectData.effect) {
      for (const change of effectData.effect.changes) {
        if (change.mode === CONST.ACTIVE_EFFECT_MODES.ADD) {
          effectChanges.push({
            key: change.key,
            name: effectKeys[change.key] ?? change.key,
            negative: (change.value < 0),
            value: Math.abs(change.value)
          })
          delete effectKeys[change.key]
        }
      }
    }
    return {
      effectKeys,
      effectChanges
    }
  }

  static async getActorEffectsFromSheet(document) {
    const effectKeys = foundry.utils.duplicate(CONFIG.Elysium.keysActiveEffects)
    const aEffects = this.getItemEffectsFromSheet(document)
    const effects = []
    for (let eff of aEffects) {
      // v1.1.0-c1: local var was `brpAE` (legacy "BRP" naming). Renamed to
      // `legacyAE` since this is a pre-rebuild legacy ActiveEffect being
      // resolved by uuid + origin lookup.
      const legacyAE = await fromUuid(eff.uuid)
      const item = await fromUuid(legacyAE.origin)
      if (item) {
        for (let chng of legacyAE.changes) {
          effects.push({
            id: item.id,
            sourceName: item.name,
            key: chng.key,
            name: game.i18n.localize((effectKeys[chng.key] ?? chng.key)),
            value: chng.value,
            isActive: legacyAE.active ?? false
          })
        }
      }
    }
    return effects
  }

  static activateListeners(document) {
    if (game.user.isGM) {
      document.element.querySelectorAll('div[data-action="openActiveEffect"]').forEach(n => n.addEventListener("click", ElysiumActiveEffectSheet._onOpenActiveEffect.bind(document)))
      document.element.querySelectorAll('div[data-action="addItemEffect"]').forEach(n => n.addEventListener("click", ElysiumActiveEffectSheet._onAddItemEffect.bind(document)))
      document.element.querySelectorAll('div.active-effect-change-edit .fa-trash').forEach(n => n.addEventListener("click", ElysiumActiveEffectSheet._onDeleteItemEffectChange.bind(document)))
      document.element.querySelectorAll('div.active-effect-change-edit select').forEach(n => n.addEventListener("click", ElysiumActiveEffectSheet._onChangeItemEffectChange.bind(document)))
      document.element.querySelectorAll('div.active-effect-change-edit input').forEach(n => n.addEventListener("blur", ElysiumActiveEffectSheet._onChangeItemEffectChange.bind(document)))
    }
  }

  static async _onAddItemEffect(event) {
    if (typeof event.currentTarget.dataset.key === 'string') {
      const effectData = ElysiumActiveEffectSheet.getAutoEffect(this.document)
      const newChange = {
        key: event.currentTarget.dataset.key,
        mode: CONST.ACTIVE_EFFECT_MODES.ADD,
        value: 0
      }
      if (effectData.effect) {
        const changes = foundry.utils.duplicate(effectData.effect.changes)
        changes.push(newChange)
        await effectData.document.updateEmbeddedDocuments('ActiveEffect', [{
          _id: effectData.effect.id,
          changes: changes
        }])
      } else {
        const newDoc = {
          'flags.elysium.autoActiveEffect': true,
          name: effectData.document.name,
          changes: [
            newChange
          ],
        }
        if (this.document.parent) {
          newDoc.origin = this.document.uuid
        }
        await effectData.document.createEmbeddedDocuments('ActiveEffect', [newDoc])
      }
      this.render(true)
    }
  }

  static async _onDeleteItemEffectChange(event) {
    const key = event.currentTarget.closest('div.active-effect-change-edit')?.dataset?.key
    if (typeof key === 'string') {
      const effectData = ElysiumActiveEffectSheet.getAutoEffect(this.document)
      if (effectData.effect) {
        const changes = foundry.utils.duplicate(effectData.effect.changes).filter(c => c.key !== key)
        if (changes.length) {
          await effectData.document.updateEmbeddedDocuments('ActiveEffect', [{
            _id: effectData.effect.id,
            changes: changes
          }])
        } else {
          await effectData.document.deleteEmbeddedDocuments('ActiveEffect', [
            effectData.effect.id,
          ])
        }
        this.render(true)
      }
    }
  }

  static async _onChangeItemEffectChange(event) {
    const outer = event.currentTarget.closest('div.active-effect-change-edit')
    const key = outer?.dataset?.key
    if (typeof key === 'string') {
      const effectData = ElysiumActiveEffectSheet.getAutoEffect(this.document)
      if (effectData.effect) {
        const changes = foundry.utils.duplicate(effectData.effect.changes)
        const index = changes.findIndex(c => c.key === key)
        if (index > -1) {
          const value = parseInt(outer.querySelector('select').value + outer.querySelector('input').value, 10)
          changes[index].value = value
          await effectData.document.updateEmbeddedDocuments('ActiveEffect', [{
            _id: effectData.effect.id,
            changes: changes
          }])
        }
      }
    }
  }

  static async _onOpenActiveEffect(event) {
    const uuid = event.currentTarget.dataset.uuid
    if (uuid) {
      (await fromUuid(uuid))?.sheet.render(true)
    }
  }
}
