/**
 * Elysium Rules — Configuration constants
 * 
 * All numerical values that need balancing are flagged TBD via
 * `null` or via the BALANCING object. Setting them here in one
 * place means future tuning is a single-file change.
 */

export const ELYSIUM = {}

ELYSIUM.MODULE_ID = 'elysium'
ELYSIUM.SYSTEM_ID = 'brp'

// Difficulty grades (used everywhere)
ELYSIUM.DIFFICULTY = {
  veryEasy:           +40,
  easy:               +20,
  standard:             0,
  difficult:          -20,
  veryDifficult:      -40,
  extremelyDifficult: -80,
  herculean:          -80,
  hopeless:           -99,  // results in skill of 1
  nearlyImpossible:   -99,
}

// Action Point table — INT+DEX based
ELYSIUM.AP_TABLE = [
  { min:  1, max: 12, ap: 1 },
  { min: 13, max: 24, ap: 2 },
  { min: 25, max: 36, ap: 3 },
  { min: 37, max: 48, ap: 4 },
  { min: 49, max: 60, ap: 5 },
  { min: 61, max: 72, ap: 6 },
  { min: 73, max: 84, ap: 7 },
]

// Healing Rate table — Mythras CON-based
ELYSIUM.HEALING_RATE_TABLE = [
  { min:  1, max:  6, rate: 1 },
  { min:  7, max: 12, rate: 2 },
  { min: 13, max: 18, rate: 3 },
  { min: 19, max: 24, rate: 4 },
  { min: 25, max: 99, rate: 5 },
]

// Fatigue level table — full Mythras
ELYSIUM.FATIGUE_LEVELS = [
  {
    level: 0, label: 'fresh',
    skillGrade: 0, movePenalty: 0, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 0,
    canAct: true, canReact: true,
  },
  {
    level: 1, label: 'winded',
    skillGrade: -20, movePenalty: 0, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 15,
    canAct: true, canReact: true,
  },
  {
    level: 2, label: 'tired',
    skillGrade: -20, movePenalty: -1, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 180,
    canAct: true, canReact: true,
  },
  {
    level: 3, label: 'wearied',
    skillGrade: -40, movePenalty: -2, moveMult: 1,
    initiativePen: -2, apPenalty: 0,
    recoveryMins: 360,
    canAct: true, canReact: true,
  },
  {
    level: 4, label: 'exhausted',
    skillGrade: -40, movePenalty: 0, moveMult: 0.5,
    initiativePen: -4, apPenalty: 1,
    recoveryMins: 720,
    canAct: true, canReact: true,
  },
  {
    level: 5, label: 'debilitated',
    skillGrade: -80, movePenalty: 0, moveMult: 0.5,
    initiativePen: -6, apPenalty: 2,
    recoveryMins: 1080,
    canAct: true, canReact: true,
  },
  {
    level: 6, label: 'incapacitated',
    skillGrade: -80, movePenalty: 0, moveMult: 0,
    initiativePen: -8, apPenalty: 3,
    recoveryMins: 1440,
    canAct: true, canReact: false,
  },
  {
    level: 7, label: 'semiConscious',
    skillGrade: null, movePenalty: 0, moveMult: 0,
    initiativePen: null, apPenalty: null,
    recoveryMins: 2160,
    canAct: false, canReact: false,
  },
  {
    level: 8, label: 'comatose',
    skillGrade: null, movePenalty: 0, moveMult: 0,
    initiativePen: null, apPenalty: null,
    recoveryMins: 2880,
    canAct: false, canReact: false,
  },
  {
    level: 9, label: 'dead',
    skillGrade: null, movePenalty: null, moveMult: null,
    initiativePen: null, apPenalty: null,
    recoveryMins: null,
    canAct: false, canReact: false,
  },
]

// Wound thresholds
ELYSIUM.WOUND_THRESHOLDS = {
  wounded:           { test: (curr, max) => curr > 0 && curr < max },
  severelyWounded:   { test: (curr, max) => curr > 0 && curr <= Math.floor(max / 2) },
  criticallyWounded: { test: (curr, max) => curr <= 0 && curr > -max },
  severed:           { test: (curr, max) => curr <= -max },
}

// Damage types
ELYSIUM.DAMAGE_TYPES = {
  // Physical
  slashing:    { category: 'physical', specialEffect: 'bleed' },
  piercing:    { category: 'physical', specialEffect: 'impale' },
  bludgeoning: { category: 'physical', specialEffect: 'stun' },
  crushing:    { category: 'physical', specialEffect: 'bypass-armour-2ap' },

  // Elemental
  fire:        { category: 'elemental', armour: 'normal' },
  cold:        { category: 'elemental', armour: 'normal' },
  lightning:   { category: 'elemental', armour: 'no-metal' },
  acid:        { category: 'elemental', armour: 'damage-armour-first' },
  force:       { category: 'elemental', armour: 'normal' },
  sonic:       { category: 'elemental', armour: 'half' },

  // Spiritual
  radiant:     { category: 'spiritual', armour: 'normal' },
  necrotic:    { category: 'spiritual', armour: 'ignore', special: 'reduces-max-hp' },
  psychic:     { category: 'spiritual', armour: 'ignore' },
  poison:      { category: 'spiritual', armour: 'by-application' },
}

// Resistance tiers
ELYSIUM.RESISTANCE_TIERS = {
  immune:     { multiplier: 0,    flat: 0, allowCondition: false },
  resistant:  { multiplier: 0.5,  flat: 0, allowCondition: true  },
  minor:      { multiplier: 1,    flat: 3, allowCondition: true  },
  none:       { multiplier: 1,    flat: 0, allowCondition: true  },
  vulnerable: { multiplier: 2,    flat: 0, allowCondition: true  },
}

// Weapon size and reach categories
ELYSIUM.WEAPON_SIZES = ['small', 'medium', 'large', 'huge', 'enormous']
ELYSIUM.WEAPON_REACHES = ['touch', 'short', 'medium', 'long', 'veryLong']

// Armour materials
ELYSIUM.ARMOUR_MATERIALS = {
  natural: { conducts: false, reactToAcid: false, reactToSonic: false },
  cloth:   { conducts: false, reactToAcid: true,  reactToSonic: false },
  leather: { conducts: false, reactToAcid: true,  reactToSonic: false },
  metal:   { conducts: true,  reactToAcid: true,  reactToSonic: true  },
}

// Armour flexibility
ELYSIUM.ARMOUR_FLEXIBILITY = {
  natural:    { layer: 0, casting_arm: 0,   casting_head: 0,   casting_chest: 0, casting_abdomen: 0, casting_leg: 0   },
  flexible:   { layer: 1, casting_arm: -10, casting_head: -5,  casting_chest: -5, casting_abdomen: -3, casting_leg: -2 },
  inflexible: { layer: 3, casting_arm: -20, casting_head: -10, casting_chest: -8, casting_abdomen: -5, casting_leg: -3 },
}

// Armour total AP cap (worn armour only — natural armour and ward spells do not count)
ELYSIUM.ARMOUR_AP_CAP = 10

// Movement (in feet — display unit; metric tokens convert internally)
ELYSIUM.MOVEMENT = {
  combatMoveFt:        15,        // Free with action
  fullMoveAP:          1,
  runMultiplier:       3,
  runAP:               2,
  sprintMultiplier:    5,
  sprintAP:            3,
  swimDivisor:         2,
  climbAP:             1,
  jumpRunningDivisor:  2,
  jumpStandingDivisor: 4,
  crawlDivisor:        4,
  squareSizeFt:        5,
}

// Charging — bonus damage modifier steps
ELYSIUM.CHARGE_BONUS = {
  biped:        1,    // Damage Modifier +1 step
  fourLegged:   2,    // Damage Modifier +2 steps
  weaponSizeBonus: 1, // First blow weapon Size +1
  difficulty:   -20,  // Charge attack one grade harder
}

// Magic systems — universal across all four
ELYSIUM.MAGIC_SYSTEMS = ['arcane', 'sorcery', 'divine', 'mysticism']

// Magic systems affected by armour casting penalty
ELYSIUM.MAGIC_SYSTEMS_ARMOUR_PENALISED = ['arcane', 'sorcery']
ELYSIUM.MAGIC_SYSTEMS_ARMOUR_EXEMPT    = ['divine', 'mysticism']

// Arcane configuration
ELYSIUM.ARCANE = {
  damagePerMP:        1,    // 1 HP per MP — config; can be 2
  healingPerMP:       1,    // 1 HP healed per MP
  ongoingDamagePerMP: 1,    // 1 damage per round per 3 MP (see categories)
  multiComponentSurcharge: 2,
  improvisedSpellPenalty:  -20,    // one grade harder
  improvisedManaSurcharge:   2,    // +2 PP cost
  scrollPowSacrifice:        1,    // temporary
  permanentRunePerMP:        5,    // 1 POW per 5 MP permanent
  // School efficiency (51%+) — values TBD during balancing
  schoolEfficiency: [
    { thresholdMin:   1, thresholdMax:  50, manaReduction: 0,  slReduction: 0 },
    { thresholdMin:  51, thresholdMax:  60, manaReduction: 1,  slReduction: 1 },
    { thresholdMin:  61, thresholdMax:  70, manaReduction: 2,  slReduction: 2 },
    { thresholdMin:  71, thresholdMax:  80, manaReduction: 3,  slReduction: 3 },
    { thresholdMin:  81, thresholdMax:  90, manaReduction: 4,  slReduction: 4 },
    { thresholdMin:  91, thresholdMax:  99, manaReduction: 5,  slReduction: 5 },
    { thresholdMin: 100, thresholdMax: 999, manaReduction: 6,  slReduction: 6 },
  ],
}

// Sorcery configuration
ELYSIUM.SORCERY = {
  primaryEssences:        3,
  abilitiesPerEssence:    5,
  confluenceAbilityCount: 5,
  abilityUnlockCost:      [null, null, null, null, null, null], // TBD per tier
  // Restricted essences requiring GM approval
  restrictedEssences: ['death', 'void', 'corruption', 'chaos'],
}

// Divine / Patron configuration
ELYSIUM.DIVINE = {
  standings: ['devoted', 'faithful', 'wavering', 'fallen', 'revoked'],
  ppRecoveryStanding: {
    devoted:   { multiplier: 2,    sleepingOnly: true  },
    faithful:  { multiplier: 1,    sleepingOnly: false },
    wavering:  { multiplier: 0,    sleepingOnly: false, fixedAwake: 1 },
    fallen:    { multiplier: 0,    blocked: true },
    revoked:   { multiplier: 0,    blocked: true, abilitiesBlocked: true },
  },
  prayerRitualMinutes: { 1: 10, 2: 30, 3: 60, 4: 240, 5: 480 },
}

// Mysticism configuration
ELYSIUM.MYSTICISM = {
  // Activation roll required when ability IS the action
  // Per-ability flag; this is the rule reference only.
  activationRule: 'IS_THE_ACTION',
  meditationHours: 1,
}

// Superpowers
ELYSIUM.SUPERPOWERS = {
  favouredEnemyMaxTypes: 3,
}

// Vision types — granted via Mutation or Superpower items
ELYSIUM.VISION_TYPES = {
  lowLight:    { type: 'mutation',   range:  0, identifier: 'lowLight' },
  infravision: { type: 'mutation',   range: 30, identifier: 'infravision' },
  darkvision:  { type: 'mutation',   range: 60, identifier: 'darkvision' },
  superiorDarkvision: { type: 'mutation', range: 120, identifier: 'superiorDarkvision' },
  blindsight:  { type: 'superpower', range: 30, identifier: 'blindsight' },
  truesight:   { type: 'superpower', range: 60, identifier: 'truesight' },
}

// Creature types
ELYSIUM.CREATURE_TYPES = [
  'aberration', 'animal', 'beast', 'celestial', 'construct', 'dragon',
  'elemental', 'fey', 'fiend', 'giant', 'humanoid', 'lycanthrope',
  'monstrosity', 'ooze', 'plant', 'undead', 'vermin',
  'astral', 'ethereal', 'shadow',
]

ELYSIUM.CREATURE_SUBTYPES = {
  humanoid:    ['human','elf','dwarf','halfling','gnome','orc','goblinoid',
                'kobold','lizardfolk','gnoll','yuan-ti','merfolk'],
  fiend:       ['demon','devil','daemon','yugoloth','rakshasa','nightHag'],
  undead:      ['corporeal','deathless'],
  dragon:      ['chromatic','metallic','gem','planar'],
  elemental:   ['fire','water','earth','air','lightning','ice',
                'void','ash','magma','mud','steam'],
  giant:       ['hill','stone','frost','fire','cloud','storm',
                'titan','cyclops','ogre','troll','ettin'],
  celestial:   ['angel','archon','azata','empyrean','planetar','solar'],
  lycanthrope: ['werewolf','wererat','werebear','wereboar','weretiger'],
  vermin:      ['spider','insect','scorpion','centipede','beetle',
                'swarmRat','swarmBat','swarmInsect','swarmSpider'],
}

ELYSIUM.CREATURE_TAGS = [
  'shapechanger','incorporeal','swarm','legendary','mindless',
  'aquatic','amphibious','extraplanar','lycanthrope','aberrant',
]

// Critical table location mapping
ELYSIUM.CRITICAL_TABLE_MAP = {
  head:    'head',
  arm:     'arm',
  leftArm: 'arm',
  rightArm:'arm',
  chest:   'body',
  abdomen: 'body',
  leg:     'leg',
  leftLeg: 'leg',
  rightLeg:'leg',
  wing:    'tailWing',
  leftWing:'tailWing',
  rightWing:'tailWing',
  tail:    'tailWing',
  fin:     'aquatic',
  gill:    'aquatic',
  tentacle:'aquatic',
  default: 'body',
}

// Special effects (full Mythras list - kept as identifiers)
ELYSIUM.SPECIAL_EFFECTS = {
  offensive: [
    'bash', 'bleed', 'chooseLocation', 'circularStrike', 'compelSurrender',
    'damageWeapon', 'disarmOpponent', 'enhanceDamage', 'fellingBlow',
    'forceFailure', 'gainSpecialAbility', 'grip', 'impale', 'maximiseDamage',
    'overpenetration', 'pinDown', 'rapidReload', 'snareSomeone', 'stunLocation',
    'sunder', 'sweepAway', 'tripOpponent', 'wrongFooted',
  ],
  defensive: [
    'avoidance', 'blindOpponent', 'compelSurrender', 'counterAttack',
    'damageWeapon', 'disarmOpponent', 'enhanceParry', 'forceFailure',
    'gainSpecialAbility', 'maximiseDamage', 'pinWeapon', 'reactiveStrike',
    'snareSomeone', 'sunder',
  ],
}

// Special effect differential triggers (degree of advantage in opposed roll)
ELYSIUM.SE_DIFFERENTIAL = {
  criticalVsSuccess: 1,
  criticalVsFailure: 2,
  criticalVsFumble:  3,
  successVsFailure:  1,
  successVsFumble:   2,
  failureVsFumble:   1,
}

// EXP system
ELYSIUM.EXPERIENCE = {
  standardDie: 4,    // 1d4 base
  fastLearnerDie: 6, // Humans
  fumbleAdvancesImmediately: true,
  maxTicksPerSkillPerSession: 1,
}

// Stats — natural maximum before ancestry
ELYSIUM.STAT_NATURAL_MAX_BASE = 20

// Skill cap at character creation
ELYSIUM.STARTING_SKILL_CAP = 70    // hard cap

// Maximum bonuses per source
ELYSIUM.STARTING_SKILL_LIMITS = {
  perProfession:  15,    // max per single skill from profession
  perAncestry:    15,    // max per single skill from ancestry
  hardCap:        70,    // total cap regardless of source
}

// Luck Points — Mythras
ELYSIUM.LUCK_POINTS = {
  // Starting LP = 2 + POW bonus
  base: 2,
  // Recovery: full at start of each session
  combatSavesPerEncounter: 1,
}

// All TBD numerical values that need balancing later
ELYSIUM.BALANCING = {
  startingBuildPoints:     null,
  buildPointPerSkillPct:   null,
  buildPointSkillAccess:   null,
  packageSkillPointTotal:  null,
  packageBPCost:           null,
  expDicePerStatIncrease:  null,    // Method B uses current score
  abilityUnlockCostByTier: [null, 2, 3, 4, 5],
  startingWealthGold:      25,    // up to 25gp depending on profession
  startingLuckPointsBase:   2,    // + POW bonus
}
