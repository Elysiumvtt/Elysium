import { ElysiumCharDev } from '../apps/charDev.mjs'//Add GM tools to Scene

class ElysiumLayer extends foundry.canvas.layers.PlaceablesLayer {

  constructor() {
    super()
    this.objects = {}
  }

  static get layerOptions() {
    return foundry.utils.mergeObject(super.layerOptions, {
      name: 'elysiummenu',
      zIndex: 60
    })
  }

  static get documentName() {
    return 'Token'
  }

  get placeables() {
    return []
  }

}

export class ElysiumMenu {
  static getButtons(controls) {
    canvas.elysiumgmtools = new ElysiumLayer()
    const isGM = game.user.isGM
    controls.push({
      name: 'elysiummenu',
      title: game.i18n.localize('Elysium.gmTools'),
      layer: 'elysiumgmtools',
      icon: 'fas fa-tools',
      visible: isGM,
      tools: [
        {
          toggle: true,
          icon: 'fas fa-chevrons-up',
          name: 'development',
          active: game.settings.get('elysium', 'development'),
          title: game.i18n.localize('Elysium.developmentPhase'),
          onClick: async toggle => await ElysiumCharDev.developmentPhase(toggle)
        }
      ]
    })

  }

  static renderControls(app, html, data) {
    const isGM = game.user.isGM
    const gmMenu = html.find('.fas-fa-tools').parent()
    gmMenu.addClass('elysium-menu')
  }
}
