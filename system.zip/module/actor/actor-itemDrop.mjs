import { ElysiumSelectLists } from '../apps/select-lists.mjs'
import { SkillsSelectDialog } from '../apps/skill-selection.mjs'
import { ElysiumUtilities } from '../apps/utilities.mjs'
import ElysiumDialog from '../setup/elysium-dialog.mjs';

export class ElysiumActorItemDrop {

  // Change default on Drop Item Create routine for requirements (single items and folder drop)-----------------------------------------------------------------
  // v1.1.0-c1: renamed from _BRPonDropItemCreate. The legacy "BRP" prefix
  // dated to a transitional naming during P4 and was missed by the rename
  // pass. The method scope is `ElysiumActorItemDrop` so no prefix is needed.
  static async _onDropItemCreate(actor, itemData) {
    const newItemData = [];
    itemData = itemData instanceof Array ? itemData : [itemData];
    //TODO: Consider adding a bypass to just create the items with no checks
    //      return actor.createEmbeddedDocuments("Item", itemData);
    for (let thisItem of itemData) {
      let nItm = thisItem.toObject()
      let reqResult = 1;
      let errMsg = "";

      //Automatically allow gear to be added
      if (nItm.type != 'gear') {

        //Don't allow the following items to be dropped directly on a character sheet
        if (['powerMod'].includes(nItm.type)) {
          reqResult = 0;
          errMsg = game.i18n.localize('Elysium.' + nItm.type) + "(" + nItm.name + "): " + game.i18n.localize('Elysium.noDirectDrop');
        }

        // When dropping armor, prompt for a hit-location to attach it to.
        // v0.20.0: the BRP-classic `system.HPL` incompatibility check was
        // removed — Elysium always uses per-location HP, so the flag is
        // meaningless. Every armor drop runs the hit-location dialog.
        if (nItm.type === 'armor') {
          const usage = await ElysiumActorItemDrop.hitLocationDialog(actor)
          if (usage) {
            nItm.system.hitlocID = usage.hitLoc;
          } else {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.armorNoHitLoc');
          }
        }

        //When dropping get the base score
        if (nItm.type === 'skill') {
          nItm.system.base = await this._calcBase(nItm, actor)
        }

        //When dropping a weapon check to see if character has the skills and if not add them to the character sheet
        if (nItm.type === 'weapon' && actor.type==='character') {
          //If there isn't a skill1 then give an error message
          if (nItm.system.skill1 === "" || nItm.system.skill1 === "none") {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.weaponNeedsSkill');
          } else {

            nItm.system.equipStatus = 'stowed'
            nItm.system.actEnc = nItm.system.enc
            nItm.system.hpCurr = nItm.system.hp
            let skill1Test = 0
            let skill2Test = 0
            let newSkill = "";
            //Test to see if skill1 or 2 exist on the character
            if ((actor.items.filter(itm => itm.type === 'skill' && nItm.system.skill1 === itm.flags?.elysium?.elysiumidFlag?.id)).length > 0) { skill1Test = 1 }
            if (nItm.system.skill2 != 'none') {
              if ((actor.items.filter(itm => itm.type === 'skill' && nItm.system.skill2 === itm.flags?.elysium?.elysiumidFlag?.id)).length > 0) { skill2Test = 1 }
            }

            //Test to see if the skill1 or 2 are in the newItems due to be created
            if ((await newItemData.filter(itm => itm.type === 'skill' && nItm.system.skill1 === itm.flags?.elysium?.elysiumidFlag?.id)).length > 0) { skill1Test = 1 }
            if (nItm.system.skill2 != 'none') {
              if ((actor.items.filter(itm => itm.type === 'skill' && nItm.system.skill2 === itm.flags?.elysium?.elysiumidFlag?.id)).length > 0) { skill2Test = 1 }
            }

            if (skill1Test === 0 && nItm.system.skill1 != 'none') {
              newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nItm.system.skill1 }))[0]
              if (newSkill) {
                newSkill.system.base = await this._calcBase(newSkill, actor)
                newItemData.push(newSkill)
              }
            }
            if (skill2Test === 0 && nItm.system.skill2 != 'none') {
              newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nItm.system.skill2 }))[0]
              if (newSkill) {
                newSkill.system.base = await this._calcBase(newSkill, actor)
                newItemData.push(newSkill)
              }
            }
          }
        }

        //Drop Culture, Personality & Careers - check one doesnt already exist and add relevant skills etc
        if (['personality', 'career', 'culture'].includes(nItm.type)) {
          const check = await this._dropPersonality(nItm, actor)
          reqResult = check.reqResult;
          errMsg = check.errMsg;
        }

        //If skill, don't let Group Skills be added and check to see if skill exists already unless a non-named specialism skill e.g. Craft (specify)
        if (nItm.type === 'skill') {
          if (nItm.system.group) {
            reqResult = 0;
            errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.stopGroupSkill');
          } else if (nItm.system.specialism && !nItm.system.chosen) {
            nItm = await this._getSpecialism(foundry.utils.duplicate(nItm), actor)
          }
          if (!nItm.system.specialism || (nItm.system.specialism && nItm.system.chosen)) {
            const dupItm = actor.items.filter(itm => itm.type === 'skill' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
            if (dupItm.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
            }
          }
          //If skill is to be added then check that the Skill Category is on the actor
        }

        //If a failing then check that superpower has been selected
        if (nItm.type === 'failing' && actor.system.super === "") {
          reqResult = 0;
          errMsg = nItm.name + " : " + game.i18n.localize('Elysium.needPower') + " (" + game.i18n.localize('Elysium.super') + ")";
        }

        // F17 (rc.7): LEGACY 'power' ITEM TYPE GATE — RETIRED
        //
        // The 7-line block formerly at this position handled drops of items
        // with type='power' — a legacy BRP type retired in Elysium v0.8.0.
        // Per the in-code documentation that already lived above the code:
        //
        //   "If a generic 'power' (legacy BRP type — no longer used in
        //    Elysium v0.8.0; left here as a safe-no-op fallback). The check
        //    requires the corresponding world-setting category to be enabled."
        //
        // The retired code:
        //
        //   if (nItm.type === 'power' && !game.settings.get('elysium', [nItm.system.category])) {
        //     reqResult = 0;
        //     errMsg = nItm.name + " : " + game.i18n.localize('Elysium.nopower');
        //   }
        //
        // Two reasons for retirement (per F17 audit):
        //   1. Gated by `nItm.type === 'power'` short-circuit — no v1.0.0
        //      template emits 'power' type items; v0.8.0 retirement was
        //      complete. The gate is dead in production.
        //   2. The lookup itself (`game.settings.get('elysium', [category])`)
        //      suffers from the same fundamental bug as the sibling at L295
        //      (now fixed): no world-level magic-category settings exist;
        //      these flags live per-actor as `actor.system[category]`. If the
        //      code were ever reached it would throw, not no-op.
        //
        // Per Option B precedent (retire legacy dead code outright with
        // audit-comment; no band-aids), retired here. The locale key
        // `Elysium.nopower` is preserved (still used by the sibling at L295
        // — the corrected per-actor gate in `_dropPersonality`).

        //If an allegiance check that the appropriate game setting is true
        if (nItm.type === 'allegiance') {
          if (!true) {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.noAlleg');
          } else {
            const dupItm = actor.items.filter(itm => itm.type === 'allegiance' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
            if (dupItm.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
            }
          }
        }

        //If a reputation check that the appropriate game setting is true
        if (nItm.type === 'reputation') {
          if (game.settings.get('elysium', 'useReputation') === "0") {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.noRep');
          } else if (game.settings.get('elysium', 'useReputation') === "1") {
            const repNum = actor.items.filter(itm => itm.type === 'reputation')
            if (repNum.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + " : " + game.i18n.localize('Elysium.oneRep');
            }
          } else {
            const dupItm = actor.items.filter(itm => itm.type === 'reputation' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
            if (dupItm.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
            }
          }
        }

        //If a Personality Trait check that the appropriate game setting is true
        if (nItm.type === 'persTrait') {
          if (!true) {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.noPersTrait');
          } else {
            const dupItm = actor.items.filter(itm => itm.type === 'persTrait' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
            if (dupItm.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
            }
          }
        }

        //If a passion check that the appropriate game setting is true
        if (nItm.type === 'passion') {
          if (!true) {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.noPassion');
          } else {
            const dupItm = actor.items.filter(itm => itm.type === 'passion' && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
            if (dupItm.length > 0) {
              reqResult = 0;
              errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
            }
          }
        }

        //v0.8.0: removed the magic/psychic/sorcery/super "power needed
        //first" gate. Power tabs are now activated automatically by
        //_prepareCharacterData based on item content, so the gate created
        //a chicken-and-egg problem (can't drop the first item because the
        //flag isn't set yet). Mutation drops still don't have an activation
        //pre-requisite — the system.mutation flag now flips on drop.

        //If a power-type item and not failed a previous test, check to
        //see if the item already exists on the character sheet (dup check).
        //v0.8.0: type list updated — `arcane` / `divine` / `mysticism` replace
        //`magic` / (legacy `power`) / `psychic`.
        if ((['arcane', 'divine', 'mysticism', 'mutation', 'sorcery', 'super', 'hit-location', 'skillcat'].includes(nItm.type)) && reqResult === 1) {
          const dupItm = actor.items.filter(itm => itm.type === nItm.type && itm.flags?.elysium?.elysiumidFlag?.id && itm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id)
          if (dupItm.length > 0) {
            reqResult = 0;
            errMsg = nItm.name + "(" + nItm.flags?.elysium?.elysiumidFlag?.id + "): " + game.i18n.localize('Elysium.dupItem');
          }
        }

        //If a hit-location and not using HPL then only allow general hit location
        if (nItm.type === 'hit-location' && !true) {
          if (nItm.system.locType != 'general') {
            reqResult = 0;
            errMsg = nItm.name + " : " + game.i18n.localize('Elysium.noHPL');
          }
        }

      }

      //Check to see if we can drop the Item
      if (reqResult != 1) {
        ui.notifications.warn(errMsg);
      } else {
        newItemData.push(nItm);
      }
    }
    return (newItemData);
  }

  //Calculate Base Skill on Dropping the item on actor
  static async _calcBase(itm, actor) {
    //Check the skill Category exists
    await this._checkSkillCat(itm, actor)
    if (itm.system.variable) {
      const stat1 = itm.system.baseFormula[1].stat
      const stat2 = itm.system.baseFormula[2].stat
      let opt1 = 0
      let opt2 = 0
      let newScore = 0
      if (stat1 != 'fixed') {
        if (stat1 != 'edu' || false) {
          opt1 = Math.ceil((actor.system.stats[stat1].base + actor.system.stats[stat1].redist + actor.system.stats[stat1].culture) * itm.system.baseFormula[1].value)
        }
      }
      if (stat2 != 'fixed') {
        if (stat2 != 'edu' || false) {
          opt2 = Math.ceil((actor.system.stats[stat2].base + actor.system.stats[stat2].redist + actor.system.stats[stat2].culture) * itm.system.baseFormula[2].value)
        }
      }

      if (itm.system.baseFormula.Func === 'and') {
        newScore = opt1 + opt2
      } else {
        newScore = Math.max(opt1, opt2)
      }
      return newScore
    }
    return itm.system.base
  }

  static async hitLocationDialog(actor) {
    const hitLocOptions = await ElysiumSelectLists.getHitLocOptions(actor)
    const label = game.i18n.localize('Elysium.chooseHitLoc')
    const data = {
      hitLocOptions,
      label,
    }
    const html = await foundry.applications.handlebars.renderTemplate('systems/elysium/templates/dialog/hitLocChoice.hbs', data)
    const dlg = await ElysiumDialog.input({
      window: {title: game.i18n.localize('Elysium.hitLoc')},
      content: html,
      ok: {
        label: game.i18n.localize('Elysium.proceed')
      }
    })
    return dlg
  }

  //Make skill selections etc when dropping a personality, culture or career
  static async _dropPersonality(itm, actor) {
    const addItems = []
    const updateItems = []
    const skillList = []
    const powerList = []
    let newSkill = {}
    if (actor.items.filter(nitm => nitm.type === itm.type).length > 0) {
      return ({ 'reqResult': 0, 'errMsg': itm.name + " : " + game.i18n.format('Elysium.stopPersonality', { type: game.i18n.localize('Elysium.' + itm.type) }) })
    }

    //If Career then check for powers
    if (itm.type === 'career') {
      for (let nPwr of itm.system.powers) {
        newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nPwr.elysiumid }))[0]
        if (!newSkill) continue
        // F17 (rc.7) FIX: pre-existing lookup bug. The original code was
        // `game.settings.get('elysium', [newSkill.system.category])` — but:
        //   1. The bracket-wrapping (`[category]`) was suspect, AND
        //   2. The lookup itself was wrong. There are no world-level magic-
        //      category settings registered (no `elysium.arcane`, `elysium.
        //      sorcery`, etc.). Magic-category enablement is a PER-ACTOR
        //      property — `actor.system.arcane='on'|''`, `.sorcery`, `.psychic`,
        //      `.mutation`, `.mysticism`, `.super`. The original lookup always
        //      threw `<category> is not a registered game setting`, aborting
        //      the entire career-drop-with-powers flow before reaching the F9
        //      site below. F9 fix in isolation did not deliver its claimed
        //      user-facing benefit because of this upstream throw; F17 fix
        //      unblocks the path.
        //
        // The correct lookup is `actor.system[newSkill.system.category]`
        // which reads the actor's per-character magic-category flag. If the
        // category flag is "on" (truthy), the gate passes; if it's "" or
        // missing (falsy), warn and skip.
        if (!actor.system[newSkill.system.category]) {
          ui.notifications.warn(newSkill.name + " : " + game.i18n.localize('Elysium.nopower'))
          continue
        }
        if (newSkill) {
          // F9 (rc.7) FIX: pre-existing logic bug — `filter()` returns an
          // array, which is always truthy in JavaScript. The pre-rc.7 condition
          // `if (actor.items.filter(...))` was always-true, meaning the
          // `continue` branch always ran and the `else` branch (which pushes
          // the newSkill onto powerList for batch-creation) NEVER executed.
          //
          // User-visible symptom: dropping a career item with attached power-
          // skills auto-skill-creation silently failed — users had to manually
          // create the parent skills.
          //
          // F2 (alpha.54) added the defensive optional-chain guard against
          // items without ElysiumID metadata but explicitly deferred the broken-
          // logic fix to v1.1.0 (documented as F9). Per Option II at rc.7
          // (fix-not-defer methodology applied for the 5th time), the
          // `.length > 0` check is added here. Pattern now matches the correct
          // sibling usages at L286 and L647 in this same file.
          if (actor.items.filter(nitm => nitm.flags?.elysium?.elysiumidFlag?.id === newSkill.flags?.elysium?.elysiumidFlag?.id).length > 0) {
            continue
          } else {
            powerList.push(foundry.utils.duplicate(newSkill))
          }
        }
      }
    }

    //Go through each Optional Skill Group and make selections
    for (let nGrp of itm.system.groups) {
      const selected = await this._selectSkillGroup(nGrp)
      if (selected.length < 1 || !selected) { continue }
      for (let nSkill of selected) {
        newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nSkill.id }))[0]
        //If a group skill then pass to the selection
        if (newSkill.system.group) {
          const selected = await this._selectGroupSkill(newSkill, actor, 1)
          if (selected.length < 1 || !selected) { continue }
          newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: selected[0].id }))[0]
          if (newSkill) {
            const placeholder = foundry.utils.duplicate(newSkill)
            if (itm.type === 'culture') {
              placeholder.system.culture = nSkill.bonus
            }
            skillList.push(placeholder)
          }
        } else {
          if (newSkill) {
            const placeholder = foundry.utils.duplicate(newSkill)
            if (itm.type === 'culture') {
              placeholder.system.culture = nSkill.bonus
            }
            skillList.push(placeholder)
          }
        }
      }
    }

    //Get each skill etc on the main list
    for (let nItm of itm.system.skills) {
      newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: nItm.elysiumid }))[0]
      //If you can't find the skill then skip it
      if (!newSkill) continue
      //If a group skill then pass to the selection
      if (newSkill.system.group) {
        const selected = await this._selectGroupSkill(newSkill, actor, 1)
        if (selected.length < 1 || !selected) { continue }
        newSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: selected[0].id }))[0]
        if (newSkill) {
          const placeholder = foundry.utils.duplicate(newSkill)
          if (itm.type === 'culture') {
            placeholder.system.culture = nItm.bonus
          }
          skillList.push(placeholder)
        }
      } else {
        if (newSkill) {
          const placeholder = foundry.utils.duplicate(newSkill)
          if (itm.type === 'culture') {
            placeholder.system.culture = nItm.bonus
          }
          skillList.push(placeholder)
        }
      }
    }

    //This is the list of selected skills
    for (let nItm of skillList) {
      //If a specialism skill and not specified then get the name etc
      if (nItm.system.specialism && !nItm.system.chosen) {
        nItm = await this._getSpecialism(nItm, actor)
      }

      //If personality then set Personality score to 20 and flag personality skills
      if (itm.type === 'personality') {
        nItm.system.personality = 20
        nItm.system.prsnlty = true
      }

      //If career then flag career skills
      if (itm.type === 'career') {
        nItm.system.occupation = true
      }

      //If culture then flag career skills
      if (itm.type === 'culture') {
        nItm.system.cultural = true
      }

      //If existing skill on actor then push to updateItems otherwise calculate base and push to addItems
      // Direct flag read — see elysiumid.mjs for rationale (ElysiumID namespace kept as 'elysium' but accessed
      // via property path because 'elysium' is no longer an active flag scope post-system-id rename).
      const actItem = (actor.items.filter(dItm => dItm.flags?.elysium?.elysiumidFlag?.id).filter(cItm => cItm.flags.elysium.elysiumidFlag.id === nItm.flags?.elysium?.elysiumidFlag?.id))[0]
      if (actItem) {
        if (itm.type === 'personality') {
          updateItems.push({ _id: actItem._id, 'system.personality': nItm.system.personality, 'system.prsnlty': nItm.system.prsnlty })
        } else if (itm.type === 'career') {
          updateItems.push({ _id: actItem._id, 'system.occupation': nItm.system.occupation })
        } else if (itm.type === 'culture') {
          updateItems.push({ _id: actItem._id, 'system.culture': nItm.system.culture, 'system.cultural': nItm.system.cultural })
        }
      } else {
        nItm.system.base = await this._calcBase(nItm, actor)
        addItems.push(nItm)
      }
    }

    await Item.createDocuments(addItems, { parent: actor })
    await Item.createDocuments(powerList, { parent: actor })
    await Item.updateDocuments(updateItems, { parent: actor })

    //If a culture add the dice and bonuses
    if (itm.type === 'culture') {
      let changes = {}
      for (let [key, stat] of Object.entries(itm.system.stats)) {
        if (stat.formula != "") {
          changes = Object.assign(changes, { [`system.stats.${key}.formula`]: stat.formula })
        }
        changes = Object.assign(changes, { [`system.stats.${key}.culture`]: Number(stat.mod) ?? 0 })
      }
      //Now add the move score
      changes = Object.assign(changes, { 'system.move': Number(itm.system.move) })
      await actor.update(changes)
    }

    //If a career then select wealth level
    if (itm.type === 'career') {
      const wealthOptions = await ElysiumSelectLists.getWealthOptions(itm.system.minWealth, itm.system.maxWealth)
      const selected = await this.selectFromRadio(wealthOptions, "Select Wealth Level")
      await actor.update({ 'system.wealth': selected })
    }

    return ({ 'reqResult': 1, 'errMsg': "" })
  }

  static async personalityDelete(event, actor) {
    const confirmation = await ElysiumDialog.confirm({
      window: { title: game.i18n.localize("Elysium.deletePersonality") },
      content: game.i18n.localize("Elysium.deleteConfirm")
    })
    if (!confirmation) { return }

    //Reset all actor personality points on skills to zero
    const changes = []
    for (let itm of actor.items) {
      if (['skill', 'arcane', 'mysticism'].includes(itm.type)) {
        changes.push({
          _id: itm.id,
          'system.personality': 0,
          'system.prsnlty': false
        })
      }
    }
    await Item.updateDocuments(changes, { parent: actor })
    const personalities = actor.items.filter(itm =>itm.type==='personality').map(itm => {return (itm.id)})
    await Item.deleteDocuments(personalities, {parent: actor});
  }

  static async careerDelete(event, actor) {
    const confirmation = await ElysiumDialog.confirm({
      window: { title: game.i18n.localize("Elysium.deleteCareer") },
      content: game.i18n.localize("Elysium.deleteConfirm")
    })
    if (!confirmation) return;

    //Reset all actor career skills to zero
    const changes = []
    for (let itm of actor.items) {
      if (['skill', 'arcane', 'mysticism'].includes(itm.type)) {
        changes.push({
          _id: itm.id,
          'system.career': 0,
          'system.occupation': false
        })
      }
    }
    await Item.updateDocuments(changes, { parent: actor })
    await actor.update({ 'system.wealth': "" })
    const careers = actor.items.filter(itm =>itm.type==='career').map(itm => {return (itm.id)})
    await Item.deleteDocuments(careers, {parent: actor});
  }

  static async cultureDelete(event, actor) {
    const confirmation = await ElysiumDialog.confirm({
      window: { title: game.i18n.localize("Elysium.deleteCulture") },
      content: game.i18n.localize("Elysium.deleteConfirm")
    })
    if (!confirmation) return;

    //Reset all actor culture skills to zero
    const changes = []
    for (let itm of actor.items) {
      if (['skill', 'arcane', 'mysticism'].includes(itm.type)) {
        changes.push({
          _id: itm.id,
          'system.culture': 0,
          'system.cultural': false
        })
      }
    }
    await Item.updateDocuments(changes, { parent: actor })
    //Reset dice and culture stat mods
    await actor.update({
      'system.stats.str.formula': "",
      'system.stats.con.formula': "",
      'system.stats.int.formula': "",
      'system.stats.siz.formula': "",
      'system.stats.pow.formula': "",
      'system.stats.dex.formula': "",
      'system.stats.cha.formula': "",
      'system.stats.str.culture': 0,
      'system.stats.con.culture': 0,
      'system.stats.int.culture': 0,
      'system.stats.siz.culture': 0,
      'system.stats.pow.culture': 0,
      'system.stats.dex.culture': 0,
      'system.stats.cha.culture': 0,
      'system.move': 0
    })
    const cultures = actor.items.filter(itm =>itm.type==='culture').map(itm => {return (itm.id)})
    await Item.deleteDocuments(cultures, {parent: actor});
  }

  static async _selectGroupSkill(newSkill, actor, picks) {
    const selectOptions = []
    if (newSkill.system.groupSkills.length > 0) {
      for (let skillOpt of newSkill.system.groupSkills) {
        const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: skillOpt.elysiumid }))[0]
        if (tempSkill) { selectOptions.push({ id: skillOpt.elysiumid, selected: false, name: tempSkill.name }) }
      }
    } else {
      const skillList = await game.system.api.elysiumid.fromElysiumIDRegexBest({ elysiumidRegExp: new RegExp('^i.skill'), type: 'i' })
      skillList.sort(function (a, b) {
        const x = a.name;
        const y = b.name;
        if (x < y) { return -1 };
        if (x > y) { return 1 };
        return 0;
      });
      for (let skillOpt of skillList) {
        // F2 (alpha.54) defensive guard. Skip skills lacking ElysiumID metadata
        // rather than throwing during the selection-options build.
        if (!skillOpt.flags?.elysium?.elysiumidFlag?.id) continue
        selectOptions.push({ id: skillOpt.flags.elysium.elysiumidFlag.id, selected: false, name: skillOpt.name })
      }
    }
    const selectedSkill = await SkillsSelectDialog.create(selectOptions, picks, game.i18n.localize('Elysium.skills'))
    if (selectedSkill) {
      return selectedSkill
    } else { return false }
  }

  static async _selectSkillGroup(newGroup) {
    const selectOptions = []
    const picks = newGroup.options
    for (let skillOpt of newGroup.skills) {
      const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: skillOpt.elysiumid }))[0]
      if (tempSkill) { selectOptions.push({ id: skillOpt.elysiumid, selected: false, name: tempSkill.name, bonus: skillOpt.bonus ?? 0 }) }
    }
    const selectedSkill = await SkillsSelectDialog.create(selectOptions, picks, game.i18n.localize('Elysium.skills'))
    if (selectedSkill) {
      return selectedSkill
    } else { return false }
  }

  static async _getSpecialism(newSkill, actor) {

    const title = game.i18n.format('Elysium.getSpecialism', { entity: newSkill.name })
    const specName = await ElysiumDialog.input({
      window: {title: title},
      content: `<input class="centre" type="text" name="entry">`,
      ok: {
        label: game.i18n.localize('Elysium.proceed')
      }
    })
    newSkill.system.specName = specName.entry
    newSkill.name = newSkill.system.mainName + ' (' + specName.entry + ')'
    // F2 (alpha.54) defensive guard. Ensure the ElysiumID flag structure exists
    // before writing — items created without metadata won't have intermediate
    // dicts, so we can't assign .id to undefined without populating ancestors.
    newSkill.flags = newSkill.flags || {}
    newSkill.flags.elysium = newSkill.flags.elysium || {}
    newSkill.flags.elysium.elysiumidFlag = newSkill.flags.elysium.elysiumidFlag || {}
    newSkill.flags.elysium.elysiumidFlag.id = "i.skill." + await ElysiumUtilities.toKebabCase(newSkill.name)
    newSkill.system.chosen = true;
    return newSkill
  }

  static async selectFromRadio(list, title) {
    //Get list of items
    const newList = list

    //If there's only one item on the list then return it
    let selected = ""
    if (newList.length < 1) { return false }
    if (Object.keys(newList).length === 1) {
      selected = Object.values(newList)[0]

      //Otherwise call the dialog selection
    } else {
      const destination = 'systems/elysium/templates/dialog/selectItem.hbs';
      const data = {
        headTitle: title,
        newList,
      }
      const html = await foundry.applications.handlebars.renderTemplate(destination, data);

      const usage = await ElysiumDialog.input({
      window: {title: title},
      content: html,
      ok: {
        label: game.i18n.localize('Elysium.proceed')
      }
    })

      //Get the PID from the form
      if (usage) {
        selected = usage.selectItem;
      }
    }
    if (selected === "") { return false }
    return selected
  }

  static async _checkSkillCat(skill, actor) {
    // Elysium fork: skills use `system.elysium.skillCategory` for grouping,
    // not BRP's skillcat item auto-import. The `system.category` field
    // still exists (legacy values like 'cmbtmod', 'mentmod' for CSS/labels)
    // but isn't a elysiumid, so the elysiumid lookup below would throw.
    //
    // Short-circuit: if category isn't a valid elysiumid (doesn't start with
    // 'i.skillcat.'), skip the auto-import. Skills group via Elysium
    // category sections instead.
    const cat = skill.system?.category
    if (!cat || !/^i\.skillcat\./.test(cat)) {
      return
    }

    //Check to see if the skill category already exists and if it does then do nothing
    const newSkillCats = []
    // Direct flag read — see elysiumid.mjs for rationale.
    if (actor.items.filter(dItm => dItm.flags?.elysium?.elysiumidFlag?.id).filter(nitm => nitm.flags.elysium.elysiumidFlag.id === skill.system.category).length > 0) {
      return
    }
    //Get the best version of the skill category
    const newSkillCat = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: skill.system.category }))[0]
    if (newSkillCat) {
      newSkillCats.push(newSkillCat)
      await Item.createDocuments(newSkillCats, { parent: actor })
    } else {
      const errMsg = game.i18n.format('Elysium.noSkillCat', { skillCat: skill.system.category, skillName: skill.name })
      ui.notifications.warn(errMsg);
    }
    return
  }

}
