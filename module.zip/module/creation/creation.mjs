/**
 * Elysium Character Creation
 *
 * Provides:
 *   - 4D6 drop lowest stat rolling
 *   - Stat assignment dialog
 *   - Build Point/Skill Point pool tracking
 *   - Stat advance via EXP dice (gamble or guaranteed)
 *
 * The full character creation flow uses a wizard-style dialog,
 * but the underlying methods can be called individually from macros.
 */

import { ELYSIUM } from '../config/config.mjs'
import { getSetting } from '../settings/register-settings.mjs'

export class ElysiumCharacterCreation {

  /**
   * Roll seven stats (4D6 drop lowest).
   * Returns an array of seven values to assign.
   */
  static async rollSevenStats () {
    const method = getSetting('statRollMethod', '4d6dl')
    const rolls = []

    for (let i = 0; i < 7; i++) {
      let result
      if (method === '4d6dl') {
        const r = await new Roll('4d6kh3').evaluate()
        result = r.total
      } else if (method === '3d6') {
        const r = await new Roll('3d6').evaluate()
        result = r.total
      } else if (method === '2d6+6') {
        const r = await new Roll('2d6+6').evaluate()
        result = r.total
      } else {
        result = 10
      }
      rolls.push(result)
    }
    return rolls.sort((a, b) => b - a)    // sorted descending
  }


  /**
   * Roll a single stat
   */
  static async rollOneStat (formula = '4d6kh3') {
    const r = await new Roll(formula).evaluate()
    return r.total
  }


  /**
   * Open the stat assignment dialog after rolling.
   */
  static async assignRolledStats (actor, rolls) {
    return new Promise(resolve => {
      const stats = ['str', 'con', 'siz', 'int', 'pow', 'dex', 'cha']

      const optionsHtml = rolls.map((r, idx) =>
        `<option value="${idx}">${r}</option>`).join('')

      const formRows = stats.map(stat => `
        <div class="form-group">
          <label>${game.i18n.localize(`Elysium.Stats.${stat}`)}</label>
          <select name="${stat}">${optionsHtml}</select>
        </div>
      `).join('')

      new foundry.applications.api.DialogV2({
        window: { title: game.i18n.localize('Elysium.Creation.AssignStats') },
        content: `
          <div class="elysium-creation-stats">
            <p>${game.i18n.localize('Elysium.Creation.AssignStatsHint')}</p>
            <p>${game.i18n.localize('Elysium.Creation.RolledValues')}: ${rolls.join(', ')}</p>
            ${formRows}
          </div>
        `,
        buttons: [
          { action: 'cancel', label: game.i18n.localize('Cancel'),
            callback: () => resolve(null) },
          { action: 'apply', label: game.i18n.localize('Apply'),
            default: true,
            callback: async (event, button, dialog) => {
              const result = {}
              for (const stat of stats) {
                const select = dialog.element.querySelector(`select[name="${stat}"]`)
                const idx = parseInt(select?.value || 0)
                result[stat] = rolls[idx]
              }
              await this._applyAssignedStats(actor, result)
              resolve(result)
            }},
        ],
      }).render(true)
    })
  }

  static async _applyAssignedStats (actor, assignments) {
    const update = {}
    for (const stat in assignments) {
      update[`system.stats.${stat}.base`] = assignments[stat]
    }
    await actor.update(update)
  }


  /**
   * Increase a stat using EXP dice — Gamble method.
   * Returns: { success, rolled, dice, increased }
   */
  static async gambleStatIncrease (actor, stat) {
    const current = this._statBaseValue(actor, stat)
    const naturalMax = (actor.flags?.elysium?.statNaturalMax?.[stat] ||
                        ELYSIUM.STAT_NATURAL_MAX_BASE)

    if (current >= naturalMax) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.AtMax', {
        stat, max: naturalMax,
      }))
      return { success: false, atMax: true }
    }

    const expDice = actor.flags?.elysium?.expDice?.available || 0
    if (expDice < 1) {
      ui.notifications.warn(game.i18n.localize('Elysium.Stats.NoExpDice'))
      return { success: false, noDice: true }
    }

    // Spend 1 EXP die, roll 3D6 vs current score
    const roll = await new Roll('3d6').evaluate()
    const success = roll.total > current

    const newDice = expDice - 1
    let updates = {
      [`flags.elysium.expDice.available`]: newDice,
    }

    if (success) {
      updates[`system.stats.${stat}.exp`] = (actor.system.stats[stat]?.exp || 0) + 1
    }

    await actor.update(updates)

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div class="elysium-stat-advance">
          <h4>${actor.name} — ${game.i18n.localize('Elysium.Stats.GambleAdvance')}</h4>
          <p>${stat.toUpperCase()}: ${current} (target > ${current})</p>
          <p>${game.i18n.localize('Elysium.Roll')} 3d6: <strong>${roll.total}</strong></p>
          <p>${success
            ? game.i18n.format('Elysium.Stats.IncreasedTo', { stat, value: current + 1 })
            : game.i18n.localize('Elysium.Stats.NoIncrease')}</p>
        </div>
      `,
    })

    return { success, rolled: roll.total, dice: 1, increased: success ? 1 : 0 }
  }


  /**
   * Increase a stat using EXP dice — Guaranteed method.
   * Costs EXP dice equal to current score.
   */
  static async guaranteedStatIncrease (actor, stat) {
    const current = this._statBaseValue(actor, stat)
    const naturalMax = (actor.flags?.elysium?.statNaturalMax?.[stat] ||
                        ELYSIUM.STAT_NATURAL_MAX_BASE)

    if (current >= naturalMax) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.AtMax', {
        stat, max: naturalMax,
      }))
      return { success: false, atMax: true }
    }

    const expDice = actor.flags?.elysium?.expDice?.available || 0
    if (expDice < current) {
      ui.notifications.warn(game.i18n.format('Elysium.Stats.NotEnoughDice', {
        required: current, available: expDice,
      }))
      return { success: false, noDice: true }
    }

    await actor.update({
      [`flags.elysium.expDice.available`]: expDice - current,
      [`system.stats.${stat}.exp`]: (actor.system.stats[stat]?.exp || 0) + 1,
    })

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div class="elysium-stat-advance">
          <h4>${actor.name} — ${game.i18n.localize('Elysium.Stats.GuaranteedAdvance')}</h4>
          <p>${stat.toUpperCase()} ${current} → ${current + 1}</p>
          <p>${game.i18n.format('Elysium.Stats.SpentDice', { count: current })}</p>
        </div>
      `,
    })

    return { success: true, dice: current, increased: 1 }
  }


  /**
   * Award EXP dice to an actor (GM action)
   */
  static async awardExpDice (actor, count = 1) {
    const current = actor.flags?.elysium?.expDice?.available || 0
    await actor.update({
      'flags.elysium.expDice.available': current + count,
    })
    ui.notifications.info(game.i18n.format('Elysium.Exp.Awarded', {
      actor: actor.name, count,
    }))
  }


  // === HELPERS ======================================================

  static _statBaseValue (actor, stat) {
    const s = actor.system.stats?.[stat]
    if (!s) return 0
    return (s.base || 0) + (s.redist || 0) + (s.culture || 0) +
           (s.exp || 0) + (s.age || 0) + (s.effects || 0)
  }
}
