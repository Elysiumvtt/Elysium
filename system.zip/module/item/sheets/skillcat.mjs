import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumItemSheetV2 } from './base-item-sheet.mjs'

/**
 * Skill category item sheet — P10 cluster 3a / alpha.40 rewrite.
 *
 * Defines a base stat + 8 per-attribute "advanced" mappings (STR..EDU).
 * Tabbed mode with details / description / gmNotes.
 *
 * Per c3-skillcat-1: replaced 8 redundant per-stat `advStatOptions*`
 * context fields with one shared `advStatOptions`.
 * Per c3-skillcat-2/3: replaced 8 redundant `skillCatName*` context
 * fields with a single `statRows[]` data structure looped by the
 * template (each row carrying stat key + localized label + current
 * value + display name).
 */
export class ElysiumSkillCategory extends ElysiumItemSheetV2 {

  static DEFAULT_OPTIONS = {
    classes: ['skillcat'],
    position: { width: 560, height: 640 },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/skillcat.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)

    // Base-stat select + display name
    context.statOptions = await ElysiumSelectLists.addStatOptions()
    context.statName = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[this.item.system.stat])

    // One shared options list (all 8 advanced selects used identical
    // options pre-cluster-3; cluster 3a collapses to one).
    context.advStatOptions = await ElysiumSelectLists.getAdvSkillCatOptions()

    // Loop-driven per-stat rows
    const statKeys = ['str', 'con', 'int', 'siz', 'pow', 'dex', 'cha', 'edu']
    context.statRows = statKeys.map(stat => {
      const value = this.item.system.attrib?.[stat] ?? ''
      const labelKey = 'Elysium.Stats' + stat.charAt(0).toUpperCase() + stat.slice(1) + 'Abbr'
      return {
        stat,
        label: game.i18n.localize(labelKey),
        value,
        displayName: value ? game.i18n.localize('Elysium.advSkillCat.' + value) : '—',
      }
    })

    // Header chips per c3-2: Base Stat
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.baseStat'), value: context.statName },
    ]

    return context
  }
}
