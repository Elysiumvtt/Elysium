import { ElysiumCheck } from './check.mjs'
import { isCtrlKey } from './helper.mjs'

/**
 * F13 (rc.6): resolve an item/skill id from a roll-handler invocation, handling
 * the two v1.0.0 template patterns:
 *
 *   Pattern A — data on the clicked element itself:
 *     <a data-action="skillRoll" data-skill-id="...">
 *     The `detail` arg (which base-actor-sheet passes as `target.dataset`)
 *     already contains the id directly.
 *
 *   Pattern B — data on the row wrapper, action on an inner element:
 *     <div class="elysium-allegiance-row" data-item-id="...">
 *       <a data-action="allegianceRoll">...</a>
 *     </div>
 *     The `detail` arg only has the clicked <a>'s dataset (which won't include
 *     the id), so we walk up to find the row wrapper carrying the id attribute.
 *
 * Pre-F13, every roll handler used `event.target.closest('.item').dataset.itemId`
 * — a v0.x DOM-traversal pattern that returned null on v1.0.0 sheets because
 * the new templates emit semantic wrapper classes (elysium-allegiance-row etc.)
 * not the legacy `.item` class. This helper covers both patterns and is null-
 * safe (returns null instead of throwing).
 *
 * @param {Event}   event   the DOM event (target is the actual clicked element)
 * @param {Object}  detail  the dataset of target (passed by base-actor-sheet)
 * @param  {...string} attrs  dataset property names in priority order
 *                            (camelCase: 'itemId', 'skillId', 'allegianceId',
 *                            etc.). The helper checks `detail` first, then the
 *                            nearest enclosing element carrying any of those
 *                            data-* attributes.
 * @returns {string|null}
 */
function resolveTargetItemId(event, detail, ...attrs) {
  // Try direct dataset reads first (Pattern A)
  for (const attr of attrs) {
    if (detail?.[attr]) return detail[attr]
  }
  // Fallback: walk up the DOM to find a wrapper carrying any of the attrs
  // Convert camelCase -> kebab-case for the attribute selector
  const sel = attrs
    .map(a => `[data-${a.replace(/[A-Z]/g, m => '-' + m.toLowerCase())}]`)
    .join(', ')
  const wrapper = event.target.closest(sel)
  if (!wrapper) return null
  for (const attr of attrs) {
    if (wrapper.dataset[attr]) return wrapper.dataset[attr]
  }
  return null
}

export class ElysiumRollType {

  //Roll Types
  //CH = Characteristic
  //SK = Skill
  //DM = Damage
  //CM = Combat
  //AR = Armor (Random)
  //AL = Allegiance Roll
  //PA - Passion Roll
  //PT - Personality Trait Roll
  //RP - Reputation Roll
  //IM - Spell Impact Roll
  //QC - Quick Combat

  //Card Types
  //NO = Normnal Roll
  //RE = Resistance Roll (CH only)
  //PP = POW v POW (CH only)
  //GR = Combined (Group) Roll
  //CO = Cooperative Roll
  //OP = Opposed Roll
  //CB = Combat Roll

  //Start Characteristic Roll
  static async _onStatRoll(event, detail, actor) {
    const altKey = event.altKey;
    const ctrlKey = isCtrlKey(event ?? false);
    let shiftKey = event.shiftKey
    let cardType = 'NO';
    let characteristic = detail.characteristic;
    if (ctrlKey) { cardType = 'RE' }
    if (altKey) {
      cardType = 'PP';
      characteristic = 'pow'
    }
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'CH',
      cardType,
      characteristic,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Start Skill Roll
  static async _onSkillRoll(event, detail, actor) {
    const altKey = event.altKey;
    const ctrlKey = isCtrlKey(event ?? false);
    let shiftKey = event.shiftKey
    let cardType = 'NO';
    // F13 (rc.6): templates use two patterns — `data-skill-id` on the clicked
    // <a> (left-rail-skills, right-rail-senses) or `data-item-id` on the row
    // wrapper (magic-skill-summary, divine-body). Helper checks both.
    const skillId = resolveTargetItemId(event, detail, 'skillId', 'itemId');
    if (ctrlKey) { cardType = 'OP' }
    if (altKey) { cardType = 'GR' }
    if (altKey && ctrlKey) { cardType = 'CO' }
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'SK',
      cardType,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Start Allegiance Roll
  static async _onAllegianceRoll(event, detail, actor) {
    const cardType = 'NO';
    // F13 (rc.6): allegiance-row puts data-item-id on the .elysium-allegiance-row
    // wrapper; the clicked <a data-action="allegianceRoll"> has no id. Helper
    // walks up to find it.
    const skillId = resolveTargetItemId(event, detail, 'itemId');
    let shiftKey = event.shiftKey
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'AL',
      cardType,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Start Passion Roll
  static async _onPassionRoll(event, detail, actor) {
    const ctrlKey = isCtrlKey(event ?? false);
    let shiftKey = event.shiftKey
    let cardType = 'NO';
    // F13 (rc.6): passion-row puts data-item-id on .elysium-passion-row wrapper.
    const skillId = resolveTargetItemId(event, detail, 'itemId');
    if (ctrlKey) { cardType = 'OP' }
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'PA',
      cardType,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Start Reputation Roll
  static async _onReputationRoll(event, detail, actor) {
    const ctrlKey = isCtrlKey(event ?? false);
    const altKey = event.altKey;
    let shiftKey = event.shiftKey
    let cardType = 'NO';
    // F13 (rc.6): reputation-row puts data-item-id on .elysium-reputation-row.
    const skillId = resolveTargetItemId(event, detail, 'itemId');
    if (ctrlKey) { cardType = 'OP' }
    if (altKey) { cardType = 'GR' }
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'PA',
      cardType,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Start Personality Trait Roll
  static async _onPersTraitRoll(event, detail, actor) {
    const ctrlKey = isCtrlKey(event ?? false);
    let shiftKey = event.shiftKey
    let cardType = 'NO';
    // F13 (rc.6): pers-trait-row puts data-item-id on .elysium-pers-trait-row.
    // The clicked <a> has data-opp (correctly read from detail) but no id.
    const skillId = resolveTargetItemId(event, detail, 'itemId');
    const opp = detail.opp;
    if (ctrlKey) { cardType = 'OP' }
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType: 'PT',
      cardType,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token,
      opp
    })
  }

  //Start Damage Roll
  static async _onDamageRoll(event, detail, actor) {
    // F13 (rc.6): weapon-row puts data-item-id on .elysium-weapon-row wrapper.
    const itemId = resolveTargetItemId(event, detail, 'itemId');
    const cardType = 'NO'
    ElysiumCheck._trigger({
      rollType: 'DM',
      cardType,
      itemId,
      actor: actor,
      token: actor.token
    })
  }

  //Magic Spell Impact Roll
  static async _onImpactRoll(event, detail, actor) {
    // F13 (rc.6): mysticism-body (legacy unlocked-mode dev grid context) wraps
    // the trigger in <li class="item ..."> — helper covers this with the
    // [data-item-id] selector since the wrapper carries that attr too.
    const itemId = resolveTargetItemId(event, detail, 'itemId');
    const cardType = 'NO'
    ElysiumCheck._trigger({
      rollType: 'IM',
      cardType,
      itemId,
      actor: actor,
      token: actor.token
    })
  }

  //Start Weapon Skill Roll
  static async _onWeaponRoll(event, detail, actor) {
    // F13 (rc.6): weapon-row carries BOTH data-item-id (the weapon doc id) and
    // data-skill-id (the source skill id). Resolve each separately.
    const itemId = resolveTargetItemId(event, detail, 'itemId');
    const skillId = resolveTargetItemId(event, detail, 'skillId');
    let shiftKey = event.shiftKey
    let rollType = 'CM'
    let cardType = 'CB'
    if (game.settings.get('elysium', 'quickCombat') && shiftKey) {
      rollType = 'QC'
      cardType = "NO"
      shiftKey = false
    } else if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    ElysiumCheck._trigger({
      rollType,
      cardType,
      itemId,
      skillId,
      shiftKey: shiftKey,
      actor: actor,
      token: actor.token
    })
  }

  //Armor Rolling when using variable armor
  static async _onArmor(event, detail, actor) {
    const prop = detail.property
    let AVform = ""
    let label = ""
    switch (prop) {
      case "cap":
        AVform = actor.system.avr1
        label = game.i18n.localize('Elysium.armor')
        break
      // v0.21.0: 'cbap' case (ballistic armor, actor-level) removed.
      // Elysium replaces BRP-classic ballistic armor with the
      // material × stratum damage-bucket system (see armor-vs-damage.mjs).
      case "ap":
        const item = actor.items.get(detail.itemId)
        // v0.21.0: shift-for-ballistic branch removed for same reason.
        AVform = item.system.avr1
        label = item.name + ": " + game.i18n.localize('Elysium.armor')
        break
      case "nap":
        // v0.21.0: 'nbap' case removed alongside other ballistic-armor
        // paths.
        // F13 (rc.6): hit-location-row puts data-item-id on the row wrapper;
        // the clicked <a data-action="armorRoll" data-property="nap"> doesn't
        // have its own id. Resolve via helper.
        const hitLocId = resolveTargetItemId(event, detail, 'itemId')
        const hitLoc = actor.items.get(hitLocId)
        AVform = hitLoc.system.apRnd
        label = hitLoc.name + ": " + game.i18n.localize('Elysium.armor')
        break
      case "ncap":
        AVform = actor.system.apRnd
        label = game.i18n.localize('Elysium.armor')
        break
      // v0.21.0: 'ncbap' case removed alongside other ballistic-armor paths.
      default:
        return
    }
    //If the Armor Value is blank then don't make the roll

    if (AVform === "") { return }
    ElysiumCheck._trigger({
      rollType: 'AR',
      cardType: 'NO',
      label,
      AVform,
      actor: actor,
      token: actor.token
    })
  }

}
