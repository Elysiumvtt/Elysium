/**
 * Mysticism casting (v0.9.0).
 *
 * Simplest of the four. Pipeline:
 *   1. Pre-flight: Focus skill exists?
 *   2. AP and PP payment (overcast→fatigue if low)
 *   3. Focus roll (resistance value only — feat takes effect by default).
 *   4. Effect application; chat card.
 */

import { payPP, spendAP, rollD100, postCastCard, classifyRoll, findSkill } from './cast-shared.mjs'
export async function castMysticism (actor, feat) {
  // Step 1: find Focus skill.
  let focusSkill = findSkill(actor, { name: 'Focus' })
  if (!focusSkill) focusSkill = findSkill(actor, { subgroup: 'mysticism' })
  if (!focusSkill) {
    ui.notifications?.warn(
      `${actor.name} has no Focus skill. Drag it from the Skills compendium first.`)
    return
  }
  const skillTotal = focusSkill.system?.total ?? focusSkill.system?.base ?? 0

  // Step 2: AP + PP.
  const apCost = feat.system?.elysium?.apCost ?? 1
  if (apCost > 0) {
    const ok = await spendAP(actor, apCost)
    if (!ok) return
  }

  const ppCost = feat.system?.elysium?.powerCost ?? Number(feat.system?.pppl ?? 1)
  const ppResult = await payPP(actor, ppCost, true)
  if (ppResult.fizzled) {
    ui.notifications?.warn(`${actor.name} could not pay PP cost. Feat fizzled.`)
    return
  }

  // Step 3: Focus roll (resistance only).
  // Focus is modified by tier above 1: -10% per tier above 1 per design.
  const tier = feat.system?.elysium?.tier ?? 1
  const tierPenalty = (tier - 1) * 10
  const effectiveSkill = Math.max(0, skillTotal - tierPenalty)
  const { value: rollValue } = await rollD100()
  classifyRoll(effectiveSkill, rollValue)

  await postCastCard({
    casterDoc: actor,
    casterName: actor.name,
    spellId: feat.id,
    spellName: feat.name,
    tradition: 'mysticism',
    schoolName: feat.system?.elysium?.discipline ?? '',
    schoolSkillName: focusSkill.name,
    schoolSkillTotal: effectiveSkill,
    tier,
    tierPenalty,
    completed: true,
    finalRoll: rollValue,
    resistanceValue: rollValue,
    saveSkill: feat.system?.elysium?.saveSkill ?? '',
    apSpent: apCost,
    ppSpent: ppResult.ppSpent,
    fatigueAdded: ppResult.fatigueAdded,
    description: feat.system?.description ?? '',
  })
}
