// Shared helpers used by sheet-extension submodules — particularly the
// item-modifier and effects-tab injections which need to display or transform
// Foundry Active Effect mode constants.
//
// Extracted from module/elysium/sheets/sheet-extension.mjs in v0.21.0,
// where these lived as module-scope helpers. Centralised here so multiple
// extracted submodules (item-modifiers, effects-tab) can share them.

/**
 * Convert a Foundry AE mode constant to the preset string we use in the UI.
 */
export function modeConstToPresetSheet (modeConst) {
  const T = CONST.ACTIVE_EFFECT_CHANGE_TYPES
  switch (modeConst) {
    case T.ADD:       return 'ADD'
    case T.MULTIPLY:  return 'MULTIPLY'
    case T.OVERRIDE:  return 'OVERRIDE'
    case T.UPGRADE:   return 'UPGRADE'
    case T.DOWNGRADE: return 'DOWNGRADE'
    default:          return 'ADD'
  }
}

/**
 * Pretty label for a Foundry AE mode constant (for display).
 */
export function aeModeLabel (modeConst) {
  const T = CONST.ACTIVE_EFFECT_CHANGE_TYPES
  switch (modeConst) {
    case T.ADD:       return 'Add'
    case T.MULTIPLY:  return 'Multiply'
    case T.OVERRIDE:  return 'Override'
    case T.UPGRADE:   return 'Upgrade'
    case T.DOWNGRADE: return 'Downgrade'
    default:          return 'Add'
  }
}

/**
 * Tiny dialog asking the user for a free-form Attribute Key string.
 * Returns the trimmed string, or null if the user cancelled.
 */
export async function promptAttributeKey () {
  // DialogV2.wait resolves with the per-button callback's return value, or
  // null on window-close (rejectClose:false).
  const result = await foundry.applications.api.DialogV2.wait({
    window: { title: 'Custom Modifier Attribute Key' },
    content: `
      <p>Enter the Foundry Attribute Key this modifier should target.</p>
      <p style="font-size:0.9em;color:#666;">Examples:
        <code>flags.elysium.modifiers.castingPenalty</code>,
        <code>system.stats.str.effects</code>,
        <code>flags.elysium.modifiers.weaponDamageDice</code></p>
      <input type="text" name="attrKey" style="width:100%;"
             placeholder="flags.elysium.modifiers.something">
    `,
    buttons: [
      { action: 'ok', label: 'Add', default: true,
        callback: (event, button, dialog) => {
          const v = dialog.element.querySelector('input[name="attrKey"]')?.value?.trim()
          return v || null
        }},
      { action: 'cancel', label: 'Cancel' },
    ],
    rejectClose: false,
  })
  // 'ok' callback returns the trimmed string or null; cancel/close → null.
  if (typeof result === 'string') return result
  return null
}

/**
 * HTML-escape a string for safe interpolation into an HTML template.
 * Used by the v0.12.0 themed-ability injection methods which build
 * markup from user-controlled text fields (add-on names, descriptions,
 * end-condition lines).
 */
export function escapeHtml (s) {
  if (s == null) return ''
  const str = String(s)
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}
