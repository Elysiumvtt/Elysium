import { ElysiumDragDropItemSheet } from './base-dragdrop-item-sheet.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumUtilities } from '../../apps/utilities.mjs'

/**
 * Skill item sheet — P10 cluster 5 / alpha.43 rewrite.
 *
 * Inherits from ElysiumDragDropItemSheet (cluster-3b intermediate) to
 * reuse drag/drop boilerplate + collection management. Two display modes
 * driven by `system.group`:
 *
 *  - Single-skill mode (group=false): standard skill with options chips,
 *    stat formula (if variable=true), and score breakdown.
 *  - Group-container mode (group=true): a meta-skill that gathers other
 *    skills into a `groupSkills` array. Shows only the options chip row
 *    + the dropped-skills list with a `.droppable` zone.
 *
 * Header is already on the v1.0.0 specialism-aware partial (cluster-3b,
 * c3b-4): `parts/item-shell-header-specialism.hbs` — preserves the
 * mainName / specName split when system.specialism is true.
 *
 * Header chips per c5-3: Skill Group / Category / Subgroup.
 * Flag chips: 7 option toggles (noXP / specialism / variable / group /
 * basic / chosen / combat). All flat property paths.
 *
 * Overrides from base:
 *  - `_onDrop` — skill-unique group-check + dup-detection routes drops to
 *    `groupSkills` (not the personality/culture `skills` collection).
 *    Group-typed skills can't be added to other group containers.
 *  - `_onItemDelete` — operates on `groupSkills` (not the personality
 *    base default `skills`).
 *  - `_onItemView` — resolves dropped row via `data-elysiumid` (not the
 *    base default uuid path).
 *
 * Form handler `mySkillHandler` preserved unchanged from legacy — composes
 * `item.name` from `mainName` + `(specName)` when specialism toggled,
 * and rehydrates the `groupSkills` array across form submits to avoid
 * the formData empty-array problem.
 */
export class ElysiumSkillSheet extends ElysiumDragDropItemSheet {

  static DEFAULT_OPTIONS = {
    classes: ['skill'],
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }],
    position: { width: 560, height: 720 },
    form: { handler: ElysiumSkillSheet.mySkillHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header-specialism.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    details:     {
      template:  'systems/elysium/templates/item/skill.detail.hbs',
      scrollable: [''],
    },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'details', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const sys = this.item.system

    context.pcOwner = !!(context.hasOwner && this.item.parent?.type === 'character')

    // Option maps
    context.statOptions     = await ElysiumSelectLists.getStatOptions()
    context.catOptions      = await ElysiumSelectLists.getCategoryOptions()
    context.wpnOptions      = await ElysiumSelectLists.getWpnCategoryOptions()
    context.funcOptions     = await ElysiumSelectLists.getFunctionalOptions()

    // v0.19.1: subgroup dropdown for magic-tradition grouping on the
    // character sheet's Skills tab.
    context.subgroupOptions = {
      '':          '— (no subgroup)',
      'arcane':    'Arcane School',
      'sorcery':   'Sorcery Essence',
      'divine':    'Divine',
      'mysticism': 'Mysticism',
    }
    // v0.19.3: top-level skill group dropdown (Standard/Career/Combat/Magic).
    context.skillGroupOptions = {
      'standard': 'Standard',
      'career':   'Career',
      'combat':   'Combat',
      'magic':    'Magic',
    }
    context.skillCategoryOptions = {
      '':         '— (uncategorised)',
      'standard': 'Standard',
      'career':   'Career',
      'combat':   'Combat',
      'magic':    'Magic',
    }

    // Stat-formula display names
    context.stat1     = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[sys.baseFormula[1].stat])
    context.stat2     = game.i18n.localize(CONFIG.Elysium.statsAbbreviations[sys.baseFormula[2].stat])
    context.catName   = game.i18n.localize('Elysium.' + sys.category)
    context.wpnType   = game.i18n.localize('Elysium.' + sys.subType)
    context.funcDisp  = game.i18n.localize('Elysium.' + sys.baseFormula.Func)
    context.subgroupName = context.subgroupOptions[sys.elysium?.skillSubgroup] || '—'
    context.skillGroupName = context.skillGroupOptions[sys.elysium?.skillCategory] || '—'

    // Ensure mainName is populated (one-time legacy migration)
    if (sys.mainName === '') {
      this.item.update({ 'system.mainName': this.item.name })
    }

    // Resolve dropped group-skills into displayable rows
    const grpSkill = []
    for (const skill of sys.groupSkills) {
      const tempSkill = (await game.system.api.elysiumid.fromElysiumIDBest({
        elysiumid: skill.elysiumid,
      }))[0]
      if (tempSkill) {
        grpSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: tempSkill.name,
          category: tempSkill.system.category,
          variable: tempSkill.system.variable,
          base: tempSkill.system.base,
          group: tempSkill.system.group,
        })
      } else {
        grpSkill.push({
          uuid: skill.uuid,
          elysiumid: skill.elysiumid,
          name: game.i18n.localize('Elysium.invalid'),
          category: '', variable: '', base: '', group: '',
        })
      }
    }
    context.grpSkill = grpSkill.sort(ElysiumUtilities.sortByNameKey)

    // Total score for owned skills (vestigial-summing; P12 to move into DataModel)
    context.totalScore = (sys.base ?? 0) + (sys.xp ?? 0) + (sys.effects ?? 0)
                       + (sys.personality ?? 0) + (sys.career ?? 0)
                       + (sys.personal ?? 0) + (sys.culture ?? 0)

    // Header chips per c5-3 (3 chips)
    context.itemHeaderChips = [
      {
        label: game.i18n.localize('Elysium.skillGroup'),
        value: context.skillGroupName,
      },
      {
        label: game.i18n.localize('Elysium.category'),
        value: context.catName,
      },
      {
        label: game.i18n.localize('Elysium.subgroup'),
        value: context.subgroupName,
      },
    ]

    // Flag chips per c5-3 (7 toggles). Flat property paths.
    // Some chips are conditionally visible — template handles visibility
    // via the chip-row partial walking the array.
    const flagDefs = [
      ['noXP',       'Elysium.noXP',       'Elysium.noXPHint'],
      ['specialism', 'Elysium.specialism', 'Elysium.specialismHint'],
      ['variable',   'Elysium.variable',   'Elysium.variableHint'],
      ['group',      'Elysium.group',      'Elysium.groupHint'],
      ['combat',     'Elysium.combatSkill','Elysium.combatSkillHint'],
    ]
    // basic only visible when NOT group; chosen only when specialism
    if (!sys.group) flagDefs.splice(4, 0, ['basic', 'Elysium.basic', 'Elysium.basicHint'])
    if (sys.specialism) flagDefs.splice(4, 0, ['chosen', 'Elysium.chosen', 'Elysium.chosenHint'])

    context.flagChips = flagDefs.map(([prop, labelKey, tipKey]) => ({
      property:     prop,
      propertyPath: `system.${prop}`,
      active:       !!sys[prop],
      label:        game.i18n.localize(labelKey),
      tooltip:      tipKey ? game.i18n.localize(tipKey) : null,
    }))

    return context
  }

  // -----------------------------------------------------------------
  // _onDrop — skill-specific group-check + dup-detection.
  // Routes drops to `groupSkills`. Group-typed skills cannot be
  // added to another group container.
  // -----------------------------------------------------------------
  async _onDrop(event, type = 'skill', collectionName = 'groupSkills') {
    event.preventDefault()
    event.stopPropagation()

    const dataList = await ElysiumUtilities.getDataFromDropEvent(event, 'Item')
    const collection = this.item.system[collectionName]
      ? foundry.utils.duplicate(this.item.system[collectionName])
      : []

    for (const item of dataList) {
      if (!item || !item.system) continue
      if (![type].includes(item.type)) continue

      // F10 (rc.2) defensive guard — see career.mjs for rationale.
      if (!item.flags?.elysium?.elysiumidFlag?.id) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      // Group-typed skills can't nest into another group container
      if ((item.system.specialism && item.system.chosen) || !item.system.specialism) {
        if (item.system.group) {
          ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.stopGroupSkill'))
          continue
        }
        if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
          ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
          continue
        }
      }
      collection.push({
        uuid: item.uuid,
        elysiumid: item.flags.elysium.elysiumidFlag.id,
      })
    }

    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  // -----------------------------------------------------------------
  // _onItemDelete override — operates on `groupSkills` (not the base
  // class default `skills`). Same widened selector as the base.
  // -----------------------------------------------------------------
  async _onItemDelete(event) {
    return super._onItemDelete(event, 'groupSkills')
  }

  // -----------------------------------------------------------------
  // _onItemView override — resolve dropped row by elysiumid lookup
  // (the base class default uses uuid; skill stores both but elysiumid
  // is canonical for skills).
  // -----------------------------------------------------------------
  async _onItemView(event) {
    const row = event.currentTarget.closest('[data-elysiumid]')
    if (!row) return
    const elysiumid = row.dataset.elysiumid
    const tempItem = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid }))[0]
    if (tempItem) tempItem.sheet.render(true)
  }

  // -----------------------------------------------------------------
  // FORM HANDLER — preserved unchanged from legacy. Composes
  // `item.name` from mainName + (specName) when specialism is true,
  // and rehydrates groupSkills across form submits.
  // -----------------------------------------------------------------
  static async mySkillHandler(event, form, formData) {
    const skillName = formData.object['system.mainName'] || this.item.system.mainName
    if (this.item.system.specialism) {
      const spec = formData.object['system.specName'] || this.item.system.specName
      formData.object.name = skillName + ' (' + spec + ')'
    } else {
      formData.object.name = skillName
    }
    // Preserve groupSkills array (legacy rehydration pattern)
    const system = foundry.utils.expandObject(formData.object)?.system
    if (typeof system !== 'undefined') {
      if (system.groupSkills === undefined) {
        formData.object['system.groupSkills'] = foundry.utils.duplicate(
          this.item.system.groupSkills,
        )
      }
    }
    await this.document.update(formData.object)
  }
}
