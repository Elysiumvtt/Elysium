import { ElysiumDragDropItemSheet } from './base-dragdrop-item-sheet.mjs'
import { ElysiumSelectLists } from '../../apps/select-lists.mjs'
import { ElysiumUtilities } from '../../apps/utilities.mjs'

/**
 * Career item sheet — P10 cluster 6 / alpha.44 rewrite. CLOSES P10.
 *
 * Extends cluster-3b's ElysiumDragDropItemSheet to inherit 8 drag/drop
 * methods + 4 collection-management methods + the imperative listener
 * wiring in `_onRender`. Removes ~248 LOC of duplicated boilerplate.
 *
 * Structurally a personality++ sheet: main skill list + optional skill
 * groups + ADD: main powers list (3rd drop target) + wealth bracket.
 *
 * Three drop-target routing branches in `_onDrop`:
 *   - `.optional-skills` → group skills (per-group dup-detect)
 *   - `.main-powers`     → powers collection (powers-only items)
 *   - else               → main skills collection (with remove-from-groups)
 *
 * Powers delete uses a third collection (`powers`), which the base class
 * doesn't know about — sub-class adds `_onPowersDelete` + extends `_onRender`
 * to also bind `.item-power-delete` to it.
 *
 * Header chips per c6-5: Min Wealth / Max Wealth / Tier.
 *
 * TAB_ORDER = ['header','tabs','skills','powers','wealth','description','gmNotes']
 * — 3 distinct content tabs (skills/powers/wealth) per c6-2 (not consolidated).
 *
 * Form handler `myCareerHandler` preserved + adds powers-array rehydration
 * (c6-11 defensive cleanup) to match groups-array rehydration pattern.
 */
export class ElysiumCareerSheet extends ElysiumDragDropItemSheet {

  static DEFAULT_OPTIONS = {
    classes: ['career'],
    dragDrop: [{ dragSelector: '[data-drag]', dropSelector: '.droppable' }],
    position: { width: 560, height: 720 },  // standard tier per c6-4
    form: { handler: ElysiumCareerSheet.myCareerHandler },
  }

  static PARTS = {
    header:      { template: 'systems/elysium/templates/item/parts/item-shell-header.hbs' },
    tabs:        { template: 'systems/elysium/templates/item/parts/item-shell-tabs.hbs' },
    skills:      {
      template:  'systems/elysium/templates/item/career.skills.hbs',
      scrollable: [''],
    },
    powers:      {
      template:  'systems/elysium/templates/item/career.powers.hbs',
      scrollable: [''],
    },
    wealth:      { template: 'systems/elysium/templates/item/career.wealth.hbs' },
    description: { template: 'systems/elysium/templates/item/parts/item-shell-description.hbs' },
    gmNotes:     { template: 'systems/elysium/templates/item/parts/item-shell-gmnotes.hbs' },
  }

  static TAB_ORDER = ['header', 'tabs', 'skills', 'powers', 'wealth', 'description', 'gmNotes']

  async _prepareContext(options) {
    const context = await super._prepareContext(options)
    const sys = this.item.system

    // Option maps for the 2 wealth selects
    context.minWealthOptions = await ElysiumSelectLists.getWealthOptions(0, 4)
    context.maxWealthOptions = await ElysiumSelectLists.getWealthOptions(sys.minWealth, 4)
    context.minWealthName    = game.i18n.localize('Elysium.wealthLevel.' + sys.minWealth)
    context.maxWealthName    = game.i18n.localize('Elysium.wealthLevel.' + sys.maxWealth)

    // Resolve skill + group-skill + power references into displayable rows
    const perSkill = []
    const grpSkill = []
    const perPower = []
    for (const skill of sys.skills) {
      const t = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: skill.elysiumid }))[0]
      if (t) {
        perSkill.push({
          uuid: skill.uuid, elysiumid: skill.elysiumid,
          name: t.name, category: t.system.category,
          variable: t.system.variable, base: t.system.base, group: t.system.group,
        })
      } else {
        perSkill.push({
          uuid: skill.uuid, elysiumid: skill.elysiumid,
          name: game.i18n.localize('Elysium.invalid'),
          category: '', variable: '', base: '', group: '',
        })
      }
    }
    for (let index = 0; index < sys.groups.length; index++) {
      for (const skill of sys.groups[index].skills) {
        const t = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: skill.elysiumid }))[0]
        if (t) {
          grpSkill.push({
            uuid: skill.uuid, elysiumid: skill.elysiumid,
            name: t.name, category: t.system.category,
            variable: t.system.variable, base: t.system.base, group: t.system.group,
            index: index,
          })
        } else {
          grpSkill.push({
            uuid: skill.uuid, elysiumid: skill.elysiumid,
            name: game.i18n.localize('Elysium.invalid'),
            category: '', variable: '', base: '', group: '',
            index: index,
          })
        }
      }
    }
    for (const power of sys.powers) {
      const t = (await game.system.api.elysiumid.fromElysiumIDBest({ elysiumid: power.elysiumid }))[0]
      if (t) {
        perPower.push({ uuid: power.uuid, elysiumid: power.elysiumid, name: t.name })
      } else {
        perPower.push({
          uuid: power.uuid, elysiumid: power.elysiumid,
          name: game.i18n.localize('Elysium.invalid'),
        })
      }
    }
    context.perSkill = perSkill.sort(ElysiumUtilities.sortByNameKey)
    context.grpSkill = grpSkill.sort(ElysiumUtilities.sortByNameKey)
    context.perPower = perPower.sort(ElysiumUtilities.sortByNameKey)

    // Tier display name (basic / journeyman / etc.)
    context.tierName = game.i18n.localize('Elysium.careerTier.' + (sys.elysium?.tier || 'basic'))

    // Header chips per c6-5 (3 chips)
    context.itemHeaderChips = [
      { label: game.i18n.localize('Elysium.minWealth'), value: context.minWealthName },
      { label: game.i18n.localize('Elysium.maxWealth'), value: context.maxWealthName },
      { label: game.i18n.localize('Elysium.tier'),      value: context.tierName },
    ]

    return context
  }

  /**
   * Extend base `_onRender` to also bind `.item-power-delete` to
   * `_onPowersDelete` — the base only knows about `.item-delete`
   * (main collection) and `.group-item-delete` (groups). Powers is
   * career's 3rd collection per c6-7/c6-10.
   */
  _onRender(context, options) {
    super._onRender(context, options)
    this.element.querySelectorAll('.item-power-delete')
      .forEach(n => n.addEventListener('click', this._onPowersDelete.bind(this)))
  }

  // -----------------------------------------------------------------
  // _onDrop — 3-target routing preserved verbatim from legacy.
  // Routes to `groups[index].skills` / `powers` / `skills` collections.
  // -----------------------------------------------------------------
  async _onDrop(event, type = 'skill', collectionName = 'skills') {
    event.preventDefault()
    event.stopPropagation()

    const optionalSkill = event?.currentTarget?.classList?.contains('optional-skills')
    const mainPowers = event?.currentTarget?.classList?.contains('main-powers')
    if (mainPowers) {
      type = 'power'
      collectionName = 'powers'
    }
    const ol = event?.currentTarget?.closest('ol')
    const index = ol?.dataset?.group
    const dataList = await ElysiumUtilities.getDataFromDropEvent(event, 'Item')
    const collection = this.item.system[collectionName]
      ? foundry.utils.duplicate(this.item.system[collectionName])
      : []
    const groups = this.item.system.groups
      ? foundry.utils.duplicate(this.item.system.groups)
      : []

    for (const item of dataList) {
      if (!item || !item.system) continue
      if (![type].includes(item.type)) continue

      // F10 (rc.2) defensive guard. Skip items lacking ElysiumID metadata
      // rather than throwing during career group/skill management. Items
      // dropped on the career sheet must have ElysiumID metadata to be
      // assignable to a career — without it, no resolution path exists.
      if (!item.flags?.elysium?.elysiumidFlag?.id) {
        ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
        continue
      }

      if (optionalSkill) {
        // Dropping in Optional Skill Group
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          if (groups[index].skills.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
        }
        groups[index].skills = groups[index].skills.concat({
          uuid: item.uuid,
          elysiumid: item.flags.elysium.elysiumidFlag.id,
        })
      } else if (mainPowers) {
        // Dropping in Main Powers list
        if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
          ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
          continue
        }
        collection.push({ uuid: item.uuid, elysiumid: item.flags.elysium.elysiumidFlag.id })
      } else {
        // Dropping in Main Skill list — also remove from any groups
        if ((item.system.specialism && item.system.chosen) || (!item.system.specialism && !item.system.group)) {
          if (collection.find(el => el.elysiumid === item.flags.elysium.elysiumidFlag.id)) {
            ui.notifications.warn(item.name + ' : ' + game.i18n.localize('Elysium.dupItem'))
            continue
          }
          for (let i = 0; i < groups.length; i++) {
            const idx = groups[i].skills.findIndex(
              el => el.elysiumid === item.flags.elysium.elysiumidFlag.id,
            )
            if (idx !== -1) groups[i].skills.splice(idx, 1)
          }
        }
        collection.push({ uuid: item.uuid, elysiumid: item.flags.elysium.elysiumidFlag.id })
      }
    }
    await this.item.update({ 'system.groups': groups })
    await this.item.update({ [`system.${collectionName}`]: collection })
  }

  // -----------------------------------------------------------------
  // _onPowersDelete — sub-class addition per c6-7/c6-10. Uses widened
  // `[data-item-id]` selector pattern from cluster 3b (NOT legacy
  // `.closest('.item')`).
  // -----------------------------------------------------------------
  async _onPowersDelete(event) {
    event.preventDefault()
    event.stopImmediatePropagation()
    const row = event.currentTarget.closest('[data-item-id]')
    if (!row) return
    const itemId = row.dataset.itemId
    const list = this.item.system.powers
    if (!Array.isArray(list)) return
    const itemIndex = list.findIndex(i => itemId && i.uuid === itemId)
    if (itemIndex < 0) return
    const collection = foundry.utils.duplicate(list)
    collection.splice(itemIndex, 1)
    await this.item.update({ 'system.powers': collection })
  }

  // -----------------------------------------------------------------
  // FORM HANDLER — preserved from legacy + adds powers array rehydration
  // per c6-11 (defensive: form submits don't preserve array shape;
  // matches the groups-array rehydration pattern).
  // -----------------------------------------------------------------
  static async myCareerHandler(event, form, formData) {
    const system = foundry.utils.expandObject(formData.object)?.system
    if (typeof system !== 'undefined') {
      if (system.groups) {
        formData.object['system.groups'] = Object.values(system.groups || [])
        for (let index = 0; index < this.item.system.groups.length; index++) {
          formData.object[`system.groups.${index}.skills`] = foundry.utils.duplicate(
            this.item.system.groups[index].skills,
          )
        }
      }
      // Powers rehydration (c6-11)
      if (system.powers === undefined) {
        formData.object['system.powers'] = foundry.utils.duplicate(this.item.system.powers)
      }
    }
    await this.document.update(formData.object)
  }
}
