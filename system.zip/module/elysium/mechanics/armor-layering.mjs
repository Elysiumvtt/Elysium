/**
 * Armor-layering rules — extracted from register-hooks.mjs in v0.21.0.
 *
 * These are the pure-function rule checks for Elysium's armor-layering
 * system. The hook layer (`module/elysium/hooks/register-hooks.mjs`,
 * `_onPreUpdateItem`) imports `checkArmorLayerConflict` and calls it
 * when an armor item transitions to `equipStatus === 'equipped'`.
 *
 * The rule model (Elysium house rules, see armor catalog in
 * `compendium/packs/armor.db` and `module/elysium/config/config.mjs`
 * `ARMOR_WORN_STRATA`):
 *
 *   - **Natural** layer (e.g. dragon hide built into the creature):
 *     never conflicts with anything. Stacks freely.
 *   - **Worn** layer: at most one piece per stratum per location.
 *     - Soft (cloth/leather/hide): max 2 AP per piece
 *     - Mail (chain/scale): max 3 AP per piece
 *     - Plate (rigid): max 5 AP per piece
 *     - Total AP across all strata capped at WORN_AP_CAP_PER_LOCATION (10)
 *   - **Magical** layer (e.g. Cloak of Resistance): at most one magical
 *     piece per location, but stacks freely with any worn pieces.
 *
 * Legacy data without explicit `layer` or `wornStratum` infers from
 * `flexibility`: 'natural' → natural; 'inflexible' → plate worn;
 * anything else → soft worn.
 */

import { ELYSIUM } from '../config/config.mjs'

/**
 * Resolve the armor layer (natural / worn / magical) for a piece.
 * Reads system.elysium.layer if explicit; otherwise infers from flexibility.
 *
 * @param {Item} item — an armor item
 * @returns {'natural' | 'worn' | 'magical'}
 */
export function resolveArmorLayer (item) {
  const ely = item.system?.elysium
  if (ely?.layer) return ely.layer
  if (ely?.flexibility === 'natural') return 'natural'
  return 'worn'
}

/**
 * Resolve the worn-armor stratum (soft / mail / plate) for a piece.
 * Reads system.elysium.wornStratum if explicit; otherwise infers from
 * flexibility: flexible → soft, inflexible → plate, anything else → soft.
 *
 * @param {Item} item — an armor item
 * @returns {'soft' | 'mail' | 'plate'} (stratum identifier from
 *   `ELYSIUM.ARMOR_WORN_STRATA`)
 */
export function resolveWornStratum (item) {
  const ely = item.system?.elysium
  if (ely?.wornStratum) return ely.wornStratum
  if (ely?.flexibility === 'inflexible') return 'plate'
  return 'soft'
}

/**
 * Validate that equipping `item` doesn't violate Elysium's armor-layering
 * rules. Returns null if the equip is OK, or a user-facing message string
 * if blocked.
 *
 * The hook layer should call this when an armor item's `equipStatus`
 * transitions to 'equipped', surface the returned string via
 * `ui.notifications.warn`, and cancel the update.
 *
 * Skipped when the item has no `hitlocID` (unbound to a hit-location).
 * Natural-layer pieces always pass. For magical pieces, only one per
 * location is allowed. For worn pieces, the per-stratum uniqueness check,
 * the per-stratum AP cap, and the total-AP cap are all enforced.
 *
 * @param {Item} item — an armor item being equipped
 * @returns {string | null}
 */
export function checkArmorLayerConflict (item) {
  const actor = item.parent
  const hitlocID = item.system?.hitlocID
  if (!hitlocID) return null    // no location specified — skip

  const layer = resolveArmorLayer(item)
  const stratum = resolveWornStratum(item)
  const locName = actor.items.get(hitlocID)?.name || 'this location'

  // Natural never conflicts
  if (layer === 'natural') return null

  // Find all other worn armor on the same hit-location
  const others = actor.items.filter(o =>
    o.id !== item.id &&
    o.type === 'armor' &&
    o.system?.equipStatus === 'equipped' &&
    o.system?.hitlocID === hitlocID
  )

  // Magical: at most one magical-layer piece per location
  if (layer === 'magical') {
    const otherMagical = others.find(o => resolveArmorLayer(o) === 'magical')
    if (otherMagical) {
      return `Cannot wear "${item.name}" — "${otherMagical.name}" is already worn `
           + `as magical armor on ${locName}. Only one magical piece per location.`
    }
    return null
  }

  // Worn layer: enforce per-stratum uniqueness, per-stratum AP cap, and total cap
  const otherWorn = others.filter(o => resolveArmorLayer(o) === 'worn')

  // Stratum collision check
  const stratumConflict = otherWorn.find(o => resolveWornStratum(o) === stratum)
  if (stratumConflict) {
    const stratumLabel = ELYSIUM.ARMOR_WORN_STRATA[stratum]?.label || stratum
    return `Cannot wear "${item.name}" — "${stratumConflict.name}" is already worn `
         + `as ${stratumLabel} armor on ${locName}. Only one ${stratumLabel.toLowerCase()} `
         + `piece per location is allowed.`
  }

  // Per-stratum AP cap: a single piece's AP can't exceed its stratum's max
  // (Soft 2, Mail 3, Plate 5 — totalling 10 per location).
  const newAP = Number(item.system?.av1) || 0
  const stratumDef = ELYSIUM.ARMOR_WORN_STRATA[stratum]
  if (stratumDef && newAP > stratumDef.maxAP) {
    return `Cannot wear "${item.name}" — its ${newAP} AP exceeds the `
         + `${stratumDef.maxAP} AP cap for ${stratumDef.label.toLowerCase()} armor. `
         + `Reduce the piece's AP or change its stratum.`
  }

  // Total worn AP cap across all strata on this location
  const existingAP = otherWorn.reduce((sum, o) => sum + (Number(o.system?.av1) || 0), 0)
  if (existingAP + newAP > ELYSIUM.WORN_AP_CAP_PER_LOCATION) {
    return `Cannot wear "${item.name}" — would exceed the `
         + `${ELYSIUM.WORN_AP_CAP_PER_LOCATION} AP cap on ${locName} `
         + `(${existingAP} already + ${newAP} new = ${existingAP + newAP}).`
  }

  return null
}
