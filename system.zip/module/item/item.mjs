import { ElysiumCheck } from '../apps/check.mjs'
import { isCtrlKey } from '../apps/helper.mjs'
import { ElysiumID } from '../elysiumid/elysiumid.mjs'

export class ElysiumItem extends Item {
  constructor(data, context) {
    if (typeof data.img === 'undefined') {
      if (data.type === 'powerMod') {
        data.img = 'systems/elysium/assets/Icons/broken-shield.svg'
      } else if (data.type === 'failing') {
        data.img = 'systems/elysium/assets/Icons/drama-masks.svg'
      } else if (data.type === 'hit-location') {
        data.img = 'systems/elysium/assets/Icons/arm-bandage.svg'
      } else if (data.type === 'arcane') {
        data.img = 'systems/elysium/assets/Icons/scroll-unfurled.svg'
      } else if (data.type === 'mutation') {
        data.img = 'systems/elysium/assets/Icons/dna1.svg'
      } else if (data.type === 'personality') {
        data.img = 'systems/elysium/assets/Icons/inner-self.svg'
      } else if (data.type === 'divine') {
        data.img = 'systems/elysium/assets/Icons/lightning-helix.svg'
      } else if (data.type === 'career') {
        data.img = 'systems/elysium/assets/Icons/blacksmith.svg'
      } else if (data.type === 'mysticism') {
        data.img = 'systems/elysium/assets/Icons/suspicious.svg'
      } else if (data.type === 'skill') {
        data.img = 'systems/elysium/assets/Icons/skills.svg'
      } else if (data.type === 'sorcery') {
        data.img = 'systems/elysium/assets/Icons/bolt-spell-cast.svg'
      } else if (data.type === 'powerMod') {
        data.img = 'systems/elysium/assets/Icons/broken-shield.svg'
      } else if (data.type === 'super') {
        data.img = 'systems/elysium/assets/Icons/deadly-strike.svg'
      } else if (data.type === 'armor') {
        data.img = 'systems/elysium/assets/Icons/lamellar.svg'
      } else if (data.type === 'gear') {
        data.img = 'systems/elysium/assets/Icons/knapsack.svg'
      } else if (data.type === 'weapon') {
        data.img = 'systems/elysium/assets/Icons/saber-and-pistol.svg'
      } else if (data.type === 'wound') {
        data.img = 'systems/elysium/assets/Icons/drop.svg'
      } else if (data.type === 'allegiance') {
        data.img = 'systems/elysium/assets/Icons/all-seeing-eye.svg'
      } else if (data.type === 'passion') {
        data.img = 'systems/elysium/assets/Icons/shining-heart.svg'
      } else if (data.type === 'persTrait') {
        data.img = 'systems/elysium/assets/Icons/scales.svg'
      } else if (data.type === 'reputation') {
        data.img = 'systems/elysium/assets/Icons/throne-king.svg'
      } else if (data.type === 'skillcat') {
        data.img = 'systems/elysium/assets/Icons/classical-knowledge.svg'
      } else if (data.type === 'culture') {
        data.img = 'systems/elysium/assets/Icons/earth-africa-europe.svg'
      }
    }
    super(data, context)
  }

  prepareData() {
    super.prepareData();
  }

  prepareDerivedData() {
    const itemData = this;
    const systemData = itemData.system;

    // v0.20.0: fixed Elysium terminology — label overrides removed.
    systemData.powerLabel       = game.i18n.localize('Elysium.pp')
    systemData.powerLabelAbbr   = game.i18n.localize('Elysium.ppShort')
    systemData.healthLabelAbbr  = game.i18n.localize('Elysium.hp')
  }

  getRollData() {
    if (!this.actor) return null;
    const rollData = this.actor.getRollData();
    rollData.item = foundry.utils.deepClone(this.system);
    return rollData;
  }

  async roll() {
    const item = this;
    const actor = this.actor;
    const altKey = event.altKey;
    const ctrlKey = isCtrlKey(event ?? false);
    let cardType = "NO";
    let rollType = ""
    let skillId = "";
    let itemId = "";
    let opp = 'false'
    let shiftKey = event.shiftKey;
    if (game.settings.get('elysium', 'switchShift')) {
      shiftKey = !shiftKey
    }
    switch (item.type) {
      case 'skill':
      case 'arcane':
      case 'mysticism':
        rollType = "SK"
        skillId = item._id
        if (ctrlKey) { cardType = 'OP' }
        if (altKey) { cardType = 'GR' }
        if (altKey & ctrlKey) { cardType='CO' }
        break
      case 'allegiance':
        rollType = "AL"
        skillId = item._id
        break
      case 'passion':
        rollType = "PA"
        if (ctrlKey) { cardType = 'OP' }
        skillId = item._id
        break
      case 'persTrait':
        rollType = "PT"
        if (ctrlKey) { cardType = 'OP' }
        if (altKey) { opp = 'true' }
        skillId = item._id
        break
      case 'weapon':
        rollType = "CM"
        itemId = item._id
        skillId = actor.items.get(itemId).system.sourceID
        break
      case 'reputation':
        rollType = "PA"
        if (ctrlKey) { cardType = 'OP' }
        if (altKey) { cardType = 'GR' }
        skillId = item._id
        break
      default:
        item.sheet.render(true);
        return
    }

    ElysiumCheck._trigger({
      rollType,
      cardType,
      skillId,
      itemId,
      shiftKey,
      actor,
      opp,
    })
  }

  //Add ElysiumIDs to newly created items
  static async createDocuments(data = [], context = {}) {
    if (context.keepEmbeddedIds === undefined) context.keepEmbeddedIds = false;
    const created = await super.createDocuments(data, context);

    //Add ElysiumID based on item name if the game setting is flagged.
    for (let item of created) {
      if (game.settings.get('elysium', "itemElysiumID")) {
        const tempID = await ElysiumID.guessId(item)
        if (tempID) {
          await item.update({ 'flags.elysium.elysiumidFlag.id': tempID })
          item.sheet.element?.querySelectorAll('header.window-header a.header-button.edit-elysiumid-warning, header.window-header a.header-button.edit-elysiumid-exisiting').forEach(el => {
            el.style.color = tempID ? 'orange' : 'red'
          })
          item.render()
        }
      }
    }
    return created
  }

  static async createDialog(data={}, createOptions={}, { types, ...options }={}) {
    //Enter the document types you want to remove from the side bar create option - 'base' is removed in the super
    const invalid = ["wound"];
    if (!types) types = this.TYPES.filter(type => !invalid.includes(type));
    else types = types.filter(type => !invalid.includes(type));
    return super.createDialog(data, createOptions, { types, ...options });
  }

  async _preDelete(options, user) {
    if (this.parent) {
      const ids = this.parent.effects.filter(e => e.origin === this.uuid).map(e => e.id)
      if (ids.length) {
        await this.parent.deleteEmbeddedDocuments('ActiveEffect', ids)
      }
    }
    return super._preDelete(options, user);
  }

  /** @override */
  static async _onCreateOperation(documents, operation, user) {
    super._onCreateOperation(documents, operation, user)
    /* Copied from FoundryVTT v12 item.js replacing Actor with ActorDelta */
    if ( !(operation.parent instanceof ActorDelta) || !CONFIG.ActiveEffect.legacyTransferral || !user.isSelf ) return;
    const cls = getDocumentClass("ActiveEffect");

    // Create effect data
    const toCreate = [];
    for ( let item of documents ) {
      for ( let e of item.effects ) {
        if ( !e.transfer ) continue;
        const effectData = e.toJSON();
        effectData.origin = item.uuid;
        toCreate.push(effectData);
      }
    }

    // Asynchronously create transferred Active Effects
    operation = {...operation};
    delete operation.data;
    operation.renderSheet = false;
    // noinspection ES6MissingAwait
    cls.createDocuments(toCreate, operation);
  }
}
