import { ElysiumCheck } from '../apps/check.mjs'
import { OPCard } from './opposed-card.mjs'
export class GRCard {

  //Add a new skill to a Combined Card
  static async GRAdd(config, msgId) {
    if (game.user.isGM) {
      const targetMsg = await game.messages.get(msgId)
      if ((targetMsg.flags.elysium.chatCard).length >= 5 && (targetMsg.flags.elysium.cardType === 'GR' || targetMsg.flags.elysium.cardType === 'CO')) {
        ui.notifications.warn(game.i18n.localize('Elysium.resolveMax'))
        return
      } else if ((targetMsg.flags.elysium.chatCard).length >= 2 && targetMsg.flags.elysium.cardType === 'OP') {
        ui.notifications.warn(game.i18n.localize('Elysium.resolveMax'))
        return
      }

      const newChatCards = targetMsg.flags.elysium.chatCard
      newChatCards.push(config.chatCard[0])
      await targetMsg.update({ 'flags.elysium.chatCard': newChatCards })
      const pushhtml = await ElysiumCheck.startChat(targetMsg.flags.elysium)
      await targetMsg.update({ content: pushhtml })
    } else {
      const availableGM = game.users.find(d => d.active && d.isGM)?.id
      if (availableGM) {
        game.socket.emit('system.elysium', {
          type: 'GRAdd',
          to: availableGM,
          value: { config, msgId }
        })
      } else {
        ui.notifications.warn(game.i18n.localize('Elysium.noAvailableGM'))
      }
    }
  }

  //Remove a skill from a combined card
  static async GRRemove(config) {
    const targetMsg = await game.messages.get(config.targetChatId)
    const rank = config.dataset.rank
    const newChatCards = targetMsg.flags.elysium.chatCard
    newChatCards.splice(rank, 1)
    await targetMsg.update({ 'flags.elysium.chatCard': newChatCards })
    return
  }

  //Resolve a combined card - roll dice, update and close
  static async GRResolve(config) {
    const targetMsg = await game.messages.get(config.targetChatId)
    const chatCards = targetMsg.flags.elysium.chatCard
    const cardType = targetMsg.flags.elysium.cardType
    if (chatCards.length < 2) {
      ui.notifications.warn(game.i18n.localize('Elysium.resolveMore'))
      return
    }

    const newchatCards = []
    const roll = new Roll(chatCards[0].rollFormula)
    await roll.evaluate()
    const rollResult = Number(roll.result)

    let diceRolled = ""
    for (let diceRoll = 0; diceRoll < roll.dice.length; diceRoll++) {
      for (let thisDice = 0; thisDice < roll.dice[diceRoll].values.length; thisDice++) {
        if (thisDice != 0 || diceRoll != 0) {
          diceRolled = diceRolled + ", "
        }
        diceRolled = diceRolled + roll.dice[diceRoll].values[thisDice]
      }
    }

    let successes = 0
    for (let i of chatCards) {
      i.rollResult = rollResult
      i.diceRolled = diceRolled
      i.rollVal = rollResult
      i.resultLevel = await ElysiumCheck.successLevel({
        targetScore: i.targetScore,
        rollVal: i.rollVal,
        cardType,
      })
      if (i.resultLevel > 1) { successes++ }
      i.resultLabel = game.i18n.localize('Elysium.resultLevel.' + i.resultLevel)
      newchatCards.push(i)
    }
    //await OPCard.showDiceRoll(chatCards[0])
    successes = successes / chatCards.length
    await targetMsg.update({
      'flags.elysium.chatCard': newchatCards,
      'flags.elysium.state': 'closed',
      'flags.elysium.successLevel': successes,
      'flags.elysium.rollResult': rollResult,
      'rolls': [roll]
    })
    const pushhtml = await ElysiumCheck.startChat(targetMsg.flags.elysium)
    await targetMsg.update({ content: pushhtml })
    await ElysiumCheck.tickXP(targetMsg.flags.elysium)
    return
  }

  static async GRClose(config) {
    const targetMsg = await game.messages.get(config.targetChatId)
    await targetMsg.update({
      'flags.elysium.state': 'closed',
      'flags.elysium.successLevel': -1,
      'flags.elysium.chatCard': []
    })
    const pushhtml = await ElysiumCheck.startChat(targetMsg.flags.elysium)
    await targetMsg.update({ content: pushhtml })
    return
  }
}
