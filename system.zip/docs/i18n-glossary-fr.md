# Elysium → Français translation glossary

Established BRP / Mythras / Elysium terminology for French translations. Used by the c3 translation script to constrain machine-translation output to game-mechanically correct terms.

## Stat abbreviations (PRESERVE as-is — universal in fr TTRPG)
- STR → STR (Strength → Force)
- CON → CON (Constitution → Constitution)
- SIZ → SIZ (Size → Taille)
- INT → INT (Intelligence → Intelligence)
- POW → POW (Power → Pouvoir)
- DEX → DEX (Dexterity → Dextérité)
- CHA → CHA (Charisma → Charisme)
- EDU → EDU (Education → Éducation)

## Core BRP mechanical terms
- Hit Points / HP → Points de Vie / PV
- Power Points / PP → Points de Pouvoir / PP
- Magic Points / MP → Points de Magie / PM
- Action Points / AP → Points d'Action / PA
- Armor Points / AP → Points d'Armure / PA (context-dependent)
- Skill → Compétence
- Characteristic → Caractéristique
- Hit Location → Localisation
- Healing Rate → Taux de Guérison
- Damage Modifier → Modificateur de Dégâts
- Damage Bonus → Bonus de Dégâts
- Critical → Critique
- Special → Spécial
- Success → Succès / Réussite
- Failure → Échec
- Fumble → Maladresse
- Difficulty grade → Niveau de Difficulté

## Mythras-specific
- Reach → Allonge
- Encroached → Empiété
- Held at bay → Tenu à distance
- Engagement → Engagement
- Sustain (a spell) → Maintenir
- Ward → Garde / Protection
- Brace → Caler / Appuyer (weapon-bracing context)
- Charge → Charge
- Knockback → Recul
- Outmanoeuvre → Manœuvrer
- Change Range → Changer de Portée
- Passive Block → Blocage Passif
- Covering Stance → Posture de Couverture
- Effective Size → Taille Effective
- Stance → Posture
- Endurance roll → Jet d'Endurance
- Willpower roll → Jet de Volonté

## Spell schools / disciplines
- Arcane → Arcanique
- Divine → Divin
- Mysticism → Mysticisme
- Sorcery → Sorcellerie
- School → École
- Discipline → Discipline
- Spell → Sort
- Caster → Lanceur
- Casting → Lancement / Incantation

## Damage types
- physical → physique
- fire → feu
- cold → froid
- electric → électrique
- corrosive → corrosif
- poison → poison
- mind → mental
- distortion → distorsion

## Elysium-specific mechanics
- EXP Dice / EXP die → Dé(s) d'EXP
- Stat improvement → Amélioration de Caractéristique
- Cap override → Outrepasser la Limite
- Major wound → Blessure Majeure
- Serious wound → Blessure Grave
- Minor wound → Blessure Mineure
- Ongoing damage → Dégâts Continus
- Temp HP → PV Temporaires
- Overcast → Surcharge (in casting context)
- Luck Point → Point de Chance
- Spend luck → Dépenser la chance

## Fatigue levels (Mythras-style)
- Fresh → Frais / Reposé
- Winded → Essoufflé
- Tired → Fatigué
- Weary → Las
- Exhausted → Épuisé
- Spent → Vidé
- Collapsed → Effondré
- Skill Grade → Niveau de Compétence (penalty context)
- AP Penalty → Pénalité de PA
- Move Penalty → Pénalité de Mouvement
- Initiative Penalty → Pénalité d'Initiative

## UI / sheet labels
- Sheet → Fiche
- Description → Description
- Settings → Paramètres
- Tooltip → (translate inline only — no UI label)
- Roll → Lancer / Jet
- Drag → Glisser
- Drop → Déposer
- Item → Objet
- Actor → Acteur (preserve)
- Effect → Effet
- Active Effect → Effet Actif
- Apply → Appliquer
- Remove → Retirer
- Approve → Approuver
- Decline → Refuser

## Roles / Ancestry
- Ancestry → Ascendance
- Subrace → Sous-race
- Trait → Trait
- Career → Carrière
- Culture → Culture
- Personality → Personnalité
- Allegiance → Allégeance
- Reputation → Réputation
- Passion → Passion

## Resource references
- The system uses the term "Elysium" verbatim across languages — DO NOT translate.
- Foundry / VTT — preserve.
- BRPID / BRP-ID — preserve (technical identifier).
- d100 / d6 / 3d6 — preserve dice notation.

## Style notes for translation pass

- Tone: neutral, mechanical, like a rulebook reference. Avoid colloquialisms.
- French punctuation: use guillemets « » for quotes where natural; non-breaking space before : ; ! ? where natural.
- Sheet labels: short and unambiguous (avoid 3+ word translations for 1-word source terms).
- Tooltips: full sentences, end with period.
- Hints (longer): can be 1-3 sentences; preserve any HTML tags in source.
- Format strings with `{placeholder}`: preserve placeholder name verbatim.
- When source uses `→` (arrow), preserve in translation.
- When source uses `•` or `·` (bullet/middot), preserve.

## Manual-review flag

Translations longer than ~15 words OR containing HTML tags should be flagged for second-pass review against this glossary.
