/**
 * Shared casting helpers (v0.9.0).
 *
 * The four traditions share most plumbing: PP payment, fatigue overcast,
 * resistance value computation, chat-card rendering, AP consumption.
 * Per-tradition modules (arcane-cast.mjs, divine-cast.mjs, etc.) handle
 * the tradition-specific roll mechanic and pre-flight checks.
 */

/**
 * v0.19.0: Arcane damage per Power Point committed.
 *
 * Hardcoded constant (was previously a world setting, range 1-5, default 1).
 * The setting allowed GMs to break magic balance unintentionally — we
 * lock the value at 4 which is the design baseline for v0.19.0's
 * cross-tradition balance pass.
 *
 * For per-campaign deadliness tuning, GMs should use the `hpMultiplier`
 * world setting (added in v0.19.0) which scales HP per location and
 * thereby relative-tunes all damage proportionally.
 */
export const ARCANE_DAMAGE_PER_PP = 4

/**
 * Compute Success Levels (SL) for an Arcane cast attempt.
 *
 * SL = tens(skill) - tens(roll), with the following rules:
 *   - If roll > skill (failure): 0 SL
 *   - If tens digits are equal but roll <= skill: 1 SL minimum
 *   - Critical (roll <= skill/10): caller treats as auto-fill remaining SL
 *   - Fumble (roll === 100): caller triggers Arcane Fumble table
 *
 * Special handling for skill >= 100: tens of 100 is 10, of 120 is 12, etc.
 *
 * @param {number} skill - the school skill total %
 * @param {number} roll - the d100 result (1..100; 00 read as 100)
 * @returns {{sl: number, outcome: 'fumble'|'critical'|'success'|'failure'}}
 */
export function computeSL (skill, roll) {
  if (roll === 100) return { sl: 0, outcome: 'fumble' }
  if (roll <= Math.floor(skill / 10)) return { sl: 0, outcome: 'critical' }
  if (roll > skill) return { sl: 0, outcome: 'failure' }

  const skillTens = Math.floor(skill / 10)
  const rollTens = Math.floor(roll / 10)
  let sl = skillTens - rollTens
  if (sl < 1) sl = 1   // same-tens-but-still-success rule
  return { sl, outcome: 'success' }
}

/**
 * Determine BRP-style success outcome (for Sorcery / Mysticism / Divine
 * traditions that use a simpler hit/miss model rather than SL accumulation).
 *
 * @returns {'fumble'|'critical'|'special'|'success'|'failure'}
 */
export function classifyRoll (skill, roll) {
  if (roll === 100) return 'fumble'
  if (roll === 1) return 'critical'
  if (roll <= Math.floor(skill / 20)) return 'critical'
  if (roll <= Math.floor(skill / 5))  return 'special'
  if (roll <= skill) return 'success'
  return 'failure'
}

/**
 * Spend AP from the actor's pool. Returns true if enough AP available.
 * Updates actor.system.actionPoints.value (and reactValue for reactions).
 *
 * v0.10.0: For reactions (reactiveAllowed=true), drain reactValue first
 * (reactive-only pool can ONLY pay for reactions, so we use it before
 * touching the flexible regular pool). Then fall back to value.
 *
 * For proactive actions (default reactiveAllowed=false), only the regular
 * pool is touched — reactive-only AP cannot pay for offensive actions.
 *
 * v0.10.2: Proactive spends are gated to once per turn while combat is
 * active. The first successful proactive spend in a turn sets
 * `flags.elysium.proactiveAPSpentThisTurn = true`; subsequent proactive
 * spends in the same turn refuse with a warning. The flag is cleared
 * by the combat-extension's onTurn hook (in the rules module) when the
 * actor's own turn begins, and on per-round AP refresh as a safety net.
 * Reactions never set or check this flag — they're free across the turn.
 *
 * Out of combat, no gate — `game.combat?.started` is falsy.
 *
 * @param {Actor} actor
 * @param {number} amount
 * @param {object} [opts]
 * @param {boolean} [opts.reactiveAllowed=false] - this AP spend is for a reaction
 * @returns {Promise<boolean>}
 */
export async function spendAP (actor, amount, opts = {}) {
  const reactiveAllowed = !!opts.reactiveAllowed
  const ap = actor.system?.actionPoints
  if (!ap) {
    ui.notifications?.warn(`${actor.name}: no AP pool`)
    return false
  }

  // v0.10.2: proactive-once-per-turn gate (combat only).
  if (!reactiveAllowed && game.combat?.started) {
    if (actor.getFlag('elysium', 'proactiveAPSpentThisTurn')) {
      ui.notifications?.warn(
        `${actor.name} has already spent a proactive AP this turn. ` +
        `Wait until your next turn to take another proactive action.`)
      return false
    }
  }

  const reg = Number(ap.value)       || 0
  const react = Number(ap.reactValue) || 0
  const totalAvailable = reactiveAllowed ? (reg + react) : reg

  if (totalAvailable < amount) {
    ui.notifications?.warn(
      `${actor.name}: insufficient AP (need ${amount}, have ${totalAvailable}` +
      (reactiveAllowed ? ` — ${reg} regular, ${react} reactive` : '') + ')')
    return false
  }

  if (!reactiveAllowed) {
    await actor.update({ 'system.actionPoints.value': reg - amount })
    // Set the once-per-turn flag (combat only). Out of combat this is
    // a no-op flag that will simply be ignored on the next read.
    if (game.combat?.started) {
      await actor.setFlag('elysium', 'proactiveAPSpentThisTurn', true)
    }
    return true
  }

  // Reactive: drain reactive-only first, then regular.
  let remaining = amount
  let newReact = react
  let newReg = reg
  if (newReact > 0) {
    const fromReact = Math.min(newReact, remaining)
    newReact -= fromReact
    remaining -= fromReact
  }
  if (remaining > 0) {
    newReg -= remaining
  }
  await actor.update({
    'system.actionPoints.value':      newReg,
    'system.actionPoints.reactValue': newReact,
  })
  return true
}

/**
 * v0.10.2: Clear the proactive-AP-spent flag on an actor.
 * Called from combat-extension.mjs when this actor's turn begins,
 * and from the per-round AP refresh as a safety net.
 */
export async function clearProactiveAPGate (actor) {
  if (!actor) return
  if (actor.getFlag('elysium', 'proactiveAPSpentThisTurn')) {
    await actor.unsetFlag('elysium', 'proactiveAPSpentThisTurn')
  }
}

/**
 * v0.10.2: Whether this actor has already spent a proactive AP this turn.
 * Useful for sheets / cast cards that want to disable buttons.
 */
export function hasSpentProactiveAP (actor) {
  return !!actor?.getFlag('elysium', 'proactiveAPSpentThisTurn')
}

/**
 * Pay PP for a spell. If insufficient, allow overcast (fatigue penalty).
 *
 * Overcast policy (v0.9.0):
 *   - 1 fatigue level per missing PP, up to 3 missing
 *   - 4+ missing requires confirmation; beyond that the spell fizzles
 *
 * @returns {{paid: boolean, ppSpent: number, fatigueAdded: number, fizzled: boolean}}
 */
export async function payPP (actor, cost, allowOvercast = true) {
  const pp = actor.system?.power
  const current = pp?.value ?? 0
  if (current >= cost) {
    await actor.update({ 'system.power.value': current - cost })
    return { paid: true, ppSpent: cost, fatigueAdded: 0, fizzled: false }
  }

  if (!allowOvercast) {
    return { paid: false, ppSpent: 0, fatigueAdded: 0, fizzled: true }
  }

  const missing = cost - current
  const fatigueLevels = Math.min(missing, 3)

  // Burn all available PP, add fatigue levels for the deficit
  const fatigue = actor.system?.fatigue ?? { level: 0 }
  await actor.update({
    'system.power.value': 0,
    'system.fatigue.level': (fatigue.level ?? 0) + fatigueLevels,
  })
  return {
    paid: true, ppSpent: current, fatigueAdded: fatigueLevels, fizzled: false,
  }
}

/**
 * Refund PP (used by Undo Cast button on chat cards).
 */
export async function refundPP (actor, amount) {
  const pp = actor.system?.power
  const max = pp?.max ?? 0
  const newVal = Math.min(max, (pp?.value ?? 0) + amount)
  await actor.update({ 'system.power.value': newVal })
}

/**
 * Roll a d100. By default the roll is "public-feeling" — it shows
 * dice-so-nice (3D) animations to all clients if the module is
 * installed. Use `rollMode: 'gmroll'` to skip animations and
 * whisper the result to GMs only (used by v0.10.0 silent F/T checks).
 *
 * @param {object}  opts
 * @param {string}  opts.flavor    - chat flavour text if a message is posted
 * @param {string}  opts.rollMode  - 'public' (default; no chat post, dice anim
 *                                   visible) or 'gmroll' (GM whisper, no anim)
 * @returns {{ roll: Roll, value: number }}
 */
export async function rollD100 ({ flavor = '', rollMode = 'public' } = {}) {
  const roll = await new Roll('1d100').evaluate()
  if (rollMode !== 'gmroll' && game.dice3d) {
    await game.dice3d.showForRoll(roll, game.user, true)
  }
  if (rollMode === 'gmroll') {
    // Whisper the roll to GMs only, with flavor.
    const gmIds = game.users
      ?.filter(u => u.isGM)
      ?.map(u => u.id) ?? []
    if (gmIds.length > 0) {
      await roll.toMessage(
        { flavor },
        { rollMode: 'gmroll', whisper: gmIds, create: true })
    }
  }
  let value = roll.total
  // BRP convention: 00 reads as 100. Foundry's 1d100 already returns 1..100,
  // but defensive check in case of dice modules returning 0.
  if (value === 0) value = 100
  return { roll, value }
}

/**
 * Look up a skill by elysium subgroup or by name on the actor.
 * Returns the first matching skill item, or null.
 */
export function findSkill (actor, { subgroup = null, name = null } = {}) {
  for (const itm of actor.items) {
    if (itm.type !== 'skill') continue
    if (subgroup && itm.system?.elysium?.skillSubgroup !== subgroup) continue
    if (name && itm.name.toLowerCase() !== name.toLowerCase()) continue
    return itm
  }
  return null
}

/**
 * Find a Form or Technique skill by name (case-insensitive).
 *
 * v0.15.0: Forms and Techniques are now skill items, not passion items.
 * They live in the compendium pack `elysium-compendium.arcane-knowledge`
 * and are tagged with `system.elysium.skillSubgroup === 'arcane'` plus
 * `system.elysium.arcaneRole === 'form' | 'technique'`. The skill name
 * format remains "Form (X)" / "Technique (X)" — same as the v0.14.x
 * passions — so casting code that already capitalises the spell's
 * lowercase F/T strings produces matching names with no other changes.
 *
 * The returned skill's `system.total` is the percentage the cast-time
 * silent F/T check rolls against (computed in skill.mjs:55 as
 * base + xp + culture + career + personality + personal + effects).
 *
 * Returns the skill item, or null if the actor doesn't own it. Callers
 * treat null as "auto-fail this F/T → wild magic on completion."
 */
export function findFormOrTechnique (actor, kind, value) {
  const target = `${kind} (${value})`.toLowerCase()
  const expectedRole = kind.toLowerCase()  // 'form' or 'technique'
  for (const itm of actor.items) {
    if (itm.type !== 'skill') continue
    if (itm.system?.elysium?.skillSubgroup !== 'arcane') continue
    if (itm.system?.elysium?.arcaneRole !== expectedRole) continue
    if (itm.name.toLowerCase() === target) return itm
  }
  return null
}

/**
 * Fetch the canonical list of Forms and Techniques from the compendium
 * arcane-knowledge pack. Used by the Arcane spell sheet to populate F/T
 * multi-selects (v0.10.0 step 9) and by the custom-spell builder.
 *
 * Returns: { forms: [{value, label}], techniques: [{value, label}] }
 *   value = lowercase short name (stored on spells)
 *   label = display name (e.g., "Form (Fire)")
 *
 * Cached on game.system.api._ftCache so we don't hit the compendium
 * on every sheet render. Cache lives until the page reloads.
 *
 * v0.15.0: source pack moved from `elysium-compendium.passions` to
 * `elysium-compendium.arcane-knowledge`, and entries are now skill-type
 * (was passion-type). Filter changed accordingly. The lowercase string
 * values stored on spells (`spell.system.elysium.forms[]`,
 * `spell.system.elysium.techniques[]`) are unchanged from v0.14.x, so
 * existing spell content needs no migration.
 */
let _ftCache = null
export async function getArcaneFormsTechniquesFromCompendium () {
  if (_ftCache) return _ftCache
  const pack = game.packs.get('elysium-compendium.arcane-knowledge')
  if (!pack) {
    console.warn('Elysium arcane-knowledge pack not found; F/T dropdowns will be empty.')
    return { forms: [], techniques: [] }
  }
  const docs = await pack.getDocuments()
  const forms = []
  const techniques = []
  for (const doc of docs) {
    if (doc.type !== 'skill') continue
    if (doc.system?.elysium?.skillSubgroup !== 'arcane') continue
    const role = doc.system?.elysium?.arcaneRole
    if (role !== 'form' && role !== 'technique') continue
    // Names look like "Form (Fire)" or "Technique (Create)".
    const m = doc.name.match(/^(Form|Technique)\s*\(([^)]+)\)\s*$/)
    if (!m) continue
    const kind = m[1]
    const specialism = m[2].trim()
    const value = specialism.toLowerCase()
    const entry = { value, label: doc.name }
    if (kind === 'Form') forms.push(entry)
    else techniques.push(entry)
  }
  // Sort alphabetically by label for stable dropdowns.
  forms.sort((a, b) => a.label.localeCompare(b.label))
  techniques.sort((a, b) => a.label.localeCompare(b.label))
  _ftCache = { forms, techniques }
  return _ftCache
}

/**
 * Invalidate the F/T cache. Call when the compendium passions pack is
 * modified (rare in production; mostly useful for dev / hot-reload).
 */
export function invalidateFTCache () {
  _ftCache = null
}

/**
 * Look up a RollTable from the magic-tables compendium pack by its
 * elysium.magicTableKey flag.
 */
export async function findMagicTable (key) {
  const pack = game.packs.get('elysium-compendium.elysium-magic-tables')
  if (!pack) {
    ui.notifications?.warn('Elysium magic tables pack not found. Wild magic / fumble effects will not roll.')
    return null
  }
  const docs = await pack.getDocuments()
  return docs.find(d => d.flags?.['elysium']?.magicTableKey === key) ?? null
}

/**
 * Roll on a magic-tables RollTable and return the chosen result.
 */
export async function rollMagicTable (key) {
  const table = await findMagicTable(key)
  if (!table) return null
  const draw = await table.draw({ displayChat: false })
  const result = draw.results?.[0]
  return result ? {
    rangeRolled: draw.roll?.total ?? null,
    name: result.text,
    description: result.description ?? '',
    severity: result.flags?.['elysium']?.severity ?? 'moderate',
  } : null
}

/**
 * Render the cast chat card and post it.
 *
 * @param {object} ctx - card context (caster, spell, rollDetails, etc.)
 * @returns the ChatMessage that was posted
 */
export async function postCastCard (ctx) {
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/cast-card.hbs', ctx)
  return ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: ctx.casterDoc }),
    content: html,
    flags: { elysium: { castCard: true, ctx: serialiseCardCtx(ctx) } },
  })
}

/**
 * Update an existing cast progress card in place.
 */
export async function updateCastCard (messageId, ctx) {
  const msg = game.messages.get(messageId)
  if (!msg) return
  const html = await foundry.applications.handlebars.renderTemplate(
    'systems/elysium/templates/chat/cast-card.hbs', ctx)
  await msg.update({
    content: html,
    flags: { elysium: { castCard: true, ctx: serialiseCardCtx(ctx) } },
  })
}

/**
 * Strip non-serialisable bits from card context so we can roundtrip it
 * through chat-message flags (used by Undo Cast and Spend AP buttons).
 */
function serialiseCardCtx (ctx) {
  return {
    casterId: ctx.casterDoc?.id,
    casterName: ctx.casterName,
    spellId: ctx.spellId,
    spellName: ctx.spellName,
    tradition: ctx.tradition,
    schoolName: ctx.schoolName,
    requiredSL: ctx.requiredSL ?? null,
    accumulatedSL: ctx.accumulatedSL ?? null,
    attempts: ctx.attempts ?? [],
    completed: ctx.completed ?? false,
    abandoned: ctx.abandoned ?? false,
    corrupted: ctx.corrupted ?? false,                    // v0.10.0 — F/T-revealed-at-completion
    manipulationSummary: ctx.manipulationSummary ?? '',   // v0.10.0 — human-readable bend
    finalRoll: ctx.finalRoll ?? null,
    resistanceValue: ctx.resistanceValue ?? null,
    saveSkill: ctx.saveSkill ?? '',
    description: ctx.description ?? '',
    ppSpent: ctx.ppSpent ?? 0,
    ppCommitted: ctx.ppCommitted ?? 0,                    // v0.16.0 — PP committed for damage scaling (was: PP-as-magnitude)
    projectedDamage: ctx.projectedDamage ?? 0,            // v0.10.0
    damagePerPP: ctx.damagePerPP ?? 1,                    // v0.10.0
    fatigueAdded: ctx.fatigueAdded ?? 0,
    apSpent: ctx.apSpent ?? 0,
    cardSpent: ctx.cardSpent ?? false,                   // v0.10.3 — one-shot button state
    isHealing: ctx.isHealing ?? false,                   // v0.10.3 — heal vs damage label
    wildMagic: ctx.wildMagic ?? null,
    fumble: ctx.fumble ?? null,
    ftFailures: ctx.ftFailures ?? [],                     // v0.10.0 — surfaced only on corrupted-completion
  }
}

/**
 * Read/write the in-progress active-cast state on the actor.
 * Lives in flags.elysium.activeCast (one slot per actor; the rules
 * say "locked in until complete or abandoned" so multiple in-flight
 * casts on the same actor aren't allowed).
 */
export function getActiveCast (actor) {
  return actor.getFlag('elysium', 'activeCast') ?? null
}

export async function setActiveCast (actor, state) {
  return actor.setFlag('elysium', 'activeCast', state)
}

export async function clearActiveCast (actor) {
  return actor.unsetFlag('elysium', 'activeCast')
}

// === Arcane Manipulation (v0.10.0) ====================================

/**
 * Base cost in INT-pool points to bend each parameter +1 step. Defined
 * at module scope so the dialog and the cast-pipeline reference one
 * source of truth. Cost is reduced by `manipulationDiscount(skillTotal)`
 * (with floor of 1).
 */
export const MANIPULATION_BASE_COST = Object.freeze({
  range:    1,
  duration: 2,
  targets:  3,
  area:     3,
})

/**
 * Discount to manipulation costs based on school-skill %. Higher mastery
 * → cheaper bending. Floor of 1 enforced separately by `manipulationCost`.
 *
 *   < 50%  →  0
 *   50–69  →  1
 *   70–84  →  2
 *   85–94  →  3
 *   95+    →  4
 *
 * @param {number} skillTotal - the school-skill total %
 * @returns {number} - discount to subtract from base cost (before floor)
 */
export function manipulationDiscount (skillTotal) {
  const s = Number(skillTotal) || 0
  if (s >= 95) return 4
  if (s >= 85) return 3
  if (s >= 70) return 2
  if (s >= 50) return 1
  return 0
}

/**
 * Effective per-step cost for a manipulation parameter, after discount,
 * floored at 1 (per Section 4.1: "never free").
 *
 * @param {string} param - one of 'range'|'duration'|'targets'|'area'
 * @param {number} skillTotal - school-skill total %
 * @returns {number}
 */
export function manipulationCost (param, skillTotal) {
  const base = MANIPULATION_BASE_COST[param]
  if (base == null) return 0
  return Math.max(1, base - manipulationDiscount(skillTotal))
}

/**
 * Sum the total INT-pool cost of a manipulation profile.
 *
 * @param {{range,duration,targets,area}} deltas - +N step counts per param
 * @param {number} skillTotal - school-skill %
 * @returns {{totalCost: number, parametersTouched: number, perParam: object}}
 */
export function summariseManipulation (deltas, skillTotal) {
  let totalCost = 0
  let parametersTouched = 0
  const perParam = {}
  for (const param of Object.keys(MANIPULATION_BASE_COST)) {
    const steps = Number(deltas?.[param]) || 0
    const stepCost = manipulationCost(param, skillTotal)
    const cost = steps * stepCost
    perParam[param] = { steps, stepCost, cost }
    totalCost += cost
    if (steps > 0) parametersTouched += 1
  }
  return { totalCost, parametersTouched, perParam }
}
