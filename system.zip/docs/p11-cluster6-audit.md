# P11 Cluster 6 audit — island harmonisation evaluation

**Status**: COMPLETE — NO SHIP (findings folded into P12 backlog)
**Target alpha**: none (evaluation only; no version bump)
**Scope**: Re-audit the 4 v1.0.0 "island" surfaces that received the cluster-1 retoken (alpha.45) to assess whether a follow-up harmonisation pass is warranted before P12. The 4 islands:
  - **cast-card** — `templates/casting/cast-card.hbs` + `.elysium-cast-card` marker
  - **manipulation** — `templates/casting/cast-card-target-dialog.hbs` + 2 sibling targeting dialogs + `.elysium-manip-dialog` marker (long BEM prefix `.elysium-manip-*`)
  - **csb** — Custom Spell Builder, `.elysium-custom-spell-builder` marker (short BEM prefix `.csb-*`)
  - **tcd** — Tier Choice Dialog, `.elysium-tier-choice-dialog` marker (short BEM prefix `.tcd-*`)
**Inheritance from**: P11 prep audit (open-question c11-7 reserved cluster 6 as "evaluate after clusters 1-5 ship, decide go/no-go on a harmonisation pass"), cluster 1 audit (alpha.45 retoken work that this audit re-verifies), and the post-alpha.49 milestone state where 21/21 chat+dialog templates are on v1.0.0.

This audit reaches a NO-SHIP recommendation. The original cluster-6 plan in the prep audit assumed island markup or styling might need substantive rework to align with the v1.0.0 chat-card and dialog vocabularies. Measurement against the alpha.49 baseline shows the islands are already well-aligned post-cluster-1: zero legacy-token leakage, only 1 hardcoded color literal across all 4 islands combined, and the 36 hardcoded `px` values are spacing/border/radius literals that pre-date design tokens but don't represent a behavioural or visual misalignment with the v1.0.0 identity. The minor remaining work is appropriately routed to P12's omnibus polish sweep alongside the lang-completion + `data-handle-change` retirement + `darkred` retoken + legacy-CSS orphaning work — these are all single-pass mechanical retokens that batch more efficiently together than as a standalone cluster ship.

---

## 1. Current-state inventory

### Island block counts and token consumption

Measured against `styles/elysium.css` at alpha.49 baseline. "Blocks" counts rule blocks whose selectors carry an island marker class. "Tokens consumed" counts distinct `var(--ely-*)` references inside those blocks.

| Island | Marker class | BEM prefix | Blocks | Distinct `--ely-*` tokens consumed | Legacy `--ely-legacy-*` refs |
|---|---|---|---|---|---|
| cast-card | `.elysium-cast-card` | `.elysium-cast-card-*` (long) | 5 | 10 | **0** |
| manipulation | `.elysium-manip-dialog` | `.elysium-manip-*` (long) | 38 | 25 | **0** |
| csb | `.elysium-custom-spell-builder` | `.csb-*` (short) | 18 | 24 | **0** |
| tcd | `.elysium-tier-choice-dialog` | `.tcd-*` (short) | 22 | 24 | **0** |
| **Total** | — | — | **83** | — | **0** |

### Marker-class verification

All 4 island markers are present on their respective root template(s). Verified via grep against `templates/` — no island is missing its v1.0.0 scoping marker, which means the cluster-1 retoken work registered the markers correctly and the cascade is reaching the island-internal rules as intended.

### Cluster-1 retoken verification (alpha.45 hold-up)

Cluster 1 (alpha.45 changelog) reported "~80 hardcoded color substitutions across 4 islands" + cast-card light-parchment background replaced with `var(--ely-surface-card)`. Re-measurement at alpha.49:

- **Hardcoded color literals across all 4 islands**: 1 (the TCD rgba at line 2840 — see Finding F1 below).
- **Distinct `--ely-*` tokens consumed across all 4 islands**: 50 distinct (overlap ~33 across pairs, ~83 token-references in aggregate).
- **`--ely-legacy-*` references**: 0.

**Verdict on cluster 1**: the retoken held. The 4 islands are token-driven for color. Cluster 1 did its job.

---

## 2. Findings

### F1 — Single hardcoded color leak (TCD)

**File**: `styles/elysium.css` line ~2840
**Rule**: `.elysium-tier-choice-dialog .tcd-tier-selected .tcd-tier-cost`

```css
.elysium-tier-choice-dialog .tcd-tier-selected .tcd-tier-cost {
  background: rgba(255, 255, 255, 0.18);
}
```

**Context**: This is the only hardcoded color literal in any of the 4 islands. The intent is a subtle translucent-white wash on the "cost" pill inside a SELECTED tier card to provide visual differentiation from non-selected tiers. The cluster-1 retoken sweep missed it because `rgba(255,255,255,0.18)` is a semantically *neutral* layer (not a chromatic accent) and the cluster-1 mapping table focused on chromatic substitutions.

**P12 mapping candidates**: this leak should retoken to one of:
1. `var(--ely-surface-overlay)` if a semantic overlay token exists
2. `var(--ely-surface-raised)` with explicit alpha via `color-mix(in srgb, var(--ely-surface-raised) 82%, transparent)`
3. A new semantic token `--ely-overlay-subtle` defined in `elysium-tokens.css` if no existing token fits

Decision deferred to P12 cluster-6-followup; falls into the "darkred retoken" + "1 rgba" line item already in the HANDOFF P12 backlog.

### F2 — Hardcoded `px` values across islands

**Measured count**: 36 `px` literals across 83 island blocks. Per-island breakdown:

| Island | px literal count |
|---|---|
| cast-card | 1 |
| csb | 9 |
| tcd | 5 |
| manipulation | 21 |
| **Total** | **36** |

**Methodology note**: the count uses a regex that matches every `px` token in declaration values (including multi-value box-shadow declarations and var-fallback `px` literals). HANDOFF-state.md cited "31 px values" — the discrepancy of 5 is attributable to multi-value declarations being counted per-value here vs per-declaration in the original verbal audit. Either count supports the same conclusion: the px-literal load is concentrated in `manipulation` and is mostly small spacing/border-radius values (1px–4px) rather than large layout-defining values.

**Spot samples**:
- `manipulation` line ~1679: 2px and 3px border-related values in `.elysium-manip-header`
- `manipulation` line ~1682: 3px in same family
- `csb` line ~2593: 100px label width in `.elysium-custom-spell-builder .csb-row label` — this is a layout-defining value, not a spacing literal
- `tcd` line ~2733: 1px border in `.tcd-header`
- `cast-card` line ~1326: 1px border

**Categorisation** (no full per-line classification done in this audit — that's P12 work):
- Most are **1px/2px borders** that could retoken to `var(--ely-border-width-thin)` if a token exists, else stay px (1px borders are fine literals)
- Some are **3px/4px gaps** that should map to `var(--ely-space-*)` scale
- A few are **larger layout values** (e.g. `100px` label width in csb) that are arguably correct as px literals because they're component-specific layout constants, not design-system values

**P12 routing**: the px retoken is appropriate omnibus work. Each retoken is mechanical (find literal → identify nearest token → substitute → re-verify), but doing them as a batch lets us identify when a token is missing from `elysium-tokens.css` and add it once rather than discovering the gap 5 separate times. Same pattern as the alpha.45 island retoken.

### F3 — BEM prefix convention drift across islands

**Observation**: the 4 islands use two different BEM prefix conventions:

| Convention | Islands | Example |
|---|---|---|
| Long (`elysium-<island>-*`) | cast-card, manipulation | `.elysium-cast-card-portrait`, `.elysium-manip-header` |
| Short (`<2-3-letter-abbr>-*`) | csb, tcd | `.csb-section`, `.tcd-tier-selected` |

**Impact**: **stylistic only, not a bug**. The cascade works correctly in both conventions because the parent scoping marker (`.elysium-custom-spell-builder`, `.elysium-tier-choice-dialog`) provides the same uniqueness guarantee that the long-prefix convention provides directly on the child class. JS hooks don't care about the prefix shape — they care about the specific class names being preserved verbatim against the audit-5 lock list.

**Decision**: do NOT harmonise prefixes in P12. The cost (rename every selector in 2 islands + every template class binding + every JS reference if any) substantially exceeds the benefit (consistency in selector inspection). The two conventions are both readable and both correct. Documenting the divergence here is sufficient.

**Caveat**: any FUTURE new island added in P12 or later should pick the long convention (`elysium-<island>-*`) because it doesn't require a parent scoping marker to disambiguate from other elysium-scoped classes, which gives flexibility on whether the marker class lives on the root template element or somewhere else in the surface.

### F4 — No marker-class duplication or scope leaks

Verified via spot-check that no island selectors leak outside their scoping marker. Each of the 83 island blocks correctly carries the island's marker class as a selector ancestor. Cluster-1 retoken did not introduce any cross-island contamination.

### F5 — `csb` is the BEM prefix of "elysium-custom-spell-builder", NOT a "combat strategy board"

**Documentation correction**: prior handoff notes and at least one HANDOFF-state.md draft referred to `csb` as if it were a separate "combat strategy board" UI surface. It is not. `csb` is the short BEM prefix used for the Custom Spell Builder dialog's internal classes (`.csb-section`, `.csb-row`, `.csb-input`, etc.) and the scoping marker is `.elysium-custom-spell-builder`. There is no combat-strategy-board UI in the current codebase.

**Action**: this audit document is the canonical clarification. Future handoff state files should treat `csb` as Custom Spell Builder.

---

## 3. Decision — NO SHIP

The findings collected here do not justify a cluster-6 ship by themselves. Reasoning:

1. **F1 is one declaration**. Shipping a one-rule alpha is high overhead for low payoff. Folds into P12's existing "1 rgba" line item.
2. **F2 (px retoken)** is mechanical work that batches more efficiently with the lang sweep, `data-handle-change` retirement, `darkred` retoken, and the orphaning-driven legacy CSS retirements. All of these are P12 polish-class operations with the same "audit, retoken, verify" rhythm, and they share the same risk profile (cosmetic-only, no behavioural impact).
3. **F3 (BEM convention)** explicitly rejected.
4. **F4, F5** are documentation findings, not work findings.

The post-alpha.49 milestone state — 21/21 chat+dialog templates on v1.0.0, both legacy CSS retirements landed, all 15 chat-card-type accents populated — is a clean stopping point for P11's mandatory scope. Adding a cluster-6 ship to address findings that themselves recommend P12 routing is process for its own sake.

**Recommendation locked**: skip cluster-6 ship; carry findings F1 and F2 into P12 backlog under "Island cleanup".

---

## 4. P12 backlog routing

The following items consolidate this audit's findings with the previously-tracked P12 backlog. Items added in this audit are marked **[c6]**.

| Item | Source | Estimated scope |
|---|---|---|
| `data-handle-change` attribute retirement (zero JS consumers) | cluster-5 audit | mechanical — sweep all templates, remove attribute |
| Lang completion sweep (es-gap=206, fr-gap=206) | cluster-5 alpha.49 ship | translation work; can be batched |
| `darkred` → `--ely-text-danger` retoken | HANDOFF-state.md | single rule at `css/legacy.css:1384`; retoken + verify |
| **[c6]** 1 hardcoded rgba retoken at `styles/elysium.css:~2840` | this audit F1 | single rule; identify or create overlay token |
| **[c6]** 36 hardcoded px literal review across 4 islands | this audit F2 | batched audit + retoken |
| Additional legacy CSS retirements (orphaning audit) | rolling | requires full consumer-set audit |
| Behavioral acceptance testing | rolling | spot-test exercise of P7-P11 features |

**Cluster-6 followup ships as part of P12, not as its own cluster.**

---

## 5. Cross-references

- `docs/p11-prep-audit.md` open-question c11-7: original "evaluate cluster 6 after clusters 1-5 ship"
- `docs/p11-cluster1-audit.md` decisions c1-1 through c1-11: original retoken work that this audit re-verifies
- `docs/p11-cluster5-audit.md` open-question #6: "what after alpha.49?" — answer: this audit, then alpha.50 hotfix, then P12 (cluster 7 audit optional first)
- `CHANGELOG.md` [1.0.0-alpha.45]: original cluster-1 retoken scope and the ~80 hardcoded color substitutions

---

## 6. Open questions

None. This audit reaches a no-ship decision with a clean P12 routing for all live findings.
