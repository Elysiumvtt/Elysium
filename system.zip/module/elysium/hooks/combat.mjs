// Auto-extracted from module/elysium/hooks/register-hooks.mjs by tools/extract-functions.mjs
// (v0.21.0 register-hooks refactor).
//
// Top-level Foundry hook handlers extracted from the central registerHooks
// dispatcher. Each function is exported by name; the dispatcher imports them
// and wires them via Hooks.on(eventName, handler).



import { ElysiumCombatExtension } from '../combat/combat-extension.mjs'

export function _onCombatStart (combat, updateData) {
  ElysiumCombatExtension.onCombatStart(combat, updateData)
}

export function _onCombatRound (combat, updateData, updateOptions) {
  ElysiumCombatExtension.onRound(combat, updateData, updateOptions)
}

export function _onCombatTurn (combat, updateData, updateOptions) {
  ElysiumCombatExtension.onTurn(combat, updateData, updateOptions)
}

export function _onCombatEnd (combat, options, userId) {
  ElysiumCombatExtension.onCombatEnd(combat, options, userId)
}
