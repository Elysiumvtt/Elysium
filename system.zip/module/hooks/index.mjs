import * as DrawNote from "./draw-note.mjs";
import * as RenderDialog from './render-dialog.mjs'
import * as RenderChatMessage from './render-chat-message.mjs'
import * as RenderNoteConfig from './render-note-config.js'

export const ElysiumHooks = {
  listen() {
    DrawNote.listen()
    RenderDialog.listen()
    RenderChatMessage.listen()
    RenderNoteConfig.listen()
  }
}
