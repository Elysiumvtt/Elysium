/* global game */
import { ElysiumIDEditor } from './elysiumid-editor.mjs'
export function addElysiumIDSheetHeaderButton(headerButtons, sheet) {
  //if (game.user.isGM) {
  const sheetElysiumID = sheet.object.flags?.elysium?.elysiumidFlag
  const noId = (typeof sheetElysiumID === 'undefined' || typeof sheetElysiumID.id === 'undefined' || sheetElysiumID.id === '')
  const ElysiumIDEditorButton = {
    class: (noId ? 'edit-elysiumid-warning' : 'edit-elysiumid-exisiting'),
    label: 'Elysium.ElysiumIDFlag.id',
    icon: 'fas fa-fingerprint',
    onclick: () => {
      if (game.user.isGM) {
        new ElysiumIDEditor(sheet.object, {}).render(true, { focus: true })
      }
    }
  }
  const numberOfButtons = headerButtons.length
  //headerButtons.splice(numberOfButtons - 1, 0, ElysiumIDEditorButton)
  headerButtons.splice(0, 0, ElysiumIDEditorButton)
  //}
}
