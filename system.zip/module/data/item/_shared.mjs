/**
 * Shared DataModel field-builders for item types.
 *
 * Mirrors module/data/actor/_shared.mjs in pattern.
 *
 * Helpers:
 *   - makeItemBase()         — description + gmDescription (most types use this)
 *   - makeThemedBundle()     — activation/benefits/drawbacks/addOns (ability + mysticism)
 *   - makeSpellBaseFields()  — 17 shared spell-base fields (arcane + mysticism)
 *
 * Stored-schema-only per the P5/P6 decision: derived fields (perSkill,
 * grpSkill, enrichedDescription, statName, etc.) stay in ElysiumItem and
 * the per-sheet _prepareContext — NOT moved into DataModels.
 *
 * Two item types skip the base template entirely: `wound` and `hit-location`
 * (per template.json's `templates: []` for those). Note that hit-location's
 * P6.3 DataModel DECLARES base anyway because compendium content populates
 * `description` — see docs/p6-3-handoff.md side-finding.
 */

const fields = foundry.data.fields

/**
 * Item base fields. The two HTMLFields shared across most item types per
 * template.json `Item.templates.base`.
 *
 * Note: system.json's `documentTypes.Item.<type>.htmlFields` declarations
 * reference `gmNotes` rather than `gmDescription` — that's a pre-existing
 * manifest bug (side-finding #6 in docs/p6-prep-audit.md). The stored field
 * has always been `gmDescription`; the manifest entries point at a phantom
 * field. P6.6 cleans up the manifest.
 */
export function makeItemBase () {
  return {
    description:   new fields.HTMLField({ initial: '' }),
    gmDescription: new fields.HTMLField({ initial: '' }),
  }
}


/**
 * Themed-bundle fields shared by `ability` and `mysticism` per the P6.4 audit.
 * Both types declare bit-identical `{activation, benefits, drawbacks, addOns}`
 * inside their `elysium` SchemaField. Template documentation strings (`_doc`,
 * `_addOnSchema_doc`) are dropped — they're not real stored fields.
 *
 * Per the audit, the `addOns` schema documents requiredSkillPercent tier
 * gates 50/70/85/95 with xpDiceCost tiers 5/6/7/8 (compendium 0.6.x
 * rebalance). Purchase is guaranteed once both gates are met (no roll).
 */
export function makeThemedBundle () {
  return {
    activation: new fields.SchemaField({
      type:          new fields.StringField({ initial: 'passive' }),
      actionCost:    new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      ppCost:        new fields.NumberField({ integer: true, initial: 0, min: 0 }),
      duration:      new fields.StringField({ initial: '' }),
      endConditions: new fields.ArrayField(new fields.StringField(), { initial: [] }),
    }),
    benefits: new fields.ArrayField(
      new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
      { initial: [] },
    ),
    drawbacks: new fields.ArrayField(
      new fields.SchemaField({ text: new fields.StringField({ initial: '' }) }),
      { initial: [] },
    ),
    addOns: new fields.ArrayField(
      new fields.SchemaField({
        name:                  new fields.StringField({ initial: '' }),
        description:           new fields.StringField({ initial: '' }),
        requiredSkillPercent:  new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        xpDiceCost:            new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        ppCost:                new fields.NumberField({ integer: true, initial: 0, min: 0 }),
        effect:                new fields.StringField({ initial: '' }),
      }),
      { initial: [] },
    ),
  }
}


/**
 * Spell-base top-level fields shared by `arcane` and `mysticism` per the
 * P6.4 audit. Both types' templates declare these 17 fields bit-identically;
 * arcane additionally declares `mem` (memorized flag) on top. They look
 * forked from a common ancestor spell template.
 *
 * The 7 NumberFields (base/xp/career/personality/culture/personal/effects)
 * are the BRP-classic skill-resolution stack — `base` is the rolled formula
 * total; the others are sourced bonuses. `pppl` is "PP per level" stored as
 * a string per template (consistent with super.cpc/pppl pattern from P6.2).
 */
export function makeSpellBaseFields () {
  return {
    base:        new fields.NumberField({ integer: true, initial: 0 }),
    xp:          new fields.NumberField({ integer: true, initial: 0 }),
    career:  new fields.NumberField({ integer: true, initial: 0 }),
    personality: new fields.NumberField({ integer: true, initial: 0 }),
    culture:     new fields.NumberField({ integer: true, initial: 0 }),
    personal:    new fields.NumberField({ integer: true, initial: 0 }),
    effects:     new fields.NumberField({ integer: true, initial: 0 }),
    category:    new fields.StringField({ initial: '' }),
    impact:      new fields.StringField({ initial: 'other' }),
    range:       new fields.StringField({ initial: '' }),
    duration:    new fields.StringField({ initial: '' }),
    pppl:        new fields.StringField({ initial: '1' }),    // string per template
    damage:      new fields.StringField({ initial: '' }),
    prsnlty:     new fields.BooleanField({ initial: false }),
    occupation:  new fields.BooleanField({ initial: false }),
    cultural:    new fields.BooleanField({ initial: false }),
    improve:     new fields.BooleanField({ initial: false }),
  }
}


/**
 * Pre-validation normalizer for `equipStatus` on weapon/armor/gear.
 *
 * v1.0.0-alpha.11 (side-finding #8): the legacy v0.20.0-era compendium
 * content can contain `equipStatus: 'carried'` or `'worn'`. With the
 * v1.0.0-alpha.11 choices lock on equipStatus (`['stowed', 'equipped']`),
 * those values would fail validation on drop. This helper runs from each
 * affected DataModel's `static migrateData(source)` hook — Foundry V14
 * invokes it BEFORE cleanData's choices check, so the migrated value is
 * what gets validated.
 *
 * Idempotent: only mutates when source.equipStatus is one of the legacy
 * values, otherwise no-op.
 */
export function migrateLegacyEquipStatus (source) {
  if (source && (source.equipStatus === 'carried' || source.equipStatus === 'worn')) {
    source.equipStatus = 'stowed'
  }
  return source
}
