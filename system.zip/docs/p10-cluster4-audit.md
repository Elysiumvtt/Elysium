# P10 cluster 4 — arcane + sorcery (prep audit)

Captured 2026-05-14 after cluster 3b (alpha.41) smoke pass.
**Audit-then-stop**: no code shipped from this document.

## Scope

Cluster 4 covers the 2 remaining spell item types:

| Type | Sheet LOC | Detail LOC | Width | Key features |
|---|--:|--:|--:|---|
| arcane | 302 | 189 | 520×610 | F/T compendium-driven row dropdowns (with add/remove buttons); requiredSL/basePP/apCost cast profile; saveSkill; range/duration flavor; isRitual + isPermanent flags |
| sorcery | 192 | 249 | 520×525 | Essence selector (12 essences, 3 marked forbidden); baseTier/maxTier; per-tier AP cost grid (5 cells); per-tier effect rows (damage dice + locations); 14-entry damage type selector with cross-tradition palette; isDamageSpell/isSustained/forbidden/casterChoosesLocation flags; conditional Maintain PP/round when isSustained |

Total: **~494 LOC of sheet classes + ~438 LOC of templates**.

After alpha.42, **20 of 23 item types** are on v1.0.0 (87%); 3 remain on legacy paths (skill body, weapon, career — clusters 5 + 6).

## Width plan

Both wide-tier per P10 cluster 3 audit-3 spell-card convention:
- **arcane**: 720×640 (was 520×610). Wider needed for F/T row dropdowns + remove buttons + add button side-by-side.
- **sorcery**: 720×720 (was 520×525). Wider AND taller — 14-entry damage type select + 4 flag checkboxes + conditional Maintain row + 5-row tier effects with damage+locations sub-row each pushes the natural content height past the default 640. Matches divine's 720×720 spell-with-tiers profile.

## Cross-cluster shared assets review

Cluster 3a's spell helpers are partial fit:

- **`ElysiumSelectLists.getSpellSaveSkillOptions()`** (returns 5 options: none/evade/willpower/endurance/brawn) — ✅ **REUSED by both arcane and sorcery** (same 5-option set). Localization already in en/es/fr.
- **`ElysiumSelectLists.getSpellDamageTypeOptions()`** (returns 5 options: none/radiant/lightning/fire/sonic) — ⚠️ **DIVINE-ONLY palette**. Sorcery needs 14 damage types from the cross-tradition combat table. **Decision c4-1**: rename to `getDivineDamageTypeOptions()` and add new `getSorceryDamageTypeOptions()` with the full sorcery palette (slashing/piercing/bludgeoning/force/fire/cold/lightning/corrosive/sonic/poison/necrotic/psychic/radiant/distortion + "none"). 13 of these 15 entries need new `Elysium.damage*` i18n keys (radiant + fire already exist from alpha.40; cold/lightning/sonic also exist; the rest are new). 1-line callsite swap in divine.mjs.

Cluster 1 + 2 + 3a/b partials all relevant:
- **`item-shell-header.hbs`** — both use the standard header (no specialism).
- **`item-shell-description.hbs`**, **`item-shell-gmnotes.hbs`** — both use standard prose-mirror partials.
- **`item-shell-tabs.hbs`** — both use the standard 3-tab strip (details, description, gmNotes).
- **`item-field-row.hbs`** / **`item-field-grid.hbs`** — heavy reuse for the GM/player split fields (school, requiredSL, basePP, apCost, range, duration, essence, baseTier, maxTier, powerCost).

## New shared assets

### c4-new-1: `templates/item/parts/item-toggle-row.hbs` (new)

Both arcane and sorcery have a `<div class="elysium-spell-flags">` row of native `<input type="checkbox">` boolean flags. Cluster 2 introduced the `data-action="itemToggle"` BEM chip pattern (used by gear's equipStatus, mutation's enabled, super's specialism/chosen). Cluster 3a extended the writable allow-list to include divine's isRitual/isReactive/isDamageSpell.

Cluster 4 introduces 6 more booleans across arcane + sorcery:
- arcane: `isRitual`, `isPermanent`
- sorcery: `isDamageSpell` (already in writable list from cluster 3a), `isSustained`, `forbidden`, `casterChoosesLocation`

**c4-new-1**: extract a small shared partial `item-toggle-row.hbs` for rendering a row of toggle chips. Takes a single param `chips: [{ property, label, tooltip, active }]` and emits a flex row of `.elysium-item-toggle` elements with `data-action="itemToggle" data-property=...`. Used by divine's existing flag row + arcane + sorcery + future-proofing other consumers.

Decision: introduce the partial in cluster 4. Divine's `divine.detail.hbs` flag-row block (currently inline using `.elysium-divine-flag-row` class) MIGRATES to use the new partial via a 1-line targeted edit — same isolation pattern as cluster 3b's skill PARTS.header swap. Retire the `.elysium-divine-flag-row` CSS class in favor of `.elysium-item-toggle-row` (renaming for clarity; the divine-specific naming was vestigial of cluster 3a's per-item scope).

### c4-new-2: `templates/item/parts/item-tier-effect-row.hbs` (new)

Sorcery's per-tier effect row is 18 lines of template (header tier+cost / textarea / damage+locations sub-row). Divine ALREADY has a similar per-tier-effect block (currently inline in `divine.detail.hbs`, lines 134-151). Divine's version differs: textarea only, no damage/locations sub-row. They're not identical, but the textarea + tier header chrome is.

**c4-new-2**: extract `item-tier-effect-row.hbs` with optional `showDamageLocations` flag. When false (divine), only renders the textarea. When true (sorcery), renders the damage dice + locations sub-row underneath. Centralizes the per-tier effect markup so future spell-with-tier consumers (none planned beyond cluster 4) can reuse, and divine + sorcery share the chrome.

Decision: introduce the partial in cluster 4. Divine migrates inline.

### c4-new-3: `templates/item/parts/item-ap-grid.hbs` (new)

Both divine and sorcery render a 5-cell T1-T5 AP cost grid. Divine's inline markup (`elysium-divine-ap-grid` / `elysium-divine-ap-cell` / `elysium-divine-ap-label`) and sorcery's inline markup (`elysium-tier-grid` / `elysium-tier-cell` / `elysium-tier-label`) are mechanically identical — 5 cells, each with a T-label header and a numeric input (or readonly value).

**c4-new-3**: extract `item-ap-grid.hbs`. Takes `apCostByTierList` (array of `{tier, cost, idx}`) and an `isGM` flag. Renders the 5-cell grid. Divine migrates via 1-line swap.

Trade-off: this is 3 new partials in one cluster (item-toggle-row, item-tier-effect-row, item-ap-grid). Cluster 3b introduced 2 (specialism header + skill-row) successfully. The pattern works.

## Per-type ship plan

### c4-arcane-1 — F/T row dropdowns + add/remove preservation

Arcane's F/T compendium-driven dropdowns are unique and well-loved. The cluster-4 rebuild:

1. PRESERVE `_onFTAdd` / `_onFTRemove` static action handlers (lines 230-276 of arcane.mjs). The action wiring is identical to V14 conventions and works correctly.
2. PRESERVE `_prepareSubmitData` + `_coerceArray` (lines 208-227). These are essential for normalizing the per-row inputs after expandObject.
3. PRESERVE `getArcaneFormsTechniquesFromCompendium()` integration. The cache + fallback paths are battle-tested.
4. REWRITE template to:
   - Use v1.0.0 BEM classes (`elysium-arcane-ft-rows`, `elysium-arcane-ft-row`, `elysium-arcane-ft-select`, `elysium-arcane-ft-add`, `elysium-arcane-ft-remove`).
   - Keep `data-action="ftAdd|ftRemove"` action wiring (V14 actions are stable cross-cluster).
   - Keep `data-ft-kind`, `data-ft-index` attributes (used by both action handlers).
   - Remove the legacy `data-handle-change` attribute from save-skill select (item sheets use `submitOnChange` not `change` events).

5. CLEAN UP the debug `console.log` calls in `_onFTAdd` + `_onRender` (lines 231-238, 250-251, 259, 280-295). These were diagnostic from the v0.10.0 era when the action wiring was unstable. Keep ONE `console.warn` for the "invalid kind" path (defensive). Drop the rest.

6. Replace native `<input type="checkbox">` flag block (lines 174-185) with the new `item-toggle-row.hbs` partial. Add `isRitual` + `isPermanent` to writable allow-list in base-item-sheet.mjs (currently NEITHER is in the allow-list, since arcane's flags route through `submitOnChange` → `_prepareSubmitData` not through `itemToggle`).

   **c4-arcane-1-decision-point**: should arcane's flags use itemToggle (BEM chips) OR stay as native checkboxes? Trade-offs:
   - **Chips**: visually consistent with divine, super, mutation, gear. UI parity.
   - **Native checkboxes**: simpler, no extra writable allow-list entries. Submit on change happens automatically.

   Recommendation: **chips**. UI consistency is high-value across the spell-items family (divine + arcane + sorcery should look + behave alike). Adds 2 entries to writable list: `isRitual`, `isPermanent`. Same per-property scope as divine's 3 entries already in the list.

### c4-arcane-2 — Header chips

Per audit-3-cluster-3 spell-item chips: School + RequiredSL + BasePP + APCost (4 chips). All come from `system.elysium.*`.

### c4-arcane-3 — Field-row partial migration

Arcane's 5 stat-input-style rows (school, requiredSL, basePP, apCost, saveSkill) plus the 3 prose-style rows (range, duration, damage flavor) → all migrate to `item-field-row.hbs` calls with `tooltip=...` for the description tooltips. Save-skill becomes the shared `getSpellSaveSkillOptions()` helper + standard select inside the field-row.

### c4-arcane-4 — Hardcoded English purge

Lines with hardcoded English tooltips and placeholders:
- Line 21: `"Number of Success Levels the caster must accumulate to complete this spell."` → `Elysium.requiredSLHint`
- Line 33: `"Power Points consumed on completion. Overcast → fatigue."` → `Elysium.basePPHint`
- Line 45: `"Action Points spent per cast attempt. Default 1."` → `Elysium.apCostHint`
- Line 57: `"Skill targets use to oppose this spell. Empty = no save."` → `Elysium.saveSkillSpellHint`
- Line 96: `"Flavour text only since v0.10.0. Actual damage is derived..."` → `Elysium.damageFlavourHint`
- Line 107: `"Forms describe what the magic affects..."` → `Elysium.formsHint`
- Line 140: `"Techniques describe what the spell does..."` → `Elysium.techniquesHint`
- Line 14: `placeholder="Evocation, Abjuration, Illusion, ..."` → `Elysium.schoolPlaceholder`
- Line 98: `placeholder="(flavour) e.g. fire damage"` → `Elysium.damageFlavourPlaceholder`

All 9 strings → 9 new i18n keys with en/es/fr translations.

### c4-sorcery-1 — Essence selector

Sorcery's essence selector (line 10-24) is a 13-option select with hardcoded English labels INCLUDING the "(forbidden)" parenthetical. Three options have it: death, blight, void.

**c4-sorcery-1 decision**: introduce `ElysiumSelectLists.getSorceryEssenceOptions()` returning a localized 13-entry list. The "(forbidden)" suffix should be a separate column in the rendered option:
- Option A: localize as part of the label string (e.g. `'death': 'Muerte (prohibida)'` in Spanish).
- Option B: format inside the helper: `option.label = (forbidden) ? '${localized} (${localizedForbidden})' : localized`.

Option B is cleaner — the helper becomes:
```js
static async getSorceryEssenceOptions() {
  const FORBIDDEN = ['death', 'blight', 'void'];
  const ESSENCES = ['', 'elemental', 'vitality', 'death', 'ward', 'light',
                    'shadow', 'mind', 'presence', 'soul', 'wild', 'blight', 'void'];
  const forbidden = game.i18n.localize('Elysium.forbidden');
  const map = {};
  for (const k of ESSENCES) {
    const base = k === '' ? '—' : game.i18n.localize(`Elysium.essence${capitalize(k)}`);
    map[k] = FORBIDDEN.includes(k) ? `${base} (${forbidden})` : base;
  }
  return map;
}
```
This keeps i18n keys flat (12 essence labels + 1 forbidden suffix = 13 keys × 3 langs).

**c4-sorcery-2**: in addition to the dropdown, render a visual "forbidden" badge in the readonly view when essence is one of the 3 forbidden. Same `.elysium-spell-forbidden-tag` class with red accent.

### c4-sorcery-3 — 14-entry damage type select

Per c4-1: new helper `getSorceryDamageTypeOptions()` returning the 14-entry list (15 with "none"). 9 new damage tokens needed for the readonly tag styling: slashing/piercing/bludgeoning/force/cold/corrosive/poison/necrotic/psychic/distortion. (radiant/lightning/fire/sonic already exist from cluster 3a.)

**c4-sorcery-3 decision**: damage-type accent palette. Cluster 3a added `--ely-accent-gold/electric/fire/air` (4 colors). Sorcery needs ~10 more colors. Going from 4 to 14 accents adds a lot of token surface area. Trade-offs:

- **Option A**: full palette — one distinct color per damage type. Visually maximum, but a lot of tokens.
- **Option B**: family palette — group damage types into 3-4 families with a color per family (physical: brown; elemental: per-element; magical-positive: gold/cyan; magical-negative: purple/green).
- **Option C**: monochrome — single accent token for all damage types, distinguished only by the type label text. Minimum surface, least visual distinction.

Recommendation: **Option B**. Adds 6 tokens (physical, cold, corrosive, poison, necrotic-psychic, distortion) on top of the existing 4. Each damage type maps to one of 10 total accent tokens. Reusable for weapon-damage chips in cluster 5 (alpha.43 weapon ship). Per-family table:
- physical (slashing, piercing, bludgeoning, force) → `--ely-accent-physical` (steel grey)
- fire → `--ely-accent-fire` (existing)
- cold → `--ely-accent-cold` (icy blue)
- lightning → `--ely-accent-electric` (existing)
- corrosive → `--ely-accent-corrosive` (acid green)
- sonic → `--ely-accent-air` (existing, reused)
- poison → `--ely-accent-poison` (sickly green)
- necrotic, psychic → `--ely-accent-mind` (dark purple)
- radiant → `--ely-accent-gold` (existing)
- distortion → `--ely-accent-distortion` (pale violet)

5 new tokens: physical, cold, corrosive, poison, mind, distortion. Plus reusing 4 existing.

### c4-sorcery-4 — Conditional Maintain PP row

The current template renders the Maintain PP/round row only `{{#if item.system.elysium.isSustained}}`. Preserve this conditional in v1.0.0 markup. Once `isSustained` is toggled via the new BEM chip, the form re-submits and the row appears/disappears on re-render.

### c4-sorcery-5 — Field-row migration

Sorcery's 7 stat-input-style rows (essence, baseTier, maxTier, powerCost, damageType, saveSkill, range) + conditional maintainPPPerRound → all migrate to `item-field-row.hbs`.

### c4-sorcery-6 — Form handler preservation

`mySorceryHandler` (lines 163-187) preserves legacy `maxLvl`/`currLvl`/`memLvl`/`var` fields that the new template doesn't expose. PRESERVE the handler unchanged. It defensively reads existing values when template fields are absent — exactly the right behavior. Cluster 4 doesn't touch the legacy field handling.

### c4-sorcery-7 — Hardcoded English purge

Lines with hardcoded English:
- Line 8: `"Which essence this ability belongs to..."` tooltip → `Elysium.essenceHint`
- Line 33: `"Lowest tier this ability can be cast at..."` tooltip → `Elysium.baseTierSorceryHint` (different text than divine's `baseTierHint`)
- Line 45: `"Highest tier this ability scales to..."` tooltip → `Elysium.maxTierHint` (already exists from alpha.40)
- Line 58: `"PP paid at cast time..."` tooltip → `Elysium.powerCostSorceryHint`
- Line 72: `"AP Cost by Tier"` section title → already in `Elysium.apCostByTier`
- Line 92: `"Damage type drives the cross-tradition..."` tooltip → `Elysium.damageTypeSorceryHint`
- Line 144: `"Effects by Tier"` section title → already in `Elysium.effectsByTier`
- Lines 146-149: section hint paragraph → `Elysium.effectsByTierSorceryHint` (multi-line key)
- Line 165: `"Damage dice expression for this tier..."` → `Elysium.damageDiceHint`
- Line 170: `"How many random hit locations are hit..."` → `Elysium.locationsHint`
- Line 169: `placeholder="e.g. 1d6"` → `Elysium.damageDicePlaceholder`
- Line 181: `<em>(no effect description for this tier)</em>` → `Elysium.noTierEffect`
- Line 186: `<em>Damage: ${dice} × ${count} location(s)</em>` → `Elysium.tierDamageReadonly` (with placeholder substitution: `{dice} × {count} {Elysium.locations}`)
- Lines 214, 219, 224, 230: 4 flag-checkbox labels (`Damage / Healing Spell`, `Sustained Spell`, `Forbidden`, `Caster Chooses Location`) → 4 i18n keys (some already exist: `Elysium.damageSpell`, will add `Elysium.sustained`, `Elysium.forbidden`, `Elysium.casterChoosesLocation`)
- Line 221: forbidden tooltip → `Elysium.forbiddenHint`
- Line 226: caster-chooses tooltip → `Elysium.casterChoosesLocationHint`
- Line 235: maintain tooltip → `Elysium.maintainPPHint`
- Line 236: `"Maintain PP/round"` label → `Elysium.maintainPP`

~15 new sorcery-specific i18n keys.

## Hoisted state machinery

Both arcane and sorcery currently have their own copies of:
- `_getTabs(parts)` — identical 35-line implementation
- `_configureRenderOptions(options)` — identical 6-line implementation  
- Description + gmNotes preparePartContext branches — identical 16-line implementation

**All three are already hoisted into `ElysiumItemSheetV2.base-item-sheet.mjs` from cluster 2** (the P10 cluster 2 base hoist). Cluster 4 sheets simply omit them and let inheritance do the work.

LOC saved per sheet: ~60 lines (skip the _getTabs + _configureRenderOptions duplicates).

## Critical preservation contracts

### Downstream consumers MUST continue to work unchanged

Sorcery system fields consumed by `module/casting/sorcery-cast.mjs`:
- `system.elysium.essence`, `baseTier`, `maxTier`, `powerCost`, `apCostByTier[]`, `effectByTier{}`, `damageByTier[]`, `locationsByTier[]`, `damageType`, `saveSkill`, `isDamageSpell`, `isSustained`, `forbidden`, `casterChoosesLocation`, `maintainPPPerRound`

Arcane system fields consumed by `module/casting/manipulation-dialog.mjs`, `module/casting/sustain.mjs`, custom-spell-builder, F/T checks:
- `system.elysium.school`, `requiredSL`, `basePP`, `apCost`, `saveSkill`, `forms[]`, `techniques[]`, `isRitual`, `isPermanent`, `isDamageSpell`, `isSustained`

Plus the legacy variable-level fields on sorcery (`var`, `maxLvl`, `currLvl`, `memLvl`) preserved via defensive form handler.

**No DataModel changes. No field renames. No shape changes.** v1.0.0 rebuild is purely sheet + template + CSS.

### Legacy CSS retirement (cluster 4 cleanup)

After cluster 4 ships, the following CSS class definitions in `styles/elysium.css` become orphan (no consumers):
- `.elysium-spell-sheet`, `.elysium-spell-tags`, `.elysium-spell-tag` + `.form` + `.technique`, `.elysium-spell-flags`, `.elysium-spell-sheet hr` (lines 1600-1700)
- `.elysium-spell-section`, `.elysium-spell-section-title`, `.elysium-spell-section-hint`, `.elysium-tier-grid`, `.elysium-tier-cell`, `.elysium-tier-label`, `.elysium-tier-cell input[type="number"]`, `.elysium-tier-effect-row`, `.elysium-tier-effect-header`, `.elysium-tier-effect-tier`, `.elysium-tier-effect-cost`, `.elysium-tier-effect-text`, `.elysium-tier-effect-readonly` (lines 2947-3060)
- `.elysium-ft-rows`, `.elysium-ft-row`, `.elysium-ft-select`, `.elysium-ft-add`, `.elysium-ft-remove` (similar block)
- `.elysium-cast-damage-type-tag` + `.elysium-damage-*` legacy palette

**c4-cleanup-1**: retire these CSS blocks in cluster 4 ship after pre-flight grep confirms zero remaining `.hbs` + `.mjs` references. Same orphan-retirement pattern as cluster 3b's `skill.header.hbs` deletion.

Estimated CSS retirement: **~150 lines from `styles/elysium.css`**. Brace count: minus ~30 pairs.

## Action handlers

Arcane keeps:
- `ftAdd` (V14 action, static handler) — unchanged
- `ftRemove` (V14 action, static handler) — unchanged
- `itemToggle` (inherited from base) — extended writable list to include `isRitual` + `isPermanent`

Sorcery keeps:
- `itemToggle` (inherited from base) — extended writable list to include `isSustained`, `forbidden`, `casterChoosesLocation` (isDamageSpell already in list from cluster 3a)
- Form handler `mySorceryHandler` — unchanged
- No new V14 actions needed; the per-tier textarea/inputs all submit through form-on-change

## Smoke risks specific to cluster 4

1. **F/T compendium dependency** — the dropdown options come from
   `getArcaneFormsTechniquesFromCompendium()`. If the compendium isn't
   loaded yet at sheet-render time, the function returns empty arrays
   (with a console.warn). Cluster 4 must not change this fallback
   behavior. Smoke: render an arcane sheet immediately after world
   load (before compendium pages are paged in) to verify graceful
   degradation.

2. **F/T cache staleness** — `_ftCache` lives until page reload. If
   the GM edits the arcane-knowledge compendium during a session, the
   dropdowns won't refresh. NOT a cluster-4 concern (this behavior
   pre-existed); document as known limitation. The `invalidateFTCache()`
   helper exists for future use.

3. **Cached compiled templates** — arcane.mjs line 60-62 has a comment
   about `(eq ...)` helper resolution failing on cached templates. The
   current code precomputes `selected` in `_prepareContext` to avoid
   the issue. PRESERVE this precompute pattern. The new template
   should still use `{{#if opt.selected}}selected{{/if}}`, NOT
   `{{#if (eq opt.value row.value)}}selected{{/if}}`.

4. **Sorcery effectByTier key normalization** — line 63 of sorcery.mjs:
   `text: effectByTier[String(t)] ?? effectByTier[t] ?? ''`. This
   handles both numeric and string keys after Foundry's expandObject
   path. Preserve unchanged.

5. **Sorcery damage type accent on no-damage spells** — when
   `damageType === ''`, the readonly view shows "—" with no tag.
   Preserve. The 15-option list includes a "" → "—" entry; the
   readonly branch must NOT emit `elysium-damage-` class for the
   empty case.

6. **Native checkbox → BEM chip migration submit-data** — V14 native
   checkboxes submit `{name: true|false}`. BEM chips wired through
   `itemToggle` call `await this.item.update({[property]: !current})`.
   Both store identical boolean values. No DataModel change needed.
   But: if an arcane sheet is OPEN with the legacy native checkbox
   UI when alpha.42 deploys (mid-session), the checkbox click would
   submit the form, which would route through the new template (no
   checkbox emitted), so the boolean wouldn't change. This is the
   standard "reload sheets after system update" requirement and
   doesn't justify keeping the legacy markup alive.

7. **Sorcery defaultTab vs activeTab** — sorcery's height is 525px in
   legacy (smaller than divine's 720). Wider+taller defaults in
   cluster 4 will overlap with the V14 default-tab behavior:
   `tabGroups.primary` defaults to `details`. Preserve. Pre-flight:
   verify open sheets default to the details tab not the description
   tab.

8. **Sorcery form handler legacy fields** — `mySorceryHandler` reads
   `system.var`, `system.maxLvl`, `system.currLvl`, `system.memLvl`.
   These were ELYSIUM SKILL fields in pre-v0.19.0 codebases. They
   are vestigial on sorcery items (the DataModel still has them
   nullable). The handler defensively preserves values when template
   fields are absent. PRESERVE the handler. Don't try to remove
   these fields from the DataModel in cluster 4 — that's P12 work.

## New i18n keys (cluster 4)

Total: **~30 new keys × 3 langs**. Largest single batch since cluster 3a (38 keys).

Arcane (9 keys):
- `requiredSLHint`, `basePPHint`, `apCostHint`, `saveSkillSpellHint`,
  `damageFlavourHint`, `formsHint`, `techniquesHint`,
  `schoolPlaceholder`, `damageFlavourPlaceholder`

Sorcery (~16 keys):
- `essenceHint`, `baseTierSorceryHint`, `powerCostSorceryHint`,
  `damageTypeSorceryHint`, `effectsByTierSorceryHint`,
  `damageDiceHint`, `locationsHint`, `damageDicePlaceholder`,
  `noTierEffect`, `tierDamageReadonly`, `forbiddenHint`,
  `casterChoosesLocationHint`, `maintainPPHint`,
  `forbidden`, `sustained`, `casterChoosesLocation`,
  `maintainPP`, `locations`

Damage type labels (9 new):
- `damageSlashing`, `damagePiercing`, `damageBludgeoning`, `damageForce`,
  `damageCold`, `damageCorrosive`, `damagePoison`, `damageNecrotic`,
  `damagePsychic`, `damageDistortion`

Essence labels (12 + 1 suffix):
- `essenceElemental`, `essenceVitality`, `essenceDeath`, `essenceWard`,
  `essenceLight`, `essenceShadow`, `essenceMind`, `essencePresence`,
  `essenceSoul`, `essenceWild`, `essenceBlight`, `essenceVoid`,
  `forbidden` (already counted above)

Some overlap: `forbidden` and `damageRadiant`/`damageFire`/`damageCold`/`damageLightning`/`damageSonic` already exist. Final unique new keys: ~37.

## New design tokens

5 new accent tokens:
- `--ely-accent-physical` (steel grey, ~#9aa3b1)
- `--ely-accent-cold` (icy blue, ~#7ac1e6)
- `--ely-accent-corrosive` (acid green, ~#a8d04a)
- `--ely-accent-poison` (sickly green, ~#5e8c3a)
- `--ely-accent-mind` (dark purple, ~#7e5fb3)
- `--ely-accent-distortion` (pale violet, ~#b59ccc)

(That's 6, not 5 — recounting: physical, cold, corrosive, poison, mind, distortion. **6 new tokens.**)

## Cluster 4 LOC reduction estimate

| Type | alpha.41 | alpha.42 est. | Δ |
|---|--:|--:|--:|
| arcane | 302 | ~135 | -167 |
| sorcery | 192 | ~110 | -82 |
| **subtotal sheets** | **494** | **245** | **-249** |
| + select-lists additions (helpers + i18n routing) | — | ~50 | +50 |
| + 3 new partials (item-toggle-row, item-tier-effect-row, item-ap-grid) | — | ~80 | +80 |
| − legacy CSS retirement (~150 lines from elysium.css) | — | — | -150 |
| **net effect (LOC)** | **494** | **224** | **-270 (-55%)** |

Strong reduction because:
- Arcane drops ~60 LOC of debug console.log + hoisted boilerplate (_getTabs, _configureRenderOptions, description/gmNotes branches).
- Sorcery drops ~80 LOC same way + the inline 13-option hardcoded essence list + 14-option damage type list move to helpers.

## Cluster 4 open questions for user lock-in

1. **c4-1** — confirm renaming `getSpellDamageTypeOptions()` → `getDivineDamageTypeOptions()` (1-line callsite swap in divine.mjs) and adding new `getSorceryDamageTypeOptions()` with the 14-entry list. **Recommendation: yes**.

2. **c4-2** — confirm the 3 new shared partials (item-toggle-row, item-tier-effect-row, item-ap-grid) + divine migration to all three. **Recommendation: yes** — 1-line PARTS swap per partial; divine becomes a stronger reference implementation for cluster 4.

3. **c4-3** — arcane flag UI: BEM chips (UI consistency) vs native checkboxes (simpler)? **Recommendation: BEM chips** for spell-family UI consistency. Adds 2 properties (`isRitual`, `isPermanent`) to writable allow-list in base-item-sheet.mjs.

4. **c4-4** — sorcery damage-type accent palette: full per-type (14 tokens), family-grouped (6 new tokens), or monochrome (0 new tokens)? **Recommendation: family-grouped** (Option B). 6 new tokens; reusable for weapon damage chips in cluster 5.

5. **c4-5** — sorcery essence "(forbidden)" suffix: localize in helper (Option B) or in i18n key (Option A)? **Recommendation: helper-side composition** (Option B). 1 i18n key for the suffix, reusable across essence + future per-essence forbidden contexts.

6. **c4-6** — debug console.log retirement in arcane.mjs: drop all 4 diagnostic logs (one in `_onFTAdd`, one in `_onFTRemove`, one in `_onRender`)? **Recommendation: yes**, keeping 1 `console.warn` for invalid kind. The action system is stable; the debug noise no longer earns its keep.

7. **c4-7** — sorcery legacy variable-level fields (`var`, `maxLvl`, `currLvl`, `memLvl`): touch in cluster 4? **Recommendation: NO**. The form handler defensively preserves them; v1.0.0 template doesn't expose them. DataModel cleanup is P12 territory (with proper migration story).

8. **c4-8** — legacy CSS retirement: delete the orphan `elysium-spell-sheet`, `elysium-spell-tag*`, `elysium-tier-*`, `elysium-ft-*` blocks from `styles/elysium.css` (~150 lines)? **Recommendation: yes** — orphan retirement per cluster-isolation pattern. Pre-flight grep verifies zero remaining refs first.

9. **c4-9** — width plan: arcane 720×640, sorcery 720×720 (wide-tier)? **Recommendation: yes** — matches divine's spell-with-tiers profile; consistent across all 3 spell families.

10. **c4-10** — LOC target 494 → 224 (-270, -55%)? Plus orphan CSS retirement (-150 from elysium.css). **Recommendation: yes**.

## Ready-to-go checklist

- [x] 2 sheet classes inspected (302 + 192 = 494 LOC)
- [x] 2 detail templates inspected (189 + 249 = 438 LOC)
- [x] F/T compendium loader + cache behavior understood
- [x] Form handler legacy-field preservation contract identified
- [x] Casting-side downstream dependencies enumerated
- [x] Sorcery 14-entry damage palette vs divine 5-entry distinction surfaced
- [x] Cross-cluster shared-partial opportunities identified (3 new partials)
- [x] Header chip plan per item
- [x] Hardcoded English purge inventory (~30 i18n keys to add)
- [x] New design tokens (~6 family-grouped accents)
- [x] Smoke risks enumerated (8 distinct)
- [x] Legacy CSS retirement scope (~150 lines)
- [ ] User decision on 10 cluster-4 open questions
- [ ] Approval to ship cluster 4 (alpha.42)

---

**Audit posture**: read-only until user locks the 10 open questions.
