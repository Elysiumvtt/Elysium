/**
 * Elysium Rules — Configuration constants
 * 
 * All numerical values that need balancing are flagged TBD via
 * `null` or via the BALANCING object. Setting them here in one
 * place means future tuning is a single-file change.
 */

export const ELYSIUM = {}

ELYSIUM.MODULE_ID = 'elysium'
ELYSIUM.SYSTEM_ID = 'elysium'

// Difficulty grades (used everywhere)
ELYSIUM.DIFFICULTY = {
  veryEasy:           +40,
  easy:               +20,
  standard:             0,
  difficult:          -20,
  veryDifficult:      -40,
  extremelyDifficult: -80,
  herculean:          -80,
  hopeless:           -99,  // results in skill of 1
  nearlyImpossible:   -99,
}

// Action Point table — INT+DEX based
ELYSIUM.AP_TABLE = [
  { min:  1, max: 12, ap: 1 },
  { min: 13, max: 24, ap: 2 },
  { min: 25, max: 36, ap: 3 },
  { min: 37, max: 48, ap: 4 },
  { min: 49, max: 60, ap: 5 },
  { min: 61, max: 72, ap: 6 },
  { min: 73, max: 84, ap: 7 },
]

// Healing Rate table — Mythras CON-based
ELYSIUM.HEALING_RATE_TABLE = [
  { min:  1, max:  6, rate: 1 },
  { min:  7, max: 12, rate: 2 },
  { min: 13, max: 18, rate: 3 },
  { min: 19, max: 24, rate: 4 },
  { min: 25, max: 99, rate: 5 },
]

// Damage Modifier table — Mythras canonical (v0.10.3)
// Indexed by STR+SIZ. Returns a Roll-compatible dice expression string.
// Beyond 130, the table says "Continue Progression" — extending past
// that is deferred (most player-tier characters don't reach it).
ELYSIUM.DAMAGE_MOD_TABLE = [
  { min:   1, max:   5, dice: '-1d8' },
  { min:   6, max:  10, dice: '-1d6' },
  { min:  11, max:  15, dice: '-1d4' },
  { min:  16, max:  20, dice: '-1d2' },
  { min:  21, max:  25, dice: '+0' },
  { min:  26, max:  30, dice: '+1d2' },
  { min:  31, max:  35, dice: '+1d4' },
  { min:  36, max:  40, dice: '+1d6' },
  { min:  41, max:  45, dice: '+1d8' },
  { min:  46, max:  50, dice: '+1d10' },
  { min:  51, max:  60, dice: '+1d12' },
  { min:  61, max:  70, dice: '+2d6' },
  { min:  71, max:  80, dice: '+1d8+1d6' },
  { min:  81, max:  90, dice: '+2d8' },
  { min:  91, max: 100, dice: '+1d10+1d8' },
  { min: 101, max: 110, dice: '+2d10' },
  { min: 111, max: 120, dice: '+2d10+1d2' },
  { min: 121, max: 130, dice: '+2d10+1d4' },
]

// Fatigue level table — full Mythras
ELYSIUM.FATIGUE_LEVELS = [
  {
    level: 0, label: 'fresh',
    skillGrade: 0, movePenalty: 0, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 0,
    canAct: true, canReact: true,
  },
  {
    level: 1, label: 'winded',
    skillGrade: -20, movePenalty: 0, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 15,
    canAct: true, canReact: true,
  },
  {
    level: 2, label: 'tired',
    skillGrade: -20, movePenalty: -1, moveMult: 1,
    initiativePen: 0, apPenalty: 0,
    recoveryMins: 180,
    canAct: true, canReact: true,
  },
  {
    level: 3, label: 'wearied',
    skillGrade: -40, movePenalty: -2, moveMult: 1,
    initiativePen: -2, apPenalty: 0,
    recoveryMins: 360,
    canAct: true, canReact: true,
  },
  {
    level: 4, label: 'exhausted',
    skillGrade: -40, movePenalty: 0, moveMult: 0.5,
    initiativePen: -4, apPenalty: 1,
    recoveryMins: 720,
    canAct: true, canReact: true,
  },
  {
    level: 5, label: 'debilitated',
    skillGrade: -80, movePenalty: 0, moveMult: 0.5,
    initiativePen: -6, apPenalty: 2,
    recoveryMins: 1080,
    canAct: true, canReact: true,
  },
  {
    level: 6, label: 'incapacitated',
    skillGrade: -80, movePenalty: 0, moveMult: 0,
    initiativePen: -8, apPenalty: 3,
    recoveryMins: 1440,
    canAct: true, canReact: false,
  },
  {
    level: 7, label: 'semiConscious',
    skillGrade: null, movePenalty: 0, moveMult: 0,
    initiativePen: null, apPenalty: null,
    recoveryMins: 2160,
    canAct: false, canReact: false,
  },
  {
    level: 8, label: 'comatose',
    skillGrade: null, movePenalty: 0, moveMult: 0,
    initiativePen: null, apPenalty: null,
    recoveryMins: 2880,
    canAct: false, canReact: false,
  },
  {
    level: 9, label: 'dead',
    skillGrade: null, movePenalty: null, moveMult: null,
    initiativePen: null, apPenalty: null,
    recoveryMins: null,
    canAct: false, canReact: false,
  },
]

// Wound thresholds
ELYSIUM.WOUND_THRESHOLDS = {
  wounded:           { test: (curr, max) => curr > 0 && curr < max },
  severelyWounded:   { test: (curr, max) => curr > 0 && curr <= Math.floor(max / 2) },
  criticallyWounded: { test: (curr, max) => curr <= 0 && curr > -max },
  severed:           { test: (curr, max) => curr <= -max },
}

// Damage types
ELYSIUM.DAMAGE_TYPES = {
  // Physical
  slashing:    { category: 'physical', specialEffect: 'bleed' },
  piercing:    { category: 'physical', specialEffect: 'impale' },
  bludgeoning: { category: 'physical', specialEffect: 'stun' },
  crushing:    { category: 'physical', specialEffect: 'bypass-armor-2ap' },

  // Elemental
  fire:        { category: 'elemental', armor: 'normal' },
  cold:        { category: 'elemental', armor: 'normal' },
  lightning:   { category: 'elemental', armor: 'no-metal' },
  acid:        { category: 'elemental', armor: 'damage-armor-first' },
  force:       { category: 'elemental', armor: 'normal' },
  sonic:       { category: 'elemental', armor: 'half' },

  // Spiritual
  radiant:     { category: 'spiritual', armor: 'normal' },
  necrotic:    { category: 'spiritual', armor: 'ignore', special: 'reduces-max-hp' },
  psychic:     { category: 'spiritual', armor: 'ignore' },
  poison:      { category: 'spiritual', armor: 'by-application' },
}

// Resistance tiers
ELYSIUM.RESISTANCE_TIERS = {
  immune:     { multiplier: 0,    flat: 0, allowCondition: false },
  resistant:  { multiplier: 0.5,  flat: 0, allowCondition: true  },
  minor:      { multiplier: 1,    flat: 3, allowCondition: true  },
  none:       { multiplier: 1,    flat: 0, allowCondition: true  },
  vulnerable: { multiplier: 2,    flat: 0, allowCondition: true  },
}

// Weapon size and reach categories
// Mythras weapon SIZ tiers (also used as Force tiers for ranged weapons).
// Stored as letter codes for compactness; UI renders the full label.
ELYSIUM.WEAPON_SIZES = {
  T: 'Tiny',
  S: 'Small',
  M: 'Medium',
  L: 'Large',
  H: 'Huge',
  E: 'Enormous',
}

// Mythras melee weapon Reach categories. Reach is independent from Size
// (a long sword is Medium reach; a long spear is Long reach).
ELYSIUM.WEAPON_REACHES = {
  T:  'Touch',
  S:  'Short',
  M:  'Medium',
  L:  'Long',
  VL: 'Very Long',
  H:  'Huge',
}

// Ordered tier indices for size/reach comparisons. Higher = bigger/longer.
ELYSIUM.WEAPON_SIZE_ORDER = ['T', 'S', 'M', 'L', 'H', 'E']
ELYSIUM.WEAPON_REACH_ORDER = ['T', 'S', 'M', 'L', 'VL', 'H']

// Armor materials
// =====================================================================
// ARMOR MATERIALS (v0.20.0 expansion)
// =====================================================================
// Each material describes how it interacts with damage types and special
// effects. The `class` field classifies it into a broad damage-resolution
// bucket used by the damage-vs-armor table:
//
//   'organic' — cloth, leather, fur, hide. Insulates against fire/cold;
//               full AP against lightning (non-conductive); vulnerable
//               to acid.
//   'metal'   — bronze, iron, steel, mythril, adamantite. Conducts
//               electricity (bypassed by lightning); half-AP against
//               fire/cold; vulnerable to acid; resists sonic poorly.
//   'rigid'   — bone, dragonscale. Behaves like metal for thermal but
//               doesn't conduct electricity. Bone is brittle (separately
//               modeled via lower HP at the record level).
//   'natural' — intrinsic body armor (scales, chitin, etc., applied to
//               creatures via natural-armor traits). Stacks freely.
//
// `damageBucket` is the key used by the damage-vs-armor table. Adding
// a new material? Add it here and the damage table will pick it up.

ELYSIUM.ARMOR_MATERIALS = {
  natural:     { damageBucket: 'natural', conducts: false, reactToAcid: false, reactToSonic: false },

  // Organic (soft only)
  cloth:       { damageBucket: 'organic', conducts: false, reactToAcid: true,  reactToSonic: false },
  leather:     { damageBucket: 'organic', conducts: false, reactToAcid: true,  reactToSonic: false },
  fur:         { damageBucket: 'organic', conducts: false, reactToAcid: true,  reactToSonic: false },
  hide:        { damageBucket: 'organic', conducts: false, reactToAcid: true,  reactToSonic: false },

  // Rigid biological (plate only — no mail variant)
  bone:        { damageBucket: 'rigid',   conducts: false, reactToAcid: true,  reactToSonic: true  },
  dragonscale: { damageBucket: 'rigid',   conducts: false, reactToAcid: false, reactToSonic: true  },

  // Mundane metal (mail + plate)
  bronze:      { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true  },
  iron:        { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true  },
  steel:       { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true  },

  // Rare metal (mail + plate) — anti-supernatural properties handled by
  // damage-vs-armor in future versions; for now AP/HP curve matches
  // their base metal with descriptive flavor.
  'cold-iron': { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true,  antiFey: true,    antiFiend: true },
  silver:      { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true,  antiUndead: true, antiLycanthrope: true },

  // Magical metal (mail + plate)
  mithral:     { damageBucket: 'metal',   conducts: true,  reactToAcid: false, reactToSonic: true,  lightweight: true },
  orichalcum:  { damageBucket: 'metal',   conducts: true,  reactToAcid: false, reactToSonic: false, divine: true },
  adamantite:  { damageBucket: 'metal',   conducts: true,  reactToAcid: false, reactToSonic: false, indestructible: true },

  // Legacy 'metal' kept for backward compat with v0.19.x records.
  metal:       { damageBucket: 'metal',   conducts: true,  reactToAcid: true,  reactToSonic: true  },
}

// Armor flexibility
ELYSIUM.ARMOR_FLEXIBILITY = {
  natural:    { layer: 0, casting_arm: 0,   casting_head: 0,   casting_chest: 0, casting_abdomen: 0, casting_leg: 0   },
  flexible:   { layer: 1, casting_arm: -10, casting_head: -5,  casting_chest: -5, casting_abdomen: -3, casting_leg: -2 },
  inflexible: { layer: 3, casting_arm: -20, casting_head: -10, casting_chest: -8, casting_abdomen: -5, casting_leg: -3 },
}

// Armor layer system (WFRP 4e-derived):
// Three layers categorise where on the body the armor sits.
//   Natural — intrinsic (mutations, hide, scales). Always stacks freely.
//   Worn    — actual armor pieces. Stratified into soft → mail → plate.
//   Magical — magical wards / robes. One piece per location.
ELYSIUM.ARMOR_LAYERS = {
  natural: { label: 'Natural', conflicts: false, maxPerLocation: Infinity },
  worn:    { label: 'Worn',    conflicts: true,  maxPerLocation: 3 },
  magical: { label: 'Magical', conflicts: true,  maxPerLocation: 1 },
}

// Worn-armor substrata. Per Elysium's modified WFRP 4e rules: at most one
// piece per stratum per location. Soft is innermost, Mail is middle, Plate
// is outermost. You can layer Mail or Plate over Soft, and Plate over Mail.
// Two pieces of the same stratum on the same location is forbidden.
ELYSIUM.ARMOR_WORN_STRATA = {
  soft:  { label: 'Soft',  order: 1, maxAP: 2, examples: 'Padded, leather, gambeson' },
  mail:  { label: 'Mail',  order: 2, maxAP: 3, examples: 'Chain shirt, scale, brigandine' },
  plate: { label: 'Plate', order: 3, maxAP: 5, examples: 'Plate, breastplate, full helm' },
}

// AP cap per location (Worn layer only). Elysium uses 10 APs per location:
// 2 soft + 3 mail + 5 plate. Natural and Magical layers stack freely on top
// of this; their APs are added to total location AP without counting against
// the cap.
ELYSIUM.WORN_AP_CAP_PER_LOCATION = 10

// Total worn AP cap across the whole body (legacy field; kept for the
// old ARMOR_AP_CAP setting). Natural and magical layers don't count.
ELYSIUM.ARMOR_AP_CAP = 10

// =====================================================================
// ITEM MODIFIER PRESETS (v0.4.0+)
// =====================================================================
// Catalogue of named modifiers items can apply to actors via Active
// Effects. Each preset describes its target Attribute Key, default mode,
// human-readable label, and a short hint. The item sheet uses this list
// to build the "Worn Modifiers" presets dropdown; users can also pick
// "Custom..." to specify any Attribute Key directly.
//
// Sign convention: negative values are penalties, positive are bonuses.
// E.g. castingPenalty: -10 means worse, +5 means better.
//
// All Attribute Keys are under flags.elysium.modifiers.* unless the
// preset explicitly targets system.* (used for direct stat bumps).
ELYSIUM.MODIFIER_PRESETS = {
  // --- Magic & Casting --------------------------------------------
  castingPenalty: {
    key:   'flags.elysium.modifiers.castingPenalty',
    label: 'Casting Penalty',
    hint:  'Modifies all spell casting rolls (negative = penalty).',
    mode:  'ADD',
    category: 'magic',
  },
  manaRecoveryRate: {
    key:   'flags.elysium.modifiers.manaRecoveryRate',
    label: 'Mana Recovery Rate',
    hint:  'Multiplier on PP recovery (1.0 = normal, 1.5 = +50%).',
    mode:  'MULTIPLY',
    category: 'magic',
  },

  // --- Skills (categories) ----------------------------------------
  allSkills: {
    key:   'flags.elysium.modifiers.allSkills',
    label: 'All Skills',
    hint:  'Modifies every skill roll.',
    mode:  'ADD',
    category: 'skills',
  },
  physicalSkills: {
    key:   'flags.elysium.modifiers.physicalSkills',
    label: 'Physical Skills',
    hint:  'STR / CON / SIZ / DEX-based skills.',
    mode:  'ADD',
    category: 'skills',
  },
  mentalSkills: {
    key:   'flags.elysium.modifiers.mentalSkills',
    label: 'Mental Skills',
    hint:  'INT / POW-based skills.',
    mode:  'ADD',
    category: 'skills',
  },
  socialSkills: {
    key:   'flags.elysium.modifiers.socialSkills',
    label: 'Social Skills',
    hint:  'CHA / POW-based skills.',
    mode:  'ADD',
    category: 'skills',
  },

  // --- Skills (named) ---------------------------------------------
  stealth: {
    key: 'flags.elysium.modifiers.stealth', label: 'Stealth',
    hint: 'Modifies Stealth checks.', mode: 'ADD', category: 'skills',
  },
  athletics: {
    key: 'flags.elysium.modifiers.athletics', label: 'Athletics',
    hint: 'Modifies Athletics checks.', mode: 'ADD', category: 'skills',
  },
  endurance: {
    key: 'flags.elysium.modifiers.endurance', label: 'Endurance',
    hint: 'Modifies Endurance checks (and fatigue rolls).', mode: 'ADD', category: 'skills',
  },
  perception: {
    key: 'flags.elysium.modifiers.perception', label: 'Perception',
    hint: 'Modifies Perception checks.', mode: 'ADD', category: 'skills',
  },
  dodge: {
    key: 'flags.elysium.modifiers.dodge', label: 'Dodge',
    hint: 'Modifies Dodge skill rolls.', mode: 'ADD', category: 'skills',
  },
  parry: {
    key: 'flags.elysium.modifiers.parry', label: 'Parry',
    hint: 'Modifies Parry skill rolls.', mode: 'ADD', category: 'skills',
  },
  swim: {
    key: 'flags.elysium.modifiers.swim', label: 'Swim',
    hint: 'Modifies Swim checks.', mode: 'ADD', category: 'skills',
  },
  climb: {
    key: 'flags.elysium.modifiers.climb', label: 'Climb',
    hint: 'Modifies Climb checks.', mode: 'ADD', category: 'skills',
  },
  ride: {
    key: 'flags.elysium.modifiers.ride', label: 'Ride',
    hint: 'Modifies Ride checks.', mode: 'ADD', category: 'skills',
  },

  // --- Combat -----------------------------------------------------
  weaponDamage: {
    key:   'flags.elysium.modifiers.weaponDamage',
    label: 'Weapon Damage (flat)',
    hint:  'Flat numeric bonus added to weapon damage rolls (e.g. +2).',
    mode:  'ADD',
    category: 'combat',
  },
  weaponDamageDice: {
    key:   'flags.elysium.modifiers.weaponDamageDice',
    label: 'Weapon Damage (dice)',
    hint:  'Dice expression appended to weapon damage rolls (e.g. "+1d6"). Stored as string; injection at roll-time is a planned feature.',
    mode:  'OVERRIDE',
    category: 'combat',
    isString: true,
  },
  meleeAttack: {
    key: 'flags.elysium.modifiers.meleeAttack', label: 'Melee Attack',
    hint: 'Modifies melee to-hit rolls.', mode: 'ADD', category: 'combat',
  },
  rangedAttack: {
    key: 'flags.elysium.modifiers.rangedAttack', label: 'Ranged Attack',
    hint: 'Modifies ranged to-hit rolls.', mode: 'ADD', category: 'combat',
  },
  initiative: {
    key: 'flags.elysium.modifiers.initiative', label: 'Initiative',
    hint: 'Modifies initiative rolls.', mode: 'ADD', category: 'combat',
  },
  parryBonus: {
    key: 'flags.elysium.modifiers.parryBonus', label: 'Parry Bonus',
    hint: 'Defensive bonus when parrying.', mode: 'ADD', category: 'combat',
  },
  dodgeBonus: {
    key: 'flags.elysium.modifiers.dodgeBonus', label: 'Dodge Bonus',
    hint: 'Defensive bonus when dodging.', mode: 'ADD', category: 'combat',
  },
  apModifier: {
    key: 'flags.elysium.modifiers.apModifier', label: 'Action Points',
    hint: 'Adjusts the actor\'s Action Points pool.', mode: 'ADD', category: 'combat',
  },

  // --- Movement & Physical ----------------------------------------
  movePenalty: {
    key:   'flags.elysium.modifiers.movePenalty',
    label: 'Move Penalty',
    hint:  'Flat penalty to combat move (in feet).',
    mode:  'ADD',
    category: 'movement',
  },
  encReduction: {
    key:   'flags.elysium.modifiers.encReduction',
    label: 'ENC Reduction',
    hint:  'Reduces effective encumbrance from worn equipment.',
    mode:  'ADD',
    category: 'movement',
  },
  apHead: {
    key: 'flags.elysium.modifiers.armorPoints.head', label: 'AP — Head',
    hint: 'Direct AP bonus to the Head location.', mode: 'ADD', category: 'movement',
  },
  apChest: {
    key: 'flags.elysium.modifiers.armorPoints.chest', label: 'AP — Chest',
    hint: 'Direct AP bonus to the Chest location.', mode: 'ADD', category: 'movement',
  },
  apAbdomen: {
    key: 'flags.elysium.modifiers.armorPoints.abdomen', label: 'AP — Abdomen',
    hint: 'Direct AP bonus to the Abdomen location.', mode: 'ADD', category: 'movement',
  },
  apLeg: {
    key: 'flags.elysium.modifiers.armorPoints.leg', label: 'AP — Legs',
    hint: 'Direct AP bonus to leg locations.', mode: 'ADD', category: 'movement',
  },
  apArm: {
    key: 'flags.elysium.modifiers.armorPoints.arm', label: 'AP — Arms',
    hint: 'Direct AP bonus to arm locations.', mode: 'ADD', category: 'movement',
  },

  // --- Resilience -------------------------------------------------
  tempHPMax: {
    key: 'flags.elysium.modifiers.tempHPMax', label: 'Temp HP Max',
    hint: 'Increases the actor\'s Temp HP cap.', mode: 'ADD', category: 'resilience',
  },
  healingRate: {
    key: 'flags.elysium.modifiers.healingRate', label: 'Healing Rate',
    hint: 'Adjusts the actor\'s Healing Rate.', mode: 'ADD', category: 'resilience',
  },
  fatigueResist: {
    key:   'flags.elysium.modifiers.fatigueResist',
    label: 'Fatigue Resist',
    hint:  'Multiplier on fatigue gained (0.5 = half, 2.0 = double).',
    mode:  'MULTIPLY',
    category: 'resilience',
  },
}

// Categories for grouping presets in the dropdown UI
ELYSIUM.MODIFIER_CATEGORIES = {
  magic:      { label: 'Magic & Casting', order: 1 },
  skills:     { label: 'Skills',          order: 2 },
  combat:     { label: 'Combat',          order: 3 },
  movement:   { label: 'Movement',        order: 4 },
  resilience: { label: 'Resilience',      order: 5 },
}

// Flag tag set on every item-sourced modifier AE so we can distinguish
// them from condition AEs (which use flags.elysium.group).
ELYSIUM.ITEM_MODIFIER_FLAG = 'flags.elysium.itemModifier'

// Movement (in feet — display unit; metric tokens convert internally)
ELYSIUM.MOVEMENT = {
  combatMoveFt:        15,        // Free with action
  fullMoveAP:          1,
  runMultiplier:       3,
  runAP:               2,
  sprintMultiplier:    5,
  sprintAP:            3,
  swimDivisor:         2,
  climbAP:             1,
  jumpRunningDivisor:  2,
  jumpStandingDivisor: 4,
  crawlDivisor:        4,
  squareSizeFt:        5,
}

// Charging — bonus damage modifier steps
ELYSIUM.CHARGE_BONUS = {
  biped:        1,    // Damage Modifier +1 step
  fourLegged:   2,    // Damage Modifier +2 steps
  weaponSizeBonus: 1, // First blow weapon Size +1
  difficulty:   -20,  // Charge attack one grade harder
}

// Magic systems — universal across all four
ELYSIUM.MAGIC_SYSTEMS = ['arcane', 'sorcery', 'divine', 'mysticism']

// Magic systems affected by armor casting penalty
ELYSIUM.MAGIC_SYSTEMS_ARMOR_PENALISED = ['arcane', 'sorcery']
ELYSIUM.MAGIC_SYSTEMS_ARMOR_EXEMPT    = ['divine', 'mysticism']

// Arcane configuration
ELYSIUM.ARCANE = {
  damagePerMP:        1,    // 1 HP per MP — config; can be 2
  healingPerMP:       1,    // 1 HP healed per MP
  ongoingDamagePerMP: 1,    // 1 damage per round per 3 MP (see categories)
  multiComponentSurcharge: 2,
  improvisedSpellPenalty:  -20,    // one grade harder
  improvisedManaSurcharge:   2,    // +2 PP cost
  scrollPowSacrifice:        1,    // temporary
  permanentRunePerMP:        5,    // 1 POW per 5 MP permanent
  // School efficiency (51%+) — values TBD during balancing
  schoolEfficiency: [
    { thresholdMin:   1, thresholdMax:  50, manaReduction: 0,  slReduction: 0 },
    { thresholdMin:  51, thresholdMax:  60, manaReduction: 1,  slReduction: 1 },
    { thresholdMin:  61, thresholdMax:  70, manaReduction: 2,  slReduction: 2 },
    { thresholdMin:  71, thresholdMax:  80, manaReduction: 3,  slReduction: 3 },
    { thresholdMin:  81, thresholdMax:  90, manaReduction: 4,  slReduction: 4 },
    { thresholdMin:  91, thresholdMax:  99, manaReduction: 5,  slReduction: 5 },
    { thresholdMin: 100, thresholdMax: 999, manaReduction: 6,  slReduction: 6 },
  ],
}

// Sorcery configuration
ELYSIUM.SORCERY = {
  primaryEssences:        3,
  abilitiesPerEssence:    5,
  confluenceAbilityCount: 5,
  abilityUnlockCost:      [null, null, null, null, null, null], // TBD per tier
  // Restricted essences requiring GM approval
  restrictedEssences: ['death', 'void', 'corruption', 'chaos'],
}

// Divine / Patron configuration
ELYSIUM.DIVINE = {
  standings: ['devoted', 'faithful', 'wavering', 'fallen', 'revoked'],
  ppRecoveryStanding: {
    devoted:   { multiplier: 2,    sleepingOnly: true  },
    faithful:  { multiplier: 1,    sleepingOnly: false },
    wavering:  { multiplier: 0,    sleepingOnly: false, fixedAwake: 1 },
    fallen:    { multiplier: 0,    blocked: true },
    revoked:   { multiplier: 0,    blocked: true, abilitiesBlocked: true },
  },
  prayerRitualMinutes: { 1: 10, 2: 30, 3: 60, 4: 240, 5: 480 },
}

// Mysticism configuration
ELYSIUM.MYSTICISM = {
  // Activation roll required when ability IS the action
  // Per-ability flag; this is the rule reference only.
  activationRule: 'IS_THE_ACTION',
  meditationHours: 1,
}

// Superpowers
ELYSIUM.SUPERPOWERS = {
  // v1.0.0-alpha.11 (side-finding #11): renamed from favouredEnemyMaxTypes.
  nemesisMaxTypes: 3,
}

// Vision types — granted via Mutation or Superpower items
ELYSIUM.VISION_TYPES = {
  lowLight:    { type: 'mutation',   range:  0, identifier: 'lowLight' },
  infravision: { type: 'mutation',   range: 30, identifier: 'infravision' },
  darkvision:  { type: 'mutation',   range: 60, identifier: 'darkvision' },
  superiorDarkvision: { type: 'mutation', range: 120, identifier: 'superiorDarkvision' },
  blindsight:  { type: 'superpower', range: 30, identifier: 'blindsight' },
  truesight:   { type: 'superpower', range: 60, identifier: 'truesight' },
}

// Creature types
ELYSIUM.CREATURE_TYPES = [
  'aberration', 'animal', 'beast', 'celestial', 'construct', 'dragon',
  'elemental', 'fey', 'fiend', 'giant', 'humanoid', 'lycanthrope',
  'monstrosity', 'ooze', 'plant', 'undead', 'vermin',
  'astral', 'ethereal', 'shadow',
]

ELYSIUM.CREATURE_SUBTYPES = {
  humanoid:    ['human','elf','dwarf','halfling','gnome','orc','goblinoid',
                'kobold','lizardfolk','gnoll','yuan-ti','merfolk'],
  fiend:       ['demon','devil','daemon','yugoloth','rakshasa','nightHag'],
  undead:      ['corporeal','deathless'],
  dragon:      ['chromatic','metallic','gem','planar'],
  elemental:   ['fire','water','earth','air','lightning','ice',
                'void','ash','magma','mud','steam'],
  giant:       ['hill','stone','frost','fire','cloud','storm',
                'titan','cyclops','ogre','troll','ettin'],
  celestial:   ['angel','archon','azata','empyrean','planetar','solar'],
  lycanthrope: ['werewolf','wererat','werebear','wereboar','weretiger'],
  vermin:      ['spider','insect','scorpion','centipede','beetle',
                'swarmRat','swarmBat','swarmInsect','swarmSpider'],
}

ELYSIUM.CREATURE_TAGS = [
  'shapechanger','incorporeal','swarm','legendary','mindless',
  'aquatic','amphibious','extraplanar','lycanthrope','aberrant',
]

// Critical table location mapping
ELYSIUM.CRITICAL_TABLE_MAP = {
  head:        'head',
  arm:         'arm',
  leftArm:     'arm',
  rightArm:    'arm',
  chest:       'body',
  abdomen:     'body',
  leg:         'leg',
  leftLeg:     'leg',
  rightLeg:    'leg',
  wing:        'tailWing',
  leftWing:    'tailWing',
  rightWing:   'tailWing',
  tail:        'tailWing',
  fin:         'aquatic',
  gill:        'aquatic',
  tentacle:    'aquatic',
  // v0.13.0 additions for the expanded hit-location parts library:
  // forelegs/hindlegs route to the leg table; forequarters/hindquarters
  // route to the body table; general (amorphous fallback) routes to body.
  foreleg:     'leg',
  leftForeleg: 'leg',
  rightForeleg:'leg',
  hindleg:     'leg',
  leftHindleg: 'leg',
  rightHindleg:'leg',
  forequarters: 'body',
  hindquarters: 'body',
  general:     'body',
  default:     'body',
}

// Special effects (full Mythras list - kept as identifiers)
ELYSIUM.SPECIAL_EFFECTS = {
  offensive: [
    'bash', 'bleed', 'chooseLocation', 'circularStrike', 'compelSurrender',
    'damageWeapon', 'disarmOpponent', 'enhanceDamage', 'fellingBlow',
    'forceFailure', 'gainSpecialAbility', 'grip', 'impale', 'maximiseDamage',
    'overpenetration', 'pinDown', 'rapidReload', 'snareSomeone', 'stunLocation',
    'sunder', 'sweepAway', 'tripOpponent', 'wrongFooted',
  ],
  defensive: [
    'avoidance', 'blindOpponent', 'compelSurrender', 'counterAttack',
    'damageWeapon', 'disarmOpponent', 'enhanceParry', 'forceFailure',
    'gainSpecialAbility', 'maximiseDamage', 'pinWeapon', 'reactiveStrike',
    'snareSomeone', 'sunder',
  ],
}

// Special effect differential triggers (degree of advantage in opposed roll)
ELYSIUM.SE_DIFFERENTIAL = {
  criticalVsSuccess: 1,
  criticalVsFailure: 2,
  criticalVsFumble:  3,
  successVsFailure:  1,
  successVsFumble:   2,
  failureVsFumble:   1,
}

// EXP system
ELYSIUM.EXPERIENCE = {
  standardDie: 4,    // 1d4 base
  fastLearnerDie: 6, // Humans
  fumbleAdvancesImmediately: true,
  maxTicksPerSkillPerSession: 1,
}

// Stats — natural maximum before ancestry
ELYSIUM.STAT_NATURAL_MAX_BASE = 20

// Skill cap at character creation
ELYSIUM.STARTING_SKILL_CAP = 70    // hard cap

// Maximum bonuses per source
ELYSIUM.STARTING_SKILL_LIMITS = {
  perCareer:  15,    // max per single skill from career
  perAncestry:    15,    // max per single skill from ancestry
  hardCap:        70,    // total cap regardless of source
}

// Luck Points — Mythras canonical (v0.10.3)
// POW → integer table, same shape as Healing Rate.
ELYSIUM.LUCK_POINTS_TABLE = [
  { min:  1, max:  6, rate: 1 },
  { min:  7, max: 12, rate: 2 },
  { min: 13, max: 18, rate: 3 },
  { min: 19, max: 24, rate: 4 },
  { min: 25, max: 99, rate: 5 },
]
ELYSIUM.LUCK_POINTS = {
  // Recovery: full at start of each session
  combatSavesPerEncounter: 1,
}

// All TBD numerical values that need balancing later
ELYSIUM.BALANCING = {
  startingBuildPoints:     null,
  buildPointPerSkillPct:   null,
  buildPointSkillAccess:   null,
  packageSkillPointTotal:  null,
  packageBPCost:           null,
  expDicePerStatIncrease:  null,    // Method B uses current score
  abilityUnlockCostByTier: [null, 2, 3, 4, 5],
  startingWealthGold:      25,    // up to 25gp depending on career
  startingLuckPointsBase:   2,    // + POW bonus
}

// === HIT-LOCATION BODY SHAPES =======================================
// Defines the standard Mythras body-shape templates: which hit-location
// records (from the compendium pack) make up each set, with their d20
// roll ranges. Used by:
//   - ElysiumAncestryDrop to auto-apply locations on ancestry drop
//     (the culture item's system.elysium.ancestry.hitLocationSet field
//     names which shape to apply; defaults to 'humanoid')
//   - The GM hit-location-apply macros in the compendium pack
//
// Each spec is: { name: <compendium record name>, low: <roll min>,
//                 high: <roll max>, displayName?: <optional rename> }
// `name` MUST match a hit-location record name in the compendium pack
// (elysium-compendium.hit-locations). `displayName` overrides the on-actor
// label when the same compendium record serves different roles across
// body shapes (e.g. 'Forequarters' shown as 'Forequarters (Horse Body)'
// on Centaurs).
//
// Adding new body shapes: append a key here and create matching
// compendium records as needed. The set is sourced from compendium once
// per drop, so no system reload is required to use a new shape.

ELYSIUM.HIT_LOCATION_SETS = {
  'humanoid': [
    { name: 'Right Leg',  low:  1, high:  4 },
    { name: 'Left Leg',   low:  5, high:  8 },
    { name: 'Abdomen',    low:  9, high: 11 },
    { name: 'Chest',      low: 12, high: 15 },
    { name: 'Right Arm',  low: 16, high: 17 },
    { name: 'Left Arm',   low: 18, high: 19 },
    { name: 'Head',       low: 20, high: 20 },
  ],

  'quadruped': [
    { name: 'Right Hindleg', low:  1, high:  3 },
    { name: 'Left Hindleg',  low:  4, high:  6 },
    { name: 'Hindquarters',  low:  7, high: 10 },
    { name: 'Forequarters',  low: 11, high: 14 },
    { name: 'Right Foreleg', low: 15, high: 16 },
    { name: 'Left Foreleg',  low: 17, high: 18 },
    { name: 'Head',          low: 19, high: 20 },
  ],

  'winged-quadruped': [
    { name: 'Right Hindleg', low:  1, high:  2 },
    { name: 'Left Hindleg',  low:  3, high:  4 },
    { name: 'Hindquarters',  low:  5, high:  7 },
    { name: 'Forequarters',  low:  8, high: 10 },
    { name: 'Right Foreleg', low: 11, high: 12 },
    { name: 'Left Foreleg',  low: 13, high: 14 },
    { name: 'Right Wing',    low: 15, high: 16 },
    { name: 'Left Wing',     low: 17, high: 18 },
    { name: 'Tail',          low: 19, high: 19 },
    { name: 'Head',          low: 20, high: 20 },
  ],

  'centaur': [
    { name: 'Right Hindleg', low:  1, high:  2 },
    { name: 'Left Hindleg',  low:  3, high:  4 },
    { name: 'Hindquarters',  low:  5, high:  8, displayName: 'Hindquarters (Horse Body)' },
    { name: 'Right Foreleg', low:  9, high: 10 },
    { name: 'Left Foreleg',  low: 11, high: 12 },
    { name: 'Forequarters',  low: 13, high: 14, displayName: 'Forequarters (Horse Body)' },
    { name: 'Abdomen',       low: 15, high: 15, displayName: 'Humanoid Abdomen' },
    { name: 'Chest',         low: 16, high: 17, displayName: 'Humanoid Chest' },
    { name: 'Right Arm',     low: 18, high: 18 },
    { name: 'Left Arm',      low: 19, high: 19 },
    { name: 'Head',          low: 20, high: 20 },
  ],

  'avian': [
    { name: 'Right Leg',  low:  1, high:  3 },
    { name: 'Left Leg',   low:  4, high:  6 },
    { name: 'Abdomen',    low:  7, high:  9 },
    { name: 'Chest',      low: 10, high: 13 },
    { name: 'Right Wing', low: 14, high: 15 },
    { name: 'Left Wing',  low: 16, high: 17 },
    { name: 'Tail',       low: 18, high: 18 },
    { name: 'Head',       low: 19, high: 20 },
  ],

  'serpentine': [
    { name: 'Tail',         low:  1, high:  4 },
    { name: 'Hindquarters', low:  5, high: 11 },
    { name: 'Forequarters', low: 12, high: 18 },
    { name: 'Head',         low: 19, high: 20 },
  ],

  'hexapod': [
    { name: 'Right Hindleg', low:  1, high:  2 },
    { name: 'Left Hindleg',  low:  3, high:  4 },
    { name: 'Right Mid Leg', low:  5, high:  6 },
    { name: 'Left Mid Leg',  low:  7, high:  8 },
    { name: 'Right Foreleg', low:  9, high: 10 },
    { name: 'Left Foreleg',  low: 11, high: 12 },
    { name: 'Abdomen',       low: 13, high: 15 },
    { name: 'Chest',         low: 16, high: 18, displayName: 'Thorax' },
    { name: 'Head',          low: 19, high: 20 },
  ],

  'humanoid-hexapod': [
    { name: 'Right Leg',       low:  1, high:  3 },
    { name: 'Left Leg',        low:  4, high:  6 },
    { name: 'Abdomen',         low:  7, high:  9 },
    { name: 'Chest',           low: 10, high: 13 },
    { name: 'Right Lower Arm', low: 14, high: 15 },
    { name: 'Left Lower Arm',  low: 16, high: 17 },
    { name: 'Right Upper Arm', low: 18, high: 18 },
    { name: 'Left Upper Arm',  low: 19, high: 19 },
    { name: 'Head',            low: 20, high: 20 },
  ],

  'amorphous': [
    { name: 'General', low: 1, high: 20 },
  ],
}

// Display labels for the body-shape choices in the ancestry sheet dropdown.
// Keys must match ELYSIUM.HIT_LOCATION_SETS.
ELYSIUM.HIT_LOCATION_SET_LABELS = {
  'humanoid':         'Humanoid (default)',
  'quadruped':        'Quadruped',
  'winged-quadruped': 'Winged Quadruped',
  'centaur':          'Centaur',
  'avian':            'Avian',
  'serpentine':       'Serpentine',
  'hexapod':          'Hexapod',
  'humanoid-hexapod': 'Humanoid Hexapod',
  'amorphous':        'Amorphous',
}

// v0.22.0-alpha.9: ARMOR_LOCATION_HP_FACTORS removed. Armor HP is now
// flat per material (system.elysium.apMax) — no per-location scaling.
// Damage from critical hits (attack-roll crits or major wounds) decrements
// system.av1 by 1 until the piece is broken at av1 = 0.
