/**
 * Active-cast disruption (v0.16.0).
 *
 * When a wizard is mid-cast (multi-turn arcane spell with accumulated SL)
 * and takes damage, they roll Willpower. On failure, they lose accumulated
 * SL based on wound severity:
 *
 *   - Minor wound (damage > 0, location still functional)  → lose 1 SL
 *   - Serious wound (damage ≥ location maxHP × 2)          → lose 2 SL
 *   - Critical wound (damage ≥ location maxHP × 3)         → lose all SL
 *
 * The wizard's player rolls their own Willpower (via chat button); the GM
 * doesn't roll for them. This makes the wizard's "discipline under
 * pressure" a player-engaged moment, and lets the wizard's invested
 * Willpower skill matter mechanically.
 *
 * Flow:
 *   1. Wound created on actor (hooked in rules-module's register-hooks).
 *   2. checkActiveCastDisruption(actor, wound) — find active cast, classify
 *      severity, post a chat prompt with "Roll Willpower" button.
 *   3. On click, applyDisruptionRoll(actor, wound, rollResult) — roll
 *      success/fail, apply SL loss on failure, update active cast state,
 *      post resolution to chat.
 *
 * Active cast state is read/written via cast-shared's get/set/clearActiveCast.
 * If accumulated SL drops to 0 from a critical wound, the cast continues
 * (the wizard can keep accumulating from zero) — design decision: damage
 * disrupts work-in-progress, not the spell itself.
 *
 * If the active cast is *complete* (accumulatedSL >= requiredSL but the
 * cast hasn't been resolved yet — possible during the same-turn
 * resolution gap) we don't disrupt; the spell is already done.
 */

import { getActiveCast, setActiveCast } from './cast-shared.mjs'
/**
 * Classify wound severity from damage value and the affected hit location.
 * Returns one of 'minor' | 'serious' | 'critical' | null (no severity tier).
 *
 * @param {number} damage - HP damage dealt
 * @param {Item} location - hit-location item the wound is on
 * @returns {'minor'|'serious'|'critical'|null}
 */
export function classifyWoundSeverity (damage, location) {
  if (!damage || damage <= 0) return null
  const maxHP = Number(location?.system?.maxHP) || 0
  if (maxHP <= 0) return 'minor'  // can't tier without maxHP, default minor
  if (damage >= maxHP * 3) return 'critical'
  if (damage >= maxHP * 2) return 'serious'
  return 'minor'
}

/**
 * Map severity tier to SL loss per the design spec.
 *
 * @param {'minor'|'serious'|'critical'} severity
 * @returns {number|'all'} - SL count or 'all' for full loss
 */
export function slLossForSeverity (severity) {
  switch (severity) {
    case 'critical': return 'all'
    case 'serious':  return 2
    case 'minor':    return 1
    default:         return 0
  }
}

/**
 * Find the actor's Willpower skill total. Looks for a skill named
 * "Willpower" (case-insensitive). Returns 0 if not found, which means
 * the save will always fail — that's fine, encourages players to invest
 * in Willpower if they're playing a wizard.
 *
 * @param {Actor} actor
 * @returns {{name: string, total: number, found: boolean}}
 */
export function findWillpowerSkill (actor) {
  const skill = actor?.items?.find(i =>
    i.type === 'skill' && /^willpower$/i.test(i.name || ''))
  if (!skill) return { name: 'Willpower', total: 0, found: false }
  return {
    name: skill.name,
    total: Number(skill.system?.grandTotal ?? skill.system?.total ?? 0) || 0,
    found: true,
  }
}

/**
 * Check whether an active-cast disruption applies. Called from the
 * wound-created hook in register-hooks.mjs.
 *
 * Returns a description object suitable for posting a chat prompt, or
 * null if no disruption applies (no active cast, no SL accumulated, or
 * cast is already complete).
 *
 * @param {Actor} actor
 * @param {Item} wound - the wound item just created
 * @returns {{
 *   activeCast: object,
 *   severity: 'minor'|'serious'|'critical',
 *   slLoss: number|'all',
 *   damage: number,
 *   location: Item|null,
 *   willpower: object,
 * }|null}
 */
export function checkActiveCastDisruption (actor, wound) {
  if (!actor || !wound) return null
  const activeCast = getActiveCast(actor)
  if (!activeCast) return null
  if (!(activeCast.accumulatedSL > 0)) return null
  // If cast is already at requiredSL it's effectively done — don't disrupt.
  if (activeCast.accumulatedSL >= activeCast.requiredSL) return null

  const damage = Number(wound.system?.value) || 0
  if (damage <= 0) return null

  const locId = wound.system?.locId
  const location = locId ? actor.items.get(locId) : null
  const severity = classifyWoundSeverity(damage, location)
  if (!severity) return null

  const slLoss = slLossForSeverity(severity)
  const willpower = findWillpowerSkill(actor)

  return { activeCast, severity, slLoss, damage, location, willpower }
}

/**
 * Apply the result of a Willpower disruption roll. Called from the
 * chat-button click handler in register-hooks.mjs.
 *
 * On success (rolled <= willpower skill, not fumble) → no SL loss.
 * On failure → reduce accumulatedSL on the active cast by slLoss
 * ('all' = clear SL to 0). If active cast no longer exists (resolved
 * between prompt and click), no-op.
 *
 * @param {Actor} actor
 * @param {{rollValue: number, succeeded: boolean}} rollResult
 * @param {{slLoss: number|'all', severity: string, damage: number, willpowerName: string}} ctx
 * @returns {Promise<{outcome: string, slBefore: number, slAfter: number, slLost: number}|null>}
 */
export async function applyDisruptionRoll (actor, rollResult, ctx) {
  if (!actor) return null
  const cast = getActiveCast(actor)
  if (!cast) return null  // cast resolved between prompt and click

  const slBefore = Number(cast.accumulatedSL) || 0

  if (rollResult.succeeded) {
    return {
      outcome: 'concentration_held',
      slBefore,
      slAfter: slBefore,
      slLost: 0,
    }
  }

  // Failure — reduce SL.
  let slAfter = slBefore
  if (ctx.slLoss === 'all') {
    slAfter = 0
  } else {
    slAfter = Math.max(0, slBefore - ctx.slLoss)
  }
  const slLost = slBefore - slAfter

  await setActiveCast(actor, {
    ...cast,
    accumulatedSL: slAfter,
  })

  return {
    outcome: slAfter === 0 ? 'cast_disrupted' : 'sl_reduced',
    slBefore,
    slAfter,
    slLost,
  }
}
