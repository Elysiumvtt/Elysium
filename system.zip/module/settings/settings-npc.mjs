const SETTINGS = {

  tokenDropMode: {
    name: "Elysium.Settings.tokenDropMode",
    hint: "Elysium.Settings.tokenDropModeHint",
    scope: "world",
    config: false,
    default: "ask",
    type: String
  },

  npcName: {
    name: "Elysium.Settings.tokenDropName",
    hint: "Elysium.Settings.tokenDropNameHint",
    scope: "world",
    config: false,
    type: String,
    default: "NONE"
  },

  npcBars: {
    name: "Elysium.Settings.tokenDropBars",
    hint: "Elysium.Settings.tokenDropBarsHint",
    scope: "world",
    config: false,
    type: String,
    default: "NONE"
  }

}

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api
export class ElysiumNPCSettings extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    classes: ['elysium', 'rulesmenu'],
    id: 'char-settings',
    actions: {
      reset: ElysiumNPCSettings.onResetDefaults,
    },
    form: {
      handler: ElysiumNPCSettings.formHandler,
      closeOnSubmit: true,
      submitOnChange: false
    },
    position: {
      width: 550,
      height: 'auto',
    },
    tag: 'form',
    window: {
      resizable: true,
      title: 'Elysium.systemSettings',
      contentClasses: ["standard-form"]
    }
  }

  get title() {
    return `${game.i18n.localize(this.options.window.title)}`;
  }

  static PARTS = {
    form: { template: 'systems/elysium/templates/settings/npc-settings.hbs',
            scrollable: ['']
     },
    footer: { template: 'templates/generic/form-footer.hbs' }
  }

  async _prepareContext(options) {
    const isGM = game.user.isGM;
    const optSet = {}
    for (const [k, v] of Object.entries(SETTINGS)) {
      optSet[k] = {
        value: game.settings.get('elysium', k),
        setting: v
      }
    }
    optSet.tokenDropModeOptions = {
      "ask": game.i18n.localize('Elysium.Settings.tokenDropModeAsk'),
      "roll": game.i18n.localize('Elysium.Settings.tokenDropModeRoll'),
      "average": game.i18n.localize('Elysium.Settings.tokenDropModeAverage'),
      "ignore": game.i18n.localize('Elysium.Settings.tokenDropModeIgnore')
    }
    optSet.NPCNameOptions = {
      "NONE": game.i18n.localize("Elysium.Settings.displayNONE"),
      "ALWAYS": game.i18n.localize("Elysium.Settings.displayALWAYS"),
      "CONTROL": game.i18n.localize("Elysium.Settings.displayCONTROL"),
      "OWNER": game.i18n.localize("Elysium.Settings.displayOWNER"),
      "HOVER": game.i18n.localize("Elysium.Settings.displayHOVER"),
      "OWNER_HOVER": game.i18n.localize("Elysium.Settings.displayOWNER_HOVER")
    }
    optSet.NPCBarsOptions = {
      "NONE": game.i18n.localize("Elysium.Settings.displayNONE"),
      "ALWAYS": game.i18n.localize("Elysium.Settings.displayALWAYS"),
      "CONTROL": game.i18n.localize("Elysium.Settings.displayCONTROL"),
      "OWNER": game.i18n.localize("Elysium.Settings.displayOWNER"),
      "HOVER": game.i18n.localize("Elysium.Settings.displayHOVER"),
      "OWNER_HOVER": game.i18n.localize("Elysium.Settings.displayOWNER_HOVER")
    }
    return {
      isGM,
      optSet,
      buttons: [
        { type: "submit", icon: "fa-solid fa-save", label: "SETTINGS.Save" },
        { type: "reset", action: "reset", icon: "fa-solid fa-undo", label: "SETTINGS.Reset" },
      ]
    }
  }

  static registerSettings() {
    for (const [k, v] of Object.entries(SETTINGS)) {
      game.settings.register('elysium', k, v)
    }
  }

  static async onResetDefaults(event) {
    event.preventDefault()
    for await (const [k, v] of Object.entries(SETTINGS)) {
      await game.settings.set('elysium', k, v?.default)
    }
    return this.render()
  }

  static async formHandler(event, form, formData) {
    const settings = foundry.utils.expandObject(formData.object)
    await Promise.all(
      Object.entries(settings)
        .map(([key, value]) => game.settings.set("elysium", key, value))
    )
  }

}
